<?php
/**
 * Google Meet link completion for shared Group Session Calendar events.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Completes Google Meet URLs when Calendar conference creation is asynchronous.
 */
final class TutorHelper_Group_Calendar_Meeting_Link {

	const RETRY_HOOK = 'tutorhelper_group_calendar_meeting_link_retry';
	const MAX_ATTEMPTS = 4;
	const RETRY_DELAY = 15;

	/** Register Meet completion hooks. */
	public static function init() {
		add_action(
			'tutorhelper_group_session_calendar_synced',
			array( __CLASS__, 'handle_session_synced' ),
			20,
			4
		);

		add_action(
			self::RETRY_HOOK,
			array( __CLASS__, 'retry_meeting_link' ),
			10,
			2
		);
	}

	/**
	 * Queue a retry when Google accepted the event but has not finished the Meet.
	 *
	 * @param int    $session_id Group Session ID.
	 * @param int    $block_id Group Block ID.
	 * @param string $event_id Google event ID.
	 * @param string $meeting_url Current stored meeting URL.
	 * @return void
	 */
	public static function handle_session_synced(
		$session_id,
		$block_id,
		$event_id,
		$meeting_url
	) {
		if ( '' !== trim( (string) $meeting_url ) || '' === trim( (string) $event_id ) ) {
			return;
		}

		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block || 'online' !== sanitize_key( $block->location_type ) ) {
			return;
		}

		if (
			! class_exists( 'TutorHelper_Pro_Google_Calendar' )
			|| TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET
				!== TutorHelper_Pro_Google_Calendar::get_meeting_provider()
		) {
			return;
		}

		self::schedule_retry( $session_id, 1 );
	}

	/**
	 * Fetch the same Google event until its Meet URL becomes available.
	 *
	 * @param int $session_id Group Session ID.
	 * @param int $attempt Retry attempt number.
	 * @return void
	 */
	public static function retry_meeting_link( $session_id, $attempt = 1 ) {
		global $wpdb;

		$session_id = absint( $session_id );
		$attempt = max( 1, absint( $attempt ) );
		$session = TutorHelper_Group_Sessions::get_by_id( $session_id );

		if (
			! $session
			|| '' !== trim( (string) $session->meeting_url )
			|| empty( $session->calendar_event_id )
		) {
			return;
		}

		$block = TutorHelper_Group_Blocks::get_by_id( $session->block_id );
		if ( ! $block || 'online' !== sanitize_key( $block->location_type ) ) {
			return;
		}

		if (
			! class_exists( 'TutorHelper_Pro_Google_Calendar' )
			|| ! TutorHelper_Pro_Google_Calendar::is_connected()
			|| TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET
				!== TutorHelper_Pro_Google_Calendar::get_meeting_provider()
		) {
			return;
		}

		try {
			$event = TutorHelper_Pro_Google_Calendar::request(
				'GET',
				'/calendars/primary/events/'
					. rawurlencode( sanitize_text_field( $session->calendar_event_id ) ),
				null,
				array( 'conferenceDataVersion' => 1 )
			);

			if ( is_wp_error( $event ) ) {
				self::log_warning(
					'Google Meet link retry could not read the Group Session event.',
					$session,
					$attempt,
					$event->get_error_message()
				);
				self::maybe_retry( $session_id, $attempt );
				return;
			}

			$meeting_url = self::extract_google_meet_url( $event );
			if ( '' === $meeting_url ) {
				self::log_pending_status( $session, $attempt, $event );
				self::maybe_retry( $session_id, $attempt );
				return;
			}

			$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group Session owns its shared meeting URL.
				TutorHelper_Group_Sessions::get_table_name(),
				array(
					'meeting_url' => $meeting_url,
					'updated_at' => current_time( 'mysql', true ),
				),
				array( 'id' => $session_id ),
				array( '%s', '%s' ),
				array( '%d' )
			);

			if ( false === $updated ) {
				self::log_warning(
					'Google Meet link was available but could not be saved to the Group Session.',
					$session,
					$attempt,
					$wpdb->last_error
				);
				self::maybe_retry( $session_id, $attempt );
				return;
			}

			if ( class_exists( 'TutorHelper_Logger' ) ) {
				TutorHelper_Logger::success(
					'Google Meet link completed for Group Session.',
					array(
						'block_id' => absint( $session->block_id ),
						'session_id' => $session_id,
						'attempt' => $attempt,
					)
				);
			}

			do_action(
				'tutorhelper_group_session_meeting_link_ready',
				$session_id,
				absint( $session->block_id ),
				$meeting_url
			);
		} catch ( Throwable $error ) {
			self::log_warning(
				'Google Meet link retry crashed.',
				$session,
				$attempt,
				$error->getMessage()
			);
			self::maybe_retry( $session_id, $attempt );
		}
	}

	/** Schedule the first/subsequent retry once only. */
	private static function schedule_retry( $session_id, $attempt ) {
		$args = array( absint( $session_id ), absint( $attempt ) );
		if ( ! wp_next_scheduled( self::RETRY_HOOK, $args ) ) {
			wp_schedule_single_event(
				time() + self::RETRY_DELAY,
				self::RETRY_HOOK,
				$args
			);
		}
	}

	/** Schedule another attempt while inside the bounded retry window. */
	private static function maybe_retry( $session_id, $attempt ) {
		if ( $attempt >= self::MAX_ATTEMPTS ) {
			if ( class_exists( 'TutorHelper_Logger' ) ) {
				TutorHelper_Logger::warning(
					'Google Meet link remained unavailable after Group Session retries.',
					array(
						'session_id' => absint( $session_id ),
						'attempts' => self::MAX_ATTEMPTS,
					)
				);
			}
			return;
		}

		self::schedule_retry( $session_id, $attempt + 1 );
	}

	/** Extract a video Meet entry point from the Google event payload. */
	private static function extract_google_meet_url( $event ) {
		if ( ! empty( $event['hangoutLink'] ) ) {
			return esc_url_raw( $event['hangoutLink'] );
		}

		if (
			! empty( $event['conferenceData']['entryPoints'] )
			&& is_array( $event['conferenceData']['entryPoints'] )
		) {
			foreach ( $event['conferenceData']['entryPoints'] as $entry ) {
				if (
					! empty( $entry['entryPointType'] )
					&& 'video' === $entry['entryPointType']
					&& ! empty( $entry['uri'] )
				) {
					return esc_url_raw( $entry['uri'] );
				}
			}
		}

		return '';
	}

	/** Log the conference creation state when Google has not finished yet. */
	private static function log_pending_status( $session, $attempt, $event ) {
		if ( ! class_exists( 'TutorHelper_Logger' ) ) {
			return;
		}

		$status = '';
		if ( ! empty( $event['conferenceData']['createRequest']['status']['statusCode'] ) ) {
			$status = sanitize_key(
				$event['conferenceData']['createRequest']['status']['statusCode']
			);
		}

		TutorHelper_Logger::info(
			'Google Meet link is not ready yet for Group Session.',
			array(
				'block_id' => absint( $session->block_id ),
				'session_id' => absint( $session->id ),
				'attempt' => absint( $attempt ),
				'conference_status' => $status,
			)
		);
	}

	/** Log a retry failure without personal data. */
	private static function log_warning( $message, $session, $attempt, $error_message ) {
		if ( ! class_exists( 'TutorHelper_Logger' ) ) {
			return;
		}

		TutorHelper_Logger::warning(
			$message,
			array(
				'block_id' => absint( $session->block_id ),
				'session_id' => absint( $session->id ),
				'attempt' => absint( $attempt ),
				'error_message' => sanitize_text_field( $error_message ),
			)
		);
	}
}
