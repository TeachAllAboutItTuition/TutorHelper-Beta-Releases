<?php
/**
 * Group Session foundation service.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and retrieves generated lesson sessions for a Group Block.
 */
final class TutorHelper_Group_Sessions {

	const STATUS_SCHEDULED = 'scheduled';
	const STATUS_CANCELLED = 'cancelled';
	const STATUS_COMPLETED = 'completed';

	/**
	 * Initialise the service.
	 *
	 * @return void
	 */
	public static function init() {
		// Session management UI is added in a later checkpoint.
	}

	/**
	 * Return the Group Sessions table name.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		return TutorHelper_Group_Bookings_Database::get_table_name( 'sessions' );
	}

	/**
	 * Retrieve one session by ID.
	 *
	 * @param int $session_id Session ID.
	 * @return object|null
	 */
	public static function get_by_id( $session_id ) {
		global $wpdb;

		$session_id = absint( $session_id );
		if ( ! $session_id ) {
			return null;
		}

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group Session state must be current for booking and calendar workflows.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE id = %d',
				self::get_table_name(),
				$session_id
			)
		);
	}

	/**
	 * Return all sessions belonging to a block.
	 *
	 * @param int $block_id Block ID.
	 * @return array
	 */
	public static function get_for_block( $block_id ) {
		global $wpdb;

		$block_id = absint( $block_id );
		if ( ! $block_id ) {
			return array();
		}

		$results = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group Session state must be current for block management.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE block_id = %d ORDER BY session_number ASC, id ASC',
				self::get_table_name(),
				$block_id
			)
		);

		return is_array( $results ) ? $results : array();
	}

	/**
	 * Generate recurring sessions for a Group Block.
	 *
	 * Session dates are interpreted in the block timezone and stored as
	 * UTC booking_start / booking_end values. session_date remains the
	 * tutor-facing local date used for block management.
	 *
	 * @param int $block_id Group Block ID.
	 * @return array|WP_Error Generated session IDs.
	 */
	public static function generate_for_block( $block_id ) {
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			return new WP_Error( 'tutorhelper_group_session_block_not_found', __( 'The Group Block could not be found.', 'tutorhelper-group-bookings' ) );
		}

		if ( ! empty( self::get_for_block( $block_id ) ) ) {
			return new WP_Error( 'tutorhelper_group_sessions_already_exist', __( 'Sessions have already been generated for this Group Block.', 'tutorhelper-group-bookings' ) );
		}

		$preview = TutorHelper_Group_Schedule_Planner::preview(
			$block,
			TutorHelper_Group_Schedule_Planner::normalise_dates( isset( $block->excluded_session_dates ) ? $block->excluded_session_dates : array() )
		);
		if ( is_wp_error( $preview ) ) {
			return $preview;
		}

		$dates = TutorHelper_Group_Schedule_Planner::get_included_dates( $preview );
		if ( empty( $dates ) ) {
			return new WP_Error( 'tutorhelper_group_sessions_empty', __( 'No Group Lesson sessions remain after blocked or excluded dates were applied.', 'tutorhelper-group-bookings' ) );
		}

		$created = self::create_for_dates( $block, $dates );
		if ( is_wp_error( $created ) ) {
			self::delete_for_block( $block_id );
		}
		return $created;
	}

	/**
	 * Create only genuinely new sessions for a known Group Block.
	 *
	 * @param object $block Group Block.
	 * @param array  $dates Local Y-m-d session dates.
	 * @param bool   $notify Whether lifecycle listeners should be notified immediately.
	 * @return array|WP_Error
	 */
	public static function create_for_dates( $block, $dates, $notify = true ) {
		global $wpdb;

		if ( ! is_object( $block ) || ! absint( $block->id ) ) {
			return new WP_Error( 'tutorhelper_group_session_block_not_found', __( 'The Group Block could not be found.', 'tutorhelper-group-bookings' ) );
		}

		try {
			$timezone = new DateTimeZone( $block->timezone );
			$utc = new DateTimeZone( 'UTC' );
		} catch ( Exception $exception ) {
			return new WP_Error( 'tutorhelper_group_session_timezone_invalid', __( 'The Group Block timezone is invalid.', 'tutorhelper-group-bookings' ) );
		}

		$existing = self::get_for_block( $block->id );
		$existing_dates = wp_list_pluck( $existing, 'session_date' );
		$session_number = empty( $existing ) ? 1 : max( array_map( 'absint', wp_list_pluck( $existing, 'session_number' ) ) ) + 1;
		$session_ids = array();
		$now = current_time( 'mysql', true );

		foreach ( TutorHelper_Group_Schedule_Planner::normalise_dates( $dates ) as $date ) {
			if ( in_array( $date, $existing_dates, true ) ) {
				continue;
			}

			try {
				$local_start = new DateTimeImmutable( $date . ' ' . $block->start_time, $timezone );
				$local_end = new DateTimeImmutable( $date . ' ' . $block->end_time, $timezone );
			} catch ( Exception $exception ) {
				return new WP_Error( 'tutorhelper_group_session_schedule_invalid', __( 'A Group Block session date could not be generated.', 'tutorhelper-group-bookings' ) );
			}

			if ( $local_end <= $local_start ) {
				return new WP_Error( 'tutorhelper_group_session_duration_invalid', __( 'A Group Block session must end after it starts.', 'tutorhelper-group-bookings' ) );
			}

			$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Group Sessions are stored in a dedicated custom table.
				self::get_table_name(),
				array(
					'block_id' => absint( $block->id ),
					'session_number' => $session_number,
					'session_date' => $date,
					'booking_start' => $local_start->setTimezone( $utc )->format( 'Y-m-d H:i:s' ),
					'booking_end' => $local_end->setTimezone( $utc )->format( 'Y-m-d H:i:s' ),
					'status' => self::STATUS_SCHEDULED,
					'location_details' => sanitize_textarea_field( $block->location_details ),
					'calendar_event_id' => '',
					'meeting_url' => '',
					'created_at' => $now,
					'updated_at' => $now,
				)
			);

			if ( false === $inserted ) {
				return new WP_Error( 'tutorhelper_group_session_create_failed', $wpdb->last_error ? $wpdb->last_error : __( 'The Group Block sessions could not be generated.', 'tutorhelper-group-bookings' ) );
			}

			$session_ids[] = absint( $wpdb->insert_id );
			$existing_dates[] = $date;
			++$session_number;
		}

		if ( $notify && ! empty( $session_ids ) ) {
			do_action( 'tutorhelper_group_sessions_generated', absint( $block->id ), $session_ids );
		}

		return $session_ids;
	}

	/**
	 * Return this session's student-facing details, falling back for migrated records.
	 *
	 * @param object      $session Group Session.
	 * @param object|null $block Owning Group Block.
	 * @return string
	 */
	public static function get_location_details( $session, $block = null ) {
		if ( is_object( $session ) && property_exists( $session, 'location_details' ) && null !== $session->location_details ) {
			return sanitize_textarea_field( $session->location_details );
		}

		$block = is_object( $block ) ? $block : ( is_object( $session ) ? TutorHelper_Group_Blocks::get_by_id( $session->block_id ) : null );
		return $block && ! empty( $block->location_details ) ? sanitize_textarea_field( $block->location_details ) : '';
	}

	/**
	 * Update one session's student-facing location and preparation details.
	 *
	 * @param int    $session_id Group Session ID.
	 * @param string $location_details Submitted details.
	 * @return object|WP_Error Updated session.
	 */
	public static function update_location_details( $session_id, $location_details ) {
		global $wpdb;

		$previous = self::get_by_id( $session_id );
		if ( ! $previous ) {
			return new WP_Error( 'tutorhelper_group_session_missing', __( 'The Group Session could not be found.', 'tutorhelper-group-bookings' ) );
		}

		$location_details = sanitize_textarea_field( $location_details );
		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group Session details are stored in the add-on table.
			self::get_table_name(),
			array(
				'location_details' => $location_details,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $session_id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'tutorhelper_group_session_update_failed', __( 'The Group Session details could not be updated.', 'tutorhelper-group-bookings' ) );
		}

		self::update_child_booking_locations( $session_id, $location_details );
		$session = self::get_by_id( $session_id );
		do_action( 'tutorhelper_group_session_updated', absint( $session_id ), $session, $previous );
		return $session;
	}

	/** Keep existing Core child bookings aligned with the session details. */
	private static function update_child_booking_locations( $session_id, $location_details ) {
		global $wpdb;

		if ( ! class_exists( 'TutorHelper_Group_Enrolment_Bookings' ) || ! class_exists( 'TutorHelper_Booking_Records' ) ) {
			return;
		}

		$booking_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current bridge rows identify the child bookings to update.
			$wpdb->prepare( 'SELECT booking_id FROM %i WHERE session_id = %d', TutorHelper_Group_Enrolment_Bookings::get_table_name(), absint( $session_id ) )
		);

		foreach ( $booking_ids as $booking_id ) {
			$previous = TutorHelper_Booking_Records::get_by_id( $booking_id );
			if ( ! $previous ) {
				continue;
			}

			$result = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Session details must remain consistent on existing child booking records.
				TutorHelper_Booking_Records::get_table_name(),
				array(
					'location_details' => $location_details,
					'updated_at' => current_time( 'mysql', true ),
				),
				array( 'id' => absint( $booking_id ) ),
				array( '%s', '%s' ),
				array( '%d' )
			);

			if ( false !== $result ) {
				do_action( 'tutorhelper_booking_updated', absint( $booking_id ), TutorHelper_Booking_Records::get_by_id( $booking_id ), $previous );
			}
		}
	}

	/**
	 * Delete generated sessions for a block.
	 *
	 * Used to roll back incomplete creation and to remove sessions when an
	 * unused block is edited or permanently deleted.
	 *
	 * @param int $block_id Group Block ID.
	 * @return void
	 */
	public static function delete_for_block( $block_id ) {
		global $wpdb;

		$wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Rollback helper for incomplete Group Block creation.
			self::get_table_name(),
			array( 'block_id' => absint( $block_id ) ),
			array( '%d' )
		);
	}
}
