<?php
/**
 * Group Calendar lifecycle cleanup.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Removes shared Google events when a block leaves a confirmed state.
 */
final class TutorHelper_Group_Calendar_Lifecycle {

	/** Register lifecycle cleanup. */
	public static function init() {
		add_action(
			'tutorhelper_group_block_status_changed',
			array( __CLASS__, 'handle_block_status_changed' ),
			30,
			5
		);
	}

	/**
	 * Remove shared events from blocks that are no longer confirmed/full.
	 *
	 * @param int    $block_id Block ID.
	 * @param string $new_status New status.
	 * @param string $old_status Previous status.
	 * @param int    $secured_count Secured count.
	 * @param int    $reserved_count Reserved count.
	 * @return void
	 */
	public static function handle_block_status_changed(
		$block_id,
		$new_status,
		$old_status,
		$secured_count,
		$reserved_count
	) {
		unset( $old_status, $secured_count, $reserved_count );

		if (
			in_array(
				sanitize_key( $new_status ),
				array(
					TutorHelper_Group_Blocks::STATUS_CONFIRMED,
					TutorHelper_Group_Blocks::STATUS_FULL,
				),
				true
			)
		) {
			return;
		}

		self::delete_block_events( $block_id );
	}

	/**
	 * Delete every stored shared event for a Group Block and clear metadata.
	 *
	 * @param int $block_id Block ID.
	 * @return void
	 */
	public static function delete_block_events( $block_id ) {
		foreach ( TutorHelper_Group_Sessions::get_for_block( $block_id ) as $session ) {
			self::delete_session_event( $session );
		}
	}

	/** Delete one shared remote event and clear its local metadata. */
	public static function delete_session_event( $session ) {
		global $wpdb;

		$event_id = is_object( $session ) && ! empty( $session->calendar_event_id )
			? sanitize_text_field( $session->calendar_event_id )
			: '';

		if ( '' !== $event_id ) {
			/*
			 * Keep the remote ID while Google is disconnected. Clearing it here
			 * would orphan the event in Google Calendar with no safe way to find
			 * and remove it after reconnection.
			 */
			if ( ! TutorHelper_Pro_Google_Calendar::is_connected() ) {
				return;
			}

			$result = TutorHelper_Pro_Google_Calendar::request(
				'DELETE',
				'/calendars/primary/events/' . rawurlencode( $event_id ),
				null,
				array( 'sendUpdates' => 'none' )
			);

			if ( is_wp_error( $result ) ) {
				$data = $result->get_error_data();
				$status = is_array( $data ) && isset( $data['status'] ) ? absint( $data['status'] ) : 0;
				if ( 404 !== $status ) {
					if ( class_exists( 'TutorHelper_Logger' ) ) {
						TutorHelper_Logger::warning(
							'Group Session Calendar event could not be removed.',
							array(
								'session_id' => absint( $session->id ),
								'calendar_event_id' => $event_id,
								'error' => $result->get_error_message(),
							)
						);
					}
					return;
				}
			}
		}

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group Session owns its shared Calendar metadata.
			TutorHelper_Group_Sessions::get_table_name(),
			array(
				'calendar_event_id' => '',
				'meeting_url' => '',
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $session->id ) ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
	}
}
