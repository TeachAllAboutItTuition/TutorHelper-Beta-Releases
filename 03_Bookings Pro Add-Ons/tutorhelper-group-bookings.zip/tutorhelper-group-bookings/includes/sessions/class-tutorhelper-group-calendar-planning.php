<?php
/**
 * Planned Group Session Calendar lifecycle.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps Group Sessions visible in the tutor Calendar before minimum enrolment.
 */
final class TutorHelper_Group_Calendar_Planning {

	const PLANNED_PREFIX = 'PLANNED - ';

	/** Register planning lifecycle hooks. */
	public static function init() {
		/*
		 * G6 originally removed shared events when a block fell below its
		 * confirmation minimum. Keep those events instead and mark them as
		 * planned so the tutor's Calendar continues to reserve the time.
		 */
		remove_action(
			'tutorhelper_group_block_status_changed',
			array( 'TutorHelper_Group_Calendar_Lifecycle', 'handle_block_status_changed' ),
			30
		);

		/*
		 * Do not also hook tutorhelper_group_block_created here. A new block is
		 * created as draft and the readiness service immediately changes it to
		 * awaiting_minimum. That status transition is the single authoritative
		 * trigger for its first planned Calendar sync.
		 */
		add_action(
			'tutorhelper_group_block_status_changed',
			array( __CLASS__, 'handle_block_status_changed' ),
			30,
			5
		);

		add_action(
			'tutorhelper_group_block_updated',
			array( __CLASS__, 'handle_block_updated' ),
			30,
			3
		);

		add_action(
			'tutorhelper_group_session_updated',
			array( __CLASS__, 'handle_session_updated' ),
			30,
			3
		);
	}

	/**
	 * Refresh the same shared event after session-specific details change.
	 *
	 * @param int    $session_id Session ID.
	 * @param object $session Updated session.
	 * @param object $previous Previous session record.
	 * @return void
	 */
	public static function handle_session_updated( $session_id, $session, $previous ) {
		unset( $previous );

		try {
			$block = is_object( $session ) ? TutorHelper_Group_Blocks::get_by_id( $session->block_id ) : null;
			if ( ! $block || self::status_is_terminal( $block->status ) ) {
				return;
			}

			$sync = TutorHelper_Group_Calendar_Sync::sync_session( $session, $block );
			if ( is_wp_error( $sync ) ) {
				self::log_calendar_error( 'Edited Group Session could not be synchronized.', $sync, $block, $session );
				return;
			}

			if ( ! self::status_is_confirmed( $block->status ) ) {
				$fresh = TutorHelper_Group_Sessions::get_by_id( $session_id );
				if ( $fresh && ! empty( $fresh->calendar_event_id ) ) {
					self::mark_event_planned( $fresh, $block );
				}
			}
		} catch ( Throwable $error ) {
			self::log_calendar_throwable(
				'Edited Group Session Calendar synchronization failed.',
				$error,
				array( 'session_id' => absint( $session_id ) )
			);
		}
	}

	/**
	 * Refresh shared events after a tutor edits an existing block.
	 *
	 * @param int    $block_id Block ID.
	 * @param object $block Updated block.
	 * @param object $previous Previous block record.
	 * @return void
	 */
	public static function handle_block_updated( $block_id, $block, $previous ) {
		unset( $previous );

		try {
			if ( ! is_object( $block ) || self::status_is_terminal( $block->status ) ) {
				return;
			}

			if ( self::status_is_confirmed( $block->status ) ) {
				TutorHelper_Group_Calendar_Sync::sync_block( $block_id );
				return;
			}

			self::sync_planned_block( $block );
		} catch ( Throwable $error ) {
			self::log_calendar_throwable(
				'Edited Group Session Calendar synchronization failed.',
				$error,
				array( 'block_id' => absint( $block_id ) )
			);
		}
	}

	/**
	 * Update the existing shared Calendar event when readiness changes.
	 *
	 * Confirmed/full blocks use the normal G6 title. Blocks that are still
	 * viable but below minimum retain the same event and Meet/Zoom link with a
	 * PLANNED prefix. Cancelled/completed blocks are removed.
	 *
	 * Calendar is a secondary integration. No Calendar exception or PHP error
	 * may interrupt a successful Group Block or finance lifecycle request.
	 *
	 * @param int    $block_id Block ID.
	 * @param string $new_status New block status.
	 * @param string $old_status Previous block status.
	 * @param int    $secured_count Secured count.
	 * @param int    $reserved_count Reserved count.
	 * @return void
	 */
	public static function handle_block_status_changed(
		$block_id,
		$new_status,
		$old_status,
		$secured_count,
		$reserved_count
	) {
		unset( $old_status, $secured_count, $reserved_count );

		try {
			if ( self::status_is_terminal( $new_status ) ) {
				TutorHelper_Group_Calendar_Lifecycle::delete_block_events( $block_id );
				return;
			}

			$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
			if ( ! $block ) {
				return;
			}

			if ( self::status_is_confirmed( $new_status ) ) {
				/*
				 * TutorHelper_Group_Calendar_Sync runs at priority 20 and has already
				 * patched the same events back to their normal confirmed title.
				 */
				return;
			}

			self::sync_planned_block( $block );
		} catch ( Throwable $error ) {
			self::log_calendar_throwable(
				'Planned Group Session Calendar lifecycle failed.',
				$error,
				array(
					'block_id' => absint( $block_id ),
					'block_status' => sanitize_key( $new_status ),
				)
			);
		}
	}

	/**
	 * Ensure every scheduled session has a shared event, then mark it planned.
	 *
	 * @param object $block Group Block.
	 * @return void
	 */
	private static function sync_planned_block( $block ) {
		if (
			! class_exists( 'TutorHelper_Pro_Google_Calendar' )
			|| ! TutorHelper_Pro_Google_Calendar::is_connected()
		) {
			return;
		}

		foreach ( TutorHelper_Group_Sessions::get_for_block( $block->id ) as $session ) {
			if ( TutorHelper_Group_Sessions::STATUS_SCHEDULED !== sanitize_key( $session->status ) ) {
				continue;
			}

			try {
				$sync = TutorHelper_Group_Calendar_Sync::sync_session( $session, $block );
				if ( is_wp_error( $sync ) ) {
					self::log_calendar_error(
						'Planned Group Session could not be synchronized.',
						$sync,
						$block,
						$session
					);
					continue;
				}

				$fresh_session = TutorHelper_Group_Sessions::get_by_id( $session->id );
				if ( ! $fresh_session || empty( $fresh_session->calendar_event_id ) ) {
					continue;
				}

				self::mark_event_planned( $fresh_session, $block );
			} catch ( Throwable $error ) {
				self::log_calendar_throwable(
					'Planned Group Session Calendar synchronization crashed.',
					$error,
					array(
						'block_id' => absint( $block->id ),
						'session_id' => absint( $session->id ),
					)
				);
			}
		}
	}

	/**
	 * Prefix the existing Google event without replacing its conference data.
	 *
	 * @param object $session Group Session.
	 * @param object $block Group Block.
	 * @return void
	 */
	private static function mark_event_planned( $session, $block ) {
		$title = self::PLANNED_PREFIX . sanitize_text_field( $block->title );
		$result = TutorHelper_Pro_Google_Calendar::request(
			'PATCH',
			'/calendars/primary/events/' . rawurlencode( sanitize_text_field( $session->calendar_event_id ) ),
			array(
				'summary' => $title,
			),
			array(
				'sendUpdates' => 'none',
				'conferenceDataVersion' => 1,
			)
		);

		if ( is_wp_error( $result ) ) {
			self::log_calendar_error(
				'Group Session Calendar event could not be marked as planned.',
				$result,
				$block,
				$session
			);
		}
	}

	/**
	 * Log a normal WP_Error without exposing student data.
	 *
	 * @param string   $message Log message.
	 * @param WP_Error $error Calendar error.
	 * @param object   $block Group Block.
	 * @param object   $session Group Session.
	 * @return void
	 */
	private static function log_calendar_error( $message, $error, $block, $session ) {
		if ( ! class_exists( 'TutorHelper_Logger' ) ) {
			return;
		}

		TutorHelper_Logger::warning(
			$message,
			array(
				'block_id' => absint( $block->id ),
				'session_id' => absint( $session->id ),
				'error_code' => sanitize_key( $error->get_error_code() ),
				'error_message' => sanitize_text_field( $error->get_error_message() ),
			)
		);
	}

	/**
	 * Log an unexpected PHP error/exception without allowing it to escape.
	 *
	 * @param string    $message Log message.
	 * @param Throwable $error Error or exception.
	 * @param array     $context Additional non-personal context.
	 * @return void
	 */
	private static function log_calendar_throwable( $message, $error, $context = array() ) {
		if ( ! class_exists( 'TutorHelper_Logger' ) ) {
			return;
		}

		$context = is_array( $context ) ? $context : array();
		$context['error_type'] = get_class( $error );
		$context['error_message'] = sanitize_text_field( $error->getMessage() );
		$context['error_file'] = sanitize_text_field( $error->getFile() );
		$context['error_line'] = absint( $error->getLine() );

		TutorHelper_Logger::error( $message, $context );
	}

	/** Whether a block is ready to run rather than merely planned. */
	private static function status_is_confirmed( $status ) {
		return in_array(
			sanitize_key( $status ),
			array(
				TutorHelper_Group_Blocks::STATUS_CONFIRMED,
				TutorHelper_Group_Blocks::STATUS_FULL,
			),
			true
		);
	}

	/** Whether the Calendar reservation should cease to exist. */
	private static function status_is_terminal( $status ) {
		return in_array(
			sanitize_key( $status ),
			array(
				TutorHelper_Group_Blocks::STATUS_CANCELLED,
				TutorHelper_Group_Blocks::STATUS_COMPLETED,
			),
			true
		);
	}
}
