<?php
/**
 * Shared Group Lesson schedule planning service.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds tutor-facing schedule previews and applies Core booking conditions.
 */
final class TutorHelper_Group_Schedule_Planner {

	/**
	 * Build the proposed session dates for a new or extended block.
	 *
	 * @param object|array $schedule Schedule data.
	 * @param array        $manual_exclusions Local Y-m-d dates deliberately excluded by the tutor.
	 * @return array|WP_Error
	 */
	public static function preview( $schedule, $manual_exclusions = array() ) {
		$schedule = is_object( $schedule ) ? $schedule : (object) $schedule;
		$required = array( 'start_date', 'end_date', 'start_time', 'end_time', 'timezone', 'frequency', 'tutor_user_id', 'booking_type_id' );

		foreach ( $required as $field ) {
			if ( ! isset( $schedule->{$field} ) || '' === (string) $schedule->{$field} ) {
				return new WP_Error( 'tutorhelper_group_schedule_missing_field', __( 'Complete the schedule details before previewing sessions.', 'tutorhelper-group-bookings' ) );
			}
		}

		try {
			$timezone = new DateTimeZone( sanitize_text_field( $schedule->timezone ) );
			$current = new DateTimeImmutable( sanitize_text_field( $schedule->start_date ), $timezone );
			$end = new DateTimeImmutable( sanitize_text_field( $schedule->end_date ), $timezone );
		} catch ( Exception $exception ) {
			return new WP_Error( 'tutorhelper_group_schedule_timezone_invalid', __( 'The Group Lesson timezone is invalid.', 'tutorhelper-group-bookings' ) );
		}

		if ( $end < $current ) {
			return new WP_Error( 'tutorhelper_group_schedule_date_order_invalid', __( 'The schedule end date must be on or after the start date.', 'tutorhelper-group-bookings' ) );
		}

		$manual_exclusions = self::normalise_dates( $manual_exclusions );
		$interval_days = 'fortnightly' === sanitize_key( $schedule->frequency ) ? 14 : 7;
		$interval = new DateInterval( 'P' . $interval_days . 'D' );
		$candidates = array();

		while ( $current <= $end ) {
			$date = $current->format( 'Y-m-d' );
			$start = $date . ' ' . sanitize_text_field( $schedule->start_time );
			$finish = $date . ' ' . sanitize_text_field( $schedule->end_time );
			$conditions = self::evaluate_core_conditions( $schedule, $start, $finish );
			$blocking = is_array( $conditions ) && ! empty( $conditions['blocking_conditions'] ) ? $conditions['blocking_conditions'] : array();
			$warnings = is_array( $conditions ) && ! empty( $conditions['warnings'] ) ? $conditions['warnings'] : array();

			$state = 'included';
			$reason = '';
			if ( in_array( $date, $manual_exclusions, true ) ) {
				$state = 'excluded';
				$reason = __( 'Excluded manually by the tutor.', 'tutorhelper-group-bookings' );
			} elseif ( ! empty( $blocking ) ) {
				$state = 'blocked';
				$reason = self::condition_message( $blocking );
			} elseif ( ! empty( $warnings ) ) {
				$state = 'warning';
				$reason = self::condition_message( $warnings );
			}

			$candidates[] = array(
				'date' => $date,
				'label' => wp_date( get_option( 'date_format' ), $current->getTimestamp(), $timezone ),
				'state' => $state,
				'reason' => $reason,
				'can_include' => 'blocked' !== $state,
				'conditions' => array(
					'warnings' => $warnings,
					'blocking' => $blocking,
				),
			);
			$current = $current->add( $interval );
		}

		return $candidates;
	}

	/**
	 * Return only dates that may be generated.
	 *
	 * @param array $preview Preview entries.
	 * @return array
	 */
	public static function get_included_dates( $preview ) {
		$dates = array();
		foreach ( is_array( $preview ) ? $preview : array() as $candidate ) {
			if ( is_array( $candidate ) && in_array( $candidate['state'], array( 'included', 'warning' ), true ) ) {
				$dates[] = $candidate['date'];
			}
		}
		return $dates;
	}

	/**
	 * Decode a stored manual-exclusion list.
	 *
	 * @param mixed $dates Stored JSON or array.
	 * @return array
	 */
	public static function normalise_dates( $dates ) {
		if ( is_string( $dates ) ) {
			$decoded = json_decode( $dates, true );
			$dates = is_array( $decoded ) ? $decoded : array();
		}
		$results = array();
		foreach ( is_array( $dates ) ? $dates : array() as $date ) {
			$date = sanitize_text_field( $date );
			$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', $date );
			if ( $parsed && $parsed->format( 'Y-m-d' ) === $date ) {
				$results[] = $date;
			}
		}
		return array_values( array_unique( $results ) );
	}

	/**
	 * Evaluate a candidate through Core when its current booking services are available.
	 *
	 * @param object $schedule Schedule data.
	 * @param string $start Local start datetime.
	 * @param string $finish Local finish datetime.
	 * @return array
	 */
	private static function evaluate_core_conditions( $schedule, $start, $finish ) {
		if ( ! class_exists( 'TutorHelper_Booking_Conditions' ) ) {
			return array();
		}

		$result = TutorHelper_Booking_Conditions::evaluate(
			array(
				'tutor_user_id' => absint( $schedule->tutor_user_id ),
				'booking_type_id' => absint( $schedule->booking_type_id ),
				'booking_start' => $start,
				'booking_end' => $finish,
				'timezone' => sanitize_text_field( $schedule->timezone ),
				'location_type' => isset( $schedule->location_type ) ? sanitize_key( $schedule->location_type ) : '',
			)
		);

		if ( is_wp_error( $result ) ) {
			return array(
				'warnings' => array(
					array( 'message' => $result->get_error_message() ),
				),
				'blocking_conditions' => array(),
			);
		}

		return is_array( $result ) ? $result : array();
	}

	/**
	 * Collapse condition messages into a safe preview label.
	 *
	 * @param array $conditions Core conditions.
	 * @return string
	 */
	private static function condition_message( $conditions ) {
		$messages = array();
		foreach ( $conditions as $condition ) {
			if ( is_array( $condition ) && ! empty( $condition['message'] ) ) {
				$messages[] = sanitize_text_field( $condition['message'] );
			}
		}
		return implode( ' ', array_unique( $messages ) );
	}
}
