<?php
/**
 * Booking Hub calendar integration for Group Lessons.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Combines Group child bookings into one tutor-facing session entry.
 */
final class TutorHelper_Group_Booking_Calendar {

	/** Register Booking Hub calendar filters. */
	public static function init() {
		add_filter( 'tutorhelper_calendar_booking_records_prepared', array( __CLASS__, 'aggregate_session_records' ), 30, 2 );
		add_filter( 'tutorhelper_calendar_booking_edit_url', array( __CLASS__, 'filter_edit_url' ), 10, 4 );
		add_filter( 'tutorhelper_calendar_timetable_booking_label', array( __CLASS__, 'filter_timetable_label' ), 10, 2 );
	}

	/**
	 * Show the Group name in Core's compact weekly timetable.
	 *
	 * @param string $label   Core student label.
	 * @param array  $booking Prepared calendar booking.
	 * @return string
	 */
	public static function filter_timetable_label( $label, $booking ) {
		if (
			! is_array( $booking )
			|| empty( $booking['group_session_id'] )
			|| empty( $booking['booking_type_title'] )
		) {
			return $label;
		}

		return sanitize_text_field( $booking['booking_type_title'] );
	}

	/**
	 * Replace linked child records with one record for each Group Session.
	 *
	 * The Core child bookings remain unchanged for attendance and finance.
	 *
	 * @param array $records Prepared Core calendar records.
	 * @param array $rows    Raw Core booking rows.
	 * @return array
	 */
	public static function aggregate_session_records( $records, $rows ) {
		unset( $rows );

		if ( empty( $records ) || ! is_array( $records ) ) {
			return is_array( $records ) ? $records : array();
		}

		$booking_ids = array_values(
			array_filter(
				array_map(
					static function ( $record ) {
						return is_array( $record ) && isset( $record['id'] ) ? absint( $record['id'] ) : 0;
					},
					$records
				)
			)
		);

		if ( empty( $booking_ids ) ) {
			return $records;
		}

		$relationships = self::get_relationships( $booking_ids );
		if ( empty( $relationships ) ) {
			return $records;
		}

		$by_booking = array();
		foreach ( $relationships as $relationship ) {
			$by_booking[ absint( $relationship->booking_id ) ] = $relationship;
		}

		$groups = array();
		foreach ( $records as $record ) {
			$booking_id = isset( $record['id'] ) ? absint( $record['id'] ) : 0;
			if ( ! isset( $by_booking[ $booking_id ] ) ) {
				continue;
			}

			$relationship = $by_booking[ $booking_id ];
			$session_id = absint( $relationship->session_id );
			if ( ! isset( $groups[ $session_id ] ) ) {
				$groups[ $session_id ] = array(
					'all'            => array(),
					'active'         => array(),
					'records'        => array(),
					'active_records' => array(),
					'relation'       => $relationship,
				);
			}

			$is_active = TutorHelper_Group_Enrolments::STATUS_CANCELLED !== sanitize_key( $relationship->enrolment_status );
			$name = isset( $record['student_name'] ) ? sanitize_text_field( $record['student_name'] ) : '';
			if ( '' !== $name ) {
				$groups[ $session_id ]['all'][] = $name;
				if ( $is_active ) {
					$groups[ $session_id ]['active'][] = $name;
				}
			}
			$groups[ $session_id ]['records'][] = $record;
			if ( $is_active ) {
				$groups[ $session_id ]['active_records'][] = $record;
			}
		}

		$prepared_groups = array();
		foreach ( $groups as $session_id => $group ) {
			$prepared_groups[ $session_id ] = self::prepare_group_record( $group );
		}

		$output = array();
		$seen = array();
		foreach ( $records as $record ) {
			$booking_id = isset( $record['id'] ) ? absint( $record['id'] ) : 0;
			if ( ! isset( $by_booking[ $booking_id ] ) ) {
				$output[] = $record;
				continue;
			}

			$session_id = absint( $by_booking[ $booking_id ]->session_id );
			if ( isset( $seen[ $session_id ] ) ) {
				continue;
			}

			$seen[ $session_id ] = true;
			if ( isset( $prepared_groups[ $session_id ] ) ) {
				$output[] = $prepared_groups[ $session_id ];
			}
		}

		return $output;
	}

	/**
	 * Use the Group Session management screen instead of a child booking edit screen.
	 *
	 * @param string $url         Core booking edit URL.
	 * @param array  $booking     Prepared calendar booking.
	 * @param string $return_view Calendar view.
	 * @param string $return_date Calendar date.
	 * @return string
	 */
	public static function filter_edit_url( $url, $booking, $return_view, $return_date ) {
		unset( $return_view, $return_date );

		if ( ! is_array( $booking ) || empty( $booking['group_management_url'] ) ) {
			return $url;
		}

		return esc_url_raw( $booking['group_management_url'] );
	}

	/** Build one display record from a Group Session's child records. */
	private static function prepare_group_record( $group ) {
		$records = ! empty( $group['active_records'] ) ? $group['active_records'] : $group['records'];
		$record = reset( $records );
		$relationship = $group['relation'];
		$names = ! empty( $group['active'] ) ? $group['active'] : $group['all'];
		$names = array_values( array_unique( array_filter( $names ) ) );
		natcasesort( $names );

		$record['student_user_id'] = 0;
		$record['student_email'] = '';
		$record['student_name'] = empty( $names )
			? __( 'No enrolled students', 'tutorhelper-group-bookings' )
			: implode( ', ', $names );
		$record['booking_type_title'] = sanitize_text_field( $relationship->block_title );
		$record['group_block_id'] = absint( $relationship->block_id );
		$record['group_session_id'] = absint( $relationship->session_id );
		$record['group_management_url'] = self::get_management_url(
			$relationship->block_id,
			$relationship->session_id
		);
		unset( $record['display_status_label'], $record['attendance_status'] );

		$statuses = array_map(
			static function ( $item ) {
				return isset( $item['status'] ) ? sanitize_key( $item['status'] ) : '';
			},
			$records
		);

		if ( TutorHelper_Group_Sessions::STATUS_CANCELLED === sanitize_key( $relationship->session_status ) ) {
			$record['status'] = TutorHelper_Booking_Records::STATUS_CANCELLED;
		} elseif ( in_array( TutorHelper_Booking_Records::STATUS_CONFIRMED, $statuses, true ) ) {
			$record['status'] = TutorHelper_Booking_Records::STATUS_CONFIRMED;
		} elseif ( empty( $group['active_records'] ) ) {
			$record['status'] = TutorHelper_Booking_Records::STATUS_CANCELLED;
		} else {
			$record['status'] = TutorHelper_Booking_Records::STATUS_UNCONFIRMED;
		}

		return $record;
	}

	/** Return Group relationships for the displayed Core booking IDs. */
	private static function get_relationships( $booking_ids ) {
		global $wpdb;

		$placeholders = implode( ', ', array_fill( 0, count( $booking_ids ), '%d' ) );
		$query = 'SELECT l.booking_id, l.session_id, l.enrolment_id, e.status AS enrolment_status, '
			. 's.block_id, s.status AS session_status, b.title AS block_title '
			. 'FROM %i l INNER JOIN %i e ON e.id = l.enrolment_id '
			. 'INNER JOIN %i s ON s.id = l.session_id INNER JOIN %i b ON b.id = s.block_id '
			. 'WHERE l.booking_id IN (' . $placeholders . ')';
		$args = array_merge(
			array(
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				TutorHelper_Group_Enrolments::get_table_name(),
				TutorHelper_Group_Sessions::get_table_name(),
				TutorHelper_Group_Blocks::get_table_name(),
			),
			$booking_ids
		);

		return $wpdb->get_results( $wpdb->prepare( $query, $args ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table identifiers and the dynamic IN list are prepared above.
	}

	/** Return the tutor-facing Group Session management URL. */
	private static function get_management_url( $block_id, $session_id ) {
		return add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => 'group-lessons',
				'group_block_id' => absint( $block_id ),
				'group_session_id' => absint( $session_id ),
				'group_view' => 'session-details',
			),
			admin_url( 'admin.php' )
		);
	}
}
