<?php
/**
 * Shared Google Calendar synchronization for Group Lesson sessions.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps one Calendar event and one shared meeting link per Group Session.
 */
final class TutorHelper_Group_Calendar_Sync {

	/** Register Group Calendar lifecycle hooks. */
	public static function init() {
		/*
		 * Pro registers these callbacks on plugins_loaded priority 20.
		 * Group Bookings starts at priority 30, so they can be safely wrapped
		 * here to suppress per-student child events while preserving normal
		 * individual booking behaviour.
		 */
		remove_action(
			'tutorhelper_booking_created',
			array( 'TutorHelper_Pro_Calendar_Sync', 'handle_booking_created' ),
			5
		);
		remove_action(
			'tutorhelper_booking_updated',
			array( 'TutorHelper_Pro_Calendar_Sync', 'handle_booking_updated' ),
			5
		);
		remove_action(
			'tutorhelper_booking_schedule_updated',
			array( 'TutorHelper_Pro_Calendar_Sync', 'handle_schedule_updated' ),
			5
		);
		remove_action(
			'tutorhelper_booking_cancelled',
			array( 'TutorHelper_Pro_Calendar_Sync', 'handle_booking_cancelled' ),
			5
		);

		add_action( 'tutorhelper_booking_created', array( __CLASS__, 'handle_booking_created' ), 5, 1 );
		add_action( 'tutorhelper_booking_updated', array( __CLASS__, 'handle_booking_updated' ), 5, 3 );
		add_action( 'tutorhelper_booking_schedule_updated', array( __CLASS__, 'handle_schedule_updated' ), 5, 3 );
		add_action( 'tutorhelper_booking_cancelled', array( __CLASS__, 'handle_booking_cancelled' ), 5, 1 );

		add_action(
			'tutorhelper_group_block_status_changed',
			array( __CLASS__, 'handle_block_status_changed' ),
			20,
			5
		);
		add_action(
			'tutorhelper_group_sessions_generated',
			array( __CLASS__, 'handle_sessions_generated' ),
			20,
			2
		);

		/*
		 * Reconcile shared events whenever the tutor explicitly performs a
		 * Google Calendar sync. Pro may briefly inspect child bookings during
		 * that action; the shutdown reconciliation removes any child event and
		 * restores the single shared Group Session event as the final state.
		 */
		if ( is_admin() ) {
			add_action( 'admin_init', array( __CLASS__, 'register_manual_sync_cleanup' ), 1 );
		}
	}

	/** Delegate ordinary booking creation to Pro, but suppress Group children. */
	public static function handle_booking_created( $booking_id ) {
		if ( self::is_group_child_booking( $booking_id ) ) {
			self::delete_child_calendar_event( $booking_id );
			return;
		}

		TutorHelper_Pro_Calendar_Sync::handle_booking_created( $booking_id );
	}

	/** Delegate ordinary booking updates to Pro, but suppress Group children. */
	public static function handle_booking_updated( $booking_id, $updated = null, $previous = null ) {
		if ( self::is_group_child_booking( $booking_id ) ) {
			self::delete_child_calendar_event( $booking_id );
			return;
		}

		TutorHelper_Pro_Calendar_Sync::handle_booking_updated( $booking_id, $updated, $previous );
	}

	/** Delegate ordinary schedule changes to Pro, but suppress Group children. */
	public static function handle_schedule_updated( $booking_id, $before, $updated ) {
		if ( self::is_group_child_booking( $booking_id ) ) {
			self::delete_child_calendar_event( $booking_id );
			return;
		}

		TutorHelper_Pro_Calendar_Sync::handle_schedule_updated( $booking_id, $before, $updated );
	}

	/** Delegate ordinary cancellations to Pro, but only clean child metadata for Group bookings. */
	public static function handle_booking_cancelled( $booking_id ) {
		if ( self::is_group_child_booking( $booking_id ) ) {
			self::delete_child_calendar_event( $booking_id );
			return;
		}

		TutorHelper_Pro_Calendar_Sync::handle_booking_cancelled( $booking_id );
	}

	/**
	 * Create Group Session events once a block becomes confirmed/full.
	 *
	 * @param int    $block_id Block ID.
	 * @param string $new_status New block status.
	 * @param string $previous_status Previous block status.
	 * @param int    $secured_count Secured enrolments.
	 * @param int    $reserved_count Reserved enrolments.
	 * @return void
	 */
	public static function handle_block_status_changed(
		$block_id,
		$new_status,
		$previous_status,
		$secured_count,
		$reserved_count
	) {
		unset( $previous_status, $secured_count, $reserved_count );

		if ( self::block_status_is_confirmed( $new_status ) ) {
			self::sync_block( $block_id );
		}
	}

	/**
	 * Sync generated sessions immediately if their block is already confirmed.
	 *
	 * @param int   $block_id Block ID.
	 * @param array $session_ids Generated session IDs.
	 * @return void
	 */
	public static function handle_sessions_generated( $block_id, $session_ids ) {
		unset( $session_ids );
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( $block && self::block_status_is_confirmed( $block->status ) ) {
			self::sync_block( $block_id );
		}
	}

	/**
	 * Synchronize every scheduled session in a confirmed Group Block.
	 *
	 * @param int $block_id Block ID.
	 * @return array
	 */
	public static function sync_block( $block_id ) {
		$result = array(
			'synced' => 0,
			'failed' => 0,
			'skipped' => 0,
		);

		if (
			! class_exists( 'TutorHelper_Pro_Google_Calendar' )
			|| ! TutorHelper_Pro_Google_Calendar::is_connected()
		) {
			$result['skipped']++;
			return $result;
		}

		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block || ! self::block_status_is_confirmed( $block->status ) ) {
			$result['skipped']++;
			return $result;
		}

		foreach ( TutorHelper_Group_Sessions::get_for_block( $block_id ) as $session ) {
			if ( TutorHelper_Group_Sessions::STATUS_SCHEDULED !== sanitize_key( $session->status ) ) {
				$result['skipped']++;
				continue;
			}

			$sync = self::sync_session( $session, $block );
			if ( is_wp_error( $sync ) ) {
				$result['failed']++;
			} else {
				$result['synced']++;
			}
		}

		self::remove_child_events_for_block( $block_id );

		return $result;
	}

	/**
	 * Create or update one shared Google Calendar event.
	 *
	 * @param object $session Group Session.
	 * @param object $block Group Block.
	 * @return array|WP_Error
	 */
	public static function sync_session( $session, $block = null ) {
		global $wpdb;

		if ( ! is_object( $session ) || empty( $session->id ) ) {
			return new WP_Error(
				'tutorhelper_group_calendar_session_missing',
				__( 'The Group Session could not be synchronized.', 'tutorhelper-group-bookings' )
			);
		}

		$block = is_object( $block ) ? $block : TutorHelper_Group_Blocks::get_by_id( $session->block_id );
		if ( ! $block ) {
			return new WP_Error(
				'tutorhelper_group_calendar_block_missing',
				__( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		if ( ! TutorHelper_Pro_Google_Calendar::is_connected() ) {
			return new WP_Error(
				'tutorhelper_group_calendar_not_connected',
				__( 'Google Calendar is not connected.', 'tutorhelper-group-bookings' )
			);
		}

		$provider = self::get_session_provider( $block );
		$existing_event = null;
		$event_id = ! empty( $session->calendar_event_id )
			? sanitize_text_field( $session->calendar_event_id )
			: '';

		if ( '' !== $event_id ) {
			$existing_event = TutorHelper_Pro_Google_Calendar::request(
				'GET',
				'/calendars/primary/events/' . rawurlencode( $event_id ),
				null,
				array( 'conferenceDataVersion' => 1 )
			);

			if ( is_wp_error( $existing_event ) ) {
				$data = $existing_event->get_error_data();
				$status = is_array( $data ) && isset( $data['status'] ) ? absint( $data['status'] ) : 0;
				if ( 404 === $status ) {
					$event_id = '';
					$existing_event = null;
				}
			}
		}

		$payload = self::build_event_payload( $session, $block, $provider );
		$query = array( 'sendUpdates' => 'none' );

		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET === $provider ) {
			$query['conferenceDataVersion'] = 1;
			if ( is_array( $existing_event ) && ! empty( $existing_event['conferenceData'] ) ) {
				$payload['conferenceData'] = $existing_event['conferenceData'];
			} else {
				$payload['conferenceData'] = array(
					'createRequest' => array(
						'requestId' => 'th-group-session-' . absint( $session->id ) . '-' . substr( wp_generate_uuid4(), 0, 12 ),
						'conferenceSolutionKey' => array( 'type' => 'hangoutsMeet' ),
					),
				);
			}
		} elseif ( is_array( $existing_event ) && ! empty( $existing_event['conferenceData'] ) ) {
			$query['conferenceDataVersion'] = 1;
			$payload['conferenceData'] = null;
		}

		if ( '' !== $event_id ) {
			$remote = TutorHelper_Pro_Google_Calendar::request(
				'PATCH',
				'/calendars/primary/events/' . rawurlencode( $event_id ),
				$payload,
				$query
			);
		} else {
			$remote = TutorHelper_Pro_Google_Calendar::request(
				'POST',
				'/calendars/primary/events',
				$payload,
				$query
			);
		}

		if ( is_wp_error( $remote ) ) {
			if ( class_exists( 'TutorHelper_Logger' ) ) {
				TutorHelper_Logger::error(
					'Group Session Google Calendar synchronization failed.',
					array(
						'block_id' => absint( $block->id ),
						'session_id' => absint( $session->id ),
						'error' => $remote->get_error_message(),
					)
				);
			}
			return $remote;
		}

		$event_id = ! empty( $remote['id'] )
			? sanitize_text_field( $remote['id'] )
			: $event_id;

		if (
			TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET === $provider
			&& '' !== $event_id
			&& empty( $remote['hangoutLink'] )
		) {
			$fresh = TutorHelper_Pro_Google_Calendar::request(
				'GET',
				'/calendars/primary/events/' . rawurlencode( $event_id ),
				null,
				array( 'conferenceDataVersion' => 1 )
			);
			if ( ! is_wp_error( $fresh ) ) {
				$remote = $fresh;
			}
		}

		$meeting_url = self::extract_meeting_url( $provider, $remote );
		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group Session owns its shared Calendar metadata.
			TutorHelper_Group_Sessions::get_table_name(),
			array(
				'calendar_event_id' => $event_id,
				'meeting_url' => $meeting_url,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $session->id ) ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error(
				'tutorhelper_group_calendar_metadata_failed',
				__( 'The shared Calendar event was created, but TutorHelper could not save its Group Session details.', 'tutorhelper-group-bookings' )
			);
		}

		if ( class_exists( 'TutorHelper_Logger' ) ) {
			TutorHelper_Logger::success(
				'Group Session Google Calendar event synchronized.',
				array(
					'block_id' => absint( $block->id ),
					'session_id' => absint( $session->id ),
					'calendar_event_id' => $event_id,
					'meeting_provider' => $provider,
					'has_meeting_url' => '' !== $meeting_url,
				)
			);
		}

		do_action(
			'tutorhelper_group_session_calendar_synced',
			absint( $session->id ),
			absint( $block->id ),
			$event_id,
			$meeting_url
		);

		return $remote;
	}

	/**
	 * Register a final cleanup after Pro's explicit Calendar reconciliation.
	 *
	 * @return void
	 */
	public static function register_manual_sync_cleanup() {
		$action = isset( $_REQUEST['action'] ) && ! is_array( $_REQUEST['action'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing check; Pro validates the action itself.
			? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';

		if (
			in_array(
				$action,
				array(
					'tutorhelper_pro_google_calendar_sync',
					'tutorhelper_pro_google_calendar_callback',
				),
				true
			)
		) {
			register_shutdown_function( array( __CLASS__, 'reconcile_all_confirmed_blocks' ) );
		}
	}

	/** Reconcile all confirmed Group Blocks after a global Pro Calendar sync. */
	public static function reconcile_all_confirmed_blocks() {
		if ( ! class_exists( 'TutorHelper_Group_Blocks' ) ) {
			return;
		}

		foreach ( TutorHelper_Group_Blocks::get_all() as $block ) {
			if ( self::block_status_is_confirmed( $block->status ) ) {
				self::sync_block( $block->id );
			}
		}
	}

	/**
	 * Check whether a Core booking belongs to a Group Session.
	 *
	 * @param int $booking_id Booking ID.
	 * @return bool
	 */
	public static function is_group_child_booking( $booking_id ) {
		global $wpdb;

		$booking_id = absint( $booking_id );
		if ( ! $booking_id ) {
			return false;
		}

		$found = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Calendar routing must use the current Group bridge.
			$wpdb->prepare(
				'SELECT booking_id FROM %i WHERE booking_id = %d LIMIT 1',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				$booking_id
			)
		);

		return ! empty( $found );
	}

	/** Delete any old per-student Calendar event for a Group child booking. */
	private static function delete_child_calendar_event( $booking_id ) {
		if ( ! class_exists( 'TutorHelper_Pro_Calendar_Sync' ) ) {
			return;
		}

		$record = TutorHelper_Pro_Calendar_Sync::get_record( $booking_id );
		if ( $record && ! empty( $record->google_event_id ) ) {
			TutorHelper_Pro_Calendar_Sync::delete_event( $booking_id );
		}
	}

	/** Remove legacy child events across a complete Group Block. */
	private static function remove_child_events_for_block( $block_id ) {
		global $wpdb;

		$booking_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Cleanup requires the current Group bridge.
			$wpdb->prepare(
				'SELECT link.booking_id
				FROM %i AS link
				INNER JOIN %i AS enrolment ON enrolment.id = link.enrolment_id
				WHERE enrolment.block_id = %d',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				TutorHelper_Group_Enrolments::get_table_name(),
				absint( $block_id )
			)
		);

		foreach ( $booking_ids as $booking_id ) {
			self::delete_child_calendar_event( $booking_id );
		}
	}

	/** Determine the meeting provider used by this shared Group Session. */
	private static function get_session_provider( $block ) {
		if ( 'online' !== sanitize_key( $block->location_type ) ) {
			return TutorHelper_Pro_Google_Calendar::PROVIDER_NONE;
		}

		return TutorHelper_Pro_Google_Calendar::get_meeting_provider();
	}

	/** Build the shared Group Session Google Calendar payload. */
	private static function build_event_payload( $session, $block, $provider ) {
		$location_details = TutorHelper_Group_Sessions::get_location_details( $session, $block );
		$description = sprintf(
			/* translators: 1: session number, 2: block ID. */
			__(
				'TutorHelper Group Lesson
Session: %1$d
Block: #%2$d',
				'tutorhelper-group-bookings'
			),
			absint( $session->session_number ),
			absint( $block->id )
		);

		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_ZOOM === $provider ) {
			$zoom_url = TutorHelper_Pro_Online_Lessons::get_zoom_url();
			if ( $zoom_url ) {
				$description .= "\n\n" . __( 'Join Zoom:', 'tutorhelper-group-bookings' ) . ' ' . $zoom_url;
			}
		}

		if ( '' !== $location_details ) {
			$description .= "\n\n" . $location_details;
		}

		$payload = array(
			'summary' => sanitize_text_field( $block->title ),
			'description' => $description,
			'start' => self::event_datetime( $session->booking_start, $block->timezone ),
			'end' => self::event_datetime( $session->booking_end, $block->timezone ),
		);

		if ( 'online' !== sanitize_key( $block->location_type ) ) {
			$payload['location'] = '' !== $location_details ? sanitize_text_field( $location_details ) : '';
		}

		return $payload;
	}

	/** Preserve the Group Block timezone in the Google event. */
	private static function event_datetime( $utc_value, $timezone_name ) {
		try {
			$utc = new DateTimeZone( 'UTC' );
			$timezone_name = in_array( $timezone_name, timezone_identifiers_list(), true )
				? $timezone_name
				: wp_timezone_string();
			$timezone = new DateTimeZone( $timezone_name ? $timezone_name : 'UTC' );
			$value = new DateTimeImmutable( $utc_value, $utc );
			$value = $value->setTimezone( $timezone );

			return array(
				'dateTime' => $value->format( DateTimeInterface::RFC3339 ),
				'timeZone' => $timezone->getName(),
			);
		} catch ( Exception $exception ) {
			return array(
				'dateTime' => gmdate( 'c', strtotime( $utc_value ) ),
				'timeZone' => 'UTC',
			);
		}
	}

	/** Extract the shared student meeting URL from the Google response/provider. */
	private static function extract_meeting_url( $provider, $event ) {
		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_ZOOM === $provider ) {
			return esc_url_raw( TutorHelper_Pro_Online_Lessons::get_zoom_url() );
		}

		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET === $provider ) {
			if ( ! empty( $event['hangoutLink'] ) ) {
				return esc_url_raw( $event['hangoutLink'] );
			}

			if ( ! empty( $event['conferenceData']['entryPoints'] ) && is_array( $event['conferenceData']['entryPoints'] ) ) {
				foreach ( $event['conferenceData']['entryPoints'] as $entry ) {
					if (
						! empty( $entry['entryPointType'] )
						&& 'video' === $entry['entryPointType']
						&& ! empty( $entry['uri'] )
					) {
						return esc_url_raw( $entry['uri'] );
					}
				}
			}
		}

		return '';
	}

	/** Whether this block lifecycle state should own active Calendar events. */
	private static function block_status_is_confirmed( $status ) {
		return in_array(
			sanitize_key( $status ),
			array(
				TutorHelper_Group_Blocks::STATUS_CONFIRMED,
				TutorHelper_Group_Blocks::STATUS_FULL,
			),
			true
		);
	}
}
