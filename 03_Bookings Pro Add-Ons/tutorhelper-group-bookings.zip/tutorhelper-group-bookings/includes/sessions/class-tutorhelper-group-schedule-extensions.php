<?php
/**
 * Group Lesson schedule extension service.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Previews and applies safe Group Lesson extensions.
 */
final class TutorHelper_Group_Schedule_Extensions {

	/**
	 * Preview dates after a block's current end date.
	 *
	 * @param object $block Group Block.
	 * @param string $end_date Requested new end date.
	 * @param array  $manual_exclusions Requested exclusions.
	 * @return array|WP_Error
	 */
	public static function preview( $block, $end_date, $manual_exclusions = array() ) {
		if ( ! is_object( $block ) ) {
			return new WP_Error( 'tutorhelper_group_extension_block_missing', __( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' ) );
		}

		$end_date = sanitize_text_field( $end_date );
		if ( $end_date <= $block->end_date ) {
			return new WP_Error( 'tutorhelper_group_extension_date_invalid', __( 'Choose an end date after the current Group Lesson end date.', 'tutorhelper-group-bookings' ) );
		}

		$schedule = clone $block;
		$schedule->end_date = $end_date;
		$excluded = array_merge(
			TutorHelper_Group_Schedule_Planner::normalise_dates( isset( $block->excluded_session_dates ) ? $block->excluded_session_dates : array() ),
			TutorHelper_Group_Schedule_Planner::normalise_dates( $manual_exclusions )
		);
		$preview = TutorHelper_Group_Schedule_Planner::preview( $schedule, $excluded );
		if ( is_wp_error( $preview ) ) {
			return $preview;
		}

		return array_values(
			array_filter(
				$preview,
				static function ( $candidate ) use ( $block ) {
					return is_array( $candidate ) && $candidate['date'] > $block->end_date;
				}
			)
		);
	}

	/**
	 * Extend a block, add child bookings and increase each active enrolment's agreed total.
	 *
	 * @param int    $block_id Group Block ID.
	 * @param string $end_date Requested new end date.
	 * @param array  $manual_exclusions Additional manually excluded dates.
	 * @return array|WP_Error
	 */
	public static function extend( $block_id, $end_date, $manual_exclusions = array() ) {
		global $wpdb;

		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		$preview = self::preview( $block, $end_date, $manual_exclusions );
		if ( is_wp_error( $preview ) ) {
			return $preview;
		}

		$dates = TutorHelper_Group_Schedule_Planner::get_included_dates( $preview );
		if ( empty( $dates ) ) {
			return new WP_Error( 'tutorhelper_group_extension_empty', __( 'There are no available session dates to add for this extension.', 'tutorhelper-group-bookings' ) );
		}

		$existing_sessions = TutorHelper_Group_Sessions::get_for_block( $block->id );
		$existing_count = count( $existing_sessions );
		$all_exclusions = array_values(
			array_unique(
				array_merge(
					TutorHelper_Group_Schedule_Planner::normalise_dates( isset( $block->excluded_session_dates ) ? $block->excluded_session_dates : array() ),
					TutorHelper_Group_Schedule_Planner::normalise_dates( $manual_exclusions )
				)
			)
		);

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Block, sessions, child bookings and price snapshots must change together.

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Dedicated Group Block extension state.
			TutorHelper_Group_Blocks::get_table_name(),
			array(
				'end_date' => sanitize_text_field( $end_date ),
				'excluded_session_dates' => wp_json_encode( $all_exclusions ),
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $block->id ) ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Abort incomplete extension.
			return new WP_Error( 'tutorhelper_group_extension_update_failed', __( 'The Group Lesson end date could not be updated.', 'tutorhelper-group-bookings' ) );
		}

		$updated_block = TutorHelper_Group_Blocks::get_by_id( $block->id );
		$new_session_ids = TutorHelper_Group_Sessions::create_for_dates( $updated_block, $dates, false );
		if ( is_wp_error( $new_session_ids ) || empty( $new_session_ids ) ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Abort incomplete extension.
			return is_wp_error( $new_session_ids ) ? $new_session_ids : new WP_Error( 'tutorhelper_group_extension_sessions_missing', __( 'No new Group Lesson sessions were created.', 'tutorhelper-group-bookings' ) );
		}

		$enrolments = TutorHelper_Group_Enrolments::get_for_block( $block->id );
		$new_session_count = count( $new_session_ids );
		foreach ( $enrolments as $enrolment ) {
			if ( TutorHelper_Group_Enrolments::STATUS_CANCELLED === sanitize_key( $enrolment->status ) || ! empty( $enrolment->remainder_removed_at ) ) {
				continue;
			}

			$additional_price = self::get_additional_price( $block, $enrolment, $existing_count, $new_session_count );
			$new_total = absint( $enrolment->agreed_price_minor_units ) + $additional_price;
			$saved = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Enrolment price snapshot and finance reconciliation remain aligned.
				TutorHelper_Group_Bookings_Database::get_table_name( 'enrolments' ),
				array(
					'agreed_price_minor_units' => $new_total,
					'updated_at' => current_time( 'mysql', true ),
				),
				array( 'id' => absint( $enrolment->id ) ),
				array( '%d', '%s' ),
				array( '%d' )
			);
			if ( false === $saved ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Abort incomplete extension.
				return new WP_Error( 'tutorhelper_group_extension_price_failed', __( 'A student’s extended Group Lesson price could not be saved.', 'tutorhelper-group-bookings' ) );
			}

			$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment->id );
			foreach ( $new_session_ids as $session_id ) {
				$booking_id = TutorHelper_Group_Enrolment_Bookings::generate_for_session( $enrolment->id, $session_id );
				if ( is_wp_error( $booking_id ) ) {
					$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Abort incomplete extension.
					return $booking_id;
				}
			}
			self::reallocate_child_prices( $updated_block, $enrolment );
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Commit the complete extension once all child bookings exist.
		do_action( 'tutorhelper_group_sessions_generated', absint( $block->id ), $new_session_ids );
		do_action( 'tutorhelper_group_block_extended', absint( $block->id ), $new_session_ids );

		return array(
			'session_ids' => $new_session_ids,
			'dates' => $dates,
		);
	}

	/**
	 * Calculate the added price for one enrolment using the block's chosen basis.
	 *
	 * Fixed-price blocks use their existing per-session snapshot as the extension rate.
	 *
	 * @param object $block Block before extension.
	 * @param object $enrolment Enrolment snapshot.
	 * @param int    $existing_count Current session count.
	 * @param int    $new_count Added session count.
	 * @return int
	 */
	private static function get_additional_price( $block, $enrolment, $existing_count, $new_count ) {
		$per_session = TutorHelper_Group_Blocks::PRICING_FIXED_BLOCK === sanitize_key( $block->pricing_basis )
			? ( $existing_count ? (int) round( absint( $enrolment->agreed_price_minor_units ) / $existing_count ) : 0 )
			: absint( $block->price_per_session_minor_units );

		return max( 0, $per_session * absint( $new_count ) );
	}

	/**
	 * Reallocate the revised agreed total across all child bookings.
	 *
	 * @param object $block Group Block.
	 * @param object $enrolment Enrolment.
	 * @return void
	 */
	private static function reallocate_child_prices( $block, $enrolment ) {
		global $wpdb;

		$sessions = TutorHelper_Group_Sessions::get_for_block( $block->id );
		$count = count( $sessions );
		if ( ! $count ) {
			return;
		}

		$total = absint( $enrolment->agreed_price_minor_units );
		$base = intdiv( $total, $count );
		$remainder = $total % $count;
		$bookings_table = TutorHelper_Booking_Records::get_table_name();

		foreach ( $sessions as $session ) {
			$booking_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current bridge record identifies the child booking to reprice.
				$wpdb->prepare( 'SELECT booking_id FROM %i WHERE session_id = %d AND enrolment_id = %d', TutorHelper_Group_Enrolment_Bookings::get_table_name(), absint( $session->id ), absint( $enrolment->id ) )
			);
			if ( ! $booking_id ) {
				continue;
			}
			$price = $base + ( absint( $session->session_number ) <= $remainder ? 1 : 0 );
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Keep Core child booking price snapshots in line with the Group enrolment total.
				$bookings_table,
				array( 'price_minor_units' => $price, 'updated_at' => current_time( 'mysql', true ) ),
				array( 'id' => absint( $booking_id ) ),
				array( '%d', '%s' ),
				array( '%d' )
			);
		}
	}
}
