<?php
/**
 * Cleanup for per-student Calendar events created before Group bridge rows exist.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Removes child booking events after an enrolment has finished linking them.
 */
final class TutorHelper_Group_Calendar_Child_Cleanup {

	/** Register cleanup after Group enrolment creation. */
	public static function init() {
		add_action(
			'tutorhelper_group_student_enrolled',
			array( __CLASS__, 'handle_student_enrolled' ),
			20,
			4
		);
	}

	/**
	 * Remove any per-student Calendar events created before bridge insertion.
	 *
	 * Core fires tutorhelper_booking_created before Group Bookings inserts its
	 * session-booking bridge row, so a confirmed child can briefly look like an
	 * ordinary booking. Once enrolment creation completes, every child booking
	 * ID is known and any such event can be removed safely.
	 *
	 * @param int   $enrolment_id Enrolment ID.
	 * @param int   $block_id Block ID.
	 * @param int   $student_user_id Student user ID.
	 * @param array $booking_ids Linked Core booking IDs.
	 * @return void
	 */
	public static function handle_student_enrolled(
		$enrolment_id,
		$block_id,
		$student_user_id,
		$booking_ids
	) {
		unset( $enrolment_id, $block_id, $student_user_id );

		if ( ! class_exists( 'TutorHelper_Pro_Calendar_Sync' ) || ! is_array( $booking_ids ) ) {
			return;
		}

		foreach ( $booking_ids as $booking_id ) {
			$booking_id = absint( $booking_id );
			if ( ! $booking_id ) {
				continue;
			}

			$record = TutorHelper_Pro_Calendar_Sync::get_record( $booking_id );
			if ( $record && ! empty( $record->google_event_id ) ) {
				TutorHelper_Pro_Calendar_Sync::delete_event( $booking_id );
			}
		}
	}
}
