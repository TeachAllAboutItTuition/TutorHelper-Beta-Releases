<?php
/**
 * Tutor-facing Group Session detail management.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Edits student-facing details for an individual generated session.
 */
final class TutorHelper_Group_Session_Management {

	const UPDATE_ACTION = 'tutorhelper_group_update_session_details';

	/** Register the secured session update handler. */
	public static function init() {
		add_action( 'admin_post_' . self::UPDATE_ACTION, array( __CLASS__, 'handle_update' ) );
	}

	/** Render a compact details preview and edit action in the sessions table. */
	public static function render_session_details( $block, $session ) {
		$details = TutorHelper_Group_Sessions::get_location_details( $session, $block );
		$url = add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
				'group_block_id' => absint( $block->id ),
				'group_session_id' => absint( $session->id ),
				'group_view' => 'session-details',
			),
			admin_url( 'admin.php' )
		);
		?>
		<small class="tutorhelper-group-session-details__summary"><?php echo esc_html( '' !== $details ? wp_html_excerpt( $details, 90, '…' ) : __( 'No details', 'tutorhelper-group-bookings' ) ); ?></small>
		<a class="button tutorhelper-hub-pill-button-small" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html__( 'Manage session', 'tutorhelper-group-bookings' ); ?></a>
		<?php
	}

	/** Render the individual session details form. */
	public static function render_edit_page( $block, $session ) {
		if ( ! self::session_belongs_to_block( $session, $block ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'The Group Session could not be found in this lesson block.', 'tutorhelper-group-bookings' ) . '</p></div>';
			return;
		}

		$details = TutorHelper_Group_Sessions::get_location_details( $session, $block );
		?>
		<section class="tutorhelper-main-section tutorhelper-group-session-edit">
			<header class="tutorhelper-main-section__header">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php
					/* translators: %d: Group session number. */
					echo esc_html( sprintf( __( 'Manage session #%d', 'tutorhelper-group-bookings' ), absint( $session->session_number ) ) ); ?></h2>
					<p><?php echo esc_html( $block->title . ' — ' . self::format_session_date( $session, $block ) ); ?></p>
				</div>
				<a class="button tutorhelper-hub-pill-button" href="<?php echo esc_url( self::get_block_url( $block->id ) ); ?>"><?php echo esc_html__( 'Back to block', 'tutorhelper-group-bookings' ); ?></a>
			</header>
			<div class="tutorhelper-main-section__body">
				<form class="tutorhelper-group-session-edit__form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::UPDATE_ACTION ); ?>" />
					<input type="hidden" name="block_id" value="<?php echo esc_attr( $block->id ); ?>" />
					<input type="hidden" name="session_id" value="<?php echo esc_attr( $session->id ); ?>" />
					<?php wp_nonce_field( self::UPDATE_ACTION . '_' . absint( $session->id ) ); ?>
					<label class="tutorhelper-admin-control">
						<span><strong><?php echo esc_html__( 'Location details / preparation notes', 'tutorhelper-group-bookings' ); ?></strong></span>
						<textarea name="location_details" rows="7"><?php echo esc_textarea( $details ); ?></textarea>
						<small><?php echo esc_html__( 'Students can see this for the individual session. It is also copied to linked child bookings and the shared Calendar event.', 'tutorhelper-group-bookings' ); ?></small>
					</label>
					<div><button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary"><?php echo esc_html__( 'Save session details', 'tutorhelper-group-bookings' ); ?></button></div>
				</form>
			</div>
		</section>
		<?php
	}

	/** Validate and save one individual session's details. */
	public static function handle_update() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to edit Group Sessions.', 'tutorhelper-group-bookings' ) );
		}

		$block_id = isset( $_POST['block_id'] ) && ! is_array( $_POST['block_id'] ) ? absint( wp_unslash( $_POST['block_id'] ) ) : 0;
		$session_id = isset( $_POST['session_id'] ) && ! is_array( $_POST['session_id'] ) ? absint( wp_unslash( $_POST['session_id'] ) ) : 0;
		check_admin_referer( self::UPDATE_ACTION . '_' . $session_id );

		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		$session = TutorHelper_Group_Sessions::get_by_id( $session_id );
		if ( ! self::session_belongs_to_block( $session, $block ) ) {
			$result = new WP_Error( 'tutorhelper_group_session_invalid', __( 'The Group Session could not be verified.', 'tutorhelper-group-bookings' ) );
		} else {
			$details = isset( $_POST['location_details'] ) && ! is_array( $_POST['location_details'] )
				? sanitize_textarea_field( wp_unslash( $_POST['location_details'] ) )
				: '';
			$result = TutorHelper_Group_Sessions::update_location_details( $session_id, $details );
		}

		$args = array(
			'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
			'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
			'group_block_id' => $block_id,
		);
		if ( is_wp_error( $result ) ) {
			$args['group_notice'] = 'error';
			$args['group_message'] = rawurlencode( $result->get_error_message() );
		} else {
			$args['group_notice'] = 'session_updated';
		}

		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Confirm the requested session belongs to the requested block. */
	private static function session_belongs_to_block( $session, $block ) {
		return is_object( $session ) && is_object( $block ) && absint( $session->block_id ) === absint( $block->id );
	}

	/** Return to the owning block detail screen. */
	private static function get_block_url( $block_id ) {
		return add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
				'group_block_id' => absint( $block_id ),
			),
			admin_url( 'admin.php' )
		);
	}

	/** Format a session in the block timezone. */
	private static function format_session_date( $session, $block ) {
		try {
			$date = new DateTimeImmutable( $session->booking_start, new DateTimeZone( 'UTC' ) );
			$timezone = new DateTimeZone( sanitize_text_field( $block->timezone ) );
			return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $date->getTimestamp(), $timezone );
		} catch ( Exception $exception ) {
			return (string) $session->booking_start;
		}
	}
}
