<?php
/**
 * Group Block creation service.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validates Group Block definitions and creates their sessions.
 */
final class TutorHelper_Group_Block_Create {

	const FREQUENCY_WEEKLY = 'weekly';
	const FREQUENCY_FORTNIGHTLY = 'fortnightly';

	/**
	 * Create a Group Block and generate its recurring sessions.
	 *
	 * @param array $data Raw block data.
	 * @return int|WP_Error Block ID on success.
	 */
	public static function create( $data ) {
		global $wpdb;

		$data = self::prepare( $data );

		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$now = current_time( 'mysql', true );
		$data['created_at'] = $now;
		$data['updated_at'] = $now;

		$result = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Group Blocks are stored in a dedicated custom table.
			TutorHelper_Group_Blocks::get_table_name(),
			$data
		);

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_group_block_create_failed',
				$wpdb->last_error
					? $wpdb->last_error
					: __( 'The Group Block could not be created.', 'tutorhelper-group-bookings' )
			);
		}

		$block_id = absint( $wpdb->insert_id );
		$generation = TutorHelper_Group_Sessions::generate_for_block( $block_id );

		if ( is_wp_error( $generation ) ) {
			$wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back an incomplete Group Block creation.
				TutorHelper_Group_Blocks::get_table_name(),
				array( 'id' => $block_id ),
				array( '%d' )
			);

			return $generation;
		}

		do_action(
			'tutorhelper_group_block_created',
			$block_id,
			TutorHelper_Group_Blocks::get_by_id( $block_id ),
			$generation
		);

		return $block_id;
	}

	/**
	 * Sanitise, validate and complete Group Block data for creation or editing.
	 *
	 * @param array $data Raw block data.
	 * @return array|WP_Error
	 */
	public static function prepare( $data ) {
		$data = self::sanitize_data( $data );

		return self::validate_data( $data );
	}

	/**
	 * Sanitise submitted block data.
	 *
	 * @param array $data Raw block data.
	 * @return array
	 */
	private static function sanitize_data( $data ) {
		$data = is_array( $data ) ? $data : array();

		$maximum = isset( $data['max_enrolments'] ) && '' !== (string) $data['max_enrolments']
			? absint( $data['max_enrolments'] )
			: null;

		return array(
			'group_id' => isset( $data['group_id'] ) ? absint( $data['group_id'] ) : 0,
			'booking_type_id' => isset( $data['booking_type_id'] ) ? absint( $data['booking_type_id'] ) : 0,
			'tutor_user_id' => isset( $data['tutor_user_id'] ) ? absint( $data['tutor_user_id'] ) : 0,
			'title' => isset( $data['title'] ) ? sanitize_text_field( wp_unslash( $data['title'] ) ) : '',
			'start_date' => isset( $data['start_date'] ) ? sanitize_text_field( $data['start_date'] ) : '',
			'end_date' => isset( $data['end_date'] ) ? sanitize_text_field( $data['end_date'] ) : '',
			'bookable_from' => self::sanitize_optional_date( isset( $data['bookable_from'] ) ? $data['bookable_from'] : '' ),
			'bookable_until' => self::sanitize_optional_date( isset( $data['bookable_until'] ) ? $data['bookable_until'] : '' ),
			'open_for_public_booking' => ! empty( $data['open_for_public_booking'] ) ? 1 : 0,
			'excluded_session_dates' => wp_json_encode( TutorHelper_Group_Schedule_Planner::normalise_dates( isset( $data['excluded_session_dates'] ) ? wp_unslash( $data['excluded_session_dates'] ) : array() ) ),
			'frequency' => isset( $data['frequency'] ) ? sanitize_key( $data['frequency'] ) : self::FREQUENCY_WEEKLY,
			'start_time' => isset( $data['start_time'] ) ? sanitize_text_field( $data['start_time'] ) : '',
			'end_time' => isset( $data['end_time'] ) ? sanitize_text_field( $data['end_time'] ) : '',
			'timezone' => isset( $data['timezone'] ) ? sanitize_text_field( $data['timezone'] ) : wp_timezone_string(),
			'location_type' => isset( $data['location_type'] ) ? sanitize_key( $data['location_type'] ) : '',
			'location_details' => isset( $data['location_details'] ) ? sanitize_textarea_field( wp_unslash( $data['location_details'] ) ) : '',
			'min_enrolments' => isset( $data['min_enrolments'] ) ? max( 1, absint( $data['min_enrolments'] ) ) : 1,
			'max_enrolments' => $maximum,
			'pricing_basis' => isset( $data['pricing_basis'] ) ? sanitize_key( $data['pricing_basis'] ) : TutorHelper_Group_Blocks::PRICING_BOOKING_TYPE,
			'price_per_session_minor_units' => isset( $data['price_per_session_minor_units'] ) ? absint( $data['price_per_session_minor_units'] ) : 0,
			'fixed_block_price_minor_units' => isset( $data['fixed_block_price_minor_units'] ) && '' !== (string) $data['fixed_block_price_minor_units'] ? absint( $data['fixed_block_price_minor_units'] ) : null,
			'deposit_type' => isset( $data['deposit_type'] ) ? sanitize_key( $data['deposit_type'] ) : TutorHelper_Group_Blocks::DEPOSIT_NONE,
			'deposit_value' => isset( $data['deposit_value'] ) ? absint( $data['deposit_value'] ) : 0,
			'currency' => isset( $data['currency'] ) ? strtoupper( sanitize_text_field( $data['currency'] ) ) : 'GBP',
			'payment_mode' => isset( $data['payment_mode'] ) ? sanitize_key( $data['payment_mode'] ) : TutorHelper_Group_Blocks::PAYMENT_MANUAL,
			'student_cancellation_allowed' => ! empty( $data['student_cancellation_allowed'] ) ? 1 : 0,
			'cancellation_notice_hours' => isset( $data['cancellation_notice_hours'] ) ? absint( $data['cancellation_notice_hours'] ) : 24,
			'deposit_refundable' => isset( $data['deposit_refundable'] ) && 'no' === sanitize_key( $data['deposit_refundable'] ) ? 0 : 1,
			'cancellation_terms' => isset( $data['cancellation_terms'] ) ? sanitize_textarea_field( wp_unslash( $data['cancellation_terms'] ) ) : '',
			'status' => TutorHelper_Group_Blocks::STATUS_DRAFT,
		);
	}

	/**
	 * Validate and complete Group Block data.
	 *
	 * @param array $data Sanitised block data.
	 * @return array|WP_Error
	 */
	private static function validate_data( $data ) {
		$group = $data['group_id'] ? TutorHelper_Pro_Groups::get_by_id( $data['group_id'] ) : null;
		if ( ! $group || empty( $group->is_active ) ) {
			return new WP_Error(
				'tutorhelper_group_block_group_invalid',
				__( 'Select an active TutorHelper Pro Group.', 'tutorhelper-group-bookings' )
			);
		}

		$booking_type = $data['booking_type_id'] ? TutorHelper_Booking_Types::get_by_id( $data['booking_type_id'] ) : null;
		if ( ! $booking_type || empty( $booking_type->is_active ) ) {
			return new WP_Error(
				'tutorhelper_group_block_booking_type_invalid',
				__( 'Select an active Booking Type.', 'tutorhelper-group-bookings' )
			);
		}

		if ( ! $data['tutor_user_id'] || ! get_user_by( 'id', $data['tutor_user_id'] ) ) {
			return new WP_Error(
				'tutorhelper_group_block_tutor_invalid',
				__( 'Select a valid tutor.', 'tutorhelper-group-bookings' )
			);
		}

		if ( '' === trim( $data['title'] ) ) {
			$data['title'] = sanitize_text_field( $group->name );
		}

		if ( ! in_array( $data['frequency'], array( self::FREQUENCY_WEEKLY, self::FREQUENCY_FORTNIGHTLY ), true ) ) {
			return new WP_Error(
				'tutorhelper_group_block_frequency_invalid',
				__( 'Group Blocks currently support weekly or fortnightly schedules.', 'tutorhelper-group-bookings' )
			);
		}

		$date_validation = self::validate_schedule( $data );
		if ( is_wp_error( $date_validation ) ) {
			return $date_validation;
		}

		$booking_window_validation = self::validate_booking_window( $data );
		if ( is_wp_error( $booking_window_validation ) ) {
			return $booking_window_validation;
		}

		$limit_validation = TutorHelper_Group_Blocks::validate_enrolment_limits(
			$data['min_enrolments'],
			$data['max_enrolments']
		);
		if ( is_wp_error( $limit_validation ) ) {
			return $limit_validation;
		}

		$pricing_bases = array(
			TutorHelper_Group_Blocks::PRICING_BOOKING_TYPE,
			TutorHelper_Group_Blocks::PRICING_PER_SESSION,
			TutorHelper_Group_Blocks::PRICING_FIXED_BLOCK,
		);
		if ( ! in_array( $data['pricing_basis'], $pricing_bases, true ) ) {
			return new WP_Error(
				'tutorhelper_group_block_pricing_invalid',
				__( 'The Group Block pricing basis is invalid.', 'tutorhelper-group-bookings' )
			);
		}

		$duration_minutes = self::get_duration_minutes( $data['start_time'], $data['end_time'] );
		if ( is_wp_error( $duration_minutes ) ) {
			return $duration_minutes;
		}

		if ( TutorHelper_Group_Blocks::PRICING_BOOKING_TYPE === $data['pricing_basis'] ) {
			$price = TutorHelper_Booking_Types::calculate_price( $data['booking_type_id'], $duration_minutes );
			if ( is_wp_error( $price ) ) {
				return $price;
			}
			$data['price_per_session_minor_units'] = absint( $price );
		}

		if (
			TutorHelper_Group_Blocks::PRICING_FIXED_BLOCK === $data['pricing_basis']
			&& null === $data['fixed_block_price_minor_units']
		) {
			return new WP_Error(
				'tutorhelper_group_block_fixed_price_required',
				__( 'Enter a fixed block price.', 'tutorhelper-group-bookings' )
			);
		}

		$payment_modes = array(
			TutorHelper_Group_Blocks::PAYMENT_MANUAL,
			TutorHelper_Group_Blocks::PAYMENT_FULL_UPFRONT,
			TutorHelper_Group_Blocks::PAYMENT_DEPOSIT,
		);
		if ( ! in_array( $data['payment_mode'], $payment_modes, true ) ) {
			return new WP_Error(
				'tutorhelper_group_block_payment_mode_invalid',
				__( 'The Group Block payment arrangement is invalid.', 'tutorhelper-group-bookings' )
			);
		}

		$preview = TutorHelper_Group_Schedule_Planner::preview( (object) $data, TutorHelper_Group_Schedule_Planner::normalise_dates( $data['excluded_session_dates'] ) );
		if ( is_wp_error( $preview ) ) {
			return $preview;
		}

		$total = TutorHelper_Group_Blocks::calculate_block_total(
			(object) $data,
			count( TutorHelper_Group_Schedule_Planner::get_included_dates( $preview ) )
		);

		if ( TutorHelper_Group_Blocks::PAYMENT_DEPOSIT === $data['payment_mode'] ) {
			if (
				! in_array(
					$data['deposit_type'],
					array(
						TutorHelper_Group_Blocks::DEPOSIT_FIXED,
						TutorHelper_Group_Blocks::DEPOSIT_PERCENTAGE,
					),
					true
				)
				|| 0 === $data['deposit_value']
			) {
				return new WP_Error(
					'tutorhelper_group_block_deposit_required',
					__( 'Choose a fixed or percentage deposit greater than zero.', 'tutorhelper-group-bookings' )
				);
			}

			if (
				TutorHelper_Group_Blocks::DEPOSIT_PERCENTAGE === $data['deposit_type']
				&& $data['deposit_value'] > 100
			) {
				return new WP_Error(
					'tutorhelper_group_block_deposit_percentage_invalid',
					__( 'The deposit percentage cannot exceed 100%.', 'tutorhelper-group-bookings' )
				);
			}

			if (
				TutorHelper_Group_Blocks::DEPOSIT_FIXED === $data['deposit_type']
				&& $data['deposit_value'] > $total
			) {
				return new WP_Error(
					'tutorhelper_group_block_deposit_amount_invalid',
					__( 'The fixed deposit cannot exceed the Group Block price.', 'tutorhelper-group-bookings' )
				);
			}
		} else {
			$data['deposit_type'] = TutorHelper_Group_Blocks::DEPOSIT_NONE;
			$data['deposit_value'] = 0;
		}

		return $data;
	}

	/**
	 * Validate optional Group Block booking-window dates.
	 *
	 * @param array $data Sanitised Group Block data.
	 * @return true|WP_Error
	 */
	private static function validate_booking_window( $data ) {
		$from = isset( $data['bookable_from'] ) ? $data['bookable_from'] : '';
		$until = isset( $data['bookable_until'] ) ? $data['bookable_until'] : '';

		foreach ( array( $from, $until ) as $date ) {
			if ( empty( $date ) ) {
				continue;
			}

			$date_object = DateTimeImmutable::createFromFormat( '!Y-m-d', $date );
			if ( ! $date_object || $date_object->format( 'Y-m-d' ) !== $date ) {
				return new WP_Error(
					'tutorhelper_group_block_booking_window_invalid',
					__( 'Booking window dates must use a valid calendar date.', 'tutorhelper-group-bookings' )
				);
			}
		}

		if ( ! empty( $from ) && ! empty( $until ) && $from > $until ) {
			return new WP_Error(
				'tutorhelper_group_block_booking_window_order_invalid',
				__( 'Bookable until must be on or after Bookable from.', 'tutorhelper-group-bookings' )
			);
		}

		return true;
	}


	/**
	 * Convert an optional date input to a database NULL or a safe date string.
	 *
	 * @param mixed $date Raw optional date.
	 * @return string|null
	 */
	private static function sanitize_optional_date( $date ) {
		$date = is_scalar( $date ) ? sanitize_text_field( $date ) : '';

		return '' === $date || '0000-00-00' === $date ? null : $date;
	}

	/**
	 * Count the sessions generated by a validated schedule.
	 *
	 * @param array $data Validated block data.
	 * @return int
	 */
	private static function count_sessions( $data ) {
		$timezone = new DateTimeZone( $data['timezone'] );
		$current = new DateTimeImmutable( $data['start_date'], $timezone );
		$end = new DateTimeImmutable( $data['end_date'], $timezone );
		$interval_days = self::FREQUENCY_FORTNIGHTLY === $data['frequency'] ? 14 : 7;
		$count = 0;

		while ( $current <= $end ) {
			++$count;
			$current = $current->modify( '+' . $interval_days . ' days' );
		}

		return $count;
	}

	/**
	 * Validate dates, times and timezone.
	 *
	 * @param array $data Group Block data.
	 * @return true|WP_Error
	 */
	private static function validate_schedule( $data ) {
		try {
			$timezone = new DateTimeZone( $data['timezone'] );
			$start = new DateTimeImmutable( $data['start_date'] . ' ' . $data['start_time'], $timezone );
			$end = new DateTimeImmutable( $data['end_date'] . ' ' . $data['end_time'], $timezone );
			$first_end = new DateTimeImmutable( $data['start_date'] . ' ' . $data['end_time'], $timezone );
		} catch ( Exception $exception ) {
			return new WP_Error(
				'tutorhelper_group_block_schedule_invalid',
				__( 'The Group Block schedule is invalid.', 'tutorhelper-group-bookings' )
			);
		}

		if ( $end < $start || $first_end <= $start ) {
			return new WP_Error(
				'tutorhelper_group_block_schedule_order_invalid',
				__( 'The Group Block end date and time must be after the start.', 'tutorhelper-group-bookings' )
			);
		}

		return true;
	}

	/**
	 * Return session duration in minutes.
	 *
	 * @param string $start_time Start time.
	 * @param string $end_time End time.
	 * @return int|WP_Error
	 */
	private static function get_duration_minutes( $start_time, $end_time ) {
		$start = strtotime( '1970-01-01 ' . $start_time . ' UTC' );
		$end = strtotime( '1970-01-01 ' . $end_time . ' UTC' );

		if ( false === $start || false === $end || $end <= $start ) {
			return new WP_Error(
				'tutorhelper_group_block_duration_invalid',
				__( 'The Group Block session duration is invalid.', 'tutorhelper-group-bookings' )
			);
		}

		return (int) round( ( $end - $start ) / MINUTE_IN_SECONDS );
	}
}
