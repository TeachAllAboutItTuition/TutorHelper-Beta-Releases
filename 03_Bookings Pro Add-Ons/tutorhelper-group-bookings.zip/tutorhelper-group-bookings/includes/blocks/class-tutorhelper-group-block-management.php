<?php
/**
 * Tutor-facing Group Block editing and deletion.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Safely updates and deletes Group Lesson blocks.
 */
final class TutorHelper_Group_Block_Management {

	const UPDATE_ACTION = 'tutorhelper_group_update_block';
	const DELETE_ACTION = 'tutorhelper_group_delete_block';

	/** Register admin handlers. */
	public static function init() {
		add_action( 'admin_post_' . self::UPDATE_ACTION, array( __CLASS__, 'handle_update' ) );
		add_action( 'admin_post_' . self::DELETE_ACTION, array( __CLASS__, 'handle_delete' ) );
	}

	/** Render Edit/Delete controls in the block detail header. */
	public static function render_actions( $block ) {
		$edit_url = add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
				'group_block_id' => absint( $block->id ),
				'group_view' => 'edit',
			),
			admin_url( 'admin.php' )
		);
		?>
		<a class="button tutorhelper-ui-button tutorhelper-ui-button--secondary" href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html__( 'Edit block', 'tutorhelper-group-bookings' ); ?></a>
		<?php if ( ! self::has_enrolments( $block->id ) ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-group-block-delete-form" data-confirm="<?php echo esc_attr__( 'Delete this lesson block and all of its planned sessions? This cannot be undone.', 'tutorhelper-group-bookings' ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::DELETE_ACTION ); ?>" />
				<input type="hidden" name="block_id" value="<?php echo esc_attr( $block->id ); ?>" />
				<?php wp_nonce_field( self::DELETE_ACTION . '_' . absint( $block->id ) ); ?>
				<button type="submit" class="button tutorhelper-ui-button tutorhelper-ui-button--secondary button-link-delete"><?php echo esc_html__( 'Delete block', 'tutorhelper-group-bookings' ); ?></button>
			</form>
		<?php endif;
	}

	/** Render the edit screen. */
	public static function render_edit_page( $block_id ) {
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' ) . '</p></div>';
			return;
		}

		$has_enrolments = self::has_enrolments( $block_id );
		$groups = TutorHelper_Pro_Groups::get_all( array( 'active_only' => true ) );
		$booking_types = TutorHelper_Booking_Types::get_active();
		$back_url = add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
				'group_block_id' => absint( $block_id ),
			),
			admin_url( 'admin.php' )
		);
		?>
		<section class="tutorhelper-main-section tutorhelper-group-block-edit">
			<header class="tutorhelper-main-section__header">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php echo esc_html__( 'Edit lesson block', 'tutorhelper-group-bookings' ); ?></h2>
					<p><?php echo esc_html( $block->title ); ?></p>
				</div>
				<a class="button tutorhelper-ui-button tutorhelper-ui-button--secondary" href="<?php echo esc_url( $back_url ); ?>"><?php echo esc_html__( 'Cancel', 'tutorhelper-group-bookings' ); ?></a>
			</header>
			<div class="tutorhelper-main-section__body">
				<?php if ( $has_enrolments ) : ?>
					<div class="notice notice-info inline"><p><?php echo esc_html__( 'This block already has enrolment history. Its schedule, group, Booking Type, prices, payment arrangement and location are locked so existing child bookings and financial agreements remain accurate. You can still edit its title and enrolment limits.', 'tutorhelper-group-bookings' ); ?></p></div>
				<?php endif; ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-group-block-form tutorhelper-group-block-form--edit" data-group-form-mode="edit">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::UPDATE_ACTION ); ?>" />
					<input type="hidden" name="block_id" value="<?php echo esc_attr( $block->id ); ?>" />
					<?php wp_nonce_field( self::UPDATE_ACTION . '_' . absint( $block->id ) ); ?>

					<div class="tutorhelper-group-block-edit__save">
						<button type="submit" class="button tutorhelper-ui-button tutorhelper-ui-button--primary tutorhelper-admin-button tutorhelper-admin-button--primary"><?php esc_html_e( 'Save lesson block', 'tutorhelper-group-bookings' ); ?></button>
					</div>

					<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Block title', 'tutorhelper-group-bookings' ); ?></span><input type="text" name="title" value="<?php echo esc_attr( $block->title ); ?>" required /></label>

					<div class="tutorhelper-group-block-form__grid">
						<label class="tutorhelper-admin-control"><span><?php esc_html_e( 'Bookable from', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="bookable_from" value="<?php echo esc_attr( $block->bookable_from ); ?>" /><small><?php esc_html_e( 'Leave blank to allow bookings immediately.', 'tutorhelper-group-bookings' ); ?></small></label>
						<label class="tutorhelper-admin-control"><span><?php esc_html_e( 'Bookable until', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="bookable_until" value="<?php echo esc_attr( $block->bookable_until ); ?>" /><small><?php esc_html_e( 'Leave blank to keep bookings open.', 'tutorhelper-group-bookings' ); ?></small></label>
					</div>

					<label class="tutorhelper-ui-option-row tutorhelper-group-block__public-option"><input type="checkbox" name="open_for_public_booking" value="1" <?php checked( ! empty( $block->open_for_public_booking ) ); ?> /> <span><?php esc_html_e( 'Open this Group Lesson for public booking', 'tutorhelper-group-bookings' ); ?></span></label>
					<p class="description"><?php esc_html_e( 'Visitors can view this block through the public Group listing. New visitors will register before reserving a place.', 'tutorhelper-group-bookings' ); ?></p>

					<?php if ( ! $has_enrolments ) : ?>
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Group', 'tutorhelper-group-bookings' ); ?></span><select name="group_id" required><?php foreach ( $groups as $group ) : ?><option value="<?php echo esc_attr( $group->id ); ?>" <?php selected( absint( $block->group_id ), absint( $group->id ) ); ?>><?php echo esc_html( $group->name ); ?></option><?php endforeach; ?></select></label>
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Booking Type', 'tutorhelper-group-bookings' ); ?></span><select name="booking_type_id" required><?php foreach ( $booking_types as $booking_type ) : ?><option value="<?php echo esc_attr( $booking_type->id ); ?>" <?php selected( absint( $block->booking_type_id ), absint( $booking_type->id ) ); ?>><?php echo esc_html( $booking_type->title ); ?></option><?php endforeach; ?></select></label>
						<div class="tutorhelper-group-block-form__grid">
							<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Start date', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="start_date" value="<?php echo esc_attr( $block->start_date ); ?>" required /></label>
							<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'End date', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="end_date" value="<?php echo esc_attr( $block->end_date ); ?>" required /></label>
							<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Start time', 'tutorhelper-group-bookings' ); ?></span><input type="time" name="start_time" value="<?php echo esc_attr( substr( $block->start_time, 0, 5 ) ); ?>" required /></label>
							<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'End time', 'tutorhelper-group-bookings' ); ?></span><input type="time" name="end_time" value="<?php echo esc_attr( substr( $block->end_time, 0, 5 ) ); ?>" required /></label>
						</div>
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Repeats', 'tutorhelper-group-bookings' ); ?></span><select name="frequency"><option value="weekly" <?php selected( $block->frequency, 'weekly' ); ?>><?php echo esc_html__( 'Weekly', 'tutorhelper-group-bookings' ); ?></option><option value="fortnightly" <?php selected( $block->frequency, 'fortnightly' ); ?>><?php echo esc_html__( 'Fortnightly', 'tutorhelper-group-bookings' ); ?></option></select></label>
					<?php endif; ?>

					<div class="tutorhelper-group-block-form__grid">
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Minimum enrolment', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="min_enrolments" min="1" value="<?php echo esc_attr( $block->min_enrolments ); ?>" required /></label>
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Maximum enrolment', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="max_enrolments" min="1" value="<?php echo null !== $block->max_enrolments ? esc_attr( $block->max_enrolments ) : ''; ?>" placeholder="<?php echo esc_attr__( 'Unlimited', 'tutorhelper-group-bookings' ); ?>" /></label>
					</div>

					<?php if ( ! $has_enrolments ) : ?>
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Pricing', 'tutorhelper-group-bookings' ); ?></span><select name="pricing_basis"><option value="booking_type" <?php selected( $block->pricing_basis, 'booking_type' ); ?>><?php echo esc_html__( 'Use Booking Type price', 'tutorhelper-group-bookings' ); ?></option><option value="per_session" <?php selected( $block->pricing_basis, 'per_session' ); ?>><?php echo esc_html__( 'Set price per lesson', 'tutorhelper-group-bookings' ); ?></option><option value="fixed_block" <?php selected( $block->pricing_basis, 'fixed_block' ); ?>><?php echo esc_html__( 'Set fixed block price', 'tutorhelper-group-bookings' ); ?></option></select></label>
						<div class="tutorhelper-group-block-form__grid">
							<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Price per lesson', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="price_per_session_minor_units" min="0" value="<?php echo esc_attr( $block->price_per_session_minor_units ); ?>" /><small><?php echo esc_html__( 'Enter the amount students pay for each lesson.', 'tutorhelper-group-bookings' ); ?></small></label>
							<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Fixed block price', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="fixed_block_price_minor_units" min="0" value="<?php echo null !== $block->fixed_block_price_minor_units ? esc_attr( $block->fixed_block_price_minor_units ) : ''; ?>" /><small><?php echo esc_html__( 'Only used with fixed block pricing.', 'tutorhelper-group-bookings' ); ?></small></label>
						</div>
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Payment arrangement', 'tutorhelper-group-bookings' ); ?></span><select name="payment_mode"><option value="manual" <?php selected( $block->payment_mode, 'manual' ); ?>><?php echo esc_html__( 'Invoice / manual payment', 'tutorhelper-group-bookings' ); ?></option><option value="full_upfront" <?php selected( $block->payment_mode, 'full_upfront' ); ?>><?php echo esc_html__( 'Full payment upfront', 'tutorhelper-group-bookings' ); ?></option><option value="deposit" <?php selected( $block->payment_mode, 'deposit' ); ?>><?php echo esc_html__( 'Book with deposit', 'tutorhelper-group-bookings' ); ?></option></select></label>
						<div class="tutorhelper-group-block-form__grid">
							<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Deposit type', 'tutorhelper-group-bookings' ); ?></span><select name="deposit_type"><option value="none" <?php selected( $block->deposit_type, 'none' ); ?>><?php echo esc_html__( 'None', 'tutorhelper-group-bookings' ); ?></option><option value="fixed" <?php selected( $block->deposit_type, 'fixed' ); ?>><?php echo esc_html__( 'Fixed amount', 'tutorhelper-group-bookings' ); ?></option><option value="percentage" <?php selected( $block->deposit_type, 'percentage' ); ?>><?php echo esc_html__( 'Percentage', 'tutorhelper-group-bookings' ); ?></option></select></label>
							<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Deposit value', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="deposit_value" min="0" step="0.01" value="<?php echo esc_attr( self::deposit_display_value( $block ) ); ?>" /><small><?php echo esc_html__( 'Fixed amounts use currency; percentages use whole numbers.', 'tutorhelper-group-bookings' ); ?></small></label>
						</div>
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Location type', 'tutorhelper-group-bookings' ); ?></span><select name="location_type" required><option value="online" <?php selected( $block->location_type, 'online' ); ?>><?php echo esc_html__( 'Online', 'tutorhelper-group-bookings' ); ?></option><option value="in-person" <?php selected( $block->location_type, 'in-person' ); ?>><?php echo esc_html__( 'In person', 'tutorhelper-group-bookings' ); ?></option><option value="phone" <?php selected( $block->location_type, 'phone' ); ?>><?php echo esc_html__( 'Phone', 'tutorhelper-group-bookings' ); ?></option></select></label>
						<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Location details', 'tutorhelper-group-bookings' ); ?></span><textarea name="location_details" rows="3"><?php echo esc_textarea( $block->location_details ); ?></textarea></label>
					<?php endif; ?>

				</form>
			</div>
		</section>
		<?php
	}

	/** Process a block update. */
	public static function handle_update() {
		self::require_capability();
		$block_id = isset( $_POST['block_id'] ) ? absint( $_POST['block_id'] ) : 0;
		check_admin_referer( self::UPDATE_ACTION . '_' . $block_id );
		$result = self::update( $block_id, $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The service validates supported fields.
		self::redirect_after_action( $block_id, is_wp_error( $result ) ? 'error' : 'updated', $result );
	}

	/** Process permanent deletion of an unused block. */
	public static function handle_delete() {
		self::require_capability();
		$block_id = isset( $_POST['block_id'] ) ? absint( $_POST['block_id'] ) : 0;
		check_admin_referer( self::DELETE_ACTION . '_' . $block_id );
		$result = self::delete( $block_id );
		self::redirect_after_action( is_wp_error( $result ) ? $block_id : 0, is_wp_error( $result ) ? 'error' : 'deleted', $result );
	}

	/** Update a block, rebuilding sessions only while it has no enrolment history. */
	private static function update( $block_id, $raw_data ) {
		global $wpdb;
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			return new WP_Error( 'tutorhelper_group_block_missing', __( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' ) );
		}

		$has_enrolments = self::has_enrolments( $block_id );
		if ( $has_enrolments ) {
			$prepared = TutorHelper_Group_Block_Create::prepare( array_merge( (array) $block, is_array( $raw_data ) ? $raw_data : array() ) );
			if ( is_wp_error( $prepared ) ) {
				return $prepared;
			}

			$minimum = isset( $raw_data['min_enrolments'] ) ? max( 1, absint( $raw_data['min_enrolments'] ) ) : absint( $block->min_enrolments );
			$maximum = isset( $raw_data['max_enrolments'] ) && '' !== (string) $raw_data['max_enrolments'] ? absint( $raw_data['max_enrolments'] ) : null;
			$limits = TutorHelper_Group_Blocks::validate_enrolment_limits( $minimum, $maximum );
			if ( is_wp_error( $limits ) ) {
				return $limits;
			}
			$reserved = TutorHelper_Group_Enrolments::count_reserved_places( $block_id );
			if ( null !== $maximum && $maximum < $reserved ) {
				return new WP_Error( 'tutorhelper_group_capacity_below_reserved', sprintf(
					/* translators: %d: Number of places already reserved. */
					__( 'Maximum enrolment cannot be lower than the %d places already reserved.', 'tutorhelper-group-bookings' ), $reserved ) );
			}
			$changes = array(
				'title' => isset( $raw_data['title'] ) ? sanitize_text_field( wp_unslash( $raw_data['title'] ) ) : $block->title,
				'min_enrolments' => $minimum,
				'max_enrolments' => $maximum,
				'bookable_from' => $prepared['bookable_from'] ? $prepared['bookable_from'] : null,
				'bookable_until' => $prepared['bookable_until'] ? $prepared['bookable_until'] : null,
				'open_for_public_booking' => absint( $prepared['open_for_public_booking'] ),
				'updated_at' => current_time( 'mysql', true ),
			);
			if ( '' === $changes['title'] ) {
				$changes['title'] = $block->title;
			}
		} else {
			$prepared = TutorHelper_Group_Block_Create::prepare( array_merge( (array) $block, is_array( $raw_data ) ? $raw_data : array() ) );
			if ( is_wp_error( $prepared ) ) {
				return $prepared;
			}
			$changes = $prepared;
			unset( $changes['status'] );
			$changes['updated_at'] = current_time( 'mysql', true );
		}

		$schedule_changed = ! $has_enrolments && self::schedule_changed( $block, $changes );
		if ( $schedule_changed ) {
			$calendar_ready = self::remove_calendar_events( $block_id );
			if ( is_wp_error( $calendar_ready ) ) {
				return $calendar_ready;
			}
		}

		$updated = $wpdb->update( TutorHelper_Group_Blocks::get_table_name(), $changes, array( 'id' => absint( $block_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Block management owns this custom table.
		if ( false === $updated ) {
			return new WP_Error( 'tutorhelper_group_block_update_failed', $wpdb->last_error ? $wpdb->last_error : __( 'The Group Lesson block could not be updated.', 'tutorhelper-group-bookings' ) );
		}

		if ( $schedule_changed ) {
			TutorHelper_Group_Sessions::delete_for_block( $block_id );
			$generated = TutorHelper_Group_Sessions::generate_for_block( $block_id );
			if ( is_wp_error( $generated ) ) {
				return $generated;
			}
		}

		do_action( 'tutorhelper_group_block_updated', $block_id, TutorHelper_Group_Blocks::get_by_id( $block_id ), $block );
		do_action( 'tutorhelper_group_enrolment_changed', $block_id, TutorHelper_Group_Enrolments::count_secured( $block_id ) );
		return true;
	}

	/** Permanently delete a block only when no enrolment record has ever existed. */
	private static function delete( $block_id ) {
		global $wpdb;
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			return new WP_Error( 'tutorhelper_group_block_missing', __( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' ) );
		}
		if ( self::has_enrolments( $block_id ) ) {
			return new WP_Error( 'tutorhelper_group_block_has_enrolments', __( 'A block with enrolment history cannot be deleted. It will be cancellable from the G8 cancellation workflow.', 'tutorhelper-group-bookings' ) );
		}
		$calendar_ready = self::remove_calendar_events( $block_id );
		if ( is_wp_error( $calendar_ready ) ) {
			return $calendar_ready;
		}
		TutorHelper_Group_Sessions::delete_for_block( $block_id );
		$deleted = $wpdb->delete( TutorHelper_Group_Blocks::get_table_name(), array( 'id' => absint( $block_id ) ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Permanent deletion is restricted to unused blocks.
		if ( false === $deleted ) {
			return new WP_Error( 'tutorhelper_group_block_delete_failed', __( 'The Group Lesson block could not be deleted.', 'tutorhelper-group-bookings' ) );
		}
		do_action( 'tutorhelper_group_block_deleted', $block_id, $block );
		return true;
	}

	/** Remove remote events before local sessions are rebuilt/deleted. */
	private static function remove_calendar_events( $block_id ) {
		$sessions = TutorHelper_Group_Sessions::get_for_block( $block_id );
		$has_events = false;
		foreach ( $sessions as $session ) {
			$has_events = $has_events || ! empty( $session->calendar_event_id );
		}
		if ( $has_events && ( ! class_exists( 'TutorHelper_Pro_Google_Calendar' ) || ! TutorHelper_Pro_Google_Calendar::is_connected() ) ) {
			return new WP_Error( 'tutorhelper_group_calendar_disconnect', __( 'Reconnect Google Calendar before changing this schedule or deleting the block, so its existing shared events can be removed safely.', 'tutorhelper-group-bookings' ) );
		}
		TutorHelper_Group_Calendar_Lifecycle::delete_block_events( $block_id );
		foreach ( TutorHelper_Group_Sessions::get_for_block( $block_id ) as $session ) {
			if ( ! empty( $session->calendar_event_id ) ) {
				return new WP_Error( 'tutorhelper_group_calendar_delete_failed', __( 'At least one shared Calendar event could not be removed. The block was left unchanged; check TutorHelper Diagnostics and try again.', 'tutorhelper-group-bookings' ) );
			}
		}
		return true;
	}

	/** Whether any historical enrolment is linked to a block. */
	private static function has_enrolments( $block_id ) {
		return ! empty( TutorHelper_Group_Enrolments::get_for_block( $block_id ) );
	}

	/** Whether a full edit changes generated session dates or times. */
	private static function schedule_changed( $block, $changes ) {
		foreach ( array( 'start_date', 'end_date', 'start_time', 'end_time', 'frequency', 'timezone' ) as $field ) {
			if ( isset( $changes[ $field ] ) && (string) $block->{$field} !== (string) $changes[ $field ] ) {
				return true;
			}
		}
		return false;
	}

	/** Require the Booking Hub capability. */
	private static function require_capability() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Group Lesson blocks.', 'tutorhelper-group-bookings' ) );
		}
	}

	/** Redirect to the block/list with a result notice. */
	private static function redirect_after_action( $block_id, $notice, $result ) {
		$args = array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY, 'group_notice' => $notice );
		if ( $block_id ) {
			$args['group_block_id'] = absint( $block_id );
		}
		if ( is_wp_error( $result ) ) {
			$args['group_message'] = rawurlencode( $result->get_error_message() );
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Display fixed deposits as normal currency, percentages unchanged. */
	private static function deposit_display_value( $block ) {
		return TutorHelper_Group_Blocks::DEPOSIT_FIXED === sanitize_key( $block->deposit_type )
			? number_format( absint( $block->deposit_value ) / 100, 2, '.', '' )
			: absint( $block->deposit_value );
	}
}
