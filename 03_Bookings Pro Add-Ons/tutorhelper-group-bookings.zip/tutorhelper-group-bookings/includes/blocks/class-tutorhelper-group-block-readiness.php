<?php
/**
 * Group Block readiness lifecycle.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps Group Block status aligned with enrolment readiness.
 */
final class TutorHelper_Group_Block_Readiness {

	const MIGRATION_OPTION = 'tutorhelper_group_readiness_migrated_1';
	const SCRIPT_HANDLE = 'tutorhelper-group-block-readiness';

	/** Register lifecycle hooks. */
	public static function init() {
		add_action( 'tutorhelper_group_block_created', array( __CLASS__, 'handle_block_created' ), 10, 1 );
		add_action( 'tutorhelper_group_enrolment_changed', array( __CLASS__, 'refresh_from_enrolment_count' ), 10, 2 );
		add_action( 'admin_init', array( __CLASS__, 'migrate_existing_drafts' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ), 50 );
	}

	/** @param int $block_id Group Block ID. */
	public static function handle_block_created( $block_id ) {
		self::refresh_from_enrolment_count( $block_id, 0 );
	}

	/**
	 * Resolve and persist readiness from live enrolment counts.
	 *
	 * @param int $block_id Group Block ID.
	 * @param int $enrolment_count Secured enrolment count supplied by caller.
	 * @return string|WP_Error
	 */
	public static function refresh_from_enrolment_count( $block_id, $enrolment_count ) {
		global $wpdb;

		$block_id = absint( $block_id );
		$secured_count = max( 0, absint( $enrolment_count ) );
		$reserved_count = $secured_count;

		if ( class_exists( 'TutorHelper_Group_Enrolments' ) ) {
			$secured_count = TutorHelper_Group_Enrolments::count_secured( $block_id );
			$reserved_count = TutorHelper_Group_Enrolments::count_reserved_places( $block_id );
		}

		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			return new WP_Error(
				'tutorhelper_group_block_readiness_not_found',
				__( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$current_status = sanitize_key( $block->status );
		if (
			in_array(
				$current_status,
				array(
					TutorHelper_Group_Blocks::STATUS_CANCELLED,
					TutorHelper_Group_Blocks::STATUS_COMPLETED,
				),
				true
			)
		) {
			return $current_status;
		}

		$new_status = self::resolve_status( $block, $secured_count, $reserved_count );
		if ( $new_status === $current_status ) {
			return $new_status;
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group Block lifecycle state is stored in the add-on custom table.
			TutorHelper_Group_Blocks::get_table_name(),
			array(
				'status' => $new_status,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $block_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error(
				'tutorhelper_group_block_readiness_update_failed',
				__( 'The Group Lesson block status could not be updated.', 'tutorhelper-group-bookings' )
			);
		}

		do_action(
			'tutorhelper_group_block_status_changed',
			$block_id,
			$new_status,
			$current_status,
			$secured_count,
			$reserved_count
		);

		return $new_status;
	}

	/**
	 * Determine status from block enrolment rules.
	 *
	 * Reaching capacity must not imply that the block has reached its
	 * confirmation minimum. Capacity is enforced independently.
	 *
	 * @param object $block Group Block record.
	 * @param int    $secured_count Secured enrolments.
	 * @param int    $reserved_count Reserved places.
	 * @return string
	 */
	private static function resolve_status( $block, $secured_count, $reserved_count ) {
		$minimum = max( 1, absint( $block->min_enrolments ) );
		$maximum = null !== $block->max_enrolments ? absint( $block->max_enrolments ) : 0;

		if ( $secured_count < $minimum ) {
			return TutorHelper_Group_Blocks::STATUS_AWAITING_MINIMUM;
		}

		if ( $maximum && $reserved_count >= $maximum ) {
			return TutorHelper_Group_Blocks::STATUS_FULL;
		}

		return TutorHelper_Group_Blocks::STATUS_CONFIRMED;
	}

	/** One-time migration of early generated Draft blocks. */
	public static function migrate_existing_drafts() {
		global $wpdb;

		if ( get_option( self::MIGRATION_OPTION, false ) ) {
			return;
		}

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time migration of early development block state.
			$wpdb->prepare(
				'UPDATE %i AS blocks
				SET blocks.status = %s,
					blocks.updated_at = %s
				WHERE blocks.status = %s
				AND EXISTS (
					SELECT 1 FROM %i AS sessions
					WHERE sessions.block_id = blocks.id
				)',
				TutorHelper_Group_Blocks::get_table_name(),
				TutorHelper_Group_Blocks::STATUS_AWAITING_MINIMUM,
				current_time( 'mysql', true ),
				TutorHelper_Group_Blocks::STATUS_DRAFT,
				TutorHelper_Group_Sessions::get_table_name()
			)
		);

		update_option( self::MIGRATION_OPTION, 1, false );
	}

	/** @param string $hook_suffix Current admin hook. */
	public static function enqueue_admin_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: '';

		if ( TutorHelper_Group_Bookings_Admin::TAB_KEY !== $tab ) {
			return;
		}

		$script_path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/js/group-lessons-readiness.js';
		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/js/group-lessons-readiness.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperGroupReadiness',
			array(
				'awaitingLabel' => __( 'Awaiting minimum enrolment', 'tutorhelper-group-bookings' ),
				'awaitingMessage' => __( 'This block is ready to accept enrolments, but its lessons will remain unconfirmed until the minimum number of secured students is reached.', 'tutorhelper-group-bookings' ),
			)
		);
	}
}
