<?php
/**
 * Group Block foundation service.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and validates Group Block definitions.
 */
final class TutorHelper_Group_Blocks {

	const STATUS_DRAFT = 'draft';
	const STATUS_OPEN = 'open';
	const STATUS_AWAITING_MINIMUM = 'awaiting_minimum';
	const STATUS_CONFIRMED = 'confirmed';
	const STATUS_FULL = 'full';
	const STATUS_CANCELLED = 'cancelled';
	const STATUS_COMPLETED = 'completed';

	const PRICING_BOOKING_TYPE = 'booking_type';
	const PRICING_PER_SESSION = 'per_session';
	const PRICING_FIXED_BLOCK = 'fixed_block';

	const DEPOSIT_NONE = 'none';
	const DEPOSIT_FIXED = 'fixed';
	const DEPOSIT_PERCENTAGE = 'percentage';

	const PAYMENT_MANUAL = 'manual';
	const PAYMENT_FULL_UPFRONT = 'full_upfront';
	const PAYMENT_DEPOSIT = 'deposit';

	/**
	 * Initialise the service.
	 *
	 * @return void
	 */
	public static function init() {
		// Foundation only. Admin and frontend workflows are added in later checkpoints.
	}

	/**
	 * Return the Group Blocks table name.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		return TutorHelper_Group_Bookings_Database::get_table_name( 'blocks' );
	}

	/**
	 * Retrieve one block.
	 *
	 * @param int $block_id Block ID.
	 * @return object|null
	 */
	public static function get_by_id( $block_id ) {
		global $wpdb;

		$block_id = absint( $block_id );
		if ( ! $block_id ) {
			return null;
		}

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group Block state must reflect current enrolment and session status.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE id = %d',
				self::get_table_name(),
				$block_id
			)
		);
	}

	/**
	 * Retrieve Group Blocks, newest first.
	 *
	 * @param array $args Query options.
	 * @return array
	 */
	public static function get_all( $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'group_id' => 0,
				'status' => '',
			)
		);

		$where = array( '1=1' );
		$values = array();

		if ( ! empty( $args['group_id'] ) ) {
			$where[] = 'group_id = %d';
			$values[] = absint( $args['group_id'] );
		}

		if ( ! empty( $args['status'] ) ) {
			$where[] = 'status = %s';
			$values[] = sanitize_key( $args['status'] );
		}

		$sql = 'SELECT * FROM %i WHERE '
			. implode( ' AND ', $where )
			. ' ORDER BY start_date DESC, id DESC';

		$query_args = array_merge(
			array( self::get_table_name() ),
			$values
		);

		$results = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Admin list must show current Group Block state.
			$wpdb->prepare( $sql, $query_args ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Query fragments are fixed internally and all external values are parameterised.
		);

		return is_array( $results ) ? $results : array();
	}

	/**
	 * Return whether a block has explicitly been opened for public discovery.
	 *
	 * A missing value is deliberately treated as private so existing blocks
	 * remain unchanged after the schema upgrade.
	 *
	 * @param object $block Group Block record.
	 * @return bool
	 */
	public static function is_open_for_public_booking( $block ) {
		return is_object( $block )
			&& ! empty( $block->open_for_public_booking );
	}

	/**
	 * Return whether a public block can accept a new enrolment now.
	 *
	 * This is intentionally a display helper only. Enrolment performs the
	 * same checks again immediately before creating a place.
	 *
	 * @param object $block Group Block record.
	 * @return true|WP_Error
	 */
	public static function validate_public_booking( $block ) {
		if ( ! self::is_open_for_public_booking( $block ) ) {
			return new WP_Error(
				'tutorhelper_group_public_booking_not_enabled',
				__( 'This Group Lesson is not open for public booking.', 'tutorhelper-group-bookings' )
			);
		}

		if (
			in_array(
				sanitize_key( isset( $block->status ) ? $block->status : '' ),
				array( self::STATUS_DRAFT, self::STATUS_CANCELLED, self::STATUS_COMPLETED ),
				true
			)
		) {
			return new WP_Error(
				'tutorhelper_group_public_booking_closed',
				__( 'Booking for this Group Lesson is not available.', 'tutorhelper-group-bookings' )
			);
		}

		return self::validate_booking_window( $block );
	}

	/**
	 * Validate enrolment limits.
	 *
	 * @param int      $minimum Minimum enrolments.
	 * @param int|null $maximum Maximum enrolments or null for unlimited.
	 * @return true|WP_Error
	 */
	public static function validate_enrolment_limits( $minimum, $maximum ) {
		$minimum = max( 1, absint( $minimum ) );
		$maximum = null === $maximum || '' === $maximum
			? null
			: absint( $maximum );

		if ( null !== $maximum && $maximum < $minimum ) {
			return new WP_Error(
				'tutorhelper_group_invalid_enrolment_limits',
				__(
					'Maximum enrolment must be greater than or equal to minimum enrolment.',
					'tutorhelper-group-bookings'
				)
			);
		}

		return true;
	}

	/**
	 * Calculate a block total from the pricing basis.
	 *
	 * @param object $block         Group Block record.
	 * @param int    $session_count Number of sessions.
	 * @return int
	 */
	public static function calculate_block_total( $block, $session_count ) {
		$session_count = max( 0, absint( $session_count ) );

		if ( ! is_object( $block ) || 0 === $session_count ) {
			return 0;
		}

		$pricing_basis = isset( $block->pricing_basis )
			? sanitize_key( $block->pricing_basis )
			: self::PRICING_BOOKING_TYPE;

		if (
			self::PRICING_FIXED_BLOCK === $pricing_basis
			&& null !== $block->fixed_block_price_minor_units
		) {
			return absint( $block->fixed_block_price_minor_units );
		}

		return absint( $block->price_per_session_minor_units )
			* $session_count;
	}

	/**
	 * Resolve the minimum-enrolment lifecycle state.
	 *
	 * @param object $block           Group Block record.
	 * @param int    $enrolment_count Active secured enrolment count.
	 * @return string
	 */
	public static function get_enrolment_status( $block, $enrolment_count ) {
		if ( ! is_object( $block ) ) {
			return self::STATUS_DRAFT;
		}

		$current_status = isset( $block->status )
			? sanitize_key( $block->status )
			: self::STATUS_DRAFT;

		if (
			in_array(
				$current_status,
				array( self::STATUS_DRAFT, self::STATUS_CANCELLED, self::STATUS_COMPLETED ),
				true
			)
		) {
			return $current_status;
		}

		$enrolment_count = max( 0, absint( $enrolment_count ) );
		$minimum = max( 1, absint( $block->min_enrolments ) );
		$maximum = null !== $block->max_enrolments
			? absint( $block->max_enrolments )
			: 0;

		if ( $maximum && $enrolment_count >= $maximum ) {
			return self::STATUS_FULL;
		}

		if ( $enrolment_count < $minimum ) {
			return self::STATUS_AWAITING_MINIMUM;
		}

		return self::STATUS_CONFIRMED;
	}
	/**
	 * Return whether a Group Block is presently within its booking window.
	 *
	 * @param object $block Group Block record.
	 * @return true|WP_Error
	 */
	public static function validate_booking_window( $block ) {
		if ( ! is_object( $block ) ) {
			return new WP_Error(
				'tutorhelper_group_booking_window_block_missing',
				__( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$today = wp_date( 'Y-m-d', null, wp_timezone() );
		$from = self::get_optional_booking_window_date( isset( $block->bookable_from ) ? $block->bookable_from : '' );
		$until = self::get_optional_booking_window_date( isset( $block->bookable_until ) ? $block->bookable_until : '' );

		if ( '' !== $from && $today < $from ) {
			return new WP_Error(
				'tutorhelper_group_booking_window_not_open',
				sprintf(
					/* translators: %s: booking opening date. */
					__( 'This Group Lesson opens for booking on %s.', 'tutorhelper-group-bookings' ),
					wp_date(
						get_option( 'date_format' ),
						( new DateTimeImmutable( $from, wp_timezone() ) )->getTimestamp(),
						wp_timezone()
					)
				)
			);
		}

		if ( '' !== $until && $today > $until ) {
			return new WP_Error(
				'tutorhelper_group_booking_window_closed',
				__( 'Booking for this Group Lesson has now closed.', 'tutorhelper-group-bookings' )
			);
		}

		return true;
	}


	/**
	 * Treat legacy MySQL zero dates as an unrestricted booking window.
	 *
	 * @param mixed $date Stored date value.
	 * @return string
	 */
	private static function get_optional_booking_window_date( $date ) {
		$date = is_scalar( $date ) ? sanitize_text_field( $date ) : '';

		return '0000-00-00' === $date || '0000-00-00 00:00:00' === $date
			? ''
			: $date;
	}

	/**
	 * Return a student-facing booking-window message, if applicable.
	 *
	 * @param object $block Group Block record.
	 * @return string
	 */
	public static function get_booking_window_message( $block ) {
		$result = self::validate_booking_window( $block );

		return is_wp_error( $result ) ? $result->get_error_message() : '';
	}

}
