<?php
/**
 * TutorHelper Group Bookings dependency checks.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Confirms that TutorHelper Core and Pro are available.
 */
final class TutorHelper_Group_Bookings_Dependency {

	/**
	 * Check whether TutorHelper Bookings Core is loaded.
	 *
	 * @return bool
	 */
	public static function core_is_available() {
		return defined( 'TUTORHELPER_BOOKINGS_VERSION' )
			&& class_exists( 'TutorHelper_Booking_Records' );
	}

	/**
	 * Check whether TutorHelper Pro is loaded.
	 *
	 * @return bool
	 */
	public static function pro_is_available() {
		return defined( 'TUTORHELPER_PRO_VERSION' )
			&& class_exists( 'TutorHelper_Pro_Groups' );
	}

	/**
	 * Check whether TutorHelper Pro has an active licence.
	 *
	 * @return bool
	 */
	public static function pro_is_licensed() {
		return self::pro_is_available()
			&& class_exists( 'TutorHelper_Pro_License' )
			&& TutorHelper_Pro_License::is_active();
	}

	/**
	 * Check whether all required plugins are available.
	 *
	 * @return bool
	 */
	public static function requirements_met() {
		return self::core_is_available()
			&& self::pro_is_available();
	}

	/**
	 * Register the missing dependency notice.
	 *
	 * @return void
	 */
	public static function register_admin_notice() {
		add_action(
			'admin_notices',
			array( __CLASS__, 'render_admin_notice' )
		);
	}

	/**
	 * Render the missing dependency notice.
	 *
	 * @return void
	 */
	public static function render_admin_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		if ( self::requirements_met() && ! self::pro_is_licensed() ) {
			$message = __( 'Activate your TutorHelper Pro licence before using Group Bookings.', 'tutorhelper-group-bookings' );
		} else {
			$message = __( 'Both TutorHelper Bookings and TutorHelper Pro must be active before Group Bookings can run.', 'tutorhelper-group-bookings' );
		}
		?>
		<div class="notice notice-error">
			<p>
				<strong>
					<?php
					echo esc_html__(
						'TutorHelper Group Bookings is not active.',
						'tutorhelper-group-bookings'
					);
					?>
				</strong>
				<?php
				echo esc_html( $message );
				?>
			</p>
		</div>
		<?php
	}
}
