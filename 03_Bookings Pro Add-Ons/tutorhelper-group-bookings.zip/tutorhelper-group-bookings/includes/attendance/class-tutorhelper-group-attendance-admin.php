<?php
/**
 * Tutor-facing attendance for Group Sessions.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Presents one Group Session roster while storing attendance against the
 * existing individual Core child bookings through TutorHelper Pro.
 */
final class TutorHelper_Group_Attendance_Admin {

	const AJAX_ACTION = 'tutorhelper_group_save_attendance';
	const AJAX_NONCE = 'tutorhelper_group_save_attendance';

	/** Register attendance hooks. */
	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 50 );
		add_action( 'wp_ajax_' . self::AJAX_ACTION, array( __CLASS__, 'handle_save_ajax' ) );
	}

	/** Load the Group attendance controller on the Group Lessons tab. */
	public static function enqueue_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: '';

		if ( TutorHelper_Group_Bookings_Admin::TAB_KEY !== $tab ) {
			return;
		}

		$script_path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/js/group-lessons-attendance.js';
		wp_enqueue_script(
			'tutorhelper-group-lessons-attendance',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/js/group-lessons-attendance.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION,
			true
		);

		wp_localize_script(
			'tutorhelper-group-lessons-attendance',
			'tutorhelperGroupAttendance',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action' => self::AJAX_ACTION,
				'nonce' => wp_create_nonce( self::AJAX_NONCE ),
				'savingLabel' => __( 'Saving…', 'tutorhelper-group-bookings' ),
				'savedLabel' => __( 'Saved', 'tutorhelper-group-bookings' ),
				'failedLabel' => __( 'Attendance could not be saved.', 'tutorhelper-group-bookings' ),
			)
		);
	}

	/**
	 * Render the attendance workspace for one Group Session.
	 *
	 * @param object $block Group Block.
	 * @param object $session Group Session.
	 * @return void
	 */
	public static function render_page( $block, $session ) {
		if ( ! self::session_belongs_to_block( $session, $block ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'The Group Session could not be found in this lesson block.', 'tutorhelper-group-bookings' ) . '</p></div>';
			return;
		}

		$roster = self::get_roster( $session->id );
		$summary = self::get_summary_from_roster( $roster );
		$navigation = self::get_session_navigation( $block->id, $session->id );
		$block_url = self::get_block_url( $block->id );
		?>
		<section class="tutorhelper-main-section tutorhelper-group-attendance" data-group-attendance-session="<?php echo esc_attr( $session->id ); ?>">
			<header class="tutorhelper-main-section__header">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php echo esc_html__( 'Group attendance', 'tutorhelper-group-bookings' ); ?></h2>
					<p><?php echo esc_html( $block->title . ' — ' . self::format_session_date( $session, $block ) ); ?></p>
				</div>
				<div class="tutorhelper-group-block-detail__actions">
					<?php
					if ( class_exists( 'TutorHelper_Pro_Lesson_Follow_Up' ) ) {
						TutorHelper_Pro_Lesson_Follow_Up::render_group_tutor_button( absint( $session->id ) );
					}
					?>
					<a class="button tutorhelper-hub-pill-button" href="<?php echo esc_url( $block_url ); ?>"><?php echo esc_html__( 'Back to block', 'tutorhelper-group-bookings' ); ?></a>
				</div>
			</header>

			<div class="tutorhelper-main-section__body">
				<div class="tutorhelper-group-attendance__summary">
					<div><strong><?php echo esc_html__( 'Session', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo esc_html( '#' . absint( $session->session_number ) ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Students', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo esc_html( count( $roster ) ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Attendance recorded', 'tutorhelper-group-bookings' ); ?></strong><span data-attendance-progress><?php echo esc_html( self::format_progress( $summary ) ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Session status', 'tutorhelper-group-bookings' ); ?></strong><span class="tutorhelper-group-status is-<?php echo esc_attr( sanitize_key( $session->status ) ); ?>"><?php echo esc_html( ucfirst( str_replace( '_', ' ', sanitize_key( $session->status ) ) ) ); ?></span></div>
				</div>

				<?php self::render_navigation( $navigation, $block ); ?>

				<div class="tutorhelper-group-lessons__table-wrap">
					<table class="widefat striped tutorhelper-group-attendance__table">
						<thead><tr><th scope="col"><?php echo esc_html__( 'Student', 'tutorhelper-group-bookings' ); ?></th><th scope="col"><?php echo esc_html__( 'Booking status', 'tutorhelper-group-bookings' ); ?></th><th scope="col"><?php echo esc_html__( 'Attendance', 'tutorhelper-group-bookings' ); ?></th><th scope="col"><?php echo esc_html__( 'Feedback & homework', 'tutorhelper-group-bookings' ); ?></th><th scope="col"><span class="screen-reader-text"><?php echo esc_html__( 'Save status', 'tutorhelper-group-bookings' ); ?></span></th></tr></thead>
						<tbody>
							<?php if ( empty( $roster ) ) : ?>
								<tr><td colspan="5"><?php echo esc_html__( 'No student bookings are linked to this Group Session yet.', 'tutorhelper-group-bookings' ); ?></td></tr>
							<?php else : ?>
								<?php foreach ( $roster as $entry ) : ?>
									<?php self::render_student_row( $entry ); ?>
								<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</section>
		<?php
	}

	/** Render the attendance action in the block's sessions table. */
	public static function render_session_action( $block, $session ) {
		$roster = self::get_roster( $session->id );
		$summary = self::get_summary_from_roster( $roster );
		$url = add_query_arg( 'group_session_id', absint( $session->id ), self::get_block_url( $block->id ) );
		?>
		<a class="button tutorhelper-hub-pill-button-small" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html__( 'Attendance', 'tutorhelper-group-bookings' ); ?></a>
		<small class="tutorhelper-group-attendance__session-progress"><?php echo esc_html( self::format_attended( $summary ) ); ?></small>
		<?php
	}

	/** Save one linked student's attendance through AJAX. */
	public static function handle_save_ajax() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to update attendance.', 'tutorhelper-group-bookings' ) ), 403 );
		}

		check_ajax_referer( self::AJAX_NONCE, 'nonce' );

		$session_id = isset( $_POST['session_id'] ) && ! is_array( $_POST['session_id'] ) ? absint( $_POST['session_id'] ) : 0;
		$booking_id = isset( $_POST['booking_id'] ) && ! is_array( $_POST['booking_id'] ) ? absint( $_POST['booking_id'] ) : 0;
		$status = isset( $_POST['attendance_status'] ) && ! is_array( $_POST['attendance_status'] ) ? sanitize_key( wp_unslash( $_POST['attendance_status'] ) ) : '';

		if ( ! $session_id || ! $booking_id || ! self::booking_belongs_to_session( $booking_id, $session_id ) ) {
			wp_send_json_error( array( 'message' => __( 'This booking is not part of the selected Group Session.', 'tutorhelper-group-bookings' ) ), 400 );
		}

		$allowed = TutorHelper_Pro_Booking_Attendance::get_statuses();
		if (
			! isset( $allowed[ $status ] )
			|| TutorHelper_Pro_Booking_Attendance::STATUS_NOT_APPLICABLE === $status
		) {
			wp_send_json_error( array( 'message' => __( 'The attendance status is invalid.', 'tutorhelper-group-bookings' ) ), 400 );
		}

		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		if ( ! $booking ) {
			wp_send_json_error( array( 'message' => __( 'The linked child booking could not be found.', 'tutorhelper-group-bookings' ) ), 404 );
		}

		if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
			wp_send_json_error( array( 'message' => __( 'Attendance cannot be recorded for a cancelled booking.', 'tutorhelper-group-bookings' ) ), 409 );
		}

		$result = TutorHelper_Pro_Booking_Attendance::save( $booking_id, $status, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
		}

		$summary = self::get_summary_from_roster( self::get_roster( $session_id ) );
		wp_send_json_success(
			array(
				'bookingId' => $booking_id,
				'status' => $status,
				'label' => TutorHelper_Pro_Booking_Attendance::get_status_label( $status ),
				'progress' => self::format_progress( $summary ),
			)
		);
	}

	/** Return child bookings, students and attendance for one session. */
	private static function get_roster( $session_id ) {
		global $wpdb;
		$links = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Attendance must reflect the current Group Session roster.
			$wpdb->prepare(
				'SELECT booking_id, enrolment_id, student_user_id FROM %i WHERE session_id = %d ORDER BY student_user_id ASC',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				absint( $session_id )
			)
		);

		$links = is_array( $links ) ? $links : array();
		$booking_ids = array_map( 'absint', wp_list_pluck( $links, 'booking_id' ) );
		$attendance = TutorHelper_Pro_Booking_Attendance::get_for_booking_ids( $booking_ids );
		$roster = array();

		foreach ( $links as $link ) {
			$booking_id = absint( $link->booking_id );
			$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
			if ( ! $booking ) {
				continue;
			}
			$student = get_user_by( 'id', absint( $link->student_user_id ) );
			$roster[] = array(
				'booking' => $booking,
				'session_id' => absint( $session_id ),
				'student_name' => $student instanceof WP_User ? $student->display_name : self::get_booking_student_name( $booking ),
				'attendance' => isset( $attendance[ $booking_id ] ) ? $attendance[ $booking_id ] : null,
			);
		}

		usort(
			$roster,
			function ( $first, $second ) {
				return strcasecmp( $first['student_name'], $second['student_name'] );
			}
		);

		return $roster;
	}

	/** Render one independently editable student row. */
	private static function render_student_row( $entry ) {
		$booking = $entry['booking'];
		$cancelled = TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status );
		$status = $cancelled
			? TutorHelper_Pro_Booking_Attendance::STATUS_NOT_APPLICABLE
			: ( $entry['attendance'] && ! empty( $entry['attendance']->attendance_status ) ? sanitize_key( $entry['attendance']->attendance_status ) : TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED );
		?>
		<tr data-attendance-row data-attendance-status="<?php echo esc_attr( $status ); ?>">
			<td><strong><?php echo esc_html( $entry['student_name'] ); ?></strong></td>
			<td><?php echo esc_html( self::get_booking_status_label( $booking->status ) ); ?></td>
			<td>
				<?php if ( $cancelled ) : ?>
					<span><?php echo esc_html( TutorHelper_Pro_Booking_Attendance::get_status_label( TutorHelper_Pro_Booking_Attendance::STATUS_NOT_APPLICABLE ) ); ?></span>
				<?php else : ?>
					<label><span class="screen-reader-text"><?php echo esc_html( sprintf(
							/* translators: %s: Student name. */
							__( 'Attendance for %s', 'tutorhelper-group-bookings' ), $entry['student_name'] ) ); ?></span>
						<select data-group-attendance data-booking-id="<?php echo esc_attr( $booking->id ); ?>" data-previous-status="<?php echo esc_attr( $status ); ?>">
							<?php foreach ( TutorHelper_Pro_Booking_Attendance::get_statuses() as $status_key => $status_label ) : ?>
								<?php if ( TutorHelper_Pro_Booking_Attendance::STATUS_NOT_APPLICABLE === $status_key ) { continue; } ?>
								<option value="<?php echo esc_attr( $status_key ); ?>" <?php selected( $status, $status_key ); ?>><?php echo esc_html( $status_label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
				<?php endif; ?>
			</td>
			<td>
				<?php
				if ( ! $cancelled && class_exists( 'TutorHelper_Pro_Lesson_Follow_Up' ) ) {
					TutorHelper_Pro_Lesson_Follow_Up::render_tutor_button(
						absint( $booking->id ),
						absint( $entry['session_id'] )
					);
				}
				?>
			</td>
			<td><span class="tutorhelper-group-attendance__save-status" data-attendance-save-status aria-live="polite"></span></td>
		</tr>
		<?php
	}

	/** Calculate recorded/eligible counts from a roster. */
	private static function get_summary_from_roster( $roster ) {
		$summary = array( 'recorded' => 0, 'eligible' => 0, 'not_applicable' => 0, 'confirmed' => 0, 'attended' => 0 );
		foreach ( $roster as $entry ) {
			if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $entry['booking']->status ) ) {
				++$summary['not_applicable'];
				continue;
			}
			++$summary['eligible'];
			$attendance_status = $entry['attendance'] && ! empty( $entry['attendance']->attendance_status )
				? sanitize_key( $entry['attendance']->attendance_status )
				: TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED;

			if ( TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED !== $attendance_status ) {
				++$summary['recorded'];
			}

			if ( TutorHelper_Booking_Records::STATUS_CONFIRMED === sanitize_key( $entry['booking']->status ) ) {
				++$summary['confirmed'];
				if ( TutorHelper_Pro_Booking_Attendance::STATUS_ATTENDED === $attendance_status ) {
					++$summary['attended'];
				}
			}
		}
		return $summary;
	}

	/** Format the attended count against confirmed child bookings. */
	private static function format_attended( $summary ) {
		return sprintf(
			/* translators: 1: attended student count, 2: confirmed booking count. */
			__( '%1$d/%2$d attended', 'tutorhelper-group-bookings' ),
			absint( $summary['attended'] ),
			absint( $summary['confirmed'] )
		);
	}

	/** Format a compact attendance progress label. */
	private static function format_progress( $summary ) {
		if ( 0 === absint( $summary['eligible'] ) ) {
			return 0 < absint( $summary['not_applicable'] ) ? __( 'Not applicable', 'tutorhelper-group-bookings' ) : __( 'No students', 'tutorhelper-group-bookings' );
		}
		return sprintf(
			/* translators: 1: recorded student count, 2: eligible student count. */
			__( '%1$d of %2$d recorded', 'tutorhelper-group-bookings' ),
			absint( $summary['recorded'] ),
			absint( $summary['eligible'] )
		);
	}

	/** Confirm a child booking belongs to this exact Group Session. */
	private static function booking_belongs_to_session( $booking_id, $session_id ) {
		global $wpdb;
		return (bool) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Security boundary for the submitted Group attendance row.
			$wpdb->prepare(
				'SELECT 1 FROM %i WHERE booking_id = %d AND session_id = %d LIMIT 1',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				absint( $booking_id ),
				absint( $session_id )
			)
		);
	}

	/** Confirm the requested session is owned by the requested block. */
	private static function session_belongs_to_block( $session, $block ) {
		return is_object( $session ) && is_object( $block ) && absint( $session->block_id ) === absint( $block->id );
	}

	/** Render previous/next session links. */
	private static function render_navigation( $navigation, $block ) {
		if ( ! $navigation['previous'] && ! $navigation['next'] ) {
			return;
		}
		?>
		<nav class="tutorhelper-group-attendance__navigation" aria-label="<?php echo esc_attr__( 'Group Session attendance navigation', 'tutorhelper-group-bookings' ); ?>">
			<?php if ( $navigation['previous'] ) : ?><a class="button" href="<?php echo esc_url( add_query_arg( 'group_session_id', absint( $navigation['previous']->id ), self::get_block_url( $block->id ) ) ); ?>">&larr; <?php echo esc_html__( 'Previous session', 'tutorhelper-group-bookings' ); ?></a><?php endif; ?>
			<?php if ( $navigation['next'] ) : ?><a class="button" href="<?php echo esc_url( add_query_arg( 'group_session_id', absint( $navigation['next']->id ), self::get_block_url( $block->id ) ) ); ?>"><?php echo esc_html__( 'Next session', 'tutorhelper-group-bookings' ); ?> &rarr;</a><?php endif; ?>
		</nav>
		<?php
	}

	/** Return adjacent sessions in the block's generated order. */
	private static function get_session_navigation( $block_id, $session_id ) {
		$sessions = TutorHelper_Group_Sessions::get_for_block( $block_id );
		$result = array( 'previous' => null, 'next' => null );
		foreach ( $sessions as $index => $candidate ) {
			if ( absint( $candidate->id ) !== absint( $session_id ) ) {
				continue;
			}
			$result['previous'] = 0 < $index ? $sessions[ $index - 1 ] : null;
			$result['next'] = isset( $sessions[ $index + 1 ] ) ? $sessions[ $index + 1 ] : null;
			break;
		}
		return $result;
	}

	/** Format one session in its owning block timezone. */
	private static function format_session_date( $session, $block ) {
		try {
			$date = new DateTimeImmutable( $session->booking_start, new DateTimeZone( 'UTC' ) );
			$timezone = new DateTimeZone( sanitize_text_field( $block->timezone ) );
			return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $date->getTimestamp(), $timezone );
		} catch ( Exception $exception ) {
			return (string) $session->booking_start;
		}
	}

	/** Prefer the immutable booking student-name snapshot when the user is unavailable. */
	private static function get_booking_student_name( $booking ) {
		return ! empty( $booking->student_name ) ? (string) $booking->student_name : __( 'Unknown student', 'tutorhelper-group-bookings' );
	}

	/** Return a readable Core child-booking status. */
	private static function get_booking_status_label( $status ) {
		return ucfirst( str_replace( '_', ' ', sanitize_key( $status ) ) );
	}

	/** Return a Group Block detail URL. */
	private static function get_block_url( $block_id ) {
		return add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
				'group_block_id' => absint( $block_id ),
			),
			admin_url( 'admin.php' )
		);
	}
}
