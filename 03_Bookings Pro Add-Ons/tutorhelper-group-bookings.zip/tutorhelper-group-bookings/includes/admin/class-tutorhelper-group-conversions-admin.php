<?php
/**
 * Tutor administration for booking-to-Group Lesson conversion.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the reviewed conversion wizard and handles its protected actions.
 */
final class TutorHelper_Group_Conversions_Admin {

	const PREVIEW_ACTION = 'tutorhelper_group_preview_conversion';
	const EXECUTE_ACTION = 'tutorhelper_group_execute_conversion';
	const TRANSIENT_PREFIX = 'tutorhelper_group_conversion_';

	/** Register protected conversion endpoints. */
	public static function init() {
		add_action( 'admin_post_' . self::PREVIEW_ACTION, array( __CLASS__, 'handle_preview' ) );
		add_action( 'admin_post_' . self::EXECUTE_ACTION, array( __CLASS__, 'handle_execute' ) );
	}

	/** Render the conversion selection or confirmation screen. */
	public static function render_page() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}

		$token = isset( $_GET['conversion_token'] ) && ! is_array( $_GET['conversion_token'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only wizard state.
			? sanitize_text_field( wp_unslash( $_GET['conversion_token'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only wizard state.
			: '';
		$stored = $token ? get_transient( self::TRANSIENT_PREFIX . $token ) : false;

		if ( is_array( $stored ) && absint( $stored['user_id'] ) === get_current_user_id() ) {
			try {
				self::render_confirmation( $token, $stored['preview'] );
			} catch ( Throwable $exception ) {
				TutorHelper_Logger::error(
					'Group booking conversion preview could not be displayed.',
					array(
						'conversion_token_present' => '' !== $token,
						'error_type' => get_class( $exception ),
						'error_message' => $exception->getMessage(),
						'error_file' => wp_basename( $exception->getFile() ),
						'error_line' => absint( $exception->getLine() ),
					)
				);
				echo '<div class="notice notice-error"><p>' . esc_html__( 'The conversion preview could not be displayed. The details have been recorded in Diagnostics.', 'tutorhelper-group-bookings' ) . '</p></div>';
			}
			return;
		}

		self::render_selector();
	}

	/** Render initial source and target selection. */
	private static function render_selector() {
		$bookings = self::get_convertible_bookings( get_current_user_id() );
		$groups = TutorHelper_Pro_Groups::get_all( array( 'active_only' => true ) );
		$booking_types = TutorHelper_Booking_Types::get_active();
		?>
		<section class="tutorhelper-group-lessons">
			<header class="tutorhelper-main-section__header tutorhelper-group-lessons__header">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php echo esc_html__( 'Convert booking to Group Lesson', 'tutorhelper-group-bookings' ); ?></h2>
					<p><?php echo esc_html__( 'Create a new Group Lesson block from an upcoming individual lesson or the remaining compatible part of a recurring series.', 'tutorhelper-group-bookings' ); ?></p>
				</div>
				<a class="button tutorhelper-ui-button tutorhelper-ui-button--secondary tutorhelper-group-conversion__back" href="<?php echo esc_url( self::get_workspace_url() ); ?>"><?php echo esc_html__( 'Back to Group Lessons', 'tutorhelper-group-bookings' ); ?></a>
			</header>
			<section class="tutorhelper-main-section">
				<div class="tutorhelper-main-section__body">
					<?php self::render_notice(); ?>
					<?php if ( empty( $bookings ) || empty( $groups ) || empty( $booking_types ) ) : ?>
						<div class="notice notice-warning inline"><p><?php echo esc_html__( 'You need an active Pro Group, an active Booking Type and an upcoming individual booking before you can create a conversion.', 'tutorhelper-group-bookings' ); ?></p></div>
					<?php else : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-group-block-form tutorhelper-group-conversion-form">
							<input type="hidden" name="action" value="<?php echo esc_attr( self::PREVIEW_ACTION ); ?>" />
							<?php wp_nonce_field( self::PREVIEW_ACTION ); ?>
							<label class="tutorhelper-admin-control">
								<span><?php echo esc_html__( 'Individual booking', 'tutorhelper-group-bookings' ); ?></span>
								<select name="source_booking_id" required>
									<option value=""><?php echo esc_html__( 'Select an upcoming booking', 'tutorhelper-group-bookings' ); ?></option>
									<?php foreach ( $bookings as $booking ) : ?>
										<option value="<?php echo esc_attr( $booking->id ); ?>"><?php echo esc_html( self::get_booking_label( $booking ) ); ?></option>
									<?php endforeach; ?>
								</select>
							</label>
							<fieldset class="tutorhelper-admin-control tutorhelper-group-conversion-form__scope">
								<legend><?php echo esc_html__( 'Convert', 'tutorhelper-group-bookings' ); ?></legend>
								<label class="tutorhelper-group-conversion-form__choice"><input type="radio" name="scope" value="<?php echo esc_attr( TutorHelper_Group_Conversions::SCOPE_SINGLE ); ?>" checked /><span><?php echo esc_html__( 'Only this lesson', 'tutorhelper-group-bookings' ); ?></span></label>
								<label class="tutorhelper-group-conversion-form__choice"><input type="radio" name="scope" value="<?php echo esc_attr( TutorHelper_Group_Conversions::SCOPE_REMAINING_SERIES ); ?>" /><span><?php echo esc_html__( 'This and the remaining recurring lessons', 'tutorhelper-group-bookings' ); ?></span></label>
								<small><?php echo esc_html__( 'The series option is available only for weekly or fortnightly future lessons with matching details. Past, cancelled and edited exceptions remain unchanged.', 'tutorhelper-group-bookings' ); ?></small>
							</fieldset>
							<label class="tutorhelper-admin-control">
								<span><?php echo esc_html__( 'Target Pro Group', 'tutorhelper-group-bookings' ); ?></span>
								<select name="group_id" required>
									<option value=""><?php echo esc_html__( 'Select Group', 'tutorhelper-group-bookings' ); ?></option>
									<?php foreach ( $groups as $group ) : ?>
										<option value="<?php echo esc_attr( $group->id ); ?>"><?php echo esc_html( $group->name ); ?></option>
									<?php endforeach; ?>
								</select>
							</label>
							<label class="tutorhelper-admin-control">
								<span><?php echo esc_html__( 'Group Booking Type', 'tutorhelper-group-bookings' ); ?></span>
								<select name="target_booking_type_id" required>
									<option value=""><?php echo esc_html__( 'Select the Booking Type for this Group Lesson', 'tutorhelper-group-bookings' ); ?></option>
									<?php foreach ( $booking_types as $booking_type ) : ?>
										<option value="<?php echo esc_attr( $booking_type->id ); ?>"><?php echo esc_html( $booking_type->title ); ?></option>
									<?php endforeach; ?>
								</select>
								<small><?php echo esc_html__( 'The Group Booking Type supplies the normal group price. The original individual price is used only to transfer any paid value as account credit.', 'tutorhelper-group-bookings' ); ?></small>
							</label>

							<div class="tutorhelper-group-block-form__grid">
								<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Bookable from', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="bookable_from" /><small><?php echo esc_html__( 'Leave blank to allow bookings immediately.', 'tutorhelper-group-bookings' ); ?></small></label>
								<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Bookable until', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="bookable_until" /><small><?php echo esc_html__( 'Leave blank to keep bookings open until the group is full or closed.', 'tutorhelper-group-bookings' ); ?></small></label>
							</div>
							<div class="tutorhelper-group-block-form__grid">
								<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Minimum enrolment', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="min_enrolments" min="1" value="1" required /></label>
								<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Maximum enrolment', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="max_enrolments" min="1" placeholder="<?php echo esc_attr__( 'Unlimited', 'tutorhelper-group-bookings' ); ?>" /></label>
							</div>
							<label class="tutorhelper-admin-control">
								<span><?php echo esc_html__( 'Pricing', 'tutorhelper-group-bookings' ); ?></span>
								<select name="pricing_basis">
									<option value="booking_type"><?php echo esc_html__( 'Use Group Booking Type price', 'tutorhelper-group-bookings' ); ?></option>
									<option value="per_session"><?php echo esc_html__( 'Set price per lesson', 'tutorhelper-group-bookings' ); ?></option>
									<option value="fixed_block"><?php echo esc_html__( 'Set fixed block price', 'tutorhelper-group-bookings' ); ?></option>
								</select>
							</label>
							<div class="tutorhelper-group-block-form__grid">
								<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Price per lesson', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="price_per_session_minor_units" min="0" value="0" /><small><?php echo esc_html__( 'Used only for a custom per-lesson price.', 'tutorhelper-group-bookings' ); ?></small></label>
								<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Fixed block price', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="fixed_block_price_minor_units" min="0" /><small><?php echo esc_html__( 'Used only for a fixed block price.', 'tutorhelper-group-bookings' ); ?></small></label>
							</div>
							<label class="tutorhelper-admin-control">
								<span><?php echo esc_html__( 'Payment arrangement', 'tutorhelper-group-bookings' ); ?></span>
								<select name="payment_mode">
									<option value="manual"><?php echo esc_html__( 'Invoice / manual payment', 'tutorhelper-group-bookings' ); ?></option>
									<option value="full_upfront"><?php echo esc_html__( 'Full payment upfront', 'tutorhelper-group-bookings' ); ?></option>
									<option value="deposit"><?php echo esc_html__( 'Deposit required', 'tutorhelper-group-bookings' ); ?></option>
								</select>
							</label>
							<div class="tutorhelper-group-block-form__grid">
								<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Deposit type', 'tutorhelper-group-bookings' ); ?></span><select name="deposit_type"><option value="none"><?php echo esc_html__( 'None', 'tutorhelper-group-bookings' ); ?></option><option value="fixed"><?php echo esc_html__( 'Fixed amount', 'tutorhelper-group-bookings' ); ?></option><option value="percentage"><?php echo esc_html__( 'Percentage', 'tutorhelper-group-bookings' ); ?></option></select></label>
								<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Deposit value', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="deposit_value" min="0" value="0" /><small><?php echo esc_html__( 'Required only when a deposit is selected.', 'tutorhelper-group-bookings' ); ?></small></label>
							</div>
							<fieldset class="tutorhelper-admin-control">
								<legend><strong><?php echo esc_html__( 'Student cancellation terms', 'tutorhelper-group-bookings' ); ?></strong></legend>
								<label class="tutorhelper-ui-option-row"><input type="checkbox" name="student_cancellation_allowed" value="1" checked /> <?php echo esc_html__( 'Allow students to cancel their place on the whole block', 'tutorhelper-group-bookings' ); ?></label>
								<label><span><?php echo esc_html__( 'Minimum notice (hours before first session)', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="cancellation_notice_hours" min="0" value="24" /></label>
								<label><span><?php echo esc_html__( 'Deposit treatment', 'tutorhelper-group-bookings' ); ?></span><select name="deposit_refundable"><option value="yes"><?php echo esc_html__( 'Refundable as account credit', 'tutorhelper-group-bookings' ); ?></option><option value="no"><?php echo esc_html__( 'Non-refundable', 'tutorhelper-group-bookings' ); ?></option></select></label>
								<label><span><?php echo esc_html__( 'Terms shown to students', 'tutorhelper-group-bookings' ); ?></span><textarea name="cancellation_terms" rows="4" placeholder="<?php echo esc_attr__( 'Explain any additional cancellation conditions.', 'tutorhelper-group-bookings' ); ?>"></textarea></label>
							</fieldset>
							<p><button type="submit" class="button tutorhelper-ui-button tutorhelper-ui-button--primary tutorhelper-group-conversion__confirm"><?php echo esc_html__( 'Build conversion preview', 'tutorhelper-group-bookings' ); ?></button></p>
						</form>
					<?php endif; ?>
				</div>
			</section>
		</section>
		<?php
	}

	/** Render a server-validated conversion confirmation. */
	private static function render_confirmation( $token, $preview ) {
		$excluded_session_dates = TutorHelper_Group_Schedule_Planner::normalise_dates(
			isset( $preview['block_data']['excluded_session_dates'] )
				? $preview['block_data']['excluded_session_dates']
				: array()
		);
		$student = get_user_by( 'id', $preview['student_user_id'] );
		?>
		<section class="tutorhelper-group-lessons">
			<?php self::render_notice(); ?>
			<header class="tutorhelper-main-section__header tutorhelper-group-lessons__header">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php echo esc_html__( 'Review Group Lesson conversion', 'tutorhelper-group-bookings' ); ?></h2>
					<p><?php echo esc_html__( 'Nothing has changed yet. Confirm only when the replacement sessions and financial transfer are correct.', 'tutorhelper-group-bookings' ); ?></p>
				</div>
				<a class="button tutorhelper-ui-button tutorhelper-ui-button--secondary tutorhelper-group-conversion__back" href="<?php echo esc_url( self::get_workspace_url( array( 'group_view' => 'convert' ) ) ); ?>"><?php echo esc_html__( 'Choose another booking', 'tutorhelper-group-bookings' ); ?></a>
			</header>
			<section class="tutorhelper-main-section">
				<div class="tutorhelper-main-section__body">
					<h3><?php echo esc_html__( 'Replacement Group Lesson', 'tutorhelper-group-bookings' ); ?></h3>
					<p><strong><?php echo esc_html( $preview['block_data']['title'] ); ?></strong> — <?php echo esc_html( $preview['group_name'] ); ?></p>
					<p><?php echo esc_html( sprintf( __( 'Group Booking Type: %s.', 'tutorhelper-group-bookings' ), $preview['target_booking_type_title'] ) ); ?></p>
					<p><?php echo esc_html( sprintf( __( 'First enrolment: %s.', 'tutorhelper-group-bookings' ), $student instanceof WP_User ? $student->display_name : __( 'Student unavailable', 'tutorhelper-group-bookings' ) ) ); ?></p>
					<?php if ( empty( $preview['student_is_member'] ) ) : ?><div class="notice notice-info inline"><p><?php echo esc_html__( 'The student will be added to the selected Pro Group as part of the conversion.', 'tutorhelper-group-bookings' ); ?></p></div><?php endif; ?>
					<h3><?php echo esc_html__( 'New Group sessions', 'tutorhelper-group-bookings' ); ?></h3>
					<p><?php echo esc_html( sprintf( _n( '%d session will be created from the original schedule.', '%d sessions will be created from the original schedule.', count( TutorHelper_Group_Schedule_Planner::get_included_dates( $preview['session_preview'] ) ), 'tutorhelper-group-bookings' ), count( TutorHelper_Group_Schedule_Planner::get_included_dates( $preview['session_preview'] ) ) ) ); ?></p>
					<table class="widefat striped"><thead><tr><th><?php echo esc_html__( 'Date', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Outcome', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Notes', 'tutorhelper-group-bookings' ); ?></th></tr></thead><tbody>
						<?php foreach ( $preview['session_preview'] as $candidate ) : ?>
							<tr><td><?php echo esc_html( $candidate['label'] ); ?></td><td><?php echo esc_html( ucfirst( $candidate['state'] ) ); ?></td><td><?php echo esc_html( ! empty( $candidate['reason'] ) ? $candidate['reason'] : __( 'Will be created.', 'tutorhelper-group-bookings' ) ); ?></td></tr>
						<?php endforeach; ?>
					</tbody></table>
					<h3><?php echo esc_html__( 'Sessions and source bookings to retire', 'tutorhelper-group-bookings' ); ?></h3>
					<table class="widefat striped"><thead><tr><th><?php echo esc_html__( 'Source booking', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Saved price', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Paid value transferred', 'tutorhelper-group-bookings' ); ?></th></tr></thead><tbody>
						<?php foreach ( $preview['source_bookings'] as $booking ) : ?><tr><td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $booking['booking_start'] . ' UTC' ) ) ); ?></td><td><?php echo esc_html( self::format_money( $booking['price_minor_units'], $preview['block_data']['currency'] ) ); ?></td><td><?php echo esc_html( self::format_money( $booking['net_paid_minor_units'], $preview['block_data']['currency'] ) ); ?></td></tr><?php endforeach; ?>
					</tbody></table>
					<?php if ( ! empty( $excluded_session_dates ) ) : ?><div class="notice notice-info inline"><p><?php echo esc_html( sprintf( _n( '%d future date is excluded because its original booking is cancelled or has different lesson details.', '%d future dates are excluded because their original bookings are cancelled or have different lesson details.', count( $excluded_session_dates ), 'tutorhelper-group-bookings' ), count( $excluded_session_dates ) ) ); ?></p></div><?php endif; ?>
					<p><?php echo esc_html( sprintf( __( 'New Group enrolment price: %1$s. Credit applied: %2$s.', 'tutorhelper-group-bookings' ), self::format_money( $preview['price_total_minor_units'], $preview['block_data']['currency'] ), self::format_money( $preview['credit_to_apply_minor_units'], $preview['block_data']['currency'] ) ) ); ?></p>
					<?php if ( $preview['credit_remaining_minor_units'] > 0 ) : ?><div class="notice notice-info inline"><p><?php echo esc_html( sprintf( __( '%s remains as account credit after the new Group enrolment has been settled.', 'tutorhelper-group-bookings' ), self::format_money( $preview['credit_remaining_minor_units'], $preview['block_data']['currency'] ) ) ); ?></p></div><?php endif; ?>
					<div class="notice notice-info inline"><p><?php echo esc_html( $preview['calendar_meet_note'] ); ?></p></div>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::EXECUTE_ACTION ); ?>" />
						<input type="hidden" name="conversion_token" value="<?php echo esc_attr( $token ); ?>" />
						<?php wp_nonce_field( self::EXECUTE_ACTION . '_' . $token ); ?>
						<p><button type="submit" class="button tutorhelper-ui-button tutorhelper-ui-button--primary tutorhelper-group-conversion__confirm" onclick="return window.confirm('<?php echo esc_js( __( 'Create the Group Lesson, transfer the paid value and cancel the selected original booking(s)?', 'tutorhelper-group-bookings' ) ); ?>');"><?php echo esc_html__( 'Confirm conversion', 'tutorhelper-group-bookings' ); ?></button></p>
					</form>
				</div>
			</section>
		</section>
		<?php
	}

	/** Handle server-side preview generation. */
	public static function handle_preview() {
		self::require_capability();
		check_admin_referer( self::PREVIEW_ACTION );

		$source_booking_id = isset( $_POST['source_booking_id'] ) ? absint( wp_unslash( $_POST['source_booking_id'] ) ) : 0;
		$scope = isset( $_POST['scope'] ) && ! is_array( $_POST['scope'] ) ? sanitize_key( wp_unslash( $_POST['scope'] ) ) : '';
		$group_id = isset( $_POST['group_id'] ) ? absint( wp_unslash( $_POST['group_id'] ) ) : 0;
		$target_booking_type_id = isset( $_POST['target_booking_type_id'] ) ? absint( wp_unslash( $_POST['target_booking_type_id'] ) ) : 0;
		$block_options = self::get_block_options_from_request();

		try {
			$preview = TutorHelper_Group_Conversions::build_preview( $source_booking_id, $scope, $group_id, get_current_user_id(), $target_booking_type_id, $block_options );
		} catch ( Throwable $exception ) {
			TutorHelper_Logger::error(
				'Group booking conversion preview encountered an unexpected error.',
				array(
					'source_booking_id' => $source_booking_id,
					'scope' => $scope,
					'group_id' => $group_id,
					'target_booking_type_id' => $target_booking_type_id,
					'error_type' => get_class( $exception ),
					'error_message' => $exception->getMessage(),
					'error_file' => wp_basename( $exception->getFile() ),
					'error_line' => absint( $exception->getLine() ),
				)
			);
			self::redirect( array( 'group_conversion_notice' => 'error', 'group_conversion_message' => rawurlencode( __( 'The conversion preview could not be generated. The details have been recorded in Diagnostics.', 'tutorhelper-group-bookings' ) ) ) );
		}

		if ( is_wp_error( $preview ) ) {
			TutorHelper_Logger::error(
				'Group booking conversion preview failed.',
				array(
					'source_booking_id' => $source_booking_id,
					'scope' => $scope,
					'group_id' => $group_id,
					'target_booking_type_id' => $target_booking_type_id,
					'error_code' => $preview->get_error_code(),
					'error_message' => $preview->get_error_message(),
				)
			);
			self::redirect( array( 'group_conversion_notice' => 'error', 'group_conversion_message' => rawurlencode( $preview->get_error_message() ) ) );
		}

		$token = wp_generate_uuid4();
		set_transient( self::TRANSIENT_PREFIX . $token, array( 'user_id' => get_current_user_id(), 'source_booking_id' => $source_booking_id, 'scope' => $scope, 'group_id' => $group_id, 'target_booking_type_id' => $target_booking_type_id, 'block_options' => $preview['conversion_options'], 'preview' => $preview ), 15 * MINUTE_IN_SECONDS );
		self::redirect( array( 'conversion_token' => $token ) );
	}

	/** Handle explicit conversion confirmation. */
	public static function handle_execute() {
		self::require_capability();

		$token = isset( $_POST['conversion_token'] ) && ! is_array( $_POST['conversion_token'] )
			? sanitize_text_field( wp_unslash( $_POST['conversion_token'] ) )
			: '';
		$stored = $token ? get_transient( self::TRANSIENT_PREFIX . $token ) : false;
		check_admin_referer( self::EXECUTE_ACTION . '_' . $token );

		if ( ! is_array( $stored ) || absint( $stored['user_id'] ) !== get_current_user_id() ) {
			TutorHelper_Logger::error(
				'Group booking conversion confirmation could not load its preview.',
				array(
					'conversion_token_present' => '' !== $token,
					'current_user_id' => get_current_user_id(),
				)
			);
			self::redirect( array( 'group_conversion_notice' => 'error', 'group_conversion_message' => rawurlencode( __( 'This conversion preview has expired. Please build it again.', 'tutorhelper-group-bookings' ) ) ) );
		}

		$target_booking_type_id = isset( $stored['target_booking_type_id'] )
			? absint( $stored['target_booking_type_id'] )
			: 0;

		try {
			$result = TutorHelper_Group_Conversions::convert( $stored['source_booking_id'], $stored['scope'], $stored['group_id'], get_current_user_id(), $target_booking_type_id, isset( $stored['block_options'] ) && is_array( $stored['block_options'] ) ? $stored['block_options'] : array() );
		} catch ( Throwable $exception ) {
			TutorHelper_Logger::error(
				'Group booking conversion confirmation encountered an unexpected error.',
				array(
					'source_booking_id' => absint( $stored['source_booking_id'] ),
					'scope' => sanitize_key( $stored['scope'] ),
					'group_id' => absint( $stored['group_id'] ),
					'error_type' => get_class( $exception ),
					'error_message' => $exception->getMessage(),
					'error_file' => wp_basename( $exception->getFile() ),
					'error_line' => absint( $exception->getLine() ),
				)
			);
			self::redirect( array( 'group_conversion_notice' => 'error', 'group_conversion_message' => rawurlencode( __( 'The conversion could not be completed. The details have been recorded in Diagnostics.', 'tutorhelper-group-bookings' ) ) ) );
		}

		if ( is_wp_error( $result ) ) {
			TutorHelper_Logger::error(
				'Group booking conversion confirmation failed.',
				array(
					'source_booking_id' => absint( $stored['source_booking_id'] ),
					'scope' => sanitize_key( $stored['scope'] ),
					'group_id' => absint( $stored['group_id'] ),
					'error_code' => $result->get_error_code(),
					'error_message' => $result->get_error_message(),
				)
			);
			self::redirect( array( 'group_conversion_notice' => 'error', 'group_conversion_message' => rawurlencode( $result->get_error_message() ) ) );
		}

		delete_transient( self::TRANSIENT_PREFIX . $token );
		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
					'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
					'group_block_id' => absint( $result['block_id'] ),
					'group_conversion_notice' => 'success',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/** Return tutor-owned, future, non-Group source bookings. */
	private static function get_convertible_bookings( $tutor_user_id ) {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT booking.* FROM %i AS booking LEFT JOIN %i AS group_booking ON group_booking.booking_id = booking.id WHERE booking.tutor_user_id = %d AND booking.status != %s AND booking.booking_start > %s AND group_booking.booking_id IS NULL ORDER BY booking.booking_start ASC LIMIT 200',
				TutorHelper_Booking_Records::get_table_name(),
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				absint( $tutor_user_id ),
				TutorHelper_Booking_Records::STATUS_CANCELLED,
				current_time( 'mysql', true )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Tutor must select from the current eligible booking set.

		return is_array( $rows ) ? $rows : array();
	}

	/** Render a conversion return notice. */
	private static function render_notice() {
		$notice = isset( $_GET['group_conversion_notice'] ) && ! is_array( $_GET['group_conversion_notice'] ) ? sanitize_key( wp_unslash( $_GET['group_conversion_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only return state.
		if ( 'success' === $notice ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'The Group Lesson was created, the paid value was transferred and the original booking(s) were retired.', 'tutorhelper-group-bookings' ) . '</p></div>';
			return;
		}
		if ( 'error' === $notice ) {
			$message = isset( $_GET['group_conversion_message'] ) && ! is_array( $_GET['group_conversion_message'] ) ? sanitize_text_field( rawurldecode( wp_unslash( $_GET['group_conversion_message'] ) ) ) : __( 'The conversion could not be completed.', 'tutorhelper-group-bookings' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only return state.
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
		}
	}


	/**
	 * Extract supported Group Block controls from a nonce-protected request.
	 *
	 * @return array
	 */
	private static function get_block_options_from_request() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called only from handle_preview() after its conversion nonce is verified.
		$request = wp_unslash( $_POST );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$options = array();
		$fields = array(
			'bookable_from',
			'bookable_until',
			'min_enrolments',
			'max_enrolments',
			'pricing_basis',
			'price_per_session_minor_units',
			'fixed_block_price_minor_units',
			'deposit_type',
			'deposit_value',
			'payment_mode',
			'cancellation_notice_hours',
			'deposit_refundable',
			'cancellation_terms',
		);

		foreach ( $fields as $field ) {
			if ( isset( $request[ $field ] ) && ! is_array( $request[ $field ] ) ) {
				$options[ $field ] = $request[ $field ];
			}
		}

		$options['student_cancellation_allowed'] = ! empty( $request['student_cancellation_allowed'] ) && ! is_array( $request['student_cancellation_allowed'] )
			? 1
			: 0;

		return $options;
	}

	/** Enforce tutor capability. */
	private static function require_capability() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to convert bookings into Group Lessons.', 'tutorhelper-group-bookings' ) );
		}
	}

	/** Redirect back to this wizard. */
	private static function redirect( $args ) {
		wp_safe_redirect( self::get_workspace_url( array_merge( array( 'group_view' => 'convert' ), $args ) ) );
		exit;
	}

	/** Return the Group Lessons workspace URL. */
	private static function get_workspace_url( $args = array() ) {
		$args = array_merge( array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY ), $args );
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/** Build an accessible source booking label. */
	private static function get_booking_label( $booking ) {
		$student = get_user_by( 'id', $booking->student_user_id );
		$booking_type = TutorHelper_Booking_Types::get_by_id( $booking->booking_type_id );
		return sprintf( '%1$s — %2$s — %3$s', $student instanceof WP_User ? $student->display_name : __( 'Unknown student', 'tutorhelper-group-bookings' ), $booking_type ? $booking_type->title : __( 'Lesson', 'tutorhelper-group-bookings' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $booking->booking_start . ' UTC' ) ) );
	}

	/** Format minor units for the review. */
	private static function format_money( $amount, $currency ) {
		$currency = strtoupper( sanitize_text_field( $currency ) );
		return ( 'GBP' === $currency ? '£' : $currency . ' ' ) . number_format_i18n( absint( $amount ) / 100, 2 );
	}
}
