<?php
/**
 * Group Lesson enrolment administration.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds student enrolment management to Group Lesson block detail views.
 */
final class TutorHelper_Group_Enrolments_Admin {

	const ENROL_ACTION = 'tutorhelper_group_enrol_student';
	const RECORD_PAYMENT_ACTION = 'tutorhelper_group_record_manual_payment';
	const REMOVE_REMAINDER_ACTION = 'tutorhelper_group_remove_remainder';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'tutorhelper_booking_hub_render_tab',
			array( __CLASS__, 'render_panel' ),
			30,
			2
		);

		add_action(
			'admin_post_' . self::ENROL_ACTION,
			array( __CLASS__, 'handle_enrol_student' )
		);

		add_action(
			'admin_post_' . self::RECORD_PAYMENT_ACTION,
			array( __CLASS__, 'handle_record_payment' )
		);

		add_action( 'admin_post_' . self::REMOVE_REMAINDER_ACTION, array( __CLASS__, 'handle_remove_remainder' ) );
	}

	/**
	 * Render enrolment management underneath the block detail screen.
	 *
	 * @param string $selected_tab Selected Booking Hub tab.
	 * @param array  $active_tab Active tab definition.
	 * @return void
	 */
	public static function render_panel( $selected_tab, $active_tab ) {
		unset( $active_tab );

		if (
			TutorHelper_Group_Bookings_Admin::TAB_KEY !== $selected_tab
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$block_id = isset( $_GET['group_block_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin navigation state.
			? absint( $_GET['group_block_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin navigation state.
			: 0;

		if ( ! $block_id ) {
			return;
		}

		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			return;
		}

		$reconciliation_errors = TutorHelper_Group_Payments::reconcile_block( $block_id );
		if ( ! empty( $reconciliation_errors ) && class_exists( 'TutorHelper_Logger' ) ) {
			foreach ( $reconciliation_errors as $enrolment_id => $error ) {
				TutorHelper_Logger::warning(
					'Group Lesson payment reconciliation failed.',
					array(
						'block_id' => $block_id,
						'enrolment_id' => absint( $enrolment_id ),
						'error_code' => $error->get_error_code(),
					)
				);
			}
		}

		$enrolments = TutorHelper_Group_Enrolments::get_for_block( $block_id );
		$group_students = TutorHelper_Pro_Groups::get_group_students( $block->group_id );
		$enrolled_ids = array_map(
			'absint',
			wp_list_pluck( $enrolments, 'student_user_id' )
		);
		$available_students = array();

		foreach ( $group_students as $student ) {
			if ( ! in_array( absint( $student->ID ), $enrolled_ids, true ) ) {
				$available_students[] = $student;
			}
		}

		$reserved = TutorHelper_Group_Enrolments::count_reserved_places( $block_id );
		$secured = TutorHelper_Group_Enrolments::count_secured( $block_id );
		$maximum = null !== $block->max_enrolments ? absint( $block->max_enrolments ) : 0;
		$is_full = $maximum && $reserved >= $maximum;

		self::render_feedback();
		?>
		<section class="tutorhelper-main-section tutorhelper-group-enrolments-admin">
			<header class="tutorhelper-main-section__header">
				<div class="tutorhelper-main-section__header-content">
					<h3><?php echo esc_html__( 'Student enrolments', 'tutorhelper-group-bookings' ); ?></h3>
					<p>
						<?php
						printf(
							/* translators: 1: secured enrolments, 2: minimum, 3: reserved places, 4: maximum. */
							esc_html__( '%1$d secured / %2$d minimum · %3$d places reserved / %4$s maximum', 'tutorhelper-group-bookings' ),
							absint( $secured ),
							absint( $block->min_enrolments ),
							absint( $reserved ),
							$maximum ? esc_html( (string) absint( $maximum ) ) : esc_html__( 'Unlimited', 'tutorhelper-group-bookings' )
						);
						?>
					</p>
				</div>
			</header>

			<div class="tutorhelper-main-section__body tutorhelper-group-enrolments-admin__body">
				<div class="tutorhelper-group-enrolments-admin__layout">
					<div>
						<h4><?php echo esc_html__( 'Enrolled students', 'tutorhelper-group-bookings' ); ?></h4>
						<?php self::render_enrolments_table( $enrolments ); ?>
					</div>

					<aside class="tutorhelper-group-enrolments-admin__add">
						<h4><?php echo esc_html__( 'Add students to block', 'tutorhelper-group-bookings' ); ?></h4>
						<?php if ( $is_full ) : ?>
							<p class="tutorhelper-group-enrolments-admin__capacity-message">
								<?php echo esc_html__( 'This lesson block has reached its maximum enrolment.', 'tutorhelper-group-bookings' ); ?>
							</p>
						<?php elseif ( empty( $available_students ) ) : ?>
							<p><?php echo esc_html__( 'All students currently assigned to the linked Pro Group already have an enrolment record.', 'tutorhelper-group-bookings' ); ?></p>
						<?php else : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ENROL_ACTION ); ?>" />
								<input type="hidden" name="block_id" value="<?php echo esc_attr( $block_id ); ?>" />
								<?php wp_nonce_field( self::ENROL_ACTION . '_' . $block_id ); ?>

								<fieldset
									class="tutorhelper-group-student-selector"
									data-group-student-selector
									data-max-selections="<?php echo esc_attr( $maximum ? max( 0, $maximum - $reserved ) : 0 ); ?>"
								>
									<legend><?php echo esc_html__( 'Students', 'tutorhelper-group-bookings' ); ?></legend>
									<div class="tutorhelper-group-student-selector__controls">
										<button type="button" class="button tutorhelper-ui-button tutorhelper-ui-button--secondary button-small" data-group-select-all><?php echo esc_html__( 'Select all', 'tutorhelper-group-bookings' ); ?></button>
										<button type="button" class="button tutorhelper-ui-button tutorhelper-ui-button--secondary button-small" data-group-clear-all><?php echo esc_html__( 'Clear', 'tutorhelper-group-bookings' ); ?></button>
										<span data-group-selection-count aria-live="polite"></span>
									</div>
									<div class="tutorhelper-group-student-selector__list">
										<?php foreach ( $available_students as $student ) : ?>
											<label>
												<input type="checkbox" name="student_user_ids[]" value="<?php echo esc_attr( $student->ID ); ?>" />
												<span><?php echo esc_html( $student->display_name ); ?></span>
											</label>
										<?php endforeach; ?>
									</div>
								</fieldset>

								<p class="description">
									<?php echo esc_html__( 'Each selected student receives one individual TutorHelper booking for every generated session in this block.', 'tutorhelper-group-bookings' ); ?>
								</p>

								<button type="submit" class="button tutorhelper-ui-button tutorhelper-ui-button--primary tutorhelper-admin-button tutorhelper-admin-button--primary">
									<?php echo esc_html__( 'Enrol selected students', 'tutorhelper-group-bookings' ); ?>
								</button>
							</form>
						<?php endif; ?>
					</aside>
				</div>
			</div>
		</section>
		<?php
	}

	/**
	 * Render enrolments and linked booking counts.
	 *
	 * @param array $enrolments Enrolment records.
	 * @return void
	 */
	private static function render_enrolments_table( $enrolments ) {
		if ( empty( $enrolments ) ) {
			?>
			<div class="tutorhelper-group-enrolments-admin__empty">
				<p><?php echo esc_html__( 'No students have been enrolled in this lesson block yet.', 'tutorhelper-group-bookings' ); ?></p>
			</div>
			<?php
			return;
		}
		?>
		<div class="tutorhelper-group-lessons__table-wrap">
			<table class="widefat striped tutorhelper-group-lessons__table">
				<thead>
					<tr>
						<th><?php echo esc_html__( 'Student', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Enrolment', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Bookings', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Agreed block price', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Payment', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Record payment', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Remaining sessions', 'tutorhelper-group-bookings' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $enrolments as $enrolment ) : ?>
						<?php
						$student = get_user_by( 'id', $enrolment->student_user_id );
						$bookings = TutorHelper_Group_Enrolment_Bookings::get_for_enrolment( $enrolment->id );
						$payment = TutorHelper_Group_Payments::get_summary( $enrolment );
						?>
						<tr>
							<td><strong><?php echo esc_html( $student ? $student->display_name : __( 'Student unavailable', 'tutorhelper-group-bookings' ) ); ?></strong></td>
							<td><span class="tutorhelper-group-status is-<?php echo esc_attr( sanitize_key( $enrolment->status ) ); ?>"><?php echo esc_html( self::get_enrolment_label( $enrolment->status ) ); ?></span></td>
							<td><?php echo esc_html( count( $bookings ) ); ?></td>
							<td><?php echo esc_html( self::format_money( $enrolment->agreed_price_minor_units, $enrolment->currency ) ); ?></td>
							<td>
								<strong><?php echo esc_html( self::get_payment_label( $payment['payment_status'] ) ); ?></strong><br />
								<span><?php
								/* translators: 1: Amount paid, 2: Remaining balance. */
								echo esc_html( sprintf( __( '%1$s paid · %2$s remaining', 'tutorhelper-group-bookings' ), self::format_money( $payment['net_paid_minor_units'], $enrolment->currency ), self::format_money( $payment['balance_minor_units'], $enrolment->currency ) ) ); ?></span>
							</td>
							<td>
								<?php if ( $payment['balance_minor_units'] > 0 && TutorHelper_Group_Enrolments::STATUS_CANCELLED !== sanitize_key( $enrolment->status ) ) : ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-group-payment-form">
										<input type="hidden" name="action" value="<?php echo esc_attr( self::RECORD_PAYMENT_ACTION ); ?>" />
										<input type="hidden" name="block_id" value="<?php echo esc_attr( $enrolment->block_id ); ?>" />
										<input type="hidden" name="enrolment_id" value="<?php echo esc_attr( $enrolment->id ); ?>" />
										<?php wp_nonce_field( self::RECORD_PAYMENT_ACTION . '_' . absint( $enrolment->id ) ); ?>
										<label><span class="screen-reader-text"><?php echo esc_html__( 'Amount received', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="amount" min="0.01" step="0.01" max="<?php echo esc_attr( number_format( $payment['balance_minor_units'] / 100, 2, '.', '' ) ); ?>" placeholder="<?php echo esc_attr__( 'Amount', 'tutorhelper-group-bookings' ); ?>" required /></label>
										<label><span class="screen-reader-text"><?php echo esc_html__( 'Payment type', 'tutorhelper-group-bookings' ); ?></span><select name="payment_type"><option value="payment"><?php echo esc_html__( 'Payment', 'tutorhelper-group-bookings' ); ?></option><option value="deposit"><?php echo esc_html__( 'Deposit', 'tutorhelper-group-bookings' ); ?></option></select></label>
										<label><span class="screen-reader-text"><?php echo esc_html__( 'Payment date', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="payment_date" value="<?php echo esc_attr( wp_date( 'Y-m-d' ) ); ?>" required /></label>
										<label><span class="screen-reader-text"><?php echo esc_html__( 'Reference', 'tutorhelper-group-bookings' ); ?></span><input type="text" name="reference" placeholder="<?php echo esc_attr__( 'Invoice/reference', 'tutorhelper-group-bookings' ); ?>" /></label>
										<button type="submit" class="button"><?php echo esc_html__( 'Record', 'tutorhelper-group-bookings' ); ?></button>
									</form>
								<?php else : ?>
									<span aria-hidden="true">—</span><span class="screen-reader-text"><?php echo esc_html__( 'No payment is outstanding.', 'tutorhelper-group-bookings' ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( ! empty( $enrolment->remainder_removed_at ) ) : ?>
									<span><?php echo esc_html__( 'Removed from remaining sessions', 'tutorhelper-group-bookings' ); ?></span>
								<?php elseif ( TutorHelper_Group_Enrolments::STATUS_CANCELLED !== sanitize_key( $enrolment->status ) ) : ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return window.confirm('<?php echo esc_js( __( 'Remove this student from all remaining Group Lesson sessions? Their past lessons will remain unchanged.', 'tutorhelper-group-bookings' ) ); ?>');">
										<input type="hidden" name="action" value="<?php echo esc_attr( self::REMOVE_REMAINDER_ACTION ); ?>" />
										<input type="hidden" name="block_id" value="<?php echo esc_attr( $enrolment->block_id ); ?>" />
										<input type="hidden" name="enrolment_id" value="<?php echo esc_attr( $enrolment->id ); ?>" />
										<?php wp_nonce_field( self::REMOVE_REMAINDER_ACTION . '_' . absint( $enrolment->id ) ); ?>
										<label class="screen-reader-text"><span><?php echo esc_html__( 'Reason', 'tutorhelper-group-bookings' ); ?></span><input type="text" name="reason" /></label>
										<button type="submit" class="button"><?php echo esc_html__( 'Remove from remainder', 'tutorhelper-group-bookings' ); ?></button>
									</form>
								<?php else : ?><span aria-hidden="true">—</span><?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Handle adding a student to a block.
	 *
	 * @return void
	 */
	public static function handle_enrol_student() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Group Lesson enrolments.', 'tutorhelper-group-bookings' ) );
		}

		$block_id = isset( $_POST['block_id'] ) && ! is_array( $_POST['block_id'] )
			? absint( wp_unslash( $_POST['block_id'] ) )
			: 0;

		check_admin_referer( self::ENROL_ACTION . '_' . $block_id );

		$student_user_ids = array();
		if ( isset( $_POST['student_user_ids'] ) && is_array( $_POST['student_user_ids'] ) ) {
			$student_user_ids = array_map( 'absint', wp_unslash( $_POST['student_user_ids'] ) );
		} elseif ( isset( $_POST['student_user_id'] ) && ! is_array( $_POST['student_user_id'] ) ) {
			$student_user_ids = array( absint( wp_unslash( $_POST['student_user_id'] ) ) );
		}
		$student_user_ids = array_values( array_unique( array_filter( $student_user_ids ) ) );

		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		$maximum = $block && null !== $block->max_enrolments ? absint( $block->max_enrolments ) : 0;
		$available_places = $maximum ? max( 0, $maximum - TutorHelper_Group_Enrolments::count_reserved_places( $block_id ) ) : count( $student_user_ids );
		$results = array();
		$errors = array();

		if ( empty( $student_user_ids ) ) {
			$errors[] = __( 'Select at least one student to enrol.', 'tutorhelper-group-bookings' );
		} elseif ( $maximum && count( $student_user_ids ) > $available_places ) {
			$errors[] = sprintf(
				/* translators: %d: number of places currently available. */
				_n( 'Only %d place is currently available in this block.', 'Only %d places are currently available in this block.', $available_places, 'tutorhelper-group-bookings' ),
				$available_places
			);
		} else {
			foreach ( $student_user_ids as $student_user_id ) {
				$result = TutorHelper_Group_Enrolments::enrol_student( $block_id, $student_user_id );
				if ( is_wp_error( $result ) ) {
					$student = get_user_by( 'id', $student_user_id );
					$errors[] = sprintf(
						/* translators: 1: student name, 2: enrolment error. */
						__( '%1$s: %2$s', 'tutorhelper-group-bookings' ),
						$student instanceof WP_User ? $student->display_name : __( 'Unknown student', 'tutorhelper-group-bookings' ),
						$result->get_error_message()
					);
				} else {
					$results[] = absint( $result );
				}
			}
		}

		$args = array(
			'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
			'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
			'group_block_id' => $block_id,
		);

		if ( ! empty( $errors ) ) {
			$args['group_enrol_notice'] = empty( $results ) ? 'error' : 'partial';
			$args['group_enrol_message'] = rawurlencode( implode( ' ', $errors ) );
			if ( ! empty( $results ) ) {
				$args['group_enrol_count'] = count( $results );
			}
		} else {
			$args['group_enrol_notice'] = 'added';
			$args['group_enrol_count'] = count( $results );
		}

		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}



	/**
	 * Remove an enrolled student from their remaining scheduled sessions.
	 *
	 * @return void
	 */
	public static function handle_remove_remainder() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Group Lesson enrolments.', 'tutorhelper-group-bookings' ) );
		}
		$enrolment_id = isset( $_POST['enrolment_id'] ) ? absint( wp_unslash( $_POST['enrolment_id'] ) ) : 0;
		$block_id = isset( $_POST['block_id'] ) ? absint( wp_unslash( $_POST['block_id'] ) ) : 0;
		check_admin_referer( self::REMOVE_REMAINDER_ACTION . '_' . $enrolment_id );
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		$result = ! $enrolment || absint( $enrolment->block_id ) !== $block_id
			? new WP_Error( 'tutorhelper_group_remainder_enrolment_invalid', __( 'The Group Lesson enrolment could not be verified.', 'tutorhelper-group-bookings' ) )
			: TutorHelper_Group_Enrolment_Removal::remove_from_remainder( $enrolment_id, isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : '', get_current_user_id() );
		$args = array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY, 'group_block_id' => $block_id );
		if ( is_wp_error( $result ) ) {
			$args['group_enrol_notice'] = 'remainder_error';
			$args['group_enrol_message'] = rawurlencode( $result->get_error_message() );
		} else {
			$args['group_enrol_notice'] = 'remainder_removed';
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}


	/**
	 * Record a manual or invoice payment against an enrolment.
	 *
	 * @return void
	 */
	public static function handle_record_payment() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to record Group Lesson payments.', 'tutorhelper-group-bookings' ) );
		}

		$enrolment_id = isset( $_POST['enrolment_id'] ) && ! is_array( $_POST['enrolment_id'] )
			? absint( wp_unslash( $_POST['enrolment_id'] ) )
			: 0;
		$block_id = isset( $_POST['block_id'] ) && ! is_array( $_POST['block_id'] )
			? absint( wp_unslash( $_POST['block_id'] ) )
			: 0;

		check_admin_referer( self::RECORD_PAYMENT_ACTION . '_' . $enrolment_id );

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if ( ! $enrolment || absint( $enrolment->block_id ) !== $block_id ) {
			$result = new WP_Error(
				'tutorhelper_group_payment_enrolment_invalid',
				__( 'The Group Lesson enrolment could not be verified.', 'tutorhelper-group-bookings' )
			);
		} else {
			$amount_raw = isset( $_POST['amount'] ) && ! is_array( $_POST['amount'] )
				? sanitize_text_field( wp_unslash( $_POST['amount'] ) )
				: '';
			$currency = ! empty( $enrolment->currency )
				? strtoupper( sanitize_text_field( $enrolment->currency ) )
				: TutorHelper_Currency::get_currency();
			$amount = TutorHelper_Currency::major_to_minor_units( $amount_raw, $currency );
			$payment_type = isset( $_POST['payment_type'] ) && ! is_array( $_POST['payment_type'] )
				? sanitize_key( wp_unslash( $_POST['payment_type'] ) )
				: TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT;
			$payment_date = isset( $_POST['payment_date'] ) && ! is_array( $_POST['payment_date'] )
				? sanitize_text_field( wp_unslash( $_POST['payment_date'] ) )
				: '';
			$reference = isset( $_POST['reference'] ) && ! is_array( $_POST['reference'] )
				? sanitize_text_field( wp_unslash( $_POST['reference'] ) )
				: '';

			$result = TutorHelper_Group_Payments::record_manual_payment(
				$enrolment_id,
				$amount,
				$payment_type,
				$payment_date,
				$reference
			);
		}

		$args = array(
			'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
			'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY,
			'group_block_id' => $block_id,
		);

		if ( is_wp_error( $result ) ) {
			$args['group_enrol_notice'] = 'payment_error';
			$args['group_enrol_message'] = rawurlencode( $result->get_error_message() );
		} else {
			$args['group_enrol_notice'] = 'payment_recorded';
		}

		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Render enrolment action feedback.
	 *
	 * @return void
	 */
	private static function render_feedback() {
		$payment_return = isset( $_GET['group_payment'] ) && ! is_array( $_GET['group_payment'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Stripe return display state only.
			? sanitize_key( wp_unslash( $_GET['group_payment'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Stripe return display state only.
			: '';

		if ( 'success' === $payment_return ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Stripe has accepted the payment. The verified webhook will update the Group Lesson balance.', 'tutorhelper-group-bookings' ) . '</p></div>';
		} elseif ( 'cancelled' === $payment_return ) {
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'Stripe Checkout was cancelled. No payment has been recorded.', 'tutorhelper-group-bookings' ) . '</p></div>';
		}

		$notice = isset( $_GET['group_enrol_notice'] ) && ! is_array( $_GET['group_enrol_notice'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			? sanitize_key( wp_unslash( $_GET['group_enrol_notice'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			: '';

		if ( 'added' === $notice ) {
			$count = isset( $_GET['group_enrol_count'] ) ? absint( $_GET['group_enrol_count'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			$message = sprintf(
				/* translators: %d: number of students enrolled. */
				_n( '%d student was added and their lesson bookings were created.', '%d students were added and their lesson bookings were created.', $count, 'tutorhelper-group-bookings' ),
				$count
			);
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
			return;
		}

		if ( 'partial' === $notice ) {
			$count = isset( $_GET['group_enrol_count'] ) ? absint( $_GET['group_enrol_count'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			$detail = isset( $_GET['group_enrol_message'] ) && ! is_array( $_GET['group_enrol_message'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
				? sanitize_text_field( rawurldecode( wp_unslash( $_GET['group_enrol_message'] ) ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				: '';
			$summary = sprintf(
				/* translators: %d: number of students enrolled successfully. */
				_n( '%d student was added.', '%d students were added.', $count, 'tutorhelper-group-bookings' ),
				$count
			);
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html( trim( $summary . ' ' . $detail ) ) . '</p></div>';
			return;
		}

		if ( 'payment_recorded' === $notice ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'The Group Lesson payment was recorded and allocated across the student’s lesson bookings.', 'tutorhelper-group-bookings' ) . '</p></div>';
			return;
		}

		if ( 'remainder_removed' === $notice ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'The student has been removed from the remaining Group Lesson sessions.', 'tutorhelper-group-bookings' ) . '</p></div>';
			return;
		}

		if ( ! in_array( $notice, array( 'error', 'payment_error', 'remainder_error' ), true ) ) {
			return;
		}

		$message = isset( $_GET['group_enrol_message'] ) && ! is_array( $_GET['group_enrol_message'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			? sanitize_text_field( rawurldecode( wp_unslash( $_GET['group_enrol_message'] ) ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only feedback state.
			: ( 'payment_error' === $notice
				? __( 'The payment could not be recorded.', 'tutorhelper-group-bookings' )
				: __( 'The student could not be added to the Group Lesson block.', 'tutorhelper-group-bookings' ) );

		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}

	/**
	 * Return an enrolment label.
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	private static function get_enrolment_label( $status ) {
		$labels = array(
			TutorHelper_Group_Enrolments::STATUS_PENDING => __( 'Pending', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT => __( 'Awaiting payment', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Enrolments::STATUS_SECURED => __( 'Secured', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Enrolments::STATUS_CANCELLED => __( 'Cancelled', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Enrolments::STATUS_COMPLETED => __( 'Completed', 'tutorhelper-group-bookings' ),
		);

		$status = sanitize_key( $status );
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
	}


	/**
	 * Return a payment status label.
	 *
	 * @param string $status Payment status.
	 * @return string
	 */
	private static function get_payment_label( $status ) {
		$labels = array(
			TutorHelper_Group_Payments::STATUS_UNPAID => __( 'Unpaid', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Payments::STATUS_PARTIALLY_PAID => __( 'Partially paid', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Payments::STATUS_PAID => __( 'Paid', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Payments::STATUS_PARTIALLY_REFUNDED => __( 'Partially refunded', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Payments::STATUS_REFUNDED => __( 'Refunded', 'tutorhelper-group-bookings' ),
		);

		$status = sanitize_key( $status );
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
	}

	/**
	 * Format the enrolment snapshot price.
	 *
	 * @param int $amount Minor currency units.
	 * @return string
	 */
	private static function format_money( $amount, $currency = '' ) {
		$currency = $currency ? strtoupper( sanitize_text_field( $currency ) ) : ( class_exists( 'TutorHelper_Currency' ) ? TutorHelper_Currency::get_currency() : 'GBP' );
		$symbol = 'GBP' === strtoupper( $currency ) ? '£' : strtoupper( $currency ) . ' ';
		return $symbol . number_format_i18n( absint( $amount ) / 100, 2 );
	}
}
