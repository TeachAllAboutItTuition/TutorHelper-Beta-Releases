<?php
/**
 * TutorHelper Group Bookings Booking Hub administration.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds the Group Lessons workspace to the TutorHelper Booking Hub.
 */
final class TutorHelper_Group_Bookings_Admin {

	const TAB_KEY = 'group-lessons';
	const CREATE_ACTION = 'tutorhelper_group_create_block';
	const PREVIEW_ACTION = 'tutorhelper_group_preview_schedule';
	const EXTEND_ACTION = 'tutorhelper_group_extend_block';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter(
			'tutorhelper_booking_hub_tabs',
			array( __CLASS__, 'register_tab' )
		);

		add_action(
			'tutorhelper_booking_hub_render_tab',
			array( __CLASS__, 'render_tab' ),
			10,
			2
		);

		add_action(
			'admin_post_' . self::CREATE_ACTION,
			array( __CLASS__, 'handle_create_block' )
		);

		add_action( 'wp_ajax_' . self::PREVIEW_ACTION, array( __CLASS__, 'handle_schedule_preview' ) );

		add_action( 'admin_post_' . self::EXTEND_ACTION, array( __CLASS__, 'handle_extend_block' ) );

		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' ),
			40
		);
	}

	/**
	 * Add the Group Lessons tab after Students.
	 *
	 * @param array $tabs Booking Hub tab definitions.
	 * @return array
	 */
	public static function register_tab( $tabs ) {
		if ( ! is_array( $tabs ) ) {
			return $tabs;
		}

		$definition = array(
			'label' => __( 'Group Lessons', 'tutorhelper-group-bookings' ),
			'icon' => 'dashicons-groups',
			'status' => 'available',
			'description' => __( 'Create and manage group lesson blocks and their sessions.', 'tutorhelper-group-bookings' ),
		);

		$result = array();
		$inserted = false;

		foreach ( $tabs as $key => $tab ) {
			$result[ $key ] = $tab;

			if ( 'students' === $key ) {
				$result[ self::TAB_KEY ] = $definition;
				$inserted = true;
			}
		}

		if ( ! $inserted ) {
			$result[ self::TAB_KEY ] = $definition;
		}

		return $result;
	}

	/**
	 * Enqueue Group Lessons styling on its Booking Hub tab.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: '';

		if ( self::TAB_KEY !== $tab ) {
			return;
		}

		$style_path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/css/group-lessons-admin.css';

		wp_enqueue_style(
			'tutorhelper-group-lessons-admin',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/css/group-lessons-admin.css',
			array( 'tutorhelper-booking-hub' ),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION
		);

		$script_path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/js/group-lessons-admin-form.js';
		wp_enqueue_script(
			'tutorhelper-group-lessons-admin-form',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/js/group-lessons-admin-form.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-group-lessons-admin-form',
			'TutorHelperGroupSchedule',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action' => self::PREVIEW_ACTION,
				'nonce' => wp_create_nonce( self::PREVIEW_ACTION ),
				'error' => __( 'The schedule preview could not be generated. Please check the lesson details and try again.', 'tutorhelper-group-bookings' ),
			)
		);
	}

	/**
	 * Render the Group Lessons Booking Hub tab.
	 *
	 * @param string $selected_tab Selected tab.
	 * @param array  $active_tab   Active tab definition.
	 * @return void
	 */
	public static function render_tab( $selected_tab, $active_tab ) {
		if (
			self::TAB_KEY !== $selected_tab
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		self::render_notice();

		$block_id = isset( $_GET['group_block_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? absint( $_GET['group_block_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: 0;

		$view = isset( $_GET['group_view'] ) && ! is_array( $_GET['group_view'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? sanitize_key( wp_unslash( $_GET['group_view'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: '';

		$session_id = isset( $_GET['group_session_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? absint( $_GET['group_session_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: 0;

		if ( 'convert' === $view ) {
			TutorHelper_Group_Conversions_Admin::render_page();
			return;
		}

		if ( $block_id && $session_id && 'session-details' === $view ) {
			TutorHelper_Group_Session_Management::render_edit_page(
				TutorHelper_Group_Blocks::get_by_id( $block_id ),
				TutorHelper_Group_Sessions::get_by_id( $session_id )
			);
			return;
		}

		if ( $block_id && $session_id ) {
			TutorHelper_Group_Attendance_Admin::render_page(
				TutorHelper_Group_Blocks::get_by_id( $block_id ),
				TutorHelper_Group_Sessions::get_by_id( $session_id )
			);
			return;
		}

		if ( $block_id && 'edit' === $view ) {
			TutorHelper_Group_Block_Management::render_edit_page( $block_id );
			return;
		}

		if ( $block_id ) {
			self::render_block_detail( $block_id );
			return;
		}

		self::render_workspace( $active_tab );
	}

	/**
	 * Render the main block list and create form.
	 *
	 * @param array $active_tab Active tab definition.
	 * @return void
	 */
	private static function render_workspace( $active_tab ) {
		$blocks = TutorHelper_Group_Blocks::get_all();
		$groups = TutorHelper_Pro_Groups::get_all(
			array( 'active_only' => true )
		);
		$booking_types = TutorHelper_Booking_Types::get_active();
		$current_user = wp_get_current_user();
		?>
		<section class="tutorhelper-group-lessons">
			<header class="tutorhelper-main-section__header tutorhelper-group-lessons__header">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php echo esc_html( isset( $active_tab['label'] ) ? $active_tab['label'] : __( 'Group Lessons', 'tutorhelper-group-bookings' ) ); ?></h2>
					<p><?php echo esc_html__( 'Create recurring lesson blocks from your existing TutorHelper Pro Groups.', 'tutorhelper-group-bookings' ); ?></p>
				</div>
				<a class="button tutorhelper-ui-button tutorhelper-ui-button--secondary" href="<?php echo esc_url( add_query_arg( array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => self::TAB_KEY, 'group_view' => 'convert' ), admin_url( 'admin.php' ) ) ); ?>"><?php echo esc_html__( 'Convert booking', 'tutorhelper-group-bookings' ); ?></a>
			</header>

			<div class="tutorhelper-group-lessons__layout">
				<section class="tutorhelper-main-section tutorhelper-group-lessons__blocks">
					<header class="tutorhelper-main-section__header">
						<div class="tutorhelper-main-section__header-content">
							<h3><?php echo esc_html__( 'Lesson blocks', 'tutorhelper-group-bookings' ); ?></h3>
							<p><?php echo esc_html__( 'Review the blocks already created for your groups.', 'tutorhelper-group-bookings' ); ?></p>
						</div>
					</header>
					<div class="tutorhelper-main-section__body">
						<?php self::render_blocks_table( $blocks ); ?>
					</div>
				</section>

				<aside class="tutorhelper-main-section tutorhelper-group-lessons__create">
					<header class="tutorhelper-main-section__header">
						<div class="tutorhelper-main-section__header-content">
							<h3><?php echo esc_html__( 'Create lesson block', 'tutorhelper-group-bookings' ); ?></h3>
							<p><?php echo esc_html__( 'Set the group, schedule, enrolment limits and pricing.', 'tutorhelper-group-bookings' ); ?></p>
						</div>
					</header>
					<div class="tutorhelper-main-section__body">
						<?php self::render_create_form( $groups, $booking_types, $current_user ); ?>
					</div>
				</aside>
			</div>
		</section>
		<?php
	}

	/**
	 * Render existing blocks.
	 *
	 * @param array $blocks Block records.
	 * @return void
	 */
	private static function render_blocks_table( $blocks ) {
		if ( empty( $blocks ) ) {
			?>
			<div class="tutorhelper-group-lessons__empty">
				<span class="dashicons dashicons-groups" aria-hidden="true"></span>
				<h4><?php echo esc_html__( 'No Group Lesson blocks yet', 'tutorhelper-group-bookings' ); ?></h4>
				<p><?php echo esc_html__( 'Create your first block using the form alongside this list.', 'tutorhelper-group-bookings' ); ?></p>
			</div>
			<?php
			return;
		}
		?>
		<div class="tutorhelper-group-lessons__table-wrap">
			<table class="widefat striped tutorhelper-group-lessons__table">
				<thead>
					<tr>
						<th><?php echo esc_html__( 'Block', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Schedule', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Sessions', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Enrolment', 'tutorhelper-group-bookings' ); ?></th>
						<th><?php echo esc_html__( 'Status', 'tutorhelper-group-bookings' ); ?></th>
						<th><span class="screen-reader-text"><?php echo esc_html__( 'Actions', 'tutorhelper-group-bookings' ); ?></span></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $blocks as $block ) : ?>
						<?php
						$sessions = TutorHelper_Group_Sessions::get_for_block( $block->id );
						$group = TutorHelper_Pro_Groups::get_by_id( $block->group_id );
						$status = sanitize_key( $block->status );
						?>
						<tr>
							<td>
								<strong><?php echo esc_html( $block->title ); ?></strong>
								<small><?php echo esc_html( $group ? $group->name : __( 'Group unavailable', 'tutorhelper-group-bookings' ) ); ?></small>
							</td>
							<td>
								<?php echo esc_html( self::format_block_schedule( $block ) ); ?>
							</td>
							<td><?php echo esc_html( count( $sessions ) ); ?></td>
							<td>
								<?php
								$enrolled = TutorHelper_Group_Enrolments::count_reserved_places( $block->id );
								$maximum = null !== $block->max_enrolments
									? absint( $block->max_enrolments )
									: esc_html__( 'Unlimited', 'tutorhelper-group-bookings' );
								printf(
									/* translators: 1: enrolled places, 2: maximum places, 3: minimum enrolments. */
									esc_html__( '%1$d/%2$s enrolled (min %3$d)', 'tutorhelper-group-bookings' ),
									$enrolled,
									$maximum,
									absint( $block->min_enrolments )
								);
								?>
							</td>
							<td><span class="tutorhelper-group-status is-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( self::get_status_label( $status ) ); ?></span></td>
							<td>
								<div class="tutorhelper-group-lessons__row-actions">
									<a class="button tutorhelper-hub-pill-button-small" href="<?php echo esc_url( self::get_block_url( $block->id ) ); ?>"><?php echo esc_html__( 'View', 'tutorhelper-group-bookings' ); ?></a>
									<a class="button tutorhelper-hub-pill-button-small" href="<?php echo esc_url( add_query_arg( 'group_view', 'edit', self::get_block_url( $block->id ) ) ); ?>"><?php echo esc_html__( 'Edit', 'tutorhelper-group-bookings' ); ?></a>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Render the block creation form.
	 *
	 * @param array   $groups Active Pro Groups.
	 * @param array   $booking_types Active Core Booking Types.
	 * @param WP_User $current_user Current admin user.
	 * @return void
	 */
	private static function render_create_form( $groups, $booking_types, $current_user ) {
		if ( empty( $groups ) || empty( $booking_types ) ) {
			?>
			<div class="notice notice-warning inline">
				<p><?php echo esc_html__( 'Create at least one active Pro Group and one active Booking Type before creating a Group Lesson block.', 'tutorhelper-group-bookings' ); ?></p>
			</div>
			<?php
			return;
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-group-block-form">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::CREATE_ACTION ); ?>" />
			<input type="hidden" name="tutor_user_id" value="<?php echo esc_attr( $current_user->ID ); ?>" />
			<input type="hidden" name="timezone" value="<?php echo esc_attr( wp_timezone_string() ); ?>" />
			<input type="hidden" name="currency" value="<?php echo esc_attr( class_exists( 'TutorHelper_Currency' ) ? TutorHelper_Currency::get_currency() : 'GBP' ); ?>" />
			<?php wp_nonce_field( self::CREATE_ACTION ); ?>

			<label class="tutorhelper-admin-control">
				<span><?php echo esc_html__( 'Group', 'tutorhelper-group-bookings' ); ?></span>
				<select name="group_id" required>
					<option value=""><?php echo esc_html__( 'Select group', 'tutorhelper-group-bookings' ); ?></option>
					<?php foreach ( $groups as $group ) : ?>
						<option value="<?php echo esc_attr( $group->id ); ?>"><?php echo esc_html( $group->name ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>

			<label class="tutorhelper-admin-control">
				<span><?php echo esc_html__( 'Block title', 'tutorhelper-group-bookings' ); ?></span>
				<input type="text" name="title" placeholder="<?php echo esc_attr__( 'e.g. Easter GCSE Revision', 'tutorhelper-group-bookings' ); ?>" />
				<small><?php echo esc_html__( 'Leave blank to use the Group name.', 'tutorhelper-group-bookings' ); ?></small>
			</label>

			<label class="tutorhelper-admin-control">
				<span><?php echo esc_html__( 'Booking Type', 'tutorhelper-group-bookings' ); ?></span>
				<select name="booking_type_id" required>
					<option value=""><?php echo esc_html__( 'Select Booking Type', 'tutorhelper-group-bookings' ); ?></option>
					<?php foreach ( $booking_types as $booking_type ) : ?>
						<option value="<?php echo esc_attr( $booking_type->id ); ?>"><?php echo esc_html( $booking_type->title ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>

			<div class="tutorhelper-group-block-form__grid">
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Start date', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="start_date" required /></label>
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'End date', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="end_date" required /></label>
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Start time', 'tutorhelper-group-bookings' ); ?></span><input type="time" name="start_time" required /></label>
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'End time', 'tutorhelper-group-bookings' ); ?></span><input type="time" name="end_time" required /></label>
			</div>

			<div class="tutorhelper-group-block-form__grid">
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Bookable from', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="bookable_from" /><small><?php esc_html_e( 'Leave blank to allow bookings immediately.', 'tutorhelper-group-bookings' ); ?></small></label>
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Bookable until', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="bookable_until" /><small><?php esc_html_e( 'Leave blank to keep bookings open until the group is full or closed.', 'tutorhelper-group-bookings' ); ?></small></label>
			</div>

			<label class="tutorhelper-ui-option-row tutorhelper-group-block__public-option"><input type="checkbox" name="open_for_public_booking" value="1" /> <span><?php esc_html_e( 'Open this Group Lesson for public booking', 'tutorhelper-group-bookings' ); ?></span></label>
			<p class="description"><?php esc_html_e( 'Public groups can be listed with the open Group Lessons shortcode. Visitors register or sign in before a place is reserved.', 'tutorhelper-group-bookings' ); ?></p>

			<label class="tutorhelper-admin-control">
				<span><?php echo esc_html__( 'Repeats', 'tutorhelper-group-bookings' ); ?></span>
				<select name="frequency">
					<option value="weekly"><?php echo esc_html__( 'Weekly', 'tutorhelper-group-bookings' ); ?></option>
					<option value="fortnightly"><?php echo esc_html__( 'Fortnightly', 'tutorhelper-group-bookings' ); ?></option>
				</select>
			</label>

			<div class="tutorhelper-group-block-form__grid">
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Minimum enrolment', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="min_enrolments" min="1" value="1" required /></label>
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Maximum enrolment', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="max_enrolments" min="1" placeholder="<?php echo esc_attr__( 'Unlimited', 'tutorhelper-group-bookings' ); ?>" /></label>
			</div>

			<label class="tutorhelper-admin-control">
				<span><?php echo esc_html__( 'Pricing', 'tutorhelper-group-bookings' ); ?></span>
				<select name="pricing_basis">
					<option value="booking_type"><?php echo esc_html__( 'Use Booking Type price', 'tutorhelper-group-bookings' ); ?></option>
					<option value="per_session"><?php echo esc_html__( 'Set price per lesson', 'tutorhelper-group-bookings' ); ?></option>
					<option value="fixed_block"><?php echo esc_html__( 'Set fixed block price', 'tutorhelper-group-bookings' ); ?></option>
				</select>
			</label>

			<div class="tutorhelper-group-block-form__grid">
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Price per lesson (minor units)', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="price_per_session_minor_units" min="0" value="0" /><small><?php echo esc_html__( 'Example: £25.00 = 2500.', 'tutorhelper-group-bookings' ); ?></small></label>
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Fixed block price (minor units)', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="fixed_block_price_minor_units" min="0" /><small><?php echo esc_html__( 'Only used with fixed block pricing.', 'tutorhelper-group-bookings' ); ?></small></label>
			</div>

			<label class="tutorhelper-admin-control">
				<span><?php echo esc_html__( 'Payment arrangement', 'tutorhelper-group-bookings' ); ?></span>
				<select name="payment_mode">
					<option value="manual"><?php echo esc_html__( 'Invoice / manual payment', 'tutorhelper-group-bookings' ); ?></option>
					<option value="full_upfront"><?php echo esc_html__( 'Full payment upfront', 'tutorhelper-group-bookings' ); ?></option>
					<option value="deposit"><?php echo esc_html__( 'Deposit required', 'tutorhelper-group-bookings' ); ?></option>
				</select>
			</label>

			<div class="tutorhelper-group-block-form__grid">
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Deposit type', 'tutorhelper-group-bookings' ); ?></span><select name="deposit_type"><option value="none"><?php echo esc_html__( 'None', 'tutorhelper-group-bookings' ); ?></option><option value="fixed"><?php echo esc_html__( 'Fixed amount', 'tutorhelper-group-bookings' ); ?></option><option value="percentage"><?php echo esc_html__( 'Percentage', 'tutorhelper-group-bookings' ); ?></option></select></label>
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Deposit value', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="deposit_value" min="0" value="0" /><small><?php echo esc_html__( 'Fixed amounts use minor units; percentages use whole numbers.', 'tutorhelper-group-bookings' ); ?></small></label>
			</div>

			<fieldset class="tutorhelper-admin-control">
				<legend><strong><?php echo esc_html__( 'Student cancellation terms', 'tutorhelper-group-bookings' ); ?></strong></legend>
				<label class="tutorhelper-ui-option-row"><input type="checkbox" name="student_cancellation_allowed" value="1" checked /> <?php echo esc_html__( 'Allow students to cancel their place on the whole block', 'tutorhelper-group-bookings' ); ?></label>
				<label><span><?php echo esc_html__( 'Minimum notice (hours before first session)', 'tutorhelper-group-bookings' ); ?></span><input type="number" name="cancellation_notice_hours" min="0" value="24" /></label>
				<label><span><?php echo esc_html__( 'Deposit treatment', 'tutorhelper-group-bookings' ); ?></span><select name="deposit_refundable"><option value="yes"><?php echo esc_html__( 'Refundable as account credit', 'tutorhelper-group-bookings' ); ?></option><option value="no"><?php echo esc_html__( 'Non-refundable', 'tutorhelper-group-bookings' ); ?></option></select></label>
				<label><span><?php echo esc_html__( 'Terms shown to students', 'tutorhelper-group-bookings' ); ?></span><textarea name="cancellation_terms" rows="4" placeholder="<?php echo esc_attr__( 'Explain any additional cancellation conditions.', 'tutorhelper-group-bookings' ); ?>"></textarea></label>
				<small><?php echo esc_html__( 'Cancellation applies to the complete block. Eligible paid fees are issued as account credit; a non-refundable deposit is retained.', 'tutorhelper-group-bookings' ); ?></small>
			</fieldset>

			<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Location type', 'tutorhelper-group-bookings' ); ?></span><input type="text" name="location_type" placeholder="online" /></label>
			<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'Location details', 'tutorhelper-group-bookings' ); ?></span><textarea name="location_details" rows="3"></textarea></label>

			<div class="tutorhelper-group-schedule-preview" data-group-schedule-preview></div>
			<button type="button" class="button" data-group-schedule-preview-button>
				<?php echo esc_html__( 'Preview session dates', 'tutorhelper-group-bookings' ); ?>
			</button>
			<button type="submit" class="button tutorhelper-ui-button tutorhelper-ui-button--primary tutorhelper-admin-button tutorhelper-admin-button--primary">
				<?php echo esc_html__( 'Create lesson block', 'tutorhelper-group-bookings' ); ?>
			</button>
		</form>
		<?php
	}

	/**
	 * Handle Group Block creation from wp-admin.
	 *
	 * @return void
	 */
	public static function handle_create_block() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to create Group Lesson blocks.', 'tutorhelper-group-bookings' ) );
		}

		check_admin_referer( self::CREATE_ACTION );

		$result = TutorHelper_Group_Block_Create::create( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Service layer sanitises and validates every supported field.

		$args = array(
			'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
			'tab' => self::TAB_KEY,
		);

		if ( is_wp_error( $result ) ) {
			$args['group_notice'] = 'error';
			$args['group_message'] = rawurlencode( $result->get_error_message() );
		} else {
			$args['group_notice'] = 'created';
			$args['group_block_id'] = absint( $result );
		}

		wp_safe_redirect(
			add_query_arg( $args, admin_url( 'admin.php' ) )
		);
		exit;
	}

	/**
	 * Render a block detail view with generated sessions.
	 *
	 * @param int $block_id Block ID.
	 * @return void
	 */
	private static function render_block_detail( $block_id ) {
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' ) . '</p></div>';
			return;
		}

		$sessions = TutorHelper_Group_Sessions::get_for_block( $block_id );
		$group = TutorHelper_Pro_Groups::get_by_id( $block->group_id );
		$booking_type = TutorHelper_Booking_Types::get_by_id( $block->booking_type_id );
		?>
		<section class="tutorhelper-main-section tutorhelper-group-block-detail">
			<header class="tutorhelper-main-section__header">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php echo esc_html( $block->title ); ?></h2>
					<p><?php echo esc_html( $group ? $group->name : '' ); ?></p>
				</div>
				<div class="tutorhelper-group-block-detail__actions">
					<?php TutorHelper_Group_Block_Management::render_actions( $block ); ?>
					<a class="button tutorhelper-hub-pill-button" href="<?php echo esc_url( self::get_tab_url() ); ?>"><?php echo esc_html__( 'Back to Group Lessons', 'tutorhelper-group-bookings' ); ?></a>
				</div>
			</header>

			<?php self::render_extension_panel( $block ); ?>

			<div class="tutorhelper-main-section__body">
				<div class="tutorhelper-group-block-summary">
					<div><strong><?php echo esc_html__( 'Booking Type', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo esc_html( $booking_type ? $booking_type->title : '' ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Schedule', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo esc_html( self::format_block_schedule( $block ) ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Sessions', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo esc_html( count( $sessions ) ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Enrolment', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo esc_html( absint( $block->min_enrolments ) . ' min / ' . ( null !== $block->max_enrolments ? absint( $block->max_enrolments ) : __( 'Unlimited', 'tutorhelper-group-bookings' ) ) . ' max' ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Price per lesson', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo esc_html( self::format_money( $block->price_per_session_minor_units, $block->currency ) ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Status', 'tutorhelper-group-bookings' ); ?></strong><span class="tutorhelper-group-status is-<?php echo esc_attr( $block->status ); ?>"><?php echo esc_html( self::get_status_label( $block->status ) ); ?></span></div>
					<div><strong><?php echo esc_html__( 'Student cancellation', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo esc_html( ! empty( $block->student_cancellation_allowed ) ? sprintf(
						/* translators: %d: Cancellation notice in hours. */
						__( 'Available until %d hours before the first session', 'tutorhelper-group-bookings' ), absint( $block->cancellation_notice_hours ) ) : __( 'Not available', 'tutorhelper-group-bookings' ) ); ?></span></div>
					<?php if ( ! empty( $block->cancellation_terms ) ) : ?><div><strong><?php echo esc_html__( 'Cancellation terms', 'tutorhelper-group-bookings' ); ?></strong><span><?php echo wp_kses_post( nl2br( esc_html( $block->cancellation_terms ) ) ); ?></span></div><?php endif; ?>
				</div>

				<h3><?php echo esc_html__( 'Generated sessions', 'tutorhelper-group-bookings' ); ?></h3>
				<table class="widefat striped tutorhelper-group-lessons__table">
					<thead><tr><th><?php echo esc_html__( 'Session', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Date', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Start', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'End', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Status', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Session details', 'tutorhelper-group-bookings' ); ?></th><th><?php echo esc_html__( 'Attendance', 'tutorhelper-group-bookings' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $sessions as $session ) : ?>
							<tr>
								<td><?php echo esc_html( '#' . absint( $session->session_number ) ); ?></td>
								<td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $session->session_date ) ) ); ?></td>
								<td><?php echo esc_html( get_date_from_gmt( $session->booking_start, get_option( 'time_format' ) ) ); ?></td>
								<td><?php echo esc_html( get_date_from_gmt( $session->booking_end, get_option( 'time_format' ) ) ); ?></td>
								<td><?php echo esc_html( ucfirst( sanitize_key( $session->status ) ) ); ?></td>
								<td><?php TutorHelper_Group_Session_Management::render_session_details( $block, $session ); ?></td>
								<td><?php TutorHelper_Group_Attendance_Admin::render_session_action( $block, $session ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</section>
		<?php
	}


	/**
	 * Return a live schedule preview for the creation and extension forms.
	 *
	 * @return void
	 */
	public static function handle_schedule_preview() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to preview this schedule.', 'tutorhelper-group-bookings' ) ), 403 );
		}
		check_ajax_referer( self::PREVIEW_ACTION, 'nonce' );
		$data = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Service layers sanitise accepted fields.
		if ( ! empty( $data['extension_block_id'] ) ) {
			$preview = TutorHelper_Group_Schedule_Extensions::preview( TutorHelper_Group_Blocks::get_by_id( absint( $data['extension_block_id'] ) ), isset( $data['end_date'] ) ? $data['end_date'] : '', isset( $data['excluded_session_dates'] ) ? $data['excluded_session_dates'] : array() );
		} else {
			$prepared = TutorHelper_Group_Block_Create::prepare( $data );
			$preview = is_wp_error( $prepared ) ? $prepared : TutorHelper_Group_Schedule_Planner::preview( $prepared, isset( $data['excluded_session_dates'] ) ? $data['excluded_session_dates'] : array() );
		}
		if ( is_wp_error( $preview ) ) {
			wp_send_json_error( array( 'message' => $preview->get_error_message() ), 400 );
		}
		ob_start();
		self::render_schedule_preview( $preview );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/**
	 * Render a proposed schedule with clear included, warning and blocked states.
	 *
	 * @param array $preview Schedule candidates.
	 * @return void
	 */
	private static function render_schedule_preview( $preview ) {
		?>
		<div class="tutorhelper-group-schedule-preview__inner">
			<h4><?php echo esc_html__( 'Proposed session dates', 'tutorhelper-group-bookings' ); ?></h4>
			<p class="description"><?php echo esc_html__( 'Warnings can remain selected. Blocked dates cannot be created. Tick a date to exclude it manually.', 'tutorhelper-group-bookings' ); ?></p>
			<ul class="tutorhelper-group-schedule-preview__list">
				<?php foreach ( $preview as $candidate ) : ?>
					<li class="is-<?php echo esc_attr( $candidate['state'] ); ?>">
						<?php if ( $candidate['can_include'] ) : ?>
							<label><input type="checkbox" name="excluded_session_dates[]" value="<?php echo esc_attr( $candidate['date'] ); ?>" <?php checked( 'excluded' === $candidate['state'] ); ?> /> <span><?php echo esc_html( $candidate['label'] ); ?></span></label>
						<?php else : ?><strong><?php echo esc_html( $candidate['label'] ); ?></strong><?php endif; ?>
						<span class="tutorhelper-group-schedule-preview__state"><?php echo esc_html( ucfirst( $candidate['state'] ) ); ?></span>
						<?php if ( ! empty( $candidate['reason'] ) ) : ?><small><?php echo esc_html( $candidate['reason'] ); ?></small><?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render the tutor-only extension form on a block detail page.
	 *
	 * @param object $block Group Block.
	 * @return void
	 */
	private static function render_extension_panel( $block ) {
		?>
		<section class="tutorhelper-main-section tutorhelper-group-extension">
			<header class="tutorhelper-main-section__header"><div class="tutorhelper-main-section__header-content"><h3><?php echo esc_html__( 'Extend schedule', 'tutorhelper-group-bookings' ); ?></h3><p><?php echo esc_html__( 'Preview and add only new sessions. Each active enrolment balance will increase using this block’s pricing basis.', 'tutorhelper-group-bookings' ); ?></p></div></header>
			<div class="tutorhelper-main-section__body"><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-group-block-form" data-group-schedule-form>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::EXTEND_ACTION ); ?>" /><input type="hidden" name="block_id" value="<?php echo esc_attr( $block->id ); ?>" /><input type="hidden" name="extension_block_id" value="<?php echo esc_attr( $block->id ); ?>" />
				<?php wp_nonce_field( self::EXTEND_ACTION . '_' . absint( $block->id ) ); ?>
				<label class="tutorhelper-admin-control"><span><?php echo esc_html__( 'New end date', 'tutorhelper-group-bookings' ); ?></span><input type="date" name="end_date" min="<?php echo esc_attr( wp_date( 'Y-m-d', strtotime( $block->end_date . ' +1 day' ) ) ); ?>" required /></label>
				<div class="tutorhelper-group-schedule-preview" data-group-schedule-preview></div>
				<button type="button" class="button" data-group-schedule-preview-button><?php echo esc_html__( 'Preview additional sessions', 'tutorhelper-group-bookings' ); ?></button>
				<button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary"><?php echo esc_html__( 'Confirm extension', 'tutorhelper-group-bookings' ); ?></button>
			</form></div>
		</section>
		<?php
	}

	/**
	 * Apply a tutor-confirmed extension.
	 *
	 * @return void
	 */
	public static function handle_extend_block() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to extend Group Lessons.', 'tutorhelper-group-bookings' ) );
		}
		$block_id = isset( $_POST['block_id'] ) ? absint( wp_unslash( $_POST['block_id'] ) ) : 0;
		check_admin_referer( self::EXTEND_ACTION . '_' . $block_id );
		$result = TutorHelper_Group_Schedule_Extensions::extend( $block_id, isset( $_POST['end_date'] ) ? sanitize_text_field( wp_unslash( $_POST['end_date'] ) ) : '', isset( $_POST['excluded_session_dates'] ) && is_array( $_POST['excluded_session_dates'] ) ? wp_unslash( $_POST['excluded_session_dates'] ) : array() );
		$args = array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => self::TAB_KEY, 'group_block_id' => $block_id );
		if ( is_wp_error( $result ) ) {
			$args['group_notice'] = 'error';
			$args['group_message'] = rawurlencode( $result->get_error_message() );
		} else {
			$args['group_notice'] = 'extended';
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Render success/error feedback.
	 *
	 * @return void
	 */
	private static function render_notice() {
		$notice = isset( $_GET['group_notice'] ) && ! is_array( $_GET['group_notice'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			? sanitize_key( wp_unslash( $_GET['group_notice'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			: '';

		$success_messages = array(
			'created' => __( 'Group Lesson block created and sessions generated.', 'tutorhelper-group-bookings' ),
			'extended' => __( 'The Group Lesson schedule has been extended and enrolment balances updated.', 'tutorhelper-group-bookings' ),
			'updated' => __( 'Group Lesson block updated.', 'tutorhelper-group-bookings' ),
			'session_updated' => __( 'Group Session details updated.', 'tutorhelper-group-bookings' ),
			'deleted' => __( 'Group Lesson block and its planned sessions deleted.', 'tutorhelper-group-bookings' ),
			'g8_updated' => __( 'The Group Lesson change was saved and affected students were updated.', 'tutorhelper-group-bookings' ),
		);

		if ( isset( $success_messages[ $notice ] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $success_messages[ $notice ] ) . '</p></div>';
			return;
		}

		if ( 'error' !== $notice ) {
			return;
		}

		$message = isset( $_GET['group_message'] ) && ! is_array( $_GET['group_message'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			? sanitize_text_field( rawurldecode( wp_unslash( $_GET['group_message'] ) ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only feedback state.
			: __( 'The Group Lesson block could not be created.', 'tutorhelper-group-bookings' );

		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}

	/**
	 * Return all blocks, newest first.
	 *
	 * @return array
	 */
	private static function get_blocks() {
		return TutorHelper_Group_Blocks::get_all();
	}

	/**
	 * Format a block schedule.
	 *
	 * @param object $block Block record.
	 * @return string
	 */
	private static function format_block_schedule( $block ) {
		$frequency = 'fortnightly' === $block->frequency
			? __( 'Fortnightly', 'tutorhelper-group-bookings' )
			: __( 'Weekly', 'tutorhelper-group-bookings' );

		$day = wp_date(
			'l',
			( new DateTimeImmutable( $block->start_date, wp_timezone() ) )->getTimestamp(),
			wp_timezone()
		);

		return sprintf(
			/* translators: 1: day of week, 2: recurrence, 3: start time, 4: end time. */
			__( '%1$s, %2$s, %3$s–%4$s', 'tutorhelper-group-bookings' ),
			$day,
			$frequency,
			date_i18n( get_option( 'time_format' ), strtotime( $block->start_time ) ),
			date_i18n( get_option( 'time_format' ), strtotime( $block->end_time ) )
		);
	}

	/**
	 * Get a human-readable block status.
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	private static function get_status_label( $status ) {
		$labels = array(
			'draft' => __( 'Draft', 'tutorhelper-group-bookings' ),
			'open' => __( 'Open', 'tutorhelper-group-bookings' ),
			'awaiting_minimum' => __( 'Awaiting minimum', 'tutorhelper-group-bookings' ),
			'confirmed' => __( 'Confirmed', 'tutorhelper-group-bookings' ),
			'full' => __( 'Full', 'tutorhelper-group-bookings' ),
			'cancelled' => __( 'Cancelled', 'tutorhelper-group-bookings' ),
			'completed' => __( 'Completed', 'tutorhelper-group-bookings' ),
		);

		$status = sanitize_key( $status );
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
	}

	/**
	 * Format minor currency units for display.
	 *
	 * @param int    $amount Amount in minor units.
	 * @param string $currency Currency code.
	 * @return string
	 */
	private static function format_money( $amount, $currency ) {
		$amount = absint( $amount );
		$currency = strtoupper( sanitize_text_field( $currency ) );
		$symbol = 'GBP' === $currency ? '£' : $currency . ' ';

		return $symbol . number_format_i18n( $amount / 100, 2 );
	}

	/**
	 * Return the Group Lessons tab URL.
	 *
	 * @return string
	 */
	private static function get_tab_url() {
		return add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => self::TAB_KEY,
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Return a block detail URL.
	 *
	 * @param int $block_id Block ID.
	 * @return string
	 */
	private static function get_block_url( $block_id ) {
		return add_query_arg(
			'group_block_id',
			absint( $block_id ),
			self::get_tab_url()
		);
	}
}
