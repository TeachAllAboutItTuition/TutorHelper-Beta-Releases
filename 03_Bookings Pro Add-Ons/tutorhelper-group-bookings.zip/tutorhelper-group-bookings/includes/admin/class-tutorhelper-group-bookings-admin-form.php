<?php
/**
 * Group Lessons admin form enhancements.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Improves the Group Lesson creation form while keeping the service layer
 * in integer minor currency units.
 */
final class TutorHelper_Group_Bookings_Admin_Form {

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_script' ),
			45
		);

		add_action(
			'admin_post_' . TutorHelper_Group_Bookings_Admin::CREATE_ACTION,
			array( __CLASS__, 'normalise_currency_inputs' ),
			1
		);

		add_action(
			'admin_post_' . TutorHelper_Group_Block_Management::UPDATE_ACTION,
			array( __CLASS__, 'normalise_currency_inputs' ),
			1
		);

		add_action(
			'admin_post_' . TutorHelper_Group_Conversions_Admin::PREVIEW_ACTION,
			array( __CLASS__, 'normalise_currency_inputs' ),
			1
		);
	}

	/**
	 * Enqueue the external form-behaviour script on Group Lessons only.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public static function enqueue_script( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: '';

		if ( TutorHelper_Group_Bookings_Admin::TAB_KEY !== $tab ) {
			return;
		}

		$script_path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/js/group-lessons-admin-form.js';

		wp_enqueue_script(
			'tutorhelper-group-lessons-admin-form',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/js/group-lessons-admin-form.js',
			array(),
			file_exists( $script_path )
				? (string) filemtime( $script_path )
				: TUTORHELPER_GROUP_BOOKINGS_VERSION,
			true
		);

		$currency = class_exists( 'TutorHelper_Currency' )
			? TutorHelper_Currency::get_currency()
			: 'GBP';

		$symbol = 'GBP' === strtoupper( $currency )
			? '£'
			: strtoupper( $currency ) . ' ';

		wp_localize_script(
			'tutorhelper-group-lessons-admin-form',
			'tutorhelperGroupLessonsForm',
			array(
				'currencyCode' => strtoupper( $currency ),
				'currencySymbol' => $symbol,
				'locationNote' => __(
					'Use location notes for preparation and joining instructions. If you have saved a Zoom link or Google Calendar integration is set up, students will see the joining link on their dashboard.',
					'tutorhelper-group-bookings'
				),
			)
		);
	}

	/**
	 * Convert tutor-facing currency amounts to integer minor units before
	 * the existing block creation handler passes data to the service layer.
	 *
	 * @return void
	 */
	public static function normalise_currency_inputs() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}

		if ( isset( $_POST['price_per_session'] ) && ! is_array( $_POST['price_per_session'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			$_POST['price_per_session_minor_units'] = self::currency_to_minor_units(
				wp_unslash( $_POST['price_per_session'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			);
		}

		if ( isset( $_POST['fixed_block_price'] ) && ! is_array( $_POST['fixed_block_price'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			$value = trim( (string) wp_unslash( $_POST['fixed_block_price'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.

			$_POST['fixed_block_price_minor_units'] = '' === $value
				? ''
				: self::currency_to_minor_units( $value );
		}

		$payment_mode = isset( $_POST['payment_mode'] ) && ! is_array( $_POST['payment_mode'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			? sanitize_key( wp_unslash( $_POST['payment_mode'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			: '';

		$deposit_type = isset( $_POST['deposit_type'] ) && ! is_array( $_POST['deposit_type'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			? sanitize_key( wp_unslash( $_POST['deposit_type'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			: '';

		if ( TutorHelper_Group_Blocks::PAYMENT_DEPOSIT !== $payment_mode ) {
			$_POST['deposit_type'] = TutorHelper_Group_Blocks::DEPOSIT_NONE;
			$_POST['deposit_value'] = 0;
			return;
		}

		if (
			TutorHelper_Group_Blocks::DEPOSIT_FIXED === $deposit_type
			&& isset( $_POST['deposit_value'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			&& ! is_array( $_POST['deposit_value'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
		) {
			$_POST['deposit_value'] = self::currency_to_minor_units(
				wp_unslash( $_POST['deposit_value'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
			);
		}
	}

	/**
	 * Convert a decimal currency string into integer minor units.
	 *
	 * @param mixed $value Tutor-facing currency amount.
	 * @return int
	 */
	private static function currency_to_minor_units( $value ) {
		$value = is_scalar( $value )
			? trim( (string) $value )
			: '0';

		$value = str_replace( ',', '.', $value );

		if ( ! preg_match( '/^\d+(?:\.\d{0,2})?$/', $value ) ) {
			return 0;
		}

		$parts = explode( '.', $value, 2 );
		$major = absint( $parts[0] );
		$minor = isset( $parts[1] )
			? str_pad( substr( $parts[1], 0, 2 ), 2, '0' )
			: '00';

		return ( $major * 100 ) + absint( $minor );
	}
}
