<?php
/** TutorHelper Group Bookings licence controller. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_Group_License_Controller {
	public static function activate( $license_key ) {
		$license_key = trim( sanitize_text_field( $license_key ) );
		if ( '' === $license_key ) { return new WP_Error( 'missing_key', __( 'A licence key is required.', 'tutorhelper-group-bookings' ) ); }
		if ( ! TutorHelper_Group_License::set_key( $license_key ) ) {
			return new WP_Error( 'license_not_saved', __( 'The licence key could not be saved on this site.', 'tutorhelper-group-bookings' ) );
		}
		$response = TutorHelper_Group_License_API::activate( $license_key );
		if ( is_wp_error( $response ) ) { return $response; }
		if ( empty( $response['success'] ) || empty( $response['activation_token'] ) || 'active' !== sanitize_key( $response['status'] ?? '' ) ) {
			return new WP_Error( 'activation_failed', __( 'The Group Bookings licence could not be activated.', 'tutorhelper-group-bookings' ) );
		}
		TutorHelper_Group_License::store_activation( $license_key, $response );
		return true;
	}

	public static function validate() {
		$key = TutorHelper_Group_License::get_key();
		if ( '' === $key ) { return new WP_Error( 'missing_key', __( 'No licence key is stored.', 'tutorhelper-group-bookings' ) ); }
		$response = TutorHelper_Group_License_API::validate( $key );
		if ( is_wp_error( $response ) ) { return $response; }
		$status = sanitize_key( $response['status'] ?? '' );
		$reason = sanitize_key( $response['reason'] ?? '' );
		if ( ! empty( $response['success'] ) && in_array( $status, array( 'valid', 'active' ), true ) ) {
			TutorHelper_Group_License::store_validation( $response );
			return true;
		}
		if ( 'expired' === $status ) {
			TutorHelper_Group_License::set_status( 'expired' );
			return new WP_Error(
				'expired',
				__( 'The Group Bookings licence has expired.', 'tutorhelper-group-bookings' ),
				array( 'server_reason' => $reason )
			);
		}
		if ( in_array( $status, array( 'invalid', 'inactive', 'revoked' ), true ) ) {
			TutorHelper_Group_License::set_status( 'invalid' );
			return new WP_Error(
				'invalid',
				__( 'The Group Bookings licence is not valid for this installation.', 'tutorhelper-group-bookings' ),
				array( 'server_reason' => $reason )
			);
		}
		return new WP_Error(
			'license_unconfirmed',
			__( 'The licence server returned an unexpected response. The previous local licence state has been kept.', 'tutorhelper-group-bookings' )
		);
	}

	public static function deactivate() {
		$key = TutorHelper_Group_License::get_key();
		$token = TutorHelper_Group_License::get_token();
		if ( '' === $key || '' === $token ) { return new WP_Error( 'not_active', __( 'No active Group Bookings licence was found.', 'tutorhelper-group-bookings' ) ); }
		$response = TutorHelper_Group_License_API::deactivate( $key, $token );
		if ( is_wp_error( $response ) ) { return $response; }
		if ( empty( $response['success'] ) || 'inactive' !== sanitize_key( $response['status'] ?? '' ) ) { return new WP_Error( 'deactivation_failed', __( 'The Group Bookings licence could not be deactivated.', 'tutorhelper-group-bookings' ) ); }
		TutorHelper_Group_License::deactivate_local();
		return true;
	}
}
