<?php
/**
 * TutorHelper Group Bookings main plugin class.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads Group Bookings services.
 */
final class TutorHelper_Group_Bookings {

	/** @var TutorHelper_Group_Bookings|null */
	private static $instance = null;

	/** @return TutorHelper_Group_Bookings */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/** Start the add-on. */
	public function run() {
		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/blocks/class-tutorhelper-group-blocks.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-sessions.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-schedule-planner.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-schedule-extensions.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/blocks/class-tutorhelper-group-block-create.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/blocks/class-tutorhelper-group-block-management.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/enrolments/class-tutorhelper-group-booking-context.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/payments/class-tutorhelper-group-payments.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/payments/class-tutorhelper-group-stripe.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/frontend/class-tutorhelper-group-student-frontend.php';


		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/frontend/class-tutorhelper-group-public-registration.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/frontend/class-tutorhelper-group-public-discovery.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/enrolments/class-tutorhelper-group-enrolment-bookings.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/enrolments/class-tutorhelper-group-enrolment-removal.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/enrolments/class-tutorhelper-group-enrolments.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/enrolments/class-tutorhelper-group-core-booking-bridge.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/enrolments/class-tutorhelper-group-booking-status-sync.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/blocks/class-tutorhelper-group-block-readiness.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/payments/class-tutorhelper-group-finance-reconciliation.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/payments/class-tutorhelper-group-finance-summary-ui.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-calendar-sync.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-calendar-child-cleanup.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-booking-calendar.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-calendar-lifecycle.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-calendar-planning.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/sessions/class-tutorhelper-group-calendar-meeting-link.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/frontend/class-tutorhelper-group-joining-links.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/frontend/class-tutorhelper-group-dashboard-actions.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/emails/class-tutorhelper-group-emails.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/lifecycle/class-tutorhelper-group-lifecycle-audit.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/lifecycle/class-tutorhelper-group-conversion-context.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/lifecycle/class-tutorhelper-group-conversions.php';

		require_once TUTORHELPER_GROUP_BOOKINGS_PATH
			. 'includes/cancellations/class-tutorhelper-group-cancellations.php';

		TutorHelper_Group_Blocks::init();
		TutorHelper_Group_Block_Management::init();
		TutorHelper_Group_Sessions::init();
		TutorHelper_Group_Core_Booking_Bridge::init();
		TutorHelper_Group_Conversion_Context::init();
		TutorHelper_Group_Booking_Status_Sync::init();
		TutorHelper_Group_Block_Readiness::init();
		TutorHelper_Group_Stripe::init();
		TutorHelper_Group_Finance_Reconciliation::init();
		TutorHelper_Group_Finance_Summary_UI::init();
		TutorHelper_Group_Calendar_Sync::init();
		TutorHelper_Group_Calendar_Child_Cleanup::init();
		TutorHelper_Group_Booking_Calendar::init();
		TutorHelper_Group_Calendar_Lifecycle::init();
		TutorHelper_Group_Calendar_Planning::init();
		TutorHelper_Group_Calendar_Meeting_Link::init();
		TutorHelper_Group_Student_Frontend::init();
		TutorHelper_Group_Public_Registration::init();
		TutorHelper_Group_Public_Discovery::init();
		TutorHelper_Group_Dashboard_Actions::init();
		TutorHelper_Group_Emails::init();
		TutorHelper_Group_Cancellations::init();

		if ( is_admin() ) {
			require_once TUTORHELPER_GROUP_BOOKINGS_PATH
				. 'includes/admin/class-tutorhelper-group-bookings-admin.php';

			require_once TUTORHELPER_GROUP_BOOKINGS_PATH
				. 'includes/admin/class-tutorhelper-group-conversions-admin.php';

			require_once TUTORHELPER_GROUP_BOOKINGS_PATH
				. 'includes/attendance/class-tutorhelper-group-attendance-admin.php';

			require_once TUTORHELPER_GROUP_BOOKINGS_PATH
				. 'includes/sessions/class-tutorhelper-group-session-management.php';

			require_once TUTORHELPER_GROUP_BOOKINGS_PATH
				. 'includes/admin/class-tutorhelper-group-bookings-admin-form.php';

			require_once TUTORHELPER_GROUP_BOOKINGS_PATH
				. 'includes/admin/class-tutorhelper-group-enrolments-admin.php';

			TutorHelper_Group_Bookings_Admin::init();
			TutorHelper_Group_Conversions_Admin::init();
			TutorHelper_Group_Attendance_Admin::init();
			TutorHelper_Group_Session_Management::init();
			TutorHelper_Group_Bookings_Admin_Form::init();
			TutorHelper_Group_Enrolments_Admin::init();
		}
	}
}
