<?php
/**
 * Group cancellation and rescheduling lifecycle.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Coordinates tutor session changes and student block-level cancellation.
 */
final class TutorHelper_Group_Cancellations {

	const TUTOR_ACTION = 'tutorhelper_group_session_change';
	const BLOCK_ACTION = 'tutorhelper_group_cancel_block';
	const STUDENT_CANCEL_ACTION = 'tutorhelper_group_cancel_enrolment';
	const RESPONSE_ACTION = 'tutorhelper_group_reschedule_response';

	/** Register G8 hooks. */
	public static function init() {
		add_action( 'admin_post_' . self::TUTOR_ACTION, array( __CLASS__, 'handle_session_change' ) );
		add_action( 'admin_post_' . self::BLOCK_ACTION, array( __CLASS__, 'handle_block_cancel' ) );
		add_action( 'admin_post_' . self::STUDENT_CANCEL_ACTION, array( __CLASS__, 'handle_student_cancel' ) );
		add_action( 'admin_post_' . self::RESPONSE_ACTION, array( __CLASS__, 'handle_response' ) );
		add_action( 'tutorhelper_booking_hub_render_tab', array( __CLASS__, 'render_admin_controls' ), 40, 2 );
		add_action( 'tutorhelper_group_dashboard_enrolment_actions', array( __CLASS__, 'render_enrolment_cancel_action' ), 10, 2 );

		if ( class_exists( 'TutorHelper_Student_Dashboard_Actions' ) ) {
			remove_action(
				'admin_post_' . TutorHelper_Student_Dashboard_Actions::CANCEL_ACTION,
				array( 'TutorHelper_Student_Dashboard_Actions', 'handle_cancel' )
			);
			add_action(
				'admin_post_' . TutorHelper_Student_Dashboard_Actions::CANCEL_ACTION,
				array( __CLASS__, 'route_core_cancellation' )
			);
		}
	}

	/** Prevent a Group child lesson being cancelled independently through Core. */
	public static function route_core_cancellation() {
		$booking_id = isset( $_POST['booking_id'] ) && ! is_array( $_POST['booking_id'] ) ? absint( wp_unslash( $_POST['booking_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
		if ( self::get_link_by_booking( $booking_id ) ) {
			$url = wp_get_referer() ? wp_get_referer() : home_url( '/' );
			wp_safe_redirect( add_query_arg( 'group_cancellation', 'use_group_lessons', $url ) );
			exit;
		}
		TutorHelper_Student_Dashboard_Actions::handle_cancel();
	}

	/** Render secured tutor controls on a session detail or block detail screen. */
	public static function render_admin_controls( $selected_tab, $active_tab ) {
		unset( $active_tab );
		if ( TutorHelper_Group_Bookings_Admin::TAB_KEY !== $selected_tab || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}

		$block_id = isset( $_GET['group_block_id'] ) ? absint( $_GET['group_block_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$session_id = isset( $_GET['group_session_id'] ) ? absint( $_GET['group_session_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$view = isset( $_GET['group_view'] ) && ! is_array( $_GET['group_view'] ) ? sanitize_key( wp_unslash( $_GET['group_view'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			return;
		}

		if ( $session_id && 'session-details' === $view ) {
			$session = TutorHelper_Group_Sessions::get_by_id( $session_id );
			if ( ! $session || absint( $session->block_id ) !== $block_id || TutorHelper_Group_Sessions::STATUS_SCHEDULED !== sanitize_key( $session->status ) || strtotime( $session->booking_end . ' UTC' ) <= time() ) {
				return;
			}
			$local_start = self::local_datetime( $session->booking_start, $block->timezone );
			$local_end = self::local_datetime( $session->booking_end, $block->timezone );
			?>
			<section class="tutorhelper-main-section tutorhelper-group-session-change">
				<header class="tutorhelper-main-section__header"><h3><?php esc_html_e( 'Reschedule or cancel this session', 'tutorhelper-group-bookings' ); ?></h3></header>
				<div class="tutorhelper-main-section__body">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::TUTOR_ACTION ); ?>" />
						<input type="hidden" name="change_type" value="reschedule" />
						<input type="hidden" name="block_id" value="<?php echo esc_attr( $block_id ); ?>" />
						<input type="hidden" name="session_id" value="<?php echo esc_attr( $session_id ); ?>" />
						<?php wp_nonce_field( self::TUTOR_ACTION . '_' . $session_id ); ?>
						<p><label><?php esc_html_e( 'New date', 'tutorhelper-group-bookings' ); ?> <input type="date" name="session_date" value="<?php echo esc_attr( $local_start->format( 'Y-m-d' ) ); ?>" required /></label></p>
						<p><label><?php esc_html_e( 'Start', 'tutorhelper-group-bookings' ); ?> <input type="time" name="start_time" value="<?php echo esc_attr( $local_start->format( 'H:i' ) ); ?>" required /></label>
						<label><?php esc_html_e( 'End', 'tutorhelper-group-bookings' ); ?> <input type="time" name="end_time" value="<?php echo esc_attr( $local_end->format( 'H:i' ) ); ?>" required /></label></p>
						<p><label><?php esc_html_e( 'Reason / message to students', 'tutorhelper-group-bookings' ); ?><br /><textarea name="reason" rows="3" class="large-text" required></textarea></label></p>
						<p class="description"><?php esc_html_e( 'Each student can accept the new time or request account credit for this lesson.', 'tutorhelper-group-bookings' ); ?></p>
						<button type="submit" class="button button-primary"><?php esc_html_e( 'Reschedule session and notify students', 'tutorhelper-group-bookings' ); ?></button>
					</form>
					<hr />
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Cancel this session and issue account credit to paid students?', 'tutorhelper-group-bookings' ) ); ?>');">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::TUTOR_ACTION ); ?>" />
						<input type="hidden" name="change_type" value="cancel" />
						<input type="hidden" name="block_id" value="<?php echo esc_attr( $block_id ); ?>" />
						<input type="hidden" name="session_id" value="<?php echo esc_attr( $session_id ); ?>" />
						<?php wp_nonce_field( self::TUTOR_ACTION . '_' . $session_id ); ?>
						<p><label><?php esc_html_e( 'Cancellation reason', 'tutorhelper-group-bookings' ); ?><br /><textarea name="reason" rows="3" class="large-text" required></textarea></label></p>
						<button type="submit" class="button"><?php esc_html_e( 'Cancel session and issue credits', 'tutorhelper-group-bookings' ); ?></button>
					</form>
				</div>
			</section>
			<?php
			return;
		}

		if ( ! $session_id && ! in_array( sanitize_key( $block->status ), array( 'cancelled', 'completed' ), true ) ) {
			?>
			<section class="tutorhelper-main-section tutorhelper-group-block-cancel">
				<header class="tutorhelper-main-section__header"><h3><?php esc_html_e( 'Cancel whole lesson block', 'tutorhelper-group-bookings' ); ?></h3></header>
				<div class="tutorhelper-main-section__body">
					<p><?php esc_html_e( 'Cancels every remaining session, releases all places and applies the block cancellation policy to paid fees.', 'tutorhelper-group-bookings' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Cancel this entire Group Lesson block?', 'tutorhelper-group-bookings' ) ); ?>');">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::BLOCK_ACTION ); ?>" />
						<input type="hidden" name="block_id" value="<?php echo esc_attr( $block_id ); ?>" />
						<?php wp_nonce_field( self::BLOCK_ACTION . '_' . $block_id ); ?>
						<textarea name="reason" rows="3" class="large-text" required placeholder="<?php echo esc_attr__( 'Reason shown to students and parents', 'tutorhelper-group-bookings' ); ?>"></textarea>
						<p><button type="submit" class="button"><?php esc_html_e( 'Cancel block', 'tutorhelper-group-bookings' ); ?></button></p>
					</form>
				</div>
			</section>
			<?php
		}
	}

	/** Append student cancellation and reschedule-response controls. */
	public static function render_student_controls( $output, $tag, $attr, $match ) {
		unset( $attr, $match );
		if (
			! class_exists( 'TutorHelper_Student_Dashboard_Shortcode' )
			|| TutorHelper_Student_Dashboard_Shortcode::SHORTCODE !== $tag
			|| ! is_user_logged_in()
			|| ! TutorHelper_Students::get_student( get_current_user_id() )
		) {
			return $output;
		}

		global $wpdb;
		$student_id = get_current_user_id();
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$wpdb->prepare(
				'SELECT e.*, b.title, b.student_cancellation_allowed, b.cancellation_notice_hours, b.deposit_refundable, b.cancellation_terms, b.start_date, b.timezone FROM %i e INNER JOIN %i b ON b.id=e.block_id WHERE e.student_user_id=%d AND e.status!=%s ORDER BY e.joined_at DESC',
				TutorHelper_Group_Enrolments::get_table_name(),
				TutorHelper_Group_Blocks::get_table_name(),
				$student_id,
				TutorHelper_Group_Enrolments::STATUS_CANCELLED
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( empty( $rows ) ) {
			return $output;
		}

		ob_start();
		?>
		<section class="tutorhelper-group-g8" aria-labelledby="tutorhelper-group-g8-heading">
			<h2 id="tutorhelper-group-g8-heading"><?php esc_html_e( 'Group Lesson changes & cancellation', 'tutorhelper-group-bookings' ); ?></h2>
			<?php foreach ( $rows as $enrolment ) : ?>
				<article class="tutorhelper-group-g8__card">
					<h3><?php echo esc_html( $enrolment->title ); ?></h3>
					<?php self::render_pending_responses( $enrolment ); ?>
					<?php if ( ! empty( $enrolment->cancellation_terms ) ) : ?><p><?php echo wp_kses_post( nl2br( esc_html( $enrolment->cancellation_terms ) ) ); ?></p><?php endif; ?>
					<p><?php echo esc_html( self::policy_summary( $enrolment ) ); ?></p>
					<?php if ( self::student_can_cancel( $enrolment ) ) : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Cancel your place on the whole block?', 'tutorhelper-group-bookings' ) ); ?>');">
							<input type="hidden" name="action" value="<?php echo esc_attr( self::STUDENT_CANCEL_ACTION ); ?>" />
							<input type="hidden" name="enrolment_id" value="<?php echo esc_attr( $enrolment->id ); ?>" />
							<?php wp_nonce_field( self::STUDENT_CANCEL_ACTION . '_' . absint( $enrolment->id ) ); ?>
							<textarea name="reason" rows="2" required placeholder="<?php echo esc_attr__( 'Reason for cancellation', 'tutorhelper-group-bookings' ); ?>"></textarea>
							<button type="submit"><?php esc_html_e( 'Cancel my place on this block', 'tutorhelper-group-bookings' ); ?></button>
						</form>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</section>
		<?php
		return $output . ob_get_clean();
	}

	/** Process a tutor reschedule or one-session cancellation. */
	public static function handle_session_change() {
		self::require_tutor();
		$session_id = isset( $_POST['session_id'] ) && ! is_array( $_POST['session_id'] ) ? absint( wp_unslash( $_POST['session_id'] ) ) : 0;
		$block_id = isset( $_POST['block_id'] ) && ! is_array( $_POST['block_id'] ) ? absint( wp_unslash( $_POST['block_id'] ) ) : 0;
		check_admin_referer( self::TUTOR_ACTION . '_' . $session_id );
		$session = TutorHelper_Group_Sessions::get_by_id( $session_id );
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $session || ! $block || absint( $session->block_id ) !== $block_id || TutorHelper_Group_Sessions::STATUS_SCHEDULED !== sanitize_key( $session->status ) || strtotime( $session->booking_end . ' UTC' ) <= time() ) {
			self::redirect_admin( $block_id, new WP_Error( 'invalid_session', __( 'The Group Session could not be verified.', 'tutorhelper-group-bookings' ) ) );
		}
		$reason = isset( $_POST['reason'] ) && ! is_array( $_POST['reason'] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) ) : '';
		if ( '' === $reason ) {
			self::redirect_admin( $block_id, new WP_Error( 'reason_required', __( 'Enter a reason or message for the students.', 'tutorhelper-group-bookings' ) ) );
		}
		$type = isset( $_POST['change_type'] ) && ! is_array( $_POST['change_type'] ) ? sanitize_key( wp_unslash( $_POST['change_type'] ) ) : '';
		$result = 'cancel' === $type ? self::cancel_session( $session, $block, $reason ) : self::reschedule_session( $session, $block, $reason );
		self::redirect_admin( $block_id, $result );
	}

	/** Reschedule the shared session and every linked child booking. */
	private static function reschedule_session( $session, $block, $reason ) {
		global $wpdb;
		$date = isset( $_POST['session_date'] ) && ! is_array( $_POST['session_date'] ) ? sanitize_text_field( wp_unslash( $_POST['session_date'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
		$start_time = isset( $_POST['start_time'] ) && ! is_array( $_POST['start_time'] ) ? sanitize_text_field( wp_unslash( $_POST['start_time'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
		$end_time = isset( $_POST['end_time'] ) && ! is_array( $_POST['end_time'] ) ? sanitize_text_field( wp_unslash( $_POST['end_time'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The enclosing protected handler verifies the nonce before state is changed; this read only routes or normalises the request.
		try {
			$timezone = new DateTimeZone( sanitize_text_field( $block->timezone ) );
			$start = new DateTimeImmutable( $date . ' ' . $start_time, $timezone );
			$end = new DateTimeImmutable( $date . ' ' . $end_time, $timezone );
			if ( $start->format( 'Y-m-d H:i' ) !== $date . ' ' . $start_time || $end <= $start ) {
				throw new Exception( 'Invalid schedule.' );
			}
			$start_utc = $start->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
			$end_utc = $end->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		} catch ( Exception $exception ) {
			return new WP_Error( 'invalid_schedule', __( 'Enter a valid date and an end time after the start time.', 'tutorhelper-group-bookings' ) );
		}

		$previous = clone $session;
		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			TutorHelper_Group_Sessions::get_table_name(),
			array(
				'session_date' => $date,
				'booking_start' => $start_utc,
				'booking_end' => $end_utc,
				'original_booking_start' => ! empty( $session->original_booking_start ) ? $session->original_booking_start : $session->booking_start,
				'original_booking_end' => ! empty( $session->original_booking_end ) ? $session->original_booking_end : $session->booking_end,
				'change_reason' => $reason,
				'rescheduled_at' => current_time( 'mysql', true ),
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $session->id ) )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		if ( false === $updated ) {
			return new WP_Error( 'session_update_failed', __( 'The Group Session could not be rescheduled.', 'tutorhelper-group-bookings' ) );
		}

		$links = self::get_session_links( $session->id );
		foreach ( $links as $link ) {
			$booking_before = TutorHelper_Booking_Records::get_by_id( $link->booking_id );
			if ( ! $booking_before || TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking_before->status ) ) {
				continue;
			}
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
				TutorHelper_Booking_Records::get_table_name(),
				array( 'booking_start' => $start_utc, 'booking_end' => $end_utc, 'updated_at' => current_time( 'mysql', true ) ),
				array( 'id' => absint( $link->booking_id ) ),
				array( '%s', '%s', '%s' ),
				array( '%d' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$booking_after = TutorHelper_Booking_Records::get_by_id( $link->booking_id );
			do_action( 'tutorhelper_booking_schedule_updated', absint( $link->booking_id ), $booking_after, $booking_before );
			do_action( 'tutorhelper_booking_updated', absint( $link->booking_id ), $booking_after, $booking_before );
			self::upsert_response( $session->id, $link->enrolment_id, $link->student_user_id, 'pending' );
		}

		$fresh = TutorHelper_Group_Sessions::get_by_id( $session->id );
		do_action( 'tutorhelper_group_session_updated', absint( $session->id ), $fresh, $previous );
		do_action( 'tutorhelper_group_session_rescheduled', absint( $session->id ), $fresh, $previous, $reason );
		return true;
	}

	/** Cancel one session, issue credit and reduce each enrolment's agreed price. */
	private static function cancel_session( $session, $block, $reason ) {
		global $wpdb;
		foreach ( self::get_session_links( $session->id ) as $link ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $link->booking_id );
			if ( ! $booking || TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
				continue;
			}
			self::issue_booking_credit( $booking, __( 'Tutor-cancelled Group Session', 'tutorhelper-group-bookings' ) . ': ' . $reason );
			self::reduce_enrolment_price( $link->enrolment_id, absint( $booking->price_minor_units ) );
			TutorHelper_Booking_Records::cancel( $booking->id, $reason, 'tutor' );
		}
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			TutorHelper_Group_Sessions::get_table_name(),
			array( 'status' => TutorHelper_Group_Sessions::STATUS_CANCELLED, 'change_reason' => $reason, 'updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => absint( $session->id ) )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		if ( method_exists( 'TutorHelper_Group_Calendar_Lifecycle', 'delete_session_event' ) ) {
			TutorHelper_Group_Calendar_Lifecycle::delete_session_event( TutorHelper_Group_Sessions::get_by_id( $session->id ) );
		}
		do_action( 'tutorhelper_group_session_cancelled', absint( $session->id ), $reason );
		return true;
	}

	/** Render whole-block cancellation as an action inside its Group Lesson card. */
	public static function render_enrolment_cancel_action( $enrolment, $block ) {
		if ( ! is_object( $enrolment ) || ! is_object( $block ) || ! self::student_can_cancel( $enrolment ) ) {
			return;
		}

		$form_id = 'tutorhelper-group-cancel-enrolment-' . absint( $enrolment->id );
		?>
		<details class="tutorhelper-group-dashboard__cancel">
			<summary class="tutorhelper-group-dashboard__cancel-toggle" aria-controls="<?php echo esc_attr( $form_id ); ?>"><?php esc_html_e( 'Cancel my Group Lesson booking', 'tutorhelper-group-bookings' ); ?></summary>
			<p><?php echo esc_html( self::policy_summary( $block ) ); ?></p>
			<?php if ( ! empty( $block->cancellation_terms ) ) : ?>
				<p><?php echo wp_kses_post( nl2br( esc_html( $block->cancellation_terms ) ) ); ?></p>
			<?php endif; ?>
			<form id="<?php echo esc_attr( $form_id ); ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::STUDENT_CANCEL_ACTION ); ?>" />
				<input type="hidden" name="enrolment_id" value="<?php echo esc_attr( $enrolment->id ); ?>" />
				<?php wp_nonce_field( self::STUDENT_CANCEL_ACTION . '_' . absint( $enrolment->id ) ); ?>
				<label>
					<span><?php esc_html_e( 'Reason for cancellation', 'tutorhelper-group-bookings' ); ?></span>
					<textarea name="reason" rows="3" required></textarea>
				</label>
				<button type="submit" class="tutorhelper-group-dashboard__cancel-submit"><?php esc_html_e( 'Confirm cancellation', 'tutorhelper-group-bookings' ); ?></button>
			</form>
		</details>
		<?php
	}

	/** Cancel the complete block and all active enrolments. */
	public static function handle_block_cancel() {
		self::require_tutor();
		$block_id = isset( $_POST['block_id'] ) && ! is_array( $_POST['block_id'] ) ? absint( wp_unslash( $_POST['block_id'] ) ) : 0;
		check_admin_referer( self::BLOCK_ACTION . '_' . $block_id );
		$reason = isset( $_POST['reason'] ) && ! is_array( $_POST['reason'] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) ) : '';
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block || '' === $reason ) {
			self::redirect_admin( $block_id, new WP_Error( 'invalid_block_cancel', __( 'Choose a valid block and enter a cancellation reason.', 'tutorhelper-group-bookings' ) ) );
		}

		$lifecycle_key = 'block_cancel_' . $block_id;
		$audit = TutorHelper_Group_Lifecycle_Audit::record(
			array(
				'lifecycle_key' => $lifecycle_key,
				'operation' => 'block_cancellation',
				'status' => 'started',
				'block_id' => $block_id,
				'context' => array(
					'reason' => $reason,
				),
			)
		);

		if ( is_wp_error( $audit ) ) {
			TutorHelper_Logger::error(
				'Group block cancellation could not start its audit record.',
				array(
					'block_id' => $block_id,
					'error_code' => $audit->get_error_code(),
					'error_message' => $audit->get_error_message(),
				)
			);

			self::redirect_admin( $block_id, $audit );
		}

		$active_enrolments = self::get_active_enrolments( $block_id );
		$cancelled_enrolment_ids = array();

		/*
		 * Work enrolment-by-enrolment. If an eligible credit cannot be
		 * recorded, leave the block open so a retry resumes only the
		 * remaining active enrolments. Already-cancelled enrolments are
		 * deliberately excluded by get_active_enrolments(), preventing
		 * duplicate credits on a retry.
		 */
		foreach ( $active_enrolments as $enrolment ) {
			$result = self::cancel_enrolment(
				$enrolment,
				$block,
				$reason,
				'tutor',
				false
			);

			if ( is_wp_error( $result ) ) {
				TutorHelper_Group_Lifecycle_Audit::record(
					array(
						'lifecycle_key' => $lifecycle_key,
						'operation' => 'block_cancellation',
						'status' => 'failed',
						'block_id' => $block_id,
						'enrolment_id' => absint( $enrolment->id ),
						'context' => array(
							'reason' => $reason,
							'cancelled_enrolment_ids' =>
								$cancelled_enrolment_ids,
							'error_code' =>
								$result->get_error_code(),
							'error_message' =>
								$result->get_error_message(),
						),
					)
				);

				TutorHelper_Logger::error(
					'Group block cancellation stopped before completion.',
					array(
						'block_id' => $block_id,
						'enrolment_id' => absint( $enrolment->id ),
						'cancelled_enrolment_ids' =>
							$cancelled_enrolment_ids,
						'error_code' =>
							$result->get_error_code(),
						'error_message' =>
							$result->get_error_message(),
					)
				);

				self::redirect_admin( $block_id, $result );
			}

			$cancelled_enrolment_ids[] =
				absint( $enrolment->id );
		}

		global $wpdb;
		$wpdb->update( TutorHelper_Group_Blocks::get_table_name(), array( 'status' => TutorHelper_Group_Blocks::STATUS_CANCELLED, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $block_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( TutorHelper_Group_Sessions::get_table_name(), array( 'status' => TutorHelper_Group_Sessions::STATUS_CANCELLED, 'change_reason' => $reason, 'updated_at' => current_time( 'mysql', true ) ), array( 'block_id' => $block_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		TutorHelper_Group_Calendar_Lifecycle::delete_block_events( $block_id );

		TutorHelper_Group_Lifecycle_Audit::record(
			array(
				'lifecycle_key' => $lifecycle_key,
				'operation' => 'block_cancellation',
				'status' => 'completed',
				'block_id' => $block_id,
				'context' => array(
					'reason' => $reason,
					'cancelled_enrolment_ids' =>
						$cancelled_enrolment_ids,
				),
			)
		);

		TutorHelper_Logger::success(
			'Group block cancellation completed.',
			array(
				'block_id' => $block_id,
				'cancelled_enrolment_ids' =>
					$cancelled_enrolment_ids,
				'active_enrolment_count' =>
					count( $active_enrolments ),
			)
		);

		do_action( 'tutorhelper_group_block_cancelled', $block_id, $reason );
		self::redirect_admin( $block_id, true );
	}

	/** Cancel the logged-in student's whole enrolment. */
	public static function handle_student_cancel() {
		$student_id = get_current_user_id();
		if ( ! $student_id || ! TutorHelper_Students::get_student( $student_id ) ) {
			self::redirect_student( 'not_allowed' );
		}
		$enrolment_id = isset( $_POST['enrolment_id'] ) && ! is_array( $_POST['enrolment_id'] ) ? absint( wp_unslash( $_POST['enrolment_id'] ) ) : 0;
		check_admin_referer( self::STUDENT_CANCEL_ACTION . '_' . $enrolment_id );
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		$block = $enrolment ? TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id ) : null;
		if ( ! $enrolment || ! $block || $student_id !== absint( $enrolment->student_user_id ) || ! self::student_can_cancel( $enrolment ) ) {
			self::redirect_student( 'not_allowed' );
		}
		$reason = isset( $_POST['reason'] ) && ! is_array( $_POST['reason'] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) ) : '';
		if ( '' === $reason ) {
			self::redirect_student( 'reason_required' );
		}
		$result = self::cancel_enrolment( $enrolment, $block, $reason, 'student', true );
		self::redirect_student( is_wp_error( $result ) ? $result->get_error_code() : 'cancelled' );
	}

	/** Record attendance or credit response to a tutor reschedule. */
	public static function handle_response() {
		$student_id = get_current_user_id();
		$response_id = isset( $_POST['response_id'] ) && ! is_array( $_POST['response_id'] ) ? absint( wp_unslash( $_POST['response_id'] ) ) : 0;
		check_admin_referer( self::RESPONSE_ACTION . '_' . $response_id );
		global $wpdb;
		$table = TutorHelper_Group_Bookings_Database::get_table_name( 'session_responses' );
		$response = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id=%d AND student_user_id=%d AND response_status=%s', $table, $response_id, $student_id, 'pending' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( ! $response ) {
			self::redirect_student( 'invalid_response' );
		}
		$choice = isset( $_POST['response'] ) && ! is_array( $_POST['response'] ) ? sanitize_key( wp_unslash( $_POST['response'] ) ) : '';
		if ( 'attending' === $choice ) {
			$wpdb->update( $table, array( 'response_status' => 'attending', 'responded_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $response_id, 'response_status' => 'pending' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			self::redirect_student( 'attending' );
		}
		if ( 'credit' !== $choice ) {
			self::redirect_student( 'invalid_response' );
		}
		$link = self::get_session_enrolment_link( $response->session_id, $response->enrolment_id );
		$booking = $link ? TutorHelper_Booking_Records::get_by_id( $link->booking_id ) : null;
		if ( ! $booking ) {
			self::redirect_student( 'booking_missing' );
		}
		$credit_id = self::issue_booking_credit( $booking, __( 'Student requested credit after Group Session reschedule.', 'tutorhelper-group-bookings' ) );
		if ( is_wp_error( $credit_id ) ) {
			self::redirect_student( $credit_id->get_error_code() );
		}
		self::reduce_enrolment_price( $response->enrolment_id, absint( $booking->price_minor_units ) );
		TutorHelper_Booking_Records::cancel( $booking->id, __( 'Student cannot attend the rescheduled Group Session.', 'tutorhelper-group-bookings' ), 'student' );
		$wpdb->update( $table, array( 'response_status' => 'credit_requested', 'credit_ledger_id' => absint( $credit_id ), 'responded_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $response_id, 'response_status' => 'pending' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		self::redirect_student( 'credit_issued' );
	}

	/** Apply the policy, credit eligible money and cancel every child booking. */
	private static function cancel_enrolment( $enrolment, $block, $reason, $cancelled_by, $respect_deposit ) {
		global $wpdb;
		TutorHelper_Group_Payments::reconcile_enrolment( $enrolment->id );
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment->id );
		$summary = TutorHelper_Group_Payments::get_summary( $enrolment );
		$protected = 0;
		if (
			$respect_deposit
			&& TutorHelper_Group_Blocks::PAYMENT_DEPOSIT === sanitize_key( $enrolment->payment_mode )
			&& empty( $block->deposit_refundable )
		) {
			$protected = TutorHelper_Group_Payments::calculate_deposit( absint( $enrolment->agreed_price_minor_units ), $enrolment->deposit_type, $enrolment->deposit_value );
		}
		$credit_target = max( 0, absint( $summary['net_paid_minor_units'] ) - min( $protected, absint( $summary['net_paid_minor_units'] ) ) );
		$remaining = $credit_target;
		$links = self::get_enrolment_links( $enrolment->id );
		$links = array_reverse( $links );
		foreach ( $links as $link ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $link->booking_id );
			if ( ! $booking ) {
				continue;
			}
			if ( $remaining > 0 ) {
				$totals = TutorHelper_Pro_Finance_Adjustments::get_booking_totals( $booking->id );
				$amount = min( $remaining, absint( $totals['refundable_minor_units'] ) );
				if ( $amount > 0 ) {
					$result = TutorHelper_Pro_Finance_Adjustments::record_adjustment( $booking->id, TutorHelper_Pro_Finance_Adjustments::ADJUSTMENT_CREDIT, $amount, __( 'Group enrolment cancellation', 'tutorhelper-group-bookings' ) . ': ' . $reason );
					if ( is_wp_error( $result ) ) {
						return $result;
					}
					$remaining -= $amount;
				}
			}
			if ( TutorHelper_Booking_Records::STATUS_CANCELLED !== sanitize_key( $booking->status ) ) {
				TutorHelper_Booking_Records::cancel( $booking->id, $reason, $cancelled_by );
			}
		}
		if ( $remaining > 0 ) {
			return new WP_Error( 'credit_allocation_incomplete', __( 'Not all eligible paid fees could be allocated to account credit.', 'tutorhelper-group-bookings' ) );
		}
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			TutorHelper_Group_Enrolments::get_table_name(),
			array( 'status' => TutorHelper_Group_Enrolments::STATUS_CANCELLED, 'cancelled_at' => current_time( 'mysql', true ), 'cancelled_by' => sanitize_key( $cancelled_by ), 'cancellation_reason' => $reason, 'updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => absint( $enrolment->id ) )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		do_action( 'tutorhelper_group_enrolment_changed', absint( $enrolment->id ), absint( $block->id ) );
		do_action( 'tutorhelper_group_enrolment_cancelled', absint( $enrolment->id ), $credit_target, $protected, $cancelled_by );
		return true;
	}

	/** Issue all currently refundable value on one child booking as account credit. */
	private static function issue_booking_credit( $booking, $note ) {
		$totals = TutorHelper_Pro_Finance_Adjustments::get_booking_totals( $booking->id );
		$amount = absint( $totals['refundable_minor_units'] );
		if ( 0 === $amount ) {
			return 0;
		}
		return TutorHelper_Pro_Finance_Adjustments::record_adjustment(
			$booking->id,
			TutorHelper_Pro_Finance_Adjustments::ADJUSTMENT_CREDIT,
			$amount,
			$note
		);
	}

	/** Reduce what this enrolment owes after a session is removed from it. */
	private static function reduce_enrolment_price( $enrolment_id, $amount ) {
		global $wpdb;
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if ( ! $enrolment ) {
			return;
		}
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			TutorHelper_Group_Enrolments::get_table_name(),
			array( 'agreed_price_minor_units' => max( 0, absint( $enrolment->agreed_price_minor_units ) - absint( $amount ) ), 'updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => absint( $enrolment_id ) )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		TutorHelper_Group_Payments::reconcile_enrolment( $enrolment_id );
	}

	/** Render outstanding response choices for an enrolment. */
	private static function render_pending_responses( $enrolment ) {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$wpdb->prepare(
				'SELECT r.*, s.session_number, s.booking_start, s.change_reason FROM %i r INNER JOIN %i s ON s.id=r.session_id WHERE r.enrolment_id=%d AND r.response_status=%s ORDER BY s.booking_start ASC',
				TutorHelper_Group_Bookings_Database::get_table_name( 'session_responses' ),
				TutorHelper_Group_Sessions::get_table_name(),
				absint( $enrolment->id ),
				'pending'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		foreach ( $rows as $row ) {
			$date = self::local_datetime( $row->booking_start, $enrolment->timezone );
			?>
			<div class="tutorhelper-group-g8__response">
				<p><strong><?php echo esc_html( sprintf(
					/* translators: 1: Session number, 2: New session date and time. */
					__( 'Session #%1$d moved to %2$s', 'tutorhelper-group-bookings' ), absint( $row->session_number ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $date->getTimestamp(), $date->getTimezone() ) ) ); ?></strong></p>
				<p><?php echo esc_html( $row->change_reason ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::RESPONSE_ACTION ); ?>" />
					<input type="hidden" name="response_id" value="<?php echo esc_attr( $row->id ); ?>" />
					<?php wp_nonce_field( self::RESPONSE_ACTION . '_' . absint( $row->id ) ); ?>
					<button type="submit" name="response" value="attending"><?php esc_html_e( 'I can attend', 'tutorhelper-group-bookings' ); ?></button>
					<button type="submit" name="response" value="credit"><?php esc_html_e( 'I cannot attend — apply lesson credit', 'tutorhelper-group-bookings' ); ?></button>
				</form>
			</div>
			<?php
		}
	}

	/** Store/reset one response row. */
	private static function upsert_response( $session_id, $enrolment_id, $student_id, $status ) {
		global $wpdb;
		$table = TutorHelper_Group_Bookings_Database::get_table_name( 'session_responses' );
		$wpdb->replace( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$table,
			array( 'session_id' => absint( $session_id ), 'enrolment_id' => absint( $enrolment_id ), 'student_user_id' => absint( $student_id ), 'response_status' => sanitize_key( $status ), 'responded_at' => null, 'credit_ledger_id' => null, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
	}

	/** Determine whether block-level self-cancellation is still available. */
	private static function student_can_cancel( $enrolment ) {
		$policy = $enrolment;
		if ( ! property_exists( $policy, 'student_cancellation_allowed' ) ) {
			$policy = TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id );
		}
		if ( ! $policy || empty( $policy->student_cancellation_allowed ) || TutorHelper_Group_Enrolments::STATUS_CANCELLED === sanitize_key( $enrolment->status ) ) {
			return false;
		}
		$sessions = TutorHelper_Group_Sessions::get_for_block( $enrolment->block_id );
		if ( empty( $sessions ) ) {
			return false;
		}
		$first = reset( $sessions );
		try {
			$deadline = ( new DateTimeImmutable( $first->booking_start, new DateTimeZone( 'UTC' ) ) )->modify( '-' . absint( $policy->cancellation_notice_hours ) . ' hours' );
			return new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) ) <= $deadline;
		} catch ( Exception $exception ) {
			return false;
		}
	}

	/** Human-readable policy summary. */
	private static function policy_summary( $enrolment ) {
		if ( empty( $enrolment->student_cancellation_allowed ) ) {
			return __( 'Student cancellation is not available for this block.', 'tutorhelper-group-bookings' );
		}
		$deposit = 'deposit' === sanitize_key( $enrolment->payment_mode )
			? ( empty( $enrolment->deposit_refundable ) ? __( 'The deposit is non-refundable.', 'tutorhelper-group-bookings' ) : __( 'The deposit is refundable as account credit.', 'tutorhelper-group-bookings' ) )
			: '';
		return trim( sprintf(
			/* translators: 1: Cancellation notice in hours, 2: Deposit policy summary. */
			__( 'Cancel the whole block at least %1$d hours before its first session. Eligible paid fees are returned as account credit. %2$s', 'tutorhelper-group-bookings' ), absint( $enrolment->cancellation_notice_hours ), $deposit ) );
	}

	/** Linked child bookings for a session. */
	private static function get_session_links( $session_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE session_id=%d ORDER BY enrolment_id ASC', TutorHelper_Group_Enrolment_Bookings::get_table_name(), absint( $session_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** Linked child bookings for an enrolment. */
	private static function get_enrolment_links( $enrolment_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE enrolment_id=%d ORDER BY session_id ASC', TutorHelper_Group_Enrolment_Bookings::get_table_name(), absint( $enrolment_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** One link by child booking. */
	private static function get_link_by_booking( $booking_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE booking_id=%d', TutorHelper_Group_Enrolment_Bookings::get_table_name(), absint( $booking_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** One link for session and enrolment. */
	private static function get_session_enrolment_link( $session_id, $enrolment_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE session_id=%d AND enrolment_id=%d', TutorHelper_Group_Enrolment_Bookings::get_table_name(), absint( $session_id ), absint( $enrolment_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** Active enrolments for a block. */
	private static function get_active_enrolments( $block_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE block_id=%d AND status!=%s', TutorHelper_Group_Enrolments::get_table_name(), absint( $block_id ), TutorHelper_Group_Enrolments::STATUS_CANCELLED ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** Parse UTC storage into the block timezone. */
	private static function local_datetime( $value, $timezone ) {
		try {
			return ( new DateTimeImmutable( sanitize_text_field( $value ), new DateTimeZone( 'UTC' ) ) )->setTimezone( new DateTimeZone( sanitize_text_field( $timezone ) ) );
		} catch ( Exception $exception ) {
			return new DateTimeImmutable( 'now', wp_timezone() );
		}
	}

	/** Require tutor capability. */
	private static function require_tutor() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Group Lesson changes.', 'tutorhelper-group-bookings' ) );
		}
	}

	/** Return to the Group block screen. */
	private static function redirect_admin( $block_id, $result ) {
		$args = array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => TutorHelper_Group_Bookings_Admin::TAB_KEY, 'group_block_id' => absint( $block_id ) );
		if ( is_wp_error( $result ) ) {
			$args['group_notice'] = 'error';
			$args['group_message'] = rawurlencode( $result->get_error_message() );
		} else {
			$args['group_notice'] = 'g8_updated';
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Return to the student dashboard. */
	private static function redirect_student( $status ) {
		$url = wp_get_referer() ? wp_get_referer() : home_url( '/' );
		wp_safe_redirect( add_query_arg( 'group_cancellation', sanitize_key( $status ), $url ) );
		exit;
	}
}
