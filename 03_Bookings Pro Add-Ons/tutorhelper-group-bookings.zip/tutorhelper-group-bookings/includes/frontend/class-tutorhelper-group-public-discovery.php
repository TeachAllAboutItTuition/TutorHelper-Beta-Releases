<?php
/**
 * Public Group Lesson discovery shortcode.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders explicitly public Group Lesson blocks without exposing private data.
 */
final class TutorHelper_Group_Public_Discovery {

	const SHORTCODE = 'tutorhelper_open_group_bookings';

	/**
	 * Register public discovery hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode( self::SHORTCODE, array( __CLASS__, 'render_shortcode' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_disable_page_cache' ), 0 );
		add_action( 'admin_post_tutorhelper_group_public_join', array( __CLASS__, 'handle_join_request' ) );
		add_action( 'wp_ajax_nopriv_tutorhelper_group_public_registration_form', array( __CLASS__, 'handle_registration_form_request' ) );
		add_filter( 'tutorhelper_student_booking_type_can_view', array( __CLASS__, 'restrict_external_booking_types' ), 20, 3 );
		add_filter( 'tutorhelper_student_booking_type_can_book', array( __CLASS__, 'restrict_external_booking_types' ), 20, 3 );
	}

	/**
	 * Prevent a cached public listing from showing stale availability or a
	 * signed-in visitor's booking state to somebody else.
	 *
	 * @return void
	 */
	public static function maybe_disable_page_cache() {
		if ( ! is_singular() ) {
			return;
		}

		$post = get_post();
		if ( ! $post instanceof WP_Post || ! has_shortcode( (string) $post->post_content, self::SHORTCODE ) ) {
			return;
		}

		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}

		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}

		nocache_headers();
	}

	/**
	 * Prevent External students from accessing standard booking types.
	 *
	 * Public Group Lesson enrolment uses its dedicated protected route.
	 *
	 * @param bool   $allowed         Current access result.
	 * @param object $booking_type    Booking Type record.
	 * @param int    $student_user_id Student user ID.
	 * @return bool
	 */
	public static function restrict_external_booking_types( $allowed, $booking_type, $student_user_id ) {
		unset( $booking_type );

		if (
			class_exists( 'TutorHelper_Students' )
			&& method_exists( 'TutorHelper_Students', 'is_external_student' )
			&& TutorHelper_Students::is_external_student( $student_user_id )
		) {
			return false;
		}

		return (bool) $allowed;
	}

	/**
	 * Render public Group Lesson cards.
	 *
	 * @param array|string $attributes Shortcode attributes.
	 * @return string
	 */
	public static function render_shortcode( $attributes ) {
		$attributes = shortcode_atts(
			array(
				'show_unavailable' => 'no',
			),
			$attributes,
			self::SHORTCODE
		);

		$show_unavailable = 'yes' === sanitize_key( $attributes['show_unavailable'] );
		$registration_block_id = isset( $_GET['tutorhelper_open_group_register'] ) && ! is_array( $_GET['tutorhelper_open_group_register'] )
			? absint( wp_unslash( $_GET['tutorhelper_open_group_register'] ) )
			: 0;
		$return_url = isset( $_GET['tutorhelper_open_group_return'] ) && ! is_array( $_GET['tutorhelper_open_group_return'] )
			? wp_validate_redirect( rawurldecode( wp_unslash( $_GET['tutorhelper_open_group_return'] ) ), self::get_current_url() )
			: self::get_current_url();

		if ( $registration_block_id && class_exists( 'TutorHelper_Group_Public_Registration' ) ) {
			self::enqueue_assets();
			return TutorHelper_Group_Public_Registration::render_form( $registration_block_id, $return_url );
		}

		$blocks = TutorHelper_Group_Blocks::get_all();
		$cards = array();

		foreach ( $blocks as $block ) {
			if ( ! TutorHelper_Group_Blocks::is_open_for_public_booking( $block ) ) {
				continue;
			}

			$card = self::get_card_data( $block );
			if ( ! $show_unavailable && ! $card['bookable'] ) {
				continue;
			}

			$cards[] = $card;
		}

		usort(
			$cards,
			static function( $first, $second ) {
				return strcmp( $first['start_date'], $second['start_date'] );
			}
		);

		self::enqueue_assets();

		ob_start();
		?>
		<section class="tutorhelper-public-groups tutorhelper-student-booking" aria-labelledby="tutorhelper-public-groups-heading">
			<?php self::render_notice(); ?>
			<header class="tutorhelper-public-groups__header tutorhelper-student-booking__header">
				<h2 id="tutorhelper-public-groups-heading" class="tutorhelper-student-booking__heading"><?php esc_html_e( 'Open Group Lessons', 'tutorhelper-group-bookings' ); ?></h2>
				<p class="tutorhelper-student-booking__introduction"><?php esc_html_e( 'Browse group lessons currently available to book.', 'tutorhelper-group-bookings' ); ?></p>
			</header>
			<div id="tutorhelper-group-registration-panel" class="tutorhelper-public-groups__registration-panel" aria-live="polite" aria-atomic="true" hidden></div>
			<?php if ( empty( $cards ) ) : ?>
				<p class="tutorhelper-public-groups__empty"><?php esc_html_e( 'There are no open Group Lessons available to book at the moment.', 'tutorhelper-group-bookings' ); ?></p>
			<?php else : ?>
				<div class="tutorhelper-public-groups__grid">
					<?php foreach ( $cards as $card ) : ?>
						<article class="tutorhelper-public-groups__card">
							<h3><?php echo esc_html( $card['title'] ); ?></h3>
							<p class="tutorhelper-public-groups__date"><strong><?php echo esc_html( $card['date_label'] ); ?></strong><br /><?php echo esc_html( $card['day_label'] . ' · ' . $card['time_label'] ); ?></p>
							<ul class="tutorhelper-public-groups__details">
								<li><?php echo esc_html( $card['duration_label'] ); ?></li>
								<li><?php echo esc_html( $card['recurrence_label'] ); ?></li>
								<li><?php echo esc_html( $card['capacity_label'] ); ?></li>
								<li><?php echo esc_html( $card['price_label'] ); ?></li>
							</ul>
							<p class="tutorhelper-public-groups__status"><?php echo esc_html( $card['status_label'] ); ?></p>
							<?php if ( $card['bookable'] && is_user_logged_in() && $card['already_enrolled'] ) : ?>
								<p class="tutorhelper-public-groups__status"><?php esc_html_e( 'You already have a place in this Group Lesson.', 'tutorhelper-group-bookings' ); ?></p>
								<a class="button tutorhelper-ui-button tutorhelper-ui-button--secondary" href="<?php echo esc_url( self::get_student_dashboard_url( self::get_current_url() ) ); ?>"><?php esc_html_e( 'View my Group Lessons', 'tutorhelper-group-bookings' ); ?></a>
							<?php elseif ( $card['bookable'] && is_user_logged_in() ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="tutorhelper_group_public_join" />
									<input type="hidden" name="block_id" value="<?php echo esc_attr( $card['block_id'] ); ?>" />
									<input type="hidden" name="return_url" value="<?php echo esc_url( self::get_student_dashboard_url( self::get_current_url() ) ); ?>" />
									<?php wp_nonce_field( 'tutorhelper_group_public_join_' . absint( $card['block_id'] ) ); ?>
									<button type="submit" class="button tutorhelper-ui-button tutorhelper-ui-button--primary"><?php esc_html_e( 'Book this Group Lesson', 'tutorhelper-group-bookings' ); ?></button>
								</form>
							<?php elseif ( $card['bookable'] ) : ?>
								<a class="button tutorhelper-ui-button tutorhelper-ui-button--primary" href="<?php echo esc_url( self::get_booking_url( $card['block_id'] ) ); ?>" data-tutorhelper-public-registration data-block-id="<?php echo esc_attr( $card['block_id'] ); ?>" data-return-url="<?php echo esc_url( self::get_current_url() ); ?>"><?php esc_html_e( 'Sign in or register to book', 'tutorhelper-group-bookings' ); ?></a>
							<?php endif; ?>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</section>
		<?php
		return ob_get_clean();
	}

	/**
	 * Build escaped-display-ready details for one public block.
	 *
	 * @param object $block Group Block record.
	 * @return array
	 */
	private static function get_card_data( $block ) {
		$window = TutorHelper_Group_Blocks::validate_public_booking( $block );
		$reserved = TutorHelper_Group_Enrolments::count_reserved_places( $block->id );
		$maximum = null !== $block->max_enrolments ? absint( $block->max_enrolments ) : 0;
		$is_full = $maximum && $reserved >= $maximum;
		$sessions = TutorHelper_Group_Sessions::get_for_block( $block->id );
		$total = TutorHelper_Group_Blocks::calculate_block_total( $block, count( $sessions ) );
		$bookable = ! is_wp_error( $window ) && ! $is_full;
		$student_user_id = is_user_logged_in() ? absint( get_current_user_id() ) : 0;
		$existing_enrolment = $student_user_id ? TutorHelper_Group_Enrolments::get_for_student( $block->id, $student_user_id ) : null;
		$already_enrolled = $existing_enrolment && ! in_array( sanitize_key( $existing_enrolment->status ), array( 'cancelled', 'cancelled_unpaid' ), true );

		if ( $is_full ) {
			$status = __( 'This Group Lesson is full.', 'tutorhelper-group-bookings' );
		} elseif ( is_wp_error( $window ) ) {
			$status = $window->get_error_message();
		} elseif ( TutorHelper_Group_Blocks::STATUS_AWAITING_MINIMUM === sanitize_key( $block->status ) ) {
			$status = __( 'Open for booking — awaiting minimum enrolment.', 'tutorhelper-group-bookings' );
		} else {
			$status = __( 'Open for booking.', 'tutorhelper-group-bookings' );
		}

		return array(
			'block_id' => absint( $block->id ),
			'title' => sanitize_text_field( $block->title ),
			'start_date' => sanitize_text_field( $block->start_date ),
			'date_label' => self::format_date( $block->start_date ),
			'day_label' => self::format_day( $block->start_date ),
			'time_label' => self::format_time_range( $block->start_time, $block->end_time ),
			'duration_label' => self::format_duration( $block->start_time, $block->end_time ),
			'recurrence_label' => self::format_recurrence( $block, count( $sessions ) ),
			'capacity_label' => self::format_capacity( $reserved, $maximum, absint( $block->min_enrolments ) ),
			'price_label' => self::format_price( $block, $total ),
			'status_label' => $status,
			'bookable' => $bookable,
			'already_enrolled' => (bool) $already_enrolled,
		);
	}

	/**
	 * Render the selected registration panel without reloading the page.
	 *
	 * This is a read-only public endpoint. The registration submission remains
	 * nonce-protected and is validated again server-side.
	 *
	 * @return void
	 */
	public static function handle_registration_form_request() {
		$block_id = isset( $_POST['block_id'] ) && ! is_array( $_POST['block_id'] )
			? absint( wp_unslash( $_POST['block_id'] ) )
			: 0;
		$return_url = isset( $_POST['return_url'] ) && ! is_array( $_POST['return_url'] )
			? wp_validate_redirect( wp_unslash( $_POST['return_url'] ), home_url( '/' ) )
			: home_url( '/' );

		if ( ! $block_id || ! class_exists( 'TutorHelper_Group_Public_Registration' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'This Group Lesson booking form is unavailable. Please refresh the page and try again.', 'tutorhelper-group-bookings' ) ),
				400
			);
		}

		wp_send_json_success(
			array( 'html' => TutorHelper_Group_Public_Registration::render_form( $block_id, $return_url ) )
		);
	}

	/**
	 * Create a public Group Lesson enrolment for the current student.
	 *
	 * @return void
	 */
	public static function handle_join_request() {
		if ( ! is_user_logged_in() ) {
			wp_die( esc_html__( 'Please sign in before booking a Group Lesson.', 'tutorhelper-group-bookings' ) );
		}

		$block_id = isset( $_POST['block_id'] ) && ! is_array( $_POST['block_id'] )
			? absint( wp_unslash( $_POST['block_id'] ) )
			: 0;
		check_admin_referer( 'tutorhelper_group_public_join_' . $block_id );

		$requested_return_url = isset( $_POST['return_url'] ) && ! is_array( $_POST['return_url'] )
			? wp_validate_redirect( wp_unslash( $_POST['return_url'] ), self::get_current_url() )
			: self::get_current_url();
		$return_url = self::get_student_dashboard_url( $requested_return_url );

		$result = TutorHelper_Group_Enrolments::enrol_student( $block_id, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			if ( 'tutorhelper_group_enrolment_duplicate' === $result->get_error_code() ) {
				self::redirect_with_notice( $return_url, 'success', __( 'You already have a place in this Group Lesson.', 'tutorhelper-group-bookings' ) );
			}

			self::redirect_with_notice( $return_url, 'error', $result->get_error_message() );
		}

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $result );
		if ( $enrolment && TutorHelper_Group_Stripe::can_start_checkout( $enrolment ) ) {
			$checkout = TutorHelper_Group_Stripe::create_checkout( $enrolment->id, $return_url );
			if ( is_wp_error( $checkout ) ) {
				self::redirect_with_notice( $return_url, 'error', $checkout->get_error_message() );
			}

			if ( empty( $checkout['url'] ) || ! is_string( $checkout['url'] ) || ! wp_http_validate_url( $checkout['url'] ) ) {
				TutorHelper_Logger::error(
					'Public Group Lesson checkout could not be started because Stripe did not return a valid checkout URL.',
					array( 'block_id' => $block_id )
				);

				self::redirect_with_notice( $return_url, 'error', __( 'Payment checkout could not be started. Please try again or contact your tutor.', 'tutorhelper-group-bookings' ) );
			}

			wp_redirect( esc_url_raw( $checkout['url'] ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Stripe Checkout is an intentionally external destination returned by the verified payment integration.
			exit;
		}

		self::redirect_with_notice(
			$return_url,
			'success',
			__( 'Your Group Lesson place has been reserved.', 'tutorhelper-group-bookings' )
		);
	}

	/**
	 * Return safely to the public listing with a short status notice.
	 *
	 * @param string $return_url Destination URL.
	 * @param string $type       Notice type.
	 * @param string $message    Notice message.
	 * @return void
	 */
	private static function redirect_with_notice( $return_url, $type, $message ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'tutorhelper_group_notice' => sanitize_key( $type ),
					'tutorhelper_group_message' => rawurlencode( sanitize_text_field( $message ) ),
				),
				$return_url
			)
		);
		exit;
	}

	/**
	 * Return the protected login/registration hand-off for a selected block.
	 *
	 * Batch 16 supplies the registration route. The filter keeps themes and
	 * integrators able to provide their existing student-login URL meanwhile.
	 *
	 * @param int $block_id Group Block ID.
	 * @return string
	 */
	private static function get_booking_url( $block_id ) {
		$destination = add_query_arg(
			array( 'tutorhelper_open_group' => absint( $block_id ) ),
			self::get_current_url()
		);

		if ( is_user_logged_in() ) {
			return apply_filters( 'tutorhelper_group_public_booking_url', $destination, $block_id );
		}

		return apply_filters( 'tutorhelper_group_public_registration_url', wp_login_url( $destination ), $block_id, $destination );
	}

	/**
	 * Return the configured Student Dashboard URL when Core provides one.
	 *
	 * @param string $fallback Safe local fallback URL.
	 * @return string
	 */
	private static function get_student_dashboard_url( $fallback ) {
		if ( class_exists( 'TutorHelper_Settings' ) && method_exists( 'TutorHelper_Settings', 'get_student_dashboard_url' ) ) {
			$dashboard_url = TutorHelper_Settings::get_student_dashboard_url();
			if ( is_string( $dashboard_url ) && '' !== $dashboard_url ) {
				return wp_validate_redirect( $dashboard_url, $fallback );
			}
		}

		return wp_validate_redirect( $fallback, home_url( '/' ) );
	}

	/** @return string */
	private static function get_current_url() {
		$scheme = is_ssl() ? 'https://' : 'http://';
		$host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$request = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';

		return esc_url_raw( $scheme . $host . $request );
	}

	/**
	 * Render the booking return notice.
	 *
	 * @return void
	 */
	private static function render_notice() {
		$registration = isset( $_GET['tutorhelper_group_registration'] ) && ! is_array( $_GET['tutorhelper_group_registration'] )
			? sanitize_key( wp_unslash( $_GET['tutorhelper_group_registration'] ) )
			: '';

		if ( 'created' === $registration ) {
			echo '<div class="tutorhelper-public-groups__notice tutorhelper-public-groups__notice--success" role="status">'
				. esc_html__( 'Your student account is ready. You can now reserve your selected Group Lesson place.', 'tutorhelper-group-bookings' )
				. '</div>';
		}

		$type = isset( $_GET['tutorhelper_group_notice'] ) && ! is_array( $_GET['tutorhelper_group_notice'] )
			? sanitize_key( wp_unslash( $_GET['tutorhelper_group_notice'] ) )
			: '';
		$message = isset( $_GET['tutorhelper_group_message'] ) && ! is_array( $_GET['tutorhelper_group_message'] )
			? sanitize_text_field( rawurldecode( wp_unslash( $_GET['tutorhelper_group_message'] ) ) )
			: '';

		if ( ! in_array( $type, array( 'success', 'error' ), true ) || '' === $message ) {
			return;
		}

		printf(
			'<div class="tutorhelper-public-groups__notice tutorhelper-public-groups__notice--%1$s" role="status">%2$s</div>',
			esc_attr( $type ),
			esc_html( $message )
		);
	}

	/** @return string */
	private static function format_date( $date ) {
		$date_object = DateTimeImmutable::createFromFormat( '!Y-m-d', sanitize_text_field( $date ), wp_timezone() );
		return $date_object ? wp_date( get_option( 'date_format' ), $date_object->getTimestamp(), wp_timezone() ) : '';
	}

	/** @return string */
	private static function format_day( $date ) {
		$date_object = DateTimeImmutable::createFromFormat( '!Y-m-d', sanitize_text_field( $date ), wp_timezone() );
		return $date_object ? wp_date( 'l', $date_object->getTimestamp(), wp_timezone() ) : '';
	}

	/** @return string */
	private static function format_duration( $start_time, $end_time ) {
		$start = strtotime( '1970-01-01 ' . sanitize_text_field( $start_time ) . ' UTC' );
		$end = strtotime( '1970-01-01 ' . sanitize_text_field( $end_time ) . ' UTC' );
		$minutes = ( false !== $start && false !== $end ) ? max( 0, (int) round( ( $end - $start ) / MINUTE_IN_SECONDS ) ) : 0;

		return sprintf(
			/* translators: %d: duration in minutes. */
			_n( '%d minute session', '%d minute sessions', $minutes, 'tutorhelper-group-bookings' ),
			$minutes
		);
	}

	/** @return string */
	private static function format_time_range( $start_time, $end_time ) {
		$start = strtotime( '1970-01-01 ' . sanitize_text_field( $start_time ) . ' UTC' );
		$end = strtotime( '1970-01-01 ' . sanitize_text_field( $end_time ) . ' UTC' );
		if ( false === $start || false === $end ) {
			return '';
		}

		return wp_date( get_option( 'time_format' ), $start, new DateTimeZone( 'UTC' ) )
			. ' – '
			. wp_date( get_option( 'time_format' ), $end, new DateTimeZone( 'UTC' ) );
	}

	/** @return string */
	private static function format_recurrence( $block, $session_count ) {
		if ( 1 === absint( $session_count ) ) {
			return __( 'One session', 'tutorhelper-group-bookings' );
		}

		return TutorHelper_Group_Block_Create::FREQUENCY_FORTNIGHTLY === sanitize_key( $block->frequency )
			? __( 'Fortnightly sessions', 'tutorhelper-group-bookings' )
			: __( 'Weekly sessions', 'tutorhelper-group-bookings' );
	}

	/** @return string */
	private static function format_capacity( $reserved, $maximum, $minimum ) {
		if ( ! $maximum ) {
			return sprintf(
				/* translators: 1: enrolled places, 2: minimum enrolment. */
				__( '%1$d enrolled (minimum %2$d)', 'tutorhelper-group-bookings' ),
				$reserved,
				$minimum
			);
		}

		return sprintf(
			/* translators: 1: enrolled places, 2: total places, 3: minimum enrolment. */
			__( '%1$d/%2$d enrolled (minimum %3$d)', 'tutorhelper-group-bookings' ),
			$reserved,
			$maximum,
			$minimum
		);
	}

	/** @return string */
	private static function format_price( $block, $total ) {
		$currency = strtoupper( sanitize_text_field( $block->currency ) );
		$price = class_exists( 'TutorHelper_Currency' )
			? TutorHelper_Currency::format_minor_units( absint( $total ), $currency )
			: $currency . ' ' . number_format_i18n( absint( $total ) / 100, 2 );

		if ( TutorHelper_Group_Blocks::PAYMENT_DEPOSIT === sanitize_key( $block->payment_mode ) ) {
			return sprintf(
				/* translators: %s: group block price. */
				__( '%s total — deposit available', 'tutorhelper-group-bookings' ),
				$price
			);
		}

		if ( TutorHelper_Group_Blocks::PAYMENT_FULL_UPFRONT === sanitize_key( $block->payment_mode ) ) {
			return sprintf(
				/* translators: %s: group block price. */
				__( '%s total — payment required when booking', 'tutorhelper-group-bookings' ),
				$price
			);
		}

		return sprintf(
			/* translators: %s: group block price. */
			__( '%s total — payment details sent after booking', 'tutorhelper-group-bookings' ),
			$price
		);
	}

	/** Enqueue the small public-card stylesheet. */
	private static function enqueue_assets() {
		$path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/css/group-lessons-public.css';
		wp_enqueue_style(
			'tutorhelper-group-lessons-public',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/css/group-lessons-public.css',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION
		);

		$script_path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/js/group-lessons-public-registration.js';
		wp_enqueue_script(
			'tutorhelper-group-lessons-public-registration',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/js/group-lessons-public-registration.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-group-lessons-public-registration',
			'tutorhelperGroupPublicRegistration',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'loadingLabel' => __( 'Loading booking form…', 'tutorhelper-group-bookings' ),
				'errorMessage' => __( 'The booking form could not be loaded. Please try again.', 'tutorhelper-group-bookings' ),
			)
		);
	}
}
