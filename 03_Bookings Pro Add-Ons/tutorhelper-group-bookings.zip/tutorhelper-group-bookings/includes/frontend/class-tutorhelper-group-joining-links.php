<?php
/**
 * Shared Group Session joining links for the student dashboard.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Appends confirmed Group Session joining links to the student dashboard.
 */
final class TutorHelper_Group_Joining_Links {

	/** Register dashboard integration. */
	public static function init() {
		add_filter(
			'do_shortcode_tag',
			array( __CLASS__, 'append_joining_links' ),
			40,
			4
		);
	}

	/**
	 * Append upcoming shared session links after the existing dashboard.
	 *
	 * @param string $output Shortcode output.
	 * @param string $tag Shortcode tag.
	 * @param array  $attr Shortcode attributes.
	 * @param array  $match Shortcode match.
	 * @return string
	 */
	public static function append_joining_links( $output, $tag, $attr, $match ) {
		unset( $attr, $match );

		if (
			! is_user_logged_in()
			|| ! class_exists( 'TutorHelper_Student_Dashboard_Shortcode' )
			|| TutorHelper_Student_Dashboard_Shortcode::SHORTCODE !== $tag
		) {
			return $output;
		}

		$student_id = get_current_user_id();
		if ( ! TutorHelper_Students::get_student( $student_id ) ) {
			return $output;
		}

		$rows = self::get_upcoming_sessions( $student_id );
		if ( empty( $rows ) ) {
			return $output;
		}

		self::enqueue_style();

		ob_start();
		?>
		<section
			class="tutorhelper-group-joining-links"
			aria-labelledby="tutorhelper-group-joining-links-heading"
		>
			<header class="tutorhelper-group-joining-links__header">
				<h2 id="tutorhelper-group-joining-links-heading">
					<?php esc_html_e( 'Upcoming Group Lesson links', 'tutorhelper-group-bookings' ); ?>
				</h2>
				<p>
					<?php esc_html_e( 'Everyone enrolled in the same Group Session uses the same joining link.', 'tutorhelper-group-bookings' ); ?>
				</p>
			</header>

			<div class="tutorhelper-group-joining-links__list">
				<?php foreach ( $rows as $row ) : ?>
					<article class="tutorhelper-group-joining-links__item">
						<div>
							<strong><?php echo esc_html( $row['title'] ); ?></strong>
							<span><?php echo esc_html( $row['date_time'] ); ?></span>
							<?php if ( '' !== $row['location_details'] ) : ?><small><?php echo wp_kses_post( nl2br( make_clickable( esc_html( $row['location_details'] ) ) ) ); ?></small><?php endif; ?>
						</div>

						<a
							class="tutorhelper-group-joining-links__button"
							href="<?php echo esc_url( $row['meeting_url'] ); ?>"
							target="_blank"
							rel="noopener noreferrer"
						>
							<?php echo esc_html( $row['label'] ); ?>
						</a>
					</article>
				<?php endforeach; ?>
			</div>
		</section>
		<?php

		return $output . ob_get_clean();
	}

	/**
	 * Return future confirmed sessions available to this student.
	 *
	 * @param int $student_id Student user ID.
	 * @return array
	 */
	private static function get_upcoming_sessions( $student_id ) {
		global $wpdb;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Student dashboard needs current shared session links.
			$wpdb->prepare(
				'SELECT DISTINCT session.id AS session_id,
					session.booking_start,
					session.meeting_url,
					session.location_details,
					block.location_details AS block_location_details,
					block.title,
					block.timezone
				FROM %i AS enrolment
				INNER JOIN %i AS block ON block.id = enrolment.block_id
				INNER JOIN %i AS session ON session.block_id = block.id
				WHERE enrolment.student_user_id = %d
				AND enrolment.status = %s
				AND block.status IN (%s, %s)
				AND session.status = %s
				AND session.booking_start > %s
				AND session.meeting_url != %s
				ORDER BY session.booking_start ASC',
				TutorHelper_Group_Enrolments::get_table_name(),
				TutorHelper_Group_Blocks::get_table_name(),
				TutorHelper_Group_Sessions::get_table_name(),
				absint( $student_id ),
				TutorHelper_Group_Enrolments::STATUS_SECURED,
				TutorHelper_Group_Blocks::STATUS_CONFIRMED,
				TutorHelper_Group_Blocks::STATUS_FULL,
				TutorHelper_Group_Sessions::STATUS_SCHEDULED,
				current_time( 'mysql', true ),
				''
			)
		);

		$prepared = array();
		foreach ( $rows as $row ) {
			$meeting_url = esc_url_raw( $row->meeting_url );
			if ( '' === $meeting_url ) {
				continue;
			}

			$prepared[] = array(
				'session_id' => absint( $row->session_id ),
				'title' => sanitize_text_field( $row->title ),
				'date_time' => self::format_session_datetime( $row->booking_start, $row->timezone ),
				'meeting_url' => $meeting_url,
				'label' => self::get_join_label( $meeting_url ),
				'location_details' => null !== $row->location_details
					? sanitize_textarea_field( $row->location_details )
					: sanitize_textarea_field( $row->block_location_details ),
			);
		}

		return $prepared;
	}

	/** Format one UTC session timestamp in the Group Block timezone. */
	private static function format_session_datetime( $booking_start, $timezone_name ) {
		try {
			$timezone = new DateTimeZone(
				in_array( $timezone_name, timezone_identifiers_list(), true )
					? $timezone_name
					: wp_timezone_string()
			);
			$value = new DateTimeImmutable(
				sanitize_text_field( $booking_start ),
				new DateTimeZone( 'UTC' )
			);
			$value = $value->setTimezone( $timezone );

			return wp_date(
				get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ),
				$value->getTimestamp(),
				$timezone
			);
		} catch ( Exception $exception ) {
			return '';
		}
	}

	/** Return a useful provider-specific button label from the shared URL. */
	private static function get_join_label( $meeting_url ) {
		$host = wp_parse_url( $meeting_url, PHP_URL_HOST );
		$host = is_string( $host ) ? strtolower( $host ) : '';

		if ( false !== strpos( $host, 'meet.google.com' ) ) {
			return __( 'Join Google Meet', 'tutorhelper-group-bookings' );
		}

		if ( false !== strpos( $host, 'zoom.' ) || false !== strpos( $host, 'zoom.us' ) ) {
			return __( 'Join Zoom Meeting', 'tutorhelper-group-bookings' );
		}

		return __( 'Join online lesson', 'tutorhelper-group-bookings' );
	}

	/** Load the small joining-link dashboard stylesheet. */
	private static function enqueue_style() {
		$path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/css/group-lessons-joining-links.css';

		wp_enqueue_style(
			'tutorhelper-group-lessons-joining-links',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/css/group-lessons-joining-links.css',
			array( 'tutorhelper-group-lessons-student' ),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION
		);
	}
}
