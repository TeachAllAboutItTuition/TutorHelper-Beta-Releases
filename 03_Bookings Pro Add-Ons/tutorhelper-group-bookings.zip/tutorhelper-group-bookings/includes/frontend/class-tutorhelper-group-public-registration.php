<?php
/**
 * Lightweight External student registration for public Group Lessons.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lets a visitor create an External student account before using the
 * established protected public Group Lesson enrolment route.
 */
final class TutorHelper_Group_Public_Registration {

	const ACTION = 'tutorhelper_group_public_register';
	const NONCE_ACTION = 'tutorhelper_group_public_register';
	const STATUS_QUERY_KEY = 'tutorhelper_group_registration';
	const STATUS_CREATED = 'created';
	const RATE_LIMIT_WINDOW = 15 * MINUTE_IN_SECONDS;
	const RATE_LIMIT_ATTEMPTS = 5;

	/**
	 * Register the public account-creation handler.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_nopriv_' . self::ACTION, array( __CLASS__, 'handle_registration' ) );
		add_filter( 'tutorhelper_group_public_registration_url', array( __CLASS__, 'get_registration_url' ), 10, 3 );
	}

	/**
	 * Return the registration prompt on the current public listing page.
	 *
	 * @param string $url         Default URL.
	 * @param int    $block_id    Group Block ID.
	 * @param string $destination Safe return URL.
	 * @return string
	 */
	public static function get_registration_url( $url, $block_id, $destination ) {
		unset( $url );

		return add_query_arg(
			array(
				'tutorhelper_open_group_register' => absint( $block_id ),
				'tutorhelper_open_group_return'   => rawurlencode(
					wp_validate_redirect( $destination, home_url( '/' ) )
				),
			),
			$destination
		);
	}

	/**
	 * Render a concise registration prompt for the selected public Group.
	 *
	 * @param int    $block_id   Group Block ID.
	 * @param string $return_url Safe public-listing URL.
	 * @return string
	 */
	public static function render_form( $block_id, $return_url ) {
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		$availability = TutorHelper_Group_Blocks::validate_public_booking( $block );

		if ( ! $block || is_wp_error( $availability ) ) {
			return self::render_error(
				is_wp_error( $availability )
					? $availability->get_error_message()
					: __( 'This Group Lesson is no longer available.', 'tutorhelper-group-bookings' )
			);
		}

		if ( is_user_logged_in() ) {
			return self::render_error(
				__( 'You are already signed in. Return to the Group Lesson to reserve your place.', 'tutorhelper-group-bookings' )
			);
		}

		$privacy_url = TutorHelper_Settings::get_privacy_url();
		$terms_url = (string) apply_filters(
			'tutorhelper_registration_terms_url',
			TutorHelper_Settings::get_terms_url()
		);

		if ( ! $privacy_url || ! $terms_url ) {
			return self::render_error(
				__( 'Registration is temporarily unavailable because the Privacy Policy and Terms and Conditions pages have not both been configured.', 'tutorhelper-group-bookings' )
			);
		}

		self::enqueue_assets();

		$login_url = self::get_login_url( $return_url );
		$notice = self::get_status_notice();

		ob_start();
		?>
		<section class="tutorhelper-public-registration tutorhelper-student-booking" aria-labelledby="tutorhelper-public-registration-heading">
			<header class="tutorhelper-public-registration__header tutorhelper-student-booking__header">
				<h2 id="tutorhelper-public-registration-heading" class="tutorhelper-student-booking__heading"><?php esc_html_e( 'Book this Group Lesson', 'tutorhelper-group-bookings' ); ?></h2>
				<p class="tutorhelper-student-booking__introduction">
					<?php
					printf(
						/* translators: %s: Group Lesson title. */
						esc_html__( 'Sign in or create a student account to book %s.', 'tutorhelper-group-bookings' ),
						esc_html( $block->title )
					);
					?>
				</p>
			</header>

			<?php echo wp_kses_post( $notice ); ?>

			<div class="tutorhelper-public-registration__existing-account tutorhelper-student-booking__panel">
				<h3><?php esc_html_e( 'Already have an account?', 'tutorhelper-group-bookings' ); ?></h3>
				<p><?php esc_html_e( 'Sign in first. You will return here to complete your Group Lesson booking.', 'tutorhelper-group-bookings' ); ?></p>
				<a class="button tutorhelper-ui-button tutorhelper-ui-button--secondary" href="<?php echo esc_url( $login_url ); ?>"><?php esc_html_e( 'Sign in to your account', 'tutorhelper-group-bookings' ); ?></a>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-public-registration__form tutorhelper-student-booking__panel">
				<h3 class="tutorhelper-student-booking__panel-heading"><?php esc_html_e( 'New to TutorHelper?', 'tutorhelper-group-bookings' ); ?></h3>
				<p><?php echo esc_html( self::get_new_account_description() ); ?></p>

				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
				<input type="hidden" name="block_id" value="<?php echo esc_attr( $block->id ); ?>" />
				<input type="hidden" name="return_url" value="<?php echo esc_url( $return_url ); ?>" />
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>

				<div class="tutorhelper-public-registration__grid">
					<label>
						<span><?php esc_html_e( 'First name', 'tutorhelper-group-bookings' ); ?></span>
						<input type="text" name="first_name" autocomplete="given-name" required />
					</label>
					<label>
						<span><?php esc_html_e( 'Last name', 'tutorhelper-group-bookings' ); ?></span>
						<input type="text" name="last_name" autocomplete="family-name" required />
					</label>
				</div>

				<label>
					<span><?php esc_html_e( 'Email address', 'tutorhelper-group-bookings' ); ?></span>
					<input type="email" name="email" autocomplete="email" required />
				</label>

				<div class="tutorhelper-public-registration__grid">
					<label>
						<span><?php esc_html_e( 'Password', 'tutorhelper-group-bookings' ); ?></span>
						<input type="password" name="password" autocomplete="new-password" minlength="12" data-tutorhelper-public-password required />
					</label>
					<label>
						<span><?php esc_html_e( 'Confirm password', 'tutorhelper-group-bookings' ); ?></span>
						<input type="password" name="password_confirm" autocomplete="new-password" minlength="12" data-tutorhelper-public-password required />
					</label>
				</div>

				<label class="tutorhelper-ui-option-row tutorhelper-public-registration__password-toggle">
					<input type="checkbox" value="1" data-tutorhelper-password-toggle />
					<span><?php esc_html_e( 'Show passwords', 'tutorhelper-group-bookings' ); ?></span>
				</label>

				<div class="tutorhelper-public-registration__honeypot" aria-hidden="true">
					<label>
						<?php esc_html_e( 'Website', 'tutorhelper-group-bookings' ); ?>
						<input type="text" name="website" tabindex="-1" autocomplete="off" />
					</label>
				</div>

				<label class="tutorhelper-ui-option-row">
					<input type="checkbox" name="privacy_acknowledged" value="1" required />
					<span>
						<?php
						printf(
							/* translators: %s: Privacy Policy URL. */
							wp_kses_post( __( 'I have read the <a href="%s" target="_blank" rel="noopener noreferrer">Privacy Policy</a>.', 'tutorhelper-group-bookings' ) ),
							esc_url( $privacy_url )
						);
						?>
					</span>
				</label>

				<label class="tutorhelper-ui-option-row">
					<input type="checkbox" name="terms_agreed" value="1" required />
					<span>
						<?php
						printf(
							/* translators: %s: Terms and Conditions URL. */
							wp_kses_post( __( 'I agree to the <a href="%s" target="_blank" rel="noopener noreferrer">Terms and Conditions</a>.', 'tutorhelper-group-bookings' ) ),
							esc_url( $terms_url )
						);
						?>
					</span>
				</label>

				<button type="submit" class="button tutorhelper-ui-button tutorhelper-ui-button--primary">
					<?php esc_html_e( 'Create account and continue', 'tutorhelper-group-bookings' ); ?>
				</button>
			</form>
		</section>
		<?php

		return ob_get_clean();
	}

	/**
	 * Describe the standard tuition route without exposing restricted bookings.
	 *
	 * A site may use the same filter as its standard registration flow to state
	 * that regular tuition registrations join a waiting list.
	 *
	 * @return string
	 */
	private static function get_new_account_description() {
		$waiting_list = class_exists( 'TutorHelper_Pro_Registration_Settings' )
			&& defined( 'TutorHelper_Pro_Registration_Settings::STATUS_WAITING_LIST' )
			&& TutorHelper_Pro_Registration_Settings::STATUS_WAITING_LIST === TutorHelper_Pro_Registration_Settings::get_status();
		$waiting_list = (bool) apply_filters( 'tutorhelper_group_public_registration_uses_waiting_list', $waiting_list );

		if ( $waiting_list ) {
			return __( 'Create a basic student account for Group Lessons. You can request a place on my waiting list for regular lessons or individual tuition through your student dashboard.', 'tutorhelper-group-bookings' );
		}

		return __( 'Create a basic student account for Group Lessons. You can request a place for regular lessons or individual tuition through your student dashboard.', 'tutorhelper-group-bookings' );
	}

	/**
	 * Create an External student account without creating a Group place or
	 * starting payment. Booking remains an explicit second action.
	 *
	 * @return void
	 */
	public static function handle_registration() {
		$return_url = self::get_return_url();
		$block_id = self::get_posted_id( 'block_id' );

		if ( 'POST' !== strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
			self::redirect_with_notice( $return_url, 'error', __( 'The registration request could not be processed. Please try again.', 'tutorhelper-group-bookings' ) );
		}

		check_admin_referer( self::NONCE_ACTION );

		if ( is_user_logged_in() ) {
			self::redirect_with_notice( $return_url, 'error', __( 'You are already signed in. Please return to the Group Lesson to reserve your place.', 'tutorhelper-group-bookings' ) );
		}

		if ( ! self::external_status_is_available() ) {
			TutorHelper_Logger::error(
				'Public Group Lesson registration could not use the External student status.',
				array( 'block_id' => $block_id )
			);
			self::redirect_with_notice( $return_url, 'error', __( 'Registration is temporarily unavailable. Please contact the tutor.', 'tutorhelper-group-bookings' ) );
		}

		if ( self::is_rate_limited() || '' !== self::get_posted_text( 'website' ) ) {
			self::redirect_with_notice( $return_url, 'error', __( 'We could not create your account. Please try again later.', 'tutorhelper-group-bookings' ) );
		}

		if ( ! self::has_required_policies() ) {
			self::redirect_with_notice( $return_url, 'error', __( 'Registration is temporarily unavailable because the Privacy Policy and Terms and Conditions pages have not both been configured.', 'tutorhelper-group-bookings' ) );
		}

		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		$availability = TutorHelper_Group_Blocks::validate_public_booking( $block );

		if ( ! $block || is_wp_error( $availability ) ) {
			self::redirect_with_notice(
				$return_url,
				'error',
				is_wp_error( $availability )
					? $availability->get_error_message()
					: __( 'This Group Lesson is no longer available.', 'tutorhelper-group-bookings' )
			);
		}

		$first_name = self::get_posted_text( 'first_name' );
		$last_name = self::get_posted_text( 'last_name' );
		$email = sanitize_email( self::get_posted_text( 'email' ) );
		$password = self::get_posted_password( 'password' );
		$password_confirm = self::get_posted_password( 'password_confirm' );
		$privacy_acknowledged = self::get_posted_checkbox( 'privacy_acknowledged' );
		$terms_agreed = self::get_posted_checkbox( 'terms_agreed' );

		if (
			'' === $first_name
			|| '' === $last_name
			|| ! is_email( $email )
			|| strlen( $password ) < 12
			|| $password !== $password_confirm
			|| ! $privacy_acknowledged
			|| ! $terms_agreed
		) {
			self::redirect_with_notice( $return_url, 'error', __( 'Complete all required fields and use matching passwords of at least 12 characters.', 'tutorhelper-group-bookings' ) );
		}

		if ( email_exists( $email ) ) {
			self::redirect_with_notice(
				$return_url,
				'error',
				__( 'An account already exists for this email address. Please sign in to continue.', 'tutorhelper-group-bookings' )
			);
		}

		$user_id = wp_insert_user(
			array(
				'user_login'   => self::get_unique_login( $email ),
				'user_email'   => $email,
				'user_pass'    => $password,
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => trim( $first_name . ' ' . $last_name ),
				'role'         => TutorHelper_Students::STUDENT_ROLE,
			)
		);

		if ( is_wp_error( $user_id ) ) {
			TutorHelper_Logger::error(
				'Public Group Lesson External account creation failed.',
				array(
					'block_id'   => $block_id,
					'error_code' => $user_id->get_error_code(),
				)
			);
			self::redirect_with_notice( $return_url, 'error', __( 'Your account could not be created. Please try again.', 'tutorhelper-group-bookings' ) );
		}

		$status = TutorHelper_Students::set_account_status(
			$user_id,
			TutorHelper_Students::STATUS_EXTERNAL
		);

		if ( is_wp_error( $status ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( $user_id );

			TutorHelper_Logger::error(
				'Public Group Lesson External account status could not be saved.',
				array(
					'block_id'        => $block_id,
					'student_user_id' => $user_id,
					'error_code'      => $status->get_error_code(),
				)
			);
			self::redirect_with_notice( $return_url, 'error', __( 'Your account could not be created. Please try again.', 'tutorhelper-group-bookings' ) );
		}

		update_user_meta( $user_id, 'tutorhelper_group_external_privacy_acknowledged_at', current_time( 'mysql', true ) );
		update_user_meta( $user_id, 'tutorhelper_group_external_terms_agreed_at', current_time( 'mysql', true ) );
		update_user_meta( $user_id, 'tutorhelper_group_external_pending_block_id', $block_id );

		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, true );

		do_action( 'tutorhelper_group_external_student_registered', $user_id, $block_id );

		$return_url = add_query_arg(
			array(
				self::STATUS_QUERY_KEY => self::STATUS_CREATED,
				'tutorhelper_open_group' => $block_id,
			),
			remove_query_arg(
				array( 'tutorhelper_open_group_register', 'tutorhelper_open_group_return' ),
				$return_url
			)
		);

		wp_safe_redirect( $return_url );
		exit;
	}

	/**
	 * Render a consistent escaped error panel.
	 *
	 * @param string $message Error message.
	 * @return string
	 */
	private static function render_error( $message ) {
		return '<div class="tutorhelper-public-groups__notice tutorhelper-public-groups__notice--error" role="alert">'
			. esc_html( $message )
			. '</div>';
	}

	/**
	 * Queue assets only while the public registration prompt is rendered.
	 *
	 * @return void
	 */
	private static function enqueue_assets() {
		$path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/js/group-lessons-public-registration.js';

		wp_enqueue_script(
			'tutorhelper-group-lessons-public-registration',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/js/group-lessons-public-registration.js',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION,
			true
		);
	}

	/**
	 * Get the configured student-login page with this listing as its return.
	 *
	 * @param string $return_url Safe return URL.
	 * @return string
	 */
	private static function get_login_url( $return_url ) {
		$login_url = TutorHelper_Settings::get_login_url();

		if ( ! $login_url ) {
			$login_url = wp_login_url( $return_url );
		}

		return add_query_arg(
			'redirect_to',
			rawurlencode( wp_validate_redirect( $return_url, home_url( '/' ) ) ),
			$login_url
		);
	}

	/**
	 * @return string
	 */
	private static function get_return_url() {
		return isset( $_POST['return_url'] ) && ! is_array( $_POST['return_url'] )
			? wp_validate_redirect( wp_unslash( $_POST['return_url'] ), home_url( '/' ) )
			: home_url( '/' );
	}

	/**
	 * @param string $key Field name.
	 * @return int
	 */
	private static function get_posted_id( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] )
			? absint( wp_unslash( $_POST[ $key ] ) )
			: 0;
	}

	/**
	 * @param string $key Field name.
	 * @return string
	 */
	private static function get_posted_text( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] )
			? sanitize_text_field( wp_unslash( $_POST[ $key ] ) )
			: '';
	}

	/**
	 * Passwords must not be sanitised because that changes the credential.
	 *
	 * @param string $key Field name.
	 * @return string
	 */
	private static function get_posted_password( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] )
			? (string) wp_unslash( $_POST[ $key ] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords are intentionally preserved for wp_insert_user() after validation.
			: '';
	}

	/**
	 * @param string $key Field name.
	 * @return bool
	 */
	private static function get_posted_checkbox( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) && '1' === wp_unslash( $_POST[ $key ] );
	}

	/**
	 * Confirm Core's External-status API is available before account creation.
	 *
	 * @return bool
	 */
	private static function external_status_is_available() {
		return class_exists( 'TutorHelper_Students' )
			&& defined( 'TutorHelper_Students::STATUS_EXTERNAL' )
			&& method_exists( 'TutorHelper_Students', 'set_account_status' );
	}

	/**
	 * Confirm both mandatory policy pages are configured.
	 *
	 * @return bool
	 */
	private static function has_required_policies() {
		$privacy_url = TutorHelper_Settings::get_privacy_url();
		$terms_url = (string) apply_filters(
			'tutorhelper_registration_terms_url',
			TutorHelper_Settings::get_terms_url()
		);

		return (bool) ( $privacy_url && $terms_url );
	}

	/**
	 * Apply a short-lived anonymous registration-attempt limit.
	 *
	 * @return bool
	 */
	private static function is_rate_limited() {
		$address = isset( $_SERVER['REMOTE_ADDR'] )
			? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
			: '';

		if ( '' === $address ) {
			return false;
		}

		$key = 'tutorhelper_group_register_' . substr(
			hash_hmac( 'sha256', $address, wp_salt( 'nonce' ) ),
			0,
			32
		);
		$attempts = absint( get_transient( $key ) );

		set_transient( $key, $attempts + 1, self::RATE_LIMIT_WINDOW );

		return $attempts >= self::RATE_LIMIT_ATTEMPTS;
	}

	/**
	 * Generate a unique WordPress login from the supplied email address.
	 *
	 * @param string $email Valid email address.
	 * @return string
	 */
	private static function get_unique_login( $email ) {
		$base = sanitize_user( strtok( $email, '@' ), true );
		$base = '' !== $base ? $base : 'student';
		$login = $base;
		$number = 1;

		while ( username_exists( $login ) ) {
			$login = $base . $number;
			++$number;
		}

		return $login;
	}

	/**
	 * Redirect safely to the public listing with a short notice.
	 *
	 * @param string $return_url Destination URL.
	 * @param string $type       Notice type.
	 * @param string $message    Notice content.
	 * @return void
	 */
	private static function redirect_with_notice( $return_url, $type, $message ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'tutorhelper_group_notice'  => sanitize_key( $type ),
					'tutorhelper_group_message' => rawurlencode( sanitize_text_field( $message ) ),
				),
				$return_url
			)
		);
		exit;
	}

	/**
	 * Read the public registration status notice.
	 *
	 * @return string
	 */
	private static function get_status_notice() {
		$status = isset( $_GET[ self::STATUS_QUERY_KEY ] ) && ! is_array( $_GET[ self::STATUS_QUERY_KEY ] )
			? sanitize_key( wp_unslash( $_GET[ self::STATUS_QUERY_KEY ] ) )
			: '';

		if ( self::STATUS_CREATED !== $status ) {
			return '';
		}

		return '<div class="tutorhelper-public-groups__notice tutorhelper-public-groups__notice--success" role="status">'
			. esc_html__( 'Your student account is ready. You can now reserve this Group Lesson place.', 'tutorhelper-group-bookings' )
			. '</div>';
	}
}
