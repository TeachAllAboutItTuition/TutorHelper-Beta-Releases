<?php
/**
 * Group Session actions inside Core/Pro student lesson views.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Places Group-specific links and notices on the matching child lesson. */
final class TutorHelper_Group_Dashboard_Actions {

	/** Register dashboard, calendar and visibility hooks. */
	public static function init() {
		self::migrate_legacy_expired_checkouts();
		add_action( 'tutorhelper_student_dashboard_booking_actions', array( __CLASS__, 'render_booking_actions' ), 10, 2 );
		add_filter( 'tutorhelper_student_dashboard_booking_visible', array( __CLASS__, 'filter_visible_booking' ), 10, 3 );
		add_filter( 'tutorhelper_calendar_booking_visible', array( __CLASS__, 'filter_calendar_booking' ), 10, 2 );
	}

	/** Mark G8-era unpaid expiry cancellations so every UI can treat them consistently. */
	private static function migrate_legacy_expired_checkouts() {
		if ( get_option( 'tutorhelper_group_g9_expired_checkout_migrated', false ) ) {
			return;
		}
		global $wpdb;
		$now = current_time( 'mysql', true );
		$enrolments = TutorHelper_Group_Enrolments::get_table_name();
		$links = TutorHelper_Group_Enrolment_Bookings::get_table_name();
		$bookings = TutorHelper_Booking_Records::get_table_name();
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$wpdb->prepare(
				'UPDATE %i b INNER JOIN %i l ON l.booking_id=b.id INNER JOIN %i e ON e.id=l.enrolment_id
				SET b.price_minor_units=0, b.cancellation_reason=%s, b.cancelled_by=%s, b.updated_at=%s
				WHERE e.status=%s AND e.amount_paid_minor_units=0 AND (e.cancellation_reason IS NULL OR e.cancellation_reason=%s)
				AND (e.cancelled_by IS NULL OR e.cancelled_by=%s) AND b.status=%s',
				$bookings,
				$links,
				$enrolments,
				'stripe_checkout_expired',
				'system',
				$now,
				TutorHelper_Group_Enrolments::STATUS_CANCELLED,
				'',
				'',
				TutorHelper_Booking_Records::STATUS_CANCELLED
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time repair of legacy machine-cancelled rows.
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$wpdb->prepare(
				'UPDATE %i SET cancellation_reason=%s, cancelled_by=%s, updated_at=%s
				WHERE status=%s AND amount_paid_minor_units=0 AND (cancellation_reason IS NULL OR cancellation_reason=%s) AND (cancelled_by IS NULL OR cancelled_by=%s)',
				$enrolments,
				'stripe_checkout_expired',
				'system',
				$now,
				TutorHelper_Group_Enrolments::STATUS_CANCELLED,
				'',
				''
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time repair of legacy machine-cancelled rows.
		update_option( 'tutorhelper_group_g9_expired_checkout_migrated', 1, false );
	}

	/** Hide only machine-cancelled, wholly unpaid Stripe-expiry records. */
	public static function filter_visible_booking( $visible, $booking, $section ) {
		unset( $section );
		return $visible && ! self::is_expired_checkout_booking( $booking );
	}

	/** Hide Stripe-expired Group children from the tutor calendar. */
	public static function filter_calendar_booking( $visible, $booking ) {
		return $visible && ! self::is_expired_checkout_booking( $booking );
	}

	/** Render the shared join link and reschedule decision on one child lesson. */
	public static function render_booking_actions( $booking, $section_type ) {
		unset( $section_type );
		$booking_id = is_array( $booking ) && ! empty( $booking['id'] )
			? absint( $booking['id'] )
			: ( is_object( $booking ) && ! empty( $booking->id ) ? absint( $booking->id ) : 0 );
		if ( ! $booking_id || ! is_user_logged_in() ) {
			return;
		}

		$context = self::get_context( $booking_id );
		if ( ! $context || absint( $context->student_user_id ) !== get_current_user_id() ) {
			return;
		}

		if (
			TutorHelper_Group_Enrolments::STATUS_SECURED === sanitize_key( $context->enrolment_status )
			&& TutorHelper_Group_Sessions::STATUS_SCHEDULED === sanitize_key( $context->session_status )
			&& ! empty( $context->meeting_url )
		) {
			?>
			<a class="button tutorhelper-group-lesson__join" href="<?php echo esc_url( $context->meeting_url ); ?>" target="_blank" rel="noopener noreferrer">
				<?php echo esc_html( self::get_join_label( $context->meeting_url ) ); ?>
			</a>
			<?php
		}

		$response = self::get_pending_response( $context->session_id, $context->enrolment_id );
		if ( ! $response ) {
			return;
		}
		?>
		<details class="tutorhelper-group-lesson__change" open>
			<summary><span aria-hidden="true">⚠</span> <?php esc_html_e( 'This Group Lesson was rescheduled', 'tutorhelper-group-bookings' ); ?></summary>
			<?php if ( ! empty( $context->change_reason ) ) : ?>
				<p><?php echo esc_html( $context->change_reason ); ?></p>
			<?php endif; ?>
			<p><?php esc_html_e( 'Please confirm whether you can attend the new time.', 'tutorhelper-group-bookings' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( TutorHelper_Group_Cancellations::RESPONSE_ACTION ); ?>" />
				<input type="hidden" name="response_id" value="<?php echo esc_attr( $response->id ); ?>" />
				<?php wp_nonce_field( TutorHelper_Group_Cancellations::RESPONSE_ACTION . '_' . absint( $response->id ) ); ?>
				<button type="submit" class="button" name="response" value="attending"><?php esc_html_e( 'I can attend', 'tutorhelper-group-bookings' ); ?></button>
				<button type="submit" class="button" name="response" value="credit"><?php esc_html_e( 'I cannot attend — apply lesson credit', 'tutorhelper-group-bookings' ); ?></button>
			</form>
		</details>
		<?php
	}

	/** Return the Group relationship for one Core booking. */
	private static function get_context( $booking_id ) {
		global $wpdb;
		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$wpdb->prepare(
				'SELECT l.session_id, l.enrolment_id, l.student_user_id,
					e.status AS enrolment_status, s.status AS session_status,
					s.meeting_url, s.change_reason
				FROM %i l
				INNER JOIN %i e ON e.id=l.enrolment_id
				INNER JOIN %i s ON s.id=l.session_id
				WHERE l.booking_id=%d',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				TutorHelper_Group_Enrolments::get_table_name(),
				TutorHelper_Group_Sessions::get_table_name(),
				absint( $booking_id )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Dashboard actions must reflect current Group state.
	}

	/** Return the student's unresolved decision for this reschedule. */
	private static function get_pending_response( $session_id, $enrolment_id ) {
		global $wpdb;
		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE session_id=%d AND enrolment_id=%d AND student_user_id=%d AND response_status=%s',
				TutorHelper_Group_Bookings_Database::get_table_name( 'session_responses' ),
				absint( $session_id ),
				absint( $enrolment_id ),
				get_current_user_id(),
				'pending'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- A response action must use current state.
	}

	/** Identify the machine-generated cancellation marker. */
	private static function is_expired_checkout_booking( $booking ) {
		$reason = is_object( $booking ) && isset( $booking->cancellation_reason )
			? $booking->cancellation_reason
			: ( is_array( $booking ) && isset( $booking['cancellation_reason'] ) ? $booking['cancellation_reason'] : '' );
		return 'stripe_checkout_expired' === sanitize_key( $reason );
	}

	/** Return a provider-specific joining label. */
	private static function get_join_label( $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		if ( false !== strpos( $host, 'meet.google.com' ) ) {
			return __( 'Join Google Meet', 'tutorhelper-group-bookings' );
		}
		if ( false !== strpos( $host, 'zoom.' ) || false !== strpos( $host, 'zoom.us' ) ) {
			return __( 'Join Zoom lesson', 'tutorhelper-group-bookings' );
		}
		return __( 'Join online lesson', 'tutorhelper-group-bookings' );
	}
}
