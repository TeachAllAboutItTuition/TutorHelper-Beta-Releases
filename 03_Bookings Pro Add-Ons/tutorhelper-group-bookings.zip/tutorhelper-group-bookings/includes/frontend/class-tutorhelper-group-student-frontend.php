<?php
/**
 * Student-facing Group Lesson enrolment and dashboard.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Replaces individual slot selection with eligible Group Lesson blocks.
 */
final class TutorHelper_Group_Student_Frontend {

	const JOIN_ACTION = 'tutorhelper_group_join_block';
	const NONCE_ACTION = 'tutorhelper_group_student_enrolment';

	/** Register frontend hooks. */
	public static function init() {
		add_filter( 'do_shortcode_tag', array( __CLASS__, 'filter_shortcode_output' ), 20, 4 );
		add_action( 'wp_ajax_' . self::JOIN_ACTION, array( __CLASS__, 'handle_join_block' ) );
	}

	/**
	 * Enhance Core booking and dashboard shortcodes.
	 *
	 * @param string $output Shortcode output.
	 * @param string $tag Shortcode tag.
	 * @param array  $attr Shortcode attributes.
	 * @param array  $match Shortcode parser match.
	 * @return string
	 */
	public static function filter_shortcode_output( $output, $tag, $attr, $match ) {
		unset( $attr, $match );

		if ( TutorHelper_Student_Booking_Shortcode::SHORTCODE === $tag ) {
			self::enqueue_assets();
			$payment_return = isset( $_GET['group_payment'] ) && ! is_array( $_GET['group_payment'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Stripe return display state only.
				? sanitize_key( wp_unslash( $_GET['group_payment'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Stripe return display state only.
				: '';

			if ( 'success' === $payment_return ) {
				$output = '<div class="tutorhelper-group-student__success" role="status">' . esc_html__( 'Stripe has accepted your payment. Your Group Lesson dashboard will update once the verified payment is processed.', 'tutorhelper-group-bookings' ) . '</div>' . $output;
			} elseif ( 'cancelled' === $payment_return ) {
				$output = '<div class="tutorhelper-group-student__minimum" role="status">' . esc_html__( 'Stripe Checkout was cancelled and no payment was recorded. An unpaid new place has been released; an existing part-paid enrolment remains active.', 'tutorhelper-group-bookings' ) . '</div>' . $output;
			}

			return $output;
		}

		if (
			class_exists( 'TutorHelper_Student_Dashboard_Shortcode' )
			&& TutorHelper_Student_Dashboard_Shortcode::SHORTCODE === $tag
			&& is_user_logged_in()
		) {
			self::enqueue_assets();

			if (
				method_exists( 'TutorHelper_Students', 'is_external_student' )
				&& TutorHelper_Students::is_external_student( get_current_user_id() )
			) {
				return $output
					. self::render_external_student_notice()
					. TutorHelper_Group_Public_Discovery::render_shortcode( array() )
					. self::render_dashboard();
			}

			return $output . self::render_dashboard();
		}

		return $output;
	}

	/**
	 * Explain the deliberately restricted External account to its owner.
	 *
	 * @return string
	 */
	private static function render_external_student_notice() {
		return '<section class="tutorhelper-group-dashboard tutorhelper-group-dashboard--external" aria-labelledby="tutorhelper-group-external-heading">'
			. '<header class="tutorhelper-group-dashboard__header">'
			. '<h2 id="tutorhelper-group-external-heading">'
			. esc_html__( 'Open Group Lessons', 'tutorhelper-group-bookings' )
			. '</h2>'
			. '</header>'
			. '<p>'
			. esc_html__( 'Your account currently gives you access to open Group Lessons only. Contact your tutor if you would like to discuss other tuition options.', 'tutorhelper-group-bookings' )
			. '</p>'
			. '</section>';
	}

	/** Enqueue the Group block selector. */
	private static function enqueue_assets() {
		$script_path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/js/group-lessons-student.js';
		$style_path = TUTORHELPER_GROUP_BOOKINGS_PATH . 'assets/css/group-lessons-student.css';

		$style_version = file_exists( $style_path ) ? md5_file( $style_path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION;
		$script_version = file_exists( $script_path ) ? md5_file( $script_path ) : TUTORHELPER_GROUP_BOOKINGS_VERSION;

		wp_enqueue_style(
			'tutorhelper-group-lessons-student',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/css/group-lessons-student.css',
			array( 'tutorhelper-student-booking' ),
			$style_version
		);
		wp_enqueue_script(
			'tutorhelper-group-lessons-student',
			TUTORHELPER_GROUP_BOOKINGS_URL . 'assets/js/group-lessons-student.js',
			array(),
			$script_version,
			true
		);

		$student_user_id = self::get_booking_context_student_id();
		$data = self::get_booking_form_data( $student_user_id );
		$data['studentUserId'] = $student_user_id;
		$data['ajaxUrl'] = admin_url( 'admin-ajax.php' );
		$data['nonce'] = wp_create_nonce( self::NONCE_ACTION );
		$data['isPreview'] = current_user_can( 'manage_options' ) && ! TutorHelper_Students::get_student( get_current_user_id() );
		$data['messages'] = array(
			'empty' => __( 'There are no Group Lesson blocks currently available for you.', 'tutorhelper-group-bookings' ),
			'joining' => __( 'Joining Group Lesson…', 'tutorhelper-group-bookings' ),
			'error' => __( 'The Group Lesson could not be joined. Please try again.', 'tutorhelper-group-bookings' ),
			'preview' => __( 'Preview mode shows available blocks, but cannot create an enrolment.', 'tutorhelper-group-bookings' ),
		);

		wp_localize_script(
			'tutorhelper-group-lessons-student',
			'TutorHelperGroupStudent',
			$data
		);
	}

	/**
	 * Return the authorised student for the current Core booking form.
	 *
	 * Parent/Child may safely substitute a linked child through Core's
	 * booking context. Falling back preserves the normal student flow.
	 *
	 * @return int
	 */
	private static function get_booking_context_student_id() {
		if ( class_exists( 'TutorHelper_Student_Booking_Context' ) ) {
			$context = TutorHelper_Student_Booking_Context::resolve();
			if ( ! is_wp_error( $context ) ) {
				return absint( $context['student_user_id'] );
			}
		}

		return absint( get_current_user_id() );
	}

	/**
	 * Prepare visible Group Blocks keyed by Booking Type.
	 *
	 * @param int $student_user_id Student ID.
	 * @return array
	 */
	private static function get_booking_form_data( $student_user_id ) {
		$blocks_by_type = array();
		$group_type_ids = array();
		$student_user_id = absint( $student_user_id );
		$open_statuses = array(
			TutorHelper_Group_Blocks::STATUS_OPEN,
			TutorHelper_Group_Blocks::STATUS_AWAITING_MINIMUM,
			TutorHelper_Group_Blocks::STATUS_CONFIRMED,
			TutorHelper_Group_Blocks::STATUS_FULL,
		);

		foreach ( TutorHelper_Group_Blocks::get_all() as $block ) {
			if ( ! in_array( sanitize_key( $block->status ), $open_statuses, true ) ) {
				continue;
			}

			$type_id = absint( $block->booking_type_id );
			$group_type_ids[ $type_id ] = $type_id;

			if (
				! $student_user_id
				|| ! TutorHelper_Pro_Groups::student_is_in_group( $block->group_id, $student_user_id )
			) {
				continue;
			}

			$existing = TutorHelper_Group_Enrolments::get_for_student( $block->id, $student_user_id );
			$reserved = TutorHelper_Group_Enrolments::count_reserved_places( $block->id );
			$maximum = null !== $block->max_enrolments ? absint( $block->max_enrolments ) : 0;
			$spaces = $maximum ? max( 0, $maximum - $reserved ) : null;
			$sessions = TutorHelper_Group_Sessions::get_for_block( $block->id );
			$total = TutorHelper_Group_Blocks::calculate_block_total( $block, count( $sessions ) );

			$booking_window_message = TutorHelper_Group_Blocks::get_booking_window_message( $block );

			$blocks_by_type[ $type_id ][] = array(
				'id' => absint( $block->id ),
				'title' => sanitize_text_field( $block->title ),
				'startDate' => self::format_date( $block->start_date ),
				'endDate' => self::format_date( $block->end_date ),
				'dayOfWeek' => self::format_day_of_week( $block->start_date ),
				'time' => self::format_time( $block->start_time ),
				'duration' => self::format_duration( $block->start_time, $block->end_time ),
				'frequency' => sanitize_key( $block->frequency ),
				'isBookable' => '' === $booking_window_message,
				'bookingWindowMessage' => $booking_window_message,
				'sessionCount' => count( $sessions ),
				'total' => self::format_money( $total, $block->currency ),
				'paymentMode' => sanitize_key( $block->payment_mode ),
				'deposit' => self::format_deposit( $block, $total ),
				'spaces' => $spaces,
				'isFull' => null !== $spaces && 0 === $spaces,
				'isEnrolled' => (bool) $existing,
				'awaitingMinimum' => TutorHelper_Group_Blocks::STATUS_AWAITING_MINIMUM === sanitize_key( $block->status ),
				'location' => sanitize_text_field( $block->location_type ),
			);
		}

		return array(
			'groupBookingTypeIds' => array_values( $group_type_ids ),
			'blocksByType' => $blocks_by_type,
		);
	}

	/** Join a Group Block from the student booking form. */
	public static function handle_join_block() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$booking_context = class_exists( 'TutorHelper_Student_Booking_Context' )
			? TutorHelper_Student_Booking_Context::resolve()
			: new WP_Error(
				'tutorhelper_group_booking_context_unavailable',
				__( 'Lesson booking is currently unavailable.', 'tutorhelper-group-bookings' )
			);

		if ( is_wp_error( $booking_context ) ) {
			wp_send_json_error(
				array( 'message' => $booking_context->get_error_message() ),
				403
			);
		}

		$student_id = absint( $booking_context['student_user_id'] );
		$student = TutorHelper_Students::get_student( $student_id );
		if ( ! $student instanceof WP_User ) {
			wp_send_json_error(
				array( 'message' => __( 'Only registered students can join a Group Lesson.', 'tutorhelper-group-bookings' ) ),
				403
			);
		}

		$block_id = isset( $_POST['block_id'] ) && ! is_array( $_POST['block_id'] )
			? absint( wp_unslash( $_POST['block_id'] ) )
			: 0;
		$result = TutorHelper_Group_Enrolments::enrol_student( $block_id, $student_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
					'code' => $result->get_error_code(),
				),
				400
			);
		}

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $result );
		$response = array(
			'enrolmentId' => absint( $result ),
			'redirectUrl' => '',
			'message' => __( 'You have joined the Group Lesson block.', 'tutorhelper-group-bookings' ),
		);

		if ( $enrolment && TutorHelper_Group_Stripe::can_start_checkout( $enrolment ) ) {
			$checkout = TutorHelper_Group_Stripe::create_checkout(
				$enrolment->id,
				wp_get_referer()
			);
			if ( is_wp_error( $checkout ) ) {
				wp_send_json_error(
					array(
						'message' => $checkout->get_error_message(),
						'code' => $checkout->get_error_code(),
					),
					400
				);
			}

			$response['redirectUrl'] = esc_url_raw( $checkout['url'] );
			$response['message'] = __( 'Taking you to secure payment…', 'tutorhelper-group-bookings' );
		}

		wp_send_json_success( $response );
	}

	/**
	 * Render Group Lesson enrolments beneath the Core dashboard.
	 *
	 * @return string
	 */
	private static function render_dashboard() {
		global $wpdb;

		$student_id = get_current_user_id();
		if ( ! TutorHelper_Students::get_student( $student_id ) ) {
			return '';
		}

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Dashboard requires current enrolment state.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE student_user_id = %d AND status != %s ORDER BY joined_at DESC',
				TutorHelper_Group_Enrolments::get_table_name(),
				$student_id,
				TutorHelper_Group_Enrolments::STATUS_CANCELLED
			)
		);

		if ( empty( $rows ) ) {
			return '';
		}

		ob_start();
		?>
		<section class="tutorhelper-group-dashboard" aria-labelledby="tutorhelper-group-dashboard-heading">
			<header class="tutorhelper-group-dashboard__header">
				<h2 id="tutorhelper-group-dashboard-heading"><?php esc_html_e( 'My Group Lessons', 'tutorhelper-group-bookings' ); ?></h2>
			</header>
			<div class="tutorhelper-group-dashboard__grid">
				<?php foreach ( $rows as $enrolment ) : ?>
					<?php
					TutorHelper_Group_Payments::reconcile_enrolment( $enrolment->id );
					$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment->id );
					$block = TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id );
					if ( ! $block ) {
						continue;
					}
					$payment = TutorHelper_Group_Payments::get_summary( $enrolment );
					$confirmed = in_array(
						sanitize_key( $block->status ),
						array( TutorHelper_Group_Blocks::STATUS_CONFIRMED, TutorHelper_Group_Blocks::STATUS_FULL ),
						true
					);
					$checkout = TutorHelper_Group_Stripe::get_checkout_details( $enrolment, $payment );
					?>
					<article class="tutorhelper-group-dashboard__card">
						<h3><?php echo esc_html( $block->title ); ?></h3>
						<p><strong><?php echo esc_html( self::format_date( $block->start_date ) . ' – ' . self::format_date( $block->end_date ) ); ?></strong><br /><?php echo esc_html( self::format_time( $block->start_time ) ); ?></p>
						<?php if ( ! $confirmed ) : ?>
							<p class="tutorhelper-group-dashboard__notice"><?php esc_html_e( 'Awaiting minimum enrolment. Your place is recorded, and we will confirm the sessions once enough students have joined.', 'tutorhelper-group-bookings' ); ?></p>
						<?php else : ?>
							<p class="tutorhelper-group-dashboard__confirmed"><?php esc_html_e( 'Your Group Lesson sessions are confirmed.', 'tutorhelper-group-bookings' ); ?></p>
							<?php $sessions = TutorHelper_Group_Sessions::get_for_block( $block->id ); ?>
							<?php if ( ! empty( $sessions ) ) : ?>
								<ul class="tutorhelper-group-dashboard__sessions">
									<?php foreach ( $sessions as $session ) : ?>
										<?php
										$start = new DateTimeImmutable( $session->booking_start, new DateTimeZone( 'UTC' ) );
										$local = $start->setTimezone( wp_timezone() );
										?>
										<?php $session_details = TutorHelper_Group_Sessions::get_location_details( $session, $block ); ?>
										<li>
											<strong><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), $local->getTimestamp(), wp_timezone() ) ); ?></strong>
											<?php if ( '' !== $session_details ) : ?><span class="tutorhelper-group-dashboard__session-details"><?php echo wp_kses_post( nl2br( make_clickable( esc_html( $session_details ) ) ) ); ?></span><?php endif; ?>
											<?php do_action( 'tutorhelper_group_dashboard_session_details', $session, $block, $enrolment ); ?>
										</li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
						<?php endif; ?>
						<p><?php
						/* translators: 1: Amount paid, 2: Remaining balance. */
						echo esc_html( sprintf( __( '%1$s paid · %2$s remaining', 'tutorhelper-group-bookings' ), self::format_money( $payment['net_paid_minor_units'], $enrolment->currency ), self::format_money( $payment['balance_minor_units'], $enrolment->currency ) ) ); ?></p>
						<?php if ( $payment['balance_minor_units'] > 0 && TutorHelper_Group_Stripe::can_pay_balance( $enrolment ) ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="<?php echo esc_attr( TutorHelper_Group_Stripe::START_ACTION ); ?>" />
								<input type="hidden" name="enrolment_id" value="<?php echo esc_attr( $enrolment->id ); ?>" />
								<?php wp_nonce_field( TutorHelper_Group_Stripe::START_ACTION . '_' . absint( $enrolment->id ) ); ?>
								<button type="submit" class="tutorhelper-group-dashboard__pay"><?php echo esc_html( $checkout['label'] ); ?></button>
							</form>
						<?php endif; ?>
						<?php do_action( 'tutorhelper_group_dashboard_enrolment_actions', $enrolment, $block, $payment ); ?>
					</article>
				<?php endforeach; ?>
			</div>
		</section>
		<?php
		return ob_get_clean();
	}

	/** @return string */
	private static function format_day_of_week( $date ) {
		$date_object = DateTimeImmutable::createFromFormat(
			'!Y-m-d',
			sanitize_text_field( $date ),
			wp_timezone()
		);

		return $date_object
			? wp_date( 'l', $date_object->getTimestamp(), wp_timezone() )
			: '';
	}

	/** @return string */
	private static function format_duration( $start_time, $end_time ) {
		$start = strtotime( '1970-01-01 ' . sanitize_text_field( $start_time ) . ' UTC' );
		$end = strtotime( '1970-01-01 ' . sanitize_text_field( $end_time ) . ' UTC' );
		$minutes = ( false !== $start && false !== $end ) ? max( 0, (int) round( ( $end - $start ) / MINUTE_IN_SECONDS ) ) : 0;

		return sprintf(
			/* translators: %d: session duration in minutes. */
			_n( '%d minute', '%d minutes', $minutes, 'tutorhelper-group-bookings' ),
			$minutes
		);
	}

	/** @return string */
	private static function format_date( $date ) {
		$timestamp = strtotime( sanitize_text_field( $date ) . ' UTC' );
		return $timestamp ? wp_date( get_option( 'date_format' ), $timestamp, new DateTimeZone( 'UTC' ) ) : '';
	}

	/** @return string */
	private static function format_time( $time ) {
		$timestamp = strtotime( '1970-01-01 ' . sanitize_text_field( $time ) . ' UTC' );
		return $timestamp ? wp_date( get_option( 'time_format' ), $timestamp, new DateTimeZone( 'UTC' ) ) : '';
	}

	/** @return string */
	private static function format_money( $amount, $currency ) {
		return class_exists( 'TutorHelper_Currency' )
			? TutorHelper_Currency::format_minor_units( absint( $amount ), strtoupper( sanitize_text_field( $currency ) ) )
			: strtoupper( sanitize_text_field( $currency ) ) . ' ' . number_format_i18n( absint( $amount ) / 100, 2 );
	}

	/** @return string */
	private static function format_deposit( $block, $total ) {
		if ( TutorHelper_Group_Blocks::PAYMENT_DEPOSIT !== sanitize_key( $block->payment_mode ) ) {
			return '';
		}

		$amount = TutorHelper_Group_Payments::calculate_deposit(
			$total,
			$block->deposit_type,
			$block->deposit_value
		);

		return sprintf(
			/* translators: %s: formatted deposit. */
			__( '%s deposit required', 'tutorhelper-group-bookings' ),
			self::format_money( $amount, $block->currency )
		);
	}
}
