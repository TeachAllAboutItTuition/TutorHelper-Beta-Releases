<?php
/**
 * Reconcile Pro finance adjustments into Group Lesson enrolments.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps enrolment lifecycle/capacity aligned with Pro's immutable ledger.
 */
final class TutorHelper_Group_Finance_Reconciliation {

	/** Register reconciliation hooks. */
	public static function init() {
		add_action(
			'tutorhelper_pro_finance_adjustment_recorded',
			array( __CLASS__, 'handle_pro_adjustment' ),
			10,
			3
		);

		/*
		 * This hook also catches reconciliation triggered by Group payment flows.
		 * The callback is deliberately idempotent.
		 */
		add_action(
			'tutorhelper_group_payment_reconciled',
			array( __CLASS__, 'enforce_security_threshold' ),
			20,
			1
		);
	}

	/**
	 * Reconcile the enrolment containing a booking changed by Pro Finance.
	 *
	 * @param int    $booking_id Core booking ID.
	 * @param int    $ledger_id Pro ledger transaction ID.
	 * @param string $transaction_type Pro ledger transaction type.
	 * @return void
	 */
	public static function handle_pro_adjustment( $booking_id, $ledger_id, $transaction_type ) {
		unset( $ledger_id, $transaction_type );

		$enrolment_id = self::get_enrolment_id_for_booking( $booking_id );
		if ( ! $enrolment_id ) {
			return;
		}

		$result = TutorHelper_Group_Payments::reconcile_enrolment( $enrolment_id );
		if ( is_wp_error( $result ) ) {
			if ( class_exists( 'TutorHelper_Logger' ) ) {
				TutorHelper_Logger::error(
					'Group finance reconciliation failed after a Pro adjustment.',
					array(
						'booking_id' => absint( $booking_id ),
						'enrolment_id' => absint( $enrolment_id ),
						'error' => $result->get_error_message(),
					)
				);
			}
			return;
		}

		self::enforce_security_threshold( $enrolment_id );
	}

	/**
	 * Demote a previously secured enrolment when its net payment no longer
	 * satisfies the original deposit/full-payment requirement.
	 *
	 * @param int $enrolment_id Enrolment ID.
	 * @return void
	 */
	public static function enforce_security_threshold( $enrolment_id ) {
		global $wpdb;

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if ( ! $enrolment ) {
			return;
		}

		$status = sanitize_key( $enrolment->status );
		if (
			! in_array(
				$status,
				array(
					TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT,
					TutorHelper_Group_Enrolments::STATUS_SECURED,
				),
				true
			)
		) {
			return;
		}

		$summary = TutorHelper_Group_Payments::get_summary( $enrolment );
		$should_be_secured = 0 === absint( $summary['amount_to_secure_minor_units'] );
		$target_status = $should_be_secured
			? TutorHelper_Group_Enrolments::STATUS_SECURED
			: TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT;

		if ( $target_status === $status ) {
			return;
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group lifecycle cache mirrors Pro finance state.
			TutorHelper_Group_Enrolments::get_table_name(),
			array(
				'status' => $target_status,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $enrolment->id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return;
		}

		/*
		 * Readiness owns block status/capacity decisions. Tell it the secured
		 * count changed rather than duplicating those rules here.
		 */
		do_action(
			'tutorhelper_group_enrolment_changed',
			absint( $enrolment->block_id ),
			TutorHelper_Group_Enrolments::count_secured( $enrolment->block_id )
		);

		$fresh = TutorHelper_Group_Enrolments::get_by_id( $enrolment->id );
		if ( $fresh && class_exists( 'TutorHelper_Group_Stripe' ) ) {
			TutorHelper_Group_Stripe::invalidate_stale_checkout(
				$fresh,
				TutorHelper_Group_Payments::get_summary( $fresh )
			);
		}
	}

	/** Return the Group enrolment linked to a Core child booking. */
	private static function get_enrolment_id_for_booking( $booking_id ) {
		global $wpdb;

		return absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Bridge lookup must reflect the current linked booking.
				$wpdb->prepare(
					'SELECT enrolment_id FROM %i WHERE booking_id = %d LIMIT 1',
					TutorHelper_Group_Enrolment_Bookings::get_table_name(),
					absint( $booking_id )
				)
			)
		);
	}
}
