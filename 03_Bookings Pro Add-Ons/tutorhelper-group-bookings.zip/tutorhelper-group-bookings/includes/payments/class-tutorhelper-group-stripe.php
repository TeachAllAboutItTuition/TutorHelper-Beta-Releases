<?php
/**
 * Stripe Checkout integration for Group Lesson enrolments.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates enrolment Checkout Sessions and handles verified Pro webhooks.
 */
final class TutorHelper_Group_Stripe {

	const START_ACTION = 'tutorhelper_group_start_stripe_checkout';
	const CANCEL_ACTION = 'tutorhelper_group_cancel_stripe_checkout';
	const CONTEXT = 'tutorhelper_group_enrolment';

	/** Register Stripe integration hooks. */
	public static function init() {
		add_action(
			'admin_post_' . self::START_ACTION,
			array( __CLASS__, 'handle_start_checkout' )
		);
		add_action(
			'admin_post_' . self::CANCEL_ACTION,
			array( __CLASS__, 'handle_cancel_checkout' )
		);

		add_filter(
			'tutorhelper_pro_stripe_webhook_extension_result',
			array( __CLASS__, 'handle_webhook_event' ),
			10,
			3
		);
	}

	/**
	 * Return whether full Stripe payment can be started.
	 *
	 * @param object $enrolment Enrolment record.
	 * @return bool
	 */
	public static function can_start_checkout( $enrolment ) {
		if ( ! is_object( $enrolment ) || ! TutorHelper_Pro_Payment_Settings::stripe_is_configured() ) {
			return false;
		}

		$payment_mode = sanitize_key( $enrolment->payment_mode );
		$status = sanitize_key( $enrolment->status );

		return (
			in_array(
				$payment_mode,
				array(
					TutorHelper_Group_Blocks::PAYMENT_FULL_UPFRONT,
					TutorHelper_Group_Blocks::PAYMENT_DEPOSIT,
				),
				true
			)
			&& in_array(
				$status,
				array(
					TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT,
					TutorHelper_Group_Enrolments::STATUS_SECURED,
				),
				true
			)
		);
	}

	/**
	 * Return whether the student can pay any outstanding balance by Stripe.
	 *
	 * @param object $enrolment Enrolment record.
	 * @return bool
	 */
	public static function can_pay_balance( $enrolment ) {
		if (
			! is_object( $enrolment )
			|| get_current_user_id() !== absint( $enrolment->student_user_id )
			|| ! TutorHelper_Pro_Payment_Settings::stripe_is_configured()
		) {
			return false;
		}

		return in_array(
			sanitize_key( $enrolment->status ),
			array(
				TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT,
				TutorHelper_Group_Enrolments::STATUS_SECURED,
			),
			true
		);
	}

	/**
	 * Resolve the next Stripe charge for an enrolment.
	 *
	 * @param object $enrolment Enrolment record.
	 * @param array  $summary Payment summary.
	 * @return array
	 */
	public static function get_checkout_details( $enrolment, $summary ) {
		$balance = absint( $summary['balance_minor_units'] );
		$to_secure = absint( $summary['amount_to_secure_minor_units'] );

		if (
			TutorHelper_Group_Blocks::PAYMENT_DEPOSIT === sanitize_key( $enrolment->payment_mode )
			&& $to_secure > 0
		) {
			return array(
				'type' => 'deposit',
				'amount_minor_units' => $to_secure,
				'label' => __( 'Pay deposit with Stripe', 'tutorhelper-group-bookings' ),
			);
		}

		$payment_mode = sanitize_key( $enrolment->payment_mode );

		return array(
			'type' => TutorHelper_Group_Blocks::PAYMENT_FULL_UPFRONT === $payment_mode
				? 'full'
				: 'balance',
			'amount_minor_units' => $balance,
			'label' => TutorHelper_Group_Blocks::PAYMENT_FULL_UPFRONT === $payment_mode
				? __( 'Pay in full with Stripe', 'tutorhelper-group-bookings' )
				: __( 'Pay balance with Stripe', 'tutorhelper-group-bookings' ),
		);
	}

	/**
	 * Create a Checkout Session for the enrolment's complete balance.
	 *
	 * @param int    $enrolment_id Enrolment ID.
	 * @param string $return_url Local page to return to.
	 * @param bool   $allow_any_balance Allow an enrolled student to choose Stripe for an invoice balance.
	 * @return array|WP_Error Checkout result.
	 */
	public static function create_checkout( $enrolment_id, $return_url = '', $allow_any_balance = false ) {
		global $wpdb;

		$reconciled = TutorHelper_Group_Payments::reconcile_enrolment( $enrolment_id );
		if ( is_wp_error( $reconciled ) ) {
			return $reconciled;
		}

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if (
			! self::can_start_checkout( $enrolment )
			&& ! ( $allow_any_balance && self::can_pay_balance( $enrolment ) )
		) {
			return new WP_Error(
				'tutorhelper_group_stripe_checkout_unavailable',
				__( 'Stripe Checkout is not available for this enrolment.', 'tutorhelper-group-bookings' )
			);
		}

		$summary = TutorHelper_Group_Payments::get_summary( $enrolment );
		$checkout_details = self::get_checkout_details( $enrolment, $summary );
		if ( 0 === $checkout_details['amount_minor_units'] ) {
			return new WP_Error(
				'tutorhelper_group_stripe_already_paid',
				__( 'This Group Lesson enrolment is already paid.', 'tutorhelper-group-bookings' )
			);
		}

		if ( ! empty( $enrolment->checkout_session_id ) ) {
			TutorHelper_Pro_Stripe::expire_checkout_session(
				sanitize_text_field( $enrolment->checkout_session_id )
			);
		}

		$block = TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id );
		$student = get_user_by( 'id', $enrolment->student_user_id );
		if ( ! $block || ! $student ) {
			return new WP_Error(
				'tutorhelper_group_stripe_context_missing',
				__( 'The Group Lesson payment details could not be prepared.', 'tutorhelper-group-bookings' )
			);
		}

		$return_url = wp_validate_redirect(
			$return_url ? $return_url : wp_get_referer(),
			home_url( '/' )
		);
		$return_url = remove_query_arg(
			array( 'group_payment', 'group_enrolment_id' ),
			$return_url
		);
		$success_url = add_query_arg(
			array(
				'group_payment' => 'success',
				'group_enrolment_id' => absint( $enrolment->id ),
			),
			$return_url
		);
		$cancel_url = add_query_arg(
			array(
				'action' => self::CANCEL_ACTION,
				'group_enrolment_id' => absint( $enrolment->id ),
				'return_url' => rawurlencode( $return_url ),
				'_wpnonce' => wp_create_nonce( self::CANCEL_ACTION . '_' . absint( $enrolment->id ) ),
			),
			admin_url( 'admin-post.php' )
		);

		$checkout = TutorHelper_Pro_Stripe::create_extension_checkout_session(
			array(
				'amount_minor_units' => $checkout_details['amount_minor_units'],
				'currency' => $enrolment->currency,
				'product_name' => $block->title,
				'description' => sprintf(
					/* translators: %s: student display name. */
					__( 'Full Group Lesson block payment for %s', 'tutorhelper-group-bookings' ),
					$student->display_name
				),
				'customer_email' => $student->user_email,
				'client_reference_id' => 'group-enrolment-' . absint( $enrolment->id ),
				'success_url' => $success_url,
				'cancel_url' => $cancel_url,
				'metadata' => array(
					'tutorhelper_context' => self::CONTEXT,
					'group_enrolment_id' => absint( $enrolment->id ),
					'group_block_id' => absint( $block->id ),
					'student_user_id' => absint( $enrolment->student_user_id ),
					'group_checkout_type' => $checkout_details['type'],
				),
			)
		);

		if ( is_wp_error( $checkout ) ) {
			return $checkout;
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Store active Checkout state.
			TutorHelper_Group_Enrolments::get_table_name(),
			array(
				'checkout_session_id' => sanitize_text_field( $checkout['id'] ),
				'checkout_amount_minor_units' => absint( $checkout_details['amount_minor_units'] ),
				'checkout_type' => sanitize_key( $checkout_details['type'] ),
				'checkout_created_at' => current_time( 'mysql', true ),
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $enrolment->id ) ),
			array( '%s', '%d', '%s', '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			TutorHelper_Pro_Stripe::expire_checkout_session( $checkout['id'] );
			return new WP_Error(
				'tutorhelper_group_stripe_checkout_store_failed',
				__( 'The Stripe Checkout Session could not be saved.', 'tutorhelper-group-bookings' )
			);
		}

		return $checkout;
	}

	/** Start Stripe Checkout from the enrolled student's dashboard. */
	public static function handle_start_checkout() {
		$enrolment_id = isset( $_POST['enrolment_id'] ) && ! is_array( $_POST['enrolment_id'] )
			? absint( wp_unslash( $_POST['enrolment_id'] ) )
			: 0;
		check_admin_referer( self::START_ACTION . '_' . $enrolment_id );

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		$allowed = $enrolment && get_current_user_id() === absint( $enrolment->student_user_id );
		if ( ! $allowed ) {
			wp_die( esc_html__( 'You do not have permission to start this payment.', 'tutorhelper-group-bookings' ) );
		}

		$result = self::create_checkout( $enrolment_id, wp_get_referer(), true );
		if ( is_wp_error( $result ) || empty( $result['url'] ) ) {
			wp_die(
				esc_html( is_wp_error( $result ) ? $result->get_error_message() : __( 'Stripe Checkout could not be started.', 'tutorhelper-group-bookings' ) ),
				esc_html__( 'Group Lesson payment', 'tutorhelper-group-bookings' ),
				array( 'back_link' => true )
			);
		}

		wp_redirect( esc_url_raw( $result['url'] ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Stripe is an intentionally external destination returned by Pro.
		exit;
	}

	/**
	 * Claim and process verified Group Bookings webhook events.
	 *
	 * @param mixed  $result Current extension result.
	 * @param array  $event Stripe event.
	 * @param string $event_type Stripe event type.
	 * @return mixed
	 */
	public static function handle_webhook_event( $result, $event, $event_type ) {
		if ( null !== $result || ! is_array( $event ) ) {
			return $result;
		}

		$session = isset( $event['data']['object'] ) && is_array( $event['data']['object'] )
			? $event['data']['object']
			: array();
		$metadata = isset( $session['metadata'] ) && is_array( $session['metadata'] )
			? $session['metadata']
			: array();

		if ( self::CONTEXT !== sanitize_key( isset( $metadata['tutorhelper_context'] ) ? $metadata['tutorhelper_context'] : '' ) ) {
			return null;
		}

		$enrolment_id = isset( $metadata['group_enrolment_id'] )
			? absint( $metadata['group_enrolment_id'] )
			: 0;
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		$session_id = sanitize_text_field( isset( $session['id'] ) ? $session['id'] : '' );

		if (
			$enrolment
			&& sanitize_text_field( $event['id'] ) === sanitize_text_field( $enrolment->last_provider_event_id )
		) {
			return true;
		}

		if ( ! $enrolment || $session_id !== sanitize_text_field( $enrolment->checkout_session_id ) ) {
			return new WP_Error(
				'tutorhelper_group_stripe_session_mismatch',
				__( 'The Group Lesson Checkout Session could not be verified.', 'tutorhelper-group-bookings' ),
				array( 'status' => 409 )
			);
		}

		if ( 'checkout.session.expired' === $event_type ) {
			self::cancel_unpaid_enrolment_or_clear( $enrolment->id );
			return true;
		}

		if ( 'checkout.session.completed' !== $event_type ) {
			return null;
		}

		if ( 'paid' !== sanitize_key( isset( $session['payment_status'] ) ? $session['payment_status'] : '' ) ) {
			return new WP_Error(
				'tutorhelper_group_stripe_not_paid',
				__( 'Stripe has not confirmed payment for this Group Lesson.', 'tutorhelper-group-bookings' ),
				array( 'status' => 409 )
			);
		}

		$amount = isset( $session['amount_total'] ) ? absint( $session['amount_total'] ) : 0;
		$currency = strtoupper( sanitize_text_field( isset( $session['currency'] ) ? $session['currency'] : '' ) );
		if (
			$amount !== absint( $enrolment->checkout_amount_minor_units )
			|| $currency !== strtoupper( sanitize_text_field( $enrolment->currency ) )
		) {
			return new WP_Error(
				'tutorhelper_group_stripe_checkout_amount_mismatch',
				__( 'The completed Stripe payment does not match the stored Group Lesson checkout.', 'tutorhelper-group-bookings' ),
				array( 'status' => 409 )
			);
		}

		$created = isset( $event['created'] ) ? absint( $event['created'] ) : time();
		$recorded = TutorHelper_Group_Payments::record_stripe_payment(
			$enrolment->id,
			$amount,
			sanitize_text_field( $event['id'] ),
			$session_id,
			gmdate( 'Y-m-d H:i:s', $created ),
			sanitize_key( $enrolment->checkout_type )
		);

		return is_wp_error( $recorded ) ? $recorded : true;
	}


	/**
	 * Handle the student's explicit Stripe cancellation return.
	 *
	 * @return void
	 */
	public static function handle_cancel_checkout() {
		$enrolment_id = isset( $_GET['group_enrolment_id'] ) && ! is_array( $_GET['group_enrolment_id'] )
			? absint( wp_unslash( $_GET['group_enrolment_id'] ) )
			: 0;
		check_admin_referer( self::CANCEL_ACTION . '_' . $enrolment_id );

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if ( ! $enrolment || get_current_user_id() !== absint( $enrolment->student_user_id ) ) {
			wp_die( esc_html__( 'This Group Lesson checkout could not be cancelled.', 'tutorhelper-group-bookings' ) );
		}

		if ( ! empty( $enrolment->checkout_session_id ) ) {
			TutorHelper_Pro_Stripe::expire_checkout_session( $enrolment->checkout_session_id );
		}
		self::cancel_unpaid_enrolment_or_clear( $enrolment_id );

		$return_url = isset( $_GET['return_url'] ) && ! is_array( $_GET['return_url'] )
			? rawurldecode( wp_unslash( $_GET['return_url'] ) ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The value is normalised and validated by the receiving currency, form or domain method.
			: home_url( '/' );
		$return_url = wp_validate_redirect( $return_url, home_url( '/' ) );
		wp_safe_redirect( add_query_arg( 'group_payment', 'cancelled', $return_url ) );
		exit;
	}

	/**
	 * Cancel an entirely unpaid enrolment, or only clear a later balance checkout.
	 *
	 * @param int $enrolment_id Enrolment ID.
	 * @return void
	 */
	private static function cancel_unpaid_enrolment_or_clear( $enrolment_id ) {
		global $wpdb;
		$summary = TutorHelper_Group_Payments::reconcile_enrolment( $enrolment_id );
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );

		if ( is_wp_error( $summary ) || ! $enrolment ) {
			return;
		}

		if (
			0 === absint( $summary['net_paid_minor_units'] )
			&& TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT === sanitize_key( $enrolment->status )
		) {
			foreach ( TutorHelper_Group_Enrolment_Bookings::get_for_enrolment( $enrolment->id ) as $booking ) {
				$current = sanitize_key( $booking->status );
				if ( TutorHelper_Booking_Records::STATUS_CANCELLED !== $current ) {
					$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
						TutorHelper_Booking_Records::get_table_name(),
						array(
							'status' => TutorHelper_Booking_Records::STATUS_CANCELLED,
							'price_minor_units' => 0,
							'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING,
							'cancellation_reason' => 'stripe_checkout_expired',
							'cancelled_by' => 'system',
							'updated_at' => current_time( 'mysql', true ),
						),
						array( 'id' => absint( $booking->id ) )
					); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Expired unpaid Group children are void finance records.
				}
			}

			TutorHelper_Group_Enrolments::update_status(
				$enrolment->id,
				TutorHelper_Group_Enrolments::STATUS_CANCELLED
			);
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
				TutorHelper_Group_Enrolments::get_table_name(),
				array(
					'cancelled_at' => current_time( 'mysql', true ),
					'cancelled_by' => 'system',
					'cancellation_reason' => 'stripe_checkout_expired',
					'updated_at' => current_time( 'mysql', true ),
				),
				array( 'id' => absint( $enrolment->id ) )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Records the machine cancellation source.
		}

		self::clear_checkout( $enrolment->id );
	}

	/**
	 * Expire a Checkout Session when another payment changed its balance.
	 *
	 * @param object $enrolment Enrolment record.
	 * @param array  $summary Reconciled payment summary.
	 * @return void
	 */
	public static function invalidate_stale_checkout( $enrolment, $summary ) {
		if ( ! is_object( $enrolment ) || empty( $enrolment->checkout_session_id ) || ! is_array( $summary ) ) {
			return;
		}

		$expected = 'deposit' === sanitize_key( $enrolment->checkout_type )
			? absint( $summary['amount_to_secure_minor_units'] )
			: absint( $summary['balance_minor_units'] );

		if ( absint( $enrolment->checkout_amount_minor_units ) === $expected ) {
			return;
		}

		TutorHelper_Pro_Stripe::expire_checkout_session(
			sanitize_text_field( $enrolment->checkout_session_id )
		);
		self::clear_checkout( $enrolment->id );
	}

	/**
	 * Clear an expired or cancelled Checkout Session.
	 *
	 * @param int $enrolment_id Enrolment ID.
	 * @return void
	 */
	private static function clear_checkout( $enrolment_id ) {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Clear expired Checkout state.
			TutorHelper_Group_Enrolments::get_table_name(),
			array(
				'checkout_session_id' => null,
				'checkout_amount_minor_units' => 0,
				'checkout_type' => '',
				'checkout_created_at' => null,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $enrolment_id ) ),
			array( null, '%d', '%s', null, '%s' ),
			array( '%d' )
		);
	}
}
