<?php
/**
 * Group Lesson payment calculations and account summaries.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps Group Lesson money calculations in integer minor units.
 */
final class TutorHelper_Group_Payments {

	const STATUS_UNPAID = 'unpaid';
	const STATUS_PARTIALLY_PAID = 'partially_paid';
	const STATUS_PAID = 'paid';
	const STATUS_PARTIALLY_REFUNDED = 'partially_refunded';
	const STATUS_REFUNDED = 'refunded';

	/**
	 * Calculate the amount required to secure an enrolment.
	 *
	 * Manual enrolments do not require an online payment. Deposit blocks
	 * require the configured deposit; full-upfront blocks require the total.
	 *
	 * @param object $enrolment Enrolment record.
	 * @return int
	 */
	public static function get_initial_amount_due( $enrolment ) {
		if ( ! is_object( $enrolment ) ) {
			return 0;
		}

		$total = isset( $enrolment->agreed_price_minor_units )
			? absint( $enrolment->agreed_price_minor_units )
			: 0;
		$payment_mode = isset( $enrolment->payment_mode )
			? sanitize_key( $enrolment->payment_mode )
			: TutorHelper_Group_Blocks::PAYMENT_MANUAL;

		if ( TutorHelper_Group_Blocks::PAYMENT_MANUAL === $payment_mode ) {
			return 0;
		}

		if ( TutorHelper_Group_Blocks::PAYMENT_DEPOSIT !== $payment_mode ) {
			return $total;
		}

		return self::calculate_deposit(
			$total,
			isset( $enrolment->deposit_type ) ? $enrolment->deposit_type : '',
			isset( $enrolment->deposit_value ) ? $enrolment->deposit_value : 0
		);
	}

	/**
	 * Calculate a fixed or percentage deposit.
	 *
	 * Percentage deposits round up so the amount collected is never below
	 * the configured percentage because of a fractional minor unit.
	 *
	 * @param int    $total_minor_units Total price.
	 * @param string $deposit_type Deposit type.
	 * @param int    $deposit_value Fixed minor units or whole percentage.
	 * @return int
	 */
	public static function calculate_deposit( $total_minor_units, $deposit_type, $deposit_value ) {
		$total_minor_units = absint( $total_minor_units );
		$deposit_type = sanitize_key( $deposit_type );
		$deposit_value = absint( $deposit_value );

		if ( 0 === $total_minor_units || 0 === $deposit_value ) {
			return 0;
		}

		if ( TutorHelper_Group_Blocks::DEPOSIT_FIXED === $deposit_type ) {
			return min( $total_minor_units, $deposit_value );
		}

		if ( TutorHelper_Group_Blocks::DEPOSIT_PERCENTAGE === $deposit_type ) {
			$percentage = min( 100, $deposit_value );
			return min(
				$total_minor_units,
				(int) ceil( ( $total_minor_units * $percentage ) / 100 )
			);
		}

		return 0;
	}

	/**
	 * Return the current financial summary for an enrolment.
	 *
	 * Paid, refunded and credited values are cumulative immutable-ledger
	 * allocations cached on the enrolment for fast dashboard reads.
	 *
	 * @param object $enrolment Enrolment record.
	 * @return array
	 */
	public static function get_summary( $enrolment ) {
		$total = is_object( $enrolment ) && isset( $enrolment->agreed_price_minor_units )
			? absint( $enrolment->agreed_price_minor_units )
			: 0;
		$paid = is_object( $enrolment ) && isset( $enrolment->amount_paid_minor_units )
			? absint( $enrolment->amount_paid_minor_units )
			: 0;
		$refunded = is_object( $enrolment ) && isset( $enrolment->amount_refunded_minor_units )
			? absint( $enrolment->amount_refunded_minor_units )
			: 0;
		$credited = is_object( $enrolment ) && isset( $enrolment->amount_credited_minor_units )
			? absint( $enrolment->amount_credited_minor_units )
			: 0;
		$net_paid = max( 0, $paid - $refunded - $credited );
		$balance = max( 0, $total - $net_paid );
		$initial_due = self::get_initial_amount_due( $enrolment );

		return array(
			'total_minor_units' => $total,
			'initial_due_minor_units' => $initial_due,
			'paid_minor_units' => $paid,
			'refunded_minor_units' => $refunded,
			'credited_minor_units' => $credited,
			'net_paid_minor_units' => $net_paid,
			'balance_minor_units' => $balance,
			'amount_to_secure_minor_units' => max( 0, $initial_due - $net_paid ),
			'payment_status' => self::resolve_status(
				$total,
				$paid,
				$refunded,
				$credited
			),
		);
	}

	/**
	 * Resolve a payment status from cumulative amounts.
	 *
	 * @param int $total Total due.
	 * @param int $paid Gross paid.
	 * @param int $refunded Refunded.
	 * @param int $credited Converted to account credit.
	 * @return string
	 */
	public static function resolve_status( $total, $paid, $refunded, $credited ) {
		$total = absint( $total );
		$paid = absint( $paid );
		$returned = absint( $refunded ) + absint( $credited );
		$net_paid = max( 0, $paid - $returned );

		if ( $paid > 0 && $returned >= $paid ) {
			return self::STATUS_REFUNDED;
		}

		if ( $returned > 0 ) {
			return self::STATUS_PARTIALLY_REFUNDED;
		}

		if ( 0 === $total || $net_paid >= $total ) {
			return self::STATUS_PAID;
		}

		if ( $net_paid > 0 ) {
			return self::STATUS_PARTIALLY_PAID;
		}

		return self::STATUS_UNPAID;
	}


	/**
	 * Rebuild cached payment totals for every enrolment in a block.
	 *
	 * @param int $block_id Group Block ID.
	 * @return array WP_Error objects keyed by enrolment ID when reconciliation fails.
	 */
	public static function reconcile_block( $block_id ) {
		$errors = array();

		foreach ( TutorHelper_Group_Enrolments::get_for_block( $block_id ) as $enrolment ) {
			$result = self::reconcile_enrolment( $enrolment->id );
			if ( is_wp_error( $result ) ) {
				$errors[ absint( $enrolment->id ) ] = $result;
			}
		}

		return $errors;
	}

	/**
	 * Rebuild one enrolment account from its linked Pro ledger entries.
	 *
	 * Pro remains the source of truth. The Group enrolment columns are a
	 * dashboard cache and must never be treated as a second finance ledger.
	 *
	 * @param int $enrolment_id Enrolment ID.
	 * @return array|WP_Error Reconciled payment summary.
	 */
	public static function reconcile_enrolment( $enrolment_id ) {
		global $wpdb;

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if ( ! $enrolment ) {
			return new WP_Error(
				'tutorhelper_group_reconciliation_enrolment_missing',
				__( 'The Group Lesson enrolment could not be reconciled.', 'tutorhelper-group-bookings' )
			);
		}

		$finance_table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$bridge_table = TutorHelper_Group_Enrolment_Bookings::get_table_name();
		$transactions = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Pro's immutable ledger is the payment source of truth.
			$wpdb->prepare(
				'SELECT finance.transaction_type, finance.amount_minor_units
				FROM %i AS finance
				INNER JOIN %i AS bridge ON bridge.booking_id = finance.booking_id
				WHERE bridge.enrolment_id = %d
				AND finance.transaction_type IN (%s, %s, %s, %s, %s)',
				$finance_table,
				$bridge_table,
				absint( $enrolment->id ),
				TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
				TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
				TutorHelper_Pro_Payment_Ledger::TYPE_REFUND,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED
			)
		);

		$paid = 0;
		$refunded = 0;
		$credited = 0;

		foreach ( $transactions as $transaction ) {
			$type = sanitize_key( $transaction->transaction_type );
			$amount = absint( $transaction->amount_minor_units );

			if ( TutorHelper_Pro_Payment_Ledger::TYPE_REFUND === $type ) {
				$refunded += $amount;
			} elseif ( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED === $type ) {
				$credited += $amount;
			} else {
				$paid += $amount;
			}
		}

		$payment_status = self::resolve_status(
			$enrolment->agreed_price_minor_units,
			$paid,
			$refunded,
			$credited
		);
		$old_status = sanitize_key( $enrolment->status );
		$new_status = $old_status;
		$prospective = clone $enrolment;
		$prospective->amount_paid_minor_units = $paid;
		$prospective->amount_refunded_minor_units = $refunded;
		$prospective->amount_credited_minor_units = $credited;

		if (
			self::get_summary( $prospective )['amount_to_secure_minor_units'] === 0
			&& TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT === $old_status
		) {
			$new_status = TutorHelper_Group_Enrolments::STATUS_SECURED;
		}

		$changed = (
			$paid !== absint( $enrolment->amount_paid_minor_units )
			|| $refunded !== absint( $enrolment->amount_refunded_minor_units )
			|| $credited !== absint( $enrolment->amount_credited_minor_units )
			|| $payment_status !== sanitize_key( $enrolment->payment_status )
			|| $new_status !== $old_status
		);

		if ( $changed ) {
			$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Cache mirrors Pro's immutable ledger.
				TutorHelper_Group_Enrolments::get_table_name(),
				array(
					'amount_paid_minor_units' => $paid,
					'amount_refunded_minor_units' => $refunded,
					'amount_credited_minor_units' => $credited,
					'payment_status' => $payment_status,
					'status' => $new_status,
					'updated_at' => current_time( 'mysql', true ),
				),
				array( 'id' => absint( $enrolment->id ) ),
				array( '%d', '%d', '%d', '%s', '%s', '%s' ),
				array( '%d' )
			);

			if ( false === $updated ) {
				return new WP_Error(
					'tutorhelper_group_reconciliation_update_failed',
					__( 'The Group Lesson payment summary could not be refreshed.', 'tutorhelper-group-bookings' )
				);
			}
		}

		if ( $old_status !== $new_status ) {
			do_action(
				'tutorhelper_group_enrolment_changed',
				absint( $enrolment->block_id ),
				TutorHelper_Group_Enrolments::count_secured( $enrolment->block_id )
			);
		}

		$fresh = $changed
			? TutorHelper_Group_Enrolments::get_by_id( $enrolment->id )
			: $enrolment;

		do_action(
			'tutorhelper_group_payment_reconciled',
			absint( $enrolment->id ),
			$paid,
			$refunded,
			$credited
		);

		$summary = self::get_summary( $fresh );
		if ( class_exists( 'TutorHelper_Group_Stripe' ) ) {
			TutorHelper_Group_Stripe::invalidate_stale_checkout( $fresh, $summary );
		}

		return $summary;
	}

	/**
	 * Record a tutor-entered payment and allocate it across child bookings.
	 *
	 * @param int    $enrolment_id Enrolment ID.
	 * @param int    $amount_minor_units Amount received.
	 * @param string $payment_type Payment or deposit ledger type.
	 * @param string $payment_date Local payment date in Y-m-d format.
	 * @param string $reference Tutor reference.
	 * @param string $notes Tutor notes.
	 * @return array|WP_Error Updated enrolment payment summary.
	 */
	public static function record_manual_payment(
		$enrolment_id,
		$amount_minor_units,
		$payment_type,
		$payment_date,
		$reference = '',
		$notes = ''
	) {
		global $wpdb;

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if ( ! $enrolment ) {
			return new WP_Error(
				'tutorhelper_group_payment_enrolment_missing',
				__( 'The Group Lesson enrolment could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$reconciled = self::reconcile_enrolment( $enrolment->id );
		if ( is_wp_error( $reconciled ) ) {
			return $reconciled;
		}
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment->id );

		if ( TutorHelper_Group_Enrolments::STATUS_CANCELLED === sanitize_key( $enrolment->status ) ) {
			return new WP_Error(
				'tutorhelper_group_payment_enrolment_cancelled',
				__( 'A payment cannot be added to a cancelled enrolment.', 'tutorhelper-group-bookings' )
			);
		}

		$amount_minor_units = absint( $amount_minor_units );
		$summary = self::get_summary( $enrolment );
		if ( 0 === $amount_minor_units ) {
			return new WP_Error(
				'tutorhelper_group_payment_amount_invalid',
				__( 'Enter a payment amount greater than zero.', 'tutorhelper-group-bookings' )
			);
		}

		if ( $amount_minor_units > $summary['balance_minor_units'] ) {
			return new WP_Error(
				'tutorhelper_group_payment_exceeds_balance',
				__( 'The payment cannot be greater than the enrolment balance.', 'tutorhelper-group-bookings' )
			);
		}

		$allowed_types = array(
			TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
			TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT,
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
		);
		$payment_type = sanitize_key( $payment_type );
		if ( ! in_array( $payment_type, $allowed_types, true ) ) {
			return new WP_Error(
				'tutorhelper_group_payment_type_invalid',
				__( 'The payment type is invalid.', 'tutorhelper-group-bookings' )
			);
		}

		$transaction_date = self::normalise_payment_date( $payment_date );
		if ( is_wp_error( $transaction_date ) ) {
			return $transaction_date;
		}

		$bookings = TutorHelper_Group_Enrolment_Bookings::get_for_enrolment( $enrolment->id );
		if ( empty( $bookings ) ) {
			return new WP_Error(
				'tutorhelper_group_payment_bookings_missing',
				__( 'No child bookings are available for this enrolment.', 'tutorhelper-group-bookings' )
			);
		}

		$currency = ! empty( $enrolment->currency )
			? strtoupper( sanitize_text_field( $enrolment->currency ) )
			: TutorHelper_Currency::get_currency();
		$reference = sanitize_text_field( $reference );
		$notes = sanitize_textarea_field( $notes );
		$batch_reference = '' !== $reference
			? $reference
			: 'group-' . absint( $enrolment->id ) . '-' . wp_generate_uuid4();
		if ( TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT === $payment_type ) {
			$description = __( 'Group Lesson deposit recorded by tutor.', 'tutorhelper-group-bookings' );
		} elseif ( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED === $payment_type ) {
			$description = __( 'Account credit applied to a Group Lesson enrolment.', 'tutorhelper-group-bookings' );
		} else {
			$description = __( 'Group Lesson payment recorded by tutor.', 'tutorhelper-group-bookings' );
		}

		if ( '' !== $notes ) {
			$description .= ' ' . $notes;
		}

		$remaining = $amount_minor_units;
		$ledger_ids = array();
		$history_changes = array();

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Keep Group and Pro finance writes atomic.

		foreach ( $bookings as $booking ) {
			if ( 0 === $remaining ) {
				break;
			}

			if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
				continue;
			}

			$outstanding = self::get_booking_outstanding( $booking );
			if ( 0 === $outstanding ) {
				continue;
			}

			$allocation = min( $remaining, $outstanding );
			$ledger_result = TutorHelper_Pro_Payment_Ledger::record(
				array(
					'booking_id' => absint( $booking->id ),
					'student_user_id' => absint( $booking->student_user_id ),
					'tutor_user_id' => absint( $booking->tutor_user_id ),
					'transaction_type' => $payment_type,
					'amount_minor_units' => $allocation,
					'currency' => $currency,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
					'payment_provider' => '',
					'provider_reference' => $batch_reference,
					'description' => $description,
					'transaction_date' => $transaction_date,
					'created_by_user_id' => get_current_user_id(),
				)
			);

			if ( is_wp_error( $ledger_result ) ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back an incomplete payment allocation.
				return $ledger_result;
			}

			$ledger_ids[] = absint( $ledger_result );
			$remaining -= $allocation;

			if ( $allocation === $outstanding ) {
				$previous_payment_status = sanitize_key( $booking->payment_status );
				$updated = TutorHelper_Booking_Records::update_payment_details(
					$booking->id,
					array(
						'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
						'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
						'payment_provider' => '',
						'payment_reference' => $batch_reference,
					),
					$previous_payment_status
				);

				if ( is_wp_error( $updated ) ) {
					$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back an incomplete payment allocation.
					return $updated;
				}

				$history_changes[] = array(
					'booking' => $booking,
					'previous_payment_status' => $previous_payment_status,
					'amount_minor_units' => $allocation,
				);
			}
		}

		if ( 0 !== $remaining ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- No partial allocation may survive.
			return new WP_Error(
				'tutorhelper_group_payment_allocation_failed',
				__( 'The payment could not be fully allocated across the child bookings.', 'tutorhelper-group-bookings' )
			);
		}

		$new_paid = absint( $enrolment->amount_paid_minor_units ) + $amount_minor_units;
		$new_payment_status = self::resolve_status(
			$enrolment->agreed_price_minor_units,
			$new_paid,
			$enrolment->amount_refunded_minor_units,
			$enrolment->amount_credited_minor_units
		);
		$new_status = sanitize_key( $enrolment->status );
		$prospective = clone $enrolment;
		$prospective->amount_paid_minor_units = $new_paid;

		if (
			self::get_summary( $prospective )['amount_to_secure_minor_units'] === 0
			&& TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT === $new_status
		) {
			$new_status = TutorHelper_Group_Enrolments::STATUS_SECURED;
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Payment totals are cached on the Group enrolment.
			TutorHelper_Group_Enrolments::get_table_name(),
			array(
				'amount_paid_minor_units' => $new_paid,
				'payment_status' => $new_payment_status,
				'status' => $new_status,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $enrolment->id ) ),
			array( '%d', '%s', '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back an incomplete payment allocation.
			return new WP_Error(
				'tutorhelper_group_payment_update_failed',
				__( 'The enrolment payment totals could not be updated.', 'tutorhelper-group-bookings' )
			);
		}

		foreach ( $history_changes as $change ) {
			$history = TutorHelper_Pro_Payment_History::record(
				array(
					'booking_id' => absint( $change['booking']->id ),
					'student_user_id' => absint( $change['booking']->student_user_id ),
					'previous_payment_status' => $change['previous_payment_status'],
					'new_payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
					'previous_booking_status' => sanitize_key( $change['booking']->status ),
					'new_booking_status' => sanitize_key( $change['booking']->status ),
					'amount_minor_units' => absint( $change['amount_minor_units'] ),
					'currency' => $currency,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
					'payment_provider' => '',
					'provider_reference' => $batch_reference,
					'change_source' => TutorHelper_Pro_Payment_History::SOURCE_ADMIN,
					'changed_by_user_id' => get_current_user_id(),
					'notes' => $description,
				)
			);

			if ( is_wp_error( $history ) ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Payment history is part of the atomic finance write.
				return $history;
			}
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Commit the complete payment allocation.

		if ( sanitize_key( $enrolment->status ) !== $new_status ) {
			do_action(
				'tutorhelper_group_enrolment_changed',
				absint( $enrolment->block_id ),
				TutorHelper_Group_Enrolments::count_secured( $enrolment->block_id )
			);
		}

		do_action(
			'tutorhelper_group_manual_payment_recorded',
			absint( $enrolment->id ),
			$amount_minor_units,
			$ledger_ids,
			$batch_reference
		);

		$result = self::reconcile_enrolment( $enrolment->id );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$result['ledger_transaction_ids'] = $ledger_ids;
		$result['batch_reference'] = $batch_reference;

		return $result;
	}

	/**
	 * Return the outstanding amount for one child booking from Pro's ledger.
	 *
	 * @param object $booking Core booking.
	 * @return int
	 */
	private static function get_booking_outstanding( $booking ) {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Allocation requires the current ledger balance.
			$wpdb->prepare(
				'SELECT transaction_type, amount_minor_units
				FROM %i
				WHERE booking_id = %d
				AND transaction_type IN (%s, %s, %s, %s)',
				$table,
				absint( $booking->id ),
				TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
				TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
				TutorHelper_Pro_Payment_Ledger::TYPE_REFUND
			)
		);

		$settled = 0;
		foreach ( $rows as $row ) {
			$amount = absint( $row->amount_minor_units );
			$settled += TutorHelper_Pro_Payment_Ledger::TYPE_REFUND === sanitize_key( $row->transaction_type )
				? -$amount
				: $amount;
		}

		return max( 0, absint( $booking->price_minor_units ) - max( 0, $settled ) );
	}


	/**
	 * Record a completed full-block Stripe payment.
	 *
	 * @param int    $enrolment_id Enrolment ID.
	 * @param int    $amount_minor_units Amount paid.
	 * @param string $event_id Stripe event ID.
	 * @param string $session_id Stripe Checkout Session ID.
	 * @param string $transaction_date UTC transaction date.
	 * @param string $checkout_type Full, deposit or balance.
	 * @return array|WP_Error Reconciled summary.
	 */
	public static function record_stripe_payment(
		$enrolment_id,
		$amount_minor_units,
		$event_id,
		$session_id,
		$transaction_date,
		$checkout_type = 'full'
	) {
		global $wpdb;

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if ( ! $enrolment ) {
			return new WP_Error(
				'tutorhelper_group_stripe_enrolment_missing',
				__( 'The Group Lesson enrolment could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$reconciled = self::reconcile_enrolment( $enrolment->id );
		if ( is_wp_error( $reconciled ) ) {
			return $reconciled;
		}

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment->id );
		$summary = self::get_summary( $enrolment );
		$amount_minor_units = absint( $amount_minor_units );
		$event_id = sanitize_text_field( $event_id );
		$session_id = sanitize_text_field( $session_id );
		$checkout_type = sanitize_key( $checkout_type );

		if ( $event_id === sanitize_text_field( $enrolment->last_provider_event_id ) ) {
			return $summary;
		}

		$payment_mode = sanitize_key( $enrolment->payment_mode );
		$is_deposit = 'deposit' === $checkout_type;
		$expected = $is_deposit
			? absint( $summary['amount_to_secure_minor_units'] )
			: absint( $summary['balance_minor_units'] );

		if (
			! in_array(
				$payment_mode,
				array(
					TutorHelper_Group_Blocks::PAYMENT_MANUAL,
					TutorHelper_Group_Blocks::PAYMENT_FULL_UPFRONT,
					TutorHelper_Group_Blocks::PAYMENT_DEPOSIT,
				),
				true
			)
			|| ! in_array( $checkout_type, array( 'full', 'deposit', 'balance' ), true )
			|| ( $is_deposit && TutorHelper_Group_Blocks::PAYMENT_DEPOSIT !== $payment_mode )
			|| ( TutorHelper_Group_Blocks::PAYMENT_MANUAL === $payment_mode && 'balance' !== $checkout_type )
			|| 0 === $amount_minor_units
			|| $amount_minor_units !== $expected
		) {
			return new WP_Error(
				'tutorhelper_group_stripe_amount_mismatch',
				__( 'The Stripe payment does not match the amount currently due for this Group Lesson.', 'tutorhelper-group-bookings' )
			);
		}

		$transaction_type = $is_deposit
			? TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT
			: TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT;

		$bookings = TutorHelper_Group_Enrolment_Bookings::get_for_enrolment( $enrolment->id );
		if ( empty( $bookings ) ) {
			return new WP_Error(
				'tutorhelper_group_stripe_bookings_missing',
				__( 'No child bookings are available for this enrolment.', 'tutorhelper-group-bookings' )
			);
		}

		$currency = strtoupper( sanitize_text_field( $enrolment->currency ) );
		$remaining = $amount_minor_units;
		$history_changes = array();

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Keep Stripe allocation atomic.

		foreach ( $bookings as $booking ) {
			if ( 0 === $remaining ) {
				break;
			}

			if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
				continue;
			}

			$outstanding = self::get_booking_outstanding( $booking );
			if ( 0 === $outstanding ) {
				continue;
			}

			$allocation = min( $remaining, $outstanding );
			$ledger = TutorHelper_Pro_Payment_Ledger::record(
				array(
					'booking_id' => absint( $booking->id ),
					'student_user_id' => absint( $booking->student_user_id ),
					'tutor_user_id' => absint( $booking->tutor_user_id ),
					'transaction_type' => $transaction_type,
					'amount_minor_units' => $allocation,
					'currency' => $currency,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
					'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					'provider_reference' => $session_id,
					'provider_event_id' => $event_id . '-booking-' . absint( $booking->id ),
					'description' => $is_deposit
						? __( 'Group Lesson deposit received through Stripe.', 'tutorhelper-group-bookings' )
						: __( 'Group Lesson balance payment received through Stripe.', 'tutorhelper-group-bookings' ),
					'transaction_date' => sanitize_text_field( $transaction_date ),
					'created_by_user_id' => absint( $enrolment->student_user_id ),
				)
			);

			if ( is_wp_error( $ledger ) ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back incomplete Stripe allocation.
				return $ledger;
			}

			$remaining -= $allocation;

			if ( $allocation === $outstanding ) {
				$previous_payment_status = sanitize_key( $booking->payment_status );
				$updated = TutorHelper_Booking_Records::update_payment_details(
					$booking->id,
					array(
						'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
						'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
						'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
						'payment_reference' => $session_id,
					),
					$previous_payment_status
				);

				if ( is_wp_error( $updated ) ) {
					$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back incomplete Stripe allocation.
					return $updated;
				}

				$history_changes[] = array(
					'booking' => $booking,
					'previous_payment_status' => $previous_payment_status,
					'amount' => $allocation,
				);
			}
		}

		if ( 0 !== $remaining ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- No partial Stripe allocation may survive.
			return new WP_Error(
				'tutorhelper_group_stripe_allocation_failed',
				__( 'The Stripe payment could not be allocated across the child bookings.', 'tutorhelper-group-bookings' )
			);
		}

		foreach ( $history_changes as $change ) {
			$history = TutorHelper_Pro_Payment_History::record(
				array(
					'booking_id' => absint( $change['booking']->id ),
					'student_user_id' => absint( $change['booking']->student_user_id ),
					'previous_payment_status' => $change['previous_payment_status'],
					'new_payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
					'previous_booking_status' => sanitize_key( $change['booking']->status ),
					'new_booking_status' => sanitize_key( $change['booking']->status ),
					'amount_minor_units' => absint( $change['amount'] ),
					'currency' => $currency,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
					'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					'provider_event_id' => $event_id . '-history-' . absint( $change['booking']->id ),
					'provider_reference' => $session_id,
					'change_source' => TutorHelper_Pro_Payment_History::SOURCE_PROVIDER_WEBHOOK,
					'changed_by_user_id' => absint( $enrolment->student_user_id ),
					'notes' => __( 'Child booking settled by a full Group Lesson Stripe payment.', 'tutorhelper-group-bookings' ),
				)
			);

			if ( is_wp_error( $history ) ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Payment history is part of the atomic write.
				return $history;
			}
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Store webhook idempotency state.
			TutorHelper_Group_Enrolments::get_table_name(),
			array(
				'last_provider_event_id' => $event_id,
				'checkout_session_id' => null,
				'checkout_amount_minor_units' => 0,
				'checkout_type' => '',
				'checkout_created_at' => null,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $enrolment->id ) ),
			array( '%s', null, '%d', '%s', null, '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back incomplete Stripe processing.
			return new WP_Error(
				'tutorhelper_group_stripe_state_update_failed',
				__( 'The Stripe payment state could not be saved.', 'tutorhelper-group-bookings' )
			);
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Commit verified Stripe payment.
		return self::reconcile_enrolment( $enrolment->id );
	}

	/**
	 * Convert an admin-entered date to UTC.
	 *
	 * @param string $payment_date Date in Y-m-d format.
	 * @return string|WP_Error
	 */
	private static function normalise_payment_date( $payment_date ) {
		$payment_date = sanitize_text_field( $payment_date );
		if ( ! preg_match( '/^\\d{4}-\\d{2}-\\d{2}$/', $payment_date ) ) {
			return new WP_Error(
				'tutorhelper_group_payment_date_invalid',
				__( 'Enter a valid payment date.', 'tutorhelper-group-bookings' )
			);
		}

		try {
			$local = new DateTimeImmutable( $payment_date . ' 12:00:00', wp_timezone() );
			if ( $local->format( 'Y-m-d' ) !== $payment_date ) {
				throw new Exception( 'Invalid date.' );
			}
			return $local->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		} catch ( Exception $exception ) {
			return new WP_Error(
				'tutorhelper_group_payment_date_invalid',
				__( 'Enter a valid payment date.', 'tutorhelper-group-bookings' )
			);
		}
	}

}
