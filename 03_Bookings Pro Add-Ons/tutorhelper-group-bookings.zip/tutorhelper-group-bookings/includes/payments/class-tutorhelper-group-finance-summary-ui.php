<?php
/**
 * Reconciled Group Lesson finance summaries for tutor and student views.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Display the same enrolment totals used by the reconciliation engine. */
final class TutorHelper_Group_Finance_Summary_UI {

	/** Register display hooks. */
	public static function init() {
		add_action(
			'tutorhelper_booking_hub_render_tab',
			array( __CLASS__, 'render_tutor_summary' ),
			50,
			2
		);

		add_filter(
			'do_shortcode_tag',
			array( __CLASS__, 'append_student_summary' ),
			40,
			4
		);
	}

	/**
	 * Show reconciled totals beneath a Group Block admin screen.
	 *
	 * @param string $selected_tab Selected tab.
	 * @param array  $active_tab Tab definition.
	 * @return void
	 */
	public static function render_tutor_summary( $selected_tab, $active_tab ) {
		unset( $active_tab );

		if (
			! is_admin()
			|| TutorHelper_Group_Bookings_Admin::TAB_KEY !== $selected_tab
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$block_id = isset( $_GET['group_block_id'] ) && ! is_array( $_GET['group_block_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin navigation state.
			? absint( wp_unslash( $_GET['group_block_id'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin navigation state.
			: 0;
		if ( ! $block_id ) {
			return;
		}

		TutorHelper_Group_Payments::reconcile_block( $block_id );
		$enrolments = TutorHelper_Group_Enrolments::get_for_block( $block_id );
		if ( empty( $enrolments ) ) {
			return;
		}
		?>
		<section class="tutorhelper-main-section tutorhelper-group-finance-summary">
			<header class="tutorhelper-main-section__header">
				<h3><?php echo esc_html__( 'Reconciled finance', 'tutorhelper-group-bookings' ); ?></h3>
				<p><?php echo esc_html__( 'These totals are rebuilt from TutorHelper Pro’s immutable ledger across every child lesson in each enrolment.', 'tutorhelper-group-bookings' ); ?></p>
			</header>
			<div class="tutorhelper-main-section__body">
				<div class="tutorhelper-group-lessons__table-wrap">
					<table class="widefat striped tutorhelper-group-lessons__table">
						<thead><tr>
							<th><?php echo esc_html__( 'Student', 'tutorhelper-group-bookings' ); ?></th>
							<th><?php echo esc_html__( 'Payment state', 'tutorhelper-group-bookings' ); ?></th>
							<th><?php echo esc_html__( 'Paid', 'tutorhelper-group-bookings' ); ?></th>
							<th><?php echo esc_html__( 'Refunded', 'tutorhelper-group-bookings' ); ?></th>
							<th><?php echo esc_html__( 'Credited', 'tutorhelper-group-bookings' ); ?></th>
							<th><?php echo esc_html__( 'Outstanding', 'tutorhelper-group-bookings' ); ?></th>
							<th><?php echo esc_html__( 'Place', 'tutorhelper-group-bookings' ); ?></th>
						</tr></thead>
						<tbody>
						<?php foreach ( $enrolments as $enrolment ) :
							$summary = TutorHelper_Group_Payments::get_summary( $enrolment );
							$student = get_user_by( 'id', absint( $enrolment->student_user_id ) );
						?>
						<tr>
							<td><?php echo esc_html( $student ? $student->display_name : '#' . absint( $enrolment->student_user_id ) ); ?></td>
							<td><strong><?php echo esc_html( self::payment_status_label( $summary['payment_status'] ) ); ?></strong></td>
							<td><?php echo esc_html( self::format_money( $summary['paid_minor_units'], $enrolment->currency ) ); ?></td>
							<td><?php echo esc_html( self::format_money( $summary['refunded_minor_units'], $enrolment->currency ) ); ?></td>
							<td><?php echo esc_html( self::format_money( $summary['credited_minor_units'], $enrolment->currency ) ); ?></td>
							<td><?php echo esc_html( self::format_money( $summary['balance_minor_units'], $enrolment->currency ) ); ?></td>
							<td><?php echo esc_html( self::enrolment_status_label( $enrolment->status ) ); ?></td>
						</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</section>
		<?php
	}

	/**
	 * Append a compact finance summary to the student dashboard shortcode.
	 *
	 * @param string $output Shortcode output.
	 * @param string $tag Shortcode tag.
	 * @param array  $attr Attributes.
	 * @param array  $match Shortcode parser match.
	 * @return string
	 */
	public static function append_student_summary( $output, $tag, $attr, $match ) {
		unset( $attr, $match );

		if (
			! is_user_logged_in()
			|| ! class_exists( 'TutorHelper_Student_Dashboard_Shortcode' )
			|| TutorHelper_Student_Dashboard_Shortcode::SHORTCODE !== $tag
		) {
			return $output;
		}

		$student_id = get_current_user_id();
		$enrolments = self::get_student_enrolments( $student_id );
		if ( empty( $enrolments ) ) {
			return $output;
		}

		ob_start();
		?>
		<section class="tutorhelper-group-dashboard tutorhelper-group-finance-summary" aria-labelledby="tutorhelper-group-finance-summary-heading">
			<header class="tutorhelper-group-dashboard__header">
				<h2 id="tutorhelper-group-finance-summary-heading"><?php echo esc_html__( 'Group Lesson payments', 'tutorhelper-group-bookings' ); ?></h2>
			</header>
			<div class="tutorhelper-group-dashboard__grid">
				<?php foreach ( $enrolments as $enrolment ) :
					TutorHelper_Group_Payments::reconcile_enrolment( $enrolment->id );
					TutorHelper_Group_Finance_Reconciliation::enforce_security_threshold( $enrolment->id );
					$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment->id );
					$summary = TutorHelper_Group_Payments::get_summary( $enrolment );
					$block = TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id );
				?>
				<article class="tutorhelper-group-dashboard__card">
					<h3><?php echo esc_html( $block ? $block->title : __( 'Group Lesson', 'tutorhelper-group-bookings' ) ); ?></h3>
					<p><strong><?php echo esc_html( self::payment_status_label( $summary['payment_status'] ) ); ?></strong></p>
					<p>
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1 paid, 2 refunded, 3 credited, 4 outstanding. */
								__( '%1$s paid · %2$s refunded · %3$s credited · %4$s outstanding', 'tutorhelper-group-bookings' ),
								self::format_money( $summary['paid_minor_units'], $enrolment->currency ),
								self::format_money( $summary['refunded_minor_units'], $enrolment->currency ),
								self::format_money( $summary['credited_minor_units'], $enrolment->currency ),
								self::format_money( $summary['balance_minor_units'], $enrolment->currency )
							)
						);
						?>
					</p>
					<?php if ( TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT === sanitize_key( $enrolment->status ) ) : ?>
						<p class="tutorhelper-group-dashboard__notice">
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s amount required to secure place. */
									__( 'Your place is awaiting payment. %s is currently required to secure it.', 'tutorhelper-group-bookings' ),
									self::format_money( $summary['amount_to_secure_minor_units'], $enrolment->currency )
								)
							);
							?>
						</p>
					<?php endif; ?>
				</article>
				<?php endforeach; ?>
			</div>
		</section>
		<?php

		return $output . ob_get_clean();
	}

	/** Return current non-cancelled enrolments for a student. */
	private static function get_student_enrolments( $student_id ) {
		global $wpdb;

		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Student finance summary must show current enrolment state.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE student_user_id = %d AND status != %s ORDER BY joined_at DESC',
				TutorHelper_Group_Enrolments::get_table_name(),
				absint( $student_id ),
				TutorHelper_Group_Enrolments::STATUS_CANCELLED
			)
		);
	}

	/** Format minor units using Core's currency service. */
	private static function format_money( $amount, $currency ) {
		return TutorHelper_Currency::format_minor_units(
			absint( $amount ),
			strtoupper( sanitize_text_field( $currency ) )
		);
	}

	/** Friendly Group payment status. */
	private static function payment_status_label( $status ) {
		$labels = array(
			TutorHelper_Group_Payments::STATUS_PAID => __( 'Paid', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Payments::STATUS_PARTIALLY_PAID => __( 'Partially paid', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Payments::STATUS_PARTIALLY_REFUNDED => __( 'Partially refunded', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Payments::STATUS_REFUNDED => __( 'Refunded', 'tutorhelper-group-bookings' ),
			TutorHelper_Group_Payments::STATUS_UNPAID => __( 'Unpaid', 'tutorhelper-group-bookings' ),
		);
		$status = sanitize_key( $status );
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( str_replace( '_', ' ', $status ) );
	}

	/** Friendly enrolment state. */
	private static function enrolment_status_label( $status ) {
		$status = sanitize_key( $status );
		if ( TutorHelper_Group_Enrolments::STATUS_SECURED === $status ) {
			return __( 'Secured', 'tutorhelper-group-bookings' );
		}
		if ( TutorHelper_Group_Enrolments::STATUS_AWAITING_PAYMENT === $status ) {
			return __( 'Awaiting payment', 'tutorhelper-group-bookings' );
		}
		return ucfirst( str_replace( '_', ' ', $status ) );
	}
}
