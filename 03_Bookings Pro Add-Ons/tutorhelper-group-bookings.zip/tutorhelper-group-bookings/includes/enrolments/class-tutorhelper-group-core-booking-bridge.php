<?php
/**
 * Group Lesson integration with Core booking creation.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Supplies Group Lesson pricing and conflict scoping while Core creates
 * one ordinary booking for each student/session combination.
 */
final class TutorHelper_Group_Core_Booking_Bridge {

	/** Register bridge hooks. */
	public static function init() {
		add_filter( 'tutorhelper_booking_resolved_pricing', array( __CLASS__, 'filter_pricing' ), 20, 4 );
		add_filter( 'tutorhelper_booking_send_student_confirmation', array( __CLASS__, 'suppress_child_confirmation' ), 20, 3 );
		add_filter( 'tutorhelper_booking_send_request_emails', array( __CLASS__, 'suppress_child_request_emails' ), 20, 3 );
		add_filter( 'query', array( __CLASS__, 'scope_group_conflict_query' ), 20 );
	}

	/**
	 * Override Core's resolved price with the enrolment's agreed price
	 * snapshot, allocated across its sessions in integer minor units.
	 *
	 * @param array $pricing Core pricing result.
	 * @param int   $student_user_id Student ID.
	 * @param int   $booking_type_id Booking Type ID.
	 * @param int   $duration_minutes Duration.
	 * @return array
	 */
	public static function filter_pricing( $pricing, $student_user_id, $booking_type_id, $duration_minutes ) {
		unset( $duration_minutes );

		if ( ! TutorHelper_Group_Booking_Context::is_active() ) {
			return $pricing;
		}

		$block = TutorHelper_Group_Booking_Context::get_block();
		$enrolment = TutorHelper_Group_Booking_Context::get_enrolment();
		$session = TutorHelper_Group_Booking_Context::get_session();

		if (
			! $block
			|| ! $enrolment
			|| ! $session
			|| absint( $student_user_id ) !== absint( $enrolment->student_user_id )
			|| absint( $booking_type_id ) !== absint( $block->booking_type_id )
		) {
			return $pricing;
		}

		return array(
			'price_minor_units' => self::get_session_price( $block, $enrolment, $session ),
			'pricing_basis' => 'group_block',
		);
	}

	/**
	 * Allocate the student's agreed total across the block sessions.
	 *
	 * This ensures the sum of child bookings always exactly matches the
	 * enrolment price snapshot, including fixed-price blocks that do not
	 * divide evenly into minor currency units.
	 *
	 * @param object $block Group Block.
	 * @param object $enrolment Enrolment price snapshot.
	 * @param object $session Group Session.
	 * @return int
	 */
	private static function get_session_price( $block, $enrolment, $session ) {
		$sessions = TutorHelper_Group_Sessions::get_for_block( $block->id );
		$count = count( $sessions );
		if ( 0 === $count ) {
			return 0;
		}

		$total = absint( $enrolment->agreed_price_minor_units );
		$base = intdiv( $total, $count );
		$remainder = $total % $count;
		$position = max( 1, absint( $session->session_number ) );

		return $base + ( $position <= $remainder ? 1 : 0 );
	}

	/** @return bool */
	public static function suppress_child_confirmation( $send, $booking_id, $insert_data ) {
		unset( $booking_id, $insert_data );
		return TutorHelper_Group_Booking_Context::is_active() ? false : $send;
	}

	/** @return bool */
	public static function suppress_child_request_emails( $send, $booking_id, $insert_data ) {
		unset( $booking_id, $insert_data );
		return TutorHelper_Group_Booking_Context::is_active() ? false : $send;
	}

	/**
	 * Exclude bookings already linked to the same Group Session from Core's
	 * tutor-overlap query while another student booking for that same session
	 * is being created. Unrelated overlapping bookings still conflict.
	 *
	 * This compatibility layer should ultimately be replaced by a dedicated
	 * Core conflict extension point before public release.
	 *
	 * @param string $query SQL query.
	 * @return string
	 */
	public static function scope_group_conflict_query( $query ) {
		global $wpdb;

		if ( ! TutorHelper_Group_Booking_Context::is_active() ) {
			return $query;
		}

		$session = TutorHelper_Group_Booking_Context::get_session();
		if ( ! $session ) {
			return $query;
		}

		$bookings_table = TutorHelper_Booking_Records::get_table_name();
		$is_legacy_conflict_query = false !== strpos( $query, 'booking_end >' );
		$is_buffered_conflict_query = false !== strpos( $query, 'DATE_ADD(' )
			&& false !== strpos( $query, 'booking_end' )
			&& false !== strpos( $query, 'buffer_after_minutes' );

		if (
			false === strpos( $query, $bookings_table )
			|| false === strpos( $query, 'tutor_user_id' )
			|| false === strpos( $query, 'booking_start <' )
			|| ( ! $is_legacy_conflict_query && ! $is_buffered_conflict_query )
			|| false !== strpos( $query, 'ORDER BY' )
		) {
			return $query;
		}

		$booking_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current sibling IDs scope the active conflict check.
			$wpdb->prepare(
				'SELECT booking_id FROM %i WHERE session_id = %d',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				absint( $session->id )
			)
		);

		$booking_ids = array_values(
			array_filter(
				array_map( 'absint', is_array( $booking_ids ) ? $booking_ids : array() )
			)
		);

		if ( empty( $booking_ids ) ) {
			return $query;
		}

		$id_column = false !== strpos( $query, 'b.tutor_user_id' )
			? 'b.id'
			: 'id';

		return $query . ' AND ' . $id_column . ' NOT IN (' . implode( ',', $booking_ids ) . ')';
	}
}
