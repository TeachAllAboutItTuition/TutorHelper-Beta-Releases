<?php
/**
 * Group Lesson child booking status synchronisation.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps individual Core bookings aligned with Group Block readiness.
 */
final class TutorHelper_Group_Booking_Status_Sync {

	/**
	 * Register lifecycle hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'tutorhelper_group_block_status_changed',
			array( __CLASS__, 'handle_block_status_changed' ),
			20,
			6
		);
	}

	/**
	 * Synchronise secured students' Core bookings when readiness changes.
	 *
	 * @param int    $block_id Block ID.
	 * @param string $new_status New block status.
	 * @param string $old_status Previous block status.
	 * @param int    $secured_count Secured enrolment count.
	 * @param int    $reserved_count Reserved place count.
	 * @param mixed  $unused Reserved for future lifecycle context.
	 * @return void
	 */
	public static function handle_block_status_changed(
		$block_id,
		$new_status,
		$old_status,
		$secured_count,
		$reserved_count,
		$unused = null
	) {
		unset( $old_status, $secured_count, $reserved_count, $unused );

		$block_id = absint( $block_id );
		$new_status = sanitize_key( $new_status );

		if ( ! $block_id ) {
			return;
		}

		if (
			in_array(
				$new_status,
				array(
					TutorHelper_Group_Blocks::STATUS_CONFIRMED,
					TutorHelper_Group_Blocks::STATUS_FULL,
				),
				true
			)
		) {
			self::sync_secured_bookings(
				$block_id,
				TutorHelper_Booking_Records::STATUS_CONFIRMED
			);
			return;
		}

		if ( TutorHelper_Group_Blocks::STATUS_AWAITING_MINIMUM === $new_status ) {
			self::sync_secured_bookings(
				$block_id,
				TutorHelper_Booking_Records::STATUS_UNCONFIRMED
			);
		}
	}

	/**
	 * Set all secured enrolments' child bookings to one Core status.
	 *
	 * @param int    $block_id Block ID.
	 * @param string $target_status Target Core booking status.
	 * @return void
	 */
	private static function sync_secured_bookings( $block_id, $target_status ) {
		$enrolments = TutorHelper_Group_Enrolments::get_for_block( $block_id );

		foreach ( $enrolments as $enrolment ) {
			if (
				TutorHelper_Group_Enrolments::STATUS_SECURED
				!== sanitize_key( $enrolment->status )
			) {
				continue;
			}

			$bookings = TutorHelper_Group_Enrolment_Bookings::get_for_enrolment(
				$enrolment->id
			);

			foreach ( $bookings as $booking ) {
				$current = sanitize_key( $booking->status );

				if ( $current === $target_status ) {
					continue;
				}

				if (
					! in_array(
						$current,
						array(
							TutorHelper_Booking_Records::STATUS_CONFIRMED,
							TutorHelper_Booking_Records::STATUS_UNCONFIRMED,
						),
						true
					)
				) {
					continue;
				}

				$result = TutorHelper_Booking_Records::update_status(
					$booking->id,
					$target_status,
					$current
				);

				if ( is_wp_error( $result ) ) {
					if ( class_exists( 'TutorHelper_Logger' ) ) {
						TutorHelper_Logger::warning(
							'Group Lesson child booking status could not be synchronised.',
							array(
								'block_id' => $block_id,
								'enrolment_id' => absint( $enrolment->id ),
								'booking_id' => absint( $booking->id ),
								'error_code' => $result->get_error_code(),
							)
						);
					}
					continue;
				}

				do_action(
					'tutorhelper_group_child_booking_status_synced',
					absint( $booking->id ),
					$target_status,
					$current,
					$block_id,
					absint( $enrolment->id )
				);
			}
		}
	}
}
