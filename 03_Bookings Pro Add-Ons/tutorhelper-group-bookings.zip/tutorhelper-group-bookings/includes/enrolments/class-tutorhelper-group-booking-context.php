<?php
/**
 * Temporary context for Core booking creation from a Group Lesson enrolment.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Exposes the active Group Lesson creation context to Core extension hooks.
 */
final class TutorHelper_Group_Booking_Context {

	/** @var object|null */
	private static $block = null;

	/** @var object|null */
	private static $enrolment = null;

	/** @var object|null */
	private static $session = null;

	/**
	 * Begin a Group Lesson Core-booking creation context.
	 *
	 * @param object $block Group Block.
	 * @param object $enrolment Group enrolment.
	 * @return void
	 */
	public static function begin( $block, $enrolment ) {
		self::$block = is_object( $block ) ? $block : null;
		self::$enrolment = is_object( $enrolment ) ? $enrolment : null;
		self::$session = null;
	}

	/**
	 * Set the Group Session currently being converted into a Core booking.
	 *
	 * @param object $session Group Session.
	 * @return void
	 */
	public static function set_session( $session ) {
		self::$session = is_object( $session ) ? $session : null;
	}

	/**
	 * End the current creation context.
	 *
	 * @return void
	 */
	public static function end() {
		self::$block = null;
		self::$enrolment = null;
		self::$session = null;
	}

	/**
	 * Check whether Group Bookings is currently creating child bookings.
	 *
	 * @return bool
	 */
	public static function is_active() {
		return is_object( self::$block )
			&& is_object( self::$enrolment );
	}

	/** @return object|null */
	public static function get_block() {
		return self::$block;
	}

	/** @return object|null */
	public static function get_enrolment() {
		return self::$enrolment;
	}

	/** @return object|null */
	public static function get_session() {
		return self::$session;
	}
}
