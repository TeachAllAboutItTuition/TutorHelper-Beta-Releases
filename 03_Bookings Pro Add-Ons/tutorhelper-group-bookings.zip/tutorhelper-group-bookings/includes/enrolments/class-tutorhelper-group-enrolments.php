<?php
/**
 * Group Lesson enrolment service.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores student enrolments for Group Lesson blocks.
 */
final class TutorHelper_Group_Enrolments {

	const STATUS_PENDING = 'pending';
	const STATUS_AWAITING_PAYMENT = 'awaiting_payment';
	const STATUS_SECURED = 'secured';
	const STATUS_CANCELLED = 'cancelled';
	const STATUS_COMPLETED = 'completed';

	/**
	 * Return the enrolments table name.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		return TutorHelper_Group_Bookings_Database::get_table_name( 'enrolments' );
	}

	/**
	 * Retrieve one enrolment.
	 *
	 * @param int $enrolment_id Enrolment ID.
	 * @return object|null
	 */
	public static function get_by_id( $enrolment_id ) {
		global $wpdb;

		$enrolment_id = absint( $enrolment_id );
		if ( ! $enrolment_id ) {
			return null;
		}

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Enrolment state must be current for capacity and booking creation.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE id = %d',
				self::get_table_name(),
				$enrolment_id
			)
		);
	}

	/**
	 * Retrieve an enrolment by block and student.
	 *
	 * @param int $block_id Group Block ID.
	 * @param int $student_user_id Student user ID.
	 * @return object|null
	 */
	public static function get_for_student( $block_id, $student_user_id ) {
		global $wpdb;

		$block_id = absint( $block_id );
		$student_user_id = absint( $student_user_id );

		if ( ! $block_id || ! $student_user_id ) {
			return null;
		}

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Enrolment state must be current for duplicate and capacity checks.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE block_id = %d AND student_user_id = %d',
				self::get_table_name(),
				$block_id,
				$student_user_id
			)
		);
	}

	/**
	 * Return all enrolments for a block.
	 *
	 * @param int $block_id Group Block ID.
	 * @return array
	 */
	public static function get_for_block( $block_id ) {
		global $wpdb;

		$block_id = absint( $block_id );
		if ( ! $block_id ) {
			return array();
		}

		$results = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current enrolment state drives live block capacity.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE block_id = %d ORDER BY joined_at ASC, id ASC',
				self::get_table_name(),
				$block_id
			)
		);

		return is_array( $results ) ? $results : array();
	}

	/**
	 * Count enrolments that currently reserve a place.
	 *
	 * Awaiting-payment enrolments reserve capacity even though they do not
	 * yet count toward the minimum required to confirm the block.
	 *
	 * @param int $block_id Group Block ID.
	 * @return int
	 */
	public static function count_reserved_places( $block_id ) {
		global $wpdb;

		$block_id = absint( $block_id );
		if ( ! $block_id ) {
			return 0;
		}

		return absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Capacity must be calculated from current enrolment state.
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i WHERE block_id = %d AND status IN ( %s, %s, %s )',
					self::get_table_name(),
					$block_id,
					self::STATUS_PENDING,
					self::STATUS_AWAITING_PAYMENT,
					self::STATUS_SECURED
				)
			)
		);
	}

	/**
	 * Count enrolments that satisfy the block minimum.
	 *
	 * @param int $block_id Group Block ID.
	 * @return int
	 */
	public static function count_secured( $block_id ) {
		global $wpdb;

		$block_id = absint( $block_id );
		if ( ! $block_id ) {
			return 0;
		}

		return absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Readiness must reflect current secured enrolments.
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i WHERE block_id = %d AND status = %s',
					self::get_table_name(),
					$block_id,
					self::STATUS_SECURED
				)
			)
		);
	}

	/**
	 * Enrol one student in a Group Lesson block.
	 *
	 * @param int $block_id Group Block ID.
	 * @param int $student_user_id Student user ID.
	 * @return int|WP_Error Enrolment ID on success.
	 */
	public static function enrol_student( $block_id, $student_user_id ) {
		global $wpdb;

		$block_id = absint( $block_id );
		$student_user_id = absint( $student_user_id );
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );

		if ( ! $block ) {
			return new WP_Error(
				'tutorhelper_group_enrolment_block_missing',
				__( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$booking_window = TutorHelper_Group_Blocks::validate_booking_window( $block );
		if ( is_wp_error( $booking_window ) ) {
			return $booking_window;
		}

		if (
			in_array(
				sanitize_key( $block->status ),
				array(
					TutorHelper_Group_Blocks::STATUS_CANCELLED,
					TutorHelper_Group_Blocks::STATUS_COMPLETED,
				),
				true
			)
		) {
			return new WP_Error(
				'tutorhelper_group_enrolment_block_closed',
				__( 'Students cannot be added to a cancelled or completed Group Lesson block.', 'tutorhelper-group-bookings' )
			);
		}

		$student = TutorHelper_Students::get_student( $student_user_id );
		if ( ! $student instanceof WP_User ) {
			return new WP_Error(
				'tutorhelper_group_enrolment_student_missing',
				__( 'The selected student could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$is_public_booking = TutorHelper_Group_Blocks::is_open_for_public_booking( $block );
		$membership_added = false;

		if ( $is_public_booking ) {
			$public_booking = TutorHelper_Group_Blocks::validate_public_booking( $block );
			if ( is_wp_error( $public_booking ) ) {
				return $public_booking;
			}
		}

		if ( ! TutorHelper_Pro_Groups::student_is_in_group( $block->group_id, $student_user_id ) ) {
			if ( ! $is_public_booking ) {
				return new WP_Error(
					'tutorhelper_group_enrolment_membership_required',
					__( 'The student must belong to the linked TutorHelper Pro Group before they can join this lesson block.', 'tutorhelper-group-bookings' )
				);
			}

			$membership = TutorHelper_Pro_Groups::assign_student( $block->group_id, $student_user_id );
			if ( is_wp_error( $membership ) ) {
				return $membership;
			}

			$membership_added = true;
		}

		if ( self::get_for_student( $block_id, $student_user_id ) ) {
			return new WP_Error(
				'tutorhelper_group_enrolment_duplicate',
				__( 'This student already has an enrolment record for the lesson block.', 'tutorhelper-group-bookings' )
			);
		}

		$maximum = null !== $block->max_enrolments ? absint( $block->max_enrolments ) : 0;
		if ( $maximum && self::count_reserved_places( $block_id ) >= $maximum ) {
			if ( $membership_added ) {
				TutorHelper_Pro_Groups::remove_student( $block->group_id, $student_user_id );
			}

			return new WP_Error(
				'tutorhelper_group_enrolment_full',
				__( 'This Group Lesson block is full.', 'tutorhelper-group-bookings' )
			);
		}

		$sessions = TutorHelper_Group_Sessions::get_for_block( $block_id );
		if ( empty( $sessions ) ) {
			if ( $membership_added ) {
				TutorHelper_Pro_Groups::remove_student( $block->group_id, $student_user_id );
			}

			return new WP_Error(
				'tutorhelper_group_enrolment_sessions_missing',
				__( 'The Group Lesson block has no generated sessions.', 'tutorhelper-group-bookings' )
			);
		}

		$payment_mode = sanitize_key( $block->payment_mode );
		$status = TutorHelper_Group_Blocks::PAYMENT_MANUAL === $payment_mode
			? self::STATUS_SECURED
			: self::STATUS_AWAITING_PAYMENT;

		$agreed_price = TutorHelper_Group_Blocks::calculate_block_total(
			$block,
			count( $sessions )
		);
		$now = current_time( 'mysql', true );

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Group enrolments are stored in the add-on custom table.
			self::get_table_name(),
			array(
				'block_id' => $block_id,
				'student_user_id' => $student_user_id,
				'agreed_price_minor_units' => absint( $agreed_price ),
				'payment_mode' => $payment_mode,
				'deposit_type' => sanitize_key( $block->deposit_type ),
				'deposit_value' => absint( $block->deposit_value ),
				'currency' => strtoupper( sanitize_text_field( $block->currency ) ),
				'payment_status' => TutorHelper_Group_Payments::STATUS_UNPAID,
				'amount_paid_minor_units' => 0,
				'amount_refunded_minor_units' => 0,
				'amount_credited_minor_units' => 0,
				'status' => $status,
				'joined_at' => $now,
				'created_at' => $now,
				'updated_at' => $now,
			),
			array( '%d', '%d', '%d', '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s' )
		);

		if ( false === $inserted ) {
			if ( $membership_added ) {
				TutorHelper_Pro_Groups::remove_student( $block->group_id, $student_user_id );
			}

			return new WP_Error(
				'tutorhelper_group_enrolment_create_failed',
				$wpdb->last_error ? $wpdb->last_error : __( 'The student could not be enrolled in the Group Lesson block.', 'tutorhelper-group-bookings' )
			);
		}

		$enrolment_id = absint( $wpdb->insert_id );
		$bookings = TutorHelper_Group_Enrolment_Bookings::generate_for_enrolment( $enrolment_id );

		if ( is_wp_error( $bookings ) ) {
			$wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back an enrolment when its Core bookings cannot be generated.
				self::get_table_name(),
				array( 'id' => $enrolment_id ),
				array( '%d' )
			);

			if ( $membership_added ) {
				TutorHelper_Pro_Groups::remove_student( $block->group_id, $student_user_id );
			}

			return $bookings;
		}

		$secured_count = self::count_secured( $block_id );

		if ( class_exists( 'TutorHelper_Group_Emails' ) ) {
			TutorHelper_Group_Emails::begin_enrolment_notification( $enrolment_id );
		}

		do_action(
			'tutorhelper_group_enrolment_changed',
			$block_id,
			$secured_count
		);

		do_action(
			'tutorhelper_group_student_enrolled',
			$enrolment_id,
			$block_id,
			$student_user_id,
			$bookings
		);

		if ( class_exists( 'TutorHelper_Group_Emails' ) ) {
			TutorHelper_Group_Emails::end_enrolment_notification();
		}

		return $enrolment_id;
	}

	/**
	 * Change an enrolment lifecycle status.
	 *
	 * This is used by later payment and cancellation workflows so that
	 * readiness remains centralised from the start.
	 *
	 * @param int    $enrolment_id Enrolment ID.
	 * @param string $status New status.
	 * @return true|WP_Error
	 */
	public static function update_status( $enrolment_id, $status ) {
		global $wpdb;

		$enrolment = self::get_by_id( $enrolment_id );
		if ( ! $enrolment ) {
			return new WP_Error(
				'tutorhelper_group_enrolment_not_found',
				__( 'The Group Lesson enrolment could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$status = sanitize_key( $status );
		$allowed = array(
			self::STATUS_PENDING,
			self::STATUS_AWAITING_PAYMENT,
			self::STATUS_SECURED,
			self::STATUS_CANCELLED,
			self::STATUS_COMPLETED,
		);

		if ( ! in_array( $status, $allowed, true ) ) {
			return new WP_Error(
				'tutorhelper_group_enrolment_status_invalid',
				__( 'The Group Lesson enrolment status is invalid.', 'tutorhelper-group-bookings' )
			);
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Enrolment lifecycle state is stored in the add-on custom table.
			self::get_table_name(),
			array(
				'status' => $status,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $enrolment->id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error(
				'tutorhelper_group_enrolment_status_update_failed',
				__( 'The Group Lesson enrolment could not be updated.', 'tutorhelper-group-bookings' )
			);
		}

		do_action(
			'tutorhelper_group_enrolment_changed',
			absint( $enrolment->block_id ),
			self::count_secured( $enrolment->block_id )
		);

		return true;
	}
}
