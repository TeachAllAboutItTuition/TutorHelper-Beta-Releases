<?php
/**
 * Tutor-only removal of a student from the remaining Group Lesson sessions.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Preserves past records while cancelling only the selected enrolment's future child bookings.
 */
final class TutorHelper_Group_Enrolment_Removal {

	/**
	 * Remove an enrolment from remaining sessions without changing the historic enrolment record.
	 *
	 * @param int    $enrolment_id Enrolment ID.
	 * @param string $reason Tutor-supplied reason.
	 * @param int    $removed_by_user_id Tutor/admin user ID.
	 * @return int|WP_Error Number of sessions removed.
	 */
	public static function remove_from_remainder( $enrolment_id, $reason, $removed_by_user_id ) {
		global $wpdb;

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		$block = $enrolment ? TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id ) : null;
		if ( ! $enrolment || ! $block ) {
			return new WP_Error( 'tutorhelper_group_remainder_enrolment_missing', __( 'The Group Lesson enrolment could not be found.', 'tutorhelper-group-bookings' ) );
		}

		try {
			$timezone = new DateTimeZone( $block->timezone );
			$today = ( new DateTimeImmutable( 'now', $timezone ) )->format( 'Y-m-d' );
		} catch ( Exception $exception ) {
			return new WP_Error( 'tutorhelper_group_remainder_timezone_invalid', __( 'The Group Lesson timezone is invalid.', 'tutorhelper-group-bookings' ) );
		}

		$sessions = array_filter(
			TutorHelper_Group_Sessions::get_for_block( $block->id ),
			static function ( $session ) use ( $today ) {
				return TutorHelper_Group_Sessions::STATUS_SCHEDULED === sanitize_key( $session->status ) && $session->session_date >= $today;
			}
		);
		if ( empty( $sessions ) ) {
			return new WP_Error( 'tutorhelper_group_remainder_empty', __( 'There are no remaining scheduled sessions for this student.', 'tutorhelper-group-bookings' ) );
		}

		$exclusions_table = TutorHelper_Group_Bookings_Database::get_table_name( 'enrolment_session_exclusions' );
		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Exclusion records and booking cancellations must be atomic.
		$removed = 0;

		foreach ( $sessions as $session ) {
			$already_removed = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Exclusion state must be current to make retries safe.
				$wpdb->prepare( 'SELECT session_id FROM %i WHERE session_id = %d AND enrolment_id = %d', $exclusions_table, absint( $session->id ), absint( $enrolment->id ) )
			);
			if ( $already_removed ) {
				continue;
			}

			$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Dedicated audit record for a remainder removal.
				$exclusions_table,
				array(
					'session_id' => absint( $session->id ),
					'enrolment_id' => absint( $enrolment->id ),
					'student_user_id' => absint( $enrolment->student_user_id ),
					'reason' => sanitize_textarea_field( $reason ),
					'removed_by_user_id' => absint( $removed_by_user_id ),
					'removed_at' => current_time( 'mysql', true ),
				),
				array( '%d', '%d', '%d', '%s', '%d', '%s' )
			);
			if ( false === $inserted ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Abort incomplete removal.
				return new WP_Error( 'tutorhelper_group_remainder_save_failed', __( 'The student could not be removed from the remaining sessions.', 'tutorhelper-group-bookings' ) );
			}

			$booking_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Bridge record identifies the child booking to cancel.
				$wpdb->prepare( 'SELECT booking_id FROM %i WHERE session_id = %d AND enrolment_id = %d', TutorHelper_Group_Enrolment_Bookings::get_table_name(), absint( $session->id ), absint( $enrolment->id ) )
			);
			if ( $booking_id ) {
				$result = TutorHelper_Booking_Records::update_status( absint( $booking_id ), TutorHelper_Booking_Records::STATUS_CANCELLED );
				if ( is_wp_error( $result ) ) {
					$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Abort incomplete removal.
					return $result;
				}
			}
			++$removed;
		}

		$marked = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Persist the enrolment-wide remainder removal for future extensions.
			TutorHelper_Group_Bookings_Database::get_table_name( 'enrolments' ),
			array(
				'remainder_removed_at' => current_time( 'mysql', true ),
				'remainder_removal_reason' => sanitize_textarea_field( $reason ),
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $enrolment->id ) ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
		if ( false === $marked ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Abort incomplete removal.
			return new WP_Error( 'tutorhelper_group_remainder_save_failed', __( 'The student could not be removed from the remaining sessions.', 'tutorhelper-group-bookings' ) );
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Complete the full remainder removal.
		do_action( 'tutorhelper_group_enrolment_remainder_removed', $enrolment, $removed );

		return $removed;
	}

	/**
	 * Check whether a child booking should be suppressed because this student was removed.
	 *
	 * @param int $session_id Session ID.
	 * @param int $enrolment_id Enrolment ID.
	 * @return bool
	 */
	public static function is_removed( $session_id, $enrolment_id ) {
		global $wpdb;
		return (bool) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Prevent recreating deliberately removed child bookings.
			$wpdb->prepare( 'SELECT session_id FROM %i WHERE session_id = %d AND enrolment_id = %d', TutorHelper_Group_Bookings_Database::get_table_name( 'enrolment_session_exclusions' ), absint( $session_id ), absint( $enrolment_id ) )
		);
	}
}
