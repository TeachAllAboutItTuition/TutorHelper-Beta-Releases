<?php
/**
 * Core booking generation for Group Lesson enrolments.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates and links one Core booking per Group Session for an enrolment.
 */
final class TutorHelper_Group_Enrolment_Bookings {

	/**
	 * Return the session-booking bridge table name.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		return TutorHelper_Group_Bookings_Database::get_table_name( 'session_bookings' );
	}

	/**
	 * Generate all Core bookings for one enrolment.
	 *
	 * @param int $enrolment_id Enrolment ID.
	 * @return array|WP_Error Booking IDs on success.
	 */
	public static function generate_for_enrolment( $enrolment_id ) {
		global $wpdb;

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		if ( ! $enrolment ) {
			return new WP_Error(
				'tutorhelper_group_booking_enrolment_missing',
				__( 'The Group Lesson enrolment could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$block = TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id );
		if ( ! $block ) {
			return new WP_Error(
				'tutorhelper_group_booking_block_missing',
				__( 'The Group Lesson block could not be found.', 'tutorhelper-group-bookings' )
			);
		}

		$sessions = TutorHelper_Group_Sessions::get_for_block( $block->id );
		if ( empty( $sessions ) ) {
			return new WP_Error(
				'tutorhelper_group_booking_sessions_missing',
				__( 'The Group Lesson block has no sessions to book.', 'tutorhelper-group-bookings' )
			);
		}

		$created_booking_ids = array();

		TutorHelper_Group_Booking_Context::begin( $block, $enrolment );

		foreach ( $sessions as $session ) {
			TutorHelper_Group_Booking_Context::set_session( $session );
			$booking_id = self::create_for_session( $block, $enrolment, $session );

			if ( is_wp_error( $booking_id ) ) {
				TutorHelper_Group_Booking_Context::end();
				self::rollback_bookings( $created_booking_ids );
				return $booking_id;
			}

			$linked = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Group-to-Core booking relationships are stored in the add-on bridge table.
				self::get_table_name(),
				array(
					'session_id' => absint( $session->id ),
					'enrolment_id' => absint( $enrolment->id ),
					'booking_id' => absint( $booking_id ),
					'student_user_id' => absint( $enrolment->student_user_id ),
					'created_at' => current_time( 'mysql', true ),
				),
				array( '%d', '%d', '%d', '%d', '%s' )
			);

			if ( false === $linked ) {
				TutorHelper_Group_Booking_Context::end();
				$created_booking_ids[] = absint( $booking_id );
				self::rollback_bookings( $created_booking_ids );

				return new WP_Error(
					'tutorhelper_group_booking_link_failed',
					$wpdb->last_error ? $wpdb->last_error : __( 'A Group Lesson booking could not be linked to its session.', 'tutorhelper-group-bookings' )
				);
			}

			$created_booking_ids[] = absint( $booking_id );
		}

		TutorHelper_Group_Booking_Context::end();

		return $created_booking_ids;
	}

	/**
	 * Create and link a booking for one newly added session, if it is not linked already.
	 *
	 * @param int $enrolment_id Enrolment ID.
	 * @param int $session_id Session ID.
	 * @return int|WP_Error Existing or created booking ID.
	 */
	public static function generate_for_session( $enrolment_id, $session_id ) {
		global $wpdb;

		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		$session = TutorHelper_Group_Sessions::get_by_id( $session_id );
		$block = $enrolment ? TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id ) : null;
		if ( ! $enrolment || ! $session || ! $block || absint( $session->block_id ) !== absint( $block->id ) ) {
			return new WP_Error( 'tutorhelper_group_booking_session_invalid', __( 'The Group Lesson session could not be prepared for this enrolment.', 'tutorhelper-group-bookings' ) );
		}

		if ( class_exists( 'TutorHelper_Group_Enrolment_Removal' ) && TutorHelper_Group_Enrolment_Removal::is_removed( $session_id, $enrolment_id ) ) {
			return new WP_Error( 'tutorhelper_group_booking_session_removed', __( 'This student has been removed from this remaining Group Lesson session.', 'tutorhelper-group-bookings' ) );
		}

		$existing = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- The bridge is the authoritative idempotency record.
			$wpdb->prepare( 'SELECT booking_id FROM %i WHERE session_id = %d AND enrolment_id = %d', self::get_table_name(), absint( $session_id ), absint( $enrolment_id ) )
		);
		if ( $existing ) {
			return absint( $existing );
		}

		TutorHelper_Group_Booking_Context::begin( $block, $enrolment );
		TutorHelper_Group_Booking_Context::set_session( $session );
		$booking_id = self::create_for_session( $block, $enrolment, $session );
		TutorHelper_Group_Booking_Context::end();
		if ( is_wp_error( $booking_id ) ) {
			return $booking_id;
		}

		$linked = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Group-to-Core booking relationships are stored in the add-on bridge table.
			self::get_table_name(),
			array(
				'session_id' => absint( $session_id ),
				'enrolment_id' => absint( $enrolment_id ),
				'booking_id' => absint( $booking_id ),
				'student_user_id' => absint( $enrolment->student_user_id ),
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%d', '%d', '%d', '%d', '%s' )
		);

		if ( false === $linked ) {
			self::rollback_bookings( array( $booking_id ) );
			return new WP_Error( 'tutorhelper_group_booking_link_failed', $wpdb->last_error ? $wpdb->last_error : __( 'A Group Lesson booking could not be linked to its session.', 'tutorhelper-group-bookings' ) );
		}

		return absint( $booking_id );
	}

	/**
	 * Create one Core booking for one Group Session.
	 *
	 * @param object $block Group Block.
	 * @param object $enrolment Enrolment.
	 * @param object $session Group Session.
	 * @return int|WP_Error
	 */
	private static function create_for_session( $block, $enrolment, $session ) {
		$booking_status = self::block_is_confirmed( $block )
			? TutorHelper_Booking_Records::STATUS_CONFIRMED
			: TutorHelper_Booking_Records::STATUS_UNCONFIRMED;

		try {
			$timezone = new DateTimeZone( sanitize_text_field( $block->timezone ) );
			$utc = new DateTimeZone( 'UTC' );
			$booking_start = ( new DateTimeImmutable( $session->booking_start, $utc ) )
				->setTimezone( $timezone )
				->format( 'Y-m-d H:i:s' );
			$booking_end = ( new DateTimeImmutable( $session->booking_end, $utc ) )
				->setTimezone( $timezone )
				->format( 'Y-m-d H:i:s' );
		} catch ( Exception $exception ) {
			return new WP_Error(
				'tutorhelper_group_booking_timezone_invalid',
				__( 'The Group Lesson timezone could not be applied to its child booking.', 'tutorhelper-group-bookings' )
			);
		}

		$location_details = TutorHelper_Group_Sessions::get_location_details( $session, $block );

		return TutorHelper_Booking_Records::create(
			array(
				'booking_type_id' => absint( $block->booking_type_id ),
				'student_user_id' => absint( $enrolment->student_user_id ),
				'tutor_user_id' => absint( $block->tutor_user_id ),
				'booking_start' => $booking_start,
				'booking_end' => $booking_end,
				'timezone' => sanitize_text_field( $block->timezone ),
				'location_type' => sanitize_key( $block->location_type ),
				'location_details' => $location_details,
				'status' => $booking_status,
				'source' => TutorHelper_Booking_Records::SOURCE_TUTOR,
				'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
				'notes' => sprintf(
					/* translators: %d Group Lesson block ID. */
					__( 'Group Lesson block #%d', 'tutorhelper-group-bookings' ),
					absint( $block->id )
				),
			)
		);
	}

	/**
	 * Check whether a block is currently confirmed for lesson purposes.
	 *
	 * @param object $block Group Block.
	 * @return bool
	 */
	private static function block_is_confirmed( $block ) {
		return in_array(
			sanitize_key( $block->status ),
			array(
				TutorHelper_Group_Blocks::STATUS_CONFIRMED,
				TutorHelper_Group_Blocks::STATUS_FULL,
			),
			true
		);
	}

	/**
	 * Delete partially-created Core bookings and bridge rows after failure.
	 *
	 * @param array $booking_ids Booking IDs.
	 * @return void
	 */
	private static function rollback_bookings( $booking_ids ) {
		global $wpdb;

		foreach ( $booking_ids as $booking_id ) {
			$booking_id = absint( $booking_id );
			if ( ! $booking_id ) {
				continue;
			}

			$wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back bridge rows for an incomplete enrolment transaction.
				self::get_table_name(),
				array( 'booking_id' => $booking_id ),
				array( '%d' )
			);

			$wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back Core bookings created by this incomplete Group Lesson enrolment transaction.
				TutorHelper_Booking_Records::get_table_name(),
				array( 'id' => $booking_id ),
				array( '%d' )
			);
		}
	}

	/**
	 * Return Core booking records linked to one enrolment.
	 *
	 * @param int $enrolment_id Enrolment ID.
	 * @return array
	 */
	public static function get_for_enrolment( $enrolment_id ) {
		global $wpdb;

		$enrolment_id = absint( $enrolment_id );
		if ( ! $enrolment_id ) {
			return array();
		}

		$booking_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Linked booking state must be current for lifecycle updates.
			$wpdb->prepare(
				'SELECT booking_id FROM %i WHERE enrolment_id = %d ORDER BY session_id ASC',
				self::get_table_name(),
				$enrolment_id
			)
		);

		$bookings = array();
		foreach ( $booking_ids as $booking_id ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
			if ( $booking ) {
				$bookings[] = $booking;
			}
		}

		return $bookings;
	}
}
