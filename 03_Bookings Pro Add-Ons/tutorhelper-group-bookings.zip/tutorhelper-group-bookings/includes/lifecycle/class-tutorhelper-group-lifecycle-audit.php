<?php
/**
 * Group lifecycle audit service.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores retry-safe audit state for group conversions and cancellations.
 */
final class TutorHelper_Group_Lifecycle_Audit {

	/**
	 * Return the audit table name.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		return TutorHelper_Group_Bookings_Database::
			get_table_name( 'lifecycle_audit' );
	}

	/**
	 * Return an audit record by its idempotency key.
	 *
	 * @param string $lifecycle_key Stable operation key.
	 *
	 * @return object|null
	 */
	public static function get_by_key( $lifecycle_key ) {
		global $wpdb;

		$lifecycle_key = sanitize_key( $lifecycle_key );

		if ( '' === $lifecycle_key ) {
			return null;
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE lifecycle_key = %s',
				self::get_table_name(),
				$lifecycle_key
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Lifecycle state must be current for retry safety.
	}

	/**
	 * Create or refresh one lifecycle audit record.
	 *
	 * @param array $args Audit values.
	 *
	 * @return int|WP_Error Audit record ID.
	 */
	public static function record( $args ) {
		global $wpdb;

		$args = is_array( $args )
			? $args
			: array();

		$lifecycle_key = isset( $args['lifecycle_key'] )
			? sanitize_key( $args['lifecycle_key'] )
			: '';
		$operation = isset( $args['operation'] )
			? sanitize_key( $args['operation'] )
			: '';
		$status = isset( $args['status'] )
			? sanitize_key( $args['status'] )
			: '';

		if (
			'' === $lifecycle_key
			|| '' === $operation
			|| ! in_array(
				$status,
				array( 'started', 'completed', 'failed' ),
				true
			)
		) {
			return new WP_Error(
				'tutorhelper_group_lifecycle_audit_invalid',
				__(
					'The Group lifecycle audit record is invalid.',
					'tutorhelper-group-bookings'
				)
			);
		}

		$existing = self::get_by_key( $lifecycle_key );
		$now = current_time( 'mysql', true );
		$context = isset( $args['context'] )
			&& is_array( $args['context'] )
			? $args['context']
			: array();

		$values = array(
			'lifecycle_key' => $lifecycle_key,
			'operation' => $operation,
			'status' => $status,
			'block_id' => isset( $args['block_id'] )
				? absint( $args['block_id'] )
				: 0,
			'enrolment_id' => isset( $args['enrolment_id'] )
				? absint( $args['enrolment_id'] )
				: 0,
			'source_booking_id' => isset( $args['source_booking_id'] )
				? absint( $args['source_booking_id'] )
				: 0,
			'target_booking_id' => isset( $args['target_booking_id'] )
				? absint( $args['target_booking_id'] )
				: 0,
			'context' => wp_json_encode( $context ),
			'created_by_user_id' => isset( $args['created_by_user_id'] )
				? absint( $args['created_by_user_id'] )
				: get_current_user_id(),
			'updated_at' => $now,
		);

		if ( $existing ) {
			$updated = $wpdb->update(
				self::get_table_name(),
				$values,
				array( 'id' => absint( $existing->id ) ),
				array( '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%d', '%s' ),
				array( '%d' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Persisted lifecycle state supports safe retried operations.

			if ( false === $updated ) {
				return new WP_Error(
					'tutorhelper_group_lifecycle_audit_update_failed',
					__(
						'The Group lifecycle audit record could not be updated.',
						'tutorhelper-group-bookings'
					)
				);
			}

			return absint( $existing->id );
		}

		$values['created_at'] = $now;

		$inserted = $wpdb->insert(
			self::get_table_name(),
			$values,
			array( '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%d', '%s', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Group lifecycle audits are stored in an add-on custom table.

		if ( false === $inserted ) {
			return new WP_Error(
				'tutorhelper_group_lifecycle_audit_create_failed',
				$wpdb->last_error
					? $wpdb->last_error
					: __(
						'The Group lifecycle audit record could not be created.',
						'tutorhelper-group-bookings'
					)
			);
		}

		return absint( $wpdb->insert_id );
	}
}
