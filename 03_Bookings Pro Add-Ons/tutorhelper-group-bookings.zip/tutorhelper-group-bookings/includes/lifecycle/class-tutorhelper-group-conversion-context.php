<?php
/**
 * Temporary Core conflict-query scope for booking conversions.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Excludes only the individual booking records being replaced while the
 * replacement Group Block schedule is checked and created.
 */
final class TutorHelper_Group_Conversion_Context {

	/** @var array<int> */
	private static $source_booking_ids = array();

	/** Register the narrowly-scoped Core conflict-query filter. */
	public static function init() {
		add_filter( 'query', array( __CLASS__, 'exclude_source_bookings_from_conflicts' ), 21 );
	}

	/**
	 * Start a conversion schedule context.
	 *
	 * @param array $booking_ids Source Core booking IDs being replaced.
	 * @return void
	 */
	public static function begin( $booking_ids ) {
		self::$source_booking_ids = array_values(
			array_unique(
				array_filter( array_map( 'absint', is_array( $booking_ids ) ? $booking_ids : array() ) )
			)
		);
	}

	/** End the conversion schedule context. */
	public static function end() {
		self::$source_booking_ids = array();
	}

	/**
	 * Exclude the retiring source bookings from Core's overlap query.
	 *
	 * The scope is active only while a replacement Group Block is being
	 * created. Availability, leave, exclusion dates and every unrelated
	 * booking remain subject to the normal Core checks.
	 *
	 * @param string $query SQL query.
	 * @return string
	 */
	public static function exclude_source_bookings_from_conflicts( $query ) {
		if ( empty( self::$source_booking_ids ) ) {
			return $query;
		}

		$bookings_table = TutorHelper_Booking_Records::get_table_name();
		$is_legacy_conflict_query = false !== strpos( $query, 'booking_end >' );
		$is_buffered_conflict_query = false !== strpos( $query, 'DATE_ADD(' )
			&& false !== strpos( $query, 'booking_end' )
			&& false !== strpos( $query, 'buffer_after_minutes' );

		if (
			false === strpos( $query, $bookings_table )
			|| false === strpos( $query, 'tutor_user_id' )
			|| false === strpos( $query, 'booking_start <' )
			|| ( ! $is_legacy_conflict_query && ! $is_buffered_conflict_query )
			|| false !== strpos( $query, 'ORDER BY' )
		) {
			return $query;
		}

		$id_column = false !== strpos( $query, 'b.tutor_user_id' ) ? 'b.id' : 'id';

		return $query . ' AND ' . $id_column . ' NOT IN (' . implode( ',', self::$source_booking_ids ) . ')';
	}
}
