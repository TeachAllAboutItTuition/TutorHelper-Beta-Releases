<?php
/**
 * Individual-booking to Group Lesson conversion service.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Safely creates a new Group Block from an individual booking or the
 * remaining compatible future occurrences in a recurring series.
 */
final class TutorHelper_Group_Conversions {

	const SCOPE_SINGLE = 'single';
	const SCOPE_REMAINING_SERIES = 'remaining_series';

	/**
	 * Build the complete, server-validated conversion preview.
	 *
	 * The returned values are suitable for display but must be rebuilt before
	 * execution. This prevents a stale browser preview from retiring changed
	 * bookings or applying the wrong financial values.
	 *
	 * @param int    $source_booking_id Source Core booking ID.
	 * @param string $scope Conversion scope.
	 * @param int    $group_id Existing TutorHelper Pro Group ID.
	 * @param int    $tutor_user_id Tutor performing the conversion.
	 * @param int    $target_booking_type_id Booking Type for the new Group block.
	 * @return array|WP_Error
	 */
	public static function build_preview( $source_booking_id, $scope, $group_id, $tutor_user_id, $target_booking_type_id = 0, $block_options = array() ) {
		$source_booking_id = absint( $source_booking_id );
		$scope = sanitize_key( $scope );
		$group_id = absint( $group_id );
		$tutor_user_id = absint( $tutor_user_id );
		$target_booking_type_id = absint( $target_booking_type_id );

		if ( ! in_array( $scope, array( self::SCOPE_SINGLE, self::SCOPE_REMAINING_SERIES ), true ) ) {
			return new WP_Error(
				'tutorhelper_group_conversion_scope_invalid',
				__( 'Choose whether to convert this lesson or the remaining recurring series.', 'tutorhelper-group-bookings' )
			);
		}

		$source = self::get_eligible_source_booking( $source_booking_id, $tutor_user_id );
		if ( is_wp_error( $source ) ) {
			return $source;
		}

		$target_booking_type_id = $target_booking_type_id ? $target_booking_type_id : absint( $source->booking_type_id );
		$target_booking_type = TutorHelper_Booking_Types::get_by_id( $target_booking_type_id );
		if ( ! $target_booking_type || empty( $target_booking_type->is_active ) ) {
			return new WP_Error(
				'tutorhelper_group_conversion_booking_type_invalid',
				__( 'Select an active Booking Type for the new Group Lesson.', 'tutorhelper-group-bookings' )
			);
		}

		$group = $group_id ? TutorHelper_Pro_Groups::get_by_id( $group_id ) : null;
		if ( ! $group || empty( $group->is_active ) ) {
			return new WP_Error(
				'tutorhelper_group_conversion_group_invalid',
				__( 'Select an active TutorHelper Pro Group for the converted lessons.', 'tutorhelper-group-bookings' )
			);
		}

		$source_bookings = self::get_source_bookings( $source, $scope, $tutor_user_id );
		if ( is_wp_error( $source_bookings ) ) {
			return $source_bookings;
		}

		$schedule = self::build_schedule( $source_bookings, $scope );
		if ( is_wp_error( $schedule ) ) {
			return $schedule;
		}

		$price_total = 0;
		$paid_total = 0;
		$source_rows = array();

		foreach ( $source_bookings as $booking ) {
			$price = absint( $booking->price_minor_units );
			$totals = TutorHelper_Pro_Finance_Adjustments::get_booking_totals( $booking->id );
			$paid = is_array( $totals ) && isset( $totals['net_paid_minor_units'] )
				? min( $price, absint( $totals['net_paid_minor_units'] ) )
				: 0;

			$price_total += $price;
			$paid_total += $paid;
			$source_rows[] = array(
				'booking_id' => absint( $booking->id ),
				'booking_start' => sanitize_text_field( $booking->booking_start ),
				'price_minor_units' => $price,
				'net_paid_minor_units' => $paid,
			);
		}

		$block_data = array_merge(
			array(
				'group_id' => $group_id,
				'booking_type_id' => $target_booking_type_id,
				'tutor_user_id' => $tutor_user_id,
				'title' => self::get_converted_title( $source, $target_booking_type_id ),
				'start_date' => $schedule['start_date'],
				'end_date' => $schedule['end_date'],
				'excluded_session_dates' => $schedule['excluded_session_dates'],
				'frequency' => $schedule['frequency'],
				'start_time' => $schedule['start_time'],
				'end_time' => $schedule['end_time'],
				'timezone' => $schedule['timezone'],
				'location_type' => sanitize_key( $source->location_type ),
				'location_details' => sanitize_textarea_field( $source->location_details ),
				'bookable_from' => '',
				'bookable_until' => '',
				'min_enrolments' => 1,
				'max_enrolments' => null,
				'pricing_basis' => TutorHelper_Group_Blocks::PRICING_BOOKING_TYPE,
				'fixed_block_price_minor_units' => null,
				'price_per_session_minor_units' => 0,
				'deposit_type' => TutorHelper_Group_Blocks::DEPOSIT_NONE,
				'deposit_value' => 0,
				'currency' => strtoupper( sanitize_text_field( $source->currency ) ),
				'payment_mode' => TutorHelper_Group_Blocks::PAYMENT_MANUAL,
				'student_cancellation_allowed' => 1,
				'cancellation_notice_hours' => 24,
				'deposit_refundable' => 'yes',
				'cancellation_terms' => '',
			),
			self::get_conversion_block_options( $block_options )
		);

		/*
		 * The retiring booking occupies the same time as its Group replacement.
		 * Ignore only those source IDs while validating this new schedule.
		 */
		TutorHelper_Group_Conversion_Context::begin( wp_list_pluck( $source_rows, 'booking_id' ) );
		try {
			$block_data = TutorHelper_Group_Block_Create::prepare( $block_data );
			$session_preview = is_wp_error( $block_data )
				? $block_data
				: TutorHelper_Group_Schedule_Planner::preview(
					(object) $block_data,
					TutorHelper_Group_Schedule_Planner::normalise_dates( $block_data['excluded_session_dates'] )
				);
		} finally {
			TutorHelper_Group_Conversion_Context::end();
		}

		if ( is_wp_error( $block_data ) ) {
			return $block_data;
		}

		if ( is_wp_error( $session_preview ) ) {
			return $session_preview;
		}

		$included_session_count = count( TutorHelper_Group_Schedule_Planner::get_included_dates( $session_preview ) );
		if ( 0 === $included_session_count ) {
			return new WP_Error(
				'tutorhelper_group_conversion_sessions_empty',
				__( 'No Group Lesson sessions remain after blocked or excluded dates were applied.', 'tutorhelper-group-bookings' )
			);
		}

		$group_price_total = TutorHelper_Group_Blocks::calculate_block_total(
			(object) $block_data,
			$included_session_count
		);
		return array(
			'source_booking_id' => absint( $source->id ),
			'source_booking_ids' => wp_list_pluck( $source_rows, 'booking_id' ),
			'source_bookings' => $source_rows,
			'scope' => $scope,
			'group_id' => $group_id,
			'group_name' => sanitize_text_field( $group->name ),
			'target_booking_type_id' => $target_booking_type_id,
			'target_booking_type_title' => ! empty( $target_booking_type->title )
				? sanitize_text_field( $target_booking_type->title )
				: sanitize_text_field( $target_booking_type->name ),
			'student_user_id' => absint( $source->student_user_id ),
			'student_is_member' => TutorHelper_Pro_Groups::student_is_in_group( $group_id, $source->student_user_id ),
			'block_data' => $block_data,
			'conversion_options' => self::get_conversion_block_options( $block_data ),
			'session_preview' => $session_preview,
			'source_price_total_minor_units' => $price_total,
			'price_total_minor_units' => $group_price_total,
			'credit_to_apply_minor_units' => min( $group_price_total, $paid_total ),
			'credit_remaining_minor_units' => max( 0, $paid_total - $group_price_total ),
			'calendar_meet_note' => __(
				'The original booking calendar and Meet records remain unchanged until you confirm. The new Group sessions use the normal shared Group calendar and meeting lifecycle after conversion.',
				'tutorhelper-group-bookings'
			),
		);
	}

	/**
	 * Execute a freshly built conversion.
	 *
	 * @param int    $source_booking_id Source Core booking ID.
	 * @param string $scope Conversion scope.
	 * @param int    $group_id Existing TutorHelper Pro Group ID.
	 * @param int    $tutor_user_id Tutor performing the conversion.
	 * @param int    $target_booking_type_id Booking Type for the new Group block.
	 * @return array|WP_Error
	 */
	public static function convert( $source_booking_id, $scope, $group_id, $tutor_user_id, $target_booking_type_id = 0, $block_options = array() ) {
		$preview = self::build_preview( $source_booking_id, $scope, $group_id, $tutor_user_id, $target_booking_type_id, $block_options );
		if ( is_wp_error( $preview ) ) {
			return $preview;
		}

		$lifecycle_key = self::get_lifecycle_key( $preview );
		$resume_block_id = 0;
		$existing = TutorHelper_Group_Lifecycle_Audit::get_by_key( $lifecycle_key );
		if ( $existing ) {
			$context = json_decode( $existing->context, true );
			$context = is_array( $context ) ? $context : array();

			if ( 'completed' === sanitize_key( $existing->status ) ) {
				return array(
					'block_id' => absint( $existing->block_id ),
					'enrolment_id' => absint( $existing->enrolment_id ),
					'target_booking_ids' => isset( $context['target_booking_ids'] ) && is_array( $context['target_booking_ids'] )
						? array_map( 'absint', $context['target_booking_ids'] )
						: array(),
					'already_completed' => true,
				);
			}

			/*
			 * A failure before the first enrolment may leave an otherwise unused
			 * Group Block. Resume that same replacement rather than creating a
			 * duplicate block, sessions or Calendar event.
			 */
			if ( 'failed' === sanitize_key( $existing->status ) && absint( $existing->block_id ) && ! absint( $existing->enrolment_id ) ) {
				$existing_block = TutorHelper_Group_Blocks::get_by_id( $existing->block_id );
				$existing_enrolments = TutorHelper_Group_Enrolments::get_for_block( $existing->block_id );

				if ( $existing_block && empty( $existing_enrolments ) ) {
					$resume_block_id = absint( $existing->block_id );
				}
			}

			if ( ! $resume_block_id ) {
				return new WP_Error(
					'tutorhelper_group_conversion_existing_attempt',
					__( 'This conversion already has an incomplete attempt. No duplicate Group block has been created; review Diagnostics before trying a different conversion.', 'tutorhelper-group-bookings' )
				);
			}
		}

		$audit_context = array(
			'source_booking_ids' => $preview['source_booking_ids'],
			'scope' => $preview['scope'],
			'group_id' => $preview['group_id'],
			'target_booking_type_id' => $preview['target_booking_type_id'],
			'price_total_minor_units' => $preview['price_total_minor_units'],
			'credit_to_apply_minor_units' => $preview['credit_to_apply_minor_units'],
		);

		$audit = TutorHelper_Group_Lifecycle_Audit::record(
			array(
				'lifecycle_key' => $lifecycle_key,
				'operation' => 'booking_to_group_conversion',
				'status' => 'started',
				'source_booking_id' => $preview['source_booking_id'],
				'context' => $audit_context,
				'created_by_user_id' => $tutor_user_id,
			)
		);
		if ( is_wp_error( $audit ) ) {
			return $audit;
		}

		if ( $resume_block_id ) {
			$block_id = $resume_block_id;
			$audit_context['resumed_failed_attempt'] = true;
		} else {
			TutorHelper_Group_Conversion_Context::begin( $preview['source_booking_ids'] );
			try {
				$block_id = TutorHelper_Group_Block_Create::create( $preview['block_data'] );
			} finally {
				TutorHelper_Group_Conversion_Context::end();
			}
			if ( is_wp_error( $block_id ) ) {
				return self::fail_conversion( $lifecycle_key, $preview, 0, 0, $block_id );
			}
		}

		$audit_context['block_id'] = absint( $block_id );

		if ( ! $preview['student_is_member'] ) {
			$membership = TutorHelper_Pro_Groups::assign_student(
				$preview['group_id'],
				$preview['student_user_id']
			);
			if ( is_wp_error( $membership ) || false === $membership ) {
				$error = is_wp_error( $membership )
					? $membership
					: new WP_Error(
						'tutorhelper_group_conversion_membership_failed',
						__( 'The student could not be added to the selected TutorHelper Pro Group.', 'tutorhelper-group-bookings' )
					);
				return self::fail_conversion( $lifecycle_key, $preview, $block_id, 0, $error, $audit_context );
			}
			$audit_context['student_added_to_group'] = true;
		}

		/*
		 * The first enrolment creates child Core bookings. Keep the source
		 * replacement scope active for this operation as well, otherwise the
		 * original individual booking incorrectly clashes with its replacement.
		 */
		TutorHelper_Group_Conversion_Context::begin( $preview['source_booking_ids'] );
		try {
			$enrolment_id = TutorHelper_Group_Enrolments::enrol_student(
				$block_id,
				$preview['student_user_id']
			);
		} finally {
			TutorHelper_Group_Conversion_Context::end();
		}
		if ( is_wp_error( $enrolment_id ) ) {
			return self::fail_conversion( $lifecycle_key, $preview, $block_id, 0, $enrolment_id, $audit_context );
		}

		$audit_context['enrolment_id'] = absint( $enrolment_id );
		$target_bookings = TutorHelper_Group_Enrolment_Bookings::get_for_enrolment( $enrolment_id );
		$target_booking_ids = wp_list_pluck( $target_bookings, 'id' );
		$audit_context['target_booking_ids'] = array_map( 'absint', $target_booking_ids );

		$credit_result = self::transfer_paid_value( $preview, $enrolment_id, $lifecycle_key );
		if ( is_wp_error( $credit_result ) ) {
			return self::fail_conversion( $lifecycle_key, $preview, $block_id, $enrolment_id, $credit_result, $audit_context );
		}
		$audit_context['credit_transferred_minor_units'] = absint( $credit_result['applied_minor_units'] );

		foreach ( $preview['source_booking_ids'] as $booking_id ) {
			$cancelled = TutorHelper_Booking_Records::cancel(
				$booking_id,
				sprintf(
					/* translators: %d Group Block ID. */
					__( 'Converted to Group Lesson block #%d.', 'tutorhelper-group-bookings' ),
					$block_id
				),
				'tutor'
			);

			if ( is_wp_error( $cancelled ) || false === $cancelled ) {
				$error = is_wp_error( $cancelled )
					? $cancelled
					: new WP_Error(
						'tutorhelper_group_conversion_source_cancel_failed',
						__( 'The replacement Group Lesson was created, but an original booking could not be cancelled.', 'tutorhelper-group-bookings' )
					);
				return self::fail_conversion( $lifecycle_key, $preview, $block_id, $enrolment_id, $error, $audit_context );
			}
		}

		$audit_context['source_bookings_cancelled'] = true;
		$completed = TutorHelper_Group_Lifecycle_Audit::record(
			array(
				'lifecycle_key' => $lifecycle_key,
				'operation' => 'booking_to_group_conversion',
				'status' => 'completed',
				'block_id' => $block_id,
				'enrolment_id' => $enrolment_id,
				'source_booking_id' => $preview['source_booking_id'],
				'target_booking_id' => ! empty( $target_booking_ids ) ? absint( $target_booking_ids[0] ) : 0,
				'context' => $audit_context,
				'created_by_user_id' => $tutor_user_id,
			)
		);
		if ( is_wp_error( $completed ) ) {
			TutorHelper_Logger::error(
				'Group booking conversion completed but its audit record could not be finalised.',
				array(
					'block_id' => $block_id,
					'enrolment_id' => $enrolment_id,
					'error' => $completed->get_error_message(),
				)
			);
		}

		TutorHelper_Logger::success(
			'Individual booking converted to Group Lesson block.',
			array(
				'block_id' => $block_id,
				'enrolment_id' => $enrolment_id,
				'source_booking_ids' => $preview['source_booking_ids'],
				'target_booking_ids' => $audit_context['target_booking_ids'],
				'credit_transferred_minor_units' => $audit_context['credit_transferred_minor_units'],
			)
		);

		do_action( 'tutorhelper_group_booking_converted', $block_id, $enrolment_id, $preview );

		return array(
			'block_id' => $block_id,
			'enrolment_id' => $enrolment_id,
			'target_booking_ids' => $audit_context['target_booking_ids'],
			'already_completed' => false,
		);
	}

	/**
	 * Return eligible bookings for a selected scope.
	 *
	 * @param object $source Source booking.
	 * @param string $scope Scope.
	 * @param int    $tutor_user_id Tutor ID.
	 * @return array|WP_Error
	 */
	private static function get_source_bookings( $source, $scope, $tutor_user_id ) {
		if ( self::SCOPE_SINGLE === $scope ) {
			return array( $source );
		}

		if ( ! class_exists( 'TutorHelper_Pro_Booking_Series' ) ) {
			return new WP_Error(
				'tutorhelper_group_conversion_series_unavailable',
				__( 'Recurring series conversion requires TutorHelper Pro.', 'tutorhelper-group-bookings' )
			);
		}

		$series = TutorHelper_Pro_Booking_Series::get_series_for_booking( $source->id );
		if ( ! $series ) {
			return new WP_Error(
				'tutorhelper_group_conversion_series_missing',
				__( 'This booking is not part of a recurring series.', 'tutorhelper-group-bookings' )
			);
		}

		$frequency = isset( $series->frequency ) ? sanitize_key( $series->frequency ) : '';
		if ( ! in_array( $frequency, array( TutorHelper_Group_Block_Create::FREQUENCY_WEEKLY, TutorHelper_Group_Block_Create::FREQUENCY_FORTNIGHTLY ), true ) ) {
			return new WP_Error(
				'tutorhelper_group_conversion_series_frequency_unsupported',
				__( 'Only weekly or fortnightly recurring series can be converted into a Group Lesson block.', 'tutorhelper-group-bookings' )
			);
		}

		$selected_start = self::get_booking_timestamp( $source );
		$bookings = array();

		foreach ( TutorHelper_Pro_Booking_Series::get_items( $series->id ) as $item ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $item->booking_id );
			if ( ! $booking || self::get_booking_timestamp( $booking ) < $selected_start ) {
				continue;
			}

			if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
				continue;
			}

			$candidate = self::get_eligible_source_booking( $booking->id, $tutor_user_id );
			if ( is_wp_error( $candidate ) ) {
				continue;
			}

			$compatibility = self::validate_compatible_booking( $source, $candidate );
			if ( is_wp_error( $compatibility ) ) {
				// An edited exception retains its original booking, payment and attendance history.
				// The schedule builder marks that date excluded from the replacement Group Block.
				continue;
			}

			$bookings[] = $candidate;
		}

		if ( empty( $bookings ) ) {
			return new WP_Error(
				'tutorhelper_group_conversion_series_empty',
				__( 'This recurring series has no active future lessons to convert.', 'tutorhelper-group-bookings' )
			);
		}

		return $bookings;
	}

	/**
	 * Construct a Group Block schedule that preserves selected dates exactly.
	 *
	 * @param array  $bookings Compatible source bookings.
	 * @param string $scope Scope.
	 * @return array|WP_Error
	 */
	private static function build_schedule( $bookings, $scope ) {
		$first = reset( $bookings );
		$first_local = self::get_booking_local_times( $first );
		if ( is_wp_error( $first_local ) ) {
			return $first_local;
		}

		if ( self::SCOPE_SINGLE === $scope ) {
			return array(
				'start_date' => $first_local['start']->format( 'Y-m-d' ),
				'end_date' => $first_local['start']->format( 'Y-m-d' ),
				'excluded_session_dates' => array(),
				'frequency' => TutorHelper_Group_Block_Create::FREQUENCY_WEEKLY,
				'start_time' => $first_local['start']->format( 'H:i:s' ),
				'end_time' => $first_local['end']->format( 'H:i:s' ),
				'timezone' => $first_local['timezone']->getName(),
			);
		}

		$frequency = self::get_recurrence_frequency( $bookings );

		$dates = array();
		foreach ( $bookings as $booking ) {
			$local = self::get_booking_local_times( $booking );
			if ( is_wp_error( $local ) ) {
				return $local;
			}
			$dates[] = $local['start']->format( 'Y-m-d' );
		}
		$dates = array_values( array_unique( $dates ) );
		sort( $dates );

		$excluded = array();
		$current = new DateTimeImmutable( $dates[0], $first_local['timezone'] );
		$last = new DateTimeImmutable( end( $dates ), $first_local['timezone'] );
		$interval = TutorHelper_Group_Block_Create::FREQUENCY_FORTNIGHTLY === $frequency ? 14 : 7;

		while ( $current <= $last ) {
			$date = $current->format( 'Y-m-d' );
			if ( ! in_array( $date, $dates, true ) ) {
				$excluded[] = $date;
			}
			$current = $current->modify( '+' . $interval . ' days' );
		}

		return array(
			'start_date' => $dates[0],
			'end_date' => end( $dates ),
			'excluded_session_dates' => $excluded,
			'frequency' => $frequency,
			'start_time' => $first_local['start']->format( 'H:i:s' ),
			'end_time' => $first_local['end']->format( 'H:i:s' ),
			'timezone' => $first_local['timezone']->getName(),
		);
	}


	/**
	 * Keep only conversion controls that may override Group Block defaults.
	 *
	 * Schedule, tutor, booking type, source location and currency always come
	 * from the selected booking and cannot be changed by a conversion request.
	 *
	 * @param array $options Submitted Group Block options.
	 * @return array
	 */
	private static function get_conversion_block_options( $options ) {
		$options = is_array( $options ) ? $options : array();
		$allowed = array(
			'bookable_from',
			'bookable_until',
			'min_enrolments',
			'max_enrolments',
			'pricing_basis',
			'price_per_session_minor_units',
			'fixed_block_price_minor_units',
			'deposit_type',
			'deposit_value',
			'payment_mode',
			'student_cancellation_allowed',
			'cancellation_notice_hours',
			'deposit_refundable',
			'cancellation_terms',
		);

		return array_intersect_key( $options, array_flip( $allowed ) );
	}

	/**
	 * Transfer paid source value to the target enrolment through the immutable ledger.
	 *
	 * @param array  $preview Validated conversion preview.
	 * @param int    $enrolment_id Target Group enrolment.
	 * @param string $lifecycle_key Conversion audit key.
	 * @return array|WP_Error
	 */
	private static function transfer_paid_value( $preview, $enrolment_id, $lifecycle_key ) {
		$transfer = absint( $preview['credit_to_apply_minor_units'] );
		if ( 0 === $transfer ) {
			return array( 'applied_minor_units' => 0 );
		}

		$remaining = $transfer;
		foreach ( $preview['source_bookings'] as $source ) {
			if ( 0 === $remaining ) {
				break;
			}

			$amount = min( $remaining, absint( $source['net_paid_minor_units'] ) );
			if ( 0 === $amount ) {
				continue;
			}

			$credit = TutorHelper_Pro_Finance_Adjustments::record_adjustment(
				absint( $source['booking_id'] ),
				TutorHelper_Pro_Finance_Adjustments::ADJUSTMENT_CREDIT,
				$amount,
				sprintf(
					/* translators: %s Conversion lifecycle reference. */
					__( 'Account credit transferred to Group Lesson conversion %s.', 'tutorhelper-group-bookings' ),
					$lifecycle_key
				)
			);

			if ( is_wp_error( $credit ) ) {
				return $credit;
			}

			$remaining -= $amount;
		}

		if ( 0 !== $remaining ) {
			return new WP_Error(
				'tutorhelper_group_conversion_credit_source_changed',
				__( 'The source lesson payment changed while the conversion was being prepared. No replacement payment was applied.', 'tutorhelper-group-bookings' )
			);
		}

		$applied = TutorHelper_Group_Payments::record_manual_payment(
			$enrolment_id,
			$transfer,
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
			current_time( 'Y-m-d' ),
			$lifecycle_key,
			__( 'Credit transferred from the converted individual booking.', 'tutorhelper-group-bookings' )
		);

		if ( is_wp_error( $applied ) ) {
			return $applied;
		}

		return array( 'applied_minor_units' => $transfer );
	}

	/**
	 * Persist a failed conversion with enough information for Diagnostics.
	 *
	 * @param string   $lifecycle_key Audit key.
	 * @param array    $preview Conversion preview.
	 * @param int      $block_id Created block ID.
	 * @param int      $enrolment_id Created enrolment ID.
	 * @param WP_Error $error Failure.
	 * @param array    $context Audit context.
	 * @return WP_Error
	 */
	private static function fail_conversion( $lifecycle_key, $preview, $block_id, $enrolment_id, $error, $context = array() ) {
		$context['error_code'] = $error->get_error_code();
		$context['error_message'] = $error->get_error_message();

		TutorHelper_Group_Lifecycle_Audit::record(
			array(
				'lifecycle_key' => $lifecycle_key,
				'operation' => 'booking_to_group_conversion',
				'status' => 'failed',
				'block_id' => $block_id,
				'enrolment_id' => $enrolment_id,
				'source_booking_id' => $preview['source_booking_id'],
				'context' => $context,
				'created_by_user_id' => get_current_user_id(),
			)
		);

		TutorHelper_Logger::error(
			'Individual booking to Group Lesson conversion failed.',
			array(
				'source_booking_ids' => $preview['source_booking_ids'],
				'block_id' => $block_id,
				'enrolment_id' => $enrolment_id,
				'error_code' => $error->get_error_code(),
				'error_message' => $error->get_error_message(),
			)
		);

		return $error;
	}

	/**
	 * Return an eligible tutor-owned future non-Group Core booking.
	 *
	 * @param int $booking_id Booking ID.
	 * @param int $tutor_user_id Tutor user ID.
	 * @return object|WP_Error
	 */
	private static function get_eligible_source_booking( $booking_id, $tutor_user_id ) {
		global $wpdb;

		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		if ( ! $booking || absint( $booking->tutor_user_id ) !== absint( $tutor_user_id ) ) {
			return new WP_Error(
				'tutorhelper_group_conversion_booking_invalid',
				__( 'Choose one of your active future individual bookings.', 'tutorhelper-group-bookings' )
			);
		}

		if (
			TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status )
			|| self::get_booking_timestamp( $booking ) <= current_time( 'timestamp', true )
		) {
			return new WP_Error(
				'tutorhelper_group_conversion_booking_not_future',
				__( 'Only active future bookings can be converted into a Group Lesson.', 'tutorhelper-group-bookings' )
			);
		}

		$is_group_child = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT booking_id FROM %i WHERE booking_id = %d',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				absint( $booking->id )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- A conversion must not recursively replace a Group child booking.

		if ( $is_group_child ) {
			return new WP_Error(
				'tutorhelper_group_conversion_booking_is_group_child',
				__( 'A Group Lesson child booking cannot be converted into another Group Lesson.', 'tutorhelper-group-bookings' )
			);
		}

		return $booking;
	}

	/**
	 * Ensure another series occurrence has the same schedule and lesson data.
	 *
	 * @param object $source First source booking.
	 * @param object $candidate Candidate source booking.
	 * @return true|WP_Error
	 */
	private static function validate_compatible_booking( $source, $candidate ) {
		$source_local = self::get_booking_local_times( $source );
		$candidate_local = self::get_booking_local_times( $candidate );

		if ( is_wp_error( $source_local ) || is_wp_error( $candidate_local ) ) {
			return new WP_Error(
				'tutorhelper_group_conversion_timezone_invalid',
				__( 'The recurring lesson schedule could not be read safely.', 'tutorhelper-group-bookings' )
			);
		}

		if (
			absint( $source->booking_type_id ) !== absint( $candidate->booking_type_id )
			|| absint( $source->tutor_user_id ) !== absint( $candidate->tutor_user_id )
			|| sanitize_key( $source->location_type ) !== sanitize_key( $candidate->location_type )
			|| sanitize_textarea_field( $source->location_details ) !== sanitize_textarea_field( $candidate->location_details )
			|| $source_local['timezone']->getName() !== $candidate_local['timezone']->getName()
			|| $source_local['start']->format( 'H:i:s' ) !== $candidate_local['start']->format( 'H:i:s' )
			|| $source_local['end']->format( 'H:i:s' ) !== $candidate_local['end']->format( 'H:i:s' )
		) {
			return new WP_Error(
				'tutorhelper_group_conversion_booking_incompatible',
				__( 'The recurring series contains an occurrence with different lesson details.', 'tutorhelper-group-bookings' )
			);
		}

		return true;
	}

	/**
	 * Derive Group frequency from the retained source bookings.
	 *
	 * @param array $bookings Source bookings.
	 * @return string|WP_Error
	 */
	private static function get_recurrence_frequency( $bookings ) {
		$first_booking = reset( $bookings );
		$series = class_exists( 'TutorHelper_Pro_Booking_Series' )
			? TutorHelper_Pro_Booking_Series::get_series_for_booking( $first_booking->id )
			: null;
		$frequency = $series && isset( $series->frequency )
			? sanitize_key( $series->frequency )
			: '';

		if ( in_array( $frequency, array( TutorHelper_Group_Block_Create::FREQUENCY_WEEKLY, TutorHelper_Group_Block_Create::FREQUENCY_FORTNIGHTLY ), true ) ) {
			return $frequency;
		}

		return new WP_Error(
			'tutorhelper_group_conversion_series_frequency_unsupported',
			__( 'Only weekly or fortnightly recurring series can be converted into a Group Lesson block.', 'tutorhelper-group-bookings' )
		);
	}

	/**
	 * Return local start/end DateTime objects for a Core booking.
	 *
	 * @param object $booking Core booking.
	 * @return array|WP_Error
	 */
	private static function get_booking_local_times( $booking ) {
		try {
			$timezone = new DateTimeZone(
				! empty( $booking->timezone ) ? sanitize_text_field( $booking->timezone ) : wp_timezone_string()
			);
			$utc = new DateTimeZone( 'UTC' );

			return array(
				'timezone' => $timezone,
				'start' => ( new DateTimeImmutable( $booking->booking_start, $utc ) )->setTimezone( $timezone ),
				'end' => ( new DateTimeImmutable( $booking->booking_end, $utc ) )->setTimezone( $timezone ),
			);
		} catch ( Exception $exception ) {
			return new WP_Error(
				'tutorhelper_group_conversion_timezone_invalid',
				__( 'The booking timezone could not be applied.', 'tutorhelper-group-bookings' )
			);
		}
	}

	/**
	 * Return a UTC timestamp for a booking.
	 *
	 * @param object $booking Core booking.
	 * @return int
	 */
	private static function get_booking_timestamp( $booking ) {
		try {
			return ( new DateTimeImmutable( $booking->booking_start, new DateTimeZone( 'UTC' ) ) )->getTimestamp();
		} catch ( Exception $exception ) {
			return 0;
		}
	}

	/**
	 * Generate a human-readable title for a converted Group Block.
	 *
	 * @param object $booking Source booking.
	 * @return string
	 */
	private static function get_converted_title( $booking, $booking_type_id = 0 ) {
		$booking_type = TutorHelper_Booking_Types::get_by_id( $booking_type_id ? $booking_type_id : $booking->booking_type_id );
		$name = $booking_type && ! empty( $booking_type->name )
			? sanitize_text_field( $booking_type->name )
			: __( 'Converted lessons', 'tutorhelper-group-bookings' );

		return sprintf(
			/* translators: %s Booking Type name. */
			__( '%s Group Lesson', 'tutorhelper-group-bookings' ),
			$name
		);
	}

	/**
	 * Return a stable, source-specific idempotency key.
	 *
	 * @param array $preview Conversion preview.
	 * @return string
	 */
	private static function get_lifecycle_key( $preview ) {
		return 'convert_' . sha1(
			implode( ',', array_map( 'absint', $preview['source_booking_ids'] ) )
			. ':' . absint( $preview['group_id'] )
			. ':' . absint( $preview['target_booking_type_id'] )
			. ':' . wp_json_encode( isset( $preview['conversion_options'] ) ? $preview['conversion_options'] : array() )
		);
	}
}
