<?php
/**
 * TutorHelper Group Bookings database schema manager.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates and updates Group Bookings tables.
 */
final class TutorHelper_Group_Bookings_Database {

	const VERSION_OPTION = 'tutorhelper_group_bookings_db_version';

	/**
	 * Return a Group Bookings table name.
	 *
	 * @param string $suffix Table suffix.
	 * @return string
	 */
	public static function get_table_name( $suffix ) {
		global $wpdb;

		$suffix = sanitize_key( $suffix );

		return $wpdb->prefix . 'tutorhelper_group_' . $suffix;
	}

	/**
	 * Create or update Group Bookings tables.
	 *
	 * @return void
	 */
	public static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$blocks_table = self::get_table_name( 'blocks' );
		$sessions_table = self::get_table_name( 'sessions' );
		$enrolments_table = self::get_table_name( 'enrolments' );
		$session_bookings_table = self::get_table_name( 'session_bookings' );
		$session_responses_table = self::get_table_name( 'session_responses' );
		$session_exclusions_table = self::get_table_name( 'enrolment_session_exclusions' );
		$lifecycle_audit_table = self::get_table_name( 'lifecycle_audit' );

		$blocks_sql = "CREATE TABLE {$blocks_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			group_id bigint(20) unsigned NOT NULL,
			booking_type_id bigint(20) unsigned NOT NULL,
			tutor_user_id bigint(20) unsigned NOT NULL,
			title varchar(255) NOT NULL,
			start_date date NOT NULL,
			end_date date NOT NULL,
			bookable_from date DEFAULT NULL,
			bookable_until date DEFAULT NULL,
			open_for_public_booking tinyint(1) NOT NULL DEFAULT 0,
			excluded_session_dates longtext NULL,
			frequency varchar(30) NOT NULL DEFAULT 'weekly',
			start_time time NOT NULL,
			end_time time NOT NULL,
			timezone varchar(100) NOT NULL,
			location_type varchar(50) NOT NULL DEFAULT '',
			location_details text NULL,
			min_enrolments int(10) unsigned NOT NULL DEFAULT 1,
			max_enrolments int(10) unsigned DEFAULT NULL,
			pricing_basis varchar(30) NOT NULL DEFAULT 'booking_type',
			price_per_session_minor_units bigint(20) unsigned NOT NULL DEFAULT 0,
			fixed_block_price_minor_units bigint(20) unsigned DEFAULT NULL,
			deposit_type varchar(20) NOT NULL DEFAULT 'none',
			deposit_value bigint(20) unsigned NOT NULL DEFAULT 0,
			currency varchar(10) NOT NULL DEFAULT 'GBP',
			payment_mode varchar(30) NOT NULL DEFAULT 'manual',
			student_cancellation_allowed tinyint(1) NOT NULL DEFAULT 1,
			cancellation_notice_hours int(10) unsigned NOT NULL DEFAULT 24,
			deposit_refundable tinyint(1) NOT NULL DEFAULT 1,
			cancellation_terms text NULL,
			status varchar(30) NOT NULL DEFAULT 'draft',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY group_id (group_id),
			KEY booking_type_id (booking_type_id),
			KEY tutor_user_id (tutor_user_id),
			KEY status (status),
			KEY start_date (start_date),
			KEY end_date (end_date),
			KEY bookable_from (bookable_from),
			KEY bookable_until (bookable_until),
			KEY public_booking (open_for_public_booking, status, start_date)
		) {$charset_collate};";

		$sessions_sql = "CREATE TABLE {$sessions_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			block_id bigint(20) unsigned NOT NULL,
			session_number int(10) unsigned NOT NULL,
			session_date date NOT NULL,
			booking_start datetime NOT NULL,
			booking_end datetime NOT NULL,
			status varchar(30) NOT NULL DEFAULT 'scheduled',
			location_details text NULL,
			calendar_event_id varchar(255) NOT NULL DEFAULT '',
			meeting_url text NULL,
			original_booking_start datetime DEFAULT NULL,
			original_booking_end datetime DEFAULT NULL,
			change_reason text NULL,
			rescheduled_at datetime DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY block_session_number (block_id, session_number),
			UNIQUE KEY block_session_date (block_id, session_date),
			KEY block_id (block_id),
			KEY session_date (session_date),
			KEY status (status)
		) {$charset_collate};";

		$enrolments_sql = "CREATE TABLE {$enrolments_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			block_id bigint(20) unsigned NOT NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			agreed_price_minor_units bigint(20) unsigned NOT NULL DEFAULT 0,
			payment_mode varchar(30) NOT NULL DEFAULT 'manual',
			deposit_type varchar(20) NOT NULL DEFAULT 'none',
			deposit_value bigint(20) unsigned NOT NULL DEFAULT 0,
			currency varchar(10) NOT NULL DEFAULT 'GBP',
			payment_status varchar(30) NOT NULL DEFAULT 'unpaid',
			amount_paid_minor_units bigint(20) unsigned NOT NULL DEFAULT 0,
			amount_refunded_minor_units bigint(20) unsigned NOT NULL DEFAULT 0,
			amount_credited_minor_units bigint(20) unsigned NOT NULL DEFAULT 0,
			checkout_session_id varchar(255) DEFAULT NULL,
			checkout_amount_minor_units bigint(20) unsigned NOT NULL DEFAULT 0,
			checkout_type varchar(30) NOT NULL DEFAULT '',
			checkout_created_at datetime DEFAULT NULL,
			last_provider_event_id varchar(255) DEFAULT NULL,
			status varchar(30) NOT NULL DEFAULT 'pending',
			cancelled_at datetime DEFAULT NULL,
			cancelled_by varchar(20) NOT NULL DEFAULT '',
			cancellation_reason text NULL,
			remainder_removed_at datetime DEFAULT NULL,
			remainder_removal_reason text NULL,
			joined_at datetime NOT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY block_student (block_id, student_user_id),
			KEY student_user_id (student_user_id),
			KEY status (status),
			UNIQUE KEY checkout_session_id (checkout_session_id)
		) {$charset_collate};";

		$session_responses_sql = "CREATE TABLE {$session_responses_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			session_id bigint(20) unsigned NOT NULL,
			enrolment_id bigint(20) unsigned NOT NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			response_status varchar(30) NOT NULL DEFAULT 'pending',
			responded_at datetime DEFAULT NULL,
			credit_ledger_id bigint(20) unsigned DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY session_enrolment (session_id, enrolment_id),
			KEY student_status (student_user_id, response_status),
			KEY enrolment_id (enrolment_id)
		) {$charset_collate};";

		$session_bookings_sql = "CREATE TABLE {$session_bookings_table} (
			session_id bigint(20) unsigned NOT NULL,
			enrolment_id bigint(20) unsigned NOT NULL,
			booking_id bigint(20) unsigned NOT NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (session_id, booking_id),
			UNIQUE KEY booking_id (booking_id),
			UNIQUE KEY session_enrolment (session_id, enrolment_id),
			KEY enrolment_id (enrolment_id),
			KEY student_user_id (student_user_id)
		) {$charset_collate};";

		$session_exclusions_sql = "CREATE TABLE {$session_exclusions_table} (
			session_id bigint(20) unsigned NOT NULL,
			enrolment_id bigint(20) unsigned NOT NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			reason text NULL,
			removed_by_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			removed_at datetime NOT NULL,
			PRIMARY KEY  (session_id, enrolment_id),
			KEY enrolment_id (enrolment_id),
			KEY student_user_id (student_user_id)
		) {$charset_collate};";

		$lifecycle_audit_sql = "CREATE TABLE {$lifecycle_audit_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			lifecycle_key varchar(190) NOT NULL,
			operation varchar(50) NOT NULL,
			status varchar(30) NOT NULL,
			block_id bigint(20) unsigned NOT NULL DEFAULT 0,
			enrolment_id bigint(20) unsigned NOT NULL DEFAULT 0,
			source_booking_id bigint(20) unsigned NOT NULL DEFAULT 0,
			target_booking_id bigint(20) unsigned NOT NULL DEFAULT 0,
			context longtext NULL,
			created_by_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY lifecycle_key (lifecycle_key),
			KEY operation_status (operation, status),
			KEY block_id (block_id),
			KEY enrolment_id (enrolment_id),
			KEY source_booking_id (source_booking_id)
		) {$charset_collate};";

		dbDelta( $blocks_sql );
		dbDelta( $sessions_sql );
		dbDelta( $enrolments_sql );
		dbDelta( $session_bookings_sql );
		dbDelta( $session_responses_sql );
		dbDelta( $session_exclusions_sql );
		dbDelta( $lifecycle_audit_sql );

		self::repair_child_booking_timezones();

		update_option(
			self::VERSION_OPTION,
			TUTORHELPER_GROUP_BOOKINGS_DB_VERSION,
			false
		);
	}

	/**
	 * Restore each existing child booking's display timezone.
	 *
	 * Group Sessions store UTC timestamps, but Core also needs the originating
	 * IANA timezone to render those timestamps with the correct DST offset.
	 *
	 * @return void
	 */
	private static function repair_child_booking_timezones() {
		global $wpdb;

		if ( ! class_exists( 'TutorHelper_Booking_Records' ) ) {
			return;
		}

		$blocks_table = self::get_table_name( 'blocks' );
		$enrolments_table = self::get_table_name( 'enrolments' );
		$session_bookings_table = self::get_table_name( 'session_bookings' );
		$bookings_table = TutorHelper_Booking_Records::get_table_name();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time repair of linked Core booking timezone metadata.
			$wpdb->prepare(
				"UPDATE %i AS booking
				INNER JOIN %i AS link ON link.booking_id = booking.id
				INNER JOIN %i AS enrolment ON enrolment.id = link.enrolment_id
				INNER JOIN %i AS block ON block.id = enrolment.block_id
				SET booking.timezone = block.timezone
				WHERE booking.timezone = 'UTC'
				AND block.timezone != ''",
				$bookings_table,
				$session_bookings_table,
				$enrolments_table,
				$blocks_table
			)
		);
	}

	/**
	 * Run schema updates when required.
	 *
	 * @return void
	 */
	public static function update_check() {
		$installed = (string) get_option( self::VERSION_OPTION, '' );

		if (
			'' === $installed
			|| version_compare(
				$installed,
				TUTORHELPER_GROUP_BOOKINGS_DB_VERSION,
				'<'
			)
		) {
			self::create_tables();
		}
	}
}
