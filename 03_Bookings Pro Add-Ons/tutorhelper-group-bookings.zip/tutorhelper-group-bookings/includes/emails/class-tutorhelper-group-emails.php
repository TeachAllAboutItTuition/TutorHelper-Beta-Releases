<?php
/**
 * Editable Group Lesson email templates and event delivery.
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Sends one Group-level message instead of one message per child booking. */
final class TutorHelper_Group_Emails {

	/** @var int Enrolment currently completing its initial lifecycle. */
	private static $creating_enrolment_id = 0;

	const ENROLLED = 'group_lesson_enrolled';
	const RESCHEDULED = 'group_session_rescheduled';
	const SESSION_CANCELLED = 'group_session_cancelled';
	const ENROLMENT_CANCELLED = 'group_enrolment_cancelled';
	const BLOCK_CANCELLED = 'group_block_cancelled';
	const BLOCK_CONFIRMED = 'group_block_confirmed';
	const EXTERNAL_ACCOUNT_READY = 'group_external_account_ready';

	/** Register templates and Group lifecycle listeners. */
	public static function init() {
		self::register_templates();
		add_filter( 'tutorhelper_pro_email_template_modules', array( __CLASS__, 'register_email_manager_module' ) );
		add_filter( 'tutorhelper_booking_send_student_confirmation', array( __CLASS__, 'suppress_child_confirmation' ), 10, 3 );
		add_filter( 'tutorhelper_booking_send_request_emails', array( __CLASS__, 'suppress_child_confirmation' ), 10, 3 );
		add_filter( 'tutorhelper_booking_send_cancellation_emails', array( __CLASS__, 'suppress_child_cancellation' ), 10, 5 );
		add_action( 'tutorhelper_group_student_enrolled', array( __CLASS__, 'send_enrolment_confirmation' ), 20, 4 );
		add_action( 'tutorhelper_group_session_rescheduled', array( __CLASS__, 'send_reschedule_notice' ), 20, 4 );
		add_action( 'tutorhelper_group_session_cancelled', array( __CLASS__, 'send_session_cancellation' ), 20, 2 );
		add_action( 'tutorhelper_group_enrolment_cancelled', array( __CLASS__, 'send_enrolment_cancellation' ), 20, 4 );
		add_action( 'tutorhelper_group_block_cancelled', array( __CLASS__, 'send_block_cancellation' ), 20, 2 );
		add_action( 'tutorhelper_group_block_status_changed', array( __CLASS__, 'send_block_confirmed' ), 30, 5 );
		add_action( 'tutorhelper_group_external_student_registered', array( __CLASS__, 'send_external_account_ready' ), 20, 2 );
	}

	/**
	 * Expose Group Lesson templates in the shared Pro Email Manager.
	 *
	 * @param array $modules Registered Email Manager module keys.
	 * @return array
	 */
	public static function register_email_manager_module( $modules ) {
		$modules = is_array( $modules ) ? $modules : array();
		$modules[] = 'group_lessons';

		return $modules;
	}

	/** Mark the enrolment that should receive the single booking email. */
	public static function begin_enrolment_notification( $enrolment_id ) {
		self::$creating_enrolment_id = absint( $enrolment_id );
	}

	/** Clear the initial-enrolment marker. */
	public static function end_enrolment_notification() {
		self::$creating_enrolment_id = 0;
	}

	/** Suppress Core's per-session cancellation messages for Group children. */
	public static function suppress_child_cancellation( $send, $booking_id, $updated, $existing, $cancelled_by ) {
		unset( $updated, $existing, $cancelled_by );
		return self::suppress_child_confirmation( $send, $booking_id, array() );
	}

	/** Suppress per-session Core email while Group child records are generated. */
	public static function suppress_child_confirmation( $send, $booking_id, $data ) {
		unset( $data );
		if ( TutorHelper_Group_Booking_Context::is_active() ) {
			return false;
		}
		global $wpdb;
		$is_group_child = (bool) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$wpdb->prepare(
				'SELECT booking_id FROM %i WHERE booking_id=%d',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				absint( $booking_id )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Email suppression must use current bridge state.
		return $is_group_child ? false : $send;
	}

	/** Register all templates in TutorHelper's normal editable email module. */
	private static function register_templates() {
		self::register( self::ENROLLED, __( 'Group Lesson booked — Student', 'tutorhelper-group-bookings' ), __( 'Sent once when a student books a complete Group Lesson block.', 'tutorhelper-group-bookings' ), __( 'Your Group Lesson booking: {block_title}', 'tutorhelper-group-bookings' ), __( "Hello {student_name},\n\nYour place on {block_title} has been recorded.\n\nSessions:\n{session_list}\n\nPayment status: {payment_status}\nAmount paid: {amount_paid}\nAmount remaining: {amount_remaining}\n\n{minimum_notice}\n\nView your Group Lessons: {dashboard_url}\n\nBest wishes,\n{tutor_name}", 'tutorhelper-group-bookings' ) );
		self::register( self::RESCHEDULED, __( 'Group Session rescheduled — Student', 'tutorhelper-group-bookings' ), __( 'Sent once per student when a tutor moves one Group Session.', 'tutorhelper-group-bookings' ), __( 'Important: {block_title} session rescheduled', 'tutorhelper-group-bookings' ), __( "Hello {student_name},\n\nA session in {block_title} has moved.\n\nNew date and time: {session_date_time}\nReason/message: {reason}\n\nPlease open your lesson card to confirm that you can attend, or request account credit for this session:\n{dashboard_url}\n\nBest wishes,\n{tutor_name}", 'tutorhelper-group-bookings' ) );
		self::register( self::SESSION_CANCELLED, __( 'Group Session cancelled — Student', 'tutorhelper-group-bookings' ), __( 'Sent when the tutor cancels one session; any eligible credit is recorded separately in Finance.', 'tutorhelper-group-bookings' ), __( '{block_title} session cancelled', 'tutorhelper-group-bookings' ), __( "Hello {student_name},\n\nThe {block_title} session on {session_date_time} has been cancelled.\n\nReason: {reason}\n\nAny eligible lesson credit has been applied to your account and will be used against future bookings.\n\nView your account: {dashboard_url}\n\nBest wishes,\n{tutor_name}", 'tutorhelper-group-bookings' ) );
		self::register( self::ENROLMENT_CANCELLED, __( 'Group booking cancelled — Student', 'tutorhelper-group-bookings' ), __( 'Sent when one student or the tutor cancels that student’s place on a block.', 'tutorhelper-group-bookings' ), __( 'Your {block_title} booking was cancelled', 'tutorhelper-group-bookings' ), __( "Hello {student_name},\n\nYour place on {block_title} has been cancelled.\n\nReason: {reason}\nAccount credit applied: {credit_amount}\nNon-refundable amount: {protected_amount}\n\nYou can review available credit in your dashboard. It will be used against eligible future bookings, or you may request a refund.\n\n{dashboard_url}\n\nBest wishes,\n{tutor_name}", 'tutorhelper-group-bookings' ) );
		self::register( self::BLOCK_CANCELLED, __( 'Group Lesson block cancelled — Student', 'tutorhelper-group-bookings' ), __( 'Sent once to each enrolled student when the tutor cancels the whole block.', 'tutorhelper-group-bookings' ), __( '{block_title} has been cancelled', 'tutorhelper-group-bookings' ), __( "Hello {student_name},\n\nThe complete {block_title} block has been cancelled.\n\nReason: {reason}\n\nAny eligible account credit has been recorded in Finance and is visible in your dashboard.\n\n{dashboard_url}\n\nBest wishes,\n{tutor_name}", 'tutorhelper-group-bookings' ) );
		self::register( self::BLOCK_CONFIRMED, __( 'Group Lesson minimum reached — Student', 'tutorhelper-group-bookings' ), __( 'Sent to secured students when an awaiting-minimum block becomes confirmed.', 'tutorhelper-group-bookings' ), __( '{block_title} is confirmed', 'tutorhelper-group-bookings' ), __( "Hello {student_name},\n\nGood news — {block_title} has reached its minimum enrolment and is now confirmed.\n\nSessions:\n{session_list}\n\nJoining links and lesson details are available on the matching lesson cards in your dashboard:\n{dashboard_url}\n\nBest wishes,\n{tutor_name}", 'tutorhelper-group-bookings' ) );
		self::register( self::EXTERNAL_ACCOUNT_READY, __( 'External student account created', 'tutorhelper-group-bookings' ), __( 'Sent after a visitor creates a restricted account for open Group Lessons.', 'tutorhelper-group-bookings' ), __( 'Your TutorHelper student account is ready', 'tutorhelper-group-bookings' ), __( "Hello {first_name},\n\nYour student account has been created. It is currently set up for open Group Lessons only.\n\nYou can sign in here to complete your booking and view your Group Lessons:\n{login_url}\n\nBest wishes,\n{tutor_name}", 'tutorhelper-group-bookings' ) );
	}

	/** Register one standard editable template. */
	private static function register( $key, $label, $description, $subject, $body ) {
		TutorHelper_Email_Templates::register(
			$key,
			array(
				'module' => 'group_lessons',
				'label' => $label,
				'description' => $description,
				'heading' => $label,
				'recipient' => 'student',
				'enabled' => true,
				'subject' => $subject,
				'body' => $body,
				'placeholders' => array( '{student_name}', '{first_name}', '{block_title}', '{session_list}', '{session_date_time}', '{reason}', '{payment_status}', '{amount_paid}', '{amount_remaining}', '{credit_amount}', '{protected_amount}', '{minimum_notice}', '{dashboard_url}', '{login_url}', '{tutor_name}', '{site_name}' ),
			)
		);
	}

	/** Send the one block-level booking message. */
	public static function send_enrolment_confirmation( $enrolment_id, $block_id, $student_id, $booking_ids ) {
		unset( $booking_ids );
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $enrolment || ! $block ) {
			return;
		}
		$summary = TutorHelper_Group_Payments::get_summary( $enrolment );
		$placeholders = self::base_placeholders( $student_id, $block );
		$placeholders['{session_list}'] = self::session_list( $block );
		$placeholders['{payment_status}'] = ucwords( str_replace( '_', ' ', sanitize_key( $enrolment->payment_status ) ) );
		$placeholders['{amount_paid}'] = self::money( $summary['net_paid_minor_units'], $enrolment->currency );
		$placeholders['{amount_remaining}'] = self::money( $summary['balance_minor_units'], $enrolment->currency );
		$placeholders['{minimum_notice}'] = TutorHelper_Group_Blocks::STATUS_AWAITING_MINIMUM === sanitize_key( $block->status )
			? __( 'This block is awaiting minimum enrolment. We will confirm it when enough students have secured places.', 'tutorhelper-group-bookings' )
			: __( 'This block has reached minimum enrolment and its sessions are confirmed.', 'tutorhelper-group-bookings' );
		self::send_to_student_and_parent( self::ENROLLED, $student_id, $placeholders, 'enrolment', $enrolment_id );
	}

	/**
	 * Send an editable confirmation after an External account is created.
	 *
	 * No place, lesson booking or payment is implied by this email.
	 *
	 * @param int $student_id Student user ID.
	 * @param int $block_id   Selected public Group Block ID.
	 * @return void
	 */
	public static function send_external_account_ready( $student_id, $block_id ) {
		$student = get_user_by( 'id', absint( $student_id ) );
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );

		if ( ! $student || ! $block || ! is_email( $student->user_email ) ) {
			return;
		}

		if ( ! TutorHelper_Email_Templates::is_enabled( self::EXTERNAL_ACCOUNT_READY ) ) {
			return;
		}

		$placeholders = self::base_placeholders( $student_id, $block );

		TutorHelper_Email_Sender::send(
			self::EXTERNAL_ACCOUNT_READY,
			sanitize_email( $student->user_email ),
			$placeholders,
			array(
				'context' => array(
					'email_type'          => 'external_group_registration',
					'recipient_type'      => 'student',
					'student_user_id'     => absint( $student_id ),
					'related_object_type' => 'group_block',
					'related_object_id'   => absint( $block_id ),
				),
			)
		);
	}

	/** Send one reschedule message per enrolment after all child records move. */
	public static function send_reschedule_notice( $session_id, $session, $previous, $reason ) {
		unset( $previous );
		self::send_session_event( self::RESCHEDULED, $session_id, $session, $reason );
	}

	/** Send one cancellation message per affected enrolment. */
	public static function send_session_cancellation( $session_id, $reason ) {
		$session = TutorHelper_Group_Sessions::get_by_id( $session_id );
		self::send_session_event( self::SESSION_CANCELLED, $session_id, $session, $reason );
	}

	/** Send the individual enrolment cancellation summary. */
	public static function send_enrolment_cancellation( $enrolment_id, $credit, $protected, $cancelled_by ) {
		$enrolment = TutorHelper_Group_Enrolments::get_by_id( $enrolment_id );
		$block = $enrolment ? TutorHelper_Group_Blocks::get_by_id( $enrolment->block_id ) : null;
		if ( ! $enrolment || ! $block || 'tutor' === sanitize_key( $cancelled_by ) ) {
			return;
		}
		$placeholders = self::base_placeholders( $enrolment->student_user_id, $block );
		$placeholders['{reason}'] = sanitize_textarea_field( $enrolment->cancellation_reason );
		$placeholders['{credit_amount}'] = self::money( $credit, $enrolment->currency );
		$placeholders['{protected_amount}'] = self::money( $protected, $enrolment->currency );
		self::send_to_student_and_parent( self::ENROLMENT_CANCELLED, $enrolment->student_user_id, $placeholders, 'enrolment', $enrolment_id );
	}

	/** The block event is sent after tutor-cancelled enrolment credit allocation completes. */
	public static function send_block_cancellation( $block_id, $reason ) {
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			return;
		}
		foreach ( TutorHelper_Group_Enrolments::get_for_block( $block_id ) as $enrolment ) {
			if ( 'tutor' !== sanitize_key( $enrolment->cancelled_by ) || sanitize_textarea_field( $reason ) !== sanitize_textarea_field( $enrolment->cancellation_reason ) ) {
				continue;
			}
			$placeholders = self::base_placeholders( $enrolment->student_user_id, $block );
			$placeholders['{reason}'] = sanitize_textarea_field( $reason );
			self::send_to_student_and_parent( self::BLOCK_CANCELLED, $enrolment->student_user_id, $placeholders, 'block', $block_id );
		}
	}

	/** Notify already-secured students when the minimum is first reached. */
	public static function send_block_confirmed( $block_id, $new_status, $old_status, $secured_count, $reserved_count ) {
		unset( $secured_count, $reserved_count );
		if (
			TutorHelper_Group_Blocks::STATUS_AWAITING_MINIMUM !== sanitize_key( $old_status )
			|| ! in_array( sanitize_key( $new_status ), array( TutorHelper_Group_Blocks::STATUS_CONFIRMED, TutorHelper_Group_Blocks::STATUS_FULL ), true )
		) {
			return;
		}
		$block = TutorHelper_Group_Blocks::get_by_id( $block_id );
		if ( ! $block ) {
			return;
		}
		foreach ( TutorHelper_Group_Enrolments::get_for_block( $block_id ) as $enrolment ) {
			if ( TutorHelper_Group_Enrolments::STATUS_SECURED !== sanitize_key( $enrolment->status ) ) {
				continue;
			}
			if ( self::$creating_enrolment_id === absint( $enrolment->id ) ) {
				continue;
			}
			$placeholders = self::base_placeholders( $enrolment->student_user_id, $block );
			$placeholders['{session_list}'] = self::session_list( $block );
			self::send_to_student_and_parent( self::BLOCK_CONFIRMED, $enrolment->student_user_id, $placeholders, 'block', $block_id );
		}
	}

	/** Deliver a session message to each active/student-linked enrolment. */
	private static function send_session_event( $template, $session_id, $session, $reason ) {
		if ( ! $session ) {
			return;
		}
		$block = TutorHelper_Group_Blocks::get_by_id( $session->block_id );
		if ( ! $block ) {
			return;
		}
		global $wpdb;
		$students = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group booking state must reflect current enrolment, session or finance records.
			$wpdb->prepare(
				'SELECT DISTINCT e.id, e.student_user_id FROM %i l INNER JOIN %i e ON e.id=l.enrolment_id WHERE l.session_id=%d',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				TutorHelper_Group_Enrolments::get_table_name(),
				absint( $session_id )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Notification recipients must match current enrolments.
		foreach ( $students as $row ) {
			$placeholders = self::base_placeholders( $row->student_user_id, $block );
			$placeholders['{session_date_time}'] = self::format_session( $session, $block );
			$placeholders['{reason}'] = sanitize_textarea_field( $reason );
			self::send_to_student_and_parent( $template, $row->student_user_id, $placeholders, 'group_session', $session_id );
		}
	}

	/** Send separate auditable deliveries to the student and linked parent. */
	private static function send_to_student_and_parent( $template, $student_id, $placeholders, $object_type, $object_id ) {
		$student = get_user_by( 'id', absint( $student_id ) );
		if ( ! $student ) {
			return;
		}
		$recipients = array( 'student' => sanitize_email( $student->user_email ) );
		if ( method_exists( 'TutorHelper_Students', 'get_parent_details' ) ) {
			$parent = TutorHelper_Students::get_parent_details( $student_id );
			$email = is_array( $parent ) ? ( $parent['parent_email'] ?? ( $parent['email'] ?? '' ) ) : ( is_object( $parent ) ? ( $parent->parent_email ?? ( $parent->email ?? '' ) ) : '' );
			if ( is_email( $email ) ) {
				$recipients['parent'] = sanitize_email( $email );
			}
		}
		foreach ( $recipients as $recipient_type => $email ) {
			if ( ! is_email( $email ) ) {
				continue;
			}
			TutorHelper_Email_Sender::send(
				$template,
				$email,
				$placeholders,
				array( 'context' => array( 'email_type' => 'group_lesson', 'recipient_type' => $recipient_type, 'student_user_id' => absint( $student_id ), 'related_object_type' => $object_type, 'related_object_id' => absint( $object_id ) ) )
			);
		}
	}

	/** Common placeholders. */
	private static function base_placeholders( $student_id, $block ) {
		$student = get_user_by( 'id', absint( $student_id ) );
		$tutor = get_user_by( 'id', absint( $block->tutor_user_id ) );
		return array(
			'{student_name}' => $student ? $student->display_name : '',
			'{first_name}'   => $student ? ( $student->first_name ? $student->first_name : $student->display_name ) : '',
			'{block_title}' => sanitize_text_field( $block->title ),
			'{dashboard_url}' => home_url( '/' ),
			'{login_url}' => TutorHelper_Settings::get_login_url(),
			'{tutor_name}' => $tutor ? $tutor->display_name : get_bloginfo( 'name' ),
			'{site_name}' => get_bloginfo( 'name' ),
			'{session_list}' => '',
			'{session_date_time}' => '',
			'{reason}' => '',
			'{payment_status}' => '',
			'{amount_paid}' => '',
			'{amount_remaining}' => '',
			'{credit_amount}' => '',
			'{protected_amount}' => '',
			'{minimum_notice}' => '',
		);
	}

	/** Newline-separated session statement. */
	private static function session_list( $block ) {
		$lines = array();
		foreach ( TutorHelper_Group_Sessions::get_for_block( $block->id ) as $session ) {
			$lines[] = self::format_session( $session, $block );
		}
		return implode( "\n", $lines );
	}

	/** Format one stored UTC session in the block timezone. */
	private static function format_session( $session, $block ) {
		try {
			$timezone = new DateTimeZone( sanitize_text_field( $block->timezone ) );
			$date = ( new DateTimeImmutable( $session->booking_start, new DateTimeZone( 'UTC' ) ) )->setTimezone( $timezone );
			return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $date->getTimestamp(), $timezone );
		} catch ( Exception $exception ) {
			return sanitize_text_field( $session->booking_start );
		}
	}

	/** Format minor units using Core currency support. */
	private static function money( $amount, $currency ) {
		return TutorHelper_Currency::format_minor_units( absint( $amount ), strtoupper( sanitize_text_field( $currency ) ) );
	}
}
