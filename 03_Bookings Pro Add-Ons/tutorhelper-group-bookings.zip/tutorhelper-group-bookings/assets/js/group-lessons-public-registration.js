( function () {
	'use strict';

	function setPanelMessage( panel, message, isError ) {
		panel.hidden = false;
		panel.innerHTML = '<div class="tutorhelper-public-groups__notice tutorhelper-public-groups__notice--'
			+ ( isError ? 'error' : 'loading' )
			+ '" role="status">' + message + '</div>';
	}

	document.addEventListener(
		'change',
		function ( event ) {
			var toggle = event.target;

			if ( ! toggle.matches( '[data-tutorhelper-password-toggle]' ) ) {
				return;
			}

			var form = toggle.closest( 'form' );

			if ( ! form ) {
				return;
			}

			form.querySelectorAll( '[data-tutorhelper-public-password]' ).forEach(
				function ( field ) {
					field.type = toggle.checked ? 'text' : 'password';
				}
			);
		}
	);

	document.addEventListener(
		'click',
		function ( event ) {
			var trigger = event.target.closest( '[data-tutorhelper-public-registration]' );

			if ( ! trigger || ! window.tutorhelperGroupPublicRegistration || ! window.fetch ) {
				return;
			}

			event.preventDefault();

			var panel = document.getElementById( 'tutorhelper-group-registration-panel' );

			if ( ! panel ) {
				window.location.href = trigger.href;
				return;
			}

			setPanelMessage(
				panel,
				window.tutorhelperGroupPublicRegistration.loadingLabel,
				false
			);

			panel.scrollIntoView( { behavior: 'smooth', block: 'start' } );

			var data = new window.URLSearchParams();
			data.append( 'action', 'tutorhelper_group_public_registration_form' );
			data.append( 'block_id', trigger.getAttribute( 'data-block-id' ) || '' );
			data.append( 'return_url', trigger.getAttribute( 'data-return-url' ) || '' );

			window.fetch(
				window.tutorhelperGroupPublicRegistration.ajaxUrl,
				{
					method: 'POST',
					credentials: 'same-origin',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
					},
					body: data.toString()
				}
			).then(
				function ( response ) {
					return response.json();
				}
			).then(
				function ( response ) {
					if ( ! response.success || ! response.data || ! response.data.html ) {
						throw new Error( 'Unable to load public Group registration form.' );
					}

					panel.innerHTML = response.data.html;
					panel.hidden = false;
					panel.querySelector( 'input, button, a' ).focus();
				}
			).catch(
				function () {
					setPanelMessage(
						panel,
						window.tutorhelperGroupPublicRegistration.errorMessage,
						true
					);
				}
			);
		}
	);
}() );
