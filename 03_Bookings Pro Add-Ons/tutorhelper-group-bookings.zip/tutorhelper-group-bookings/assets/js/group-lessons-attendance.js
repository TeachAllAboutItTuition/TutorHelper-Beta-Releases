(function () {
	'use strict';

	var config = window.tutorhelperGroupAttendance || {};

	function getMessage(payload, fallback) {
		if (payload && payload.data && payload.data.message) {
			return payload.data.message;
		}

		return fallback;
	}

	function saveAttendance(select) {
		var workspace = select.closest('[data-group-attendance-session]');
		var row = select.closest('[data-attendance-row]');
		var status = row ? row.querySelector('[data-attendance-save-status]') : null;
		var previous = select.dataset.previousStatus || 'not_recorded';
		var body = new URLSearchParams();

		body.append('action', config.action || '');
		body.append('nonce', config.nonce || '');
		body.append('session_id', workspace ? workspace.dataset.groupAttendanceSession : '');
		body.append('booking_id', select.dataset.bookingId || '');
		body.append('attendance_status', select.value);

		select.disabled = true;
		if (status) {
			status.textContent = config.savingLabel || 'Saving…';
			status.classList.remove('is-error', 'is-success');
		}

		window.fetch(config.ajaxUrl || '', {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			body: body.toString()
		})
			.then(function (response) {
				return response.json().then(function (payload) {
					if (!response.ok || !payload.success) {
						throw new Error(getMessage(payload, config.failedLabel || 'Attendance could not be saved.'));
					}

					return payload.data;
				});
			})
			.then(function (data) {
				select.dataset.previousStatus = data.status;
				if (row) {
					row.dataset.attendanceStatus = data.status;
				}
				if (status) {
					status.textContent = config.savedLabel || 'Saved';
					status.classList.add('is-success');
				}

				var progress = workspace ? workspace.querySelector('[data-attendance-progress]') : null;
				if (progress && data.progress) {
					progress.textContent = data.progress;
				}
			})
			.catch(function (error) {
				select.value = previous;
				if (status) {
					status.textContent = error.message || config.failedLabel || 'Attendance could not be saved.';
					status.classList.add('is-error');
				}
			})
			.finally(function () {
				select.disabled = false;
			});
	}

	document.addEventListener('change', function (event) {
		if (event.target.matches('[data-group-attendance]')) {
			saveAttendance(event.target);
		}
	});
})();
