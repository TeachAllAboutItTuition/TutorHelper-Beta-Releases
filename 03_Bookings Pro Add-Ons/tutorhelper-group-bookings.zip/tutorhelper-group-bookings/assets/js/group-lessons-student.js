(function () {
	'use strict';

	var config = window.TutorHelperGroupStudent || {};
	var typeIds = (config.groupBookingTypeIds || []).map(String);

	if (!typeIds.length) {
		return;
	}

	function element(tag, className, text) {
		var node = document.createElement(tag);
		if (className) {
			node.className = className;
		}
		if (typeof text === 'string') {
			node.textContent = text;
		}
		return node;
	}

	function resetServiceSelection(root, selected) {
		root.querySelectorAll('[data-booking-service]').forEach(function (service) {
			var active = service === selected;
			service.classList.toggle('is-selected', active);
			service.setAttribute('aria-pressed', active ? 'true' : 'false');
		});
	}

	function sessionLabel(block) {
		return block.sessionCount + (block.sessionCount === 1 ? ' session' : ' sessions');
	}

	function recurrenceLabel(block) {
		if (block.sessionCount === 1) {
			return '';
		}

		return block.frequency === 'fortnightly' ? 'Fortnightly' : (block.frequency === 'weekly' ? 'Weekly' : '');
	}

	function renderDetails(container, block) {
		container.innerHTML = '';
		var card = element('div', 'tutorhelper-group-student__details');
		card.appendChild(element('h4', '', block.title));
		card.appendChild(element('p', '', block.dayOfWeek + ' · ' + block.startDate + ' – ' + block.endDate));
		var recurrence = recurrenceLabel(block);
		card.appendChild(element('p', '', block.time + ' · ' + block.duration + (recurrence ? ' · ' + recurrence : '') + ' · ' + sessionLabel(block) + ' · ' + block.total));

		if (block.deposit) {
			card.appendChild(element('p', 'tutorhelper-group-student__deposit', block.deposit));
		}

		if (block.awaitingMinimum) {
			card.appendChild(element(
				'p',
				'tutorhelper-group-student__minimum',
				'Awaiting minimum enrolment. Your sessions will be confirmed when enough students have joined.'
			));
		} else {
			card.appendChild(element('p', 'tutorhelper-group-student__confirmed', 'This block has reached its minimum enrolment.'));
		}

		if (!block.isBookable) {
			card.appendChild(element('p', 'tutorhelper-group-student__minimum', block.bookingWindowMessage));
		}

		var join = element('button', 'tutorhelper-student-booking__submit', block.isEnrolled ? 'Already joined' : 'Join this Group Lesson');
		join.type = 'button';
		join.disabled = !block.isBookable || block.isFull || block.isEnrolled || !!config.isPreview;
		join.addEventListener('click', function () {
			joinBlock(block, join, container);
		});
		card.appendChild(join);

		if (config.isPreview) {
			card.appendChild(element('p', 'tutorhelper-group-student__preview', config.messages.preview));
		}

		container.appendChild(card);
	}

	function joinBlock(block, button, container) {
		button.disabled = true;
		button.textContent = config.messages.joining;

		var data = new FormData();
		data.append('action', 'tutorhelper_group_join_block');
		data.append('nonce', config.nonce);
		data.append('block_id', String(block.id));
		if (config.studentUserId) {
			data.append(
				'tutorhelper_booking_child_id',
				String(config.studentUserId)
			);
		}

		fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (response) {
				if (!response.success) {
					throw new Error(response.data && response.data.message ? response.data.message : config.messages.error);
				}

				if (response.data.redirectUrl) {
					window.location.assign(response.data.redirectUrl);
					return;
				}

				container.innerHTML = '';
				container.appendChild(element('p', 'tutorhelper-group-student__success', response.data.message));
			})
			.catch(function (error) {
				button.disabled = false;
				button.textContent = 'Join this Group Lesson';
				var message = element('p', 'tutorhelper-group-student__error', error.message);
				container.appendChild(message);
			});
	}

	function renderBlocks(root, service) {
		var typeId = String(service.getAttribute('data-booking-type-id') || '');
		var panels = root.querySelectorAll('.tutorhelper-student-booking__selection-grid > .tutorhelper-student-booking__panel');
		if (panels.length < 3) {
			return;
		}

		resetServiceSelection(root, service);

		var blocksPanel = panels[1];
		var detailsPanel = panels[2];
		var blocksContainer = blocksPanel.querySelector('[data-booking-calendar]');
		var detailsContainer = detailsPanel.querySelector('[data-booking-times]');
		var blocks = config.blocksByType && config.blocksByType[typeId] ? config.blocksByType[typeId] : [];

		blocksPanel.querySelector('.tutorhelper-student-booking__panel-heading').childNodes[0].nodeValue = 'Select Group Block ';
		detailsPanel.querySelector('.tutorhelper-student-booking__panel-heading').childNodes[0].nodeValue = 'Block Details ';

		blocksContainer.innerHTML = '';
		detailsContainer.innerHTML = '';
		detailsContainer.appendChild(element('p', 'tutorhelper-student-booking__placeholder', 'Select a block to view its details.'));

		if (!blocks.length) {
			blocksContainer.appendChild(element('p', 'tutorhelper-group-student__empty', config.messages.empty));
			return;
		}

		var list = element('div', 'tutorhelper-group-student__blocks');
		blocks.forEach(function (block) {
			var label = block.dayOfWeek + ' · ' + block.startDate + ' – ' + block.endDate;
			var card = element('button', 'tutorhelper-group-student__block', '');
			card.type = 'button';
			card.disabled = block.isFull && !block.isEnrolled;
			card.appendChild(element('strong', '', block.title));
			card.appendChild(element('span', '', label));
			var recurrence = recurrenceLabel(block);
			card.appendChild(element('span', '', block.time + ' · ' + block.duration + (recurrence ? ' · ' + recurrence : '') + ' · ' + sessionLabel(block)));
			card.appendChild(element('span', '', block.total));
			card.appendChild(element(
				'span',
				'tutorhelper-group-student__spaces',
				block.spaces === null ? 'Spaces available' : (block.spaces + (block.spaces === 1 ? ' space remaining' : ' spaces remaining'))
			));

			if (block.isEnrolled) {
				card.appendChild(element('span', 'tutorhelper-group-student__badge', 'Already joined'));
			} else if (block.isFull) {
				card.appendChild(element('span', 'tutorhelper-group-student__badge is-full', 'Full'));
			} else if (!block.isBookable) {
				card.appendChild(element('span', 'tutorhelper-group-student__badge', block.bookingWindowMessage));
			}

			card.addEventListener('click', function () {
				list.querySelectorAll('.tutorhelper-group-student__block').forEach(function (item) {
					item.classList.toggle('is-selected', item === card);
				});
				renderDetails(detailsContainer, block);
			});
			list.appendChild(card);
		});
		blocksContainer.appendChild(list);
	}

	function initialiseGroupServices(root) {
		var scope = root && root.querySelectorAll ? root : document;

		scope.querySelectorAll('[data-booking-service]').forEach(function (service) {
			var typeId = String(service.getAttribute('data-booking-type-id') || '');
			if (typeIds.indexOf(typeId) === -1) {
				return;
			}

			service.setAttribute('data-group-booking-service', '1');
			var meta = service.querySelector('.tutorhelper-student-booking__service-meta');
			if (meta) {
				meta.textContent = 'Choose a complete Group Lesson block';
			}
		});
	}

	window.TutorHelperGroupStudentInitialise = initialiseGroupServices;
	initialiseGroupServices(document);

	document.addEventListener('click', function (event) {
		var service = event.target.closest('[data-booking-service]');
		if (!service) {
			return;
		}

		var typeId = String(service.getAttribute('data-booking-type-id') || '');
		var root = service.closest('[data-tutorhelper-student-booking]');
		if (typeIds.indexOf(typeId) === -1) {
			if (root) {
				root.classList.remove('is-group-mode');
				var headings = root.querySelectorAll('.tutorhelper-student-booking__selection-grid > .tutorhelper-student-booking__panel .tutorhelper-student-booking__panel-heading');
				if (headings.length >= 3) {
					headings[1].childNodes[0].nodeValue = 'Select Date ';
					headings[2].childNodes[0].nodeValue = 'Select Time ';
				}
			}
			return;
		}

		event.preventDefault();
		event.stopImmediatePropagation();

		if (root) {
			root.classList.add('is-group-mode');
			renderBlocks(root, service);
		}
	}, true);
}());
