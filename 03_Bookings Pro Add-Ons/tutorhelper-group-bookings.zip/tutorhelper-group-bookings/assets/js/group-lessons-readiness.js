(function () {
	'use strict';

	var config = window.tutorhelperGroupReadiness || {};

	function updateAwaitingMinimumLabels() {
		var labels = document.querySelectorAll(
			'.tutorhelper-group-status.is-awaiting_minimum'
		);

		labels.forEach(function (label) {
			if (config.awaitingLabel) {
				label.textContent = config.awaitingLabel;
			}
		});
	}

	function addReadinessMessage() {
		var detail = document.querySelector('.tutorhelper-group-block-detail');
		var status = detail
			? detail.querySelector('.tutorhelper-group-status.is-awaiting_minimum')
			: null;
		var summary = detail
			? detail.querySelector('.tutorhelper-group-block-summary')
			: null;

		if (!status || !summary || !config.awaitingMessage) {
			return;
		}

		if (detail.querySelector('.tutorhelper-group-readiness-note')) {
			return;
		}

		var note = document.createElement('div');
		note.className = 'tutorhelper-group-readiness-note';
		note.setAttribute('role', 'status');

		var icon = document.createElement('span');
		icon.className = 'dashicons dashicons-info-outline';
		icon.setAttribute('aria-hidden', 'true');

		var text = document.createElement('span');
		text.textContent = config.awaitingMessage;

		note.appendChild(icon);
		note.appendChild(text);
		summary.insertAdjacentElement('afterend', note);
	}

	document.addEventListener('DOMContentLoaded', function () {
		updateAwaitingMinimumLabels();
		addReadinessMessage();
	});
})();
