(function () {
	'use strict';

	var config = window.tutorhelperGroupLessonsForm || {};

	function toggleField(control, show) {
		if (!control) {
			return;
		}

		control.hidden = !show;
		control.setAttribute('aria-hidden', show ? 'false' : 'true');
	}

	function updateControlLabel(control, text) {
		if (!control) {
			return;
		}

		var label = control.querySelector(':scope > span');
		if (label) {
			label.textContent = text;
		}
	}

	function replaceLocationTypeInput(form) {
		var input = form.querySelector('[name="location_type"]');
		if (!input || input.tagName === 'SELECT') {
			return;
		}

		var select = document.createElement('select');
		select.name = 'location_type';
		select.required = true;

		[
			{ value: 'online', label: 'Online' },
			{ value: 'in-person', label: 'In person' },
			{ value: 'phone', label: 'Phone' }
		].forEach(function (definition) {
			var option = document.createElement('option');
			option.value = definition.value;
			option.textContent = definition.label;
			select.appendChild(option);
		});

		var current = String(input.value || '').trim().toLowerCase();
		if (current === 'in_person' || current === 'in person') {
			current = 'in-person';
		}

		select.value = current === 'in-person' || current === 'phone'
			? current
			: 'online';

		input.replaceWith(select);
	}

	function prepareExistingMarkup(form) {
		var isEdit = form.dataset.groupFormMode === 'edit';
		var perSessionInput = form.querySelector('[name="price_per_session_minor_units"]');
		var fixedBlockInput = form.querySelector('[name="fixed_block_price_minor_units"]');
		var paymentMode = form.querySelector('[name="payment_mode"]');
		var depositType = form.querySelector('[name="deposit_type"]');
		var depositValue = form.querySelector('[name="deposit_value"]');
		var locationDetails = form.querySelector('[name="location_details"]');

		replaceLocationTypeInput(form);

		if (perSessionInput) {
			perSessionInput.name = 'price_per_session';
			perSessionInput.step = '0.01';
			perSessionInput.min = '0';
			perSessionInput.value = isEdit
				? (parseInt(perSessionInput.value || '0', 10) / 100).toFixed(2)
				: '';
			perSessionInput.placeholder = '0.00';
			perSessionInput.closest('.tutorhelper-admin-control').dataset.groupPricing = 'per-session';
			updateControlLabel(
				perSessionInput.closest('.tutorhelper-admin-control'),
				'Price per lesson (' + (config.currencyCode || 'currency') + ')'
			);

			var perSessionHelp = perSessionInput.closest('.tutorhelper-admin-control').querySelector('small');
			if (perSessionHelp) {
				perSessionHelp.textContent = 'Enter the amount students pay for each lesson, for example 25.00.';
			}
		}

		if (fixedBlockInput) {
			fixedBlockInput.name = 'fixed_block_price';
			fixedBlockInput.step = '0.01';
			fixedBlockInput.min = '0';
			if (isEdit && fixedBlockInput.value !== '') {
				fixedBlockInput.value = (parseInt(fixedBlockInput.value, 10) / 100).toFixed(2);
			}
			fixedBlockInput.placeholder = '0.00';
			fixedBlockInput.closest('.tutorhelper-admin-control').dataset.groupPricing = 'fixed-block';
			updateControlLabel(
				fixedBlockInput.closest('.tutorhelper-admin-control'),
				'Fixed block price (' + (config.currencyCode || 'currency') + ')'
			);

			var fixedHelp = fixedBlockInput.closest('.tutorhelper-admin-control').querySelector('small');
			if (fixedHelp) {
				fixedHelp.textContent = 'Only used when fixed block pricing is selected.';
			}
		}

		if (paymentMode) {
			Array.prototype.forEach.call(paymentMode.options, function (option) {
				if (option.value === 'deposit') {
					option.textContent = 'Book with deposit';
				}
			});
		}

		if (depositType && depositValue) {
			var depositGrid = depositType.closest('.tutorhelper-group-block-form__grid');
			if (depositGrid) {
				depositGrid.dataset.groupDepositSettings = '';
				depositGrid.classList.add('tutorhelper-group-block-form__deposit');
			}

			var depositValueControl = depositValue.closest('.tutorhelper-admin-control');
			var depositValueLabel = depositValueControl
				? depositValueControl.querySelector(':scope > span')
				: null;
			var depositValueHelp = depositValueControl
				? depositValueControl.querySelector('small')
				: null;

			if (depositValueLabel) {
				depositValueLabel.dataset.groupDepositValueLabel = '';
			}
			if (depositValueHelp) {
				depositValueHelp.dataset.groupDepositValueHelp = '';
			}
		}

		if (locationDetails) {
			var locationControl = locationDetails.closest('.tutorhelper-admin-control');
			if (locationControl && !locationControl.querySelector('[data-group-location-note]')) {
				var note = document.createElement('small');
				note.dataset.groupLocationNote = '';
				note.className = 'tutorhelper-group-block-form__location-note';
				locationControl.appendChild(note);
			}
		}
	}

	function initialiseForm(form) {
		prepareExistingMarkup(form);

		var pricing = form.querySelector('[name="pricing_basis"]');
		var perSessionField = form.querySelector('[data-group-pricing="per-session"]');
		var fixedBlockField = form.querySelector('[data-group-pricing="fixed-block"]');
		var paymentMode = form.querySelector('[name="payment_mode"]');
		var depositFields = form.querySelector('[data-group-deposit-settings]');
		var depositType = form.querySelector('[name="deposit_type"]');
		var depositValue = form.querySelector('[name="deposit_value"]');
		var depositValueLabel = form.querySelector('[data-group-deposit-value-label]');
		var depositValueHelp = form.querySelector('[data-group-deposit-value-help]');
		var locationNote = form.querySelector('[data-group-location-note]');

		function updatePricingFields() {
			var basis = pricing ? pricing.value : 'booking_type';
			toggleField(perSessionField, basis === 'per_session');
			toggleField(fixedBlockField, basis === 'fixed_block');
		}

		function updateDepositValuePresentation() {
			if (!depositType || !depositValue) {
				return;
			}

			var isPercentage = depositType.value === 'percentage';
			depositValue.step = isPercentage ? '1' : '0.01';
			depositValue.min = '0';
			depositValue.max = isPercentage ? '100' : '';

			if (depositValueLabel) {
				depositValueLabel.textContent = isPercentage
					? 'Deposit percentage'
					: 'Deposit amount (' + (config.currencyCode || 'currency') + ')';
			}

			if (depositValueHelp) {
				depositValueHelp.textContent = isPercentage
					? 'Enter a percentage from 0 to 100.'
					: 'Enter the deposit as a normal currency amount, for example 30.00.';
			}
		}

		function updateDepositFields() {
			var show = paymentMode && paymentMode.value === 'deposit';
			toggleField(depositFields, show);

			if (!show) {
				if (depositType) {
					depositType.value = 'none';
				}
				if (depositValue) {
					depositValue.value = '0';
				}
				return;
			}

			if (depositType && depositType.value === 'none') {
				depositType.value = 'fixed';
			}

			updateDepositValuePresentation();
		}

		if (pricing) {
			pricing.addEventListener('change', updatePricingFields);
		}
		if (paymentMode) {
			paymentMode.addEventListener('change', updateDepositFields);
		}
		if (depositType) {
			depositType.addEventListener('change', updateDepositValuePresentation);
		}
		if (locationNote && config.locationNote) {
			locationNote.textContent = config.locationNote;
		}

		updatePricingFields();
		updateDepositFields();
	}

	document.addEventListener('DOMContentLoaded', function () {
		var form = document.querySelector('.tutorhelper-group-block-form');
		if (form) {
			initialiseForm(form);
		}

		Array.prototype.forEach.call(
			document.querySelectorAll('[data-group-student-selector]'),
			function (selector) {
				var checkboxes = Array.prototype.slice.call(selector.querySelectorAll('input[type="checkbox"]'));
				var maximum = parseInt(selector.dataset.maxSelections || '0', 10);
				var count = selector.querySelector('[data-group-selection-count]');
				var selectAll = selector.querySelector('[data-group-select-all]');
				var clearAll = selector.querySelector('[data-group-clear-all]');

				function refresh() {
					var selected = checkboxes.filter(function (checkbox) { return checkbox.checked; }).length;
					if (count) {
						count.textContent = selected + ' selected';
					}
					checkboxes.forEach(function (checkbox) {
						checkbox.disabled = !checkbox.checked && maximum > 0 && selected >= maximum;
					});
				}

				checkboxes.forEach(function (checkbox) { checkbox.addEventListener('change', refresh); });
				if (selectAll) {
					selectAll.addEventListener('click', function () {
						checkboxes.forEach(function (checkbox, index) {
							checkbox.checked = maximum === 0 || index < maximum;
						});
						refresh();
					});
				}
				if (clearAll) {
					clearAll.addEventListener('click', function () {
						checkboxes.forEach(function (checkbox) { checkbox.checked = false; });
						refresh();
					});
				}
				refresh();
			}
		);

		Array.prototype.forEach.call(
			document.querySelectorAll('.tutorhelper-group-block-delete-form[data-confirm]'),
			function (deleteForm) {
				deleteForm.addEventListener('submit', function (event) {
					if (!window.confirm(deleteForm.dataset.confirm)) {
						event.preventDefault();
					}
				});
			}
		);
	});
})();


/* Group schedule preview: replace only the preview panel and keep the form state intact. */
(function () {
	'use strict';

	function requestPreview(button) {
		var config = window.TutorHelperGroupSchedule;
		var form = button.closest('form');
		var panel = form ? form.querySelector('[data-group-schedule-preview]') : null;
		if (!config || !form || !panel) {
			return;
		}

		var data = new FormData(form);
		data.append('action', config.action);
		data.append('nonce', config.nonce);
		button.disabled = true;
		button.setAttribute('aria-busy', 'true');

		window.fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (response) {
				if (!response || !response.success) {
					throw new Error(response && response.data && response.data.message ? response.data.message : config.error);
				}
				panel.innerHTML = response.data.html;
			})
			.catch(function (error) {
				panel.innerHTML = '<div class="notice notice-error inline"><p>' + String(error.message || config.error).replace(/</g, '&lt;') + '</p></div>';
			})
			.finally(function () {
				button.disabled = false;
				button.removeAttribute('aria-busy');
			});
	}

	document.addEventListener('click', function (event) {
		var button = event.target.closest('[data-group-schedule-preview-button]');
		if (!button) {
			return;
		}
		event.preventDefault();
		requestPreview(button);
	});
}());
