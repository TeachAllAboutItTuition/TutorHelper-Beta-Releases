=== TutorHelper Group Bookings ===
Contributors: teachallaboutit
Tags: tutor booking, group tuition, group bookings, class booking, lesson blocks
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: tutorhelper-bookings
Stable tag: 1.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create and manage group tuition blocks, enrolments and shared lesson sessions alongside TutorHelper Bookings Core and Pro.

== Description ==

TutorHelper Group Bookings extends TutorHelper Bookings Core and TutorHelper Pro with structured group lesson blocks.

The add-on is designed for tutors who teach students in groups while still managing each student's bookings, attendance, payments and invoices individually.

Current development foundations include:

* A Group Lessons tab inside the TutorHelper Booking Hub.
* Group blocks linked to existing TutorHelper Pro Groups.
* WordPress admin creation of Group Lesson blocks.
* Weekly and fortnightly Group Block schedules.
* Automatic generation of lesson sessions between the block start and end dates.
* Block detail views showing generated session dates and times.
* Minimum and maximum enrolment limits.
* Readiness lifecycle that keeps a new block Awaiting minimum enrolment until enough secured students join.
* Automatic transition foundations for Confirmed and Full block states.
* Per-session pricing with calculated block totals.
* Booking Type pricing support using the actual group session duration.
* Tutor-facing currency inputs for per-session and fixed-block price overrides.
* Optional fixed-price block overrides.
* Manual, full-upfront and Book with deposit payment arrangements.
* Fixed-amount or percentage deposit configuration shown only when deposit booking is selected.
* Location notes for preparation and joining instructions.
* Group Block and Group Session lifecycle records.
* Individual Core booking records for every enrolled student and session.
* Tutor-managed student enrolment from the Group Lesson block screen.
* Per-enrolment payment totals, balances and payment status.
* Manual and invoice payment recording with payment dates and references.
* Payment and deposit allocation across the student's child lesson bookings.
* TutorHelper Pro finance-ledger and payment-history integration.
* Two-way payment reconciliation between Group Lessons and Pro Finance.
* Ledger-based refresh of payments, deposits, refunds and account credits.
* Full-block Stripe Checkout for full-upfront enrolments.
* Stripe Checkout for fixed and percentage deposits.
* Separate Stripe Checkout for the remaining balance after a deposit.
* Verified Stripe webhook processing through TutorHelper Pro.
* Stripe payment allocation across the linked child lesson bookings.
* Checkout amount and currency verification with replay protection.
* Automatic expiry of stale Checkout Sessions after another payment changes the balance.
* Automatic place security when the required full payment or deposit is reached.
* Student-facing Group Block selection for eligible Pro Group members.
* Complete block price, schedule, spaces and deposit details before enrolment.
* Student self-enrolment with automatic child booking creation.
* Automatic Stripe Checkout hand-off after joining a paid block.
* Cancellation of unpaid new enrolments when their initial Stripe Checkout is cancelled or expires.
* Student-only Stripe actions; tutors continue to record invoice and bank-transfer payments manually.
* Group Lesson dashboard cards with payment balance and block readiness.
* Confirmed session dates and joining details on the student dashboard.
* Student Stripe balance payments for any active Group Lesson with an outstanding balance.
* DST-safe display using each block's saved IANA timezone.
* One shared Google Calendar event and meeting link per Group Session.
* Planned Calendar reservations before minimum enrolment is reached.
* Tutor editing and safe deletion of unused Group Blocks.
* A tutor-facing attendance roster for every Group Session.
* Independent attendance saved against each student's existing Core child booking.
* Attended/confirmed session summaries and previous/next attendance navigation.
* Per-session location and preparation notes shared with students and Calendar.
* Tutor bulk enrolment of multiple eligible Group students.
* Tutor conversion of an upcoming individual lesson, or a compatible future weekly/fortnightly series, into a reviewed new Group Lesson block.
* Immutable paid-value transfer and source-to-replacement audit records for booking conversions.
* Retry-safe tutor Group Block cancellation with eligible credit allocation, Diagnostics logging and preserved child-booking history.

Planned features include:

* Student cancellation and rescheduling controls for Group Lesson places.
* Student dashboard messaging while a block is awaiting minimum enrolment.
* Tutor warnings when a block is below its minimum or reaches capacity.
* Capacity-safe student enrolment.
* Group-wide rescheduling workflows.

TutorHelper Group Bookings requires both TutorHelper Bookings Core and a licensed copy of TutorHelper Pro. Version 0.2.0 also requires its own active Group Bookings licence.

== Installation ==

1. Install and activate TutorHelper Bookings Core.
2. Install and activate TutorHelper Pro.
3. Upload the `tutorhelper-group-bookings` folder to `/wp-content/plugins/`, or install the plugin ZIP through WordPress.
4. Activate TutorHelper Group Bookings from the Plugins screen.
5. Open TutorHelper > Booking Hub > Group Lessons to create and review lesson blocks.

== Frequently Asked Questions ==

= Does Group Bookings replace individual student bookings? =

No. Each enrolled student will retain their own Core booking for each lesson in the block so attendance, finance, cancellation and student records remain individual.

= Can different blocks have different lengths? =

Yes. A tutor chooses a start date, end date and recurrence. Weekly and fortnightly schedules are supported by the current development foundation, so the same per-session rate can be used for short revision courses or longer teaching blocks.

= How is pricing calculated? =

The default model is a per-session price. A block total is calculated from the session price multiplied by the number of generated sessions. Tutors can use the Booking Type price, set a specific per-session group price, or use a fixed total block price.

When Booking Type pricing is selected, TutorHelper Group Bookings uses Core's Booking Type price calculation for the actual session duration.

Price overrides are entered in normal currency amounts in the admin interface and converted internally to integer minor units for storage and finance calculations.

= What happens if the minimum enrolment is not reached? =

A completed Group Lesson block is shown as Awaiting minimum enrolment until the required number of secured students has joined. Its lesson sessions exist, but the student bookings will remain unconfirmed until the minimum is reached.

Earlier development blocks that were shown as Draft are automatically migrated to Awaiting minimum enrolment when they already contain generated sessions.

= What happens when the minimum enrolment is reached? =

The block automatically moves to Confirmed once the secured enrolment count reaches the minimum. Manual/invoice enrolments reserve a secured place immediately. Online-payment enrolments become secured when their required full payment or deposit has been recorded.

= What happens when the maximum enrolment is reached? =

The block becomes Full and further enrolments will be prevented.


= How are manual or invoice payments recorded? =

Open the Group Lesson block and find the student in the Student enrolments table. The payment column shows the paid and remaining amounts. Enter the amount received, choose Payment or Deposit, select the payment date and optionally enter an invoice or bank reference.

TutorHelper Group Bookings allocates the amount across the student's child lesson bookings in session order. Each allocation is written to the existing TutorHelper Pro finance ledger, so the child bookings remain visible in finance reports.

Payments can also be recorded against an individual child lesson through the normal TutorHelper Pro Finance screen. When the Group Lesson block is opened, its enrolment totals are rebuilt from the linked Pro ledger entries so payments recorded through either screen produce the same balance.

= How does full Stripe payment work? =

A full-upfront enrolment uses one hosted Stripe Checkout Session for the complete remaining block balance. A deposit enrolment first creates a Checkout Session for only the fixed or percentage deposit required to secure the place. Once the deposit is confirmed, a separate Checkout can collect the remaining balance. TutorHelper Pro supplies the configured Stripe credentials and verifies the webhook signature. TutorHelper Group Bookings then verifies the enrolment, session, amount and currency before allocating the payment across the student's child lesson bookings.

If another payment changes the balance while a Checkout Session is open, the old Session is expired so it cannot collect an outdated amount.

Stripe payment controls are available only to the enrolled student. Tutors can record invoice, bank-transfer and other manual payments from the block screen. Students can use Stripe from My Group Lessons for any outstanding group balance, including a block originally configured for manual/invoice payment.

If a student cancels or leaves the initial Stripe Checkout before paying anything, the enrolment and its child bookings are cancelled and the place is released. Cancelling a later balance Checkout after a deposit or manual payment does not cancel the secured enrolment.

= Does recording a deposit mark the whole block as paid? =

No. A deposit reduces the enrolment balance and may secure the student's place, but the remaining block balance stays visible until further payments are recorded.

= How do students join a Group Lesson? =

When a Booking Type is linked to an available Group Lesson block, selecting that service replaces the individual date and time picker with eligible blocks. Each block shows its complete schedule, total price, deposit requirement, spaces remaining and minimum-enrolment state.

After selecting Join this Group Lesson, the add-on creates the enrolment and all linked child bookings. Paid enrolments then continue directly to the appropriate Stripe deposit or full-payment Checkout.

= Where can students see their Group Lessons? =

The student dashboard includes a My Group Lessons section. It shows the block dates, payment balance and whether the block is awaiting minimum enrolment. Once confirmed, it lists the session dates and displays the shared joining details.

== Changelog ==

= 1.1.1 =

* 🎨 Improvement: Matches public Group Lesson cards and the lightweight registration form to the existing TutorHelper booking-form styling, including compact controls and responsive panels.
* 🚀 Improvement: Opens the selected public Group Lesson registration form in place, so it does not reload the page or conflict with a separate standard registration form.
* 🐛 Fix: Keeps the public Group Lesson listing live for signed-out visitors, returns a booked student to the configured Student Dashboard, prevents a second place request and hands paid enrolments safely to Stripe Checkout.
* 🆕 New Feature: Lets visitors create a lightweight External student account when booking an open Group Lesson, or sign in to an existing account instead.
* 🔒 Security: Keeps account creation, Group place reservation and Stripe payment as separate confirmed actions, with server-side availability, consent, nonce and rate-limit checks.
* 🚀 Improvement: Shows External students only open Group Lesson options until their tutor promotes their account, and sends an editable account-created email.

* ✨ Add: 🌐 Lets tutors explicitly open a Group Lesson for public discovery while keeping every existing Group Lesson private by default.
* ✨ Add: 🗂️ Adds the `[tutorhelper_open_group_bookings]` shortcode, with date-ordered Group Lesson cards, availability, capacity, recurrence, price and booking-window status.
* 🎨 Improvement: 🧩 Applies the shared TutorHelper orange primary and grey secondary button treatment to Group Lesson actions, including Convert Booking and conversion confirmation.
* 🎨 Improvement: ☑️ Keeps Group Lesson cancellation controls compact and aligned instead of stretching full-width.
* ✨ Add: 🔄 Lets tutors preview and explicitly confirm conversion of an upcoming individual lesson, or the compatible remaining weekly/fortnightly series, into a new Group Lesson block.
* 🚀 Improvement: 🧩 Lets tutors choose the Group Booking Type for a conversion, so the replacement sessions use the correct Group availability while retaining the original student price and paid-value transfer.
* 🚀 Improvement: 🛠️ Gives booking conversions the same booking-window, capacity, pricing, payment and cancellation controls as a new Group Lesson block, while previewing every session that will and will not be created.
* 🐛 Fix: Prevents the Group conversion preview from failing when its stored excluded-date list is empty or JSON-encoded.
* 🐛 Fix: Treats blank booking-window dates as open booking, including existing blocks that contain a legacy zero date.
* 🐛 Fix: Keeps the source lesson out of the replacement child-booking conflict check and safely resumes an unused failed conversion block instead of duplicating it.
* 🐛 Fix: 🧭 Excludes only the individual booking(s) being replaced from the temporary conversion conflict check, while retaining all other availability, leave, exclusion and booking checks.
* 🎨 Improvement: ✨ Aligns the conversion choices and navigation/confirmation controls with the standard TutorHelper admin styling.
* ✨ Add: 🧾 Preserves the original student as the first Group enrolment, transfers eligible paid value through the Pro ledger, retires source bookings only after replacement creation, and records an auditable conversion link.
* 🐛 Fix: 🔎 Records conversion-preview and confirmation failures in TutorHelper Diagnostics with the source, scope and safe error details, including unexpected integration errors, and shows the confirmation error in the conversion wizard.

* 🐛 Fix: 🧾 Makes whole Group Block cancellation retry-safe: a failed eligible credit or child-lesson cancellation leaves the block open, logs the failure in Diagnostics and safely resumes without duplicate credit on retry.

* 🆕 New Feature: 🗓️ Adds in-place tutor previews for Group Lesson session dates, with manual date deselection and clear included, warning and blocked states from Core availability, leave, holiday and conflict rules.
* 🆕 New Feature: ➕ Lets tutors preview and safely extend a Group Lesson schedule, creating only new sessions and child bookings.
* 🚀 Improvement: 💷 Recalculates active enrolment totals and child-booking allocations when a schedule extension adds chargeable sessions, while retaining existing payment and deposit history.
* 🔒 Security: 🧾 Makes schedule extensions idempotent with unique session and enrolment-to-session booking safeguards.
* 🆕 New Feature: 👤 Lets tutors remove a student from the remaining scheduled Group Lesson sessions without altering historic bookings, and prevents later extensions from recreating those bookings.

* 🆕 New Feature: 🗓️ Adds optional Bookable from and Bookable until dates to Group Lesson blocks, enforced for student enrolment requests.
* 🚀 Improvement: 👥 Shows Group session day, duration and recurrence more clearly to students, and gives tutors an at-a-glance enrolled/minimum/capacity display.
* ♻️ Update: 🧩 Moves the Group block save action to the top of the edit form using the standard primary button style.


* 🐛 Fix: Keeps valid Group Bookings licences active when License Manager reports its active key status during scheduled rollover validation.
* 🚀 Improvement: Records the safe licence-server reason in scheduled-validation diagnostics without logging keys, tokens or site details.
* 🔒 Security: Validates this add-on licence against its specific TutorHelper installation for one-site enforcement.
* 🐛 Fix: Keeps the add-on active when a scheduled check fails because of a temporary connection, server or unexpected-response error.
* 🚀 Improvement: Adds safe scheduled-validation diagnostics without storing licence keys, tokens or site URLs.

* Persists and verifies the Group Bookings licence key before remote activation.
* Retains the saved key across logins, validation failures and licence deactivation.
* Adds an explicit Remove saved key action for inactive licences.

= 1.1.0 =

* Shows the Group name, rather than individual enrollee names, in Core's compact weekly timetable.

= 1.0.0 =

* First stable release of Group Bookings.
* Uses shared Booking Hub presentation and wrapped navigation supplied by Core.
* Retains licensed group lesson, homework and reminder workflows.



= 0.2.0 =
* Added Group Bookings licence activation, validation and deactivation within the existing Pro Licence screen.
* Locked add-on features unless both Pro and Group Bookings licences are active.
* Added renewal-date and lifetime-licence status.
* Added daily licence validation and a 30-day manual-renewal warning.

= 0.1.0 =
* Added initial plugin bootstrap and dependency checks.
* Added Group Block, Group Session, Enrolment and Session Booking database foundations.
* Added minimum and maximum enrolment fields.
* Added pricing, deposit and payment-mode foundations.
* Added Group Block and Group Session lifecycle foundations.
* Added validated Group Block creation service.
* Added weekly and fortnightly recurrence generation.
* Added timezone-aware Group Session generation with UTC session timestamps.
* Added Booking Type price resolution using the actual session duration.
* Added rollback handling when session generation fails.
* Added Group Block and Group Session creation hooks for later integrations.
* Added the Group Lessons tab to the TutorHelper Booking Hub.
* Added Group Lesson block creation controls for Group, Booking Type, schedule, capacity, pricing, deposits and payment arrangement.
* Added Group Lesson block listing and detail views.
* Added generated session inspection in wp-admin.
* Added padding and responsive spacing around the Group Lesson creation form.
* Changed tutor-entered price overrides from minor units to normal currency amounts.
* Renamed the deposit payment option to Book with deposit.
* Show deposit configuration only when Book with deposit is selected.
* Added clearer fixed and percentage deposit inputs.
* Added location guidance for preparation notes and dashboard joining links.
* Added padding around the Group Lesson block detail view.
* Replaced the normal completed-block Draft state with Awaiting minimum enrolment.
* Added one-time migration for existing generated blocks still marked Draft.
* Added reusable block readiness rules for Awaiting minimum enrolment, Confirmed and Full states.
* Added clearer readiness messaging to the Group Lesson detail screen.
* Added fixed and percentage deposit calculations using integer minor units.
* Added enrolment payment totals for paid, outstanding, refunded and credited amounts.
* Added Unpaid, Partially paid, Paid, Partially refunded and Refunded payment states.
* Added validation for payment arrangements and deposit limits.
* Added tutor controls for recording manual, invoice and deposit payments.
* Added payment dates and optional invoice or bank references.
* Added oldest-session-first allocation across child lesson bookings.
* Added TutorHelper Pro finance ledger and payment history integration.
* Added two-way reconciliation between the Group Lessons and Pro Finance screens.
* Added ledger-based refresh of payments, deposits, refunds and issued or used credits.
* Added full-block Stripe Checkout for full-upfront enrolments.
* Added fixed and percentage Stripe deposit Checkout.
* Added remaining-balance Stripe Checkout after a successful deposit.
* Recorded deposit transactions separately from ordinary payments.
* Added verified Group Bookings webhook handling through TutorHelper Pro.
* Added Stripe amount, currency and Checkout Session validation.
* Added idempotent Stripe event handling and allocation across child bookings.
* Added automatic expiry of stale Group Lesson Checkout Sessions.
* Added student-facing Group Lesson block selection.
* Replaced individual date/time selection for Group Booking Types.
* Added eligibility, capacity, schedule, price and minimum-enrolment details.
* Added student self-enrolment and automatic paid-checkout hand-off.
* Added My Group Lessons dashboard cards.
* Added confirmed session lists, joining details and outstanding-payment actions.
* Added automatic enrolment security when the required payment or deposit is met.
* Restricted Stripe Checkout controls to enrolled students while retaining tutor manual-payment controls.
* Added student Stripe balance payment for every active Group Lesson with an outstanding balance.
* Released unpaid new places when initial Stripe Checkout is cancelled or expires.
* Preserved part-paid enrolments when a later balance Checkout is cancelled.
* Corrected Group and child-booking time displays using the block timezone and per-date DST offset.
* Added a schema repair for timezone metadata on existing linked child bookings.
* Added one shared Calendar event and meeting link per Group Session.
* Added planned Calendar reservations and Group Block editing/deletion controls.
* Added one Group Session attendance roster with independently saved student results.
* Reused TutorHelper Pro attendance records attached to existing Core child bookings.
* Added attendance completion summaries and adjacent-session navigation.

== Upgrade Notice ==

= 1.1.1 =

* 🐛 Fix: 👪 Ensures authorised parents booking through a child’s dashboard use that child’s Group Lesson eligibility, enrolments and payment flow.

Ensures the Group Bookings licence key remains stored on the site between administrator sessions.

= 1.1.0 =

Adds Group names to the compact weekly Tutor Calendar. TutorHelper Bookings 2.2.0 or later is recommended.

= 1.0.0 =

First stable release. Confirm TutorHelper Pro and the add-on licence are active after updating.


= 0.2.0 =
Activate the Group Bookings licence in the Pro Licence screen after updating.

= 0.1.0 =
Initial development release of TutorHelper Group Bookings.
