<?php
/**
 * Plugin Name:       TutorHelper Group Bookings
 * Plugin URI:        https://tutorhelper.co.uk/
 * Description:       Group blocks, enrolments and shared lesson sessions for TutorHelper Bookings Pro.
 * Version:           1.1.1
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Requires Plugins:  tutorhelper-bookings
 * Author:            Holly Billinghurst
 * Author URI:        https://tutorhelper.co.uk/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tutorhelper-group-bookings
 *
 * @package TutorHelper_Group_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'TUTORHELPER_GROUP_BOOKINGS_VERSION' ) ) {
	define( 'TUTORHELPER_GROUP_BOOKINGS_VERSION', '1.1.1' );
}

if ( ! defined( 'TUTORHELPER_GROUP_BOOKINGS_DB_VERSION' ) ) {
	define( 'TUTORHELPER_GROUP_BOOKINGS_DB_VERSION', '1.10.0' );
}

if ( ! defined( 'TUTORHELPER_GROUP_BOOKINGS_FILE' ) ) {
	define( 'TUTORHELPER_GROUP_BOOKINGS_FILE', __FILE__ );
}

if ( ! defined( 'TUTORHELPER_GROUP_BOOKINGS_PATH' ) ) {
	define(
		'TUTORHELPER_GROUP_BOOKINGS_PATH',
		plugin_dir_path( TUTORHELPER_GROUP_BOOKINGS_FILE )
	);
}

if ( ! defined( 'TUTORHELPER_GROUP_BOOKINGS_URL' ) ) {
	define(
		'TUTORHELPER_GROUP_BOOKINGS_URL',
		plugin_dir_url( TUTORHELPER_GROUP_BOOKINGS_FILE )
	);
}

if ( ! defined( 'TUTORHELPER_GROUP_BOOKINGS_BASENAME' ) ) {
	define(
		'TUTORHELPER_GROUP_BOOKINGS_BASENAME',
		plugin_basename( TUTORHELPER_GROUP_BOOKINGS_FILE )
	);
}

require_once TUTORHELPER_GROUP_BOOKINGS_PATH
	. 'includes/class-tutorhelper-group-bookings-dependency.php';

require_once TUTORHELPER_GROUP_BOOKINGS_PATH
	. 'includes/class-tutorhelper-group-bookings-database.php';

require_once TUTORHELPER_GROUP_BOOKINGS_PATH
	. 'includes/licensing/class-tutorhelper-group-license.php';

require_once TUTORHELPER_GROUP_BOOKINGS_PATH
	. 'includes/licensing/class-tutorhelper-group-license-api.php';

require_once TUTORHELPER_GROUP_BOOKINGS_PATH
	. 'includes/licensing/class-tutorhelper-group-license-controller.php';

require_once TUTORHELPER_GROUP_BOOKINGS_PATH
	. 'includes/licensing/class-tutorhelper-group-license-settings.php';

require_once TUTORHELPER_GROUP_BOOKINGS_PATH
	. 'includes/class-tutorhelper-group-bookings.php';

/**
 * Activate the add-on.
 *
 * @return void
 */
function tutorhelper_group_bookings_activate() {
	if ( ! TutorHelper_Group_Bookings_Dependency::requirements_met() ) {
		deactivate_plugins( TUTORHELPER_GROUP_BOOKINGS_BASENAME );

		wp_die(
			esc_html__(
				'TutorHelper Group Bookings requires both TutorHelper Bookings and TutorHelper Pro to be active.',
				'tutorhelper-group-bookings'
			),
			esc_html__(
				'TutorHelper Group Bookings',
				'tutorhelper-group-bookings'
			),
			array(
				'back_link' => true,
			)
		);
	}

	TutorHelper_Group_Bookings_Database::create_tables();
	TutorHelper_Group_License_Settings::schedule();
}

register_activation_hook(
	TUTORHELPER_GROUP_BOOKINGS_FILE,
	'tutorhelper_group_bookings_activate'
);

/** Stop the add-on licence validation schedule. */
function tutorhelper_group_bookings_deactivate() {
	TutorHelper_Group_License_Settings::unschedule();
}

register_deactivation_hook(
	TUTORHELPER_GROUP_BOOKINGS_FILE,
	'tutorhelper_group_bookings_deactivate'
);

/**
 * Start the add-on after Core and Pro have loaded.
 *
 * @return void
 */
function tutorhelper_group_bookings_run() {
	if ( ! TutorHelper_Group_Bookings_Dependency::requirements_met() ) {
		TutorHelper_Group_Bookings_Dependency::register_admin_notice();
		return;
	}

	TutorHelper_Group_License_Settings::init();

	if ( ! TutorHelper_Group_Bookings_Dependency::pro_is_licensed() ) {
		TutorHelper_Group_Bookings_Dependency::register_admin_notice();
		return;
	}

	if ( ! TutorHelper_Group_License::is_active() ) {
		return;
	}

	TutorHelper_Group_Bookings_Database::update_check();
	TutorHelper_Group_Bookings::instance()->run();
}

add_action(
	'plugins_loaded',
	'tutorhelper_group_bookings_run',
	30
);
