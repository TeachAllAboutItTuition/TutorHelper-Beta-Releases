<?php
/**
 * Plugin Name:       TutorHelper Parent & Child
 * Plugin URI:        https://tutorhelper.co.uk/
 * Description:       Gives linked parents and guardians secure access to their children's TutorHelper lessons, reports, payments and bookings.
 * Version:           1.0.3
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Requires Plugins:  tutorhelper-bookings
 * Author:            Holly Billinghurst
 * Author URI:        https://tutorhelper.co.uk/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tutorhelper-parent-child
 * @package TutorHelper_Parent_Child
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! defined( 'TUTORHELPER_PARENT_CHILD_VERSION' ) ) { define( 'TUTORHELPER_PARENT_CHILD_VERSION', '1.0.3' ); }
if ( ! defined( 'TUTORHELPER_PARENT_CHILD_FILE' ) ) { define( 'TUTORHELPER_PARENT_CHILD_FILE', __FILE__ ); }
if ( ! defined( 'TUTORHELPER_PARENT_CHILD_PATH' ) ) { define( 'TUTORHELPER_PARENT_CHILD_PATH', plugin_dir_path( TUTORHELPER_PARENT_CHILD_FILE ) ); }
if ( ! defined( 'TUTORHELPER_PARENT_CHILD_URL' ) ) { define( 'TUTORHELPER_PARENT_CHILD_URL', plugin_dir_url( TUTORHELPER_PARENT_CHILD_FILE ) ); }
if ( ! defined( 'TUTORHELPER_PARENT_CHILD_BASENAME' ) ) { define( 'TUTORHELPER_PARENT_CHILD_BASENAME', plugin_basename( TUTORHELPER_PARENT_CHILD_FILE ) ); }

require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child-dependency.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/licensing/class-tutorhelper-parent-child-license.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/licensing/class-tutorhelper-parent-child-license-api.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/licensing/class-tutorhelper-parent-child-license-controller.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/licensing/class-tutorhelper-parent-child-license-settings.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child-assets.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child-diagnostics.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child-admin.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child-reports.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child-finance.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child-dashboard.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child.php';
require_once TUTORHELPER_PARENT_CHILD_PATH . 'includes/class-tutorhelper-parent-child-activator.php';

register_activation_hook( TUTORHELPER_PARENT_CHILD_FILE, array( 'TutorHelper_Parent_Child_Activator', 'activate' ) );

/** Stop the daily add-on licence validation schedule. */
function tutorhelper_parent_child_deactivate() {
	TutorHelper_Parent_Child_License_Settings::unschedule();
}
register_deactivation_hook( TUTORHELPER_PARENT_CHILD_FILE, 'tutorhelper_parent_child_deactivate' );

/** Start TutorHelper Parent & Child after Core and Pro have loaded. */
function tutorhelper_parent_child_run() {
	TutorHelper_Parent_Child::instance()->run();
}
add_action( 'plugins_loaded', 'tutorhelper_parent_child_run', 30 );
