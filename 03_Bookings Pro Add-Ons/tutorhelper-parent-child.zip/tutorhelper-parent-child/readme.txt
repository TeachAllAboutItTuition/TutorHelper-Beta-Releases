=== TutorHelper Parent & Child ===
Contributors: teachallaboutit
Tags: tutor, parent dashboard, student reports, lesson booking
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: tutorhelper-bookings
Stable tag: 1.0.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Secure parent and guardian access for TutorHelper Bookings and TutorHelper Pro.

== Description ==

TutorHelper Parent & Child is an optional add-on for TutorHelper Bookings Core and TutorHelper Pro.

Version 0.6.0 adds add-on licence management. Version 0.5.0 adds secure parent finance, PDF invoices and multi-lesson payments. Version 0.4.0 added relationship-aware language and read-only student reporting. Version 0.3.0 made the existing student dashboard and sidebar shortcodes role-aware. Linked parents receive a dedicated dashboard shell with secure child switching, remembered selection and navigation for lessons, attendance, feedback and homework, finance and lesson booking.

Parent-student relationships remain owned by TutorHelper Core so every TutorHelper extension uses one authoritative relationship model. TutorHelper Group Bookings remains optional.

== Installation ==

1. Install and activate TutorHelper Bookings Core.
2. Install, activate and license TutorHelper Pro.
3. Install and activate TutorHelper Parent & Child.
4. Activate the Parent & Child licence from the Pro Licence screen.
5. Link Parent Accounts from TutorHelper Student Details.
6. Add the existing `[tutorhelper_student_dashboard]` and `[tutorhelper_student_sidebar]` shortcodes to the configured pages.

== Changelog ==

= 1.0.2 =

* 🐛 Fix: 🔄 Requests fresh dashboard-tab content before replacing the panel, preventing stale booking-form markup or configuration after an update.

* 🚀 Improvement: 👪 Loads the selected child’s booking form and payment choices within the Parent Dashboard Book a Lesson tab.

* 🆕 New Feature: 🖥️ Lets authorised parent accounts book through the selected child’s Book a Lesson dashboard tab, using that child’s availability, prices and payment options.
* 🚀 Improvement: 🖥️ Updates Parent Dashboard tabs in place, preserving the page position and selected child.

* 🎨 Improvement: 🖥️ Reduces Parent Dashboard summary-card counter text to a more proportionate, readable 1rem size.

* 🎨 Improvement: 🧩 Adds shared standard TutorHelper button, compact option-row and filter-control utility hooks for consistent Parent & Child dashboard extensions.

* 🚀 Improvement: Allows Pro’s Tuition Reports table to reuse the established responsive Parent Dashboard report-table styling.

* ♻️ Update: Adds an extension point for Pro to provide a secure Tuition Reports section in linked parent dashboards.

* ♿ Accessibility: Adds a show/hide control and password-manager username metadata to Parent Password Management.

* 🐛 Fix: Keeps valid Parent & Child licences active when License Manager reports its active key status during scheduled rollover validation.
* 🚀 Improvement: Records the safe licence-server reason in scheduled-validation diagnostics without logging keys, tokens or site details.
* 🔒 Security: Validates this add-on licence against its specific TutorHelper installation for one-site enforcement.
* 🐛 Fix: Keeps the add-on active when a scheduled check fails because of a temporary connection, server or unexpected-response error.
* 🚀 Improvement: Adds safe scheduled-validation diagnostics without storing licence keys, tokens or site URLs.

* Persists the Parent & Child licence key before activation and verifies that it was stored successfully.
* Keeps the saved key available across logins, validation failures and licence deactivation.
* Adds an explicit Remove saved key action for inactive licences.

= 1.0.1 =

* Restyles Parent Account lists and details to match the TutorHelper Students workspace.
* Improves account headers, forms, actions, linked-student cards and responsive spacing.
* Ensures Parent Account admin styles remain available across Booking Hub routing states.

= 1.0.0 =

* First stable release of Parent / Child.
* Refreshes tutor-facing parent administration to match the Students area.
* Adds parent profile editing and secure password-management actions.



= 0.6.0 =
* Added Parent & Child licence activation, validation and deactivation within the existing Pro Licence screen.
* Locked add-on features unless both Pro and Parent & Child licences are active.
* Added renewal-date and lifetime-licence status.
* Added daily licence validation and a 30-day manual-renewal warning.

= 0.5.0 =
* Added unpaid and part-paid lesson balances due within 30 days.
* Added PDF invoice export and secure Stripe payment for selected lessons.
* Added bank-transfer and invoice-only payment guidance based on the student's Pro settings.
* Added finance summary cards and a filterable statement of account.
* Revalidated the parent-student relationship before invoice and payment actions.

= 0.4.0 =
* Added read-only overview, lessons, attendance, feedback and homework reports.
* Added relationship-aware dashboard wording with a Parent/Guardian fallback.
* Added responsive styling consistent with the student dashboard.
* Added attendance charts, filters and pagination without student action controls.


= 0.3.0 =
* Made the existing dashboard and sidebar shortcodes role-aware.
* Added the Parent Dashboard welcome, linked-child cards and navigation shell.
* Added session-scoped selected-child memory with signed cookies.
* Added relationship revalidation and a safe no-children empty state.

= 0.2.0 =
* Added the Parent Accounts Booking Hub workspace.
* Added searchable Parent Account listings.
* Added Parent Account detail views showing linked students.
* Added navigation to Core Student Details for relationship management.

= 0.1.0 =
* Added the Parent & Child plugin foundation.
* Added Core and Pro dependency validation.
* Added Core diagnostics integration.
* Added the parent-dashboard asset foundation.
* Added safe support for the existing TutorHelper parent role and Core-owned relationship service.
