<?php
/** Main TutorHelper Parent & Child controller. @package TutorHelper_Parent_Child */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Coordinates add-on startup. */
final class TutorHelper_Parent_Child {
	/** @var TutorHelper_Parent_Child|null */
	private static $instance = null;

	/** Return the shared plugin instance. */
	public static function instance() {
		if ( null === self::$instance ) { self::$instance = new self(); }
		return self::$instance;
	}

	/** Prevent construction outside this class. */
	private function __construct() {}

	/** Register the add-on runtime. */
	public function run() {
		TutorHelper_Parent_Child_Dependency::init();
		TutorHelper_Parent_Child_Diagnostics::init();
		if ( TutorHelper_Parent_Child_Dependency::core_is_available() && TutorHelper_Parent_Child_Dependency::pro_is_available() ) {
			TutorHelper_Parent_Child_License_Settings::init();
		}
		if ( ! TutorHelper_Parent_Child_Dependency::requirements_met() || ! TutorHelper_Parent_Child_License::is_active() ) { return; }
		TutorHelper_Parent_Child_Assets::init();
		TutorHelper_Parent_Child_Dashboard::init();
		TutorHelper_Parent_Child_Finance::init();
		if ( is_admin() ) { TutorHelper_Parent_Child_Admin::init(); }
		do_action( 'tutorhelper_parent_child_loaded', $this );
	}
}
