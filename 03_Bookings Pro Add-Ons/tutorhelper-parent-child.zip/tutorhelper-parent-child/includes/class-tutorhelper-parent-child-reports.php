<?php
/** Read-only parent reports using the TutorHelper student-table pattern. @package TutorHelper_Parent_Child */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_Parent_Child_Reports {
	const PAGE_SIZE = 10;

	public static function render( $section, $student ) {
		$student_id = absint( $student->ID );
		$upcoming   = TutorHelper_Student_Dashboard_Bookings::get_upcoming( $student_id );
		$past       = TutorHelper_Student_Dashboard_Bookings::get_past( $student_id );
		$all        = array_merge( $upcoming, $past );
		$ids        = array_map( 'absint', wp_list_pluck( $all, 'id' ) );
		$attendance = class_exists( 'TutorHelper_Pro_Student_Reporting' ) ? TutorHelper_Pro_Student_Reporting::get_attendance( $student_id, $ids ) : array( 'records' => array(), 'totals' => array() );
		$follow_ups = class_exists( 'TutorHelper_Pro_Student_Reporting' ) ? TutorHelper_Pro_Student_Reporting::get_follow_ups( $student_id, $ids ) : array();

		switch ( $section ) {
			case 'overview': self::overview( $student, $upcoming, $past, $attendance, $follow_ups ); break;
			case 'lessons': self::lessons( $upcoming ); break;
			case 'attendance': self::attendance( $past, $attendance['records'] ); break;
			case 'feedback': self::feedback( $past, $follow_ups ); break;
			default: return false;
		}
		return true;
	}

	private static function overview( $student, $upcoming, $past, $attendance, $follow_ups ) {
		$next = null; foreach ( $upcoming as $booking ) { if ( 'confirmed' === sanitize_key( $booking['status'] ) ) { $next = $booking; break; } }
		$recent = array_fill_keys( array( 'attended', 'late', 'missed' ), 0 ); $checked = 0;
		foreach ( $past as $booking ) { $status = $attendance['records'][ absint( $booking['id'] ) ]['status'] ?? 'not_recorded'; if ( isset( $recent[ $status ] ) ) { ++$recent[ $status ]; } if ( ++$checked >= 10 ) { break; } }
		$outstanding = 0; $feedback_count = 0;
		foreach ( $follow_ups as $item ) { if ( ! empty( $item['is_outstanding'] ) ) { ++$outstanding; } if ( ! empty( $item['feedback'] ) ) { ++$feedback_count; } }
		?>
		<div class="tutorhelper-parent-report__intro"><h4><?php printf( /* translators: %s: Student display name. */ esc_html__( '%s’s overview', 'tutorhelper-parent-child' ), esc_html( $student->display_name ) ); ?></h4><p><?php esc_html_e( 'A quick view of upcoming tuition and recent learning activity.', 'tutorhelper-parent-child' ); ?></p></div>
		<div class="tutorhelper-parent-summary-grid">
			<?php self::summary_card( __( 'Next lesson', 'tutorhelper-parent-child' ), $next ? $next['title'] : __( 'Nothing booked', 'tutorhelper-parent-child' ), $next ? self::date_time( $next ) : '', 'calendar-alt', 'navy' ); ?>
			<?php self::summary_card( __( 'Recent attendance', 'tutorhelper-parent-child' ), sprintf( /* translators: %d: Number of recently attended lessons. */ __( '%d attended', 'tutorhelper-parent-child' ), $recent['attended'] ), sprintf( /* translators: 1: Number of late lessons, 2: Number of missed lessons. */ __( '%1$d late · %2$d missed', 'tutorhelper-parent-child' ), $recent['late'], $recent['missed'] ), 'yes-alt', 'green' ); ?>
			<?php self::summary_card( __( 'Outstanding homework', 'tutorhelper-parent-child' ), (string) $outstanding, _n( 'task to complete', 'tasks to complete', $outstanding, 'tutorhelper-parent-child' ), 'clipboard', 'orange' ); ?>
			<?php self::summary_card( __( 'Tutor feedback', 'tutorhelper-parent-child' ), (string) $feedback_count, _n( 'feedback item available', 'feedback items available', $feedback_count, 'tutorhelper-parent-child' ), 'format-chat', 'blue' ); ?>
		</div><?php
	}

	private static function lessons( $bookings ) {
		$totals = self::booking_totals( $bookings );
		self::heading( __( 'Upcoming Lessons', 'tutorhelper-parent-child' ), __( 'Future lessons and requests awaiting confirmation.', 'tutorhelper-parent-child' ) );
		?><div class="tutorhelper-parent-summary-grid tutorhelper-parent-summary-grid--compact"><?php self::summary_card( __( 'Upcoming', 'tutorhelper-parent-child' ), (string) count( $bookings ), __( 'Future lessons', 'tutorhelper-parent-child' ), 'calendar-alt', 'navy' ); self::summary_card( __( 'Confirmed', 'tutorhelper-parent-child' ), (string) $totals['confirmed'], __( 'Ready to attend', 'tutorhelper-parent-child' ), 'yes-alt', 'green' ); self::summary_card( __( 'Pending', 'tutorhelper-parent-child' ), (string) $totals['pending'], __( 'Awaiting approval', 'tutorhelper-parent-child' ), 'clock', 'orange' ); self::summary_card( __( 'Cancelled', 'tutorhelper-parent-child' ), (string) $totals['cancelled'], __( 'Future cancellations', 'tutorhelper-parent-child' ), 'dismiss', 'red' ); ?></div><?php
		self::lesson_table( $bookings );
	}

	private static function attendance( $bookings, $records ) {
		$counts = array_fill_keys( array( 'attended', 'late', 'missed', 'info_only', 'not_recorded', 'cancelled' ), 0 );
		foreach ( $bookings as $booking ) { $status = self::attendance_status( $booking, $records ); if ( isset( $counts[ $status['key'] ] ) ) { ++$counts[ $status['key'] ]; } }
		self::heading( __( 'Attendance', 'tutorhelper-parent-child' ), __( 'Attendance for past lessons only.', 'tutorhelper-parent-child' ) );
		self::attendance_chart( $counts );
		self::attendance_table( $bookings, $records );
	}

	private static function feedback( $bookings, $follow_ups ) {
		$rows = array_values( array_filter( $bookings, function ( $booking ) use ( $follow_ups ) { return isset( $follow_ups[ absint( $booking['id'] ) ] ); } ) );
		$feedback_count = 0; $homework_count = 0; $outstanding = 0; $total_items = count( $rows );
		foreach ( $follow_ups as $item ) { if ( ! empty( $item['feedback'] ) ) { ++$feedback_count; } if ( self::has_homework( $item ) ) { ++$homework_count; } if ( ! empty( $item['is_outstanding'] ) ) { ++$outstanding; } }
		self::heading( __( 'Feedback & Homework', 'tutorhelper-parent-child' ), __( 'Read-only tutor feedback and homework from past lessons.', 'tutorhelper-parent-child' ) );
		?><div class="tutorhelper-parent-summary-grid tutorhelper-parent-summary-grid--three"><?php self::summary_card( __( 'Records', 'tutorhelper-parent-child' ), (string) $total_items, __( 'Past lessons with learning updates', 'tutorhelper-parent-child' ), 'welcome-learn-more', 'navy' ); self::summary_card( __( 'Feedback', 'tutorhelper-parent-child' ), (string) $feedback_count, __( 'Items available', 'tutorhelper-parent-child' ), 'format-chat', 'blue' ); self::summary_card( __( 'Homework', 'tutorhelper-parent-child' ), (string) $homework_count, __( 'Tasks set', 'tutorhelper-parent-child' ), 'clipboard', 'orange' ); self::summary_card( __( 'Outstanding', 'tutorhelper-parent-child' ), (string) $outstanding, __( 'Tasks not yet completed', 'tutorhelper-parent-child' ), 'warning', 'red' ); ?></div><?php
		self::feedback_table( $rows, $follow_ups );
	}

	private static function lesson_table( $bookings ) {
		$types = self::options( $bookings, 'title' ); $locations = self::options( $bookings, 'location_label' ); $statuses = self::options( $bookings, 'status_label', 'status' );
		self::table_start( 'lessons', __( 'Upcoming lesson filters', 'tutorhelper-parent-child' ), array(
			array( 'key' => 'status', 'label' => __( 'Status', 'tutorhelper-parent-child' ), 'all' => __( 'All statuses', 'tutorhelper-parent-child' ), 'options' => $statuses ),
			array( 'key' => 'type', 'label' => __( 'Lesson', 'tutorhelper-parent-child' ), 'all' => __( 'All lesson types', 'tutorhelper-parent-child' ), 'options' => $types ),
			array( 'key' => 'location', 'label' => __( 'Location', 'tutorhelper-parent-child' ), 'all' => __( 'All locations', 'tutorhelper-parent-child' ), 'options' => $locations ),
		) );
		?><div class="tutorhelper-pro-dashboard-table__scroll"><table><caption class="screen-reader-text"><?php esc_html_e( 'Upcoming lessons', 'tutorhelper-parent-child' ); ?></caption><thead><tr><?php self::sort_th( 'date', __( 'Date', 'tutorhelper-parent-child' ) ); self::sort_th( 'time', __( 'Time', 'tutorhelper-parent-child' ) ); self::sort_th( 'title', __( 'Lesson', 'tutorhelper-parent-child' ) ); self::sort_th( 'location', __( 'Location', 'tutorhelper-parent-child' ) ); self::sort_th( 'status', __( 'Status', 'tutorhelper-parent-child' ) ); ?><th scope="col"><?php esc_html_e( 'Details', 'tutorhelper-parent-child' ); ?></th><th scope="col"><?php esc_html_e( 'Actions', 'tutorhelper-parent-child' ); ?></th></tr></thead><tbody><tr class="tutorhelper-pro-dashboard-table__section-heading"><th colspan="7" scope="rowgroup"><?php esc_html_e( 'Upcoming Lessons', 'tutorhelper-parent-child' ); ?></th></tr>
		<?php foreach ( $bookings as $booking ) : self::lesson_row( $booking ); endforeach; self::empty_row( 7 ); ?>
		</tbody></table></div><?php self::table_end();
	}

	private static function attendance_table( $bookings, $records ) {
		$types = self::options( $bookings, 'title' );
		self::table_start( 'attendance', __( 'Attendance filters', 'tutorhelper-parent-child' ), array(
			array( 'key' => 'from', 'label' => __( 'From', 'tutorhelper-parent-child' ), 'type' => 'date' ), array( 'key' => 'to', 'label' => __( 'To', 'tutorhelper-parent-child' ), 'type' => 'date' ),
			array( 'key' => 'type', 'label' => __( 'Lesson', 'tutorhelper-parent-child' ), 'all' => __( 'All lesson types', 'tutorhelper-parent-child' ), 'options' => $types ),
			array( 'key' => 'status', 'label' => __( 'Attendance', 'tutorhelper-parent-child' ), 'all' => __( 'All statuses', 'tutorhelper-parent-child' ), 'options' => self::attendance_labels() ),
		) );
		?><div class="tutorhelper-pro-dashboard-table__scroll"><table><caption class="screen-reader-text"><?php esc_html_e( 'Past lesson attendance', 'tutorhelper-parent-child' ); ?></caption><thead><tr><?php self::sort_th( 'date', __( 'Date', 'tutorhelper-parent-child' ) ); self::sort_th( 'time', __( 'Time', 'tutorhelper-parent-child' ) ); self::sort_th( 'title', __( 'Lesson', 'tutorhelper-parent-child' ) ); self::sort_th( 'status', __( 'Attendance', 'tutorhelper-parent-child' ) ); ?></tr></thead><tbody><tr class="tutorhelper-pro-dashboard-table__section-heading"><th colspan="4" scope="rowgroup"><?php esc_html_e( 'Past Lessons', 'tutorhelper-parent-child' ); ?></th></tr>
		<?php foreach ( $bookings as $booking ) : self::attendance_row( $booking, $records ); endforeach; self::empty_row( 4 ); ?>
		</tbody></table></div><?php self::table_end();
	}

	private static function feedback_table( $bookings, $follow_ups ) {
		$types = self::options( $bookings, 'title' );
		self::table_start( 'feedback', __( 'Feedback and homework filters', 'tutorhelper-parent-child' ), array(
			array( 'key' => 'from', 'label' => __( 'From', 'tutorhelper-parent-child' ), 'type' => 'date' ), array( 'key' => 'to', 'label' => __( 'To', 'tutorhelper-parent-child' ), 'type' => 'date' ),
			array( 'key' => 'type', 'label' => __( 'Lesson', 'tutorhelper-parent-child' ), 'all' => __( 'All lesson types', 'tutorhelper-parent-child' ), 'options' => $types ),
			array( 'key' => 'content', 'label' => __( 'Content', 'tutorhelper-parent-child' ), 'all' => __( 'Feedback or homework', 'tutorhelper-parent-child' ), 'options' => array( 'feedback' => __( 'Has feedback', 'tutorhelper-parent-child' ), 'homework' => __( 'Has homework', 'tutorhelper-parent-child' ) ) ),
			array( 'key' => 'completion', 'label' => __( 'Homework status', 'tutorhelper-parent-child' ), 'all' => __( 'All homework statuses', 'tutorhelper-parent-child' ), 'options' => array( 'completed' => __( 'Completed', 'tutorhelper-parent-child' ), 'outstanding' => __( 'Outstanding', 'tutorhelper-parent-child' ) ) ),
		) );
		?><div class="tutorhelper-pro-dashboard-table__scroll"><table><caption class="screen-reader-text"><?php esc_html_e( 'Feedback and homework history', 'tutorhelper-parent-child' ); ?></caption><thead><tr><?php self::sort_th( 'date', __( 'Date', 'tutorhelper-parent-child' ) ); self::sort_th( 'title', __( 'Lesson', 'tutorhelper-parent-child' ) ); ?><th scope="col"><?php esc_html_e( 'Tutor Feedback', 'tutorhelper-parent-child' ); ?></th><th scope="col"><?php esc_html_e( 'Homework', 'tutorhelper-parent-child' ); ?></th><?php self::sort_th( 'due', __( 'Due', 'tutorhelper-parent-child' ) ); ?></tr></thead><tbody><tr class="tutorhelper-pro-dashboard-table__section-heading"><th colspan="5" scope="rowgroup"><?php esc_html_e( 'Feedback & Homework', 'tutorhelper-parent-child' ); ?></th></tr>
		<?php foreach ( $bookings as $booking ) : self::feedback_row( $booking, $follow_ups[ absint( $booking['id'] ) ] ); endforeach; self::empty_row( 5 ); ?>
		</tbody></table></div><?php self::table_end();
	}

	private static function lesson_row( $booking ) {
		$start = $booking['start']; $end = $booking['end']; $status = sanitize_key( $booking['status'] );
		ob_start();
		do_action( 'tutorhelper_parent_dashboard_booking_actions', $booking, 'upcoming' );
		$actions = trim( (string) ob_get_clean() );
		self::row_open( $booking, array( 'status' => $status, 'location' => sanitize_key( $booking['location_type'] ) ) ); ?>
		<td><i aria-hidden="true"></i><?php echo esc_html( wp_date( get_option( 'date_format' ), $start->getTimestamp(), $start->getTimezone() ) ); ?></td><td><?php echo esc_html( wp_date( get_option( 'time_format' ), $start->getTimestamp(), $start->getTimezone() ) . '–' . wp_date( get_option( 'time_format' ), $end->getTimestamp(), $end->getTimezone() ) ); ?></td><td><strong><?php echo esc_html( $booking['title'] ); ?></strong></td><td><?php echo esc_html( $booking['location_label'] ); ?></td><td><span class="tutorhelper-student-dashboard__status tutorhelper-student-dashboard__status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $booking['status_label'] ); ?></span></td><td><?php self::lesson_details( $booking ); ?></td><td><div class="tutorhelper-pro-dashboard-table__actions"><?php if ( $actions ) { echo wp_kses_post( $actions ); } else { ?><span class="tutorhelper-parent-report__future-action" aria-label="<?php esc_attr_e( 'Parent booking actions will be available in a later update.', 'tutorhelper-parent-child' ); ?>">—</span><?php } ?></div></td></tr><?php
	}

	private static function attendance_row( $booking, $records ) {
		$status = self::attendance_status( $booking, $records ); self::row_open( $booking, array( 'status' => $status['key'] ) ); $start = $booking['start']; ?>
		<td><i aria-hidden="true"></i><?php echo esc_html( wp_date( get_option( 'date_format' ), $start->getTimestamp(), $start->getTimezone() ) ); ?></td><td><?php echo esc_html( wp_date( get_option( 'time_format' ), $start->getTimestamp(), $start->getTimezone() ) ); ?></td><td><strong><?php echo esc_html( $booking['title'] ); ?></strong></td><td><span class="tutorhelper-parent-status is-<?php echo esc_attr( $status['key'] ); ?>"><?php echo esc_html( $status['icon'] . ' ' . $status['label'] ); ?></span></td></tr><?php
	}

	private static function feedback_row( $booking, $item ) {
		$content = trim( ( ! empty( $item['feedback'] ) ? 'feedback ' : '' ) . ( self::has_homework( $item ) ? 'homework' : '' ) );
		$completion = ! empty( $item['homework_completed'] ) ? 'completed' : ( ! empty( $item['is_outstanding'] ) ? 'outstanding' : '' );
		self::row_open( $booking, array( 'content' => $content, 'completion' => $completion, 'due' => (string) absint( $item['due_timestamp'] ) ) ); ?>
		<td><i aria-hidden="true"></i><?php echo esc_html( wp_date( get_option( 'date_format' ), $booking['start']->getTimestamp(), $booking['start']->getTimezone() ) ); ?></td><td><strong><?php echo esc_html( $booking['title'] ); ?></strong></td><td><?php echo $item['feedback'] ? wp_kses_post( wpautop( esc_html( $item['feedback'] ) ) ) : '<span aria-hidden="true">—</span>'; ?></td><td><?php self::homework_cell( $item ); ?></td><td><?php echo esc_html( $item['due_label'] ?: '—' ); ?></td></tr><?php
	}

	private static function table_start( $key, $label, $filters ) { ?>
		<div class="tutorhelper-pro-dashboard-table tutorhelper-parent-report-table" data-thpc-report="<?php echo esc_attr( $key ); ?>" data-page-size="<?php echo esc_attr( self::PAGE_SIZE ); ?>" data-default-sort="desc"><div class="tutorhelper-pro-dashboard-table__filters" aria-label="<?php echo esc_attr( $label ); ?>"><?php foreach ( $filters as $filter ) : ?><label><span><?php echo esc_html( $filter['label'] ); ?></span><?php if ( 'date' === ( $filter['type'] ?? '' ) ) : ?><input type="date" data-thpc-filter="<?php echo esc_attr( $filter['key'] ); ?>" /><?php else : ?><select data-thpc-filter="<?php echo esc_attr( $filter['key'] ); ?>"><option value=""><?php echo esc_html( $filter['all'] ); ?></option><?php foreach ( $filter['options'] as $value => $option ) : ?><option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $option ); ?></option><?php endforeach; ?></select><?php endif; ?></label><?php endforeach; ?><button type="button" class="tutorhelper-pro-dashboard-table__reset" data-thpc-reset><?php esc_html_e( 'Reset filters', 'tutorhelper-parent-child' ); ?></button></div><p data-thpc-count aria-live="polite"></p><?php
	}

	private static function table_end() { ?><nav class="tutorhelper-parent-pagination" aria-label="<?php esc_attr_e( 'Report pages', 'tutorhelper-parent-child' ); ?>" hidden><button type="button" data-thpc-previous><?php esc_html_e( 'Previous', 'tutorhelper-parent-child' ); ?></button><span data-thpc-page-status aria-live="polite"></span><button type="button" data-thpc-next><?php esc_html_e( 'Next', 'tutorhelper-parent-child' ); ?></button></nav></div><?php }
	private static function sort_th( $key, $label ) { ?><th scope="col" aria-sort="none"><button type="button" data-thpc-sort="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?> <span aria-hidden="true">↕</span></button></th><?php }
	private static function empty_row( $cols ) { ?><tr data-thpc-empty hidden><td colspan="<?php echo esc_attr( $cols ); ?>"><?php esc_html_e( 'No records match these filters.', 'tutorhelper-parent-child' ); ?></td></tr><?php }

	private static function row_open( $booking, $extra ) {
		$data = array( 'date' => $booking['start']->format( 'Y-m-d' ), 'time' => $booking['start']->format( 'Hi' ), 'title' => self::filter_value( $booking['title'] ), 'type' => self::filter_value( $booking['title'] ), 'location' => self::filter_value( $booking['location_label'] ) ) + $extra;
		?><tr class="tutorhelper-pro-dashboard-table__row" data-thpc-row style="--tutorhelper-booking-type-colour: <?php echo esc_attr( $booking['colour'] ); ?>;"<?php foreach ( $data as $key => $value ) { echo ' data-' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"'; } ?>><?php
	}

	private static function lesson_details( $booking ) {
		$joining = 'confirmed' === sanitize_key( $booking['status'] ) ? trim( (string) $booking['location_details'] ) : ''; $reason = trim( (string) $booking['cancellation_reason'] );
		if ( ! $joining && ! $reason ) { echo '<span aria-hidden="true">—</span>'; return; } ?>
		<details class="tutorhelper-pro-dashboard-table__details"><summary><span class="tutorhelper-pro-dashboard-table__details-label--closed"><?php esc_html_e( 'View details', 'tutorhelper-parent-child' ); ?></span><span class="tutorhelper-pro-dashboard-table__details-label--open"><?php esc_html_e( 'Hide details', 'tutorhelper-parent-child' ); ?></span></summary><div><?php if ( $joining ) : ?><strong><?php esc_html_e( 'How to join', 'tutorhelper-parent-child' ); ?></strong><?php echo wp_kses_post( wpautop( make_clickable( esc_html( $joining ) ) ) ); ?><?php endif; ?><?php if ( $reason ) : ?><strong><?php esc_html_e( 'Cancellation reason', 'tutorhelper-parent-child' ); ?></strong><p><?php echo esc_html( $reason ); ?></p><?php endif; ?></div></details><?php
	}

	private static function homework_cell( $item ) {
		if ( ! self::has_homework( $item ) ) { echo '<span aria-hidden="true">—</span>'; return; }
		if ( ! empty( $item['homework_completed'] ) ) {
			echo '<span class="tutorhelper-parent-homework-status is-completed">' . esc_html__( 'Completed', 'tutorhelper-parent-child' ) . '</span>';
		} elseif ( ! empty( $item['is_outstanding'] ) ) {
			echo '<span class="tutorhelper-parent-homework-status is-outstanding">' . esc_html__( 'Outstanding', 'tutorhelper-parent-child' ) . '</span>';
		}
		if ( $item['homework_title'] ) { echo '<strong>' . esc_html( $item['homework_title'] ) . '</strong>'; }
		if ( $item['instructions'] ) { echo wp_kses_post( wpautop( esc_html( $item['instructions'] ) ) ); }
		echo '<p class="tutorhelper-follow-up-card__links">'; if ( $item['homework_url'] ) { echo '<a href="' . esc_url( $item['homework_url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Open link', 'tutorhelper-parent-child' ) . '</a>'; } if ( $item['attachment_url'] ) { echo '<a href="' . esc_url( $item['attachment_url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $item['attachment_label'] ?: __( 'Download file', 'tutorhelper-parent-child' ) ) . '</a>'; } echo '</p>';
	}

	private static function attendance_chart( $counts ) {
		$total = array_sum( $counts ); $gradient = self::pie_gradient( $counts, max( 1, $total ) ); ?>
		<figure class="tutorhelper-attendance-pie"><div class="tutorhelper-attendance-pie__chart" role="img" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: Total number of past lessons. */ __( 'Attendance across %d past lessons', 'tutorhelper-parent-child' ), $total ) ); ?>" style="background: <?php echo esc_attr( $gradient ); ?>;"><span><?php echo esc_html( $total ); ?><small><?php esc_html_e( 'lessons', 'tutorhelper-parent-child' ); ?></small></span></div><figcaption><h5><?php esc_html_e( 'Attendance totals', 'tutorhelper-parent-child' ); ?></h5><ul><?php foreach ( self::attendance_labels() as $key => $label ) : ?><li class="is-<?php echo esc_attr( $key ); ?>"><i aria-hidden="true"></i><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( $counts[ $key ] ); ?></strong></li><?php endforeach; ?></ul></figcaption></figure><?php
	}

	private static function pie_gradient( $counts, $total ) { $colours = array( 'attended' => '#2f8f57', 'late' => '#d39a15', 'missed' => '#c84b4b', 'info_only' => '#7357a3', 'not_recorded' => '#9baab0', 'cancelled' => '#56656b' ); $parts = array(); $start = 0; foreach ( $colours as $key => $colour ) { $end = $start + ( ( $counts[ $key ] / $total ) * 360 ); $parts[] = $colour . ' ' . round( $start, 2 ) . 'deg ' . round( $end, 2 ) . 'deg'; $start = $end; } return 'conic-gradient(' . implode( ', ', $parts ) . ')'; }
	private static function attendance_status( $booking, $records ) { if ( 'cancelled' === sanitize_key( $booking['status'] ) ) { return array( 'key' => 'cancelled', 'label' => __( 'Cancelled', 'tutorhelper-parent-child' ), 'icon' => '✖️' ); } $record = $records[ absint( $booking['id'] ) ] ?? array( 'status' => 'not_recorded', 'label' => __( 'Not recorded', 'tutorhelper-parent-child' ), 'icon' => '📅' ); return array( 'key' => $record['status'], 'label' => $record['label'], 'icon' => $record['icon'] ); }
	private static function attendance_labels() { return array( 'attended' => __( 'Attended', 'tutorhelper-parent-child' ), 'late' => __( 'Late', 'tutorhelper-parent-child' ), 'missed' => __( 'Missed', 'tutorhelper-parent-child' ), 'info_only' => __( 'Information only', 'tutorhelper-parent-child' ), 'not_recorded' => __( 'Not recorded', 'tutorhelper-parent-child' ), 'cancelled' => __( 'Cancelled', 'tutorhelper-parent-child' ) ); }
	private static function booking_totals( $bookings ) { $totals = array( 'confirmed' => 0, 'pending' => 0, 'cancelled' => 0 ); foreach ( $bookings as $booking ) { $status = sanitize_key( $booking['status'] ); if ( isset( $totals[ $status ] ) ) { ++$totals[ $status ]; } } return $totals; }
	private static function options( $bookings, $label_key, $value_key = '' ) { $values = array(); foreach ( $bookings as $booking ) { $label = sanitize_text_field( $booking[ $label_key ] ?? '' ); $value = $value_key ? sanitize_key( $booking[ $value_key ] ?? '' ) : self::filter_value( $label ); if ( $label && $value ) { $values[ $value ] = $label; } } natcasesort( $values ); return $values; }
	private static function summary_card( $label, $value, $detail, $icon = 'chart-bar', $tone = 'navy' ) { ?><article class="tutorhelper-parent-summary-card is-<?php echo esc_attr( sanitize_key( $tone ) ); ?>"><span class="tutorhelper-parent-summary-card__icon dashicons dashicons-<?php echo esc_attr( sanitize_key( $icon ) ); ?>" aria-hidden="true"></span><div class="tutorhelper-parent-summary-card__content"><span class="tutorhelper-parent-summary-card__label"><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( $value ); ?></strong><?php if ( $detail ) : ?><p><?php echo esc_html( $detail ); ?></p><?php endif; ?></div></article><?php }
	private static function heading( $title, $description ) { ?><div class="tutorhelper-parent-report__intro"><h4><?php echo esc_html( $title ); ?></h4><p><?php echo esc_html( $description ); ?></p></div><?php }
	private static function has_homework( $item ) { return ! empty( $item['homework_title'] ) || ! empty( $item['instructions'] ) || ! empty( $item['homework_url'] ) || ! empty( $item['attachment_url'] ); }
	private static function filter_value( $value ) { return sanitize_title( remove_accents( (string) $value ) ); }
	private static function date_time( $booking ) { return wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), $booking['start']->getTimestamp(), $booking['start']->getTimezone() ); }
}
