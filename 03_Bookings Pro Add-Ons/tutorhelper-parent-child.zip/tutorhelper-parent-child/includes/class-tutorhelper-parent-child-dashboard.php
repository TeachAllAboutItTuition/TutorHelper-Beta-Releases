<?php
/** Role-aware dashboard and relationship-specific language. @package TutorHelper_Parent_Child */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_Parent_Child_Dashboard {
	const CHILD_ARG = 'tutorhelper_child';
	const SECTION_ARG = 'tutorhelper_parent_section';
	const NONCE_ARG = '_tutorhelper_parent_nonce';
	const COOKIE = 'tutorhelper_parent_selected_child';
	const NONCE_ACTION = 'tutorhelper_parent_dashboard_navigation';

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'remember_requested_child' ) );
		add_action( 'template_redirect', array( __CLASS__, 'prevent_payment_return_caching' ) );
		add_shortcode( TutorHelper_Student_Dashboard_Shortcode::SHORTCODE, array( __CLASS__, 'render_dashboard' ) );
		add_shortcode( TutorHelper_Student_Sidebar_Shortcode::SHORTCODE, array( __CLASS__, 'render_sidebar' ) );
		add_filter( 'tutorhelper_student_booking_context', array( __CLASS__, 'filter_booking_context' ), 10, 3 );
		add_filter( 'tutorhelper_pro_student_payment_return_authorised', array( __CLASS__, 'authorise_payment_return' ), 10, 3 );
	}

	/**
	 * Authorise a selected linked child as a delegated Core booking context.
	 *
	 * @param array $context              Core booking context.
	 * @param int   $viewer_user_id       Logged-in account ID.
	 * @param int   $requested_student_id Requested child ID.
	 * @return array
	 */
	public static function filter_booking_context(
		$context,
		$viewer_user_id,
		$requested_student_id
	) {
		$student_user_id = $requested_student_id
			? absint( $requested_student_id )
			: self::requested_child();

		if (
			! self::is_parent_account()
			|| absint( get_current_user_id() ) !== absint( $viewer_user_id )
			|| ! $student_user_id
		) {
			return $context;
		}

		if (
			! TutorHelper_Student_Parent_Links::is_linked(
				$viewer_user_id,
				$student_user_id
			)
		) {
			if ( class_exists( 'TutorHelper_Logger' ) ) {
				TutorHelper_Logger::warning(
					'Parent booking context was rejected.',
					array(
						'parent_user_id' => absint( $viewer_user_id ),
						'student_user_id' => absint( $student_user_id ),
					)
				);
			}

			return $context;
		}

		return array(
			'student_user_id' => absint( $student_user_id ),
			'mode'            => 'parent',
			'is_authorised'   => true,
		);
	}

	/**
	 * Allow a linked Parent Account to complete a signed payment return for
	 * the child whose booking started the Checkout Session.
	 *
	 * @param bool   $authorised     Existing authorisation decision.
	 * @param object $booking        Booking record.
	 * @param int    $viewer_user_id Current WordPress user ID.
	 * @return bool
	 */
	public static function authorise_payment_return(
		$authorised,
		$booking,
		$viewer_user_id
	) {
		if ( $authorised || ! is_object( $booking ) ) {
			return (bool) $authorised;
		}

		$viewer_user_id = absint( $viewer_user_id );
		$student_user_id = isset( $booking->student_user_id )
			? absint( $booking->student_user_id )
			: 0;

		return $viewer_user_id
			&& $student_user_id
			&& self::is_parent_account()
			&& TutorHelper_Student_Parent_Links::is_linked(
				$viewer_user_id,
				$student_user_id
			);
	}

	public static function render_dashboard() {
		// A Stripe return can arrive without the parent's WordPress session (notably
		// after an Apple Pay app/browser hand-off). Never send that visitor into a
		// protected dashboard route which would produce a 403 page.
		if ( self::is_payment_return() && ! self::is_parent_account() ) {
			return self::render_payment_sign_in();
		}
		if ( ! self::is_parent_account() ) { return TutorHelper_Student_Dashboard_Shortcode::render(); }
		TutorHelper_Student_Dashboard_Frontend::enqueue_assets();
		if ( class_exists( 'TutorHelper_Student_Booking_Frontend' ) ) {
			TutorHelper_Student_Booking_Frontend::enqueue_assets();
		}
		TutorHelper_Parent_Child_Assets::enqueue_dashboard_assets();
		$parent = wp_get_current_user();
		$children = TutorHelper_Student_Parent_Links::get_students( $parent->ID );
		if ( empty( $children ) ) { return self::render_empty( $parent ); }
		$requested = self::requested_child();
		$relationship = self::selected_relationship( $parent->ID, $children );
		$child_id = $relationship ? absint( $relationship->student_user_id ) : 0;
		$child = $child_id ? get_userdata( $child_id ) : null;
		$section = self::section();
		if ( ! $child instanceof WP_User || ! TutorHelper_Student_Parent_Links::is_linked( $parent->ID, $child_id ) ) { return self::render_empty( $parent ); }
		$relationship_label = self::relationship_label( $relationship );
		$title_label = self::relationship_title( $relationship_label );
		ob_start(); ?>
		<section class="tutorhelper-student-dashboard tutorhelper-parent-dashboard tutorhelper-parent-child" data-tutorhelper-parent-dashboard data-student-user-id="<?php echo esc_attr( $child_id ); ?>">
			<?php if ( $requested && $requested !== $child_id ) : ?><div class="tutorhelper-student-dashboard__notice tutorhelper-student-dashboard__notice--error" role="alert"><?php esc_html_e( 'That student is not linked to your account. Your selection has not been changed.', 'tutorhelper-parent-child' ); ?></div><?php endif; ?>
			<header class="tutorhelper-student-dashboard__header tutorhelper-parent-dashboard__header">
				<p class="tutorhelper-student-dashboard__eyebrow"><?php echo esc_html( sprintf( /* translators: %s: Relationship title, such as Parent or School Teacher. */ __( '%s dashboard', 'tutorhelper-parent-child' ), $title_label ) ); ?></p>
				<h2 class="tutorhelper-student-dashboard__heading"><?php echo esc_html( sprintf( /* translators: %s: Relationship title, such as Parent or School Teacher. */ __( '%s Dashboard', 'tutorhelper-parent-child' ), $title_label ) ); ?></h2>
				<p class="tutorhelper-student-dashboard__introduction"><?php printf( /* translators: %s: Parent or guardian first name. */ esc_html__( 'Welcome, %s. Choose a student to view their lessons and learning information.', 'tutorhelper-parent-child' ), esc_html( self::first_name( $parent ) ) ); ?></p>

			</header>

			<section class="tutorhelper-parent-dashboard__children" aria-labelledby="thpc-students-heading">
				<h3 id="thpc-students-heading"><?php esc_html_e( 'Linked students', 'tutorhelper-parent-child' ); ?></h3>
				<div class="tutorhelper-parent-dashboard__child-cards">
				<?php foreach ( $children as $item ) : $id = absint( $item->student_user_id ); $selected = $id === $child_id; ?>
					<a class="tutorhelper-parent-dashboard__child-card<?php echo $selected ? ' is-selected' : ''; ?>" href="<?php echo esc_url( self::url( $id, $section ) ); ?>"<?php echo $selected ? ' aria-current="true"' : ''; ?>>
						<span class="tutorhelper-parent-dashboard__avatar" aria-hidden="true"><?php echo esc_html( self::initials( $item->display_name ) ); ?></span>
						<span><strong><?php echo esc_html( $item->display_name ); ?></strong><small><?php echo esc_html( self::relationship_label( $item ) ); ?></small></span>
						<?php if ( $selected ) : ?><span class="tutorhelper-parent-dashboard__badge"><?php esc_html_e( 'Selected', 'tutorhelper-parent-child' ); ?></span><?php endif; ?>
					</a>
				<?php endforeach; ?>
				</div>
			</section>

			<nav class="tutorhelper-parent-dashboard__nav" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: Relationship title, such as Parent or School Teacher. */ __( '%s dashboard', 'tutorhelper-parent-child' ), $title_label ) ); ?>"><ul>
			<?php foreach ( self::sections() as $key => $label ) : ?><li><a href="<?php echo esc_url( self::url( $child_id, $key ) ); ?>"<?php echo $key === $section ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a></li><?php endforeach; ?>
			</ul></nav>

			<div class="tutorhelper-parent-dashboard__content">
				<header class="tutorhelper-parent-dashboard__content-header"><p><?php esc_html_e( 'Viewing', 'tutorhelper-parent-child' ); ?></p><h3><?php echo esc_html( $child->display_name ); ?></h3></header>
				<?php self::render_section( $section, $child ); ?>
			</div>
		</section>
		<?php return ob_get_clean();
	}

	public static function render_sidebar() {
		if ( ! self::is_parent_account() ) { return TutorHelper_Student_Sidebar_Shortcode::render(); }
		TutorHelper_Student_Dashboard_Frontend::enqueue_sidebar_assets();
		TutorHelper_Parent_Child_Assets::enqueue_dashboard_assets();
		$account = wp_get_current_user();
		$children = TutorHelper_Student_Parent_Links::get_students( $account->ID );
		$relationship = self::selected_relationship( $account->ID, $children );
		$selected = $relationship ? absint( $relationship->student_user_id ) : 0;
		$label = self::relationship_label( $relationship );
		$dashboard_url = TutorHelper_Settings::get_student_dashboard_url();
		ob_start(); ?>
		<aside class="tutorhelper-student-sidebar tutorhelper-parent-sidebar tutorhelper-parent-child">
			<p class="tutorhelper-student-sidebar__eyebrow"><?php esc_html_e( 'Welcome back', 'tutorhelper-parent-child' ); ?></p>
			<h2 class="tutorhelper-student-sidebar__heading"><?php printf( /* translators: %s: Parent or guardian first name. */ esc_html__( 'Hi %s!', 'tutorhelper-parent-child' ), esc_html( self::first_name( $account ) ) ); ?></h2>
			<div class="tutorhelper-parent-sidebar__children"><strong><?php esc_html_e( 'Linked students', 'tutorhelper-parent-child' ); ?></strong>
			<?php if ( empty( $children ) ) : ?><p><?php esc_html_e( 'No students are currently linked to this account.', 'tutorhelper-parent-child' ); ?></p><?php else : ?><ul><?php foreach ( $children as $item ) : ?><li<?php echo absint( $item->student_user_id ) === $selected ? ' class="is-selected"' : ''; ?>><?php echo esc_html( $item->display_name ); ?><?php if ( absint( $item->student_user_id ) === $selected ) : ?><span class="screen-reader-text"><?php esc_html_e( '(selected)', 'tutorhelper-parent-child' ); ?></span><?php endif; ?></li><?php endforeach; ?></ul><?php endif; ?></div>
			<a class="tutorhelper-student-sidebar__button" href="<?php echo esc_url( $dashboard_url ? $dashboard_url : home_url( '/' ) ); ?>"><?php echo esc_html( sprintf( /* translators: %s: Relationship label, such as parent or school teacher. */ __( 'Open %s dashboard', 'tutorhelper-parent-child' ), $label ) ); ?></a>
			<a class="tutorhelper-student-sidebar__logout" href="<?php echo esc_url( wp_logout_url( TutorHelper_Settings::get_login_url() ) ); ?>"><?php esc_html_e( 'Log out', 'tutorhelper-parent-child' ); ?></a>
		</aside>
		<?php return ob_get_clean();
	}

	/**
	 * Stop a cache or CDN re-serving a payment-return page with an old finance table.
	 *
	 * This does not confirm a payment: the verified Stripe webhook remains the
	 * only authority for payment and lesson-status changes.
	 */
	public static function prevent_payment_return_caching() {
		if ( self::is_payment_return() ) {
			nocache_headers();
		}
	}

	/** Return whether this dashboard request was sent back from Stripe Checkout. */
	private static function is_payment_return() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Reads only a return-state marker.
		$payment = isset( $_GET['tutorhelper_parent_payment'] ) && ! is_array( $_GET['tutorhelper_parent_payment'] ) ? sanitize_key( wp_unslash( $_GET['tutorhelper_parent_payment'] ) ) : '';
		$legacy = isset( $_GET['payment_request'] ) && ! is_array( $_GET['payment_request'] ) ? sanitize_key( wp_unslash( $_GET['payment_request'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		return in_array( $payment, array( 'success', 'cancelled' ), true ) || in_array( $legacy, array( 'success', 'cancelled' ), true );
	}

	/**
	 * Render a safe return state when a payment browser is not logged into WordPress.
	 *
	 * No child, lesson, payment amount or payment state is shown here. The link
	 * simply returns the parent to their normal dashboard, where usual access
	 * controls and the webhook-refreshed Finance table apply.
	 */
	private static function render_payment_sign_in() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Uses only safe route values for the post-login destination.
		$child_id = self::requested_child();
		$payment = isset( $_GET['tutorhelper_parent_payment'] ) && ! is_array( $_GET['tutorhelper_parent_payment'] ) ? sanitize_key( wp_unslash( $_GET['tutorhelper_parent_payment'] ) ) : 'success';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$base = TutorHelper_Settings::get_student_dashboard_url();
		$destination = add_query_arg( array( self::SECTION_ARG => 'finance', 'tutorhelper_parent_payment' => in_array( $payment, array( 'success', 'cancelled' ), true ) ? $payment : 'success' ), $base ? $base : home_url( '/' ) );
		if ( $child_id ) { $destination = add_query_arg( self::CHILD_ARG, $child_id, $destination ); }
		$login = TutorHelper_Settings::get_login_url();
		$login_url = $login ? add_query_arg( 'redirect_to', $destination, $login ) : wp_login_url( $destination );
		ob_start(); ?>
		<section class="tutorhelper-student-dashboard tutorhelper-parent-dashboard tutorhelper-parent-child tutorhelper-parent-dashboard--empty">
			<header class="tutorhelper-student-dashboard__header">
				<p class="tutorhelper-student-dashboard__eyebrow"><?php esc_html_e( 'Payment received', 'tutorhelper-parent-child' ); ?></p>
				<h2 class="tutorhelper-student-dashboard__heading"><?php esc_html_e( 'Your payment was successful', 'tutorhelper-parent-child' ); ?></h2>
				<p class="tutorhelper-student-dashboard__introduction"><?php esc_html_e( 'Stripe has received your payment. Sign in to view your updated lesson payment details.', 'tutorhelper-parent-child' ); ?></p>
			</header>
			<p><a class="tutorhelper-student-sidebar__button" href="<?php echo esc_url( $login_url ); ?>"><?php esc_html_e( 'Sign in to your Parent Dashboard', 'tutorhelper-parent-child' ); ?></a></p>
		</section>
		<?php return ob_get_clean();
	}

	public static function remember_requested_child() {
		if ( ! self::is_parent_account() || headers_sent() ) { return; }
		$child_id = self::requested_child();
		$nonce = isset( $_GET[ self::NONCE_ARG ] ) && ! is_array( $_GET[ self::NONCE_ARG ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::NONCE_ARG ] ) ) : '';
		$account_id = get_current_user_id();
		if ( ! $child_id || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) || ! TutorHelper_Student_Parent_Links::is_linked( $account_id, $child_id ) ) { return; }
		setcookie( self::COOKIE, self::cookie_value( $account_id, $child_id ), array( 'expires' => 0, 'path' => COOKIEPATH ? COOKIEPATH : '/', 'domain' => COOKIE_DOMAIN, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
	}

	/** Hidden route fields used by read-only report filters. */
	public static function render_route_fields( $section ) {
		$relationship = self::selected_relationship( get_current_user_id(), TutorHelper_Student_Parent_Links::get_students( get_current_user_id() ) );
		$child_id = $relationship ? absint( $relationship->student_user_id ) : 0;
		?><input type="hidden" name="<?php echo esc_attr( self::CHILD_ARG ); ?>" value="<?php echo esc_attr( $child_id ); ?>" /><input type="hidden" name="<?php echo esc_attr( self::SECTION_ARG ); ?>" value="<?php echo esc_attr( $section ); ?>" /><input type="hidden" name="<?php echo esc_attr( self::NONCE_ARG ); ?>" value="<?php echo esc_attr( wp_create_nonce( self::NONCE_ACTION ) ); ?>" /><?php
	}

	private static function render_section( $section, $child ) {
		if ( 'book' === $section ) {
			self::render_booking_section( $child );
			return;
		}

		if ( TutorHelper_Parent_Child_Reports::render( $section, $child ) ) {
			return;
		}

		if ( apply_filters( 'tutorhelper_parent_dashboard_section_rendered', false, $section, $child ) ) {
			return;
		}

		$text = 'finance' === $section
			? __( 'Payments, balances, credits and refunds will appear here.', 'tutorhelper-parent-child' )
			: __( 'This information will be available here.', 'tutorhelper-parent-child' );
		?>
		<div class="tutorhelper-parent-report__empty">
			<h4><?php echo esc_html( self::sections()[ $section ] ); ?></h4>
			<p><?php echo esc_html( $text ); ?></p>
		</div>
		<?php
	}

	/**
	 * Render Core's booking form in the selected child's dashboard section.
	 *
	 * @param WP_User $child Selected linked student.
	 * @return void
	 */
	private static function render_booking_section( $child ) {
		if (
			! $child instanceof WP_User
			|| ! shortcode_exists( TutorHelper_Student_Booking_Shortcode::SHORTCODE )
		) {
			?>
			<div class="tutorhelper-parent-report__empty" role="status">
				<h4><?php esc_html_e( 'Booking is currently unavailable', 'tutorhelper-parent-child' ); ?></h4>
				<p><?php esc_html_e( 'Please contact your tutor if you need help arranging a lesson.', 'tutorhelper-parent-child' ); ?></p>
			</div>
			<?php
			return;
		}

		?>
		<section class="tutorhelper-parent-dashboard__booking" aria-labelledby="tutorhelper-parent-booking-heading">
			<header class="tutorhelper-parent-dashboard__booking-header">
				<p><?php esc_html_e( 'Booking for', 'tutorhelper-parent-child' ); ?></p>
				<h4 id="tutorhelper-parent-booking-heading"><?php echo esc_html( $child->display_name ); ?></h4>
			</header>
			<?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core shortcode output is escaped by its renderer.
			echo do_shortcode( '[' . TutorHelper_Student_Booking_Shortcode::SHORTCODE . ']' ); ?>
		</section>
		<?php
	}

	private static function render_empty( $account ) {
		TutorHelper_Parent_Child_Assets::enqueue_dashboard_assets();
		$label = self::relationship_title( self::relationship_label( null ) );
		ob_start(); ?>
		<section class="tutorhelper-student-dashboard tutorhelper-parent-dashboard tutorhelper-parent-child tutorhelper-parent-dashboard--empty"><header class="tutorhelper-student-dashboard__header"><p class="tutorhelper-student-dashboard__eyebrow"><?php echo esc_html( sprintf( /* translators: %s: Relationship title, such as Parent or School Teacher. */ __( '%s dashboard', 'tutorhelper-parent-child' ), $label ) ); ?></p><h2 class="tutorhelper-student-dashboard__heading"><?php echo esc_html( sprintf( /* translators: %s: Relationship title, such as Parent or School Teacher. */ __( '%s Dashboard', 'tutorhelper-parent-child' ), $label ) ); ?></h2><p class="tutorhelper-student-dashboard__introduction"><?php printf( /* translators: %s: Parent or guardian first name. */ esc_html__( 'Welcome, %s.', 'tutorhelper-parent-child' ), esc_html( self::first_name( $account ) ) ); ?></p></header><div class="tutorhelper-parent-report__empty" role="status"><h3><?php esc_html_e( 'No students are linked yet', 'tutorhelper-parent-child' ); ?></h3><p><?php esc_html_e( 'Your tutor needs to link this account to a student before tuition information can be shown here. Please contact your tutor if you expected to see a student.', 'tutorhelper-parent-child' ); ?></p></div></section>
		<?php return ob_get_clean();
	}

	private static function selected_relationship( $account_id, $children ) {
		$requested = self::requested_child();
		if ( $requested && TutorHelper_Student_Parent_Links::is_linked( $account_id, $requested ) ) { return self::find_relationship( $children, $requested ); }
		$remembered = self::remembered_child( $account_id );
		if ( $remembered && TutorHelper_Student_Parent_Links::is_linked( $account_id, $remembered ) ) { return self::find_relationship( $children, $remembered ); }
		return empty( $children ) ? null : $children[0];
	}
	private static function find_relationship( $children, $student_id ) { foreach ( $children as $item ) { if ( absint( $item->student_user_id ) === absint( $student_id ) ) { return $item; } } return null; }
	private static function relationship_label( $relationship ) { $label = $relationship && isset( $relationship->relationship_label ) ? trim( sanitize_text_field( $relationship->relationship_label ) ) : ''; return '' !== $label ? $label : __( 'Parent/Guardian', 'tutorhelper-parent-child' ); }
	private static function relationship_title( $label ) { return 'Parent/Guardian' === $label ? $label : ucwords( strtolower( $label ) ); }
	private static function sections() {
		return apply_filters(
			'tutorhelper_parent_child_dashboard_sections',
			array(
				'overview'   => __( 'Overview', 'tutorhelper-parent-child' ),
				'lessons'    => __( 'Lessons', 'tutorhelper-parent-child' ),
				'attendance' => __( 'Attendance', 'tutorhelper-parent-child' ),
				'feedback'   => __( 'Feedback & Homework', 'tutorhelper-parent-child' ),
				'finance'    => __( 'Finance', 'tutorhelper-parent-child' ),
				'book'       => __( 'Book a Lesson', 'tutorhelper-parent-child' ),
			)
		);
	}
	private static function requested_child() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only student selection; ownership is verified before display or cookie storage.
		$child_id = isset( $_GET[ self::CHILD_ARG ] ) && ! is_array( $_GET[ self::CHILD_ARG ] ) ? absint( $_GET[ self::CHILD_ARG ] ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		return $child_id;
	}
	private static function remembered_child( $account_id ) { if ( empty( $_COOKIE[ self::COOKIE ] ) || is_array( $_COOKIE[ self::COOKIE ] ) ) { return 0; } $parts = explode( '|', sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ), 2 ); if ( 2 !== count( $parts ) ) { return 0; } $child_id = absint( $parts[0] ); $expected = hash_hmac( 'sha256', $account_id . '|' . $child_id, wp_salt( 'auth' ) ); return hash_equals( $expected, $parts[1] ) ? $child_id : 0; }
	private static function cookie_value( $account_id, $child_id ) { return absint( $child_id ) . '|' . hash_hmac( 'sha256', $account_id . '|' . $child_id, wp_salt( 'auth' ) ); }
	private static function section() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only dashboard navigation; no state is changed.
		$key = isset( $_GET[ self::SECTION_ARG ] ) && ! is_array( $_GET[ self::SECTION_ARG ] ) ? sanitize_key( wp_unslash( $_GET[ self::SECTION_ARG ] ) ) : 'overview';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		return isset( self::sections()[ $key ] ) ? $key : 'overview';
	}
	private static function url( $child_id, $section ) { $base = TutorHelper_Settings::get_student_dashboard_url(); return add_query_arg( array( self::CHILD_ARG => absint( $child_id ), self::SECTION_ARG => isset( self::sections()[ $section ] ) ? $section : 'overview', self::NONCE_ARG => wp_create_nonce( self::NONCE_ACTION ) ), $base ? $base : home_url( '/' ) ); }
	private static function is_parent_account() { return is_user_logged_in() && in_array( TutorHelper_Roles::PARENT_ROLE, (array) wp_get_current_user()->roles, true ); }
	private static function first_name( $user ) { return ! empty( $user->first_name ) ? $user->first_name : $user->display_name; }
	private static function initials( $name ) { $words = array_slice( array_filter( preg_split( '/\s+/', trim( (string) $name ) ) ), 0, 2 ); $value = ''; foreach ( $words as $word ) { $value .= function_exists( 'mb_substr' ) ? mb_substr( $word, 0, 1 ) : substr( $word, 0, 1 ); } return strtoupper( $value ); }
}
