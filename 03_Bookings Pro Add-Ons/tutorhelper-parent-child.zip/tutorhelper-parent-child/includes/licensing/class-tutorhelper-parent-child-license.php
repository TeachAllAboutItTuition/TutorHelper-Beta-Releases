<?php
/**
 * TutorHelper Parent & Child licence state.
 *
 * @package TutorHelper_Parent_Child_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Manages the locally cached Parent & Child licence. */
final class TutorHelper_Parent_Child_License {
	const KEY_OPTION = 'tutorhelper_parent_child_license_key';
	const STATUS_OPTION = 'tutorhelper_parent_child_license_status';
	const INSTANCE_OPTION = 'tutorhelper_parent_child_instance_id';
	const TOKEN_OPTION = 'tutorhelper_parent_child_license_token';
	const EXPIRES_OPTION = 'tutorhelper_parent_child_license_expires';
	const LIFETIME_OPTION = 'tutorhelper_parent_child_license_lifetime';
	const LAST_CHECK_OPTION = 'tutorhelper_parent_child_license_last_check';

	public static function get_key() {
		return (string) get_option( self::KEY_OPTION, '' );
	}

	public static function set_key( $license_key ) {
		$license_key = trim( sanitize_text_field( $license_key ) );
		update_option( self::KEY_OPTION, $license_key, false );
		return hash_equals( $license_key, self::get_key() );
	}

	public static function get_token() {
		return (string) get_option( self::TOKEN_OPTION, '' );
	}

	public static function get_status() {
		return sanitize_key( get_option( self::STATUS_OPTION, 'inactive' ) );
	}

	public static function get_expires() {
		return sanitize_text_field( get_option( self::EXPIRES_OPTION, '' ) );
	}

	public static function is_lifetime() {
		return (bool) get_option( self::LIFETIME_OPTION, false );
	}

	public static function get_instance_id() {
		$instance_id = (string) get_option( self::INSTANCE_OPTION, '' );
		if ( '' === $instance_id ) {
			$instance_id = wp_generate_uuid4();
			update_option( self::INSTANCE_OPTION, $instance_id, false );
		}
		return $instance_id;
	}

	public static function set_status( $status ) {
		$status = sanitize_key( $status );
		if ( ! in_array( $status, array( 'inactive', 'active', 'expired', 'invalid' ), true ) ) {
			$status = 'invalid';
		}
		update_option( self::STATUS_OPTION, $status, false );
	}

	public static function store_activation( $license_key, $response ) {
		self::set_key( $license_key );
		update_option( self::TOKEN_OPTION, sanitize_text_field( $response['activation_token'] ?? '' ), false );
		self::store_metadata( $response );
		self::set_status( 'active' );
	}

	public static function store_validation( $response ) {
		self::store_metadata( $response );
		self::set_status( 'active' );
	}

	private static function store_metadata( $response ) {
		$has_lifetime = array_key_exists( 'lifetime', $response ) || array_key_exists( 'is_lifetime', $response );
		$lifetime = ! empty( $response['lifetime'] ) || ! empty( $response['is_lifetime'] );
		$type = sanitize_key( $response['license_type'] ?? ( $response['licence_type'] ?? '' ) );
		if ( in_array( $type, array( 'lifetime', 'perpetual', 'indefinite' ), true ) ) {
			$has_lifetime = true;
			$lifetime = true;
		}

		$expires = '';
		$has_expiry = false;
		foreach ( array( 'expires_at', 'expiresAt', 'expires_on', 'date_expires', 'valid_until' ) as $field ) {
			if ( array_key_exists( $field, $response ) ) {
				$has_expiry = true;
				$expires = is_scalar( $response[ $field ] ) ? sanitize_text_field( (string) $response[ $field ] ) : '';
				break;
			}
		}

		if ( $has_expiry && ( '' === $expires || 0 === strpos( $expires, '0000-00-00' ) ) ) {
			$has_lifetime = true;
			$lifetime = true;
		}
		if ( $has_lifetime || $has_expiry ) {
			update_option( self::LIFETIME_OPTION, $lifetime ? 1 : 0, false );
			update_option( self::EXPIRES_OPTION, $lifetime ? '' : $expires, false );
		}
		update_option( self::LAST_CHECK_OPTION, time(), false );
	}

	public static function deactivate_local() {
		delete_option( self::TOKEN_OPTION );
		self::set_status( 'inactive' );
	}

	public static function remove_key() {
		delete_option( self::KEY_OPTION );
		delete_option( self::TOKEN_OPTION );
		delete_option( self::STATUS_OPTION );
		delete_option( self::EXPIRES_OPTION );
		delete_option( self::LIFETIME_OPTION );
		delete_option( self::LAST_CHECK_OPTION );
		return '' === self::get_key();
	}

	public static function is_active() {
		if ( 'active' !== self::get_status() ) {
			return false;
		}
		if ( self::is_lifetime() ) {
			return true;
		}
		$expires = self::expiry_timestamp();
		if ( $expires && $expires < time() ) {
			self::set_status( 'expired' );
			return false;
		}
		return true;
	}

	public static function expiry_timestamp() {
		$expires = self::get_expires();
		return '' === $expires ? 0 : (int) strtotime( $expires );
	}

	public static function days_until_expiry() {
		$expires = self::expiry_timestamp();
		return $expires ? (int) ceil( ( $expires - time() ) / DAY_IN_SECONDS ) : null;
	}
}
