<?php
/** TutorHelper Parent & Child licence API client. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_Parent_Child_License_API {
	const API_URL = 'https://tutorhelper.co.uk/wp-json/tutorhelper-license/v1/';
	const PRODUCT_SLUG = 'tutorhelper-parent-child';

	private static function request( $endpoint, $body ) {
		$response = wp_remote_post(
			trailingslashit( self::API_URL ) . ltrim( $endpoint, '/' ),
			array(
				'timeout' => 15,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body' => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $response ) ) { return $response; }
		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code >= 300 ) {
			$message = is_array( $data ) && ! empty( $data['message'] ) ? sanitize_text_field( $data['message'] ) : __( 'The licence server returned an error.', 'tutorhelper-parent-child' );
			return new WP_Error( 'tutorhelper_parent_child_license_api_error', $message, array( 'status' => $code ) );
		}
		return is_array( $data ) ? $data : new WP_Error( 'tutorhelper_parent_child_license_invalid_response', __( 'The licence server returned an invalid response.', 'tutorhelper-parent-child' ) );
	}

	private static function data( $license_key ) {
		return array(
			'license_key' => sanitize_text_field( $license_key ),
			'instance_id' => TutorHelper_Parent_Child_License::get_instance_id(),
			'site_url' => home_url( '/' ),
			'product_slug' => self::PRODUCT_SLUG,
		);
	}

	public static function activate( $license_key ) { return self::request( 'activate', self::data( $license_key ) ); }

	public static function validate( $license_key ) {
		$data = self::data( $license_key );
		if ( '' !== TutorHelper_Parent_Child_License::get_token() ) { $data['activation_token'] = TutorHelper_Parent_Child_License::get_token(); }
		return self::request( 'validate', $data );
	}

	public static function deactivate( $license_key, $token ) {
		$data = self::data( $license_key );
		$data['activation_token'] = sanitize_text_field( $token );
		return self::request( 'deactivate', $data );
	}
}
