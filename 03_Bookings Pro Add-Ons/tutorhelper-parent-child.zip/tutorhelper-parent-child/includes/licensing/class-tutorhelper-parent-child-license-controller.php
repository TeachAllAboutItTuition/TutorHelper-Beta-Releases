<?php
/** TutorHelper Parent & Child licence controller. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_Parent_Child_License_Controller {
	public static function activate( $license_key ) {
		$license_key = trim( sanitize_text_field( $license_key ) );
		if ( '' === $license_key ) { return new WP_Error( 'missing_key', __( 'A licence key is required.', 'tutorhelper-parent-child' ) ); }
		if ( ! TutorHelper_Parent_Child_License::set_key( $license_key ) ) {
			return new WP_Error( 'license_not_saved', __( 'The licence key could not be saved on this site.', 'tutorhelper-parent-child' ) );
		}
		$response = TutorHelper_Parent_Child_License_API::activate( $license_key );
		if ( is_wp_error( $response ) ) { return $response; }
		if ( empty( $response['success'] ) || empty( $response['activation_token'] ) || 'active' !== sanitize_key( $response['status'] ?? '' ) ) {
			return new WP_Error( 'activation_failed', __( 'The Parent & Child licence could not be activated.', 'tutorhelper-parent-child' ) );
		}
		TutorHelper_Parent_Child_License::store_activation( $license_key, $response );
		return true;
	}

	public static function validate() {
		$key = TutorHelper_Parent_Child_License::get_key();
		if ( '' === $key ) { return new WP_Error( 'missing_key', __( 'No licence key is stored.', 'tutorhelper-parent-child' ) ); }
		$response = TutorHelper_Parent_Child_License_API::validate( $key );
		if ( is_wp_error( $response ) ) { return $response; }
		$status = sanitize_key( $response['status'] ?? '' );
		$reason = sanitize_key( $response['reason'] ?? '' );
		if ( ! empty( $response['success'] ) && in_array( $status, array( 'valid', 'active' ), true ) ) {
			TutorHelper_Parent_Child_License::store_validation( $response );
			return true;
		}
		if ( 'activation_not_found' === $reason ) {
			/*
			 * The key is still valid, but this installation has a stale local token.
			 * Activation safely reuses the matching server activation where available,
			 * otherwise creates the permitted replacement activation.
			 */
			$recovery = self::activate( $key );
			if ( ! is_wp_error( $recovery ) ) {
				return true;
			}
			return new WP_Error(
				'activation_recovery_failed',
				__( 'The licence activation for this installation could not be refreshed. The previous local licence state has been kept.', 'tutorhelper-parent-child' ),
				array( 'server_reason' => $reason )
			);
		}
		if ( 'expired' === $status ) {
			TutorHelper_Parent_Child_License::set_status( 'expired' );
			return new WP_Error(
				'expired',
				__( 'The Parent & Child licence has expired.', 'tutorhelper-parent-child' ),
				array( 'server_reason' => $reason )
			);
		}
		if ( in_array( $status, array( 'invalid', 'inactive', 'revoked' ), true ) ) {
			TutorHelper_Parent_Child_License::set_status( 'invalid' );
			return new WP_Error(
				'invalid',
				__( 'The Parent & Child licence is not valid for this installation.', 'tutorhelper-parent-child' ),
				array( 'server_reason' => $reason )
			);
		}
		return new WP_Error(
			'license_unconfirmed',
			__( 'The licence server returned an unexpected response. The previous local licence state has been kept.', 'tutorhelper-parent-child' )
		);
	}

	public static function deactivate() {
		$key = TutorHelper_Parent_Child_License::get_key();
		$token = TutorHelper_Parent_Child_License::get_token();
		if ( '' === $key || '' === $token ) { return new WP_Error( 'not_active', __( 'No active Parent & Child licence was found.', 'tutorhelper-parent-child' ) ); }
		$response = TutorHelper_Parent_Child_License_API::deactivate( $key, $token );
		if ( is_wp_error( $response ) ) { return $response; }
		if ( empty( $response['success'] ) || 'inactive' !== sanitize_key( $response['status'] ?? '' ) ) { return new WP_Error( 'deactivation_failed', __( 'The Parent & Child licence could not be deactivated.', 'tutorhelper-parent-child' ) ); }
		TutorHelper_Parent_Child_License::deactivate_local();
		return true;
	}
}
