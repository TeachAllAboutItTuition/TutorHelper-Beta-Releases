<?php
/** TutorHelper Parent & Child licence settings and renewal notices. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_Parent_Child_License_Settings {
	const TAB = 'pro-license';
	const ACTIVATE_ACTION = 'tutorhelper_parent_child_activate_license';
	const VALIDATE_ACTION = 'tutorhelper_parent_child_validate_license';
	const DEACTIVATE_ACTION = 'tutorhelper_parent_child_deactivate_license';
	const REMOVE_KEY_ACTION = 'tutorhelper_parent_child_remove_license_key';
	const CRON_HOOK = 'tutorhelper_parent_child_daily_license_check';
	const ACCOUNT_URL = 'https://tutorhelper.co.uk/my-account/';

	public static function init() {
		self::schedule();
		add_action( 'tutorhelper_settings_render_tab', array( __CLASS__, 'render_tab' ) );
		add_action( 'admin_post_' . self::ACTIVATE_ACTION, array( __CLASS__, 'handle_activate' ) );
		add_action( 'admin_post_' . self::VALIDATE_ACTION, array( __CLASS__, 'handle_validate' ) );
		add_action( 'admin_post_' . self::DEACTIVATE_ACTION, array( __CLASS__, 'handle_deactivate' ) );
		add_action( 'admin_post_' . self::REMOVE_KEY_ACTION, array( __CLASS__, 'handle_remove_key' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'daily_validate' ) );
		add_action( 'admin_notices', array( __CLASS__, 'render_admin_notice' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	public static function unschedule() {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		if ( $timestamp ) { wp_unschedule_event( $timestamp, self::CRON_HOOK ); }
	}

	public static function render_tab( $selected_tab ) {
		if ( self::TAB !== $selected_tab ) { return; }
		$status = TutorHelper_Parent_Child_License::get_status();
		$key = TutorHelper_Parent_Child_License::get_key();
		?>
		<section class="tutorhelper-main-section">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'TutorHelper Parent & Child Licence', 'tutorhelper-parent-child' ); ?></h2>
					<p><?php esc_html_e( 'Activate and manage the Parent & Child licence for this site.', 'tutorhelper-parent-child' ); ?></p>
				</div>
			</header>
			<div class="tutorhelper-main-section__body tutorhelper-settings-section__body">
				<?php self::render_feedback(); ?>
				<div class="tutorhelper-input-field is-full-width">
					<label><?php esc_html_e( 'Licence status', 'tutorhelper-parent-child' ); ?></label>
					<p><strong><?php echo esc_html( self::status_label( $status ) ); ?></strong></p>
				</div>
				<?php self::render_expiry(); ?>
				<?php if ( 'active' === $status && TutorHelper_Parent_Child_License::is_active() ) : ?>
					<p><strong><?php esc_html_e( 'Licence key', 'tutorhelper-parent-child' ); ?>:</strong> <?php echo esc_html( self::mask_key( $key ) ); ?></p>
					<div class="tutorhelper-settings-actions">
						<?php self::action_form( self::VALIDATE_ACTION, __( 'Validate Licence', 'tutorhelper-parent-child' ) ); ?>
						<?php self::action_form( self::DEACTIVATE_ACTION, __( 'Deactivate Licence', 'tutorhelper-parent-child' ) ); ?>
					</div>
				<?php else : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTIVATE_ACTION ); ?>" />
						<?php wp_nonce_field( self::ACTIVATE_ACTION, 'tutorhelper_parent_child_license_nonce' ); ?>
						<div class="tutorhelper-input-field is-full-width">
							<label for="tutorhelper-parent-child-license-key"><?php esc_html_e( 'Parent & Child licence key', 'tutorhelper-parent-child' ); ?></label>
							<input id="tutorhelper-parent-child-license-key" name="license_key" type="text" value="<?php echo esc_attr( $key ); ?>" autocomplete="off" class="regular-text" required />
						</div>
						<?php submit_button( __( 'Activate Licence', 'tutorhelper-parent-child' ) ); ?>
					</form>
					<?php if ( '' !== $key ) : ?>
						<?php self::action_form( self::REMOVE_KEY_ACTION, __( 'Remove saved key', 'tutorhelper-parent-child' ) ); ?>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	private static function render_expiry() {
		if ( TutorHelper_Parent_Child_License::is_lifetime() ) {
			echo '<p><strong>' . esc_html__( 'Renewal', 'tutorhelper-parent-child' ) . ':</strong> ' . esc_html__( 'Lifetime licence', 'tutorhelper-parent-child' ) . '</p>';
			return;
		}
		$timestamp = TutorHelper_Parent_Child_License::expiry_timestamp();
		if ( $timestamp ) {
			echo '<p><strong>' . esc_html__( 'Renewal date', 'tutorhelper-parent-child' ) . ':</strong> ' . esc_html( wp_date( get_option( 'date_format' ), $timestamp ) ) . '</p>';
		}
	}

	private static function action_form( $action, $label ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>" />
			<?php wp_nonce_field( $action, 'tutorhelper_parent_child_license_nonce' ); ?>
			<?php submit_button( $label, 'secondary', 'submit', false ); ?>
		</form>
		<?php
	}

	public static function handle_activate() {
		self::check_request( self::ACTIVATE_ACTION );
		$key = isset( $_POST['license_key'] ) && ! is_array( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		$result = TutorHelper_Parent_Child_License_Controller::activate( $key );
		if ( is_wp_error( $result ) ) {
			self::log_activation_failure( $result );
			$result = new WP_Error(
				'activation_failed',
				__( 'We could not activate the Parent & Child licence. Please try again. If the problem continues, share the licence activation entry from TutorHelper Diagnostics with support.', 'tutorhelper-parent-child' )
			);
		}
		self::finish( $result, 'activated' );
	}

	/** Record safe technical details for a failed licence activation. */
	private static function log_activation_failure( $error ) {
		if ( ! class_exists( 'TutorHelper_Logger' ) ) { return; }
		$data = $error->get_error_data();
		$context = array( 'error_code' => sanitize_key( $error->get_error_code() ) );
		if ( is_array( $data ) && isset( $data['status'] ) && is_numeric( $data['status'] ) ) {
			$context['http_status'] = absint( $data['status'] );
		}
		// Deliberately omit the key, token, site URL and remote response body.
		TutorHelper_Logger::error( 'Parent & Child licence activation failed.', $context );
	}

	public static function handle_validate() {
		self::check_request( self::VALIDATE_ACTION );
		self::finish( TutorHelper_Parent_Child_License_Controller::validate(), 'validated' );
	}

	public static function handle_deactivate() {
		self::check_request( self::DEACTIVATE_ACTION );
		self::finish( TutorHelper_Parent_Child_License_Controller::deactivate(), 'deactivated' );
	}

	public static function handle_remove_key() {
		self::check_request( self::REMOVE_KEY_ACTION );
		if ( TutorHelper_Parent_Child_License::is_active() ) {
			self::finish( new WP_Error( 'active_license', __( 'Deactivate the licence before removing its saved key.', 'tutorhelper-parent-child' ) ), 'key_removed' );
		}
		$result = TutorHelper_Parent_Child_License::remove_key()
			? true
			: new WP_Error( 'key_not_removed', __( 'The saved licence key could not be removed.', 'tutorhelper-parent-child' ) );
		self::finish( $result, 'key_removed' );
	}

	private static function check_request( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'You do not have permission to manage this licence.', 'tutorhelper-parent-child' ), '', array( 'response' => 403 ) ); }
		check_admin_referer( $action, 'tutorhelper_parent_child_license_nonce' );
	}

	private static function finish( $result, $success ) {
		$type = is_wp_error( $result ) ? 'error' : 'success';
		$message = is_wp_error( $result ) ? $result->get_error_message() : $success;
		$url = add_query_arg(
			array( 'page' => TutorHelper_Settings::PAGE_SLUG, 'tab' => self::TAB, 'tutorhelper_parent_child_notice' => $type, 'tutorhelper_parent_child_message' => $message ),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}

	private static function render_feedback() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only feedback after a nonce-protected action.
		$type = isset( $_GET['tutorhelper_parent_child_notice'] ) && ! is_array( $_GET['tutorhelper_parent_child_notice'] ) ? sanitize_key( wp_unslash( $_GET['tutorhelper_parent_child_notice'] ) ) : '';
		$message = isset( $_GET['tutorhelper_parent_child_message'] ) && ! is_array( $_GET['tutorhelper_parent_child_message'] ) ? sanitize_text_field( wp_unslash( $_GET['tutorhelper_parent_child_message'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$success = array( 'activated' => __( 'The Parent & Child licence is active.', 'tutorhelper-parent-child' ), 'validated' => __( 'The Parent & Child licence is valid.', 'tutorhelper-parent-child' ), 'deactivated' => __( 'The Parent & Child licence has been deactivated.', 'tutorhelper-parent-child' ), 'key_removed' => __( 'The saved Parent & Child licence key has been removed.', 'tutorhelper-parent-child' ) );
		if ( 'success' === $type && isset( $success[ $message ] ) ) { echo '<div class="notice notice-success inline"><p>' . esc_html( $success[ $message ] ) . '</p></div>'; }
		if ( 'error' === $type && '' !== $message ) { echo '<div class="notice notice-error inline"><p>' . esc_html( $message ) . '</p></div>'; }
	}

	public static function daily_validate() {
		if ( '' === TutorHelper_Parent_Child_License::get_key() ) {
			return;
		}
		$result = TutorHelper_Parent_Child_License_Controller::validate();
		if ( is_wp_error( $result ) && class_exists( 'TutorHelper_Logger' ) ) {
			$data = $result->get_error_data();
			$context = array( 'error_code' => sanitize_key( $result->get_error_code() ) );
			if ( is_array( $data ) && isset( $data['status'] ) ) {
				$context['http_status'] = absint( $data['status'] );
			}
			if ( is_array( $data ) && ! empty( $data['server_reason'] ) ) {
				$context['server_reason'] = sanitize_key( $data['server_reason'] );
			}
			TutorHelper_Logger::warning(
				'TutorHelper Parent & Child scheduled licence validation did not complete.',
				$context
			);
		}
	}

	public static function render_admin_notice() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		if ( ! TutorHelper_Parent_Child_License::is_active() ) {
			$url = add_query_arg( array( 'page' => TutorHelper_Settings::PAGE_SLUG, 'tab' => self::TAB ), admin_url( 'admin.php' ) );
			?>
			<div class="notice notice-warning"><p><strong><?php esc_html_e( 'TutorHelper Parent & Child is locked.', 'tutorhelper-parent-child' ); ?></strong> <a href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Activate the add-on licence in TutorHelper Settings.', 'tutorhelper-parent-child' ); ?></a></p></div>
			<?php
			return;
		}
		if ( TutorHelper_Parent_Child_License::is_lifetime() ) { return; }
		$days = TutorHelper_Parent_Child_License::days_until_expiry();
		if ( null === $days || $days > 30 || $days < 0 || ! TutorHelper_Parent_Child_License::is_active() ) { return; }
		$text = sprintf(
			/* translators: %d: Number of days until the licence expires. */
			_n( 'Your TutorHelper Parent & Child licence expires in %d day.', 'Your TutorHelper Parent & Child licence expires in %d days.', $days, 'tutorhelper-parent-child' ),
			$days
		);
		?>
		<div class="notice notice-warning"><p><strong><?php echo esc_html( $text ); ?></strong> <a href="<?php echo esc_url( self::ACCOUNT_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Renew from your TutorHelper account', 'tutorhelper-parent-child' ); ?></a></p></div>
		<?php
	}

	private static function status_label( $status ) {
		$labels = array( 'active' => __( 'Active', 'tutorhelper-parent-child' ), 'inactive' => __( 'Inactive', 'tutorhelper-parent-child' ), 'expired' => __( 'Expired', 'tutorhelper-parent-child' ), 'invalid' => __( 'Invalid', 'tutorhelper-parent-child' ) );
		return $labels[ $status ] ?? $labels['inactive'];
	}

	private static function mask_key( $key ) {
		$key = (string) $key;
		if ( strlen( $key ) <= 10 ) { return str_repeat( '•', strlen( $key ) ); }
		return substr( $key, 0, 5 ) . str_repeat( '•', max( 4, strlen( $key ) - 10 ) ) . substr( $key, -5 );
	}
}
