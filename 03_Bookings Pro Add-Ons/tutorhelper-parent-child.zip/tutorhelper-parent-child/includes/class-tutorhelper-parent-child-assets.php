<?php
/**
 * TutorHelper Parent & Child assets.
 *
 * @package TutorHelper_Parent_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers namespaced parent-dashboard assets for later batches.
 */
final class TutorHelper_Parent_Child_Assets {

	/** Stylesheet handle. */
	const STYLE_HANDLE = 'tutorhelper-parent-child';

	/** Report interaction script handle. */
	const SCRIPT_HANDLE = 'tutorhelper-parent-child-reports';

	/** Administration stylesheet handle. */
	const ADMIN_STYLE_HANDLE = 'tutorhelper-parent-child-admin';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue_dashboard_assets' ), 40 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ), 90 );
	}

	/**
	 * Register the parent-dashboard stylesheet without loading it globally.
	 *
	 * @return void
	 */
	public static function register_assets() {
		$path = TUTORHELPER_PARENT_CHILD_PATH
			. 'assets/css/tutorhelper-parent-child.css';

		wp_register_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PARENT_CHILD_URL
				. 'assets/css/tutorhelper-parent-child.css',
			array( 'tutorhelper-student-dashboard', 'tutorhelper-pro-student-dashboard-table' ),
			file_exists( $path )
				? (string) filemtime( $path )
				: TUTORHELPER_PARENT_CHILD_VERSION
		);

		$script_path = TUTORHELPER_PARENT_CHILD_PATH
			. 'assets/js/tutorhelper-parent-reports.js';

		wp_register_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PARENT_CHILD_URL
				. 'assets/js/tutorhelper-parent-reports.js',
			array(),
			file_exists( $script_path )
				? (string) filemtime( $script_path )
				: TUTORHELPER_PARENT_CHILD_VERSION,
			true
		);
	}

	/**
	 * Enqueue dashboard assets early enough for WordPress to print them in the page head.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_dashboard_assets() {
		global $post;

		if ( ! is_singular() || ! $post instanceof WP_Post ) {
			return;
		}

		$content = (string) $post->post_content;
		if (
			! has_shortcode( $content, 'tutorhelper_student_dashboard' )
			&& ! has_shortcode( $content, 'tutorhelper_student_sidebar' )
		) {
			return;
		}

		self::enqueue_dashboard_assets();
	}

	/**
	 * Enqueue assets when a parent-facing component is rendered.
	 *
	 * @return void
	 */
	public static function enqueue_dashboard_assets() {
		if ( ! wp_style_is( self::STYLE_HANDLE, 'registered' ) ) {
			self::register_assets();
		}

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( self::STYLE_HANDLE );
		wp_enqueue_script( self::SCRIPT_HANDLE );
	}

	/**
	 * Load administration styles only on the Parent Accounts tab.
	 *
	 * @param string $hook_suffix Current admin screen hook.
	 * @return void
	 */
	public static function enqueue_admin_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix ) {
			return;
		}

		/*
		 * Parent Account admin selectors are fully namespaced. Enqueue the
		 * stylesheet throughout the Booking Hub so it is also available when
		 * tab content is reached through a default, restored or dynamic route.
		 */
		$path = TUTORHELPER_PARENT_CHILD_PATH
			. 'assets/css/tutorhelper-parent-child.css';

		wp_enqueue_style(
			self::ADMIN_STYLE_HANDLE,
			TUTORHELPER_PARENT_CHILD_URL
				. 'assets/css/tutorhelper-parent-child.css',
			array( 'tutorhelper-booking-hub' ),
			file_exists( $path )
				? (string) filemtime( $path )
				: TUTORHELPER_PARENT_CHILD_VERSION
		);

		if (
			class_exists( 'TutorHelper_Student_Dashboard_Frontend' )
			&& defined(
				'TutorHelper_Student_Dashboard_Frontend::PASSWORD_SCRIPT_HANDLE'
			)
		) {
			TutorHelper_Student_Dashboard_Frontend::register_assets();
			wp_enqueue_script(
				TutorHelper_Student_Dashboard_Frontend::PASSWORD_SCRIPT_HANDLE
			);
		}
	}
}
