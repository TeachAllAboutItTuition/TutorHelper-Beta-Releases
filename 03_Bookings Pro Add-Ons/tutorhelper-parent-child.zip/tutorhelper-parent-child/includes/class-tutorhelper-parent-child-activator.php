<?php
/**
 * TutorHelper Parent & Child activation handler.
 *
 * @package TutorHelper_Parent_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles safe add-on activation.
 */
final class TutorHelper_Parent_Child_Activator {

	/**
	 * Run activation checks and store the installed version.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			self::fail(
				__(
					'TutorHelper Parent & Child requires PHP 7.4 or later.',
					'tutorhelper-parent-child'
				)
			);
		}

		if ( ! TutorHelper_Parent_Child_Dependency::core_is_available() ) {
			self::fail(
				__(
					'Install and activate the latest TutorHelper Bookings Core version before activating TutorHelper Parent & Child.',
					'tutorhelper-parent-child'
				)
			);
		}

		if ( ! TutorHelper_Parent_Child_Dependency::pro_is_available() ) {
			self::fail(
				__(
					'Install and activate TutorHelper Pro before activating TutorHelper Parent & Child.',
					'tutorhelper-parent-child'
				)
			);
		}

		TutorHelper_Roles::register_roles();
		TutorHelper_Bookings_Database::create_tables();
		TutorHelper_Student_Parent_Links::migrate_legacy_links();
		TutorHelper_Parent_Child_License_Settings::schedule();

		update_option(
			'tutorhelper_parent_child_version',
			TUTORHELPER_PARENT_CHILD_VERSION,
			false
		);

		if ( class_exists( 'TutorHelper_Logger' ) ) {
			TutorHelper_Logger::success(
				'TutorHelper Parent & Child activated.',
				array( 'plugin_version' => TUTORHELPER_PARENT_CHILD_VERSION )
			);
		}
	}

	/**
	 * Stop activation with a translated, escaped message.
	 *
	 * @param string $message Failure explanation.
	 * @return void
	 */
	private static function fail( $message ) {
		deactivate_plugins( TUTORHELPER_PARENT_CHILD_BASENAME );

		wp_die(
			esc_html( $message ),
			esc_html__( 'Plugin activation failed', 'tutorhelper-parent-child' ),
			array( 'back_link' => true )
		);
	}
}
