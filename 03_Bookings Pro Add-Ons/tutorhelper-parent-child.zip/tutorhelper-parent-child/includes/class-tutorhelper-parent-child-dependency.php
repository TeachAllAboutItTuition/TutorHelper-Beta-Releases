<?php
/**
 * TutorHelper Parent & Child dependency checks.
 *
 * @package TutorHelper_Parent_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validates the Core and Pro dependencies without causing fatal errors.
 */
final class TutorHelper_Parent_Child_Dependency {

	/**
	 * Register dependency notices.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_notices', array( __CLASS__, 'render_admin_notice' ) );
	}

	/**
	 * Whether TutorHelper Core is available.
	 *
	 * @return bool
	 */
	public static function core_is_available() {
		return defined( 'TUTORHELPER_BOOKINGS_VERSION' )
			&& class_exists( 'TutorHelper_Bookings' )
			&& class_exists( 'TutorHelper_Student_Parent_Links' );
	}

	/**
	 * Whether TutorHelper Pro is available.
	 *
	 * @return bool
	 */
	public static function pro_is_available() {
		return defined( 'TUTORHELPER_PRO_VERSION' )
			&& class_exists( 'TutorHelper_Pro' );
	}

	/**
	 * Whether the installed Pro licence is active.
	 *
	 * @return bool
	 */
	public static function pro_is_licensed() {
		return self::pro_is_available()
			&& class_exists( 'TutorHelper_Pro_License' )
			&& TutorHelper_Pro_License::is_active();
	}

	/**
	 * Whether all runtime requirements are met.
	 *
	 * @return bool
	 */
	public static function requirements_met() {
		return self::core_is_available()
			&& self::pro_is_available()
			&& self::pro_is_licensed();
	}

	/**
	 * Render one actionable dependency notice.
	 *
	 * @return void
	 */
	public static function render_admin_notice() {
		if ( self::requirements_met() || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		if ( ! self::core_is_available() ) {
			$message = __(
				'TutorHelper Parent & Child requires the latest version of TutorHelper Bookings Core.',
				'tutorhelper-parent-child'
			);
		} elseif ( ! self::pro_is_available() ) {
			$message = __(
				'TutorHelper Parent & Child requires TutorHelper Pro.',
				'tutorhelper-parent-child'
			);
		} else {
			$message = __(
				'Activate your TutorHelper Pro licence to use TutorHelper Parent & Child.',
				'tutorhelper-parent-child'
			);
		}

		?>
		<div class="notice notice-warning">
			<p><strong><?php esc_html_e( 'TutorHelper Parent & Child', 'tutorhelper-parent-child' ); ?></strong></p>
			<p><?php echo esc_html( $message ); ?></p>
		</div>
		<?php
	}
}
