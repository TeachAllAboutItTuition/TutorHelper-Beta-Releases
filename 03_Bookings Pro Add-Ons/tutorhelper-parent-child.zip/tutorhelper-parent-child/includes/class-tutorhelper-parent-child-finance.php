<?php
/**
 * Parent Dashboard finance screen and protected actions.
 *
 * @package TutorHelper_Parent_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders PC5 finance and authorises parent actions.
 */
final class TutorHelper_Parent_Child_Finance {

	const ACTION = 'tutorhelper_parent_finance_action';
	const NONCE = 'tutorhelper_parent_finance_nonce';

	/** Register finance rendering and actions. */
	public static function init() {
		add_filter(
			'tutorhelper_parent_dashboard_section_rendered',
			array( __CLASS__, 'render_section' ),
			10,
			3
		);
		add_action(
			'admin_post_' . self::ACTION,
			array( __CLASS__, 'handle_action' )
		);
	}

	/**
	 * Render the Finance tab.
	 *
	 * @param bool    $rendered Whether another extension rendered the section.
	 * @param string  $section  Section key.
	 * @param WP_User $student  Selected student.
	 * @return bool
	 */
	public static function render_section( $rendered, $section, $student ) {
		if ( $rendered || 'finance' !== $section || ! $student instanceof WP_User ) {
			return $rendered;
		}

		if ( ! class_exists( 'TutorHelper_Pro_Parent_Finance' ) ) {
			self::empty_state(
				__( 'Finance information is temporarily unavailable. Please contact your tutor.', 'tutorhelper-parent-child' )
			);
			return true;
		}

		$snapshot = TutorHelper_Pro_Parent_Finance::get_snapshot( $student->ID );
		self::render_notice();
		?>
		<div class="tutorhelper-parent-report__intro">
			<h4><?php esc_html_e( 'Finance', 'tutorhelper-parent-child' ); ?></h4>
			<p><?php esc_html_e( 'Review upcoming tuition fees, download an invoice and view the full statement of account.', 'tutorhelper-parent-child' ); ?></p>
		</div>

		<?php self::summary( $snapshot ); ?>
		<?php self::due_table( $student, $snapshot ); ?>
		<?php self::payment_details( $student, $snapshot ); ?>
		<?php self::statement( $snapshot['statement'] ); ?>
		<?php
		return true;
	}

	/** Render finance summary cards. */
	private static function summary( $snapshot ) {
		$due_total = 0;
		$part_paid = 0;
		foreach ( $snapshot['due'] as $row ) {
			$due_total += absint( $row['balance_minor_units'] );
			if ( $row['paid_minor_units'] > 0 ) {
				++$part_paid;
			}
		}
		$currency = $snapshot['currency'];
		?>
		<div class="tutorhelper-parent-summary-grid tutorhelper-parent-finance__summary">
			<?php self::card( __( 'Due lessons', 'tutorhelper-parent-child' ), count( $snapshot['due'] ), __( 'Within the next 30 days or overdue', 'tutorhelper-parent-child' ), 'calendar-alt', 'navy' ); ?>
			<?php self::card( __( 'Balance due', 'tutorhelper-parent-child' ), TutorHelper_Currency::format_minor_units( $due_total, $currency ), __( 'Across selectable lessons', 'tutorhelper-parent-child' ), 'money-alt', 'orange' ); ?>
			<?php self::card( __( 'Part paid', 'tutorhelper-parent-child' ), $part_paid, __( 'Lessons with a remaining balance', 'tutorhelper-parent-child' ), 'chart-pie', 'blue' ); ?>
			<?php self::card( __( 'Account credit', 'tutorhelper-parent-child' ), TutorHelper_Currency::format_minor_units( max( 0, intval( $snapshot['credit_balance_minor_units'] ) ), $currency ), __( 'Available on the student account', 'tutorhelper-parent-child' ), 'awards', 'green' ); ?>
		</div>
		<?php
	}

	/** Render the invoice-style due list. */
	private static function due_table( $student, $snapshot ) {
		$rows = $snapshot['due'];
		$methods = $snapshot['methods'];
		?>
		<section class="tutorhelper-parent-finance__invoice" aria-labelledby="thpc-finance-due-heading">
			<header class="tutorhelper-parent-finance__invoice-header">
				<div>
					<p><?php esc_html_e( 'Tuition account', 'tutorhelper-parent-child' ); ?></p>
					<h5 id="thpc-finance-due-heading"><?php esc_html_e( 'Unpaid and part-paid lessons', 'tutorhelper-parent-child' ); ?></h5>
				</div>
				<div>
					<strong><?php echo esc_html( $student->display_name ); ?></strong>
					<span><?php esc_html_e( 'Payment due within 30 days', 'tutorhelper-parent-child' ); ?></span>
				</div>
			</header>

			<?php if ( empty( $rows ) ) : ?>
				<div class="tutorhelper-parent-report__empty">
					<h5><?php esc_html_e( 'Nothing is currently due', 'tutorhelper-parent-child' ); ?></h5>
					<p><?php esc_html_e( 'There are no unpaid or part-paid lessons due within the next 30 days.', 'tutorhelper-parent-child' ); ?></p>
				</div>
			<?php else : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-thpc-finance-form>
					<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
					<input type="hidden" name="student_id" value="<?php echo esc_attr( $student->ID ); ?>" />
					<?php wp_nonce_field( self::ACTION . '_' . absint( $student->ID ), self::NONCE ); ?>

					<div class="tutorhelper-pro-dashboard-table__scroll tutorhelper-parent-finance__table-wrap">
						<table class="tutorhelper-parent-finance__table">
							<caption class="screen-reader-text"><?php esc_html_e( 'Lessons with payment due', 'tutorhelper-parent-child' ); ?></caption>
							<thead>
								<tr>
									<th scope="col"><input type="checkbox" data-thpc-select-all aria-label="<?php esc_attr_e( 'Select all payable lessons', 'tutorhelper-parent-child' ); ?>" /></th>
									<th scope="col"><?php esc_html_e( 'Due date', 'tutorhelper-parent-child' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Lesson', 'tutorhelper-parent-child' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Fee', 'tutorhelper-parent-child' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Paid', 'tutorhelper-parent-child' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Balance', 'tutorhelper-parent-child' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Status', 'tutorhelper-parent-child' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $rows as $row ) : ?>
									<tr>
										<td data-label="<?php esc_attr_e( 'Select', 'tutorhelper-parent-child' ); ?>"><input type="checkbox" name="booking_ids[]" value="<?php echo esc_attr( $row['booking_id'] ); ?>" data-thpc-finance-item data-balance="<?php echo esc_attr( $row['balance_minor_units'] ); ?>" /></td>
										<td data-label="<?php esc_attr_e( 'Due date', 'tutorhelper-parent-child' ); ?>"><?php echo esc_html( $row['date_label'] ); ?></td>
										<td data-label="<?php esc_attr_e( 'Lesson', 'tutorhelper-parent-child' ); ?>"><strong><?php echo esc_html( $row['title'] ); ?></strong></td>
										<td data-label="<?php esc_attr_e( 'Fee', 'tutorhelper-parent-child' ); ?>"><?php echo esc_html( self::money( $row['price_minor_units'], $row['currency'] ) ); ?></td>
										<td data-label="<?php esc_attr_e( 'Paid', 'tutorhelper-parent-child' ); ?>"><?php echo esc_html( self::money( $row['paid_minor_units'], $row['currency'] ) ); ?></td>
										<td data-label="<?php esc_attr_e( 'Balance', 'tutorhelper-parent-child' ); ?>"><strong><?php echo esc_html( self::money( $row['balance_minor_units'], $row['currency'] ) ); ?></strong></td>
										<td data-label="<?php esc_attr_e( 'Status', 'tutorhelper-parent-child' ); ?>"><span class="tutorhelper-parent-status is-<?php echo esc_attr( $row['payment_status'] ); ?>"><?php echo esc_html( self::status_label( $row['payment_status'] ) ); ?></span></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
							<tfoot><tr><th colspan="5" scope="row"><?php esc_html_e( 'Selected total', 'tutorhelper-parent-child' ); ?></th><td colspan="2"><strong data-thpc-selected-total data-currency="<?php echo esc_attr( $snapshot['currency'] ); ?>" data-factor="<?php echo esc_attr( pow( 10, TutorHelper_Currency::get_decimal_places( $snapshot['currency'] ) ) ); ?>"><?php echo esc_html( self::money( 0, $snapshot['currency'] ) ); ?></strong></td></tr></tfoot>
						</table>
					</div>

					<div class="tutorhelper-parent-finance__actions">
						<button type="submit" name="operation" value="invoice" class="tutorhelper-parent-finance__button is-secondary" formtarget="_blank" disabled data-thpc-selection-action>
							<span class="dashicons dashicons-pdf" aria-hidden="true"></span>
							<?php esc_html_e( 'Export PDF invoice', 'tutorhelper-parent-child' ); ?>
						</button>
						<?php if ( ! empty( $methods['card'] ) ) : ?>
							<button type="submit" name="operation" value="stripe" class="tutorhelper-parent-finance__button" disabled data-thpc-selection-action>
								<span class="dashicons dashicons-lock" aria-hidden="true"></span>
								<?php esc_html_e( 'Pay selected lessons securely', 'tutorhelper-parent-child' ); ?>
							</button>
						<?php endif; ?>
					</div>
				</form>
			<?php endif; ?>
		</section>
		<?php
	}

	/** Render the payment instructions appropriate to the selected student. */
	private static function payment_details( $student, $snapshot ) {
		$methods = $snapshot['methods'];
		$bank = $snapshot['bank_details'];

		if ( ! empty( $methods['bank_transfer'] ) && ! empty( $bank ) ) {
			?>
			<section class="tutorhelper-parent-finance__payment-panel">
				<h5><?php esc_html_e( 'Pay by bank transfer', 'tutorhelper-parent-child' ); ?></h5>
				<p><?php esc_html_e( 'Use the details below and include the requested payment reference.', 'tutorhelper-parent-child' ); ?></p>
				<dl>
					<?php self::detail( __( 'Account name', 'tutorhelper-parent-child' ), $bank['account_name'] ); ?>
					<?php self::detail( __( 'Bank', 'tutorhelper-parent-child' ), $bank['bank_name'] ); ?>
					<?php self::detail( __( 'Sort code', 'tutorhelper-parent-child' ), $bank['sort_code'] ); ?>
					<?php self::detail( __( 'Account number', 'tutorhelper-parent-child' ), $bank['account_number'] ); ?>
					<?php self::detail( __( 'IBAN', 'tutorhelper-parent-child' ), $bank['iban'] ); ?>
					<?php self::detail( __( 'BIC / SWIFT', 'tutorhelper-parent-child' ), $bank['bic'] ); ?>
					<?php self::detail( __( 'Reference', 'tutorhelper-parent-child' ), $bank['reference_instructions'] ? $bank['reference_instructions'] : $student->display_name ); ?>
				</dl>
				<?php if ( ! empty( $bank['additional_instructions'] ) ) : ?><p><?php echo esc_html( $bank['additional_instructions'] ); ?></p><?php endif; ?>
			</section>
			<?php
		} elseif ( ! empty( $methods['invoice'] ) && empty( $methods['card'] ) ) {
			?>
			<div class="tutorhelper-parent-finance__information" role="note">
				<h5><?php esc_html_e( 'Invoice information only', 'tutorhelper-parent-child' ); ?></h5>
				<p><?php esc_html_e( 'This account is set to invoice payment only. The lesson balances are shown for your records; your tutor will provide payment instructions separately.', 'tutorhelper-parent-child' ); ?></p>
			</div>
			<?php
		}
	}

	/** Render the filterable statement. */
	private static function statement( $rows ) {
		$types = array();
		foreach ( $rows as $row ) {
			$types[ $row['type'] ] = $row['type_label'];
		}
		?>
		<section class="tutorhelper-parent-report-table tutorhelper-parent-finance__statement" data-thpc-report data-page-size="10" data-default-sort="desc">
			<div class="tutorhelper-parent-report__intro">
				<h4><?php esc_html_e( 'Statement of account', 'tutorhelper-parent-child' ); ?></h4>
				<p><?php esc_html_e( 'All other lessons, payments, credits, refunds and adjustments.', 'tutorhelper-parent-child' ); ?></p>
			</div>
			<div class="tutorhelper-pro-dashboard-table__filters" aria-label="<?php esc_attr_e( 'Statement filters', 'tutorhelper-parent-child' ); ?>">
				<label><span><?php esc_html_e( 'From', 'tutorhelper-parent-child' ); ?></span><input type="date" data-thpc-filter="from" /></label>
				<label><span><?php esc_html_e( 'To', 'tutorhelper-parent-child' ); ?></span><input type="date" data-thpc-filter="to" /></label>
				<label><span><?php esc_html_e( 'Type', 'tutorhelper-parent-child' ); ?></span><select data-thpc-filter="type"><option value=""><?php esc_html_e( 'All entries', 'tutorhelper-parent-child' ); ?></option><?php foreach ( $types as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
				<button type="button" data-thpc-reset><?php esc_html_e( 'Reset filters', 'tutorhelper-parent-child' ); ?></button>
			</div>
			<p data-thpc-count></p>
			<div class="tutorhelper-pro-dashboard-table__scroll">
				<table>
					<caption class="screen-reader-text"><?php esc_html_e( 'Statement of account', 'tutorhelper-parent-child' ); ?></caption>
					<thead><tr><th scope="col" aria-sort="descending"><button type="button" data-thpc-sort="date"><?php esc_html_e( 'Date', 'tutorhelper-parent-child' ); ?></button></th><th scope="col"><?php esc_html_e( 'Type', 'tutorhelper-parent-child' ); ?></th><th scope="col"><?php esc_html_e( 'Description', 'tutorhelper-parent-child' ); ?></th><th scope="col"><?php esc_html_e( 'Amount', 'tutorhelper-parent-child' ); ?></th><th scope="col"><?php esc_html_e( 'Status', 'tutorhelper-parent-child' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $rows as $row ) : $date_key = $row['timestamp'] ? gmdate( 'Y-m-d', $row['timestamp'] ) : ''; ?>
							<tr data-thpc-row data-date="<?php echo esc_attr( $date_key ); ?>" data-type="<?php echo esc_attr( $row['type'] ); ?>">
								<td data-label="<?php esc_attr_e( 'Date', 'tutorhelper-parent-child' ); ?>"><?php echo esc_html( $row['date_label'] ); ?></td>
								<td data-label="<?php esc_attr_e( 'Type', 'tutorhelper-parent-child' ); ?>"><?php echo esc_html( $row['type_label'] ); ?></td>
								<td data-label="<?php esc_attr_e( 'Description', 'tutorhelper-parent-child' ); ?>"><?php echo esc_html( $row['description'] ); ?></td>
								<td data-label="<?php esc_attr_e( 'Amount', 'tutorhelper-parent-child' ); ?>"><?php echo esc_html( self::money( $row['amount_minor_units'], $row['currency'] ) ); ?></td>
								<td data-label="<?php esc_attr_e( 'Status', 'tutorhelper-parent-child' ); ?>"><?php echo esc_html( self::status_label( $row['status'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
						<tr data-thpc-empty hidden><td colspan="5"><?php esc_html_e( 'No statement entries match these filters.', 'tutorhelper-parent-child' ); ?></td></tr>
					</tbody>
				</table>
			</div>
			<div class="tutorhelper-parent-pagination"><button type="button" data-thpc-previous><?php esc_html_e( 'Previous', 'tutorhelper-parent-child' ); ?></button><span data-thpc-page-status></span><button type="button" data-thpc-next><?php esc_html_e( 'Next', 'tutorhelper-parent-child' ); ?></button></div>
		</section>
		<?php
	}

	/** Handle PDF export or Stripe Checkout. */
	public static function handle_action() {
		$student_id = isset( $_POST['student_id'] ) ? absint( wp_unslash( $_POST['student_id'] ) ) : 0;
		check_admin_referer( self::ACTION . '_' . $student_id, self::NONCE );
		$parent_id = get_current_user_id();

		if (
			! $parent_id
			|| ! $student_id
			|| ! TutorHelper_Student_Parent_Links::is_linked( $parent_id, $student_id )
		) {
			wp_die(
				esc_html__( 'You do not have access to this student’s finance information.', 'tutorhelper-parent-child' ),
				esc_html__( 'Access denied', 'tutorhelper-parent-child' ),
				array( 'response' => 403 )
			);
		}

		$ids = isset( $_POST['booking_ids'] ) && is_array( $_POST['booking_ids'] )
			? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['booking_ids'] ) ) ) ) )
			: array();
		$operation = isset( $_POST['operation'] ) && ! is_array( $_POST['operation'] )
			? sanitize_key( wp_unslash( $_POST['operation'] ) )
			: '';

		if ( empty( $ids ) ) {
			self::redirect( $student_id, 'select_lessons' );
		}

		if ( 'invoice' === $operation ) {
			self::output_invoice( $student_id, $parent_id, $ids );
		}

		if ( 'stripe' === $operation ) {
			$return_url = self::finance_url( $student_id );
			$result = TutorHelper_Pro_Parent_Finance::create_checkout(
				$student_id,
				$parent_id,
				$ids,
				$return_url
			);
			if ( is_wp_error( $result ) || empty( $result['url'] ) ) {
				self::redirect( $student_id, 'payment_failed' );
			}
			wp_redirect( esc_url_raw( $result['url'] ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Stripe is the configured external payment provider.
			exit;
		}

		self::redirect( $student_id, 'invalid_action' );
	}

	/** Stream a PDF invoice containing only currently payable selected rows. */
	private static function output_invoice( $student_id, $parent_id, $ids ) {
		$snapshot = TutorHelper_Pro_Parent_Finance::get_snapshot( $student_id );
		$selected = array_values(
			array_filter(
				$snapshot['due'],
				static function ( $row ) use ( $ids ) {
					return in_array( absint( $row['booking_id'] ), $ids, true );
				}
			)
		);

		if ( empty( $selected ) ) {
			self::redirect( $student_id, 'select_lessons' );
		}

		if ( ! class_exists( '\\Dompdf\\Dompdf' ) ) {
			$autoload = defined( 'TUTORHELPER_BOOKINGS_PATH' )
				? TUTORHELPER_BOOKINGS_PATH . 'vendor/dompdf/autoload.inc.php'
				: '';
			if ( $autoload && file_exists( $autoload ) ) {
				require_once $autoload;
			}
		}

		if ( ! class_exists( '\\Dompdf\\Dompdf' ) ) {
			self::redirect( $student_id, 'pdf_unavailable' );
		}

		$student = get_userdata( $student_id );
		$parent = get_userdata( $parent_id );
		$total = array_sum( wp_list_pluck( $selected, 'balance_minor_units' ) );
		$invoice_number = 'TH-' . $student_id . '-' . gmdate( 'Ymd-His' );
		$html = self::invoice_html( $invoice_number, $student, $parent, $selected, $total, $snapshot['currency'] );

		$options = new \Dompdf\Options();
		$options->set( 'isRemoteEnabled', false );
		$dompdf = new \Dompdf\Dompdf( $options );
		$dompdf->loadHtml( $html, 'UTF-8' );
		$dompdf->setPaper( 'A4', 'portrait' );
		$dompdf->render();
		$dompdf->stream( sanitize_file_name( $invoice_number . '.pdf' ), array( 'Attachment' => true ) );
		exit;
	}

	/** Build the escaped PDF invoice HTML. */
	private static function invoice_html( $number, $student, $parent, $rows, $total, $currency ) {
		$site_name = get_bloginfo( 'name' );
		$html = '<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:DejaVu Sans,sans-serif;color:#123d4c;font-size:12px}header{border-bottom:4px solid #ff6326;padding-bottom:18px;margin-bottom:24px}h1{margin:0;font-size:28px}p{margin:5px 0}.meta{display:table;width:100%;margin-bottom:24px}.meta div{display:table-cell;width:50%;vertical-align:top}table{width:100%;border-collapse:collapse}th{background:#123d4c;color:#fff;text-align:left;padding:10px}td{padding:10px;border-bottom:1px solid #d3dfe4}.num{text-align:right}tfoot td{font-weight:bold;font-size:14px;border-top:2px solid #123d4c}.note{margin-top:24px;padding:14px;background:#fdf5ee}</style></head><body>';
		$html .= '<header><h1>' . esc_html__( 'Tuition invoice', 'tutorhelper-parent-child' ) . '</h1><p>' . esc_html( $site_name ) . '</p></header>';
		$html .= '<div class="meta"><div><strong>' . esc_html__( 'Invoice', 'tutorhelper-parent-child' ) . '</strong><p>' . esc_html( $number ) . '</p><p>' . esc_html( wp_date( get_option( 'date_format' ) ) ) . '</p></div><div><strong>' . esc_html__( 'For', 'tutorhelper-parent-child' ) . '</strong><p>' . esc_html( $student ? $student->display_name : '' ) . '</p><p>' . esc_html( $parent ? $parent->display_name : '' ) . '</p></div></div>';
		$html .= '<table><thead><tr><th>' . esc_html__( 'Due date', 'tutorhelper-parent-child' ) . '</th><th>' . esc_html__( 'Lesson', 'tutorhelper-parent-child' ) . '</th><th class="num">' . esc_html__( 'Fee', 'tutorhelper-parent-child' ) . '</th><th class="num">' . esc_html__( 'Paid', 'tutorhelper-parent-child' ) . '</th><th class="num">' . esc_html__( 'Balance', 'tutorhelper-parent-child' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $row ) {
			$html .= '<tr><td>' . esc_html( $row['date_label'] ) . '</td><td>' . esc_html( $row['title'] ) . '</td><td class="num">' . esc_html( self::money( $row['price_minor_units'], $row['currency'] ) ) . '</td><td class="num">' . esc_html( self::money( $row['paid_minor_units'], $row['currency'] ) ) . '</td><td class="num">' . esc_html( self::money( $row['balance_minor_units'], $row['currency'] ) ) . '</td></tr>';
		}
		$html .= '</tbody><tfoot><tr><td colspan="4">' . esc_html__( 'Total due', 'tutorhelper-parent-child' ) . '</td><td class="num">' . esc_html( self::money( $total, $currency ) ) . '</td></tr></tfoot></table>';
		$html .= '<div class="note">' . esc_html__( 'This invoice was generated from the current TutorHelper statement. Payments made after generation may not be shown.', 'tutorhelper-parent-child' ) . '</div></body></html>';
		return $html;
	}

	/** Render a summary card. */
	private static function card( $label, $value, $description, $icon, $tone ) {
		?><article class="tutorhelper-parent-summary-card is-<?php echo esc_attr( $tone ); ?>"><span class="dashicons dashicons-<?php echo esc_attr( $icon ); ?> tutorhelper-parent-summary-card__icon" aria-hidden="true"></span><div class="tutorhelper-parent-summary-card__content"><span class="tutorhelper-parent-summary-card__label"><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( $value ); ?></strong><p><?php echo esc_html( $description ); ?></p></div></article><?php
	}

	/** Render a non-empty bank detail. */
	private static function detail( $label, $value ) {
		if ( '' === trim( (string) $value ) ) {
			return;
		}
		?><div><dt><?php echo esc_html( $label ); ?></dt><dd><?php echo esc_html( $value ); ?></dd></div><?php
	}

	/** Render an unavailable state. */
	private static function empty_state( $message ) {
		?><div class="tutorhelper-parent-report__empty"><h4><?php esc_html_e( 'Finance', 'tutorhelper-parent-child' ); ?></h4><p><?php echo esc_html( $message ); ?></p></div><?php
	}

	/** Format money consistently with Core. */
	private static function money( $amount, $currency ) {
		return TutorHelper_Currency::format_minor_units( intval( $amount ), $currency );
	}

	/** Human-readable finance status. */
	private static function status_label( $status ) {
		$labels = array(
			'pending' => __( 'Unpaid', 'tutorhelper-parent-child' ),
			'part_paid' => __( 'Part paid', 'tutorhelper-parent-child' ),
			'paid' => __( 'Paid', 'tutorhelper-parent-child' ),
			'refunded' => __( 'Refunded', 'tutorhelper-parent-child' ),
			'not_required' => __( 'No payment required', 'tutorhelper-parent-child' ),
			'recorded' => __( 'Recorded', 'tutorhelper-parent-child' ),
			'cancelled' => __( 'Cancelled', 'tutorhelper-parent-child' ),
		);
		$key = sanitize_key( $status );
		return $labels[ $key ] ?? ucfirst( str_replace( '_', ' ', $key ) );
	}

	/** Display return/action feedback. */
	private static function render_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only return status from protected finance actions; no state is changed here.
		$notice = isset( $_GET['tutorhelper_parent_finance_notice'] ) && ! is_array( $_GET['tutorhelper_parent_finance_notice'] )
			? sanitize_key( wp_unslash( $_GET['tutorhelper_parent_finance_notice'] ) )
			: '';
		$payment = isset( $_GET['tutorhelper_parent_payment'] ) && ! is_array( $_GET['tutorhelper_parent_payment'] )
			? sanitize_key( wp_unslash( $_GET['tutorhelper_parent_payment'] ) )
			: ( isset( $_GET['payment_request'] ) && ! is_array( $_GET['payment_request'] ) ? sanitize_key( wp_unslash( $_GET['payment_request'] ) ) : '' );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( 'success' === $payment ) {
			?><div class="tutorhelper-student-dashboard__notice tutorhelper-student-dashboard__notice--success" role="status"><?php esc_html_e( 'Your payment was successful. Your Finance table has been refreshed; if Stripe confirmation is still processing, the payment will appear shortly.', 'tutorhelper-parent-child' ); ?></div><?php
		} elseif ( 'cancelled' === $payment ) {
			?><div class="tutorhelper-student-dashboard__notice" role="status"><?php esc_html_e( 'Payment was cancelled. No payment was recorded.', 'tutorhelper-parent-child' ); ?></div><?php
		} elseif ( $notice ) {
			$messages = array(
				'select_lessons' => __( 'Select at least one lesson first.', 'tutorhelper-parent-child' ),
				'payment_failed' => __( 'Secure payment could not be started. Refresh the statement and try again.', 'tutorhelper-parent-child' ),
				'pdf_unavailable' => __( 'The PDF invoice could not be created on this site.', 'tutorhelper-parent-child' ),
				'invalid_action' => __( 'That finance action was not recognised.', 'tutorhelper-parent-child' ),
			);
			if ( isset( $messages[ $notice ] ) ) {
				?><div class="tutorhelper-student-dashboard__notice tutorhelper-student-dashboard__notice--error" role="alert"><?php echo esc_html( $messages[ $notice ] ); ?></div><?php
			}
		}
	}

	/** Return the selected child's Finance URL. */
	private static function finance_url( $student_id ) {
		$base = TutorHelper_Settings::get_student_dashboard_url();
		return add_query_arg(
			array(
				TutorHelper_Parent_Child_Dashboard::CHILD_ARG => absint( $student_id ),
				TutorHelper_Parent_Child_Dashboard::SECTION_ARG => 'finance',
				TutorHelper_Parent_Child_Dashboard::NONCE_ARG => wp_create_nonce( TutorHelper_Parent_Child_Dashboard::NONCE_ACTION ),
			),
			$base ? $base : home_url( '/' )
		);
	}

	/** Redirect to Finance with a notice. */
	private static function redirect( $student_id, $notice ) {
		wp_safe_redirect(
			add_query_arg(
				'tutorhelper_parent_finance_notice',
				sanitize_key( $notice ),
				self::finance_url( $student_id )
			)
		);
		exit;
	}
}
