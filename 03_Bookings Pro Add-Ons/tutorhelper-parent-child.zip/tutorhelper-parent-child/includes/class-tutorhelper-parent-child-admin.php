<?php
/**
 * Parent Account administration.
 *
 * @package TutorHelper_Parent_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds the Parent Accounts workspace to the TutorHelper Booking Hub.
 */
final class TutorHelper_Parent_Child_Admin {

	/** Booking Hub tab identifier. */
	const TAB_KEY = 'parent-accounts';

	/** Parent Accounts shown on each list page. */
	const PER_PAGE = 20;

	/** Parent account update action. */
	const UPDATE_ACTION = 'tutorhelper_parent_account_update';

	/**
	 * Register administration hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter(
			'tutorhelper_booking_hub_tabs',
			array( __CLASS__, 'register_tab' )
		);

		add_action(
			'tutorhelper_booking_hub_render_tab',
			array( __CLASS__, 'render_tab' ),
			10,
			2
		);

		add_action( 'admin_post_' . self::UPDATE_ACTION, array( __CLASS__, 'handle_parent_update' ) );
		add_filter(
			'tutorhelper_pro_finance_parent_student_ids_for_search',
			array( __CLASS__, 'filter_finance_student_ids_by_parent' ),
			10,
			2
		);
	}

	/**
	 * Add the Parent Accounts tab.
	 *
	 * @param array $tabs Booking Hub tabs.
	 * @return array
	 */
	public static function register_tab( $tabs ) {
		if ( ! is_array( $tabs ) ) {
			return $tabs;
		}

		$tabs[ self::TAB_KEY ] = array(
			'label'       => __( 'Parent Accounts', 'tutorhelper-parent-child' ),
			'icon'        => 'dashicons-groups',
			'status'      => 'available',
			'description' => __( 'Review parents and guardians and the students linked to them.', 'tutorhelper-parent-child' ),
		);

		return $tabs;
	}

	/**
	 * Render the Parent Accounts workspace.
	 *
	 * @param string $selected_tab Selected Booking Hub tab.
	 * @param array  $active_tab   Active tab definition.
	 * @return void
	 */
	public static function render_tab( $selected_tab, $active_tab ) {
		unset( $active_tab );

		if (
			self::TAB_KEY !== $selected_tab
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$parent_user_id = isset( $_GET['parent_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing.
			? absint( $_GET['parent_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing.
			: 0;

		if ( $parent_user_id ) {
			self::render_parent_details( $parent_user_id );
			return;
		}

		self::render_parent_list();
	}

	/** Render the searchable Parent Account list. */
	private static function render_parent_list() {
		$search = isset( $_GET['s'] ) && ! is_array( $_GET['s'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only list filter.
			? sanitize_text_field( wp_unslash( $_GET['s'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only list filter.
			: '';
		$page   = isset( $_GET['paged'] ) && ! is_array( $_GET['paged'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only pagination.
			? max( 1, absint( $_GET['paged'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only pagination.
			: 1;

		$args = array(
			'role'        => TutorHelper_Roles::PARENT_ROLE,
			'number'      => self::PER_PAGE,
			'paged'       => $page,
			'orderby'     => 'display_name',
			'order'       => 'ASC',
			'count_total' => true,
		);

		if ( '' !== $search ) {
			$args['search']         = '*' . $search . '*';
			$args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
		}

		$query   = new WP_User_Query( $args );
		$parents = $query->get_results();
		?>
		<div class="tutorhelper-parent-accounts">
			<section class="tutorhelper-parent-accounts__intro">
				<h2><?php esc_html_e( 'Parent Accounts', 'tutorhelper-parent-child' ); ?></h2>
				<p><?php esc_html_e( 'Manage linked parent and guardian accounts, contact details and account access.', 'tutorhelper-parent-child' ); ?></p>
			</section>
			<section class="tutorhelper-students-panel">
				<header class="tutorhelper-students-panel__header tutorhelper-parent-accounts__header">
					<div>
						<h2><?php esc_html_e( 'Parent Accounts', 'tutorhelper-parent-child' ); ?></h2>
						<p><?php esc_html_e( 'Open an account to review every student linked to that parent or guardian.', 'tutorhelper-parent-child' ); ?></p>
					</div>
					<a class="button button-primary" href="<?php echo esc_url( self::students_url() ); ?>">
						<?php esc_html_e( 'Manage student links', 'tutorhelper-parent-child' ); ?>
					</a>
				</header>

				<div class="tutorhelper-students-panel__body">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="tutorhelper-parent-accounts__search">
						<input type="hidden" name="page" value="<?php echo esc_attr( TutorHelper_Booking_Hub::PAGE_SLUG ); ?>" />
						<input type="hidden" name="tab" value="<?php echo esc_attr( self::TAB_KEY ); ?>" />
						<label class="screen-reader-text" for="tutorhelper-parent-account-search"><?php esc_html_e( 'Search Parent Accounts', 'tutorhelper-parent-child' ); ?></label>
						<input id="tutorhelper-parent-account-search" name="s" type="search" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php echo esc_attr__( 'Search name, username or email', 'tutorhelper-parent-child' ); ?>" />
						<button type="submit" class="button"><?php esc_html_e( 'Search', 'tutorhelper-parent-child' ); ?></button>
					</form>

					<?php if ( empty( $parents ) ) : ?>
						<div class="tutorhelper-parent-accounts__empty">
							<h3><?php esc_html_e( 'No Parent Accounts found', 'tutorhelper-parent-child' ); ?></h3>
							<p><?php esc_html_e( 'Create or link a Parent Account from a student’s details screen.', 'tutorhelper-parent-child' ); ?></p>
						</div>
					<?php else : ?>
						<div class="tutorhelper-parent-accounts__table-wrap">
							<table class="widefat striped tutorhelper-parent-accounts__table">
								<thead>
									<tr>
										<th scope="col"><?php esc_html_e( 'Parent / guardian', 'tutorhelper-parent-child' ); ?></th>
										<th scope="col"><?php esc_html_e( 'Email', 'tutorhelper-parent-child' ); ?></th>
										<th scope="col"><?php esc_html_e( 'Linked students', 'tutorhelper-parent-child' ); ?></th>
										<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'tutorhelper-parent-child' ); ?></span></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $parents as $parent ) : ?>
										<?php $students = TutorHelper_Student_Parent_Links::get_students( $parent->ID ); ?>
										<tr>
											<th scope="row"><?php echo esc_html( $parent->display_name ); ?></th>
											<td>
												<a href="<?php echo esc_url( 'mailto:' . $parent->user_email ); ?>">
													<?php echo esc_html( $parent->user_email ); ?>
												</a>
											</td>
											<td><?php echo esc_html( count( $students ) ); ?></td>
											<td><a class="button button-small" href="<?php echo esc_url( self::parent_url( $parent->ID ) ); ?>"><?php esc_html_e( 'View account', 'tutorhelper-parent-child' ); ?></a></td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
						<?php self::render_pagination( $query, $page, $search ); ?>
					<?php endif; ?>
				</div>
			</section>
		</div>
		<?php
	}

	/**
	 * Render one Parent Account and its linked students.
	 *
	 * @param int $parent_user_id Parent user ID.
	 * @return void
	 */
	private static function render_parent_details( $parent_user_id ) {
		$parent = get_userdata( $parent_user_id );

		if (
			! $parent instanceof WP_User
			|| ! in_array( TutorHelper_Roles::PARENT_ROLE, (array) $parent->roles, true )
		) {
			wp_die( esc_html__( 'The Parent Account could not be found.', 'tutorhelper-parent-child' ) );
		}

		$students = TutorHelper_Student_Parent_Links::get_students( $parent_user_id );
		?>
		<?php
		$notice = isset( $_GET['parent_notice'] ) && ! is_array( $_GET['parent_notice'] )
			? sanitize_key( wp_unslash( $_GET['parent_notice'] ) )
			: '';
		?>
		<div class="tutorhelper-parent-accounts tutorhelper-parent-accounts--details">
			<section class="tutorhelper-students-panel">
				<header class="tutorhelper-students-panel__header tutorhelper-parent-accounts__header">
					<div>
						<?php echo get_avatar( $parent_user_id, 64, '', $parent->display_name, array( 'class' => 'tutorhelper-parent-accounts__avatar' ) ); ?>
						<h2><?php echo esc_html( $parent->display_name ); ?></h2>
						<p><a href="<?php echo esc_url( 'mailto:' . $parent->user_email ); ?>"><?php echo esc_html( $parent->user_email ); ?></a></p>
					</div>
					<div class="tutorhelper-parent-accounts__header-actions"><span class="tutorhelper-parent-accounts__count">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %d: number of linked students. */
								_n( '%d linked student', '%d linked students', count( $students ), 'tutorhelper-parent-child' ),
								count( $students )
							)
						);
						?>
					</span><a class="button" href="<?php echo esc_url( self::list_url() ); ?>">&larr; <?php esc_html_e( 'Back to Parent Accounts', 'tutorhelper-parent-child' ); ?></a></div>
				</header>

				<div class="tutorhelper-students-panel__body">
					<?php if ( $notice ) : ?>
						<div class="notice notice-success inline"><p><?php echo esc_html__( 'Parent account updated.', 'tutorhelper-parent-child' ); ?></p></div>
					<?php endif; ?>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-parent-account-form">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::UPDATE_ACTION ); ?>" />
						<input type="hidden" name="parent_id" value="<?php echo esc_attr( $parent_user_id ); ?>" />
						<input type="text" name="username" value="<?php echo esc_attr( $parent->user_login ); ?>" class="tutorhelper-password-username" autocomplete="username" tabindex="-1" aria-hidden="true" />
						<?php wp_nonce_field( self::UPDATE_ACTION . '_' . $parent_user_id ); ?>

						<div class="tutorhelper-parent-account-form__grid">
							<label>
								<span><?php esc_html_e( 'First name', 'tutorhelper-parent-child' ); ?></span>
								<input class="regular-text" type="text" name="first_name" value="<?php echo esc_attr( $parent->first_name ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Last name', 'tutorhelper-parent-child' ); ?></span>
								<input class="regular-text" type="text" name="last_name" value="<?php echo esc_attr( $parent->last_name ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Display name', 'tutorhelper-parent-child' ); ?></span>
								<input class="regular-text" type="text" name="display_name" value="<?php echo esc_attr( $parent->display_name ); ?>" required />
							</label>
							<label>
								<span><?php esc_html_e( 'Email address', 'tutorhelper-parent-child' ); ?></span>
								<input class="regular-text" type="email" name="user_email" value="<?php echo esc_attr( $parent->user_email ); ?>" required />
							</label>
							<label>
								<span><?php esc_html_e( 'New password (optional)', 'tutorhelper-parent-child' ); ?></span>
								<div class="tutorhelper-password-control">
									<input class="regular-text" id="tutorhelper-parent-new-password" type="password" name="new_password" autocomplete="new-password" minlength="12" />
									<button type="button" class="tutorhelper-password-toggle" aria-controls="tutorhelper-parent-new-password" aria-pressed="false" data-show-label="<?php esc_attr_e( 'Show password', 'tutorhelper-parent-child' ); ?>" data-hide-label="<?php esc_attr_e( 'Hide password', 'tutorhelper-parent-child' ); ?>"><?php esc_html_e( 'Show password', 'tutorhelper-parent-child' ); ?></button>
								</div>
							</label>
						</div>

						<div class="tutorhelper-parent-account-form__actions">
							<button type="submit" name="parent_operation" value="save" class="button button-primary"><?php esc_html_e( 'Save parent details', 'tutorhelper-parent-child' ); ?></button>
							<button type="submit" name="parent_operation" value="send_reset" class="button"><?php esc_html_e( 'Send password reset email', 'tutorhelper-parent-child' ); ?></button>
						</div>
					</form>

					<h3><?php esc_html_e( 'Linked students', 'tutorhelper-parent-child' ); ?></h3>
					<?php if ( empty( $students ) ) : ?>
						<p><?php esc_html_e( 'This Parent Account is not currently linked to a student.', 'tutorhelper-parent-child' ); ?></p>
					<?php else : ?>
						<div class="tutorhelper-parent-accounts__student-grid">
							<?php foreach ( $students as $relationship ) : ?>
								<article class="tutorhelper-parent-accounts__student-card">
									<div>
										<h4><?php echo esc_html( $relationship->display_name ); ?></h4>
										<p><?php echo esc_html( $relationship->relationship_label ); ?></p>
									</div>
									<?php if ( 1 === absint( $relationship->is_primary ) ) : ?>
										<span class="tutorhelper-parent-accounts__primary"><?php esc_html_e( 'Primary contact', 'tutorhelper-parent-child' ); ?></span>
									<?php endif; ?>
									<a class="button" href="<?php echo esc_url( self::student_url( $relationship->student_user_id ) ); ?>"><?php esc_html_e( 'Open student details', 'tutorhelper-parent-child' ); ?></a>
								</article>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			</section>
		</div>
		<?php
	}

	/** Render list pagination. */
	private static function render_pagination( $query, $page, $search ) {
		$total_pages = (int) ceil( $query->get_total() / self::PER_PAGE );

		if ( $total_pages < 2 ) {
			return;
		}

		$base = add_query_arg(
			array(
				'page'  => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab'   => self::TAB_KEY,
				's'     => $search,
				'paged' => '%#%',
			),
			admin_url( 'admin.php' )
		);

		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo wp_kses_post(
			paginate_links(
				array(
					'base'      => $base,
					'format'    => '',
					'current'   => $page,
					'total'     => $total_pages,
					'prev_text' => __( '&laquo; Previous', 'tutorhelper-parent-child' ),
					'next_text' => __( 'Next &raquo;', 'tutorhelper-parent-child' ),
				)
			)
		);
		echo '</div></div>';
	}

	/** Return the Parent Account list URL. */
	private static function list_url() {
		return add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab'  => self::TAB_KEY,
			),
			admin_url( 'admin.php' )
		);
	}

	/** Return one Parent Account detail URL. */
	private static function parent_url( $parent_user_id ) {
		return add_query_arg( 'parent_id', absint( $parent_user_id ), self::list_url() );
	}

	/** Return the Core Students workspace URL. */
	private static function students_url() {
		return add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab'  => TutorHelper_Students_Admin::TAB_KEY,
			),
			admin_url( 'admin.php' )
		);
	}

	/** Return one Core Student Details URL. */
	private static function student_url( $student_user_id ) {
		return add_query_arg( 'student_id', absint( $student_user_id ), self::students_url() );
	}

	/**
	 * Save a Parent Account or send its password reset email.
	 *
	 * @return void
	 */
	public static function handle_parent_update() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update Parent Accounts.', 'tutorhelper-parent-child' ) );
		}

		$parent_id = isset( $_POST['parent_id'] ) && ! is_array( $_POST['parent_id'] )
			? absint( $_POST['parent_id'] )
			: 0;
		check_admin_referer( self::UPDATE_ACTION . '_' . $parent_id );

		$parent = $parent_id ? get_userdata( $parent_id ) : false;
		if ( ! $parent instanceof WP_User || ! in_array( TutorHelper_Roles::PARENT_ROLE, (array) $parent->roles, true ) ) {
			wp_die( esc_html__( 'The Parent Account could not be found.', 'tutorhelper-parent-child' ) );
		}

		$operation = isset( $_POST['parent_operation'] ) && ! is_array( $_POST['parent_operation'] )
			? sanitize_key( wp_unslash( $_POST['parent_operation'] ) )
			: 'save';

		if ( 'send_reset' === $operation ) {
			$result = retrieve_password( $parent->user_login );
			if ( is_wp_error( $result ) ) {
				wp_die( esc_html( $result->get_error_message() ) );
			}
			wp_safe_redirect( add_query_arg( 'parent_notice', 'reset_sent', self::parent_url( $parent_id ) ) );
			exit;
		}

		$user_data = array(
			'ID' => $parent_id,
			'first_name' => isset( $_POST['first_name'] ) && ! is_array( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '',
			'last_name' => isset( $_POST['last_name'] ) && ! is_array( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '',
			'display_name' => isset( $_POST['display_name'] ) && ! is_array( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '',
			'user_email' => isset( $_POST['user_email'] ) && ! is_array( $_POST['user_email'] ) ? sanitize_email( wp_unslash( $_POST['user_email'] ) ) : '',
		);
		$password = isset( $_POST['new_password'] ) && ! is_array( $_POST['new_password'] )
			? (string) wp_unslash( $_POST['new_password'] )
			: '';
		if ( '' !== $password ) {
			$user_data['user_pass'] = $password;
		}

		$result = wp_update_user( $user_data );
		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ) );
		}

		wp_safe_redirect( add_query_arg( 'parent_notice', 'saved', self::parent_url( $parent_id ) ) );
		exit;
	}

	/**
	 * Include children whose parent name or email matches a Finance search.
	 *
	 * @param array  $student_ids Existing matching student IDs.
	 * @param string $search      Search term.
	 * @return array
	 */
	public static function filter_finance_student_ids_by_parent( $student_ids, $search ) {
		$query = new WP_User_Query(
			array(
				'role' => TutorHelper_Roles::PARENT_ROLE,
				'fields' => 'ids',
				'search' => '*' . sanitize_text_field( $search ) . '*',
				'search_columns' => array( 'user_login', 'user_email', 'display_name' ),
			)
		);
		foreach ( $query->get_results() as $parent_id ) {
			foreach ( TutorHelper_Student_Parent_Links::get_students( absint( $parent_id ) ) as $relationship ) {
				$student_ids[] = absint( $relationship->student_user_id );
			}
		}
		return array_values( array_unique( array_filter( array_map( 'absint', $student_ids ) ) ) );
	}

}
