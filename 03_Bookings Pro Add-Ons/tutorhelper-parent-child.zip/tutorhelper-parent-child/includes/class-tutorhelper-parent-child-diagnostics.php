<?php
/**
 * TutorHelper Parent & Child diagnostics.
 *
 * @package TutorHelper_Parent_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds privacy-conscious add-on checks to the Core system report.
 */
final class TutorHelper_Parent_Child_Diagnostics {

	/**
	 * Register diagnostic filters.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter(
			'tutorhelper_system_report_data',
			array( __CLASS__, 'add_system_report_section' )
		);
	}

	/**
	 * Add a Parent & Child section without exposing user data.
	 *
	 * @param array $report Core system report.
	 * @return array
	 */
	public static function add_system_report_section( $report ) {
		if ( ! is_array( $report ) ) {
			$report = array();
		}

		$table_available = false;

		if ( class_exists( 'TutorHelper_Student_Parent_Links' ) ) {
			$table_available = TutorHelper_Student_Parent_Links::table_exists();
		}

		$report['parent_child'] = array(
			'label' => __( 'Parent & Child', 'tutorhelper-parent-child' ),
			'items' => array(
				'plugin_version' => TUTORHELPER_PARENT_CHILD_VERSION,
				'core_available' => self::yes_no(
					TutorHelper_Parent_Child_Dependency::core_is_available()
				),
				'pro_available' => self::yes_no(
					TutorHelper_Parent_Child_Dependency::pro_is_available()
				),
				'pro_licensed' => self::yes_no(
					TutorHelper_Parent_Child_Dependency::pro_is_licensed()
				),
				'relationship_table' => self::yes_no( $table_available ),
				'parent_role' => self::yes_no(
					(bool) get_role( TutorHelper_Roles::PARENT_ROLE )
				),
				'group_bookings' => self::yes_no(
					class_exists( 'TutorHelper_Group_Bookings' )
				),
			),
		);

		return $report;
	}

	/**
	 * Format a diagnostic boolean consistently.
	 *
	 * @param bool $value Value to format.
	 * @return string
	 */
	private static function yes_no( $value ) {
		return $value
			? __( 'Yes', 'tutorhelper-parent-child' )
			: __( 'No', 'tutorhelper-parent-child' );
	}
}
