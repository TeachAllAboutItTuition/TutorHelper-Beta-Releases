<?php
/**
 * TutorHelper Parent & Child uninstall routine.
 *
 * Parent-student relationships are owned by TutorHelper Core and are
 * deliberately retained when this optional presentation add-on is removed.
 *
 * @package TutorHelper_Parent_Child
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'tutorhelper_parent_child_version' );
