( function () {
	'use strict';

	function normalise( value ) {
		return String( value || '' ).toLocaleLowerCase();
	}

	function initialise( report ) {
		var rows = Array.prototype.slice.call( report.querySelectorAll( '[data-thpc-row]' ) );
		var filters = Array.prototype.slice.call( report.querySelectorAll( '[data-thpc-filter]' ) );
		var reset = report.querySelector( '[data-thpc-reset]' );
		var count = report.querySelector( '[data-thpc-count]' );
		var empty = report.querySelector( '[data-thpc-empty]' );
		var previous = report.querySelector( '[data-thpc-previous]' );
		var next = report.querySelector( '[data-thpc-next]' );
		var pageStatus = report.querySelector( '[data-thpc-page-status]' );
		var sortButtons = Array.prototype.slice.call( report.querySelectorAll( '[data-thpc-sort]' ) );
		var pageSize = parseInt( report.getAttribute( 'data-page-size' ), 10 ) || 10;
		var page = 1;
		var sortKey = 'date';
		var sortDirection = report.getAttribute( 'data-default-sort' ) || 'desc';

		function matches( row ) {
			return filters.every( function ( field ) {
				var value = normalise( field.value );
				var key = field.getAttribute( 'data-thpc-filter' );
				var actual = normalise( row.getAttribute( 'data-' + key ) );
				if ( ! value ) {
					return true;
				}
				if ( 'from' === key ) {
					return normalise( row.getAttribute( 'data-date' ) ) >= value;
				}
				if ( 'to' === key ) {
					return normalise( row.getAttribute( 'data-date' ) ) <= value;
				}
				if ( 'content' === key ) {
					return actual.split( /\s+/ ).includes( value );
				}

				return actual === value;
			} );
		}

		function compare( a, b ) {
			var left = normalise( a.getAttribute( 'data-' + sortKey ) );
			var right = normalise( b.getAttribute( 'data-' + sortKey ) );
			var result = left.localeCompare( right, undefined, { numeric: true } );
			return 'asc' === sortDirection ? result : -result;
		}

		function render() {
			var visible = rows.filter( matches ).sort( compare );
			var pages = Math.max( 1, Math.ceil( visible.length / pageSize ) );
			page = Math.min( page, pages );
			rows.forEach( function ( row ) { row.hidden = true; } );
			visible.slice( ( page - 1 ) * pageSize, page * pageSize ).forEach( function ( row ) {
				row.hidden = false;
				if ( empty && empty.parentNode === row.parentNode ) {
					row.parentNode.insertBefore( row, empty );
				} else {
					row.parentNode.appendChild( row );
				}
			} );
			if ( count ) {
				count.textContent = 1 === visible.length ? '1 item shown' : visible.length + ' items shown';
			}
			if ( empty ) {
				empty.hidden = 0 !== visible.length;
			}
			if ( previous ) {
				previous.disabled = page <= 1;
				previous.parentNode.hidden = pages <= 1;
			}
			if ( next ) {
				next.disabled = page >= pages;
			}
			if ( pageStatus ) {
				pageStatus.textContent = 'Page ' + page + ' of ' + pages;
			}
		}

		filters.forEach( function ( field ) {
			field.addEventListener( 'change', function () { page = 1; render(); } );
		} );
		if ( reset ) {
			reset.addEventListener( 'click', function () {
				filters.forEach( function ( field ) { field.value = ''; } );
				page = 1;
				render();
			} );
		}
		sortButtons.forEach( function ( button ) {
			button.addEventListener( 'click', function () {
				var nextKey = button.getAttribute( 'data-thpc-sort' );
				sortDirection = nextKey === sortKey && 'asc' === sortDirection ? 'desc' : 'asc';
				sortKey = nextKey;
				sortButtons.forEach( function ( item ) { item.closest( 'th' ).setAttribute( 'aria-sort', 'none' ); } );
				button.closest( 'th' ).setAttribute( 'aria-sort', 'asc' === sortDirection ? 'ascending' : 'descending' );
				page = 1;
				render();
			} );
		} );
		if ( previous ) {
			previous.addEventListener( 'click', function () { if ( page > 1 ) { page--; render(); } } );
		}
		if ( next ) {
			next.addEventListener( 'click', function () { page++; render(); } );
		}
		render();
	}

	window.TutorHelperParentReportsInitialise = initialise;

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '[data-thpc-report]' ).forEach( initialise );
	} );
}() );


/**
 * PC5 invoice selection controls.
 */
( function () {
	'use strict';

	function initialiseFinance( form ) {
		var items = Array.prototype.slice.call(
			form.querySelectorAll( '[data-thpc-finance-item]' )
		);
		var selectAll = form.querySelector( '[data-thpc-select-all]' );
		var actions = Array.prototype.slice.call(
			form.querySelectorAll( '[data-thpc-selection-action]' )
		);
		var total = form.querySelector( '[data-thpc-selected-total]' );

		function renderSelection() {
			var selected = items.filter( function ( item ) {
				return item.checked;
			} );
			var minorTotal = selected.reduce( function ( sum, item ) {
				return sum + ( parseInt( item.getAttribute( 'data-balance' ), 10 ) || 0 );
			}, 0 );

			actions.forEach( function ( action ) {
				action.disabled = 0 === selected.length;
			} );

			if ( selectAll ) {
				selectAll.checked = items.length > 0 && selected.length === items.length;
				selectAll.indeterminate = selected.length > 0 && selected.length < items.length;
			}

			if ( total ) {
				var currency = total.getAttribute( 'data-currency' ) || 'GBP';
				var factor = parseInt( total.getAttribute( 'data-factor' ), 10 ) || 100;
				try {
					total.textContent = new Intl.NumberFormat( undefined, {
						style: 'currency',
						currency: currency
					} ).format( minorTotal / factor );
				} catch ( error ) {
					total.textContent = currency + ' ' + ( minorTotal / factor ).toFixed( 2 );
				}
			}
		}

		items.forEach( function ( item ) {
			item.addEventListener( 'change', renderSelection );
		} );

		if ( selectAll ) {
			selectAll.addEventListener( 'change', function () {
				items.forEach( function ( item ) {
					item.checked = selectAll.checked;
				} );
				renderSelection();
			} );
		}

		renderSelection();
	}

	window.TutorHelperParentFinanceInitialise = initialiseFinance;

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '[data-thpc-finance-form]' ).forEach( initialiseFinance );
	} );
}() );


/**
 * Parent dashboard navigation updates only the selected content panel.
 */
( function () {
	'use strict';

	function initialiseNavigation( dashboard ) {
		var content = dashboard.querySelector(
			'.tutorhelper-parent-dashboard__content'
		);
		var contentCache = {};

		if ( ! content ) {
			return;
		}

		function getCacheKey( url ) {
			return new window.URL( url, window.location.origin ).href;
		}

		function setActiveNavigation( activeLink ) {
			dashboard.querySelectorAll(
				'.tutorhelper-parent-dashboard__nav a'
			).forEach( function ( item ) {
				if ( item === activeLink ) {
					item.setAttribute( 'aria-current', 'page' );
				} else {
					item.removeAttribute( 'aria-current' );
				}
			} );
		}

		function replaceContent( html, link ) {
			content.innerHTML = html;
			setActiveNavigation( link );
			window.history.pushState( {}, '', link.href );
			content.dispatchEvent(
				new window.CustomEvent(
					'tutorhelper:parent-content-updated',
					{ bubbles: true }
				)
			);
		}

		dashboard.querySelectorAll(
			'.tutorhelper-parent-dashboard__nav a'
		).forEach( function ( link ) {
			link.addEventListener( 'click', function ( event ) {
				var targetKey;

				if (
					event.defaultPrevented
					|| event.metaKey
					|| event.ctrlKey
					|| event.shiftKey
					|| event.altKey
				) {
					return;
				}

				event.preventDefault();
				contentCache[ getCacheKey( window.location.href ) ] = content.innerHTML;
				targetKey = getCacheKey( link.href );
				content.setAttribute( 'aria-busy', 'true' );

				if ( Object.prototype.hasOwnProperty.call( contentCache, targetKey ) ) {
					replaceContent( contentCache[ targetKey ], link );
					content.removeAttribute( 'aria-busy' );
					return;
				}

				window.fetch( link.href, {
					credentials: 'same-origin',
					cache: 'no-store'
				} )
					.then( function ( response ) {
						if ( ! response.ok ) {
							throw new Error( 'Parent dashboard content could not be loaded.' );
						}

						return response.text();
					} )
					.then( function ( html ) {
						var documentFragment = new window.DOMParser()
							.parseFromString( html, 'text/html' );
						var replacement = documentFragment.querySelector(
							'.tutorhelper-parent-dashboard__content'
						);

						if ( ! replacement ) {
							throw new Error( 'Parent dashboard content was unavailable.' );
						}

						contentCache[ targetKey ] = replacement.innerHTML;
						replaceContent( replacement.innerHTML, link );
					} )
					.catch( function () {
						window.location.assign( link.href );
					} )
					.finally( function () {
						content.removeAttribute( 'aria-busy' );
					} );
			} );
		} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll(
			'[data-tutorhelper-parent-dashboard]'
		).forEach( initialiseNavigation );
	} );
}() );

document.addEventListener( 'tutorhelper:parent-content-updated', function ( event ) {
	var container = event.target;

	if ( ! container || ! container.querySelectorAll ) {
		return;
	}

	container.querySelectorAll( '[data-thpc-report]' ).forEach(
		window.TutorHelperParentReportsInitialise || function () {}
	);
	container.querySelectorAll( '[data-thpc-finance-form]' ).forEach(
		window.TutorHelperParentFinanceInitialise || function () {}
	);
	container.querySelectorAll( '[data-tutorhelper-student-booking]' ).forEach(
		window.TutorHelperStudentBookingInitialise || function () {}
	);
	container.querySelectorAll( '[data-tutorhelper-student-booking]' ).forEach(
		window.TutorHelperStudentPaymentMethodsInitialise || function () {}
	);
	container.querySelectorAll( '[data-tutorhelper-student-booking]' ).forEach(
		window.TutorHelperGroupStudentInitialise || function () {}
	);
} );
