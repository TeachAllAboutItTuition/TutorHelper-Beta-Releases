<?php
/**
 * Plugin Name:       TutorHelper LMS
 * Plugin URI:        https://tutorhelper.co.uk/
 * Description:       Learning content, courses and lesson organisation for TutorHelper Bookings.
 * Version:           1.0.59
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Requires Plugins:  tutorhelper-bookings
 * Author:            Holly Billinghurst
 * Author URI:        https://tutorhelper.co.uk/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tutorhelper-lms
 * Domain Path:       /languages
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TUTORHELPER_LMS_VERSION', '1.0.61' );
define( 'TUTORHELPER_LMS_FREE_DB_VERSION', '1.0.24' );
define( 'TUTORHELPER_LMS_FILE', __FILE__ );
define( 'TUTORHELPER_LMS_PATH', plugin_dir_path( TUTORHELPER_LMS_FILE ) );
define( 'TUTORHELPER_LMS_URL', plugin_dir_url( TUTORHELPER_LMS_FILE ) );

require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-dependency.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-learning.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-database.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-diagnostics.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-course-settings.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-course-enrolments.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-course-builder.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-learning-library.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-question-bank.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-import.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-quiz-builder.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-quiz-attempts.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-resource-library.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-grade-systems.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-student-academic-context.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-learner-access.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-learner-grants.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-learner-notes.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-learner-annotations.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-learner-progress.php';
require_once TUTORHELPER_LMS_PATH . 'includes/class-tutorhelper-lms-learning-hub.php';

if ( is_admin() ) {
	TutorHelper_LMS_Learning_Hub::init();
	TutorHelper_LMS_Grade_Systems::init();
	TutorHelper_LMS_Student_Academic_Context::init();
	add_action( 'admin_notices', array( 'TutorHelper_LMS_Dependency', 'render_notice' ) );
}

register_activation_hook(
	TUTORHELPER_LMS_FILE,
	static function() {
		if ( TutorHelper_LMS_Dependency::is_available() ) {
			TutorHelper_LMS_Learning::register_content_types();
			TutorHelper_LMS_Free_Database::install_or_upgrade();
		}
	}
);

add_action(
	'plugins_loaded',
	static function() {
		if ( TutorHelper_LMS_Dependency::is_available() ) {
			TutorHelper_LMS_Learning::init();
			TutorHelper_LMS_Course_Settings::init();
			TutorHelper_LMS_Course_Builder::init();
			TutorHelper_LMS_Learning_Library::init();
			TutorHelper_LMS_Question_Bank::init();
			TutorHelper_LMS_Import::init();
			TutorHelper_LMS_Quiz_Builder::init();
			TutorHelper_LMS_Resource_Library::init();
			TutorHelper_LMS_Learner_Access::init();
			TutorHelper_LMS_Learner_Grants::init();
			TutorHelper_LMS_Learner_Notes::init();
			TutorHelper_LMS_Learner_Annotations::init();
			TutorHelper_LMS_Learner_Progress::init();
			TutorHelper_LMS_Free_Database::maybe_upgrade();
		}
	},
	30
);
