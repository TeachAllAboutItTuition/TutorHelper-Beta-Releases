(function () {
	'use strict';
	var config = window.tutorhelperLmsCourseBuilder;
	if (!config) { return; }

	function announce(container, message) {
		var status = container.querySelector('[data-tutorhelper-lms-content-status]');
		if (!status) {
			status = document.createElement('p');
			status.className = 'tutorhelper-lms-course-builder__content-status';
			status.setAttribute('role', 'status');
			status.setAttribute('data-tutorhelper-lms-content-status', '');
			container.appendChild(status);
		}
		status.textContent = message;
	}

	function saveOrder(container, list) {
		var ids = Array.prototype.map.call(list.querySelectorAll(':scope > [data-tutorhelper-lms-sortable-item]'), function (item) { return item.getAttribute('data-child-id'); });
		var data = new URLSearchParams();
		data.append('action', 'tutorhelper_lms_reorder_course_content');
		data.append('nonce', config.nonce);
		data.append('course_id', container.getAttribute('data-course-id'));
		data.append('parent_type', list.getAttribute('data-parent-type'));
		data.append('parent_id', list.getAttribute('data-parent-id'));
		data.append('child_type', list.getAttribute('data-child-type'));
		ids.forEach(function (id) { data.append('ordered_ids[]', id); });
		fetch(config.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: data.toString() })
			.then(function (response) { return response.json(); })
			.then(function (result) { announce(container, result && result.success ? result.data.message : 'The order could not be saved. Refresh and try again.'); })
			.catch(function () { announce(container, 'The order could not be saved. Refresh and try again.'); });
	}

	document.addEventListener('DOMContentLoaded', function () {
		Array.prototype.forEach.call(document.querySelectorAll('[data-tutorhelper-lms-course-content]'), function (container) {
			function setTopicCollapsed(topic, collapsed) {
				var toggle = topic.querySelector('[data-tutorhelper-lms-topic-toggle]');
				topic.classList.toggle('is-collapsed', collapsed);
				if (toggle) {
					toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
					toggle.setAttribute('aria-label', collapsed ? 'Expand topic' : 'Collapse topic');
					toggle.title = collapsed ? 'Expand topic' : 'Collapse topic';
					var icon = toggle.querySelector('.dashicons');
					if (icon) { icon.className = 'dashicons ' + (collapsed ? 'dashicons-arrow-down-alt2' : 'dashicons-arrow-up-alt2'); }
				}
			}
			Array.prototype.forEach.call(container.querySelectorAll('[data-tutorhelper-lms-topic-toggle]'), function (toggle) {
				toggle.addEventListener('click', function () { setTopicCollapsed(toggle.closest('.tutorhelper-lms-course-builder__topic'), !toggle.closest('.tutorhelper-lms-course-builder__topic').classList.contains('is-collapsed')); });
			});
			Array.prototype.forEach.call(container.querySelectorAll('[data-tutorhelper-lms-collapse-topics], [data-tutorhelper-lms-expand-topics]'), function (button) {
				button.addEventListener('click', function () {
					var collapse = button.hasAttribute('data-tutorhelper-lms-collapse-topics');
					Array.prototype.forEach.call(container.querySelectorAll('.tutorhelper-lms-course-builder__topic'), function (topic) { setTopicCollapsed(topic, collapse); });
				});
			});
			function refreshActivityMoveControls(list) {
				if (!list || list.getAttribute('data-parent-type') !== 'course_topic_activities') { return; }
				var items = Array.prototype.slice.call(list.querySelectorAll(':scope > [data-tutorhelper-lms-sortable-item]'));
				items.forEach(function (item, index) {
					var up = item.querySelector('.tutorhelper-lms-course-builder__activity-move-up');
					var down = item.querySelector('.tutorhelper-lms-course-builder__activity-move-down');
					if (up) { up.hidden = index === 0; }
					if (down) { down.hidden = index === items.length - 1; }
				});
			}
			Array.prototype.forEach.call(container.querySelectorAll('.tutorhelper-lms-course-builder__activity-move-up, .tutorhelper-lms-course-builder__activity-move-down'), function (form) {
				form.addEventListener('submit', function (event) {
					event.preventDefault();
					var item = form.closest('[data-tutorhelper-lms-sortable-item]');
					var list = item ? item.parentElement : null;
					if (!item || !list) { return; }
					if (form.classList.contains('tutorhelper-lms-course-builder__activity-move-up') && item.previousElementSibling) { list.insertBefore(item, item.previousElementSibling); }
					if (form.classList.contains('tutorhelper-lms-course-builder__activity-move-down') && item.nextElementSibling) { list.insertBefore(item.nextElementSibling, item); }
					refreshActivityMoveControls(list);
					saveOrder(container, list);
				});
			});
			var dragged = null;
			Array.prototype.forEach.call(container.querySelectorAll('[data-tutorhelper-lms-drag-handle]'), function (handle) {
				handle.addEventListener('dragstart', function (event) {
					dragged = handle.closest('[data-tutorhelper-lms-sortable-item]');
					if (!dragged) { event.preventDefault(); return; }
					dragged.classList.add('is-dragging');
					event.dataTransfer.effectAllowed = 'move';
				});
				handle.addEventListener('dragend', function () { if (dragged) { dragged.classList.remove('is-dragging'); } Array.prototype.forEach.call(container.querySelectorAll('.is-drag-over'), function (list) { list.classList.remove('is-drag-over'); }); dragged = null; });
			});
			Array.prototype.forEach.call(container.querySelectorAll('[data-tutorhelper-lms-sortable-list]'), function (list) {
				list.addEventListener('dragover', function (event) {
					if (!dragged || dragged.parentElement !== list) { return; }
					event.preventDefault(); list.classList.add('is-drag-over');
					var after = Array.prototype.find.call(list.querySelectorAll(':scope > [data-tutorhelper-lms-sortable-item]:not(.is-dragging)'), function (item) { return event.clientY <= item.getBoundingClientRect().top + item.offsetHeight / 2; });
					if (after) { list.insertBefore(dragged, after); } else { list.appendChild(dragged); }
				});
				list.addEventListener('drop', function (event) { if (!dragged || dragged.parentElement !== list) { return; } event.preventDefault(); list.classList.remove('is-drag-over'); refreshActivityMoveControls(list); saveOrder(container, list); });
			});
			Array.prototype.forEach.call(container.querySelectorAll('[data-tutorhelper-lms-detach-form]'), function (form) { form.addEventListener('submit', function (event) { if (!window.confirm('Remove this item from this structure? The reusable item itself will not be deleted.')) { event.preventDefault(); } }); });
		});

		function bindQuizTopicModal(dialog) {
			if (!dialog || dialog.dataset.tutorhelperLmsBound) { return; }
			dialog.dataset.tutorhelperLmsBound = '1';
			var close = dialog.querySelector('[data-tutorhelper-lms-close-quiz-topic-modal]');
			if (close) { close.addEventListener('click', function (event) { event.preventDefault(); dialog.close(); if (dialog.parentNode === document.body) { dialog.remove(); } }); }
			var form = dialog.querySelector('form');
			if (form) { form.addEventListener('submit', function (event) {
				event.preventDefault();
				var submit = form.querySelector('[type="submit"]'); if (submit) { submit.disabled = true; }
				// This form includes a hidden input named "action"; use the attribute so it cannot shadow form.action.
				var formAction = form.getAttribute('action') || window.location.href;
				fetch(formAction, { method: 'POST', credentials: 'same-origin', body: new URLSearchParams(new FormData(form)), redirect: 'follow' })
					.then(function (response) {
						if (!response.ok) { throw new Error('Course Quiz options request failed.'); }
						return response.url || window.location.href;
					})
					.then(function (responseUrl) {
						// Reopen the same modal from the saved page so every field reflects the current immutable Quiz version.
						var destination = new URL(responseUrl, window.location.href);
						var topicField = form.querySelector('input[name="topic_id"]');
						var quizField = form.querySelector('input[name="content_id"]');
						if (topicField && quizField) {
							destination.searchParams.set('quiz_topic_links', quizField.value);
							destination.searchParams.set('quiz_topic_id', topicField.value);
						}
						window.location.assign(destination.toString());
					})
					.catch(function () {
						form.querySelectorAll('.notice-error.inline').forEach(function (notice) { notice.remove(); });
						var failure = document.createElement('div');
						failure.className = 'notice notice-error inline';
						failure.innerHTML = '<p>Course Quiz options could not be updated. Please refresh and try again.</p>';
						form.insertBefore(failure, form.firstChild);
					})
					.finally(function () { if (submit) { submit.disabled = false; } });
			}); }
		}
		Array.prototype.forEach.call(document.querySelectorAll('[data-tutorhelper-lms-quiz-topic-editor]'), function (dialog) {
			bindQuizTopicModal(dialog);
			if (dialog.hasAttribute('data-auto-open') && typeof dialog.showModal === 'function') { dialog.showModal(); }
		});
		document.addEventListener('click', function (event) {
			var link = event.target.closest('.tutorhelper-lms-course-builder__question-topics');
			if (!link) { return; }
			event.preventDefault();
			fetch(link.href, { credentials: 'same-origin' }).then(function (response) { return response.text(); }).then(function (html) {
				var documentResponse = new DOMParser().parseFromString(html, 'text/html');
				var dialog = documentResponse.querySelector('[data-tutorhelper-lms-quiz-topic-editor]');
				if (!dialog) { window.location.href = link.href; return; }
				document.body.appendChild(dialog); bindQuizTopicModal(dialog); if (typeof dialog.showModal === 'function') { dialog.showModal(); }
			}).catch(function () { window.location.href = link.href; });
		});

		Array.prototype.forEach.call(document.querySelectorAll('[data-tutorhelper-lms-lesson-editor]'), function (dialog) {
			if (dialog.hasAttribute('data-auto-open') && typeof dialog.showModal === 'function') { dialog.showModal(); }
			Array.prototype.forEach.call(dialog.querySelectorAll('[data-tutorhelper-lms-close-lesson-editor]'), function (button) {
				button.addEventListener('click', function () { dialog.close(); });
			});
			var imageId = dialog.querySelector('[data-tutorhelper-lms-lesson-image-id]');
			var preview = dialog.querySelector('[data-tutorhelper-lms-lesson-image-preview]');
			var choose = dialog.querySelector('[data-tutorhelper-lms-choose-lesson-image]');
			var remove = dialog.querySelector('[data-tutorhelper-lms-remove-lesson-image]');
			var frame;
			var resourceFilter = dialog.querySelector('[data-tutorhelper-lms-filter-resources]');
			var resourceSelect = dialog.querySelector('[data-tutorhelper-lms-lesson-resources]');
			if (resourceFilter && resourceSelect) {
				resourceFilter.addEventListener('input', function () {
					var term = resourceFilter.value.toLowerCase().trim();
					Array.prototype.forEach.call(resourceSelect.options, function (option) {
						var matches = !term || option.text.toLowerCase().indexOf(term) !== -1;
						option.hidden = !matches && !option.selected;
						option.disabled = !matches && !option.selected;
					});
				});
			}
			if (choose) {
				choose.addEventListener('click', function () {
					if (!window.wp || !wp.media) { return; }
					if (!frame) {
						frame = wp.media({ title: 'Choose lesson image', button: { text: 'Use image' }, multiple: false });
						frame.on('select', function () {
							var image = frame.state().get('selection').first().toJSON();
							imageId.value = image.id || '';
							if (preview) { preview.innerHTML = '<img src="' + String(image.sizes && image.sizes.medium ? image.sizes.medium.url : image.url).replace(/"/g, '&quot;') + '" alt="" />'; }
						});
					}
					frame.open();
				});
			}
			if (remove) { remove.addEventListener('click', function () { imageId.value = ''; if (preview) { preview.innerHTML = ''; } }); }
		});
	});
}());
