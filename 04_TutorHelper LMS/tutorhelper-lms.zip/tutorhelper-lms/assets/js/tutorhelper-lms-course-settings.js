( function( $ ) {
	'use strict';

	$( document ).on( 'click', '[data-tutorhelper-lms-course-image-select]', function( event ) {
		event.preventDefault();
		var control = $( this ).closest( '[data-tutorhelper-lms-course-image]' );
		var frame = wp.media( {
			title: 'Choose Course featured image',
			button: { text: 'Use featured image' },
			multiple: false,
			library: { type: 'image' }
		} );
		frame.on( 'select', function() {
			var attachment = frame.state().get( 'selection' ).first().toJSON();
			var thumbnail = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
			control.find( '[data-tutorhelper-lms-course-image-id]' ).val( attachment.id );
			control.find( '[data-tutorhelper-lms-course-image-preview]' ).html( '<img src="' + $( '<div>' ).text( thumbnail ).html() + '" alt="" />' );
			control.find( '[data-tutorhelper-lms-course-image-remove]' ).prop( 'disabled', false );
		} );
		frame.open();
	} );

	$( document ).on( 'click', '[data-tutorhelper-lms-course-image-remove]', function( event ) {
		event.preventDefault();
		var control = $( this ).closest( '[data-tutorhelper-lms-course-image]' );
		control.find( '[data-tutorhelper-lms-course-image-id]' ).val( '' );
		control.find( '[data-tutorhelper-lms-course-image-preview]' ).empty();
		$( this ).prop( 'disabled', true );
	} );
}( jQuery ) );
