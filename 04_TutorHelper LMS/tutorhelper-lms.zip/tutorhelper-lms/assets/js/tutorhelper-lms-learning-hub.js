( function( $ ) {
	'use strict';

	function text( value ) {
		return ( value || '' ).replace( /\s+/g, ' ' ).trim();
	}

	function initialiseChoicePickers( scope ) {
		$( scope ).find( '[data-tutorhelper-lms-choice-search]' ).each( function() {
			var search = this;
			var picker = search.closest( '.tutorhelper-lms-library-choice-picker' );
			if ( ! picker || search.dataset.tutorhelperLmsChoiceReady ) {
				return;
			}

			search.dataset.tutorhelperLmsChoiceReady = '1';
			var options = picker.querySelectorAll( '[data-tutorhelper-lms-choice-option]' );

			function updateVisibility() {
				var query = text( search.value ).toLowerCase();
				options.forEach( function( option ) {
					var checked = option.querySelector( 'input[type="checkbox"]' );
					var matches = text( option.textContent ).toLowerCase().indexOf( query ) !== -1;
					option.hidden = !! query && ! matches && !( checked && checked.checked );
				} );
			}

			search.addEventListener( 'input', updateVisibility );
			options.forEach( function( option ) {
				var checkbox = option.querySelector( 'input[type="checkbox"]' );
				var position = option.querySelector( '.tutorhelper-lms-library-position input' );
				if ( ! checkbox ) {
					return;
				}
				checkbox.addEventListener( 'change', function() {
					option.classList.toggle( 'is-selected', checkbox.checked );
					option.classList.toggle( 'is-not-selected', ! checkbox.checked );
					if ( position ) {
						position.disabled = ! checkbox.checked;
					}
					updateVisibility();
				} );
			} );
		} );
	}

	function makeOption( value, label ) {
		var option = document.createElement( 'option' );
		option.value = value;
		option.textContent = label;
		return option;
	}

	function initialiseTable( table, index ) {
		if ( table.dataset.tutorhelperLmsTableReady || ! table.tBodies.length ) {
			return;
		}

		var rows = Array.prototype.slice.call( table.tBodies[ 0 ].rows ).filter( function( row ) {
			return row.cells.length > 1;
		} );
		if ( ! rows.length ) {
			return;
		}

		table.dataset.tutorhelperLmsTableReady = '1';
		table.id = table.id || 'tutorhelper-lms-table-' + index;

		var headers = Array.prototype.slice.call( table.tHead ? table.tHead.rows[ 0 ].cells : [] ).map( function( cell ) {
			return text( cell.textContent ).toLowerCase();
		} );
		var statusIndex = headers.indexOf( 'status' );
		var linkedIndex = headers.indexOf( 'linked to' );
		var currentPage = 1;
		var perPage = 50;
		var searchInput = document.createElement( 'input' );
		var controls = document.createElement( 'div' );
		var summary = document.createElement( 'p' );
		var footer = document.createElement( 'div' );
		var pager = document.createElement( 'div' );
		var pageSize = document.createElement( 'select' );
		var statusFilter;
		var linkedFilter;
		var submissionKindFilter;

		controls.className = 'tutorhelper-lms-table-controls';
		controls.setAttribute( 'role', 'search' );
		searchInput.type = 'search';
		searchInput.className = 'regular-text';
		searchInput.placeholder = 'Search this table';
		searchInput.setAttribute( 'aria-label', 'Search this table' );
		controls.appendChild( searchInput );

		if ( statusIndex !== -1 ) {
			statusFilter = document.createElement( 'select' );
			statusFilter.setAttribute( 'aria-label', 'Filter by status' );
			statusFilter.appendChild( makeOption( '', 'All statuses' ) );
			if ( table.hasAttribute( 'data-tutorhelper-lms-submission-kind-table' ) ) {
				[
					[ 'marked', 'Marked' ],
					[ 'not_started', 'Not Started' ],
					[ 'awaiting_release', 'Awaiting Release' ],
					[ 'results_released', 'Results Released' ],
					[ 'submitted', 'Submitted' ]
				].forEach( function( status ) {
					statusFilter.appendChild( makeOption( status[ 0 ], status[ 1 ] ) );
				} );
			} else {
				Array.from( new Set( rows.map( function( row ) {
					return text( row.cells[ statusIndex ].textContent );
				} ).filter( Boolean ) ) ).sort().forEach( function( status ) {
					statusFilter.appendChild( makeOption( status, status ) );
				} );
			}
			controls.appendChild( statusFilter );
		}

		if ( table.hasAttribute( 'data-tutorhelper-lms-submission-kind-table' ) ) {
			submissionKindFilter = table.closest( '.tutorhelper-lms-submissions-workspace' ).querySelector( '[data-tutorhelper-lms-submission-kind-filter]' );
		}

		if ( linkedIndex !== -1 ) {
			linkedFilter = document.createElement( 'select' );
			linkedFilter.setAttribute( 'aria-label', 'Filter by attachment' );
			linkedFilter.appendChild( makeOption( '', 'All items' ) );
			linkedFilter.appendChild( makeOption( 'linked', 'Attached to a parent' ) );
			linkedFilter.appendChild( makeOption( 'unlinked', 'Not attached to a parent' ) );
			controls.appendChild( linkedFilter );
		}

		table.parentNode.insertBefore( controls, table );

		footer.className = 'tutorhelper-lms-table-footer';
		summary.className = 'tutorhelper-lms-table-summary';
		summary.setAttribute( 'aria-live', 'polite' );
		pageSize.setAttribute( 'aria-label', 'Records per page' );
		[ 25, 50, 100, 0 ].forEach( function( size ) {
			pageSize.appendChild( makeOption( String( size ), size ? size + ' per page' : 'Show all' ) );
		} );
		pageSize.value = '50';
		pager.className = 'tutorhelper-lms-table-pagination';
		footer.appendChild( summary );
		footer.appendChild( pageSize );
		footer.appendChild( pager );
		table.parentNode.insertBefore( footer, table.nextSibling );

		function filteredRows() {
			var query = text( searchInput.value ).toLowerCase();
			return rows.filter( function( row ) {
				var matchesSearch = ! query || text( row.textContent ).toLowerCase().indexOf( query ) !== -1;
				var statusValue = table.hasAttribute( 'data-tutorhelper-lms-submission-kind-table' ) ? ( row.dataset.tutorhelperLmsSubmissionStatusKey || '' ) : text( row.cells[ statusIndex ].textContent );
				var matchesStatus = ! statusFilter || ! statusFilter.value || statusValue === statusFilter.value;
				var linkedValue = linkedIndex === -1 ? '' : text( row.cells[ linkedIndex ].textContent );
				var matchesLink = ! linkedFilter || ! linkedFilter.value || ( linkedFilter.value === 'linked' ? linkedValue !== '' : linkedValue === '' );
				var matchesSubmissionKind = ! submissionKindFilter || ! submissionKindFilter.value || row.dataset.tutorhelperLmsSubmissionKind === submissionKindFilter.value;
				return matchesSearch && matchesStatus && matchesLink && matchesSubmissionKind;
			} );
		}

		function renderPagination( visibleRows ) {
			var pages = perPage ? Math.max( 1, Math.ceil( visibleRows.length / perPage ) ) : 1;
			if ( currentPage > pages ) {
				currentPage = pages;
			}
			pager.innerHTML = '';
			if ( pages <= 1 ) {
				return;
			}

			var previous = document.createElement( 'button' );
			previous.type = 'button';
			previous.className = 'button';
			previous.textContent = 'Previous';
			previous.disabled = currentPage === 1;
			previous.addEventListener( 'click', function() { currentPage--; render(); } );
			pager.appendChild( previous );

			var page = document.createElement( 'span' );
			page.textContent = 'Page ' + currentPage + ' of ' + pages;
			pager.appendChild( page );

			var next = document.createElement( 'button' );
			next.type = 'button';
			next.className = 'button';
			next.textContent = 'Next';
			next.disabled = currentPage === pages;
			next.addEventListener( 'click', function() { currentPage++; render(); } );
			pager.appendChild( next );
		}

		function render() {
			var visibleRows = filteredRows();
			var start = perPage ? ( currentPage - 1 ) * perPage : 0;
			var end = perPage ? start + perPage : visibleRows.length;

			rows.forEach( function( row ) {
				row.hidden = visibleRows.indexOf( row ) === -1 || visibleRows.indexOf( row ) < start || visibleRows.indexOf( row ) >= end;
			} );

			summary.textContent = visibleRows.length + ( visibleRows.length === 1 ? ' record found' : ' records found' );
			renderPagination( visibleRows );
		}

		searchInput.addEventListener( 'input', function() { currentPage = 1; render(); } );
		if ( statusFilter ) {
			statusFilter.addEventListener( 'change', function() { currentPage = 1; render(); } );
		}
		if ( linkedFilter ) {
			linkedFilter.addEventListener( 'change', function() { currentPage = 1; render(); } );
		}
		if ( submissionKindFilter ) {
			submissionKindFilter.addEventListener( 'change', function() { currentPage = 1; render(); } );
		}
		pageSize.addEventListener( 'change', function() {
			perPage = parseInt( pageSize.value, 10 );
			currentPage = 1;
			render();
		} );
		render();
	}

	function initialiseTables( scope ) {
		$( scope ).find( '.tutorhelper-lms-learning-hub table.widefat, .tutorhelper-lms-submissions-workspace table.widefat' ).each( function( index ) {
			initialiseTable( this, index );
		} );
	}

	function initialiseGradeSystems( scope ) {
		$( scope ).find( '[data-tutorhelper-lms-grade-system-type]' ).each( function() {
			var select = this;
			if ( select.dataset.tutorhelperLmsGradeTypeReady ) {
				return;
			}
			select.dataset.tutorhelperLmsGradeTypeReady = '1';
			var labels = select.closest( 'form' ).querySelector( '[data-tutorhelper-lms-grade-labels]' );
			function updateType() {
				if ( ! labels ) {
					return;
				}
				var percentage = select.value === 'percentage';
				labels.hidden = percentage;
				labels.querySelectorAll( 'textarea, input, select' ).forEach( function( input ) {
					input.disabled = percentage;
				} );
			}
			select.addEventListener( 'change', updateType );
			updateType();
		} );

		$( scope ).find( '[data-tutorhelper-lms-course-grade-system]' ).each( function() {
			var select = this;
			if ( select.dataset.tutorhelperLmsCourseGradeReady ) {
				return;
			}
			select.dataset.tutorhelperLmsCourseGradeReady = '1';
			var fieldset = select.closest( '.tutorhelper-lms-grade-boundaries' );
			function updateBoundaries() {
				if ( ! fieldset ) {
					return;
				}
				fieldset.querySelectorAll( '[data-tutorhelper-lms-grade-boundary-system]' ).forEach( function( system ) {
					var active = system.dataset.tutorhelperLmsGradeBoundarySystem === select.value;
					system.hidden = ! active;
					system.classList.toggle( 'is-active', active );
					system.querySelectorAll( 'input' ).forEach( function( input ) {
						input.disabled = ! active;
					} );
				} );
			}
			select.addEventListener( 'change', updateBoundaries );
			updateBoundaries();
		} );
	}

	function initialiseResourceLibrary( scope ) {
		$( scope ).find( '[data-tutorhelper-lms-resource-toggle]' ).each( function() {
			var toggle = this;
			if ( toggle.dataset.tutorhelperLmsResourceToggleReady ) {
				return;
			}
			toggle.dataset.tutorhelperLmsResourceToggleReady = '1';
			var editor = document.getElementById( toggle.getAttribute( 'aria-controls' ) );
			if ( ! editor ) {
				return;
			}
			toggle.addEventListener( 'click', function() {
				var open = editor.hasAttribute( 'hidden' );
				editor.toggleAttribute( 'hidden', ! open );
				toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
				if ( open ) {
					editor.querySelector( 'input, select, textarea, button' ).focus();
				}
			} );
		} );

		$( scope ).find( '[data-tutorhelper-lms-resource-type]' ).each( function() {
			var select = this;
			if ( select.dataset.tutorhelperLmsResourceTypeReady ) {
				return;
			}
			select.dataset.tutorhelperLmsResourceTypeReady = '1';
			var form = select.closest( 'form' );
			function updateTypeFields() {
				var type = select.value;
				form.querySelectorAll( '[data-tutorhelper-lms-resource-fields]' ).forEach( function( fields ) {
					var active = fields.dataset.tutorhelperLmsResourceFields === type;
					fields.hidden = ! active;
					fields.querySelectorAll( 'input, select, textarea' ).forEach( function( input ) {
						input.disabled = ! active;
					} );
				} );
			}
			select.addEventListener( 'change', updateTypeFields );
			updateTypeFields();
		} );

		$( scope ).find( '[data-tutorhelper-lms-resource-filter-parent]' ).each( function() {
			var childPicker = this;
			if ( childPicker.dataset.tutorhelperLmsResourceFilterReady ) {
				return;
			}
			childPicker.dataset.tutorhelperLmsResourceFilterReady = '1';
			var form = childPicker.closest( 'form' );
			var parentType = childPicker.dataset.tutorhelperLmsResourceFilterParent;
			var parentPicker = form.querySelector( '[name="' + ( parentType === 'tutorhelper_course' ? 'course_ids[]' : 'topic_ids[]' ) + '"]' );
			if ( ! parentPicker ) {
				return;
			}
			function refreshOptions() {
				var selectedParents = Array.prototype.slice.call( parentPicker.options ).filter( function( option ) {
					return option.selected;
				} ).map( function( option ) {
					return option.value;
				} );
				Array.prototype.forEach.call( childPicker.options, function( option ) {
					var parents = ( option.dataset.tutorhelperLmsResourceParentIds || '' ).split( ',' ).filter( Boolean );
					var belongsToSelectedParent = ! selectedParents.length || parents.some( function( parentId ) {
						return selectedParents.indexOf( parentId ) !== -1;
					} );
					// Preserve existing Resource relationships while editing. A filtering choice must not silently remove data.
					var visible = belongsToSelectedParent || option.selected;
					option.hidden = ! visible;
					option.disabled = ! visible;
				} );
			}
			parentPicker.addEventListener( 'change', refreshOptions );
			refreshOptions();
		} );

		$( scope ).find( '[data-tutorhelper-lms-resource-origin]' ).each( function() {
			var select = this;
			if ( select.dataset.tutorhelperLmsResourceOriginReady ) {
				return;
			}
			select.dataset.tutorhelperLmsResourceOriginReady = '1';
			var form = select.closest( 'form' );
			function updateOriginFields() {
				var thirdParty = select.value === 'third_party';
				form.querySelectorAll( '[data-tutorhelper-lms-resource-origin-fields="third_party"]' ).forEach( function( fields ) {
					fields.hidden = ! thirdParty;
					fields.querySelectorAll( 'input' ).forEach( function( input ) {
						input.disabled = ! thirdParty;
						if ( input.hasAttribute( 'data-tutorhelper-lms-third-party-confirmed' ) ) {
							input.required = thirdParty;
						}
					} );
				} );
			}
			select.addEventListener( 'change', updateOriginFields );
			updateOriginFields();
		} );
	}

	function initialiseQuizBuilder( scope ) {
		$( scope ).find( '.tutorhelper-lms-quiz-builder' ).each( function() {
			var builder = this;
			if ( builder.dataset.tutorhelperLmsQuizReady ) {
				return;
			}
			builder.dataset.tutorhelperLmsQuizReady = '1';
			var canvas = builder.querySelector( '[data-tutorhelper-lms-quiz-canvas]' );
			var library = builder.querySelector( '[data-tutorhelper-lms-quiz-library]' );
			var empty = builder.querySelector( '[data-tutorhelper-lms-quiz-empty]' );
			var search = builder.querySelector( '[data-tutorhelper-lms-quiz-search]' );
			var type = builder.querySelector( '[data-tutorhelper-lms-quiz-type]' );
			var practiceMode = builder.querySelector( '[data-tutorhelper-lms-practice-mode]' );
			var practiceSettings = builder.querySelectorAll( '[data-tutorhelper-lms-adaptive-settings]' );
			var practiceQuestionCount = builder.querySelector( '[data-tutorhelper-lms-practice-question-count]' );
			if ( ! canvas || ! library ) {
				return;
			}

			function selectedIds() {
				return Array.prototype.map.call( canvas.querySelectorAll( '[data-tutorhelper-lms-quiz-selected]' ), function( item ) { return item.dataset.questionId; } );
			}
			function refreshAdaptivePracticeSettings() {
				if ( ! practiceMode ) {
					return;
				}
				var adaptive = practiceMode.value === 'adaptive';
				Array.prototype.forEach.call( practiceSettings, function( setting ) {
					setting.hidden = ! adaptive;
					Array.prototype.forEach.call( setting.querySelectorAll( 'input, select, textarea' ), function( control ) {
						control.disabled = ! adaptive;
					} );
				} );
				if ( ! adaptive || ! practiceQuestionCount ) {
					return;
				}
				var maximum = Math.max( 1, selectedIds().length );
				var current = parseInt( practiceQuestionCount.value, 10 ) || 1;
				practiceQuestionCount.max = maximum;
				practiceQuestionCount.value = Math.min( maximum, Math.max( 1, current ) );
			}
			function refresh() {
				var selected = selectedIds();
				var total = 0;
				Array.prototype.forEach.call( canvas.querySelectorAll( '[data-tutorhelper-lms-quiz-selected]' ), function( item, index ) {
					var order = item.querySelector( 'input[name^="question_order"]' );
					if ( order ) { order.value = index + 1; }
					total += parseInt( item.dataset.questionMarks || '0', 10 ) || 0;
				} );
				var totalDisplay = builder.querySelector( '[data-tutorhelper-lms-quiz-total]' );
				if ( totalDisplay ) { totalDisplay.textContent = total; }
				if ( empty ) { empty.hidden = !! selected.length; }
				Array.prototype.forEach.call( library.querySelectorAll( '[data-tutorhelper-lms-quiz-library-question]' ), function( item ) {
					var added = selected.indexOf( item.dataset.questionId ) !== -1;
					var add = item.querySelector( '[data-tutorhelper-lms-quiz-add]' );
					item.classList.toggle( 'is-added', added );
					if ( add ) { add.disabled = added; add.textContent = added ? 'Added' : 'Add'; }
				} );
				refreshAdaptivePracticeSettings();
			}
			function selectedItem( source ) {
				var item = document.createElement( 'div' );
				item.className = 'tutorhelper-lms-quiz-builder__selected-question';
				item.draggable = true;
				item.dataset.tutorhelperLmsQuizSelected = '';
				item.dataset.questionId = source.dataset.questionId;
				item.dataset.questionVersion = source.dataset.questionVersion;
				item.dataset.questionMarks = source.dataset.questionMarks || '0';
				var move = document.createElement( 'span' );
				move.className = 'dashicons dashicons-move'; move.setAttribute( 'aria-hidden', 'true' );
				var details = document.createElement( 'div' );
				var title = document.createElement( 'strong' ); title.textContent = source.dataset.questionTitle;
				var kind = document.createElement( 'span' ); kind.textContent = source.dataset.questionLabel;
				details.appendChild( title ); details.appendChild( kind );
				var marks = document.createElement( 'span' );
				marks.className = 'tutorhelper-lms-quiz-builder__marks';
				var markCount = parseInt( item.dataset.questionMarks, 10 ) || 0;
				marks.textContent = markCount + ( markCount === 1 ? ' mark' : ' marks' );
				var actions = document.createElement( 'div' ); actions.className = 'tutorhelper-lms-quiz-builder__selected-actions';
				[ [ 'up', 'Move up', 'dashicons-arrow-up-alt2' ], [ 'down', 'Move down', 'dashicons-arrow-down-alt2' ] ].forEach( function( action ) {
					var button = document.createElement( 'button' );
					var icon = document.createElement( 'span' );
					button.type = 'button'; button.className = 'button tutorhelper-lms-button--grey tutorhelper-lms-quiz-builder__arrow'; button.dataset.tutorhelperLmsQuizMove = action[ 0 ]; button.setAttribute( 'aria-label', action[ 1 ] ); button.title = action[ 1 ];
					icon.className = 'dashicons ' + action[ 2 ]; icon.setAttribute( 'aria-hidden', 'true' ); button.appendChild( icon ); actions.appendChild( button );
				} );
				var remove = document.createElement( 'button' ); remove.type = 'button'; remove.className = 'button tutorhelper-lms-button--grey'; remove.dataset.tutorhelperLmsQuizRemove = ''; remove.textContent = 'Remove'; actions.appendChild( remove );
				[ [ 'question_ids[]', source.dataset.questionId ], [ 'question_versions[' + source.dataset.questionId + ']', source.dataset.questionVersion ], [ 'question_order[' + source.dataset.questionId + ']', '0' ] ].forEach( function( field ) {
					var input = document.createElement( 'input' ); input.type = 'hidden'; input.name = field[ 0 ]; input.value = field[ 1 ]; item.appendChild( input );
				} );
				if ( builder.dataset.tutorhelperLmsPremiumDelivery === '1' ) {
					var sectionLabel = document.createElement( 'label' );
					sectionLabel.className = 'tutorhelper-lms-quiz-builder__section-label';
					sectionLabel.appendChild( document.createTextNode( 'Section' ) );
					var sectionInput = document.createElement( 'input' );
					sectionInput.type = 'text';
					sectionInput.name = 'question_sections[' + source.dataset.questionId + ']';
					sectionInput.placeholder = 'For example: Section A';
					sectionLabel.appendChild( sectionInput );
					item.appendChild( sectionLabel );
				}
				item.appendChild( move ); item.appendChild( details ); item.appendChild( marks ); item.appendChild( actions );
				return item;
			}
			function addSource( source ) {
				if ( ! source || selectedIds().indexOf( source.dataset.questionId ) !== -1 ) { return; }
				canvas.appendChild( selectedItem( source ) );
				refresh();
			}
			function dragAfter( y ) {
				var items = Array.prototype.slice.call( canvas.querySelectorAll( '[data-tutorhelper-lms-quiz-selected]' ) );
				return items.reduce( function( closest, item ) {
					var box = item.getBoundingClientRect();
					var offset = y - box.top - box.height / 2;
					return offset < 0 && offset > closest.offset ? { offset: offset, item: item } : closest;
				}, { offset: Number.NEGATIVE_INFINITY, item: null } ).item;
			}
			function filterLibrary() {
				var query = ( search ? search.value : '' ).toLowerCase().trim();
				var selectedType = type ? type.value : '';
				Array.prototype.forEach.call( library.querySelectorAll( '[data-tutorhelper-lms-quiz-library-question]' ), function( item ) {
					var haystack = ( item.dataset.questionSearch || item.textContent || '' ).toLowerCase();
					var matches = ( ! query || haystack.indexOf( query ) !== -1 ) && ( ! selectedType || item.dataset.questionType === selectedType );
					item.hidden = ! matches;
					item.style.display = matches ? '' : 'none';
					item.setAttribute( 'aria-hidden', matches ? 'false' : 'true' );
				} );
			}
			builder.addEventListener( 'click', function( event ) {
				var tab = event.target.closest( '[data-tutorhelper-lms-quiz-tab]' );
				if ( tab ) {
					var active = tab.dataset.tutorhelperLmsQuizTab;
					builder.querySelectorAll( '[data-tutorhelper-lms-quiz-tab]' ).forEach( function( button ) { var isActive = button === tab; button.classList.toggle( 'is-active', isActive ); button.setAttribute( 'aria-pressed', isActive ? 'true' : 'false' ); } );
					builder.querySelectorAll( '[data-tutorhelper-lms-quiz-panel]' ).forEach( function( panel ) { panel.hidden = panel.dataset.tutorhelperLmsQuizPanel !== active; } );
					return;
				}
				var add = event.target.closest( '[data-tutorhelper-lms-quiz-add]' );
				if ( add ) { addSource( add.closest( '[data-tutorhelper-lms-quiz-library-question]' ) ); return; }
				var remove = event.target.closest( '[data-tutorhelper-lms-quiz-remove]' );
				if ( remove ) { remove.closest( '[data-tutorhelper-lms-quiz-selected]' ).remove(); refresh(); return; }
				var move = event.target.closest( '[data-tutorhelper-lms-quiz-move]' );
				if ( move ) {
					var item = move.closest( '[data-tutorhelper-lms-quiz-selected]' );
					if ( move.dataset.tutorhelperLmsQuizMove === 'up' && item.previousElementSibling ) { canvas.insertBefore( item, item.previousElementSibling ); }
					if ( move.dataset.tutorhelperLmsQuizMove === 'down' && item.nextElementSibling ) { canvas.insertBefore( item.nextElementSibling, item ); }
					refresh();
				}
			} );
			builder.addEventListener( 'dragstart', function( event ) {
				var item = event.target.closest( '[data-tutorhelper-lms-quiz-selected], [data-tutorhelper-lms-quiz-library-question]' );
				if ( ! item ) { return; }
				event.dataTransfer.setData( 'text/plain', item.dataset.questionId );
				event.dataTransfer.setData( 'tutorhelper-quiz-source', item.hasAttribute( 'data-tutorhelper-lms-quiz-selected' ) ? 'selected' : 'library' );
				event.dataTransfer.effectAllowed = 'move';
				item.classList.add( 'is-dragging' );
			} );
			builder.addEventListener( 'dragend', function( event ) { var item = event.target.closest( '.is-dragging' ); if ( item ) { item.classList.remove( 'is-dragging' ); } canvas.classList.remove( 'is-drag-over' ); } );
			canvas.addEventListener( 'dragover', function( event ) { event.preventDefault(); canvas.classList.add( 'is-drag-over' ); } );
			canvas.addEventListener( 'dragleave', function( event ) { if ( ! canvas.contains( event.relatedTarget ) ) { canvas.classList.remove( 'is-drag-over' ); } } );
			canvas.addEventListener( 'drop', function( event ) {
				event.preventDefault(); canvas.classList.remove( 'is-drag-over' );
				var id = event.dataTransfer.getData( 'text/plain' );
				var source = event.dataTransfer.getData( 'tutorhelper-quiz-source' );
				var item = source === 'selected' ? canvas.querySelector( '[data-question-id="' + id + '"]' ) : library.querySelector( '[data-question-id="' + id + '"]' );
				if ( ! item ) { return; }
				if ( source === 'library' ) { if ( selectedIds().indexOf( id ) !== -1 ) { return; } item = selectedItem( item ); }
				var after = dragAfter( event.clientY );
				if ( after ) { canvas.insertBefore( item, after ); } else { canvas.appendChild( item ); }
				refresh();
			} );
			if ( search ) { search.addEventListener( 'input', filterLibrary ); }
			if ( type ) { type.addEventListener( 'change', filterLibrary ); }
			if ( practiceMode ) { practiceMode.addEventListener( 'change', refreshAdaptivePracticeSettings ); }
			refresh();
		} );
	}

	function initialiseWorkspace( scope ) {
		initialiseChoicePickers( scope );
		initialiseGradeSystems( scope );
		initialiseResourceLibrary( scope );
		initialiseTables( scope );
		initialiseQuizBuilder( scope );
	}

	$( function() {
		initialiseWorkspace( document );
	} );

	function replaceWorkspaceHtml( $workspace, html ) {
		var incoming = document.createElement( 'div' );
		var editorScripts = [];

		// wp_editor() adds its configuration as inline scripts. Scripts inserted
		// through innerHTML are deliberately inert, so retain the trusted
		// WordPress editor initialisers and run them after the new fields exist.
		incoming.innerHTML = html;
		Array.prototype.forEach.call( incoming.querySelectorAll( 'script' ), function( script ) {
			var scriptSource = script.textContent || '';
			// The Question Bank's type-switcher is also rendered inline. Retain it
			// alongside the WordPress editor initialisers so its answer panels are
			// immediately filtered after an AJAX workspace replacement.
			if ( /(?:tinyMCEPreInit|wp\.editor\.initialize\s*\(|tutorhelper-lms-answer-editor)/.test( scriptSource ) ) {
				editorScripts.push( scriptSource );
			}
			script.parentNode.removeChild( script );
		} );

		// Question Bank has three wp_editor() instances. Removing only the prompt
		// left the feedback editors registered in TinyMCE after an AJAX swap,
		// preventing their replacement editors from attaching consistently.
		$workspace.find( 'textarea.wp-editor-area' ).each( function() {
			var editorId = this.id;
			if ( ! editorId ) {
				return;
			}
			if ( window.wp && wp.editor && typeof wp.editor.remove === 'function' ) {
				wp.editor.remove( editorId );
			} else if ( window.tinymce && tinymce.get( editorId ) ) {
				tinymce.get( editorId ).remove();
			}
		} );

		$workspace.html( incoming.innerHTML );
		initialiseWorkspace( $workspace[ 0 ] );

		editorScripts.forEach( function( scriptSource ) {
			$.globalEval( scriptSource );
		} );
	}

	function questionBankState( sourceUrl ) {
		var url = new URL( sourceUrl || window.location.href, window.location.href );
		var page = parseInt( url.searchParams.get( 'question_page' ) || '1', 10 );
		return {
			search: url.searchParams.get( 'question_search' ) || '',
			page: page > 0 ? page : 1
		};
	}

	function refreshQuestionBankWorkspace( questionEdit, notice, state ) {
		if ( ! window.tutorhelperLmsLearningHub ) {
			return;
		}
		state = state || questionBankState();
		var $workspace = $( '.tutorhelper-lms-learning-hub .tutorhelper-hub-workspace' );
		$workspace.attr( 'aria-busy', 'true' );
		$.post( window.tutorhelperLmsLearningHub.ajaxUrl, {
			action: window.tutorhelperLmsLearningHub.action,
			nonce: window.tutorhelperLmsLearningHub.nonce,
			tab: 'questions',
			question_edit: questionEdit || 0,
			question_search: state.search,
			question_page: state.page
		} ).done( function( response ) {
			if ( ! response || ! response.success || ! response.data ) {
				window.location.reload();
				return;
			}
			replaceWorkspaceHtml( $workspace, response.data.html );
			if ( notice ) {
				$workspace.prepend( $( '<div class="notice notice-success is-dismissible"><p></p></div>' ).find( 'p' ).text( notice ).end() );
			}
			var destination = new URL( window.location.href );
			destination.searchParams.set( 'tab', 'questions' );
			if ( state.search ) {
				destination.searchParams.set( 'question_search', state.search );
			} else {
				destination.searchParams.delete( 'question_search' );
			}
			if ( state.page > 1 ) {
				destination.searchParams.set( 'question_page', state.page );
			} else {
				destination.searchParams.delete( 'question_page' );
			}
			if ( questionEdit ) {
				destination.searchParams.set( 'edit', questionEdit );
			} else {
				destination.searchParams.delete( 'edit' );
			}
			if ( window.history && window.history.pushState ) {
				window.history.pushState( { tab: 'questions' }, '', destination.toString() );
			}
		} ).fail( function() {
			window.location.reload();
		} ).always( function() {
			$workspace.removeAttr( 'aria-busy' );
		} );
	}

	$( document ).on( 'click', '[data-tutorhelper-lms-update-quiz-version]', function() {
		var form = this.form;
		if ( form ) {
			$( form ).find( 'input[name="update_quiz_version"]' ).val( '1' );
		}
	} );

	$( document ).on( 'click', '.tutorhelper-lms-question-edit', function( event ) {
		if ( ! window.tutorhelperLmsLearningHub ) {
			return;
		}
		event.preventDefault();
		var url = new URL( $( this ).attr( 'href' ), window.location.href );
		var edit = url.searchParams.get( 'edit' );
		refreshQuestionBankWorkspace( edit ? parseInt( edit, 10 ) : 0, '', questionBankState( url.toString() ) );
	} );

	$( document ).on( 'submit', '.tutorhelper-lms-question-bank-form', function( event ) {
		if ( ! window.tutorhelperLmsLearningHub || this.dataset.tutorhelperLmsSaving ) {
			return;
		}
		event.preventDefault();
		var form = this;
		var $form = $( form );
		form.dataset.tutorhelperLmsSaving = '1';
		$form.attr( 'aria-busy', 'true' );
		$form.find( '.notice-error' ).remove();
		$.ajax( {
			// A hidden field called "action" must not shadow the form action URL.
			url: form.getAttribute( 'action' ) || window.location.href,
			method: 'POST',
			data: new FormData( form ),
			processData: false,
			contentType: false
		} ).done( function( html, status, xhr ) {
			var responseUrl = xhr.responseURL || '';
			var error = responseUrl ? new URL( responseUrl, window.location.href ).searchParams.get( 'lms_question_error' ) : '';
			if ( error ) {
				var $notice = $( html ).find( '.notice-error' ).first();
				$form.prepend( $notice.length ? $notice : $( '<div class="notice notice-error"><p>Question could not be saved. Please check the fields and try again.</p></div>' ) );
				return;
			}
			refreshQuestionBankWorkspace( 0, 'Question saved successfully.', questionBankState( responseUrl || window.location.href ) );
		} ).fail( function() {
			// The normal POST remains the safe fallback if the workspace request fails.
			form.dataset.tutorhelperLmsSaving = '';
			HTMLFormElement.prototype.submit.call( form );
		} ).always( function() {
			form.dataset.tutorhelperLmsSaving = '';
			$form.removeAttr( 'aria-busy' );
		} );
	} );

	$( document ).on( 'click', '.tutorhelper-lms-learning-hub .tutorhelper-hub-tabs__tab', function( event ) {
		var $tab = $( this );
		var tab = new URL( $tab.attr( 'href' ), window.location.href ).searchParams.get( 'tab' );

		if ( ! tab || ! window.tutorhelperLmsLearningHub ) {
			return;
		}

		event.preventDefault();

		var $workspace = $( '.tutorhelper-lms-learning-hub .tutorhelper-hub-workspace' );
		$workspace.attr( 'aria-busy', 'true' );

		$.post( window.tutorhelperLmsLearningHub.ajaxUrl, {
			action: window.tutorhelperLmsLearningHub.action,
			nonce: window.tutorhelperLmsLearningHub.nonce,
			tab: tab
		} ).done( function( response ) {
			if ( ! response || ! response.success || ! response.data ) {
				window.location.href = $tab.attr( 'href' );
				return;
			}

			replaceWorkspaceHtml( $workspace, response.data.html );
			$( '.tutorhelper-lms-learning-hub .tutorhelper-hub-tabs__tab' )
				.removeClass( 'is-active' )
				.removeAttr( 'aria-current' );
			$tab.addClass( 'is-active' ).attr( 'aria-current', 'page' );

			if ( window.history && window.history.pushState ) {
				window.history.pushState( { tab: response.data.tab }, '', $tab.attr( 'href' ) );
			}
		} ).fail( function() {
			window.location.href = $tab.attr( 'href' );
		} ).always( function() {
			$workspace.removeAttr( 'aria-busy' );
		} );
	} );


	function importAuditDialog() {
		return document.querySelector( '[data-tutorhelper-lms-import-dialog]' );
	}

	function importAuditInput( tag, name, label, value, attributes ) {
		var wrapper = document.createElement( 'p' );
		var control = document.createElement( tag );
		var caption = document.createElement( 'label' );
		caption.textContent = label;
		control.name = name;
		control.value = value || '';
		Object.keys( attributes || {} ).forEach( function( key ) {
			control.setAttribute( key, attributes[ key ] );
		} );
		caption.appendChild( control );
		wrapper.appendChild( caption );
		return wrapper;
	}

	function importAuditRichText( name, label, value, attributes ) {
		var editorId = 'tutorhelper-lms-import-audit-' + name;
		var editorAttributes = {
			id: editorId,
			rows: '8',
			class: 'wp-editor-area'
		};
		Object.keys( attributes || {} ).forEach( function( key ) {
			editorAttributes[ key ] = attributes[ key ];
		} );
		var field = importAuditInput( 'textarea', name, label, value, editorAttributes );
		window.setTimeout( function() {
			if ( window.wp && window.wp.editor && typeof window.wp.editor.initialize === 'function' && document.getElementById( editorId ) ) {
				window.wp.editor.initialize( editorId, {
					mediaButtons: false,
					tinymce: {
						wpautop: true,
						toolbar1: 'bold,italic,underline,bullist,numlist,link,unlink,undo,redo'
					},
					quicktags: true
				} );
			}
		}, 0 );
		return field;
	}

	function resetImportAuditDialog( dialog ) {
		var body = dialog.querySelector( '[data-tutorhelper-lms-import-dialog-body]' );
		if ( window.wp && window.wp.editor && typeof window.wp.editor.remove === 'function' ) {
			body.querySelectorAll( '.wp-editor-area[id]' ).forEach( function( editor ) {
				window.wp.editor.remove( editor.id );
			} );
		}
		body.innerHTML = '';
	}

	function importAuditSelectFromMapping( sourceName, targetName, label ) {
		var source = document.querySelector( '.tutorhelper-lms-import__mapping [name="' + sourceName + '"]' );
		var wrapper;
		var clone;
		if ( ! source ) {
			return null;
		}
		wrapper = document.createElement( 'p' );
		clone = source.cloneNode( true );
		clone.name = targetName;
		clone.removeAttribute( 'id' );
		var caption = document.createElement( 'label' );
		caption.textContent = label;
		caption.appendChild( clone );
		wrapper.appendChild( caption );
		return wrapper;
	}

	function importAuditAnswerLines( record ) {
		return ( record.answers || [] ).map( function( answer ) {
			var line = answer.text || '';
			if ( ( record.type === 'matrix_sort_answer' || record.type === 'matrix_sort' ) && answer.match ) {
				line += ' => ' + answer.match;
			}
			return line;
		} ).join( '\n' );
	}

	function importAuditImageReview( images ) {
		var section;
		var list;
		if ( ! Array.isArray( images ) || ! images.length ) {
			return null;
		}
		section = document.createElement( 'section' );
		section.className = 'tutorhelper-lms-import__dialog-media-review';
		var heading = document.createElement( 'h4' );
		heading.textContent = 'Images in this Question';
		section.appendChild( heading );
		var help = document.createElement( 'p' );
		help.className = 'description';
		help.textContent = 'These are source references only. A thumbnail is shown only when the image already exists in this site’s Media Library; no external image is loaded or copied.';
		section.appendChild( help );
		list = document.createElement( 'ul' );
		images.forEach( function( image ) {
			var item = document.createElement( 'li' );
			var icon = document.createElement( 'span' );
			var label = document.createElement( 'span' );
			icon.className = 'dashicons dashicons-format-image';
			icon.setAttribute( 'aria-hidden', 'true' );
			item.appendChild( icon );
			if ( image.thumbnail_url ) {
				var thumbnail = document.createElement( 'img' );
				thumbnail.className = 'tutorhelper-lms-import__dialog-media-thumb';
				thumbnail.src = image.thumbnail_url;
				thumbnail.alt = ( image.alts && image.alts[0] ) || 'Current Media Library thumbnail';
				item.appendChild( thumbnail );
			} else {
				var placeholder = document.createElement( 'span' );
				placeholder.className = 'tutorhelper-lms-import__dialog-media-thumb is-missing';
				placeholder.textContent = 'No local thumbnail';
				item.appendChild( placeholder );
			}
			label.className = 'tutorhelper-lms-import__dialog-media-label';
			var status = document.createElement( 'strong' );
			status.textContent = image.status_label || 'Image source';
			label.appendChild( status );
			var path = document.createElement( 'code' );
			path.textContent = image.source_label || image.relative_path || image.source_url || '';
			label.appendChild( path );
			if ( image.alts && image.alts.length ) {
				var alt = document.createElement( 'small' );
				alt.textContent = 'Alt text: ' + image.alts.join( ' | ' );
				label.appendChild( alt );
			}
			item.appendChild( label );
			list.appendChild( item );
		} );
		section.appendChild( list );
		return section;
	}


	function importAuditClozeEditor( record ) {
		var cloze = record.cloze || {};
		var blanks = Array.isArray( cloze.blanks ) && cloze.blanks.length ? cloze.blanks : ( record.answers || [] );
		var scoring = record.settings || {};
		var markingMode = scoring.cloze_marking_mode === 'all_or_nothing' ? 'all_or_nothing' : 'per_blank';
		var defaultTotal = Number( scoring.cloze_total_marks || record.marks || 1 );
		var section = document.createElement( 'section' );
		var sourceHeading = document.createElement( 'h4' );
		var source = document.createElement( 'pre' );
		var proposedHeading = document.createElement( 'h4' );
		var proposed = document.createElement( 'div' );
		var warning;
		section.className = 'tutorhelper-lms-import__cloze-review';
		if ( cloze.raw_pattern ) {
			sourceHeading.textContent = 'Original LearnDash fill-in pattern';
			source.textContent = cloze.raw_pattern;
			section.appendChild( sourceHeading );
			section.appendChild( source );
		}
		proposedHeading.textContent = 'Proposed TutorHelper Question';
		proposed.className = 'tutorhelper-lms-import__cloze-preview';
		proposed.innerHTML = record.prompt || '';
		section.appendChild( proposedHeading );
		section.appendChild( proposed );
		var marking = document.createElement( 'fieldset' );
		var markingLegend = document.createElement( 'legend' );
		var markingSelect = document.createElement( 'select' );
		markingLegend.textContent = 'Marking';
		marking.appendChild( markingLegend );
		markingSelect.name = 'audit_cloze_marking_mode';
		[ [ 'per_blank', 'Award marks for each correct gap' ], [ 'all_or_nothing', 'Award marks only when every gap is correct' ] ].forEach( function( option ) {
			var node = document.createElement( 'option' );
			node.value = option[0];
			node.textContent = option[1];
			node.selected = option[0] === markingMode;
			markingSelect.appendChild( node );
		} );
		var modeLabel = document.createElement( 'label' );
		var modeParagraph = document.createElement( 'p' );
		modeLabel.textContent = 'Award marks';
		modeLabel.appendChild( markingSelect );
		modeParagraph.appendChild( modeLabel );
		marking.appendChild( modeParagraph );
		marking.appendChild( importAuditInput( 'input', 'audit_cloze_total_marks', 'Marks when every gap is correct', String( defaultTotal ), { type: 'number', min: '1', step: '1', required: 'required' } ) );
		var markingHelp = document.createElement( 'p' );
		markingHelp.className = 'description';
		markingHelp.textContent = 'Per-gap marking remains the default. Choose all gaps correct to award one total mark only when every answer is correct.';
		marking.appendChild( markingHelp );
		section.appendChild( marking );
		if ( cloze.answer_points_activated ) {
			warning = document.createElement( 'p' );
			warning.className = 'description';
			warning.textContent = 'LearnDash answer-point scoring is active. You can retain marks per gap or replace them with an all-gaps-correct total.';
			section.appendChild( warning );
		}
		if ( Array.isArray( cloze.warnings ) && cloze.warnings.length ) {
			warning = document.createElement( 'p' );
			warning.className = 'notice notice-warning inline';
			warning.textContent = cloze.warnings.join( ' ' );
			section.appendChild( warning );
		}
		blanks.forEach( function( blank, index ) {
			var accepted = Array.isArray( blank.accepted ) ? blank.accepted : [ blank.text || '' ];
			var fieldset = document.createElement( 'fieldset' );
			var legend = document.createElement( 'legend' );
			var id = blank.id || ( 'blank-' + ( index + 1 ) );
			legend.textContent = 'Gap ' + ( index + 1 );
			fieldset.appendChild( legend );
			var hiddenId = document.createElement( 'input' );
			hiddenId.type = 'hidden';
			hiddenId.name = 'audit_cloze_blanks[' + index + '][id]';
			hiddenId.value = id;
			fieldset.appendChild( hiddenId );
			fieldset.appendChild( importAuditInput( 'textarea', 'audit_cloze_blanks[' + index + '][accepted]', 'Accepted answers — one per line', accepted.join( '\n' ), { rows: '3', required: 'required' } ) );
			fieldset.appendChild( importAuditInput( 'input', 'audit_cloze_blanks[' + index + '][marks]', 'Marks for this gap', String( blank.marks === undefined ? 1 : blank.marks ), { type: 'number', min: '0', step: '1', required: 'required' } ) );
			section.appendChild( fieldset );
		} );
		return section;
	}

	function openImportAuditDialog( trigger ) {
		var dialog = importAuditDialog();
		var body;
		var record;
		var field = trigger.getAttribute( 'data-tutorhelper-lms-import-field' ) || '';
		var fieldLabel = trigger.getAttribute( 'data-tutorhelper-lms-import-field-label' ) || 'field';
		var title;
		if ( ! dialog ) {
			return;
		}
		try {
			record = JSON.parse( trigger.getAttribute( 'data-tutorhelper-lms-import-record' ) || '{}' );
		} catch ( error ) {
			return;
		}
		body = dialog.querySelector( '[data-tutorhelper-lms-import-dialog-body]' );
		resetImportAuditDialog( dialog );
		dialog.querySelector( '[name="audit_kind"]' ).value = record.kind || '';
		dialog.querySelector( '[name="audit_id"]' ).value = record.id || '';
		dialog.querySelector( '[name="audit_field"]' ).value = field;
		title = document.createElement( 'h3' );
		title.textContent = 'Review and edit ' + fieldLabel;
		body.appendChild( title );
		var explanation = document.createElement( 'p' );
		explanation.className = 'description';
		explanation.textContent = 'This changes only the temporary import preview. No LMS content will be created or changed.';
		body.appendChild( explanation );
		if ( record.kind === 'question' ) {
			var imageReview = importAuditImageReview( record.media_images );
			if ( imageReview ) { body.appendChild( imageReview ); }
		}

		if ( record.kind === 'course' ) {
			if ( field === 'title' ) {
				body.appendChild( importAuditInput( 'input', 'audit_title', 'Course title', record.title, { type: 'text', required: 'required' } ) );
			} else if ( field === 'subject' ) {
				var subject = importAuditSelectFromMapping( 'course_subject_id', 'course_subject_id', 'TutorHelper Subject' );
				if ( subject ) { body.appendChild( subject ); }
			} else if ( field === 'grade' ) {
				var grade = importAuditSelectFromMapping( 'course_grade_system_id', 'course_grade_system_id', 'Grade system' );
				if ( grade ) { body.appendChild( grade ); }
			}
		} else if ( record.kind === 'lesson' ) {
			if ( field === 'title' ) {
				body.appendChild( importAuditInput( 'input', 'audit_title', 'Lesson title', record.title, { type: 'text', required: 'required' } ) );
			} else if ( field === 'topic' ) {
				var index = record.id;
				var mode = importAuditSelectFromMapping( 'lesson_mappings[' + index + '][mode]', 'lesson_mode', 'Topic plan' );
				var topic = importAuditSelectFromMapping( 'lesson_mappings[' + index + '][topic_id]', 'lesson_topic_id', 'Existing TutorHelper Topic' );
				var sourceTopic = importAuditSelectFromMapping( 'lesson_mappings[' + index + '][source_topic]', 'lesson_source_topic', 'Imported LearnDash Topic' );
				var newTopic = document.querySelector( '.tutorhelper-lms-import__mapping [name="lesson_mappings[' + index + '][new_topic_name]"]' );
				if ( mode ) { body.appendChild( mode ); }
				if ( topic ) { body.appendChild( topic ); }
				if ( sourceTopic ) { body.appendChild( sourceTopic ); }
				if ( newTopic ) { body.appendChild( importAuditInput( 'input', 'lesson_new_topic_name', 'New Topic name', newTopic.value, { type: 'text' } ) ); }
			}
		} else {
			if ( field === 'title' ) {
				body.appendChild( importAuditInput( 'input', 'audit_title', 'Question title', record.title, { type: 'text', required: 'required' } ) );
			} else if ( field === 'prompt' ) {
				body.appendChild( importAuditRichText( 'audit_prompt', 'Question prompt', record.prompt || '', { required: 'required' } ) );
			} else if ( field === 'marks' ) {
				body.appendChild( importAuditInput( 'input', 'audit_marks', 'Maximum marks', record.marks || '', { type: 'number', min: '1', step: '1', required: 'required' } ) );
			} else if ( field === 'correct_feedback' || field === 'incorrect_feedback' || field === 'tip' ) {
				var feedbackLabel = field === 'correct_feedback' ? 'Correct feedback' : ( field === 'incorrect_feedback' ? 'Incorrect feedback' : 'Student hint' );
				var feedbackValue = field === 'correct_feedback' ? record.correct_feedback : ( field === 'incorrect_feedback' ? record.incorrect_feedback : record.tip );
				body.appendChild( importAuditRichText( 'audit_text', feedbackLabel, feedbackValue || '' ) );
				var feedbackHelp = document.createElement( 'p' );
				feedbackHelp.className = 'description';
				feedbackHelp.textContent = feedbackValue ? 'This imported content is pre-filled for review. It remains private until a later import is approved.' : 'This is optional. It will be retained as rich text when the later import is approved.';
				body.appendChild( feedbackHelp );
			} else {
				if ( field === 'pattern' && record.type === 'cloze' ) {
					body.appendChild( importAuditClozeEditor( record ) );
				} else {
					var answerLabel = field === 'pairs' ? 'Matching pairs — one per line, in the format left => right' : ( field === 'pattern' ? ( record.type === 'cloze' ? 'Blank answers — one per line. Keep {{1}}, {{2}} and so on in the Question prompt.' : 'Fill-in pattern — use {braces} around each accepted answer' ) : 'Answer options — one per line' );
					body.appendChild( importAuditInput( 'textarea', 'audit_answers', answerLabel, importAuditAnswerLines( record ), { rows: '8', required: 'required' } ) );
					if ( field === 'correct' || record.type === 'single' || record.type === 'multiple' || record.type === 'single_choice' || record.type === 'multiple_choice' ) {
						var correct = ( record.answers || [] ).map( function( answer, index ) { return answer.correct ? index + 1 : null; } ).filter( Boolean ).join( ', ' );
						body.appendChild( importAuditInput( 'input', 'audit_correct', 'Correct option number(s), separated by commas', correct, { type: 'text' } ) );
					}
				}
			}
		}
		if ( typeof dialog.showModal === 'function' ) {
			dialog.showModal();
		} else {
			dialog.setAttribute( 'open', 'open' );
		}
	}

	$( document ).on( 'click', '.tutorhelper-lms-import__audit-fix', function( event ) {
		event.preventDefault();
		openImportAuditDialog( this );
	} );


	function showExternalImageActionError( form, message ) {
		var error = form.querySelector( '.tutorhelper-lms-import__external-action-error' );
		if ( ! error ) {
			error = document.createElement( 'span' );
			error.className = 'tutorhelper-lms-import__external-action-error';
			error.setAttribute( 'role', 'alert' );
			form.appendChild( error );
		}
		error.textContent = message;
	}

	function refreshExternalImageTable( form ) {
		var region = form.closest( '[data-tutorhelper-lms-import-media-table-region]' );
		var submit = form.querySelector( '[type="submit"]' );
		var originalLabel = submit ? submit.textContent : '';
		var request;
		if ( ! region || ! region.id || form.dataset.tutorhelperLmsExternalBusy ) {
			return;
		}
		form.dataset.tutorhelperLmsExternalBusy = '1';
		region.setAttribute( 'aria-busy', 'true' );
		if ( submit ) {
			submit.disabled = true;
			submit.textContent = form.dataset.tutorhelperLmsPendingLabel || 'Updating…';
		}
		request = new window.FormData( form );
		request.set( 'action', 'tutorhelper_lms_refresh_external_image_table' );
		window.fetch( window.ajaxurl || form.dataset.tutorhelperLmsAjaxUrl || form.action, {
			method: 'POST',
			body: request,
			credentials: 'same-origin',
			headers: { 'X-Requested-With': 'XMLHttpRequest' }
		} ).then( function( response ) {
			if ( ! response.ok ) {
				throw new Error( 'The image-review table could not be updated.' );
			}
			return response.json();
		} ).then( function( payload ) {
			var documentFromResponse;
			var replacement;
			if ( ! payload || ! payload.success || ! payload.data || ! payload.data.html ) {
				throw new Error( ( payload && payload.data && payload.data.message ) || 'The image-review table could not be updated.' );
			}
			documentFromResponse = new window.DOMParser().parseFromString( payload.data.html, 'text/html' );
			replacement = documentFromResponse.getElementById( region.id );
			if ( ! replacement ) {
				throw new Error( 'Updated image-review table not found.' );
			}
			region.replaceWith( replacement );
			var nextAction = replacement.querySelector( '.tutorhelper-lms-import__external-action [type="submit"]' );
			if ( nextAction ) {
				nextAction.focus();
			}
		} ).catch( function( error ) {
			form.dataset.tutorhelperLmsExternalBusy = '';
			region.removeAttribute( 'aria-busy' );
			if ( submit ) {
				submit.disabled = false;
				submit.textContent = originalLabel;
			}
			showExternalImageActionError( form, error.message || 'The image-review table could not be updated. Please try again.' );
		} );
	}

	$( document ).on( 'submit', '.tutorhelper-lms-import__external-action', function( event ) {
		event.preventDefault();
		refreshExternalImageTable( this );
	} );

	$( document ).on( 'click', '.tutorhelper-lms-import__select-local-image', function( event ) {
		var button = this;
		var region = button.closest( '[data-tutorhelper-lms-import-media-table-region]' );
		var originalLabel = button.textContent;
		var frame;
		event.preventDefault();
		if ( ! region || ! region.id || button.dataset.tutorhelperLmsImportBusy || ! window.wp || ! window.wp.media ) {
			return;
		}
		frame = window.wp.media( {
			title: 'Choose an existing image',
			library: { type: 'image' },
			button: { text: 'Use this image' },
			multiple: false
		} );
		frame.on( 'select', function() {
			var attachment = frame.state().get( 'selection' ).first().toJSON();
			var request = new window.FormData();
			button.dataset.tutorhelperLmsImportBusy = '1';
			button.disabled = true;
			button.textContent = button.dataset.tutorhelperLmsPendingLabel || 'Updating…';
			region.setAttribute( 'aria-busy', 'true' );
			request.append( 'action', 'tutorhelper_lms_select_import_media_image' );
			request.append( 'external_image_id', button.dataset.tutorhelperLmsImportImageId || '' );
			request.append( 'attachment_id', attachment.id || '' );
			request.append( '_wpnonce', button.dataset.tutorhelperLmsImportImageNonce || '' );
			window.fetch( window.ajaxurl || '', {
				method: 'POST',
				body: request,
				credentials: 'same-origin',
				headers: { 'X-Requested-With': 'XMLHttpRequest' }
			} ).then( function( response ) {
				if ( ! response.ok ) {
					throw new Error( 'The image-review table could not be updated.' );
				}
				return response.json();
			} ).then( function( payload ) {
				var documentFromResponse;
				var replacement;
				if ( ! payload || ! payload.success || ! payload.data || ! payload.data.html ) {
					throw new Error( ( payload && payload.data && payload.data.message ) || 'The image-review table could not be updated.' );
				}
				documentFromResponse = new window.DOMParser().parseFromString( payload.data.html, 'text/html' );
				replacement = documentFromResponse.getElementById( region.id );
				if ( ! replacement ) {
					throw new Error( 'Updated image-review table not found.' );
				}
				region.replaceWith( replacement );
				var nextAction = replacement.querySelector( '.tutorhelper-lms-import__select-local-image' );
				if ( nextAction ) {
					nextAction.focus();
				}
			} ).catch( function( error ) {
				button.dataset.tutorhelperLmsImportBusy = '';
				region.removeAttribute( 'aria-busy' );
				button.disabled = false;
				button.textContent = originalLabel;
				showExternalImageActionError( button.parentNode || button, error.message || 'The image-review table could not be updated. Please try again.' );
			} );
		} );
		frame.open();
	} );


	$( document ).on( 'click', '.tutorhelper-lms-import__recheck-learndash-creation', function( event ) {
		var button = this;
		var region = button.closest( '[data-tutorhelper-lms-learndash-creation-region]' );
		var originalLabel = button.textContent;
		var request = new window.FormData();
		event.preventDefault();
		if ( ! region || ! region.id || button.dataset.tutorhelperLmsRecheckBusy ) {
			return;
		}
		button.dataset.tutorhelperLmsRecheckBusy = '1';
		button.disabled = true;
		button.textContent = button.dataset.tutorhelperLmsPendingLabel || 'Rechecking…';
		region.setAttribute( 'aria-busy', 'true' );
		request.append( 'action', 'tutorhelper_lms_refresh_learndash_creation' );
		request.append( '_wpnonce', button.dataset.tutorhelperLmsLearndashCreationNonce || '' );
		window.fetch( window.ajaxurl || '', {
			method: 'POST',
			body: request,
			credentials: 'same-origin',
			headers: { 'X-Requested-With': 'XMLHttpRequest' }
		} ).then( function( response ) {
			if ( ! response.ok ) {
				throw new Error( 'The Question-creation review could not be updated.' );
			}
			return response.json();
		} ).then( function( payload ) {
			var documentFromResponse;
			var replacement;
			if ( ! payload || ! payload.success || ! payload.data || ! payload.data.html ) {
				throw new Error( ( payload && payload.data && payload.data.message ) || 'The Question-creation review could not be updated.' );
			}
			documentFromResponse = new window.DOMParser().parseFromString( payload.data.html, 'text/html' );
			replacement = documentFromResponse.getElementById( region.id );
			if ( ! replacement ) {
				throw new Error( 'Updated Question-creation review not found.' );
			}
			region.replaceWith( replacement );
			var nextAction = replacement.querySelector( '.tutorhelper-lms-import__recheck-learndash-creation' );
			if ( nextAction ) {
				nextAction.focus();
			}
		} ).catch( function( error ) {
			button.dataset.tutorhelperLmsRecheckBusy = '';
			region.removeAttribute( 'aria-busy' );
			button.disabled = false;
			button.textContent = originalLabel;
			showExternalImageActionError( button.parentNode || button, error.message || 'The Question-creation review could not be updated. Please try again.' );
		} );
	} );

	$( document ).on( 'click', '.tutorhelper-lms-import__recheck-csv-creation', function( event ) {
		var button = this;
		var region = button.closest( '[data-tutorhelper-lms-csv-creation-region]' );
		var originalLabel = button.textContent;
		var request = new window.FormData();
		event.preventDefault();
		if ( ! region || ! region.id || button.dataset.tutorhelperLmsRecheckBusy ) {
			return;
		}
		button.dataset.tutorhelperLmsRecheckBusy = '1';
		button.disabled = true;
		button.textContent = button.dataset.tutorhelperLmsPendingLabel || 'Rechecking…';
		region.setAttribute( 'aria-busy', 'true' );
		request.append( 'action', 'tutorhelper_lms_refresh_csv_creation' );
		request.append( '_wpnonce', button.dataset.tutorhelperLmsCsvCreationNonce || '' );
		window.fetch( window.ajaxurl || '', {
			method: 'POST',
			body: request,
			credentials: 'same-origin',
			headers: { 'X-Requested-With': 'XMLHttpRequest' }
		} ).then( function( response ) {
			if ( ! response.ok ) {
				throw new Error( 'The CSV Question-creation review could not be updated.' );
			}
			return response.json();
		} ).then( function( payload ) {
			var documentFromResponse;
			var replacement;
			if ( ! payload || ! payload.success || ! payload.data || ! payload.data.html ) {
				throw new Error( ( payload && payload.data && payload.data.message ) || 'The CSV Question-creation review could not be updated.' );
			}
			documentFromResponse = new window.DOMParser().parseFromString( payload.data.html, 'text/html' );
			replacement = documentFromResponse.getElementById( region.id );
			if ( ! replacement ) {
				throw new Error( 'Updated CSV Question-creation review not found.' );
			}
			region.replaceWith( replacement );
			var nextAction = replacement.querySelector( '.tutorhelper-lms-import__recheck-csv-creation' );
			if ( nextAction ) {
				nextAction.focus();
			}
		} ).catch( function( error ) {
			button.dataset.tutorhelperLmsRecheckBusy = '';
			region.removeAttribute( 'aria-busy' );
			button.disabled = false;
			button.textContent = originalLabel;
			showExternalImageActionError( button.parentNode || button, error.message || 'The CSV Question-creation review could not be updated. Please try again.' );
		} );
	} );

	$( document ).on( 'submit', '[data-tutorhelper-lms-import-dialog] form', function() {
		if ( window.tinyMCE && typeof window.tinyMCE.triggerSave === 'function' ) {
			window.tinyMCE.triggerSave();
		}
	} );

	$( document ).on( 'click', '[data-tutorhelper-lms-import-close]', function() {
		var dialog = this.closest( 'dialog' );
		if ( dialog && typeof dialog.close === 'function' ) {
			dialog.close();
		} else if ( dialog ) {
			dialog.removeAttribute( 'open' );
		}
	} );
}( jQuery ) );
