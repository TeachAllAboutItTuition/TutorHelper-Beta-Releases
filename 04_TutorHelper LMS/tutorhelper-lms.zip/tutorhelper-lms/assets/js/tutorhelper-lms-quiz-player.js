( function () {
	'use strict';

	function sortValue( item ) {
		return item.dataset.tutorhelperLmsSortValue || item.textContent.trim();
	}

	function matchValue( item ) {
		return item.dataset.tutorhelperLmsMatchValue || item.textContent.trim();
	}

	function syncSort( list ) {
		var input = list.parentNode.querySelector( '[data-tutorhelper-lms-sort-response]' );
		if ( ! input ) { return; }
		input.value = JSON.stringify( Array.prototype.map.call( list.querySelectorAll( '[data-tutorhelper-lms-sort-item]' ), sortValue ) );
	}

	function syncMatches( matching ) {
		var input = matching.parentNode.querySelector( '[data-tutorhelper-lms-match-response]' );
		if ( ! input ) { return; }
		var answer = {};
		matching.querySelectorAll( '[data-tutorhelper-lms-match-target]' ).forEach( function ( target ) {
			var token = target.querySelector( '[data-tutorhelper-lms-match-token]' );
			var value = token ? matchValue( token ) : ( target.dataset.tutorhelperLmsMatchValue || target.textContent.trim() );
			if ( value ) { answer[ target.dataset.left ] = value; }
		} );
		input.value = JSON.stringify( answer );
	}

	document.addEventListener( 'dragstart', function ( event ) {
		var sortItem = event.target.closest( '[data-tutorhelper-lms-sort-item]' );
		var token = event.target.closest( '[data-tutorhelper-lms-match-token]' );
		if ( sortItem ) {
			event.dataTransfer.setData( 'text/plain', sortValue( sortItem ) );
			event.dataTransfer.setData( 'tutorhelper-quiz-kind', 'sort' );
			event.dataTransfer.effectAllowed = 'move';
			sortItem.classList.add( 'is-dragging' );
		} else if ( token ) {
			event.dataTransfer.setData( 'text/plain', matchValue( token ) );
			event.dataTransfer.setData( 'tutorhelper-quiz-kind', 'match' );
			event.dataTransfer.effectAllowed = 'move';
			token.classList.add( 'is-dragging' );
		}
	} );

	document.addEventListener( 'dragend', function ( event ) {
		var token = event.target.closest( '[data-tutorhelper-lms-match-token]' );
		var sortItem = event.target.closest( '[data-tutorhelper-lms-sort-item]' );
		if ( token ) { token.classList.remove( 'is-dragging' ); }
		if ( sortItem ) { sortItem.classList.remove( 'is-dragging' ); }
	} );

	document.addEventListener( 'dragover', function ( event ) {
		if ( event.target.closest( '[data-tutorhelper-lms-sort-list], [data-tutorhelper-lms-match-target], [data-tutorhelper-lms-match-bank]' ) ) {
			event.preventDefault();
			var sortList = event.target.closest( '[data-tutorhelper-lms-sort-list]' );
			if ( sortList ) { sortList.classList.add( 'is-drag-over' ); }
			event.dataTransfer.dropEffect = 'move';
		}
	} );

	document.addEventListener( 'drop', function ( event ) {
		var kind = event.dataTransfer.getData( 'tutorhelper-quiz-kind' );
		var text = event.dataTransfer.getData( 'text/plain' );
		var list = event.target.closest( '[data-tutorhelper-lms-sort-list]' );
		var target = event.target.closest( '[data-tutorhelper-lms-match-target]' );
		var bank = event.target.closest( '[data-tutorhelper-lms-match-bank]' );
		if ( kind === 'sort' && list ) {
			event.preventDefault();
			list.classList.remove( 'is-drag-over' );
			var dragged = Array.prototype.find.call( list.querySelectorAll( '[data-tutorhelper-lms-sort-item]' ), function ( item ) { return sortValue( item ) === text; } );
			if ( dragged ) {
				var after = Array.prototype.find.call( list.querySelectorAll( '[data-tutorhelper-lms-sort-item]' ), function ( item ) { return event.clientY < item.getBoundingClientRect().top + item.offsetHeight / 2; } );
				list.insertBefore( dragged, after || null );
				syncSort( list );
			}
		}
		if ( kind === 'match' && ( target || bank ) ) {
			event.preventDefault();
			var matching = ( target || bank ).closest( '[data-tutorhelper-lms-matching]' );
			var token = matching.querySelector( '[data-tutorhelper-lms-match-token].is-dragging' );
			if ( ! token ) { return; }
			if ( target ) {
				var existing = target.querySelector( '[data-tutorhelper-lms-match-token]' );
				if ( existing ) { matching.querySelector( '[data-tutorhelper-lms-match-bank]' ).appendChild( existing ); }
				target.textContent = '';
				target.dataset.tutorhelperLmsMatchValue = matchValue( token );
				target.appendChild( token );
			} else {
				var previousTarget = token.closest( '[data-tutorhelper-lms-match-target]' );
				if ( previousTarget ) { previousTarget.dataset.tutorhelperLmsMatchValue = ''; }
				bank.appendChild( token );
			}
			syncMatches( matching );
		}
	} );

	document.addEventListener( 'submit', function ( event ) {
		event.target.querySelectorAll( '[data-tutorhelper-lms-sort-list]' ).forEach( syncSort );
		event.target.querySelectorAll( '[data-tutorhelper-lms-matching]' ).forEach( syncMatches );
	} );
}() );
