/* global tutorhelperLmsReader */
(function () {
	'use strict';

	if (!window.tutorhelperLmsReader) {
		return;
	}

	var reader = document.getElementById('tutorhelper-lms-reader-page');
	var content = reader ? reader.querySelector('.tutorhelper-lms-reader-page__inner') : null;
	var pageRegion = content ? content.querySelector('[data-tutorhelper-lms-page-region]') : null;
	var progressRegion = content ? content.querySelector('[data-tutorhelper-lms-progress-region]') : null;
	if (!reader || !content) {
		return;
	}

	function initialiseCourseOverview() {
		var overview = content.querySelector('[data-tutorhelper-lms-course-overview]');
		if (!overview) { return; }
		var cards = Array.prototype.slice.call(overview.querySelectorAll('[data-tutorhelper-lms-topic-card]'));
		var key = 'tutorhelperLmsOpenTopics:' + (overview.getAttribute('data-course-key') || 'course');
		var open = [];
		try { open = JSON.parse(window.sessionStorage.getItem(key) || '[]'); } catch (error) {}
		if (!open.length && cards.length) { open = [cards[0].getAttribute('data-topic-key')]; }
		function setCard(card, expanded, persist) {
			var button = card.querySelector('[data-tutorhelper-lms-topic-toggle]');
			var panel = card.querySelector('[data-tutorhelper-lms-topic-panel]');
			if (!button || !panel) { return; }
			button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			panel.hidden = !expanded;
			if (persist) {
				open = cards.filter(function (item) { var toggle = item.querySelector('[data-tutorhelper-lms-topic-toggle]'); return toggle && toggle.getAttribute('aria-expanded') === 'true'; }).map(function (item) { return item.getAttribute('data-topic-key'); });
				try { window.sessionStorage.setItem(key, JSON.stringify(open)); } catch (error) {}
			}
		}
		cards.forEach(function (card) {
			setCard(card, open.indexOf(card.getAttribute('data-topic-key')) !== -1, false);
			var button = card.querySelector('[data-tutorhelper-lms-topic-toggle]');
			if (button) { button.addEventListener('click', function () { setCard(card, button.getAttribute('aria-expanded') !== 'true', true); }); }
		});
		var expandAll = overview.querySelector('[data-tutorhelper-lms-expand-topics]');
		var collapseAll = overview.querySelector('[data-tutorhelper-lms-collapse-topics]');
		if (expandAll) { expandAll.addEventListener('click', function () { cards.forEach(function (card) { setCard(card, true, false); }); try { window.sessionStorage.setItem(key, JSON.stringify(cards.map(function (card) { return card.getAttribute('data-topic-key'); }))); } catch (error) {} }); }
		if (collapseAll) { collapseAll.addEventListener('click', function () { cards.forEach(function (card) { setCard(card, false, false); }); try { window.sessionStorage.setItem(key, '[]'); } catch (error) {} }); }
	}

	initialiseCourseOverview();

	function initialiseCourseExpansion() {
		var button = content.querySelector('[data-tutorhelper-lms-expand-course]');
		if (!button) { return; }
		var key = 'tutorhelperLmsCourseExpanded';
		var expanded = false;
		try { expanded = window.sessionStorage.getItem(key) === '1'; } catch (error) {}
		function apply(value) {
			content.classList.toggle('is-course-expanded', value);
			button.setAttribute('aria-pressed', value ? 'true' : 'false');
			button.textContent = value ? 'Use standard course view' : 'Expand course view';
		}
		apply(expanded);
		button.addEventListener('click', function () {
			expanded = !expanded;
			apply(expanded);
			try { window.sessionStorage.setItem(key, expanded ? '1' : '0'); } catch (error) {}
		});
	}

	initialiseCourseExpansion();

	function initialiseReaderModes() {
		var readerModes = content.querySelector('[data-tutorhelper-lms-reader-modes]');
		if (!readerModes || !window.fetch || !window.URLSearchParams) { return; }
		var buttons = Array.prototype.slice.call(readerModes.querySelectorAll('[data-tutorhelper-lms-reader-mode]'));
		var status = readerModes.querySelector('[data-tutorhelper-lms-reader-mode-status]');
		function applyMode(mode) {
			['all', 'reading', 'notes'].forEach(function (item) { readerModes.classList.remove('is-view-' + item); });
			readerModes.classList.add('is-view-' + mode);
			buttons.forEach(function (button) { button.setAttribute('aria-pressed', button.getAttribute('data-tutorhelper-lms-reader-mode') === mode ? 'true' : 'false'); });
		}
		buttons.forEach(function (button) {
			button.addEventListener('click', function () {
				var mode = button.getAttribute('data-tutorhelper-lms-reader-mode');
				var request = readerRequest(window.location.href);
				if (!mode || !request) { return; }
				applyMode(mode);
				if (status) { status.textContent = 'Saving reading view…'; }
				var data = new URLSearchParams();
				data.append('action', tutorhelperLmsReader.readerModeAction);
				data.append('nonce', tutorhelperLmsReader.readerModeNonce);
				data.append('tutorhelper_lms_reader', request.token);
				data.append('reader_mode', mode);
				window.fetch(tutorhelperLmsReader.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: data.toString() })
					.then(function (response) { if (!response.ok) { throw new Error(); } return response.json(); })
					.then(function (response) { if (!response || !response.success) { throw new Error(); } if (status) { status.textContent = response.data && response.data.message ? response.data.message : 'Your reading view has been saved.'; } })
					.catch(function () { if (status) { status.textContent = 'Your reading view could not be saved. Please try again.'; } });
			});
		});
	}

	initialiseReaderModes();
	if (!pageRegion || !window.fetch || !window.URLSearchParams) {
		return;
	}

	var isLoading = false;
	reader.classList.add('has-note-editor');

	function syncNoteEditor(form) {
		var editor = form.querySelector('[data-tutorhelper-lms-note-editor]');
		var source = form.querySelector('.tutorhelper-lms-textbook__notes-source');
		if (editor && source) {
			source.value = editor.innerHTML;
		}
	}

	function readerRequest(url) {
		var destination = new URL(url, window.location.href);
		var token = destination.searchParams.get('tutorhelper_lms_reader');
		if (!token || !/^[A-Za-z0-9]{32}$/.test(token)) {
			return null;
		}

		return {
			url: destination.href,
			token: token,
			page: destination.searchParams.get('tutorhelper_lms_page') || '1'
		};
	}

	function focusLessonHeading() {
		var page = pageRegion.querySelector('.tutorhelper-lms-textbook__page');
		if (!page) {
			return;
		}

		page.setAttribute('tabindex', '-1');
		page.focus({ preventScroll: true });
		page.scrollIntoView({ behavior: 'auto', block: 'start' });
	}

	function loadPage(url, addHistory) {
		var request = readerRequest(url);
		if (!request || isLoading) {
			return;
		}

		isLoading = true;
		reader.setAttribute('aria-busy', 'true');

		var data = new URLSearchParams();
		data.append('action', tutorhelperLmsReader.action);
		data.append('nonce', tutorhelperLmsReader.nonce);
		data.append('tutorhelper_lms_reader', request.token);
		data.append('tutorhelper_lms_page', request.page);

		window.fetch(tutorhelperLmsReader.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			body: data.toString()
		})
			.then(function (response) {
				if (!response.ok) {
					throw new Error('Reader navigation failed.');
				}
				return response.json();
			})
			.then(function (response) {
				if (!response || !response.success || !response.data || !response.data.html) {
					throw new Error('Reader navigation failed.');
				}

				pageRegion.innerHTML = response.data.html;
				if (progressRegion && response.data.progress_html) {
					progressRegion.innerHTML = response.data.progress_html;
				}
				applyAnnotations();
				var noteToken = content.querySelector('[name="reader_token"]');
				var returnUrl = content.querySelector('[name="return_url"]');
				if (noteToken) {
					noteToken.value = request.token;
				}
				if (returnUrl) {
					returnUrl.value = request.url;
				}
				if (addHistory) {
					window.history.pushState({}, '', request.url);
				}
				focusLessonHeading();
			})
			.catch(function () {
				// Preserve ordinary link navigation as the reliable fallback.
				window.location.assign(request.url);
			})
			.finally(function () {
				isLoading = false;
				reader.removeAttribute('aria-busy');
			});
	}

	document.addEventListener('keydown', function (event) {
		var annotation = event.target.closest('.tutorhelper-lms-annotation');
		if (annotation && (event.key === 'Enter' || event.key === ' ')) {
			event.preventDefault();
			annotation.click();
		}
	});

	document.addEventListener('click', function (event) {
		var link = event.target.closest('.tutorhelper-lms-textbook__navigation a');
		if (!link || link.hasAttribute('data-tutorhelper-lms-next-lesson') || event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
			return;
		}

		if (!readerRequest(link.href)) {
			return;
		}

		event.preventDefault();
		loadPage(link.href, true);
	});

	document.addEventListener('mousedown', function (event) {
		var formatButton = event.target.closest('[data-note-command]');
		if (formatButton) {
			event.preventDefault();
		}
	});

	document.addEventListener('click', function (event) {
		var formatButton = event.target.closest('[data-note-command]');
		if (!formatButton) {
			return;
		}

		var form = formatButton.closest('[data-tutorhelper-lms-note-form]');
		var editor = form ? form.querySelector('[data-tutorhelper-lms-note-editor]') : null;
		if (!editor || !document.execCommand) {
			return;
		}

		editor.focus();
		document.execCommand(formatButton.getAttribute('data-note-command'), false, null);
		syncNoteEditor(form);
	});

	var noteSaveTimers = new WeakMap();
	var noteDirtyForms = new WeakSet();
	function noteStatus(form, message, state) { var status = form.querySelector('[data-tutorhelper-lms-note-status]'); if (status) { status.textContent = message; status.setAttribute('data-state', state || ''); } }
	function saveNotes(form) {
		if (!form || form.getAttribute('data-note-saving') === '1') { return; }
		syncNoteEditor(form);
		var button = form.querySelector('button[type="submit"]'), retry = form.querySelector('[data-tutorhelper-lms-note-retry]'), data = new URLSearchParams();
		new FormData(form).forEach(function (value, key) { data.append(key, value); }); data.set('action', tutorhelperLmsReader.noteAction);
		form.setAttribute('data-note-saving', '1'); if (button) { button.disabled = true; } if (retry) { retry.hidden = true; } noteStatus(form, 'Saving…', 'saving');
		window.fetch(tutorhelperLmsReader.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: data.toString() })
			.then(function (response) { if (!response.ok) { throw new Error(); } return response.json(); })
			.then(function (response) { if (!response || !response.success) { throw new Error(); } noteDirtyForms.delete(form); noteStatus(form, 'Saved', 'saved'); })
			.catch(function () { noteDirtyForms.add(form); noteStatus(form, tutorhelperLmsReader.noteError, 'error'); if (retry) { retry.hidden = false; } })
			.finally(function () { form.removeAttribute('data-note-saving'); if (button) { button.disabled = false; } });
	}
	function scheduleNotes(form) { var old = noteSaveTimers.get(form); if (old) { window.clearTimeout(old); } noteSaveTimers.set(form, window.setTimeout(function () { saveNotes(form); }, 850)); }
	document.addEventListener('input', function (event) { var editor = event.target.closest('[data-tutorhelper-lms-note-editor]'); if (!editor) { return; } var form = editor.closest('[data-tutorhelper-lms-note-form]'); if (!form) { return; } syncNoteEditor(form); noteDirtyForms.add(form); noteStatus(form, 'Changes waiting to save…', 'pending'); scheduleNotes(form); });
	document.addEventListener('submit', function (event) { var form = event.target.closest('[data-tutorhelper-lms-note-form]'); if (!form) { return; } event.preventDefault(); saveNotes(form); });
	document.addEventListener('click', function (event) {
		var retry = event.target.closest('[data-tutorhelper-lms-note-retry]'); if (retry) { saveNotes(retry.closest('[data-tutorhelper-lms-note-form]')); return; }
		var copy = event.target.closest('[data-tutorhelper-lms-copy-notes]'); if (!copy) { return; }
		var form = copy.closest('[data-tutorhelper-lms-note-form]'), editor = form && form.querySelector('[data-tutorhelper-lms-note-editor]'); if (!editor) { return; }
		var done = function () { noteStatus(form, 'Notes copied to your clipboard.', 'saved'); }, text = editor.innerText || editor.textContent || '';
		if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(done).catch(function () { noteStatus(form, 'Select and copy your notes manually.', 'error'); }); }
		else { var range = document.createRange(); range.selectNodeContents(editor); var selected = window.getSelection(); selected.removeAllRanges(); selected.addRange(range); noteStatus(form, 'Notes selected — copy them using your browser.', 'pending'); }
	});
	window.addEventListener('beforeunload', function (event) { var dirty = false; document.querySelectorAll('[data-tutorhelper-lms-note-form]').forEach(function (form) { if (noteDirtyForms.has(form)) { dirty = true; } }); if (dirty) { event.preventDefault(); event.returnValue = ''; } });
	function annotationContent() {
		return pageRegion.querySelector('[data-tutorhelper-lms-annotation-content]');
	}

	function applyAnnotations() {
		var root = annotationContent();
		if (!root) { return; }
		var annotations;
		try { annotations = JSON.parse(root.getAttribute('data-annotations') || '[]'); } catch (error) { return; }
		annotations.forEach(function (annotation) {
			var text = root.textContent || '';
			if (text.slice(annotation.start, annotation.end) !== annotation.text) {
				var matchingStart = text.indexOf(annotation.text);
				if (matchingStart === -1) { return; }
				annotation.start = matchingStart;
				annotation.end = matchingStart + annotation.text.length;
			}
			var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), node, position = 0, startNode, endNode, startOffset, endOffset;
			while ((node = walker.nextNode())) {
				var next = position + node.nodeValue.length;
				if (!startNode && annotation.start >= position && annotation.start <= next) { startNode = node; startOffset = annotation.start - position; }
				if (annotation.end >= position && annotation.end <= next) { endNode = node; endOffset = annotation.end - position; break; }
				position = next;
			}
			if (!startNode || !endNode) { return; }
			var range = document.createRange();
			range.setStart(startNode, startOffset);
			range.setEnd(endNode, endOffset);
			var mark = document.createElement('mark');
			mark.className = 'tutorhelper-lms-annotation tutorhelper-lms-annotation--' + annotation.type;
			mark.setAttribute('data-annotation-id', annotation.id);
			mark.setAttribute('tabindex', '0');
			mark.setAttribute('role', 'button');
			mark.setAttribute('aria-label', annotation.type === 'sticky' ? 'Open private sticky note' : 'Open private highlight');
			var fragment = range.extractContents();
			mark.appendChild(fragment);
			range.insertNode(mark);
		});
	}

	function selectionData() {
		var root = annotationContent();
		var selection = window.getSelection();
		if (!root || !selection || !selection.rangeCount || !root.contains(selection.anchorNode) || !root.contains(selection.focusNode)) { return null; }
		var range = selection.getRangeAt(0);
		var text = range.toString();
		if (!text || !text.trim()) { return null; }
		var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
		var node, start = 0, end = 0, position = 0;
		while ((node = walker.nextNode())) {
			if (node === range.startContainer) { start = position + range.startOffset; }
			if (node === range.endContainer) { end = position + range.endOffset; break; }
			position += node.nodeValue.length;
		}
		return end > start ? { start: start, end: end, text: text } : null;
	}

	function renderAnnotationIndex(annotations, unavailable) {
		var list = content.querySelector('[data-tutorhelper-lms-annotation-list]'); if (!list) { return; } list.innerHTML = '';
		annotations.forEach(function (annotation) { var item = document.createElement('li'), button = document.createElement('button'); button.type = 'button'; button.setAttribute('data-tutorhelper-lms-open-annotation', annotation.id); button.textContent = (annotation.type === 'sticky' ? 'Sticky note: ' : 'Highlight: ') + annotation.text.slice(0, 72); item.appendChild(button); list.appendChild(item); });
		unavailable.forEach(function () { var item = document.createElement('li'); item.textContent = 'An annotation is unavailable because this Lesson page has changed.'; list.appendChild(item); });
		if (!annotations.length && !unavailable.length) { var empty = document.createElement('li'); empty.textContent = 'No annotations on this page yet.'; list.appendChild(empty); }
	}
	function applyAnnotations() {
		var root = annotationContent(); if (!root) { return; } var annotations, rendered = [], unavailable = [];
		try { annotations = JSON.parse(root.getAttribute('data-annotations') || '[]'); } catch (error) { annotations = []; }
		annotations.forEach(function (annotation) {
			var text = root.textContent || ''; if (text.slice(annotation.start, annotation.end) !== annotation.text) { var matchingStart = text.indexOf(annotation.text); if (matchingStart === -1) { unavailable.push(annotation); return; } annotation.start = matchingStart; annotation.end = matchingStart + annotation.text.length; }
			var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), node, position = 0, startNode, endNode, startOffset, endOffset;
			while ((node = walker.nextNode())) { var next = position + node.nodeValue.length; if (!startNode && annotation.start >= position && annotation.start <= next) { startNode = node; startOffset = annotation.start - position; } if (annotation.end >= position && annotation.end <= next) { endNode = node; endOffset = annotation.end - position; break; } position = next; }
			if (!startNode || !endNode) { unavailable.push(annotation); return; } var range = document.createRange(); range.setStart(startNode, startOffset); range.setEnd(endNode, endOffset);
			var mark = document.createElement('mark'); mark.className = 'tutorhelper-lms-annotation tutorhelper-lms-annotation--' + annotation.type; mark.setAttribute('data-annotation-id', annotation.id); mark.setAttribute('tabindex', '0'); mark.setAttribute('role', 'button'); mark.setAttribute('aria-label', annotation.type === 'sticky' ? 'Open and edit private sticky note' : 'Open private highlight'); var fragment = range.extractContents(); mark.appendChild(fragment); range.insertNode(mark); rendered.push(annotation);
		}); renderAnnotationIndex(rendered, unavailable);
	}
	function selectionData() {
		var root = annotationContent(), selection = window.getSelection(); if (!root || !selection || !selection.rangeCount || !root.contains(selection.anchorNode) || !root.contains(selection.focusNode)) { return null; } var range = selection.getRangeAt(0), text = range.toString(); if (!text || !text.trim()) { return null; } var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), node, start = 0, end = 0, position = 0; while ((node = walker.nextNode())) { if (node === range.startContainer) { start = position + range.startOffset; } if (node === range.endContainer) { end = position + range.endOffset; break; } position += node.nodeValue.length; } return end > start ? { start: start, end: end, text: text } : null;
	}
	function annotationRequest(data, deleting) {
		var token = content.querySelector('[name="reader_token"]'), page = annotationContent(); if (!token || !page) { return; } data.action = deleting ? 'tutorhelper_lms_delete_annotation' : 'tutorhelper_lms_save_annotation'; data.nonce = deleting ? tutorhelperLmsReader.annotationDeleteNonce : tutorhelperLmsReader.annotationNonce; data.reader_token = token.value; data.page_number = page.getAttribute('data-page-number');
		window.fetch(tutorhelperLmsReader.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: new URLSearchParams(data).toString() }).then(function (response) { if (!response.ok) { throw new Error(); } return response.json(); }).then(function (response) { if (!response.success) { throw new Error(); } loadPage(window.location.href, false); }).catch(function () { window.alert(tutorhelperLmsReader.annotationError); });
	}
	function openAnnotation(annotation) {
		var dialog = content.querySelector('[data-tutorhelper-lms-sticky-dialog]'); if (!annotation || !dialog) { return; } dialog._annotation = annotation; dialog._selection = null; dialog.querySelector('[data-tutorhelper-lms-sticky-title]').textContent = annotation.type === 'sticky' ? 'Edit your sticky note' : 'Your highlight'; dialog.querySelector('[data-tutorhelper-lms-sticky-selection]').textContent = annotation.text; var note = dialog.querySelector('[data-tutorhelper-lms-sticky-content]'); note.value = annotation.note || ''; note.readOnly = annotation.type !== 'sticky'; dialog.querySelector('[data-tutorhelper-lms-sticky-save]').hidden = annotation.type !== 'sticky'; dialog.querySelector('[data-tutorhelper-lms-annotation-delete]').hidden = false; dialog.showModal();
	}
	document.addEventListener('click', function (event) {
		var annotationMark = event.target.closest('.tutorhelper-lms-annotation'), annotationOpen = event.target.closest('[data-tutorhelper-lms-open-annotation]');
		if (annotationMark || annotationOpen) { var root = annotationContent(), id = annotationMark ? annotationMark.getAttribute('data-annotation-id') : annotationOpen.getAttribute('data-tutorhelper-lms-open-annotation'), annotations; try { annotations = JSON.parse(root.getAttribute('data-annotations') || '[]'); } catch (error) { annotations = []; } openAnnotation(annotations.filter(function (item) { return String(item.id) === id; })[0]); return; }
		var highlight = event.target.closest('[data-tutorhelper-lms-highlight]'); if (highlight) { var selected = selectionData(); if (selected) { annotationRequest({ annotation_type: 'highlight', start_offset: selected.start, end_offset: selected.end, selected_text: selected.text, note_content: '' }); } return; }
		var sticky = event.target.closest('[data-tutorhelper-lms-sticky]'); if (sticky) { var selectedSticky = selectionData(), dialog = content.querySelector('[data-tutorhelper-lms-sticky-dialog]'); if (selectedSticky && dialog) { dialog._selection = selectedSticky; dialog._annotation = null; dialog.querySelector('[data-tutorhelper-lms-sticky-title]').textContent = 'Add sticky note'; dialog.querySelector('[data-tutorhelper-lms-sticky-selection]').textContent = selectedSticky.text; dialog.querySelector('[data-tutorhelper-lms-sticky-content]').readOnly = false; dialog.querySelector('[data-tutorhelper-lms-sticky-content]').value = ''; dialog.querySelector('[data-tutorhelper-lms-sticky-save]').hidden = false; dialog.querySelector('[data-tutorhelper-lms-annotation-delete]').hidden = true; dialog.showModal(); } return; }
		var saveSticky = event.target.closest('[data-tutorhelper-lms-sticky-save]'); if (saveSticky) { var stickyDialog = content.querySelector('[data-tutorhelper-lms-sticky-dialog]'); if (stickyDialog) { if (stickyDialog._annotation) { annotationRequest({ annotation_id: stickyDialog._annotation.id, note_content: stickyDialog.querySelector('[data-tutorhelper-lms-sticky-content]').value }); } else if (stickyDialog._selection) { annotationRequest({ annotation_type: 'sticky', start_offset: stickyDialog._selection.start, end_offset: stickyDialog._selection.end, selected_text: stickyDialog._selection.text, note_content: stickyDialog.querySelector('[data-tutorhelper-lms-sticky-content]').value }); } stickyDialog.close(); } return; }
		var deletion = event.target.closest('[data-tutorhelper-lms-annotation-delete]'); if (deletion) { var deleteDialog = content.querySelector('[data-tutorhelper-lms-sticky-dialog]'); if (deleteDialog && deleteDialog._annotation) { annotationRequest({ annotation_id: deleteDialog._annotation.id }, true); deleteDialog.close(); } return; }
		var toggle = event.target.closest('[data-tutorhelper-lms-toggle-notes]'); if (toggle) { var workspace = content.querySelector('.tutorhelper-lms-textbook__workspace'); workspace.classList.toggle('is-notes-hidden'); var visible = !workspace.classList.contains('is-notes-hidden'); toggle.setAttribute('aria-expanded', visible ? 'true' : 'false'); toggle.textContent = visible ? 'Hide notes' : 'Show notes'; try { window.sessionStorage.setItem('tutorhelperLmsNotesVisible', visible ? '1' : '0'); } catch (error) {} }
	});
	try {
		if (window.sessionStorage.getItem('tutorhelperLmsNotesVisible') === '0') {
			var savedWorkspace = content.querySelector('.tutorhelper-lms-textbook__workspace');
			var savedToggle = content.querySelector('[data-tutorhelper-lms-toggle-notes]');
			if (savedWorkspace && savedToggle) { savedWorkspace.classList.add('is-notes-hidden'); savedToggle.setAttribute('aria-expanded', 'false'); savedToggle.textContent = 'Show notes'; }
		}
	} catch (error) {}
	applyAnnotations();

	window.addEventListener('popstate', function () {
		var request = readerRequest(window.location.href);
		if (request) {
			loadPage(request.url, false);
		}
	});
}());
