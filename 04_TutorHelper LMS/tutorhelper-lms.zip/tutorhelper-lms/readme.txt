=== TutorHelper LMS ===
Contributors: teachallaboutit
Tags: tutor, learning management, courses, lessons, education
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: tutorhelper-bookings
Stable tag: 1.0.46
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Build and organise reusable learning content for TutorHelper Bookings.

== Description ==

TutorHelper LMS provides Levels, Subjects, Courses, Topics and Lessons, organised through the TutorHelper Learning Hub.

This package contains all of its free learning features. TutorHelper LMS Premium is a separately installed companion plugin for premium coursework and assessment workflows.

== Privacy ==

TutorHelper LMS does not send learning-content data to an external service.

== Installation ==

1. Install and activate TutorHelper Bookings.
2. Install and activate TutorHelper LMS.
3. Open TutorHelper → LMS.

== Changelog ==

= 1.0.46 =

* 🆕 🎛️ New Feature: Adds the Core Question Bank foundation with reusable draft Questions and immutable definition versions.
* 🗃️ Improvement: Adds safe Core Question-version storage without Quiz placement, import, student delivery or Premium assessment changes.

= 1.0.45 =

* ♻️ Improvement: Course Builder Topic and Lesson edit actions now use the consistent TutorHelper grey button treatment.


= 1.0.44 =

* ✨ Improvement: Refines the full-width Course Builder workspace with clearer Topic and Lesson cards, consistent action controls and accessible Course/Topic colour cues.
* 🆕 New Feature: Tutors can edit a reusable Topic title and visual colour from the Course Builder without changing its Course relationships.


= 1.0.43 =

* ♻️ Improvement: Course List View Lesson links now open in the current tab; students can return through the existing Course breadcrumbs.


= 1.0.42 =

* ✨ Improvement: Adds clear learner-note saving states, debounced private autosave, retry and copy actions while retaining manual and non-JavaScript saving.
* ♻️ Update: Lets students reopen, edit and delete their own sticky notes, with an accessible page annotation index and stale-anchor notice.



= 1.0.41 =

* 🚀 Improvement: Reading mode now uses the full available Lesson width, with comfortable visual margins.
* ♻️ Update: Adds accessible annotation icons, Course view expansion and contextual final-page Lesson navigation.
* 🆕 New Feature: Adds a Core end-of-Course completion screen.


= 1.0.40 =

* 🆕 New Feature: Adds saved All panels, Reading mode and Notes mode choices to the student Lesson Reader.
* 🚀 Improvement: Adds compact Course, Topic and Lesson location breadcrumbs and responsive reader panel layouts.


= 1.0.39 =

* 🆕 New Feature: Adds the student Course overview with accessible Topic accordions, lesson counts and Course breadcrumbs.
* 🚀 Improvement: Preserves a learner’s expanded Topic choices while opening Lessons or returning to their Course.


= 1.0.38 =

* 🐛 Bug Fix: Opens enrolled Courses in a secure standalone Course menu rather than returning to the dashboard.
* ✨ Improvement: Adds a collapsible Course outline in the Lesson Reader and advances to the next Lesson after final-page completion.
* 🛡️ Improvement: Lesson completion is available and accepted only on the final reader page.


= 1.0.37 =

* ✨ New Feature: Adds durable formal Course lesson progress, explicit completion and a secure Resume Course route.
* 🛡️ Improvement: Progress remains per student and Course/Topic/Lesson context; individual tuition grants do not create Course completion records.


= 1.0.36 =

* ✨ Improvement: Refines the student Lesson Reader for keyboard annotation access, persistent note-panel preference, reduced motion and print use.

= 1.0.35 =

* 🐛 Bug Fix: Restores saved learner highlights after reader page rendering and lets students open a saved sticky note from its highlighted text.

= 1.0.34 =

* ✨ New Feature: Adds private page-specific text highlights and sticky-note annotations in the student Lesson Reader.
* ✨ Improvement: Students can show or hide the private Lesson-notes panel.

= 1.0.33 =

* ✨ Improvement: Lesson page navigation now refreshes only the reading-page region, retaining the Lesson heading and private notes panel in place.

= 1.0.32 =

* ✨ Improvement: Student notes now belong to the whole Lesson and remain visible while a learner moves between native WordPress Lesson pages.
* 🛡️ Improvement: Existing early page notes are copied safely into the Lesson-wide note scope during upgrade; original note records are retained for recovery.

= 1.0.31 =

* 🐛 Bug Fix: Repairs secure asynchronous Lesson-note saving and adds privacy-safe diagnostics when a note request is rejected or a database write fails.
* ✨ Improvement: Student Lesson notes now support basic rich text: paragraphs, bold, italic and bullet lists.

= 1.0.30 =

* ✨ New Feature: Adds private, student-owned page notes to the standalone Lesson Reader. Notes save securely without reloading the reader and retain a standard form fallback.
* 🛡️ Improvement: Notes remain scoped to the authorised learner and Lesson context; no notes are added to shared Lesson content.

= 1.0.29 =

* ✨ Improvement: Lesson Previous, Next and page-number controls now update only the reader panel when JavaScript is available, while retaining normal link navigation as a fallback.

= 1.0.28 =

* ✨ Improvement: Presents protected Lessons in a distraction-free LMS reader document without the main-site header, navigation or theme page wrappers.

= 1.0.27 =

* 🐛 Bug Fix: Opens protected student Lessons in a dedicated full-width Reader page instead of reloading the Student Dashboard.

= 1.0.26 =

* 🛡️ Improvement: Student Lesson Reader links now use short-lived, student-scoped opaque tokens instead of exposing WordPress content IDs; access is still verified on every request.
* ✨ Improvement: Opening a shared or Course Lesson launches the Reader in a new tab, preserving the student's dashboard.

= 1.0.25 =

* ✨ New Feature: Adds the first student-facing textbook Lesson Viewer, with authorised read-only access and native WordPress page-break navigation.
* ✨ Improvement: Keeps imported and block-based Lesson content intact, including WordPress media and supported embeds.

= 1.0.23 =

* 🔌 Improvement: Adds safe extension points for the separately distributed Premium private Resource upload service, without adding storage code to the free package.


= 1.0.22 =

* ✨ Improvement: Narrows Resource Topic and Lesson choices progressively from selected Courses and Topics, while preserving existing links during edits.
* ✨ Improvement: Returns to a clear, fresh Resource form after creating a new Resource, ready for the next entry.


= 1.0.21 =

* ✨ Improvement: Collapses the Resource editor until needed and shows only fields appropriate to the selected Resource type.
* 🐛 Bug Fix: Prevents duplicate rich-text editor toolbars after Learning Hub tab navigation.
* 🛡️ Improvement: Records a Resource’s tutor-created or third-party origin; third-party items require a permission confirmation and can retain attribution details.
* ✨ Improvement: Categorises external links as videos, websites, documents or other resources.


= 1.0.20 =

* 🆕 New Feature: Adds a free reusable Resource Library for rich-text and HTTPS external-link teaching resources.
* ✨ Improvement: Resources can be associated with Levels, Subjects, Courses, Topics and Lessons without copying their master content.

= 1.0.19 =

* 🆕 New Feature: Adds drag-and-drop, keyboard-safe move controls and safe detachment for Course Topics and Topic Lessons.
* 🛡️ Improvement: Reordering validates the complete relationship list before storing a change; detaching never deletes reusable Content.

= 1.0.18 =

* 🆕 New Feature: Adds Course Builder controls to create reusable Topics and Lessons or attach existing library content safely.
* ✨ Improvement: Appends new Content relationships without changing existing links or their order.

= 1.0.17 =

* ✨ Improvement: Refines Course Builder actions, spacing, linked Level and Subject selection, and Course-level student information.
* 🆕 New Feature: Creates new Courses directly through the Course Builder.

= 1.0.16 =

* 🆕 New Feature: Adds the three-stage Course Builder workspace for Course Details, Content and Student Information.
* 🚀 Improvement: Adds a Course Builder entry point while retaining the existing Learning Hub library screens.

= 1.0.15 =

* ✨ New: Adds Course lifecycle, enrolment availability, capacity, tags, featured image and accessible Course colour metadata.
* ✨ New: Establishes dedicated structured Course enrolment records without changing existing academic Course links.

= 1.0.14 =

* 🐛 Bug Fix: Makes reusable Course → Topic relationships available safely to front-end Gradebook views.

= 1.0.13 =

* 🐛 Fix: Repairs Grade System saving by using a valid WordPress post-type key and migrates any safely detectable truncated legacy records.

= 1.0.7 =

* 🐛 Bug Fix: Adds privacy-safe TutorHelper diagnostics for LMS save and delete failures.

= 1.0.6 =

* 🆕 New Feature: Adds reusable grade systems and Course-specific grade boundaries.
* 🆕 New Feature: Supports percentage-only Courses alongside named grade scales.

= 1.0.5 =

* ✨ Enhancement: Adds searchable content attachments, clearer relationship positions and shared Learning Hub table search, filters and pagination.
* 🐛 Bug Fix: Restores the Premium Submissions workspace inside Learning Hub.

= 1.0.4 =

* ✨ Enhancement: Adds a guided Learning Hub setup screen and data-backed overview dashboard.

= 1.0.3 =

* 🐛 Bug Fix: Prevents a database-class name collision when LMS Premium is active.

= 1.0.2 =

* 🆕 New Feature: Adds Learning Hub management for Levels, Subjects, Courses, Topics and Lessons.
* 🆕 New Feature: Adds ordered reusable Course → Topic and Topic → Lesson relationships.


= 1.0.0 =

* 🆕 New Feature: First standalone free TutorHelper LMS package.
