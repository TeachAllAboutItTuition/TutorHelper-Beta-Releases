<?php
/**
 * Durable, tutor-owned import-run storage.
 *
 * IM0 creates a resumable manifest only. It never creates Courses, Lessons,
 * Quizzes, Questions, Media Library files, students or historic attempts.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Import_Runs {

	const DB_VERSION = '1.0.0';
	const BATCH_SIZE = 200;

	/**
	 * @return void
	 */
	public static function init() {
		self::maybe_install();
	}

	/**
	 * Create the durable run and per-record manifest tables.
	 *
	 * @return void
	 */
	public static function maybe_install() {
		if ( self::DB_VERSION === get_option( 'tutorhelper_lms_import_runs_db_version' ) ) {
			return;
		}

		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$runs  = self::runs_table();
		$items = self::items_table();
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$runs} (
			id bigint(20) unsigned NOT NULL auto_increment,
			tutor_user_id bigint(20) unsigned NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'preparing',
			source_hash char(64) NOT NULL,
			snapshot_json longtext NOT NULL,
			total_items int(10) unsigned NOT NULL DEFAULT 0,
			processed_items int(10) unsigned NOT NULL DEFAULT 0,
			last_error text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			paused_at datetime NULL,
			completed_at datetime NULL,
			PRIMARY KEY  (id),
			KEY tutor_status (tutor_user_id,status,updated_at),
			KEY source_hash (tutor_user_id,source_hash)
		) {$charset};

		CREATE TABLE {$items} (
			id bigint(20) unsigned NOT NULL auto_increment,
			run_id bigint(20) unsigned NOT NULL,
			source_key varchar(96) NOT NULL,
			source_kind varchar(32) NOT NULL,
			status varchar(32) NOT NULL DEFAULT 'pending',
			result_code varchar(64) NOT NULL DEFAULT '',
			result_message text NULL,
			payload_json longtext NOT NULL,
			target_type varchar(32) NOT NULL DEFAULT '',
			target_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY run_source (run_id,source_key),
			KEY run_status (run_id,status,id)
		) {$charset};";

		dbDelta( $sql );
		update_option( 'tutorhelper_lms_import_runs_db_version', self::DB_VERSION, false );
	}

	/**
	 * Store the reviewed preview as a durable tutor-owned import run.
	 *
	 * @param int   $tutor_user_id Tutor account.
	 * @param array $snapshot Sanitised preview data.
	 * @return array|WP_Error
	 */
	public static function create_from_preview( $tutor_user_id, $snapshot ) {
		self::maybe_install();
		$tutor_user_id = absint( $tutor_user_id );
		if ( ! $tutor_user_id || ! is_array( $snapshot ) ) {
			return new WP_Error( 'invalid_import_run', __( 'The reviewed import data could not be saved.', 'tutorhelper-lms' ) );
		}

		$snapshot['_run_id'] = 0;
		$items = self::snapshot_items( $snapshot );
		if ( empty( $items ) ) {
			return new WP_Error( 'empty_import_run', __( 'There are no Course, Lesson or Question records available to save in this import run.', 'tutorhelper-lms' ) );
		}

		$json = wp_json_encode( $snapshot );
		if ( ! is_string( $json ) || '' === $json ) {
			return new WP_Error( 'import_run_encode_failed', __( 'The reviewed import data could not be encoded safely.', 'tutorhelper-lms' ) );
		}
		$hash = hash( 'sha256', $json );

		global $wpdb;
		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM " . self::runs_table() . " WHERE tutor_user_id = %d AND source_hash = %s AND status IN ('preparing','paused','review') ORDER BY id DESC LIMIT 1",
				$tutor_user_id,
				$hash
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Prevents duplicate tutor-owned runs for an identical reviewed source.
		if ( $existing ) {
			return array( 'run' => self::normalise_run( $existing ), 'created' => false );
		}

		$now = current_time( 'mysql', true );
		$inserted = $wpdb->insert(
			self::runs_table(),
			array(
				'tutor_user_id'  => $tutor_user_id,
				'status'         => 'preparing',
				'source_hash'    => $hash,
				'snapshot_json'  => $json,
				'total_items'    => count( $items ),
				'processed_items'=> 0,
				'last_error'     => '',
				'created_at'     => $now,
				'updated_at'     => $now,
			),
			array( '%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Creates a tutor-requested import manifest only.
		if ( false === $inserted ) {
			return new WP_Error( 'import_run_save_failed', __( 'The import run could not be saved. Please try again.', 'tutorhelper-lms' ) );
		}

		return array( 'run' => self::get_run( absint( $wpdb->insert_id ), $tutor_user_id ), 'created' => true );
	}

	/**
	 * Prepare the next bounded set of durable manifest rows. This validates and
	 * records source items only; it does not create LMS content.
	 *
	 * @param int $run_id Run ID.
	 * @param int $tutor_user_id Tutor account.
	 * @param int $limit Optional bounded batch size.
	 * @return array|WP_Error
	 */
	public static function prepare_next_batch( $run_id, $tutor_user_id, $limit = self::BATCH_SIZE ) {
		$run = self::get_run( $run_id, $tutor_user_id );
		if ( ! $run ) {
			return new WP_Error( 'import_run_not_found', __( 'That import run is not available.', 'tutorhelper-lms' ) );
		}
		if ( 'paused' === $run['status'] ) {
			return new WP_Error( 'import_run_paused', __( 'Resume this import run before preparing another batch.', 'tutorhelper-lms' ) );
		}
		if ( 'review' === $run['status'] ) {
			return array( 'run' => $run, 'prepared' => 0, 'complete' => true );
		}
		$limit = min( 500, max( 1, absint( $limit ) ) );
		$items = self::snapshot_items( self::decode_snapshot( $run ) );
		$offset = min( absint( $run['processed_items'] ), count( $items ) );
		$batch = array_slice( $items, $offset, $limit );
		if ( empty( $batch ) ) {
			self::update_run( $run['id'], $tutor_user_id, array( 'status' => 'review', 'completed_at' => current_time( 'mysql', true ) ) );
			return array( 'run' => self::get_run( $run['id'], $tutor_user_id ), 'prepared' => 0, 'complete' => true );
		}

		global $wpdb;
		$now = current_time( 'mysql', true );
		$prepared = 0;
		foreach ( $batch as $item ) {
			$status = 'supported' === $item['source_status'] ? 'ready_for_review' : 'needs_review';
			$code = 'supported' === $item['source_status'] ? '' : 'unsupported_source_type';
			$message = 'supported' === $item['source_status']
				? __( 'Prepared for later import review. No LMS content has been created.', 'tutorhelper-lms' )
				: __( 'This source record needs review before a later import can create anything.', 'tutorhelper-lms' );
			$ok = $wpdb->query(
				$wpdb->prepare(
					"INSERT INTO " . self::items_table() . " (run_id,source_key,source_kind,status,result_code,result_message,payload_json,target_type,target_id,created_at,updated_at)
					VALUES (%d,%s,%s,%s,%s,%s,%s,'',0,%s,%s)
					ON DUPLICATE KEY UPDATE status = VALUES(status), result_code = VALUES(result_code), result_message = VALUES(result_message), payload_json = VALUES(payload_json), updated_at = VALUES(updated_at)",
					$run['id'],
					$item['source_key'],
					$item['source_kind'],
					$status,
					$code,
					$message,
					wp_json_encode( $item['payload'] ),
					$now,
					$now
				)
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Writes bounded, tutor-owned manifest rows for a future confirmed import.
			if ( false === $ok ) {
				self::update_run( $run['id'], $tutor_user_id, array( 'status' => 'failed', 'last_error' => __( 'A manifest row could not be saved. No LMS content was created.', 'tutorhelper-lms' ) ) );
				return new WP_Error( 'import_manifest_failed', __( 'The run paused because a manifest row could not be saved. No LMS content was created.', 'tutorhelper-lms' ) );
			}
			$prepared++;
		}

		$processed = $offset + $prepared;
		$complete = $processed >= count( $items );
		self::update_run(
			$run['id'],
			$tutor_user_id,
			array(
				'processed_items' => $processed,
				'total_items'     => count( $items ),
				'status'          => $complete ? 'review' : 'preparing',
				'completed_at'    => $complete ? $now : null,
				'last_error'      => '',
			)
		);
		return array( 'run' => self::get_run( $run['id'], $tutor_user_id ), 'prepared' => $prepared, 'complete' => $complete );
	}

	/**
	 * Pause a preparing run without altering its source snapshot or rows.
	 *
	 * @param int $run_id Run ID.
	 * @param int $tutor_user_id Tutor account.
	 * @return array|false
	 */
	public static function pause( $run_id, $tutor_user_id ) {
		self::update_run( $run_id, $tutor_user_id, array( 'status' => 'paused', 'paused_at' => current_time( 'mysql', true ) ) );
		return self::get_run( $run_id, $tutor_user_id );
	}

	/**
	 * Resume an intentionally paused manifest preparation run.
	 *
	 * @param int $run_id Run ID.
	 * @param int $tutor_user_id Tutor account.
	 * @return array|false
	 */
	public static function resume( $run_id, $tutor_user_id ) {
		$run = self::get_run( $run_id, $tutor_user_id );
		if ( ! $run ) {
			return false;
		}
		if ( 'paused' === $run['status'] ) {
			self::update_run( $run_id, $tutor_user_id, array( 'status' => 'preparing', 'paused_at' => null ) );
		}
		return self::get_run( $run_id, $tutor_user_id );
	}

	/**
	 * Save a later mapping or audit correction against its durable run.
	 *
	 * @param int   $run_id Run ID.
	 * @param int   $tutor_user_id Tutor account.
	 * @param array $snapshot Preview snapshot.
	 * @return bool
	 */
	public static function save_snapshot( $run_id, $tutor_user_id, $snapshot ) {
		$run = self::get_run( $run_id, $tutor_user_id );
		if ( ! $run || ! is_array( $snapshot ) ) {
			return false;
		}
		$snapshot['_run_id'] = absint( $run_id );
		$json = wp_json_encode( $snapshot );
		if ( ! is_string( $json ) || '' === $json ) {
			return false;
		}
		return self::update_run( $run_id, $tutor_user_id, array( 'snapshot_json' => $json, 'updated_at' => current_time( 'mysql', true ) ) );
	}

	/**
	 * @param int $run_id Run ID.
	 * @param int $tutor_user_id Tutor account.
	 * @return array|false
	 */
	public static function get_run( $run_id, $tutor_user_id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::runs_table() . " WHERE id = %d AND tutor_user_id = %d LIMIT 1", absint( $run_id ), absint( $tutor_user_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Retrieves only the signed-in tutor's own import run.
		return $row ? self::normalise_run( $row ) : false;
	}

	/**
	 * @param int $tutor_user_id Tutor account.
	 * @param int $limit Number of recent runs.
	 * @return array[]
	 */
	public static function get_runs_for_tutor( $tutor_user_id, $limit = 8 ) {
		global $wpdb;
		$limit = min( 50, max( 1, absint( $limit ) ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM " . self::runs_table() . " WHERE tutor_user_id = %d ORDER BY updated_at DESC, id DESC LIMIT %d", absint( $tutor_user_id ), $limit ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Lists only the signed-in tutor's own saved runs.
		return array_map( array( __CLASS__, 'normalise_run' ), is_array( $rows ) ? $rows : array() );
	}

	/**
	 * @param int $run_id Run ID.
	 * @param int $tutor_user_id Tutor account.
	 * @param int $limit Max results.
	 * @return array[]
	 */
	public static function get_item_results( $run_id, $tutor_user_id, $limit = 20 ) {
		if ( ! self::get_run( $run_id, $tutor_user_id ) ) {
			return array();
		}
		global $wpdb;
		$limit = min( 100, max( 1, absint( $limit ) ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT source_key,source_kind,status,result_code,result_message,target_type,target_id,updated_at FROM " . self::items_table() . " WHERE run_id = %d ORDER BY id ASC LIMIT %d", absint( $run_id ), $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Shows a bounded audit log for the tutor's own run.
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * @param array $snapshot Stored preview.
	 * @return array[]
	 */
	private static function snapshot_items( $snapshot ) {
		$items = array();
		foreach ( is_array( $snapshot['course']['courses'] ?? null ) ? $snapshot['course']['courses'] : array() as $record ) {
			$items[] = self::item( 'course', $record, 'supported' );
		}
		foreach ( is_array( $snapshot['course']['lessons'] ?? null ) ? $snapshot['course']['lessons'] : array() as $record ) {
			$items[] = self::item( 'lesson', $record, 'supported' );
		}
		foreach ( is_array( $snapshot['quizzes'] ?? null ) ? $snapshot['quizzes'] : array() as $quiz_index => $quiz ) {
			foreach ( is_array( $quiz['records'] ?? null ) ? $quiz['records'] : array() as $record_index => $record ) {
				$record['id'] = (string) ( $record['id'] ?? 'learndash-question-' . $quiz_index . '-' . $record_index );
				$items[] = self::item( 'learndash_question', $record, sanitize_key( $record['status'] ?? '' ) );
			}
		}
		foreach ( is_array( $snapshot['csv_questions']['records'] ?? null ) ? $snapshot['csv_questions']['records'] : array() as $record_index => $record ) {
			$record['id'] = (string) ( $record['id'] ?? 'csv-question-' . $record_index );
			$items[] = self::item( 'tutorhelper_csv_question', $record, 'supported' );
		}
		return $items;
	}

	/**
	 * @param string $kind Source kind.
	 * @param array  $record Source record.
	 * @param string $status Source support status.
	 * @return array
	 */
	private static function item( $kind, $record, $status ) {
		$key = sanitize_key( $record['id'] ?? '' );
		if ( '' === $key ) {
			$key = $kind . '-' . substr( sha1( wp_json_encode( $record ) ), 0, 20 );
		}
		return array(
			'source_key'    => $key,
			'source_kind'   => $kind,
			'source_status' => 'supported' === $status ? 'supported' : 'needs_review',
			'payload'       => $record,
		);
	}

	/**
	 * @param array $run Run data.
	 * @return array
	 */
	private static function decode_snapshot( $run ) {
		$data = json_decode( (string) ( $run['snapshot_json'] ?? '' ), true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * @param int   $run_id Run ID.
	 * @param int   $tutor_user_id Tutor account.
	 * @param array $changes Allowed update values.
	 * @return bool
	 */
	private static function update_run( $run_id, $tutor_user_id, $changes ) {
		global $wpdb;
		$allowed = array( 'status', 'snapshot_json', 'total_items', 'processed_items', 'last_error', 'updated_at', 'paused_at', 'completed_at' );
		$data = array_intersect_key( $changes, array_flip( $allowed ) );
		if ( empty( $data ) ) {
			return false;
		}
		if ( ! isset( $data['updated_at'] ) ) {
			$data['updated_at'] = current_time( 'mysql', true );
		}
		return false !== $wpdb->update( self::runs_table(), $data, array( 'id' => absint( $run_id ), 'tutor_user_id' => absint( $tutor_user_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Updates only the signed-in tutor's own durable run state.
	}

	/**
	 * @param object $row Database row.
	 * @return array
	 */
	private static function normalise_run( $row ) {
		return array(
			'id'              => absint( $row->id ),
			'tutor_user_id'   => absint( $row->tutor_user_id ),
			'status'          => sanitize_key( $row->status ),
			'source_hash'     => (string) $row->source_hash,
			'snapshot_json'   => (string) $row->snapshot_json,
			'total_items'     => absint( $row->total_items ),
			'processed_items' => absint( $row->processed_items ),
			'last_error'      => (string) $row->last_error,
			'created_at'      => (string) $row->created_at,
			'updated_at'      => (string) $row->updated_at,
			'paused_at'       => (string) $row->paused_at,
			'completed_at'    => (string) $row->completed_at,
		);
	}

	/**
	 * @return string
	 */
	private static function runs_table() {
		global $wpdb;
		return $wpdb->prefix . 'tutorhelper_lms_import_runs';
	}

	/**
	 * @return string
	 */
	private static function items_table() {
		global $wpdb;
		return $wpdb->prefix . 'tutorhelper_lms_import_run_items';
	}
}
