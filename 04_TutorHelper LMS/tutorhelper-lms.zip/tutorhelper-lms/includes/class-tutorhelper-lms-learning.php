<?php
/**
 * Free academic learning-content foundation for TutorHelper LMS.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Learning {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_content_types' ) );
	}

	public static function register_content_types() {
		$post_types = array(
			'tutorhelper_course' => __( 'Courses', 'tutorhelper-lms' ),
			'tutorhelper_topic' => __( 'Topics', 'tutorhelper-lms' ),
			'tutorhelper_lesson' => __( 'Lessons', 'tutorhelper-lms' ),
			'tutorhelper_resource' => __( 'Resources', 'tutorhelper-lms' ),
			'tutorhelper_question' => __( 'Questions', 'tutorhelper-lms' ),
			'tutorhelper_quiz'     => __( 'Quizzes', 'tutorhelper-lms' ),
		);
		foreach ( $post_types as $post_type => $label ) {
			register_post_type(
				$post_type,
				array(
					'labels' => array( 'name' => $label, 'singular_name' => rtrim( $label, 's' ) ),
					'public' => false,
					'show_ui' => true,
					'show_in_menu' => false,
					'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ),
					'show_in_rest' => true,
					'map_meta_cap' => true,
					'capability_type' => 'post',
				)
			);
		}
		register_post_type(
			'th_lms_grade_system',
			array(
				'labels' => array(
					'name'          => __( 'Grade systems', 'tutorhelper-lms' ),
					'singular_name' => __( 'Grade system', 'tutorhelper-lms' ),
				),
				'public'          => false,
				'show_ui'         => false,
				'show_in_menu'    => false,
				'supports'        => array( 'title', 'revisions' ),
				'show_in_rest'    => false,
				'map_meta_cap'    => true,
				'capability_type' => 'post',
			)
		);

		register_taxonomy( 'tutorhelper_lms_level', array( 'tutorhelper_course', 'tutorhelper_topic', 'tutorhelper_lesson', 'tutorhelper_resource' ), array( 'labels' => array( 'name' => __( 'Levels', 'tutorhelper-lms' ), 'singular_name' => __( 'Level', 'tutorhelper-lms' ) ), 'show_ui' => true, 'show_in_rest' => true, 'hierarchical' => true ) );
		register_taxonomy( 'tutorhelper_lms_subject', array( 'tutorhelper_course', 'tutorhelper_topic', 'tutorhelper_lesson', 'tutorhelper_resource' ), array( 'labels' => array( 'name' => __( 'Subjects', 'tutorhelper-lms' ), 'singular_name' => __( 'Subject', 'tutorhelper-lms' ) ), 'show_ui' => true, 'show_in_rest' => true, 'hierarchical' => true ) );
	}
}
