<?php
/**
 * Dependency checks for TutorHelper LMS.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Dependency {

	const MINIMUM_CORE_VERSION = '2.2.1';
	const MINIMUM_PRO_VERSION  = '1.3.2';

	/**
	 * Whether the free LMS dependency is loaded.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return defined( 'TUTORHELPER_BOOKINGS_VERSION' )
			&& version_compare( TUTORHELPER_BOOKINGS_VERSION, self::MINIMUM_CORE_VERSION, '>=' );
	}

	/**
	 * Add a precise admin notice rather than allowing partially loaded features.
	 *
	 * @return void
	 */
	public static function render_notice() {
		if ( self::is_available() || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		?>
		<div class="notice notice-error">
			<p>
				<?php
				esc_html_e(
					'TutorHelper LMS requires TutorHelper Bookings 2.2.1 or later to be installed and active. Free learning features are currently unavailable.',
					'tutorhelper-lms'
				);
				?>
			</p>
		</div>
		<?php
	}
}
