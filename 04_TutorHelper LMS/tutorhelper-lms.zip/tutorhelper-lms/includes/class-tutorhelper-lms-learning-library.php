<?php
/**
 * Learning Hub management for free LMS content and reusable relationships.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Learning_Library {

	const SAVE_ACTION   = 'tutorhelper_lms_save_learning_content';
	const DELETE_ACTION = 'tutorhelper_lms_delete_learning_content';

	/**
	 * Register Learning Hub form handlers.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save' ) );
		add_action( 'admin_post_' . self::DELETE_ACTION, array( __CLASS__, 'delete' ) );
		add_filter( 'tutorhelper_lms_course_topics', array( __CLASS__, 'course_topics' ), 10, 2 );
	}

	/**
	 * Render a managed Learning Hub section.
	 *
	 * @param string $tab     Current tab.
	 * @param array  $section Section definition.
	 * @return void
	 */
	public static function render_section( $tab, $section ) {
		if ( isset( $section['taxonomy'] ) ) {
			self::render_taxonomy_section( $tab, $section );
			return;
		}

		if ( isset( $section['post_type'] ) ) {
			self::render_post_section( $tab, $section );
		}
	}

	/**
	 * Save a taxonomy term or learning-content post.
	 *
	 * @return void
	 */
	public static function save() {
		self::require_tutor();
		check_admin_referer( self::SAVE_ACTION );

		$tab        = self::posted_key( 'tab' );
		$kind       = self::posted_key( 'kind' );
		$entity_id  = absint( self::posted_value( 'entity_id' ) );
		$redirect   = self::tab_url( $tab );
		$builder_id = absint( self::posted_value( 'course_builder' ) );
		$builder_stage = sanitize_key( self::posted_value( 'course_builder_stage' ) );
		if ( 'courses' === $tab && $builder_id ) {
			$redirect = TutorHelper_LMS_Course_Builder::builder_url( $builder_id, $builder_stage );
		}

		if ( 'term' === $kind && in_array( $tab, array( 'levels', 'subjects' ), true ) ) {
			$taxonomy = 'levels' === $tab ? 'tutorhelper_lms_level' : 'tutorhelper_lms_subject';
			$name     = sanitize_text_field( self::posted_value( 'name' ) );
			$description = sanitize_textarea_field( self::posted_value( 'description' ) );

			if ( '' === $name ) {
				self::redirect( add_query_arg( 'lms_error', 'missing_name', $redirect ) );
			}

			$result = $entity_id
				? wp_update_term( $entity_id, $taxonomy, array( 'name' => $name, 'description' => $description ) )
				: wp_insert_term( $name, $taxonomy, array( 'description' => $description ) );

			if ( is_wp_error( $result ) ) {
				if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
					TutorHelper_LMS_Diagnostics::wp_error(
						'Learning taxonomy save failed.',
						$result,
						array(
							'operation' => $entity_id ? 'update_learning_term' : 'create_learning_term',
							'entity_id' => $entity_id,
							'tab'       => $tab,
						)
					);
				}
				self::redirect( add_query_arg( 'lms_error', 'save_failed', $redirect ) );
			}

			self::redirect( add_query_arg( 'lms_updated', $entity_id ? 'updated' : 'created', $redirect ) );
		}

		$post_types = array(
			'courses' => 'tutorhelper_course',
			'topics'  => 'tutorhelper_topic',
			'lessons' => 'tutorhelper_lesson',
		);

		if ( ! isset( $post_types[ $tab ] ) || 'post' !== $kind ) {
			self::redirect( $redirect );
		}

		$post_type = $post_types[ $tab ];
		$title     = sanitize_text_field( self::posted_value( 'title' ) );
		$content   = isset( $_POST['content'] ) && ! is_array( $_POST['content'] )
			? wp_kses_post( wp_unslash( $_POST['content'] ) )
			: '';

		if ( '' === $title ) {
			self::redirect( add_query_arg( 'lms_error', 'missing_title', $redirect ) );
		}

		if ( 'courses' === $tab ) {
			if ( '1' === self::posted_value( 'course_details_present' ) ) {
				$course_validation = TutorHelper_LMS_Course_Settings::validate_posted_settings();
				if ( is_wp_error( $course_validation ) ) {
					self::redirect( add_query_arg( 'lms_error', sanitize_key( $course_validation->get_error_code() ), $redirect ) );
				}
			}
			if ( '1' === self::posted_value( 'course_grade_settings_present' ) && class_exists( 'TutorHelper_LMS_Grade_Systems' ) ) {
				$grade_validation = TutorHelper_LMS_Grade_Systems::validate_course_settings();
				if ( is_wp_error( $grade_validation ) ) {
					self::redirect( add_query_arg( 'lms_error', sanitize_key( $grade_validation->get_error_code() ), $redirect ) );
				}
			}
		}

		$post_data = array(
			'post_type'    => $post_type,
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => 'publish',
		);

		if ( $entity_id ) {
			$post_data['ID'] = $entity_id;
			$post_id = wp_update_post( wp_slash( $post_data ), true );
		} else {
			$post_id = wp_insert_post( wp_slash( $post_data ), true );
		}

		if ( is_wp_error( $post_id ) || ! $post_id ) {
			if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
				if ( is_wp_error( $post_id ) ) {
					TutorHelper_LMS_Diagnostics::wp_error(
						'Learning content save failed.',
						$post_id,
						array(
							'operation' => $entity_id ? 'update_learning_content' : 'create_learning_content',
							'entity_id' => $entity_id,
							'post_type' => $post_type,
							'tab'       => $tab,
						)
					);
				} else {
					TutorHelper_LMS_Diagnostics::error(
						'Learning content save did not return a post ID.',
						array(
							'operation'      => $entity_id ? 'update_learning_content' : 'create_learning_content',
							'entity_id'      => $entity_id,
							'post_type'      => $post_type,
							'tab'            => $tab,
							'failure_reason' => 'empty_post_id',
						)
					);
				}
			}
			self::redirect( add_query_arg( 'lms_error', 'save_failed', $redirect ) );
		}

		if ( 'courses' === $tab ) {
			if ( '1' === self::posted_value( 'course_taxonomies_present' ) ) {
				wp_set_object_terms( $post_id, self::posted_ids( 'level_ids' ), 'tutorhelper_lms_level', false );
				wp_set_object_terms( $post_id, self::posted_ids( 'subject_ids' ), 'tutorhelper_lms_subject', false );
			}
			if ( '1' === self::posted_value( 'course_details_present' ) ) {
				TutorHelper_LMS_Course_Settings::save_posted_settings( $post_id );
			}
			if ( '1' === self::posted_value( 'course_grade_settings_present' ) && class_exists( 'TutorHelper_LMS_Grade_Systems' ) ) {
				TutorHelper_LMS_Grade_Systems::save_course_settings( $post_id );
			}
			if ( '1' === self::posted_value( 'course_student_information_present' ) ) {
				TutorHelper_LMS_Course_Settings::save_student_information( $post_id );
			}
		}

		if ( 'topics' === $tab ) {
			self::replace_relationships( 'tutorhelper_course', $post_id, self::posted_ids( 'parent_ids' ), self::posted_orders() );
		}

		if ( 'lessons' === $tab ) {
			self::replace_relationships( 'tutorhelper_topic', $post_id, self::posted_ids( 'parent_ids' ), self::posted_orders() );
		}

		if ( 'courses' === $tab && '1' === self::posted_value( 'course_builder_new' ) ) {
			self::redirect( add_query_arg( 'lms_updated', 'created', TutorHelper_LMS_Course_Builder::builder_url( $post_id, 'course-details' ) ) );
		}

		self::redirect( add_query_arg( 'lms_updated', $entity_id ? 'updated' : 'created', $redirect ) );
	}

	/**
	 * Delete an LMS term or content item.
	 *
	 * @return void
	 */
	public static function delete() {
		self::require_tutor();

		$tab       = self::posted_key( 'tab' );
		$kind      = self::posted_key( 'kind' );
		$entity_id = absint( self::posted_value( 'entity_id' ) );
		check_admin_referer( self::DELETE_ACTION . '_' . $kind . '_' . $entity_id );

		$redirect = self::tab_url( $tab );
		$deleted  = false;

		if ( 'term' === $kind && in_array( $tab, array( 'levels', 'subjects' ), true ) ) {
			$deleted = wp_delete_term( $entity_id, 'levels' === $tab ? 'tutorhelper_lms_level' : 'tutorhelper_lms_subject' );
		} elseif ( 'post' === $kind && in_array( $tab, array( 'courses', 'topics', 'lessons' ), true ) ) {
			$deleted = wp_trash_post( $entity_id );
			self::delete_relationships_for_content( $entity_id );
		}

		if ( ! $deleted && class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			TutorHelper_LMS_Diagnostics::error(
				'Learning content delete failed.',
				array(
					'operation'      => 'delete_learning_content',
					'entity_id'      => $entity_id,
					'tab'            => $tab,
					'failure_reason' => 'delete_returned_false',
				)
			);
		}
		self::redirect( add_query_arg( $deleted ? 'lms_updated' : 'lms_error', $deleted ? 'deleted' : 'delete_failed', $redirect ) );
	}

	/**
	 * Render Level or Subject management.
	 *
	 * @param string $tab     Tab key.
	 * @param array  $section Section definition.
	 * @return void
	 */
	private static function render_taxonomy_section( $tab, $section ) {
		$taxonomy = $section['taxonomy'];
		$edit_id  = absint( isset( $_GET['edit'] ) ? $_GET['edit'] : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only display selection.
		$editing  = $edit_id ? get_term( $edit_id, $taxonomy ) : null;
		$terms    = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
		?>
		<?php self::render_notice(); ?>
		<div class="tutorhelper-lms-library-grid">
			<section class="tutorhelper-lms-library-form">
				<h3><?php echo esc_html( $editing ? sprintf( __( 'Edit %s', 'tutorhelper-lms' ), $section['label'] ) : sprintf( __( 'Add %s', 'tutorhelper-lms' ), rtrim( $section['label'], 's' ) ) ); ?></h3>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
					<input type="hidden" name="kind" value="term" />
					<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>" />
					<input type="hidden" name="entity_id" value="<?php echo esc_attr( $editing ? $editing->term_id : 0 ); ?>" />
					<?php wp_nonce_field( self::SAVE_ACTION ); ?>
					<p><label for="tutorhelper-lms-name"><strong><?php esc_html_e( 'Name', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-name" class="regular-text" type="text" name="name" required value="<?php echo esc_attr( $editing ? $editing->name : '' ); ?>" /></p>
					<p><label for="tutorhelper-lms-description"><strong><?php esc_html_e( 'Description', 'tutorhelper-lms' ); ?></strong></label><textarea id="tutorhelper-lms-description" class="large-text" rows="4" name="description"><?php echo esc_textarea( $editing ? $editing->description : '' ); ?></textarea></p>
					<p><button class="button button-primary tutorhelper-action-button" type="submit"><?php echo esc_html( $editing ? __( 'Save changes', 'tutorhelper-lms' ) : __( 'Add', 'tutorhelper-lms' ) ); ?></button><?php if ( $editing ) : ?> <a class="button" href="<?php echo esc_url( self::tab_url( $tab ) ); ?>"><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></a><?php endif; ?></p>
				</form>
			</section>
			<section>
				<?php self::render_term_table( $tab, is_array( $terms ) ? $terms : array() ); ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Render Course, Topic or Lesson management.
	 *
	 * @param string $tab     Tab key.
	 * @param array  $section Section definition.
	 * @return void
	 */
	private static function render_post_section( $tab, $section ) {
		$post_type = $section['post_type'];
		$builder_value = 'courses' === $tab && isset( $_GET['builder'] ) && ! is_array( $_GET['builder'] ) ? sanitize_key( wp_unslash( $_GET['builder'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Course Builder selection.
		if ( $builder_value ) {
			TutorHelper_LMS_Course_Builder::render( 'new' === $builder_value ? 0 : absint( $builder_value ) );
			return;
		}
		$edit_id   = absint( isset( $_GET['edit'] ) ? $_GET['edit'] : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only display selection.
		$editing   = $edit_id ? get_post( $edit_id ) : null;
		if ( $editing && $post_type !== $editing->post_type ) { $editing = null; }
		$posts = get_posts( array( 'post_type' => $post_type, 'post_status' => array( 'publish', 'draft', 'private' ), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		?>
		<?php self::render_notice(); ?>
		<?php if ( 'courses' === $tab ) : ?>
			<div class="tutorhelper-lms-course-listing">
				<div class="tutorhelper-lms-course-listing__actions"><a class="button button-primary tutorhelper-action-button tutorhelper-lms-button--orange" href="<?php echo esc_url( TutorHelper_LMS_Course_Builder::builder_url( 0 ) ); ?>"><?php esc_html_e( 'Create new Course', 'tutorhelper-lms' ); ?></a></div>
				<?php self::render_post_table( $tab, $posts ); ?>
			</div>
			<?php return; ?>
		<?php endif; ?>
		<div class="tutorhelper-lms-library-grid">
			<section class="tutorhelper-lms-library-form">
				<h3><?php echo esc_html( $editing ? sprintf( __( 'Edit %s', 'tutorhelper-lms' ), rtrim( $section['label'], 's' ) ) : sprintf( __( 'Add %s', 'tutorhelper-lms' ), rtrim( $section['label'], 's' ) ) ); ?></h3>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
					<input type="hidden" name="kind" value="post" />
					<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>" />
					<input type="hidden" name="entity_id" value="<?php echo esc_attr( $editing ? $editing->ID : 0 ); ?>" />
					<?php wp_nonce_field( self::SAVE_ACTION ); ?>
					<p><label for="tutorhelper-lms-title"><strong><?php esc_html_e( 'Title', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-title" class="regular-text" type="text" name="title" required value="<?php echo esc_attr( $editing ? $editing->post_title : '' ); ?>" /></p>
					<?php if ( 'courses' === $tab ) : ?>
						<input type="hidden" name="course_details_present" value="1" />
						<input type="hidden" name="course_taxonomies_present" value="1" />
						<input type="hidden" name="course_grade_settings_present" value="1" />
						<?php TutorHelper_LMS_Course_Settings::render_fields( $editing ? $editing->ID : 0 ); ?>
						<?php self::render_term_choices( 'level_ids', 'tutorhelper_lms_level', __( 'Levels', 'tutorhelper-lms' ), $editing ? wp_get_object_terms( $editing->ID, 'tutorhelper_lms_level', array( 'fields' => 'ids' ) ) : array() ); ?>
						<?php self::render_term_choices( 'subject_ids', 'tutorhelper_lms_subject', __( 'Subjects', 'tutorhelper-lms' ), $editing ? wp_get_object_terms( $editing->ID, 'tutorhelper_lms_subject', array( 'fields' => 'ids' ) ) : array() ); ?>
						<?php if ( class_exists( 'TutorHelper_LMS_Grade_Systems' ) ) { TutorHelper_LMS_Grade_Systems::render_course_fields( $editing ? $editing->ID : 0 ); } ?>
					<?php endif; ?>
					<?php if ( 'topics' === $tab ) : self::render_parent_choices( 'tutorhelper_course', __( 'Courses', 'tutorhelper-lms' ), $editing ? $editing->ID : 0 ); endif; ?>
					<?php if ( 'lessons' === $tab ) : self::render_parent_choices( 'tutorhelper_topic', __( 'Topics', 'tutorhelper-lms' ), $editing ? $editing->ID : 0 ); endif; ?>
					<p><label for="tutorhelper-lms-content"><strong><?php esc_html_e( 'Learning content', 'tutorhelper-lms' ); ?></strong></label><?php wp_editor( $editing ? $editing->post_content : '', 'tutorhelper-lms-content', array( 'textarea_name' => 'content', 'textarea_rows' => 8, 'media_buttons' => true, 'teeny' => false ) ); ?></p>
					<p><button class="button button-primary tutorhelper-action-button" type="submit"><?php echo esc_html( $editing ? __( 'Save changes', 'tutorhelper-lms' ) : __( 'Create', 'tutorhelper-lms' ) ); ?></button><?php if ( $editing ) : ?> <a class="button" href="<?php echo esc_url( self::tab_url( $tab ) ); ?>"><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></a><?php endif; ?></p>
				</form>
			</section>
			<section>
				<?php self::render_post_table( $tab, $posts ); ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Render searchable multi-select choices for course terms.
	 *
	 * @param string $field    Submitted field.
	 * @param string $taxonomy Taxonomy name.
	 * @param string $label    Human-readable label.
	 * @param array  $selected Selected term IDs.
	 * @return void
	 */
	public static function render_term_choices( $field, $taxonomy, $label, $selected ) {
		$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'orderby' => 'name' ) );
		?>
		<fieldset class="tutorhelper-lms-library-choices tutorhelper-lms-library-choice-picker">
			<legend><?php echo esc_html( $label ); ?></legend>
			<?php if ( empty( $terms ) || is_wp_error( $terms ) ) : ?>
				<p><?php esc_html_e( 'Create an option in its Learning Hub tab first.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<label class="screen-reader-text" for="<?php echo esc_attr( 'tutorhelper-lms-' . $field . '-search' ); ?>"><?php echo esc_html( sprintf( __( 'Search %s', 'tutorhelper-lms' ), $label ) ); ?></label>
				<input id="<?php echo esc_attr( 'tutorhelper-lms-' . $field . '-search' ); ?>" class="regular-text tutorhelper-lms-library-choice-search" type="search" placeholder="<?php echo esc_attr( sprintf( __( 'Search and select %s', 'tutorhelper-lms' ), strtolower( $label ) ) ); ?>" data-tutorhelper-lms-choice-search />
				<p class="description"><?php esc_html_e( 'Start typing to narrow the list, then select one or more items.', 'tutorhelper-lms' ); ?></p>
				<div class="tutorhelper-lms-library-choice-results" data-tutorhelper-lms-choice-results>
					<?php foreach ( $terms as $term ) : ?>
						<?php $is_selected = in_array( $term->term_id, $selected, true ); ?>
						<label class="<?php echo $is_selected ? 'is-selected' : ''; ?>" data-tutorhelper-lms-choice-option>
							<input type="checkbox" name="<?php echo esc_attr( $field ); ?>[]" value="<?php echo esc_attr( $term->term_id ); ?>" <?php checked( $is_selected ); ?> />
							<?php echo esc_html( $term->name ); ?>
						</label>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</fieldset>
		<?php
	}

	/**
	 * Render searchable parent-content attachments.
	 *
	 * Each selected parent can have its own position for the item being edited.
	 *
	 * @param string $parent_type Parent post type.
	 * @param string $label       Parent label.
	 * @param int    $child_id    Edited child post ID.
	 * @return void
	 */
	private static function render_parent_choices( $parent_type, $label, $child_id ) {
		$parents = get_posts( array( 'post_type' => $parent_type, 'post_status' => array( 'publish', 'draft', 'private' ), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$selected = $child_id ? self::parent_relationships( $parent_type, $child_id ) : array();
		$child_label = 'tutorhelper_course' === $parent_type ? __( 'Topic', 'tutorhelper-lms' ) : __( 'Lesson', 'tutorhelper-lms' );
		?>
		<fieldset class="tutorhelper-lms-library-choices tutorhelper-lms-library-choice-picker">
			<legend><?php echo esc_html( $label ); ?></legend>
			<?php if ( empty( $parents ) ) : ?>
				<p><?php esc_html_e( 'Create a parent item in its Learning Hub tab first.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<label class="screen-reader-text" for="<?php echo esc_attr( 'tutorhelper-lms-' . $parent_type . '-search' ); ?>"><?php echo esc_html( sprintf( __( 'Search %s', 'tutorhelper-lms' ), $label ) ); ?></label>
				<input id="<?php echo esc_attr( 'tutorhelper-lms-' . $parent_type . '-search' ); ?>" class="regular-text tutorhelper-lms-library-choice-search" type="search" placeholder="<?php echo esc_attr( sprintf( __( 'Search and attach %s', 'tutorhelper-lms' ), strtolower( $label ) ) ); ?>" data-tutorhelper-lms-choice-search />
				<p class="description"><?php esc_html_e( 'Start typing to find an item, then tick it to attach it. You can attach more than one.', 'tutorhelper-lms' ); ?></p>
				<div class="tutorhelper-lms-library-choice-results" data-tutorhelper-lms-choice-results>
					<?php foreach ( $parents as $parent ) : ?>
						<?php
						$order       = isset( $selected[ $parent->ID ] ) ? $selected[ $parent->ID ] : '';
						$is_selected = isset( $selected[ $parent->ID ] );
						?>
						<div class="<?php echo $is_selected ? 'is-selected' : 'is-not-selected'; ?>" data-tutorhelper-lms-choice-option>
							<label class="tutorhelper-lms-library-choice-name"><input type="checkbox" name="parent_ids[]" value="<?php echo esc_attr( $parent->ID ); ?>" <?php checked( $is_selected ); ?> /> <?php echo esc_html( $parent->post_title ); ?></label>
							<div class="tutorhelper-lms-library-position">
								<label><?php echo esc_html( sprintf( __( '%1$s position in this %2$s', 'tutorhelper-lms' ), $child_label, rtrim( $label, 's' ) ) ); ?>
									<input type="number" min="1" name="relationship_order[<?php echo esc_attr( $parent->ID ); ?>]" value="<?php echo esc_attr( $order ); ?>" <?php disabled( ! $is_selected ); ?> />
								</label>
								<p class="description"><?php esc_html_e( 'Use 1 for first, or leave blank to place it after existing items.', 'tutorhelper-lms' ); ?></p>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</fieldset>
		<?php
	}

	private static function render_term_table( $tab, $terms ) {
		?><table class="widefat striped<?php echo $is_course_table ? ' tutorhelper-lms-course-table' : ''; ?>"><thead><tr><th><?php esc_html_e( 'Name', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Description', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Actions', 'tutorhelper-lms' ); ?></th></tr></thead><tbody><?php if ( empty( $terms ) ) : ?><tr><td colspan="3"><?php esc_html_e( 'Nothing has been created yet.', 'tutorhelper-lms' ); ?></td></tr><?php else : foreach ( $terms as $term ) : ?><tr><td><strong><?php echo esc_html( $term->name ); ?></strong></td><td><?php echo esc_html( $term->description ); ?></td><td><?php self::render_actions( $tab, 'term', $term->term_id ); ?></td></tr><?php endforeach; endif; ?></tbody></table><?php
	}

	private static function render_post_table( $tab, $posts ) {
		$is_course_table = 'courses' === $tab;
		?>
		<table class="widefat striped">
			<thead><tr>
				<th><?php esc_html_e( 'Title', 'tutorhelper-lms' ); ?></th>
				<?php if ( $is_course_table ) : ?><th><?php esc_html_e( 'Lifecycle', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Enrolments', 'tutorhelper-lms' ); ?></th><?php endif; ?>
				<th><?php esc_html_e( 'Linked to', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'tutorhelper-lms' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( empty( $posts ) ) : ?>
				<tr><td colspan="<?php echo esc_attr( $is_course_table ? 5 : 3 ); ?>"><?php esc_html_e( 'Nothing has been created yet.', 'tutorhelper-lms' ); ?></td></tr>
			<?php else : foreach ( $posts as $post ) : ?>
				<tr>
					<td><strong><?php echo esc_html( $post->post_title ); ?></strong></td>
					<?php if ( $is_course_table ) : ?>
						<td><?php echo esc_html( TutorHelper_LMS_Course_Settings::lifecycle_labels()[ TutorHelper_LMS_Course_Settings::lifecycle( $post->ID ) ] ); ?></td>
						<td><?php $capacity = TutorHelper_LMS_Course_Settings::capacity( $post->ID ); $active = TutorHelper_LMS_Course_Enrolments::active_count( $post->ID ); echo esc_html( $active . ( $capacity ? ' / ' . $capacity : ' / ' . __( 'Unlimited', 'tutorhelper-lms' ) ) . ( TutorHelper_LMS_Course_Settings::enrolments_open( $post->ID ) ? ' · ' . __( 'Open', 'tutorhelper-lms' ) : ' · ' . __( 'Closed', 'tutorhelper-lms' ) ) ); ?></td>
					<?php endif; ?>
					<td><?php echo esc_html( self::link_label( $tab, $post->ID ) ); ?></td>
					<td><?php self::render_actions( $tab, 'post', $post->ID ); ?></td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>
		<?php
	}

	private static function render_actions( $tab, $kind, $entity_id ) {
		$edit = add_query_arg( 'edit', absint( $entity_id ), self::tab_url( $tab ) );
		if ( 'courses' === $tab && 'post' === $kind ) {
			echo '<a class="button button-primary tutorhelper-action-button tutorhelper-lms-button--orange" href="' . esc_url( TutorHelper_LMS_Course_Builder::builder_url( $entity_id ) ) . '">' . esc_html__( 'Edit Course', 'tutorhelper-lms' ) . '</a> ';
		}
		?><?php if ( 'courses' !== $tab || 'post' !== $kind ) : ?><a href="<?php echo esc_url( $edit ); ?>"><?php esc_html_e( 'Edit', 'tutorhelper-lms' ); ?></a><?php endif; ?><form class="tutorhelper-lms-library-delete" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="<?php echo esc_attr( self::DELETE_ACTION ); ?>" /><input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>" /><input type="hidden" name="kind" value="<?php echo esc_attr( $kind ); ?>" /><input type="hidden" name="entity_id" value="<?php echo esc_attr( $entity_id ); ?>" /><?php wp_nonce_field( self::DELETE_ACTION . '_' . $kind . '_' . absint( $entity_id ) ); ?><button type="submit" class="button-link-delete"><?php esc_html_e( 'Delete', 'tutorhelper-lms' ); ?></button></form><?php
	}

	private static function replace_relationships( $parent_type, $child_id, $parent_ids, $orders ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$child_type = get_post_type( $child_id );
		$wpdb->delete( $table, array( 'child_type' => $child_type, 'child_id' => absint( $child_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Replaces one content item's reusable parents.
		$position = 0;
		foreach ( $parent_ids as $parent_id ) {
			if ( $parent_type !== get_post_type( $parent_id ) ) { continue; }
			$position++;
			$order = isset( $orders[ $parent_id ] ) && '' !== $orders[ $parent_id ] ? absint( $orders[ $parent_id ] ) : $position;
			$wpdb->insert( $table, array( 'parent_type' => $parent_type, 'parent_id' => absint( $parent_id ), 'child_type' => $child_type, 'child_id' => absint( $child_id ), 'sort_order' => $order, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds explicit reusable content links.
		}
	}

	/**
	 * Supply the reusable topics linked to an LMS course for optional integrations.
	 *
	 * @param array $topics Existing topic rows.
	 * @param int   $course_id LMS course post ID.
	 * @return array<int,array{id:int,title:string}>
	 */
	public static function course_topics( $topics, $course_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d ORDER BY sort_order ASC, id ASC", 'tutorhelper_course', absint( $course_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Provides explicit, ordered course-to-topic links.
		$items = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$topic_id = absint( $row->child_id );
			if ( 'tutorhelper_topic' === get_post_type( $topic_id ) ) {
				$items[] = array( 'id' => $topic_id, 'title' => html_entity_decode( get_the_title( $topic_id ), ENT_QUOTES, get_bloginfo( 'charset' ) ) );
			}
		}
		return $items;
	}

	private static function parent_relationships( $parent_type, $child_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT parent_id, sort_order FROM {$table} WHERE parent_type = %s AND child_id = %d ORDER BY sort_order ASC", $parent_type, absint( $child_id ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads reusable relationship records.
		$results = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) { $results[ absint( $row['parent_id'] ) ] = absint( $row['sort_order'] ); }
		return $results;
	}

	private static function delete_relationships_for_content( $content_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE parent_id = %d OR child_id = %d", absint( $content_id ), absint( $content_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only links belonging to deleted content.
	}

	private static function link_label( $tab, $post_id ) {
		if ( 'courses' === $tab ) {
			$levels = wp_get_object_terms( $post_id, 'tutorhelper_lms_level', array( 'fields' => 'names' ) );
			$subjects = wp_get_object_terms( $post_id, 'tutorhelper_lms_subject', array( 'fields' => 'names' ) );
			return implode( ' · ', array_filter( array( implode( ', ', $levels ), implode( ', ', $subjects ) ) ) );
		}
		$parent_type = 'topics' === $tab ? 'tutorhelper_course' : 'tutorhelper_topic';
		$ids = array_keys( self::parent_relationships( $parent_type, $post_id ) );
		$names = array();
		foreach ( $ids as $id ) { $names[] = get_the_title( $id ); }
		return implode( ', ', array_filter( $names ) );
	}

	private static function posted_ids( $name ) {
		$values = isset( $_POST[ $name ] ) && is_array( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : array();
		return array_values( array_unique( array_filter( array_map( 'absint', $values ) ) ) );
	}

	private static function posted_orders() {
		$values = isset( $_POST['relationship_order'] ) && is_array( $_POST['relationship_order'] ) ? wp_unslash( $_POST['relationship_order'] ) : array();
		$orders = array();
		foreach ( $values as $id => $order ) { $orders[ absint( $id ) ] = sanitize_text_field( $order ); }
		return $orders;
	}

	private static function posted_key( $name ) { return sanitize_key( self::posted_value( $name ) ); }
	private static function posted_value( $name ) { return isset( $_POST[ $name ] ) && ! is_array( $_POST[ $name ] ) ? (string) wp_unslash( $_POST[ $name ] ) : ''; }

	private static function require_tutor() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage learning content.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
	}

	private static function tab_url( $tab ) { return add_query_arg( array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => sanitize_key( $tab ) ), admin_url( 'admin.php' ) ); }
	private static function redirect( $url ) { wp_safe_redirect( $url ); exit; }

	private static function render_notice() {
		$updated = isset( $_GET['lms_updated'] ) ? sanitize_key( wp_unslash( $_GET['lms_updated'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect notice.
		$error = isset( $_GET['lms_error'] ) ? sanitize_key( wp_unslash( $_GET['lms_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect notice.
		$errors = array(
			'missing_grade_boundaries' => __( 'Enter a minimum percentage for every grade in the selected grade system.', 'tutorhelper-lms' ),
			'invalid_grade_boundaries' => __( 'Course grade boundaries must be between 0 and 100 and descend from the highest grade to the lowest.', 'tutorhelper-lms' ),
			'invalid_grade_system'      => __( 'Choose a valid grade system for this course.', 'tutorhelper-lms' ),
			'invalid_course_lifecycle'  => __( 'Choose a valid Course lifecycle.', 'tutorhelper-lms' ),
			'invalid_course_capacity'   => __( 'Maximum enrolments must be a whole number of zero or more.', 'tutorhelper-lms' ),
		);
		if ( $updated ) { echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Learning content saved.', 'tutorhelper-lms' ) . '</p></div>'; }
		if ( $error ) { echo '<div class="notice notice-error"><p>' . esc_html( isset( $errors[ $error ] ) ? $errors[ $error ] : __( 'The learning content could not be saved. Check the required fields and try again.', 'tutorhelper-lms' ) ) . '</p></div>'; }
	}
}
