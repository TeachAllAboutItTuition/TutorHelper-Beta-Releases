<?php
/**
 * Course Builder workspace foundation.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Course_Builder {

	const STAGE_DETAILS = 'course-details';
	const STAGE_CONTENT = 'content';
	const STAGE_STUDENTS = 'student-information';
	const CONTENT_ACTION = 'tutorhelper_lms_manage_course_content';
	const ORDER_AJAX_ACTION = 'tutorhelper_lms_reorder_course_content';
	const META_VIDEO_RESOURCE = '_tutorhelper_lms_lesson_video_resource_id';
	const META_TOPIC_COLOUR = '_tutorhelper_lms_topic_colour';

	/**
	 * Register the builder entry point.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_' . self::CONTENT_ACTION, array( __CLASS__, 'handle_content_action' ) );
		add_action( 'wp_ajax_' . self::ORDER_AJAX_ACTION, array( __CLASS__, 'ajax_reorder_content' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'load-post.php', array( __CLASS__, 'capture_block_editor_return_context' ) );
		add_filter( 'redirect_post_location', array( __CLASS__, 'preserve_block_editor_return_context' ), 10, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'render_block_editor_return_link' ) );
	}

	/**
	 * Render one Course Builder workspace.
	 *
	 * @param int $course_id Course post ID.
	 * @return void
	 */
	public static function render( $course_id ) {
		$course_id = absint( $course_id );
		$course    = get_post( $course_id );
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) || ( $course_id && ( ! $course || 'tutorhelper_course' !== $course->post_type ) ) ) {
			wp_die( esc_html__( 'You do not have permission to build this Course.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		$stage = $course_id ? self::selected_stage() : self::STAGE_DETAILS;
		?>
		<section class="tutorhelper-main-section tutorhelper-lms-course-builder">
			<header class="tutorhelper-main-section__header">
				<div class="tutorhelper-main-section__header-content">
					<p class="tutorhelper-lms-course-builder__eyebrow"><?php esc_html_e( 'Learning Hub / Courses', 'tutorhelper-lms' ); ?></p>
					<h2><?php echo esc_html( $course && $course->post_title ? $course->post_title : __( 'New Course', 'tutorhelper-lms' ) ); ?></h2>
					<p><?php esc_html_e( 'Build Course information and inspect its reusable academic structure in one workspace.', 'tutorhelper-lms' ); ?></p>
				</div>
				<a class="button button-primary tutorhelper-action-button tutorhelper-lms-button--orange" href="<?php echo esc_url( self::courses_url() ); ?>"><?php esc_html_e( 'Back to Courses', 'tutorhelper-lms' ); ?></a>
			</header>
			<div class="tutorhelper-main-section__body">
				<?php self::render_notice(); ?>
				<nav class="tutorhelper-lms-course-builder__steps" aria-label="<?php esc_attr_e( 'Course Builder stages', 'tutorhelper-lms' ); ?>">
					<?php self::render_stage_link( $course_id, self::STAGE_DETAILS, __( 'Course Details', 'tutorhelper-lms' ), $stage ); ?>
					<?php self::render_stage_link( $course_id, self::STAGE_CONTENT, __( 'Content', 'tutorhelper-lms' ), $stage ); ?>
					<?php self::render_stage_link( $course_id, self::STAGE_STUDENTS, __( 'Student Information', 'tutorhelper-lms' ), $stage ); ?>
				</nav>
				<?php if ( self::STAGE_DETAILS === $stage ) : ?>
					<?php self::render_details_stage( $course ); ?>
				<?php elseif ( self::STAGE_CONTENT === $stage ) : ?>
					<?php self::render_content_stage( $course_id ); ?>
				<?php else : ?>
					<?php self::render_students_stage( $course_id ); ?>
				<?php endif; ?>
			</div>
		</section>
		<?php if ( $course_id && self::STAGE_CONTENT === $stage ) : self::render_requested_topic_editor( $course_id ); self::render_requested_lesson_editor( $course_id ); self::render_requested_resource_editor( $course_id ); self::render_requested_quiz_topic_editor( $course_id ); endif; ?>
		<?php
	}

	/** Render Course Details using the existing Learning Library save action. */
	private static function render_details_stage( $course ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form tutorhelper-lms-course-builder__form">
			<input type="hidden" name="action" value="<?php echo esc_attr( TutorHelper_LMS_Learning_Library::SAVE_ACTION ); ?>" />
			<input type="hidden" name="kind" value="post" />
			<input type="hidden" name="tab" value="courses" />
			<input type="hidden" name="entity_id" value="<?php echo esc_attr( $course ? $course->ID : 0 ); ?>" />
			<input type="hidden" name="course_builder" value="<?php echo esc_attr( $course ? $course->ID : 0 ); ?>" />
			<input type="hidden" name="course_builder_new" value="<?php echo esc_attr( $course ? 0 : 1 ); ?>" />
			<input type="hidden" name="course_builder_stage" value="<?php echo esc_attr( self::STAGE_DETAILS ); ?>" />
			<input type="hidden" name="course_details_present" value="1" />
			<input type="hidden" name="course_taxonomies_present" value="1" />
			<?php wp_nonce_field( TutorHelper_LMS_Learning_Library::SAVE_ACTION ); ?>
			<p><label for="tutorhelper-lms-builder-title"><strong><?php esc_html_e( 'Course title', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-builder-title" class="regular-text" type="text" name="title" required value="<?php echo esc_attr( $course ? $course->post_title : '' ); ?>" /></p>
			<p><label for="tutorhelper-lms-builder-content"><strong><?php esc_html_e( 'Course description', 'tutorhelper-lms' ); ?></strong></label><?php wp_editor( $course ? $course->post_content : '', 'tutorhelper-lms-builder-content', array( 'textarea_name' => 'content', 'textarea_rows' => 10, 'media_buttons' => true, 'teeny' => false ) ); ?></p>
			<?php TutorHelper_LMS_Course_Settings::render_fields( $course ? $course->ID : 0 ); ?>
			<?php self::render_term_multi_select( 'level_ids', 'tutorhelper_lms_level', __( 'Levels', 'tutorhelper-lms' ), $course ? wp_get_object_terms( $course->ID, 'tutorhelper_lms_level', array( 'fields' => 'ids' ) ) : array() ); ?>
			<?php self::render_term_multi_select( 'subject_ids', 'tutorhelper_lms_subject', __( 'Subjects', 'tutorhelper-lms' ), $course ? wp_get_object_terms( $course->ID, 'tutorhelper_lms_subject', array( 'fields' => 'ids' ) ) : array() ); ?>
			<p><button class="button button-primary tutorhelper-action-button" type="submit"><?php esc_html_e( 'Save Course details', 'tutorhelper-lms' ); ?></button></p>
		</form>
		<?php
	}

	/** Render reusable Course → Topic → Lesson content controls. */
	private static function render_content_stage( $course_id ) {
		$topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
		$course_colour = class_exists( 'TutorHelper_LMS_Course_Settings' ) ? TutorHelper_LMS_Course_Settings::colour( $course_id ) : '';
		$course_colour = sanitize_hex_color( $course_colour ) ?: '#174957';
		?>
		<div class="tutorhelper-lms-course-builder__content" style="--tutorhelper-course-colour:<?php echo esc_attr( $course_colour ); ?>" data-tutorhelper-lms-course-content data-course-id="<?php echo esc_attr( $course_id ); ?>">
			<div class="tutorhelper-lms-course-builder__content-heading">
				<div><p class="tutorhelper-lms-course-builder__course-colour"><span aria-hidden="true"></span><?php esc_html_e( 'Course colour', 'tutorhelper-lms' ); ?></p><h3><?php esc_html_e( 'Course content', 'tutorhelper-lms' ); ?></h3><p><?php esc_html_e( 'Drag Topics or Lessons to reorder them, or use the move buttons. Removing an item only removes it from this Course or Topic; the reusable record remains available elsewhere.', 'tutorhelper-lms' ); ?></p></div>
			</div>
			<?php self::render_curriculum_resource_summary( $course_id, 'tutorhelper_course', $course_id, __( 'Course resources', 'tutorhelper-lms' ) ); ?>
			<?php self::render_topic_controls( $course_id, $topics ); ?>
			<?php if ( ! empty( $topics ) ) : ?><div class="tutorhelper-lms-course-builder__topic-bulk-actions"><button type="button" class="button tutorhelper-lms-button--grey" data-tutorhelper-lms-expand-topics><?php esc_html_e( 'Expand all topics', 'tutorhelper-lms' ); ?></button><button type="button" class="button tutorhelper-lms-button--grey" data-tutorhelper-lms-collapse-topics><?php esc_html_e( 'Collapse all topics', 'tutorhelper-lms' ); ?></button></div><?php endif; ?>
			<?php if ( empty( $topics ) ) : ?>
				<p class="tutorhelper-lms-empty-state"><?php esc_html_e( 'No Topics are attached to this Course yet. Create a new Topic or attach one from your library.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<div class="tutorhelper-lms-course-builder__topics" data-tutorhelper-lms-sortable-list data-parent-type="tutorhelper_course" data-parent-id="<?php echo esc_attr( $course_id ); ?>" data-child-type="tutorhelper_topic">
					<?php foreach ( $topics as $topic_index => $topic ) : ?>
						<?php $topic_id = absint( $topic['id'] ?? 0 ); $lessons = self::topic_lessons( $topic_id ); $topic_colour = sanitize_hex_color( get_post_meta( $topic_id, self::META_TOPIC_COLOUR, true ) ) ?: '#287ca8'; ?>
						<article class="tutorhelper-lms-course-builder__topic" style="--tutorhelper-topic-colour:<?php echo esc_attr( $topic_colour ); ?>" data-tutorhelper-lms-sortable-item data-child-id="<?php echo esc_attr( $topic_id ); ?>">
							<header><span class="dashicons dashicons-category" aria-hidden="true"></span><span class="tutorhelper-lms-course-builder__topic-colour" aria-hidden="true"></span><div><h4><?php echo esc_html( $topic['title'] ?? __( 'Topic', 'tutorhelper-lms' ) ); ?></h4><p><?php /* translators: %d: Number of Lessons in a Topic. */ echo esc_html( sprintf( _n( '%d Lesson', '%d Lessons', count( $lessons ), 'tutorhelper-lms' ), count( $lessons ) ) ); ?></p></div><button type="button" class="button tutorhelper-lms-button--grey tutorhelper-lms-course-builder__topic-toggle" data-tutorhelper-lms-topic-toggle aria-expanded="true"><span class="dashicons dashicons-arrow-up-alt2" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Collapse topic', 'tutorhelper-lms' ); ?></span></button><a class="button tutorhelper-lms-button--grey tutorhelper-lms-course-builder__edit-topic" href="<?php echo esc_url( self::topic_editor_url( $course_id, $topic_id ) ); ?>"><?php esc_html_e( 'Edit topic', 'tutorhelper-lms' ); ?></a><?php self::render_relationship_controls( $course_id, 'tutorhelper_course', $course_id, 'tutorhelper_topic', $topic_id, $topic_index, count( $topics ) ); ?></header>
							<?php do_action( 'tutorhelper_lms_course_builder_topic_options', $course_id, $topic_id ); ?>
							<?php self::render_curriculum_resource_summary( $course_id, 'tutorhelper_topic', $topic_id, __( 'Topic resources', 'tutorhelper-lms' ) ); ?>
							<?php self::render_topic_activity_list( $course_id, $topic_id ); ?>
							<?php self::render_lesson_controls( $course_id, $topic_id, $lessons ); ?>
							<?php self::render_topic_quiz_section( $course_id, $topic_id ); ?>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}


	/** Display explicit Course/Topic Resource Library links without copying the master resources. */
	private static function render_curriculum_resource_summary( $course_id, $parent_type, $parent_id, $label ) {
		$ids = self::curriculum_resource_ids( $parent_type, $parent_id );
		?>
		<div class="tutorhelper-lms-course-builder__curriculum-resources"><strong><?php echo esc_html( $label ); ?></strong>
			<?php foreach ( $ids as $resource_id ) : ?><span class="tutorhelper-lms-course-builder__resource-chip"><span class="dashicons dashicons-paperclip" aria-hidden="true"></span><?php echo esc_html( get_the_title( $resource_id ) ); ?></span><?php endforeach; ?>
			<a class="button-link" href="<?php echo esc_url( self::resource_editor_url( $course_id, $parent_type, $parent_id ) ); ?>"><?php echo esc_html( $ids ? __( 'Manage resources', 'tutorhelper-lms' ) : __( 'Add resources', 'tutorhelper-lms' ) ); ?></a>
		</div>
		<?php
	}

	/** Render a generic Course/Topic resource selector in the current Course Builder. */
	private static function render_requested_resource_editor( $course_id ) {
		$parent_type = isset( $_GET['resource_parent_type'] ) && ! is_array( $_GET['resource_parent_type'] ) ? sanitize_key( wp_unslash( $_GET['resource_parent_type'] ) ) : '';
		$parent_id = isset( $_GET['resource_parent_id'] ) && ! is_array( $_GET['resource_parent_id'] ) ? absint( wp_unslash( $_GET['resource_parent_id'] ) ) : 0;
		$valid = ( 'tutorhelper_course' === $parent_type && $parent_id === absint( $course_id ) ) || ( 'tutorhelper_topic' === $parent_type && self::course_has_topic( $course_id, $parent_id ) );
		if ( ! $valid ) { return; }
		$resources = self::available_lesson_resources();
		$selected = self::curriculum_resource_ids( $parent_type, $parent_id );
		?>
		<dialog class="tutorhelper-lms-lesson-editor" data-tutorhelper-lms-lesson-editor data-auto-open aria-labelledby="tutorhelper-lms-resource-editor-title">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form tutorhelper-lms-lesson-editor__form">
				<header class="tutorhelper-lms-lesson-editor__header"><div><p class="tutorhelper-lms-course-builder__eyebrow"><?php echo esc_html( 'tutorhelper_course' === $parent_type ? get_the_title( $course_id ) : get_the_title( $parent_id ) ); ?></p><h2 id="tutorhelper-lms-resource-editor-title"><?php esc_html_e( 'Manage Resource Library links', 'tutorhelper-lms' ); ?></h2></div><button type="button" class="button-link" data-tutorhelper-lms-close-lesson-editor aria-label="<?php esc_attr_e( 'Close resource selector', 'tutorhelper-lms' ); ?>">×</button></header>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CONTENT_ACTION ); ?>" /><input type="hidden" name="content_operation" value="save_resource_links" /><input type="hidden" name="course_id" value="<?php echo esc_attr( $course_id ); ?>" /><input type="hidden" name="resource_parent_type" value="<?php echo esc_attr( $parent_type ); ?>" /><input type="hidden" name="resource_parent_id" value="<?php echo esc_attr( $parent_id ); ?>" />
				<?php wp_nonce_field( self::CONTENT_ACTION . '_' . absint( $course_id ) ); ?>
				<div class="tutorhelper-lms-lesson-editor__content-choice"><span class="dashicons dashicons-paperclip" aria-hidden="true"></span><div><h3><?php esc_html_e( 'Existing Resource Library items', 'tutorhelper-lms' ); ?></h3><p><?php esc_html_e( 'These are links to master Resources. Saving does not copy a file or create another Google Drive item.', 'tutorhelper-lms' ); ?></p><label class="screen-reader-text" for="tutorhelper-lms-curriculum-resource-filter"><?php esc_html_e( 'Filter resources', 'tutorhelper-lms' ); ?></label><input id="tutorhelper-lms-curriculum-resource-filter" type="search" class="regular-text" placeholder="<?php esc_attr_e( 'Filter resources…', 'tutorhelper-lms' ); ?>" data-tutorhelper-lms-filter-resources /><select name="resource_ids[]" multiple size="12" class="tutorhelper-lms-resource-select" data-tutorhelper-lms-lesson-resources><?php foreach ( $resources as $resource ) : ?><option value="<?php echo esc_attr( $resource['id'] ); ?>" <?php selected( in_array( $resource['id'], $selected, true ) ); ?>><?php echo esc_html( $resource['title'] . ' (' . $resource['label'] . ')' ); ?></option><?php endforeach; ?></select></div></div>
				<footer><button type="button" class="button" data-tutorhelper-lms-close-lesson-editor><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></button><button type="submit" class="button button-primary tutorhelper-action-button"><?php esc_html_e( 'Save resource links', 'tutorhelper-lms' ); ?></button></footer>
			</form>
		</dialog>
		<?php
	}

	/** Render controls to create or attach a reusable Topic. */
	private static function render_topic_controls( $course_id, $attached_topics ) {
		$attached_ids = wp_list_pluck( is_array( $attached_topics ) ? $attached_topics : array(), 'id' );
		$available = self::available_content( 'tutorhelper_topic', $attached_ids );
		?>
		<div class="tutorhelper-lms-course-builder__content-controls">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__quick-form">
				<?php self::content_action_fields( $course_id, 'create_topic' ); ?>
				<label for="tutorhelper-lms-new-topic"><strong><?php esc_html_e( 'New Topic', 'tutorhelper-lms' ); ?></strong></label>
				<input id="tutorhelper-lms-new-topic" class="regular-text" type="text" name="content_title" required placeholder="<?php esc_attr_e( 'e.g. Algebraic methods', 'tutorhelper-lms' ); ?>" />
				<button class="button button-primary tutorhelper-action-button tutorhelper-lms-button--orange" type="submit"><?php esc_html_e( 'Create Topic', 'tutorhelper-lms' ); ?></button>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__quick-form">
				<?php self::content_action_fields( $course_id, 'attach_topic' ); ?>
				<label for="tutorhelper-lms-attach-topic"><strong><?php esc_html_e( 'Add an existing Topic', 'tutorhelper-lms' ); ?></strong></label>
				<select id="tutorhelper-lms-attach-topic" name="content_id" <?php disabled( empty( $available ) ); ?>><option value=""><?php echo esc_html( empty( $available ) ? __( 'No unattached Topics available', 'tutorhelper-lms' ) : __( 'Choose a Topic', 'tutorhelper-lms' ) ); ?></option><?php foreach ( $available as $item ) : ?><option value="<?php echo esc_attr( $item->ID ); ?>"><?php echo esc_html( $item->post_title ); ?></option><?php endforeach; ?></select>
				<button class="button tutorhelper-action-button" type="submit" <?php disabled( empty( $available ) ); ?>><?php esc_html_e( 'Add Topic', 'tutorhelper-lms' ); ?></button>
			</form>
		</div>
		<?php
	}

	/** Render controls to create or attach a reusable Lesson under a Topic. */
	private static function render_lesson_controls( $course_id, $topic_id, $attached_lessons ) {
		// A reusable Lesson may belong to one Topic in this Course only. This
		// prevents duplicate delivery paths while still allowing reuse in another Course.
		$attached_ids = self::course_lesson_ids( $course_id );
		$available = self::available_content( 'tutorhelper_lesson', $attached_ids );
		?>
		<div class="tutorhelper-lms-course-builder__lesson-controls">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__quick-form">
				<?php self::content_action_fields( $course_id, 'create_lesson', $topic_id ); ?>
				<label for="<?php echo esc_attr( 'tutorhelper-lms-new-lesson-' . $topic_id ); ?>"><strong><?php esc_html_e( 'New Lesson', 'tutorhelper-lms' ); ?></strong></label>
				<input id="<?php echo esc_attr( 'tutorhelper-lms-new-lesson-' . $topic_id ); ?>" class="regular-text" type="text" name="content_title" required placeholder="<?php esc_attr_e( 'e.g. Solving linear equations', 'tutorhelper-lms' ); ?>" />
				<button class="button button-primary tutorhelper-action-button tutorhelper-lms-button--orange" type="submit"><?php esc_html_e( 'Create Lesson', 'tutorhelper-lms' ); ?></button>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__quick-form">
				<?php self::content_action_fields( $course_id, 'attach_lesson', $topic_id ); ?>
				<label for="<?php echo esc_attr( 'tutorhelper-lms-attach-lesson-' . $topic_id ); ?>"><strong><?php esc_html_e( 'Add an existing Lesson', 'tutorhelper-lms' ); ?></strong></label>
				<select id="<?php echo esc_attr( 'tutorhelper-lms-attach-lesson-' . $topic_id ); ?>" name="content_id" <?php disabled( empty( $available ) ); ?>><option value=""><?php echo esc_html( empty( $available ) ? __( 'No Lessons from other Courses available', 'tutorhelper-lms' ) : __( 'Choose a Lesson', 'tutorhelper-lms' ) ); ?></option><?php foreach ( $available as $item ) : ?><option value="<?php echo esc_attr( $item->ID ); ?>"><?php echo esc_html( $item->post_title ); ?></option><?php endforeach; ?></select>
				<button class="button tutorhelper-action-button" type="submit" <?php disabled( empty( $available ) ); ?>><?php esc_html_e( 'Add Lesson', 'tutorhelper-lms' ); ?></button>
			</form>
		</div>
		<?php
	}


	/** Render linked lesson video and Resource Library items beneath the lesson title. */
	private static function render_lesson_resource_summary( $lesson_id ) {
		$video_id = absint( get_post_meta( $lesson_id, self::META_VIDEO_RESOURCE, true ) );
		$resource_ids = array_values( array_diff( self::lesson_resource_ids( $lesson_id ), array( $video_id ) ) );
		if ( ! $video_id && ! $resource_ids ) { return; }
		?>
		<div class="tutorhelper-lms-course-builder__lesson-resources" aria-label="<?php esc_attr_e( 'Linked lesson resources', 'tutorhelper-lms' ); ?>">
			<?php if ( $video_id ) : ?><span class="tutorhelper-lms-course-builder__resource-chip is-video"><span class="dashicons dashicons-video-alt3" aria-hidden="true"></span><?php echo esc_html( get_the_title( $video_id ) ); ?></span><?php endif; ?>
			<?php foreach ( $resource_ids as $resource_id ) : ?><span class="tutorhelper-lms-course-builder__resource-chip"><span class="dashicons dashicons-paperclip" aria-hidden="true"></span><?php echo esc_html( get_the_title( $resource_id ) ); ?></span><?php endforeach; ?>
		</div>
		<?php
	}

	/** Hidden action fields shared by each Content-stage form. */
	private static function content_action_fields( $course_id, $operation, $topic_id = 0 ) {
		?>
		<input type="hidden" name="action" value="<?php echo esc_attr( self::CONTENT_ACTION ); ?>" />
		<input type="hidden" name="course_id" value="<?php echo esc_attr( $course_id ); ?>" />
		<input type="hidden" name="topic_id" value="<?php echo esc_attr( $topic_id ); ?>" />
		<input type="hidden" name="content_operation" value="<?php echo esc_attr( $operation ); ?>" />
		<?php wp_nonce_field( self::CONTENT_ACTION . '_' . absint( $course_id ) ); ?>
		<?php
	}

	/** Return existing reusable items that are not yet attached to the selected parent. */
	private static function available_content( $post_type, $attached_ids ) {
		$items = get_posts( array( 'post_type' => $post_type, 'post_status' => array( 'publish', 'draft', 'private' ), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$attached_ids = array_map( 'absint', is_array( $attached_ids ) ? $attached_ids : array() );
		return array_values( array_filter( $items, static function( $item ) use ( $attached_ids ) { return ! in_array( absint( $item->ID ), $attached_ids, true ); } ) );
	}

	/** Render drag, move and detach controls for one relationship. */
	private static function render_relationship_controls( $course_id, $parent_type, $parent_id, $child_type, $child_id, $position, $total ) {
		$is_topic = 'tutorhelper_topic' === $child_type;
		$detach_operation = $is_topic ? 'detach_topic' : 'detach_lesson';
		$move_operation = $is_topic ? 'move_topic' : 'move_lesson';
		?>
		<div class="tutorhelper-lms-course-builder__relationship-controls">
			<button type="button" class="button-link tutorhelper-lms-course-builder__drag-handle" draggable="true" data-tutorhelper-lms-drag-handle aria-label="<?php echo esc_attr( sprintf( __( 'Drag to reorder %s', 'tutorhelper-lms' ), get_the_title( $child_id ) ) ); ?>"><span class="dashicons dashicons-move" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Drag to reorder', 'tutorhelper-lms' ); ?></span></button>
			<?php if ( $position > 0 ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php self::relationship_action_fields( $course_id, $parent_id, $child_id, $move_operation, 'up' ); ?><button class="button-link" type="submit"><?php esc_html_e( 'Move up', 'tutorhelper-lms' ); ?></button></form><?php endif; ?>
			<?php if ( $position < $total - 1 ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php self::relationship_action_fields( $course_id, $parent_id, $child_id, $move_operation, 'down' ); ?><button class="button-link" type="submit"><?php esc_html_e( 'Move down', 'tutorhelper-lms' ); ?></button></form><?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-tutorhelper-lms-detach-form><?php self::relationship_action_fields( $course_id, $parent_id, $child_id, $detach_operation ); ?><button class="button-link-delete" type="submit"><?php esc_html_e( 'Remove', 'tutorhelper-lms' ); ?></button></form>
		</div>
		<?php
	}

	/** Hidden fields shared by a relationship move or detach action. */
	private static function relationship_action_fields( $course_id, $topic_id, $content_id, $operation, $direction = '' ) {
		?>
		<input type="hidden" name="action" value="<?php echo esc_attr( self::CONTENT_ACTION ); ?>" />
		<input type="hidden" name="course_id" value="<?php echo esc_attr( $course_id ); ?>" />
		<input type="hidden" name="topic_id" value="<?php echo esc_attr( $topic_id ); ?>" />
		<input type="hidden" name="content_id" value="<?php echo esc_attr( $content_id ); ?>" />
		<input type="hidden" name="content_operation" value="<?php echo esc_attr( $operation ); ?>" />
		<input type="hidden" name="content_direction" value="<?php echo esc_attr( $direction ); ?>" />
		<?php wp_nonce_field( self::CONTENT_ACTION . '_' . absint( $course_id ) ); ?>
		<?php
	}

	/** Load Course Builder editing controls only in the Learning Hub. */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'tutorhelper_page_' . TutorHelper_LMS_Learning_Hub::PAGE_SLUG !== $hook_suffix ) { return; }
		wp_enqueue_media();
		$path = TUTORHELPER_LMS_PATH . 'assets/js/tutorhelper-lms-course-builder.js';
		wp_enqueue_script( 'tutorhelper-lms-course-builder', TUTORHELPER_LMS_URL . 'assets/js/tutorhelper-lms-course-builder.js', array(), file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_LMS_VERSION, true );
		wp_localize_script( 'tutorhelper-lms-course-builder', 'tutorhelperLmsCourseBuilder', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( self::ORDER_AJAX_ACTION ) ) );
	}


	/** Render Topic metadata controls for a Topic attached to this Course. */
	private static function render_requested_topic_editor( $course_id ) {
		$topic_id = isset( $_GET['edit_topic_metadata'] ) && ! is_array( $_GET['edit_topic_metadata'] ) ? absint( wp_unslash( $_GET['edit_topic_metadata'] ) ) : 0;
		$topic = $topic_id ? get_post( $topic_id ) : null;
		if ( ! $topic || 'tutorhelper_topic' !== $topic->post_type || ! self::course_has_topic( $course_id, $topic_id ) ) {
			return;
		}
		$colour = sanitize_hex_color( get_post_meta( $topic_id, self::META_TOPIC_COLOUR, true ) ) ?: '#287ca8';
		?>
		<dialog class="tutorhelper-lms-lesson-editor tutorhelper-lms-topic-editor" data-tutorhelper-lms-lesson-editor data-auto-open aria-labelledby="tutorhelper-lms-topic-editor-title">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form tutorhelper-lms-lesson-editor__form">
				<header class="tutorhelper-lms-lesson-editor__header"><div><p class="tutorhelper-lms-course-builder__eyebrow"><?php echo esc_html( get_the_title( $course_id ) ); ?></p><h2 id="tutorhelper-lms-topic-editor-title"><?php esc_html_e( 'Topic details', 'tutorhelper-lms' ); ?></h2></div><button type="button" class="button button-secondary" data-tutorhelper-lms-close-lesson-editor><?php esc_html_e( 'Close', 'tutorhelper-lms' ); ?></button></header>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CONTENT_ACTION ); ?>" /><input type="hidden" name="content_operation" value="save_topic_metadata" /><input type="hidden" name="course_id" value="<?php echo esc_attr( $course_id ); ?>" /><input type="hidden" name="content_id" value="<?php echo esc_attr( $topic_id ); ?>" /><?php wp_nonce_field( self::CONTENT_ACTION . '_' . absint( $course_id ) ); ?>
				<p><label for="tutorhelper-lms-topic-title"><strong><?php esc_html_e( 'Topic title', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-topic-title" class="regular-text" type="text" name="topic_title" required value="<?php echo esc_attr( $topic->post_title ); ?>" /></p>
				<p><label for="tutorhelper-lms-topic-colour"><strong><?php esc_html_e( 'Topic colour', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-topic-colour" type="color" name="topic_colour" value="<?php echo esc_attr( $colour ); ?>" /><span class="description"><?php esc_html_e( 'Used as a visual course-builder cue. Topic name and order remain available so colour is never the only identifier.', 'tutorhelper-lms' ); ?></span></p>
				<footer><button type="submit" class="button button-primary tutorhelper-action-button tutorhelper-lms-button--orange"><?php esc_html_e( 'Save topic details', 'tutorhelper-lms' ); ?></button></footer>
			</form>
		</dialog>
		<?php
	}

	/** Save verified reusable Topic metadata without changing Course relationships. */
	private static function handle_topic_editor_action( $course_id, $topic_id, $redirect ) {
		if ( ! $topic_id || 'tutorhelper_topic' !== get_post_type( $topic_id ) || ! self::course_has_topic( $course_id, $topic_id ) ) {
			self::content_redirect( $redirect, false );
		}
		$title = isset( $_POST['topic_title'] ) && ! is_array( $_POST['topic_title'] ) ? sanitize_text_field( wp_unslash( $_POST['topic_title'] ) ) : '';
		$colour = isset( $_POST['topic_colour'] ) && ! is_array( $_POST['topic_colour'] ) ? sanitize_hex_color( wp_unslash( $_POST['topic_colour'] ) ) : '';
		$updated = '' !== $title ? wp_update_post( array( 'ID' => $topic_id, 'post_title' => $title ), true ) : 0;
		if ( ! $updated || is_wp_error( $updated ) ) {
			self::content_redirect( $redirect, false );
		}
		if ( $colour ) {
			update_post_meta( $topic_id, self::META_TOPIC_COLOUR, $colour );
		} else {
			delete_post_meta( $topic_id, self::META_TOPIC_COLOUR );
		}
		self::content_redirect( $redirect, true );
	}

	/** Render a rich lesson editor only for a lesson deliberately selected in this Course Builder. */
	private static function render_requested_lesson_editor( $course_id ) {
		$lesson_id = isset( $_GET['edit_lesson'] ) && ! is_array( $_GET['edit_lesson'] ) ? absint( wp_unslash( $_GET['edit_lesson'] ) ) : 0;
		$topic_id  = isset( $_GET['edit_topic'] ) && ! is_array( $_GET['edit_topic'] ) ? absint( wp_unslash( $_GET['edit_topic'] ) ) : 0;
		$lesson = $lesson_id ? get_post( $lesson_id ) : null;
		if ( ! $lesson || 'tutorhelper_lesson' !== $lesson->post_type || ! self::course_has_topic( $course_id, $topic_id ) || ! self::relationship_exists( 'tutorhelper_topic', $topic_id, 'tutorhelper_lesson', $lesson_id ) ) { return; }
		$shared_uses = self::lesson_other_uses( $lesson_id, $course_id, $topic_id );
		$resources = self::available_lesson_resources();
		$resource_ids = self::lesson_resource_ids( $lesson_id );
		$video_resource_id = absint( get_post_meta( $lesson_id, self::META_VIDEO_RESOURCE, true ) );
		?>
		<dialog class="tutorhelper-lms-lesson-editor" data-tutorhelper-lms-lesson-editor data-auto-open aria-labelledby="tutorhelper-lms-lesson-editor-title">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form tutorhelper-lms-lesson-editor__form">
				<header class="tutorhelper-lms-lesson-editor__header"><div><p class="tutorhelper-lms-course-builder__eyebrow"><?php echo esc_html( sprintf( __( 'Lesson / %s', 'tutorhelper-lms' ), get_the_title( $topic_id ) ) ); ?></p><h2 id="tutorhelper-lms-lesson-editor-title"><?php esc_html_e( 'Lesson details', 'tutorhelper-lms' ); ?></h2></div><button type="button" class="button-link" data-tutorhelper-lms-close-lesson-editor aria-label="<?php esc_attr_e( 'Close lesson options', 'tutorhelper-lms' ); ?>">×</button></header>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CONTENT_ACTION ); ?>" />
				<input type="hidden" name="course_id" value="<?php echo esc_attr( $course_id ); ?>" />
				<input type="hidden" name="topic_id" value="<?php echo esc_attr( $topic_id ); ?>" />
				<input type="hidden" name="content_id" value="<?php echo esc_attr( $lesson_id ); ?>" />
				<?php wp_nonce_field( self::CONTENT_ACTION . '_' . absint( $course_id ) ); ?>
				<?php if ( $shared_uses ) : ?><aside class="notice notice-warning inline tutorhelper-lms-lesson-editor__shared-notice"><p><strong><?php esc_html_e( 'This is a shared lesson.', 'tutorhelper-lms' ); ?></strong> <?php esc_html_e( 'Saving metadata or changing content will update it in the following other Course or Topic locations:', 'tutorhelper-lms' ); ?></p><ul><?php foreach ( $shared_uses as $use ) : ?><li><?php echo esc_html( $use['course_title'] . ' → ' . $use['topic_title'] ); ?></li><?php endforeach; ?></ul><p><?php esc_html_e( 'Duplicate the lesson first if this Topic needs its own version.', 'tutorhelper-lms' ); ?></p></aside><?php endif; ?>
				<div class="tutorhelper-lms-lesson-editor__grid"><div><p><label for="tutorhelper-lms-lesson-title"><strong><?php esc_html_e( 'Lesson title', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-lesson-title" class="regular-text" type="text" name="lesson_title" required value="<?php echo esc_attr( $lesson->post_title ); ?>" /></p><p><label for="tutorhelper-lms-lesson-description"><strong><?php esc_html_e( 'Short description', 'tutorhelper-lms' ); ?></strong></label><textarea id="tutorhelper-lms-lesson-description" name="lesson_description" rows="4" class="large-text"><?php echo esc_textarea( $lesson->post_excerpt ); ?></textarea><span class="description"><?php esc_html_e( 'Shown with this lesson in the Course output.', 'tutorhelper-lms' ); ?></span></p><div class="tutorhelper-lms-lesson-editor__content-choice"><span class="dashicons dashicons-layout" aria-hidden="true"></span><div><h3><?php esc_html_e( 'Lesson content', 'tutorhelper-lms' ); ?></h3><p><?php esc_html_e( 'Use the WordPress block editor for lesson text, images, embeds and reusable content. This supports reliable imports from other LMS plugins.', 'tutorhelper-lms' ); ?></p><a class="button button-primary tutorhelper-action-button tutorhelper-lms-button--orange" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( self::block_editor_url( $course_id, $topic_id, $lesson_id ) ); ?>"><?php esc_html_e( 'Edit content with blocks', 'tutorhelper-lms' ); ?></a></div></div></div><aside class="tutorhelper-lms-lesson-editor__sidebar"><p><strong><?php esc_html_e( 'Featured image', 'tutorhelper-lms' ); ?></strong></p><input type="hidden" name="lesson_featured_image_id" value="<?php echo esc_attr( get_post_thumbnail_id( $lesson_id ) ); ?>" data-tutorhelper-lms-lesson-image-id /><div data-tutorhelper-lms-lesson-image-preview><?php if ( has_post_thumbnail( $lesson_id ) ) { echo wp_kses_post( get_the_post_thumbnail( $lesson_id, 'medium' ) ); } ?></div><p><button type="button" class="button tutorhelper-action-button tutorhelper-lms-button--orange" data-tutorhelper-lms-choose-lesson-image><?php esc_html_e( 'Choose image', 'tutorhelper-lms' ); ?></button> <button type="button" class="button" data-tutorhelper-lms-remove-lesson-image><?php esc_html_e( 'Remove image', 'tutorhelper-lms' ); ?></button></p><p><label for="tutorhelper-lms-lesson-video"><strong><?php esc_html_e( 'Lesson video', 'tutorhelper-lms' ); ?></strong></label><select id="tutorhelper-lms-lesson-video" name="lesson_video_resource_id"><option value="0"><?php esc_html_e( 'No video selected', 'tutorhelper-lms' ); ?></option><?php foreach ( $resources as $resource ) : if ( 'video' !== $resource['kind'] ) { continue; } ?><option value="<?php echo esc_attr( $resource['id'] ); ?>" <?php selected( $video_resource_id, $resource['id'] ); ?>><?php echo esc_html( $resource['title'] ); ?></option><?php endforeach; ?></select><span class="description"><?php esc_html_e( 'Select a video already held in the Resource Library.', 'tutorhelper-lms' ); ?></span></p><p><label for="tutorhelper-lms-lesson-resources"><strong><?php esc_html_e( 'Lesson resources', 'tutorhelper-lms' ); ?></strong></label><input type="search" class="regular-text" placeholder="<?php esc_attr_e( 'Filter resource list…', 'tutorhelper-lms' ); ?>" data-tutorhelper-lms-filter-resources /><select id="tutorhelper-lms-lesson-resources" name="lesson_resource_ids[]" multiple size="8" data-tutorhelper-lms-lesson-resources><?php foreach ( $resources as $resource ) : ?><option value="<?php echo esc_attr( $resource['id'] ); ?>" <?php selected( in_array( $resource['id'], $resource_ids, true ) ); ?>><?php echo esc_html( $resource['title'] . ' (' . $resource['label'] . ')' ); ?></option><?php endforeach; ?></select><span class="description"><?php esc_html_e( 'Select one or more existing Resource Library items.', 'tutorhelper-lms' ); ?></span></p></aside></div>
				<footer><button type="button" class="button" data-tutorhelper-lms-close-lesson-editor><?php esc_html_e( 'Close', 'tutorhelper-lms' ); ?></button><?php if ( $shared_uses ) : ?><button type="submit" class="button" name="content_operation" value="duplicate_lesson"><?php esc_html_e( 'Duplicate lesson, then edit', 'tutorhelper-lms' ); ?></button><?php endif; ?><button type="submit" class="button button-primary tutorhelper-action-button" name="content_operation" value="save_lesson_metadata"><?php esc_html_e( 'Save lesson details', 'tutorhelper-lms' ); ?></button></footer>
			</form>
		</dialog>
		<?php
	}

	/** Return contexts outside the current Course that share this exact reusable Lesson. */
	private static function lesson_other_uses( $lesson_id, $current_course_id, $current_topic_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$topics = $wpdb->get_col( $wpdb->prepare( "SELECT parent_id FROM {$table} WHERE parent_type = %s AND child_type = %s AND child_id = %d", 'tutorhelper_topic', 'tutorhelper_lesson', absint( $lesson_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- inspects explicit Lesson reuse before editing.
		$uses = array();
		foreach ( array_unique( array_map( 'absint', $topics ) ) as $topic_id ) {
			$courses = $wpdb->get_col( $wpdb->prepare( "SELECT parent_id FROM {$table} WHERE parent_type = %s AND child_type = %s AND child_id = %d", 'tutorhelper_course', 'tutorhelper_topic', $topic_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- resolves Course contexts for a reused Topic.
			foreach ( array_unique( array_map( 'absint', $courses ) ) as $course_id ) {
				if ( $course_id && ( $course_id !== absint( $current_course_id ) || $topic_id !== absint( $current_topic_id ) ) ) { $uses[] = array( 'course_title' => get_the_title( $course_id ), 'topic_title' => get_the_title( $topic_id ) ); }
			}
		}
		return $uses;
	}

	/** Save lesson metadata everywhere, or duplicate this reusable Lesson into one Topic. */
	private static function handle_lesson_editor_action( $course_id, $topic_id, $lesson_id, $operation, $redirect ) {
		if ( ! in_array( $operation, array( 'save_lesson_metadata', 'duplicate_lesson' ), true ) || ! self::course_has_topic( $course_id, $topic_id ) || 'tutorhelper_lesson' !== get_post_type( $lesson_id ) || ! self::relationship_exists( 'tutorhelper_topic', $topic_id, 'tutorhelper_lesson', $lesson_id ) ) { self::content_redirect( $redirect, false ); }
		$lesson = get_post( $lesson_id );
		if ( 'duplicate_lesson' === $operation ) {
			$new_id = wp_insert_post( array( 'post_type' => 'tutorhelper_lesson', 'post_status' => 'publish', 'post_title' => $lesson->post_title, 'post_content' => $lesson->post_content, 'post_excerpt' => $lesson->post_excerpt ), true );
			if ( is_wp_error( $new_id ) || ! $new_id || ! self::replace_lesson_relationship( $topic_id, $lesson_id, $new_id ) ) { self::content_redirect( $redirect, false ); }
			self::copy_lesson_metadata( $lesson_id, $new_id );
			self::content_redirect( self::lesson_editor_url( $course_id, $topic_id, $new_id ), true );
		}
		$title = isset( $_POST['lesson_title'] ) && ! is_array( $_POST['lesson_title'] ) ? sanitize_text_field( wp_unslash( $_POST['lesson_title'] ) ) : '';
		$description = isset( $_POST['lesson_description'] ) && ! is_array( $_POST['lesson_description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['lesson_description'] ) ) : '';
		$image_id = isset( $_POST['lesson_featured_image_id'] ) && ! is_array( $_POST['lesson_featured_image_id'] ) ? absint( wp_unslash( $_POST['lesson_featured_image_id'] ) ) : 0;
		$video_id = isset( $_POST['lesson_video_resource_id'] ) && ! is_array( $_POST['lesson_video_resource_id'] ) ? absint( wp_unslash( $_POST['lesson_video_resource_id'] ) ) : 0;
		$resource_ids = isset( $_POST['lesson_resource_ids'] ) && is_array( $_POST['lesson_resource_ids'] ) ? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['lesson_resource_ids'] ) ) ) ) ) : array();
		if ( '' === $title || is_wp_error( wp_update_post( array( 'ID' => $lesson_id, 'post_title' => $title, 'post_excerpt' => $description ), true ) ) || ! self::replace_lesson_resources( $lesson_id, $resource_ids ) ) { self::content_redirect( $redirect, false ); }
		if ( $image_id && 'attachment' === get_post_type( $image_id ) ) { set_post_thumbnail( $lesson_id, $image_id ); } else { delete_post_thumbnail( $lesson_id ); }
		if ( $video_id && self::is_video_resource( $video_id ) ) { update_post_meta( $lesson_id, self::META_VIDEO_RESOURCE, $video_id ); } else { delete_post_meta( $lesson_id, self::META_VIDEO_RESOURCE ); }
		self::content_redirect( $redirect, true );
	}

	private static function handle_curriculum_resource_action( $course_id, $redirect ) {
		$parent_type = isset( $_POST['resource_parent_type'] ) && ! is_array( $_POST['resource_parent_type'] ) ? sanitize_key( wp_unslash( $_POST['resource_parent_type'] ) ) : '';
		$parent_id = isset( $_POST['resource_parent_id'] ) && ! is_array( $_POST['resource_parent_id'] ) ? absint( wp_unslash( $_POST['resource_parent_id'] ) ) : 0;
		$valid = ( 'tutorhelper_course' === $parent_type && $parent_id === absint( $course_id ) ) || ( 'tutorhelper_topic' === $parent_type && self::course_has_topic( $course_id, $parent_id ) );
		$ids = isset( $_POST['resource_ids'] ) && is_array( $_POST['resource_ids'] ) ? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['resource_ids'] ) ) ) ) ) : array();
		if ( ! $valid || ! self::replace_curriculum_resources( $parent_type, $parent_id, $ids ) ) { self::content_redirect( $redirect, false ); }
		self::content_redirect( $redirect, true );
	}
	private static function curriculum_resource_ids( $parent_type, $parent_id ) {
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		return array_map( 'absint', $wpdb->get_col( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", $parent_type, absint( $parent_id ), TutorHelper_LMS_Resource_Library::POST_TYPE ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- reads explicit curriculum Resource links.
	}
	private static function replace_curriculum_resources( $parent_type, $parent_id, $resource_ids ) {
		$valid = wp_list_pluck( self::available_lesson_resources(), 'id' );
		$resource_ids = array_values( array_intersect( array_map( 'absint', $resource_ids ), array_map( 'absint', $valid ) ) );
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		if ( false === $wpdb->delete( $table, array( 'parent_type' => $parent_type, 'parent_id' => absint( $parent_id ), 'child_type' => TutorHelper_LMS_Resource_Library::POST_TYPE ) ) ) { return false; } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- replaces selected curriculum Resource links.
		foreach ( $resource_ids as $index => $resource_id ) { if ( false === $wpdb->insert( $table, array( 'parent_type' => $parent_type, 'parent_id' => absint( $parent_id ), 'child_type' => TutorHelper_LMS_Resource_Library::POST_TYPE, 'child_id' => $resource_id, 'sort_order' => $index + 1, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ) ) { return false; } } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- saves selected curriculum Resource links.
		return true;
	}
	private static function available_lesson_resources() {
		$posts = get_posts( array( 'post_type' => TutorHelper_LMS_Resource_Library::POST_TYPE, 'post_status' => 'publish', 'posts_per_page' => 500, 'orderby' => 'title', 'order' => 'ASC' ) );
		return array_map( static function( $post ) {
			$type = sanitize_key( get_post_meta( $post->ID, TutorHelper_LMS_Resource_Library::META_TYPE, true ) );
			$kind = sanitize_key( get_post_meta( $post->ID, TutorHelper_LMS_Resource_Library::META_EXTERNAL_KIND, true ) );
			return array( 'id' => absint( $post->ID ), 'title' => get_the_title( $post ), 'kind' => $kind, 'label' => $kind ? $kind : str_replace( '_', ' ', $type ) );
		}, $posts );
	}
	private static function is_video_resource( $resource_id ) {
		foreach ( self::available_lesson_resources() as $resource ) { if ( absint( $resource['id'] ) === absint( $resource_id ) && 'video' === $resource['kind'] ) { return true; } }
		return false;
	}
	private static function lesson_resource_ids( $lesson_id ) {
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		return array_map( 'absint', $wpdb->get_col( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", 'tutorhelper_lesson', absint( $lesson_id ), TutorHelper_LMS_Resource_Library::POST_TYPE ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- reads explicit lesson resources.
	}
	private static function replace_lesson_resources( $lesson_id, $resource_ids ) {
		$valid = wp_list_pluck( self::available_lesson_resources(), 'id' );
		$resource_ids = array_values( array_intersect( array_map( 'absint', $resource_ids ), array_map( 'absint', $valid ) ) );
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		if ( false === $wpdb->delete( $table, array( 'parent_type' => 'tutorhelper_lesson', 'parent_id' => absint( $lesson_id ), 'child_type' => TutorHelper_LMS_Resource_Library::POST_TYPE ) ) ) { return false; } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- replaces explicit lesson resource links.
		foreach ( $resource_ids as $index => $resource_id ) { if ( false === $wpdb->insert( $table, array( 'parent_type' => 'tutorhelper_lesson', 'parent_id' => absint( $lesson_id ), 'child_type' => TutorHelper_LMS_Resource_Library::POST_TYPE, 'child_id' => $resource_id, 'sort_order' => $index + 1, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ) ) { return false; } } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- saves explicit lesson resource links.
		return true;
	}
	private static function copy_lesson_metadata( $from_lesson_id, $to_lesson_id ) {
		if ( has_post_thumbnail( $from_lesson_id ) ) { set_post_thumbnail( $to_lesson_id, get_post_thumbnail_id( $from_lesson_id ) ); }
		$video = absint( get_post_meta( $from_lesson_id, self::META_VIDEO_RESOURCE, true ) ); if ( $video ) { update_post_meta( $to_lesson_id, self::META_VIDEO_RESOURCE, $video ); }
		self::replace_lesson_resources( $to_lesson_id, self::lesson_resource_ids( $from_lesson_id ) );
	}


	/** Replace the current Topic relationship while preserving its order and all other uses. */
	private static function replace_lesson_relationship( $topic_id, $old_lesson_id, $new_lesson_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		return false !== $wpdb->update( $table, array( 'child_id' => absint( $new_lesson_id ), 'updated_at' => current_time( 'mysql', true ) ), array( 'parent_type' => 'tutorhelper_topic', 'parent_id' => absint( $topic_id ), 'child_type' => 'tutorhelper_lesson', 'child_id' => absint( $old_lesson_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- replaces only this Topic's reusable Lesson link.
	}

	/** Create or attach reusable Content from the Course Builder. */
	public static function handle_content_action() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update Course content.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$course_id = isset( $_POST['course_id'] ) && ! is_array( $_POST['course_id'] ) ? absint( wp_unslash( $_POST['course_id'] ) ) : 0;
		check_admin_referer( self::CONTENT_ACTION . '_' . $course_id );
		$redirect = self::builder_url( $course_id, self::STAGE_CONTENT );
		if ( 'tutorhelper_course' !== get_post_type( $course_id ) ) {
			self::content_redirect( $redirect, false );
		}
		$operation = isset( $_POST['content_operation'] ) && ! is_array( $_POST['content_operation'] ) ? sanitize_key( wp_unslash( $_POST['content_operation'] ) ) : '';
		$update_quiz_version = isset( $_POST['update_quiz_version'] ) && ! is_array( $_POST['update_quiz_version'] ) && '1' === (string) wp_unslash( $_POST['update_quiz_version'] );
		$topic_id = isset( $_POST['topic_id'] ) && ! is_array( $_POST['topic_id'] ) ? absint( wp_unslash( $_POST['topic_id'] ) ) : 0;
		$content_id = isset( $_POST['content_id'] ) && ! is_array( $_POST['content_id'] ) ? absint( wp_unslash( $_POST['content_id'] ) ) : 0;
		$title = isset( $_POST['content_title'] ) && ! is_array( $_POST['content_title'] ) ? sanitize_text_field( wp_unslash( $_POST['content_title'] ) ) : '';
		if ( in_array( $operation, array( 'detach_topic', 'detach_lesson', 'move_topic', 'move_lesson' ), true ) ) {
			self::handle_relationship_action( $course_id, $topic_id, $content_id, $operation, $redirect );
		}
				if ( 'save_topic_metadata' === $operation ) {
			self::handle_topic_editor_action( $course_id, $content_id, $redirect );
		}
		if ( in_array( $operation, array( 'save_lesson_metadata', 'duplicate_lesson' ), true ) ) {
			self::handle_lesson_editor_action( $course_id, $topic_id, $content_id, $operation, $redirect );
		}
		if ( $update_quiz_version ) {
			self::handle_quiz_version_update_action( $course_id, $topic_id, $content_id, $redirect );
		}
		if ( 'save_quiz_question_topics' === $operation ) {
			self::handle_quiz_question_topic_action( $course_id, $topic_id, $content_id, $redirect );
		}
		if ( 'save_resource_links' === $operation ) {
			self::handle_curriculum_resource_action( $course_id, $redirect );
		}
		if ( in_array( $operation, array( 'move_activity', 'detach_activity' ), true ) ) {
			self::handle_topic_activity_action( $course_id, $topic_id, $content_id, $operation, $redirect );
		}
		if ( in_array( $operation, array( 'attach_quiz', 'detach_quiz', 'move_quiz' ), true ) ) {
			self::handle_quiz_placement_action( $course_id, $topic_id, $content_id, $operation, $redirect );
		}
		$is_topic = in_array( $operation, array( 'create_topic', 'attach_topic' ), true );
		$is_lesson = in_array( $operation, array( 'create_lesson', 'attach_lesson' ), true );
		if ( ! $is_topic && ! $is_lesson ) {
			self::content_redirect( $redirect, false );
		}
		if ( $is_lesson && ! self::course_has_topic( $course_id, $topic_id ) ) {
			self::content_redirect( $redirect, false );
		}
		if ( 'attach_lesson' === $operation && in_array( $content_id, self::course_lesson_ids( $course_id ), true ) ) {
			self::content_redirect( $redirect, false );
		}
		$post_type = $is_topic ? 'tutorhelper_topic' : 'tutorhelper_lesson';
		if ( 0 === strpos( $operation, 'create_' ) ) {
			if ( '' === $title ) {
				self::content_redirect( $redirect, false );
			}
			$content_id = wp_insert_post( array( 'post_type' => $post_type, 'post_title' => $title, 'post_status' => 'publish' ), true );
			if ( is_wp_error( $content_id ) || ! $content_id ) {
				if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
					TutorHelper_LMS_Diagnostics::error( 'Course Builder content creation failed.', array( 'component' => 'lms', 'operation' => $operation, 'post_type' => $post_type, 'entity_id' => 0 ) );
				}
				self::content_redirect( $redirect, false );
			}
		}
		if ( $post_type !== get_post_type( $content_id ) ) {
			self::content_redirect( $redirect, false );
		}
		$parent_type = $is_topic ? 'tutorhelper_course' : 'tutorhelper_topic';
		$parent_id = $is_topic ? $course_id : $topic_id;
		if ( ! self::attach_content( $parent_type, $parent_id, $post_type, $content_id ) ) {
			if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
				TutorHelper_LMS_Diagnostics::error( 'Course Builder content relationship save failed.', array( 'component' => 'lms', 'operation' => $operation, 'entity_id' => absint( $content_id ), 'failure_reason' => 'relationship_insert_failed' ) );
			}
			self::content_redirect( $redirect, false );
		}
		self::content_redirect( $redirect, true );
	}

	/** Move or detach one verified relationship, retaining its reusable Content record. */
	private static function handle_relationship_action( $course_id, $topic_id, $content_id, $operation, $redirect ) {
		$is_topic = in_array( $operation, array( 'detach_topic', 'move_topic' ), true );
		$parent_type = $is_topic ? 'tutorhelper_course' : 'tutorhelper_topic';
		$parent_id = $is_topic ? $course_id : $topic_id;
		$child_type = $is_topic ? 'tutorhelper_topic' : 'tutorhelper_lesson';
		if ( ( ! $is_topic && ! self::course_has_topic( $course_id, $topic_id ) ) || $child_type !== get_post_type( $content_id ) || ! self::relationship_exists( $parent_type, $parent_id, $child_type, $content_id ) ) {
			self::content_redirect( $redirect, false );
		}
		if ( 0 === strpos( $operation, 'detach_' ) ) {
			if ( ! self::detach_content( $parent_type, $parent_id, $child_type, $content_id ) ) {
				self::log_relationship_failure( $operation, $content_id, 'relationship_delete_failed' );
				self::content_redirect( $redirect, false );
			}
			self::content_redirect( $redirect, true );
		}
		$direction = isset( $_POST['content_direction'] ) && ! is_array( $_POST['content_direction'] ) ? sanitize_key( wp_unslash( $_POST['content_direction'] ) ) : '';
		if ( ! in_array( $direction, array( 'up', 'down' ), true ) || ! self::move_content( $parent_type, $parent_id, $child_type, $content_id, $direction ) ) {
			self::content_redirect( $redirect, false );
		}
		self::content_redirect( $redirect, true );
	}

	/** Reorder Content after a drag-and-drop change without reloading the builder. */
	public static function ajax_reorder_content() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to reorder Course content.', 'tutorhelper-lms' ) ), 403 );
		}
		check_ajax_referer( self::ORDER_AJAX_ACTION, 'nonce' );
		$course_id = isset( $_POST['course_id'] ) && ! is_array( $_POST['course_id'] ) ? absint( wp_unslash( $_POST['course_id'] ) ) : 0;
		$parent_type = isset( $_POST['parent_type'] ) && ! is_array( $_POST['parent_type'] ) ? sanitize_key( wp_unslash( $_POST['parent_type'] ) ) : '';
		$parent_id = isset( $_POST['parent_id'] ) && ! is_array( $_POST['parent_id'] ) ? absint( wp_unslash( $_POST['parent_id'] ) ) : 0;
		$child_type = isset( $_POST['child_type'] ) && ! is_array( $_POST['child_type'] ) ? sanitize_key( wp_unslash( $_POST['child_type'] ) ) : '';
		$raw_order = isset( $_POST['ordered_ids'] ) && is_array( $_POST['ordered_ids'] ) ? wp_unslash( $_POST['ordered_ids'] ) : array();
		$ordered_ids = array_values( array_filter( array_map( 'absint', $raw_order ) ) );
		$is_activity_context = 'course_topic_activities' === $parent_type && 'activity' === $child_type && self::course_has_topic( $course_id, $parent_id );
		$valid_context = ( 'tutorhelper_course' === $parent_type && $course_id === $parent_id && 'tutorhelper_topic' === $child_type ) || ( 'tutorhelper_topic' === $parent_type && 'tutorhelper_lesson' === $child_type && self::course_has_topic( $course_id, $parent_id ) );
		$ordered_activities = array_values( array_filter( array_map( 'sanitize_text_field', $raw_order ) ) );
		$updated = $is_activity_context ? self::replace_topic_activity_order( $course_id, $parent_id, $ordered_activities ) : self::replace_relationship_order( $parent_type, $parent_id, $child_type, $ordered_ids );
		if ( 'tutorhelper_course' !== get_post_type( $course_id ) || ( ! $valid_context && ! $is_activity_context ) || ! $updated ) {
			self::log_relationship_failure( 'drag_reorder_content', 0, 'invalid_order_request' );
			wp_send_json_error( array( 'message' => __( 'The order could not be saved. Refresh and try again.', 'tutorhelper-lms' ) ), 400 );
		}
		wp_send_json_success( array( 'message' => __( 'Order saved.', 'tutorhelper-lms' ) ) );
	}

	/** Return whether a relationship exists. */
	private static function relationship_exists( $parent_type, $parent_id, $child_type, $child_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s AND child_id = %d", $parent_type, absint( $parent_id ), $child_type, absint( $child_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Verifies one explicit reusable Content relationship.
	}

	/** Detach without deleting the reusable Content post. */
	private static function detach_content( $parent_type, $parent_id, $child_type, $child_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		return false !== $wpdb->delete( $table, array( 'parent_type' => $parent_type, 'parent_id' => absint( $parent_id ), 'child_type' => $child_type, 'child_id' => absint( $child_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Detaches an explicit reusable Content relationship only.
	}

	/** Move one child relationship by swapping its position with its neighbour. */
	private static function move_content( $parent_type, $parent_id, $child_type, $child_id, $direction ) {
		$rows = self::relationship_rows( $parent_type, $parent_id, $child_type );
		$ids = wp_list_pluck( $rows, 'child_id' );
		$index = array_search( absint( $child_id ), array_map( 'absint', $ids ), true );
		$target = 'up' === $direction ? $index - 1 : $index + 1;
		if ( false === $index || ! isset( $rows[ $target ] ) ) {
			return false;
		}
		$ordered = array_map( static function( $row ) { return absint( $row->child_id ); }, $rows );
		$swap = $ordered[ $index ]; $ordered[ $index ] = $ordered[ $target ]; $ordered[ $target ] = $swap;
		return self::replace_relationship_order( $parent_type, $parent_id, $child_type, $ordered );
	}

	/** Replace the order only when the submitted IDs exactly match existing relationships. */
	private static function replace_relationship_order( $parent_type, $parent_id, $child_type, $ordered_ids ) {
		$rows = self::relationship_rows( $parent_type, $parent_id, $child_type );
		$current_ids = array_map( static function( $row ) { return absint( $row->child_id ); }, $rows );
		$submitted = array_values( array_unique( array_map( 'absint', $ordered_ids ) ) );
		sort( $current_ids ); sort( $submitted );
		if ( count( $current_ids ) < 2 || $current_ids !== $submitted ) {
			return false;
		}
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		foreach ( $ordered_ids as $position => $child_id ) {
			$updated = $wpdb->update( $table, array( 'sort_order' => $position + 1, 'updated_at' => current_time( 'mysql', true ) ), array( 'parent_type' => $parent_type, 'parent_id' => absint( $parent_id ), 'child_type' => $child_type, 'child_id' => absint( $child_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Updates explicit relationship order only.
			if ( false === $updated ) { return false; }
		}
		return true;
	}

	/** Return ordered relationship rows for one parent. */
	private static function relationship_rows( $parent_type, $parent_id, $child_type ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", $parent_type, absint( $parent_id ), $child_type ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads explicit reusable Content order.
	}

	/** Log one privacy-safe relationship failure. */
	private static function log_relationship_failure( $operation, $entity_id, $failure_reason ) {
		if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			TutorHelper_LMS_Diagnostics::error( 'Course Builder relationship operation failed.', array( 'component' => 'lms', 'operation' => sanitize_key( $operation ), 'entity_id' => absint( $entity_id ), 'failure_reason' => sanitize_key( $failure_reason ) ) );
		}
	}

	/** Attach a reusable item once, appended after existing records. */
	private static function attach_content( $parent_type, $parent_id, $child_type, $child_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s AND child_id = %d", $parent_type, absint( $parent_id ), $child_type, absint( $child_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checks one explicit reusable Content relationship.
		if ( $exists ) {
			return true;
		}
		$order = absint( $wpdb->get_var( $wpdb->prepare( "SELECT MAX(sort_order) FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s", $parent_type, absint( $parent_id ), $child_type ) ) ) + 1; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Appends without changing existing relationship order.
		return false !== $wpdb->insert( $table, array( 'parent_type' => $parent_type, 'parent_id' => absint( $parent_id ), 'child_type' => $child_type, 'child_id' => absint( $child_id ), 'sort_order' => $order, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Creates an explicit reusable Content relationship.
	}

	/** Check that a Topic is attached to the selected Course. */
	private static function course_has_topic( $course_id, $topic_id ) {
		foreach ( apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id ) as $topic ) {
			if ( absint( $topic['id'] ?? 0 ) === absint( $topic_id ) ) {
				return true;
			}
		}
		return false;
	}

	/** Redirect Content operations with a short-lived builder notice. */
	private static function content_redirect( $url, $success ) {
		wp_safe_redirect( add_query_arg( $success ? 'lms_content_updated' : 'lms_content_error', '1', $url ) );
		exit;
	}

	/** Render Course grading and enrolment information. */
	private static function render_students_stage( $course_id ) {
		$capacity = TutorHelper_LMS_Course_Settings::capacity( $course_id );
		$active   = TutorHelper_LMS_Course_Enrolments::active_count( $course_id );
		?>
		<div class="tutorhelper-lms-course-builder__student-summary">
			<h3><?php esc_html_e( 'Structured Course enrolments', 'tutorhelper-lms' ); ?></h3>
			<p><?php /* translators: 1: Active enrolment count, 2: Capacity label, 3: Enrolment availability. */ echo esc_html( sprintf( __( '%1$d active enrolments%2$s. New enrolments are currently %3$s.', 'tutorhelper-lms' ), $active, $capacity ? ' / ' . $capacity : ' / ' . __( 'unlimited', 'tutorhelper-lms' ), TutorHelper_LMS_Course_Settings::enrolments_open( $course_id ) ? __( 'open', 'tutorhelper-lms' ) : __( 'closed', 'tutorhelper-lms' ) ) ); ?></p>
			<p class="description"><?php esc_html_e( 'Manage individual formal Course places from the student’s Academic Courses section. Existing Group and academic-context links are retained separately.', 'tutorhelper-lms' ); ?></p>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form tutorhelper-lms-course-builder__form">
			<input type="hidden" name="action" value="<?php echo esc_attr( TutorHelper_LMS_Learning_Library::SAVE_ACTION ); ?>" />
			<input type="hidden" name="kind" value="post" />
			<input type="hidden" name="tab" value="courses" />
			<input type="hidden" name="entity_id" value="<?php echo esc_attr( $course_id ); ?>" />
			<input type="hidden" name="title" value="<?php echo esc_attr( get_the_title( $course_id ) ); ?>" />
			<input type="hidden" name="content" value="<?php echo esc_attr( get_post_field( 'post_content', $course_id ) ); ?>" />
			<input type="hidden" name="course_builder" value="<?php echo esc_attr( $course_id ); ?>" />
			<input type="hidden" name="course_builder_stage" value="<?php echo esc_attr( self::STAGE_STUDENTS ); ?>" />
			<input type="hidden" name="course_grade_settings_present" value="1" />
			<input type="hidden" name="course_student_information_present" value="1" />
			<?php wp_nonce_field( TutorHelper_LMS_Learning_Library::SAVE_ACTION ); ?>
			<?php TutorHelper_LMS_Grade_Systems::render_course_fields( $course_id ); ?>
			<p><label for="tutorhelper-lms-student-information"><strong><?php esc_html_e( 'Student information', 'tutorhelper-lms' ); ?></strong></label><?php wp_editor( TutorHelper_LMS_Course_Settings::student_information( $course_id ), 'tutorhelper-lms-student-information', array( 'textarea_name' => 'course_student_information', 'textarea_rows' => 8, 'media_buttons' => true, 'teeny' => false ) ); ?><span class="description"><?php esc_html_e( 'Add prerequisites, materials needed and any information students should know before starting this Course.', 'tutorhelper-lms' ); ?></span></p>
			<p><button class="button button-primary tutorhelper-action-button" type="submit"><?php esc_html_e( 'Save Student Information', 'tutorhelper-lms' ); ?></button></p>
		</form>
		<?php
	}

	/** Render a native multi-select and the currently linked Level or Subject names. */
	private static function render_term_multi_select( $field, $taxonomy, $label, $selected ) {
		$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'orderby' => 'name' ) );
		$selected = array_map( 'absint', is_array( $selected ) ? $selected : array() );
		?>
		<p class="tutorhelper-lms-course-builder__term-picker">
			<label for="<?php echo esc_attr( 'tutorhelper-lms-builder-' . $field ); ?>"><strong><?php echo esc_html( $label ); ?></strong></label>
			<?php if ( empty( $terms ) || is_wp_error( $terms ) ) : ?>
				<span class="description"><?php esc_html_e( 'Create an option in its Learning Hub tab first.', 'tutorhelper-lms' ); ?></span>
			<?php else : ?>
				<select id="<?php echo esc_attr( 'tutorhelper-lms-builder-' . $field ); ?>" class="tutorhelper-lms-course-builder__term-select" name="<?php echo esc_attr( $field ); ?>[]" multiple size="5"><?php foreach ( $terms as $term ) : ?><option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( in_array( $term->term_id, $selected, true ) ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select>
				<span class="description"><?php esc_html_e( 'Choose one or more items. Hold Ctrl (Windows) or Command (Mac) to select more than one.', 'tutorhelper-lms' ); ?></span>
				<?php $linked = array_filter( $terms, static function( $term ) use ( $selected ) { return in_array( $term->term_id, $selected, true ); } ); ?>
				<p class="tutorhelper-lms-course-builder__linked-terms"><strong><?php esc_html_e( 'Currently linked:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( $linked ? implode( ', ', wp_list_pluck( $linked, 'name' ) ) : __( 'None yet', 'tutorhelper-lms' ) ); ?></p>
			<?php endif; ?>
		</p>
		<?php
	}

	/** Return ordered reusable Lessons for one Topic. */
	private static function course_lesson_ids( $course_id ) {
		$ids = array();
		foreach ( apply_filters( 'tutorhelper_lms_course_topics', array(), absint( $course_id ) ) as $topic ) {
			$ids = array_merge( $ids, wp_list_pluck( self::topic_lessons( absint( $topic['id'] ?? 0 ) ), 'id' ) );
		}
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	private static function render_topic_activity_list( $course_id, $topic_id ) {
		$activities = self::topic_activities( $course_id, $topic_id );
		?>
		<section class="tutorhelper-lms-course-builder__topic-activities" data-tutorhelper-lms-topic-activities="<?php echo esc_attr( $topic_id ); ?>"><header><h5><?php esc_html_e( 'Activities in this Topic', 'tutorhelper-lms' ); ?></h5><p class="description"><?php esc_html_e( 'Lessons and quizzes share one order. Use the arrow controls to place a Quiz between lessons.', 'tutorhelper-lms' ); ?></p></header>
		<?php if ( $activities ) : ?><ol data-tutorhelper-lms-sortable-list data-parent-type="course_topic_activities" data-parent-id="<?php echo esc_attr( $topic_id ); ?>" data-child-type="activity"><?php foreach ( $activities as $index => $activity ) : $is_outdated = 'quiz' === $activity->activity_type && absint( $activity->latest_version_id ?? 0 ) && absint( $activity->latest_version_id ) !== absint( $activity->quiz_version_id ?? 0 ); ?><li class="<?php echo esc_attr( 'is-' . $activity->activity_type . ( $is_outdated ? ' is-quiz-outdated' : '' ) ); ?>" data-tutorhelper-lms-sortable-item data-child-id="<?php echo esc_attr( $activity->activity_type . ':' . absint( $activity->activity_id ) ); ?>"><button type="button" class="tutorhelper-lms-course-builder__activity-drag-handle" draggable="true" data-tutorhelper-lms-drag-handle aria-label="<?php esc_attr_e( 'Drag to reorder activity', 'tutorhelper-lms' ); ?>"><span class="dashicons dashicons-move" aria-hidden="true"></span></button><span class="dashicons <?php echo esc_attr( 'quiz' === $activity->activity_type ? 'dashicons-clipboard' : 'dashicons-media-document' ); ?>" aria-hidden="true"></span><div><strong><?php echo esc_html( $activity->title ); ?></strong><span><?php echo esc_html( 'quiz' === $activity->activity_type ? sprintf( __( '%1$sQuiz · %2$d marks · Version %3$d', 'tutorhelper-lms' ), $is_outdated ? __( 'Update available · ', 'tutorhelper-lms' ) : '', absint( $activity->total_marks ), absint( $activity->version_number ) ) : __( 'Lesson', 'tutorhelper-lms' ) ); ?></span></div><?php if ( 'lesson' === $activity->activity_type ) : ?><a class="button tutorhelper-lms-button--grey" href="<?php echo esc_url( self::lesson_editor_url( $course_id, $topic_id, absint( $activity->activity_id ) ) ); ?>"><?php esc_html_e( 'Edit lesson', 'tutorhelper-lms' ); ?></a><?php else : ?><a class="button tutorhelper-lms-button--grey tutorhelper-lms-course-builder__question-topics" href="<?php echo esc_url( self::quiz_topic_editor_url( $course_id, $topic_id, absint( $activity->activity_id ) ) ); ?>"><?php esc_html_e( 'Edit quiz options', 'tutorhelper-lms' ); ?></a><?php endif; ?><div class="tutorhelper-lms-course-builder__relationship-controls"><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__activity-move-up"<?php echo 0 === $index ? ' hidden' : ''; ?>><?php self::relationship_action_fields( $course_id, $topic_id, absint( $activity->activity_id ), 'move_activity', 'up' ); ?><input type="hidden" name="activity_type" value="<?php echo esc_attr( $activity->activity_type ); ?>" /><button class="button tutorhelper-lms-button--grey" type="submit" aria-label="<?php esc_attr_e( 'Move activity up', 'tutorhelper-lms' ); ?>">↑</button></form><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__activity-move-down"<?php echo $index === count( $activities ) - 1 ? ' hidden' : ''; ?>><?php self::relationship_action_fields( $course_id, $topic_id, absint( $activity->activity_id ), 'move_activity', 'down' ); ?><input type="hidden" name="activity_type" value="<?php echo esc_attr( $activity->activity_type ); ?>" /><button class="button tutorhelper-lms-button--grey" type="submit" aria-label="<?php esc_attr_e( 'Move activity down', 'tutorhelper-lms' ); ?>">↓</button></form><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-tutorhelper-lms-detach-form><?php self::relationship_action_fields( $course_id, $topic_id, absint( $activity->activity_id ), 'detach_activity' ); ?><input type="hidden" name="activity_type" value="<?php echo esc_attr( $activity->activity_type ); ?>" /><button class="button tutorhelper-lms-button--grey" type="submit"><?php esc_html_e( 'Remove', 'tutorhelper-lms' ); ?></button></form></div><?php do_action( 'tutorhelper_lms_course_builder_activity_options', $activity, $course_id, $topic_id ); ?></li><?php endforeach; ?></ol><?php else : ?><p class="description"><?php esc_html_e( 'No activities are attached to this Topic yet.', 'tutorhelper-lms' ); ?></p><?php endif; ?></section>
		<?php
	}

	private static function topic_activities( $course_id, $topic_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'course_topic_activities' );
		$existing = $wpdb->get_results( $wpdb->prepare( "SELECT activity_type, activity_id FROM {$table} WHERE course_id = %d AND topic_id = %d", $course_id, $topic_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Ensures Course Topic activity ordering.
		$known = array(); foreach ( $existing as $row ) { $known[ $row->activity_type . ':' . absint( $row->activity_id ) ] = true; }
		$order = count( $known );
		foreach ( self::topic_lessons( $topic_id ) as $lesson ) { if ( empty( $known['lesson:' . absint( $lesson['id'] )] ) ) { $order++; $wpdb->insert( $table, array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'activity_type' => 'lesson', 'activity_id' => absint( $lesson['id'] ), 'sort_order' => $order, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ); } }
		foreach ( self::topic_quiz_placements( $course_id, $topic_id ) as $quiz ) { if ( empty( $known['quiz:' . absint( $quiz->quiz_id )] ) ) { $order++; $wpdb->insert( $table, array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'activity_type' => 'quiz', 'activity_id' => absint( $quiz->quiz_id ), 'sort_order' => $order, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ); } }
		$activities = $wpdb->get_results( $wpdb->prepare( "SELECT a.*, p.post_title AS title, cp.quiz_version_id, v.total_marks, v.version_number FROM {$table} a LEFT JOIN {$wpdb->posts} p ON p.ID = a.activity_id LEFT JOIN " . TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' ) . " cp ON cp.course_id=a.course_id AND cp.topic_id=a.topic_id AND cp.quiz_id=a.activity_id AND a.activity_type='quiz' LEFT JOIN " . TutorHelper_LMS_Free_Database::table( 'quiz_versions' ) . " v ON v.id=cp.quiz_version_id WHERE a.course_id=%d AND a.topic_id=%d ORDER BY a.sort_order ASC, a.id ASC", $course_id, $topic_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads ordered mixed Topic activities.
		foreach ( $activities as $activity ) {
			if ( 'quiz' === $activity->activity_type ) {
				$activity->latest_version_id = 'published' === get_post_meta( $activity->activity_id, TutorHelper_LMS_Quiz_Builder::META_STATUS, true ) ? absint( get_post_meta( $activity->activity_id, TutorHelper_LMS_Quiz_Builder::META_CURRENT_VERSION, true ) ) : 0;
				$activity->latest_version_number = self::quiz_version_number( $activity->latest_version_id );
			}
		}
		return $activities; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads ordered mixed Topic activities.
	}

	private static function replace_topic_activity_order( $course_id, $topic_id, $tokens ) {
		$activities = self::topic_activities( $course_id, $topic_id );
		$expected = array_map( static function( $activity ) { return $activity->activity_type . ':' . absint( $activity->activity_id ); }, $activities );
		$tokens = array_values( array_unique( $tokens ) );
		sort( $expected ); $provided = $tokens; sort( $provided );
		if ( count( $expected ) < 2 || $expected !== $provided ) { return false; }
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'course_topic_activities' );
		foreach ( $tokens as $position => $token ) { list( $type, $id ) = array_pad( explode( ':', $token, 2 ), 2, '' ); if ( false === $wpdb->update( $table, array( 'sort_order' => $position + 1, 'updated_at' => current_time( 'mysql', true ) ), array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'activity_type' => sanitize_key( $type ), 'activity_id' => absint( $id ) ) ) ) { return false; } } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Saves verified mixed Topic activity order.
		return true;
	}

	private static function handle_topic_activity_action( $course_id, $topic_id, $activity_id, $operation, $redirect ) {
		$type = isset( $_POST['activity_type'] ) && ! is_array( $_POST['activity_type'] ) ? sanitize_key( wp_unslash( $_POST['activity_type'] ) ) : '';
		if ( ! self::course_has_topic( $course_id, $topic_id ) || ! in_array( $type, array( 'lesson', 'quiz' ), true ) ) { self::content_redirect( $redirect, false ); }
		$activities = self::topic_activities( $course_id, $topic_id ); $index = false; foreach ( $activities as $position => $activity ) { if ( $type === $activity->activity_type && $activity_id === absint( $activity->activity_id ) ) { $index = $position; break; } } if ( false === $index ) { self::content_redirect( $redirect, false ); }
		$table = TutorHelper_LMS_Free_Database::table( 'course_topic_activities' ); global $wpdb;
		if ( 'detach_activity' === $operation ) { if ( 'lesson' === $type ) { self::detach_content( 'tutorhelper_topic', $topic_id, 'tutorhelper_lesson', $activity_id ); } else { $wpdb->delete( TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' ), array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'quiz_id' => $activity_id ) ); } $ok = false !== $wpdb->delete( $table, array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'activity_type' => $type, 'activity_id' => $activity_id ) ); self::content_redirect( $redirect, $ok ); }
		$direction = isset( $_POST['content_direction'] ) && ! is_array( $_POST['content_direction'] ) ? sanitize_key( wp_unslash( $_POST['content_direction'] ) ) : ''; $target = 'up' === $direction ? $index - 1 : $index + 1; if ( ! in_array( $direction, array( 'up', 'down' ), true ) || ! isset( $activities[$target] ) ) { self::content_redirect( $redirect, false ); } $swap = $activities[$index]; $activities[$index] = $activities[$target]; $activities[$target] = $swap; foreach ( $activities as $position => $activity ) { $wpdb->update( $table, array( 'sort_order' => $position + 1, 'updated_at' => current_time( 'mysql', true ) ), array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'activity_type' => $activity->activity_type, 'activity_id' => absint( $activity->activity_id ) ) ); } self::content_redirect( $redirect, true );
	}

	/**
	 * Render immutable published Quiz placements for one Topic.
	 *
	 * @param int $course_id Course ID.
	 * @param int $topic_id Topic ID.
	 * @return void
	 */
	private static function render_topic_quiz_section( $course_id, $topic_id ) {
		$placements = self::topic_quiz_placements( $course_id, $topic_id );
		$available = self::available_published_quizzes( wp_list_pluck( $placements, 'quiz_id' ) );
		?>
		<section class="tutorhelper-lms-course-builder__topic-quiz-add">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__quick-form">
				<?php self::content_action_fields( $course_id, 'attach_quiz', $topic_id ); ?>
				<label for="<?php echo esc_attr( 'tutorhelper-lms-attach-quiz-' . $topic_id ); ?>"><strong><?php esc_html_e( 'Add a published Quiz', 'tutorhelper-lms' ); ?></strong></label>
				<select id="<?php echo esc_attr( 'tutorhelper-lms-attach-quiz-' . $topic_id ); ?>" name="content_id" <?php disabled( empty( $available ) ); ?>><option value=""><?php echo esc_html( empty( $available ) ? __( 'No published Quizzes available', 'tutorhelper-lms' ) : __( 'Choose a Quiz', 'tutorhelper-lms' ) ); ?></option><?php foreach ( $available as $quiz ) : ?><option value="<?php echo esc_attr( $quiz->ID ); ?>"><?php echo esc_html( $quiz->post_title ); ?></option><?php endforeach; ?></select>
				<button class="button tutorhelper-lms-button--orange" type="submit" <?php disabled( empty( $available ) ); ?>><?php esc_html_e( 'Add Quiz', 'tutorhelper-lms' ); ?></button>
			</form>
		</section>
		<?php
	}

	private static function quiz_topic_editor_url( $course_id, $topic_id, $quiz_id ) {
		return add_query_arg( array( 'quiz_topic_links' => absint( $quiz_id ), 'quiz_topic_id' => absint( $topic_id ) ), self::builder_url( $course_id, self::STAGE_CONTENT ) );
	}

	private static function render_requested_quiz_topic_editor( $course_id ) {
		$quiz_id = isset( $_GET['quiz_topic_links'] ) && ! is_array( $_GET['quiz_topic_links'] ) ? absint( wp_unslash( $_GET['quiz_topic_links'] ) ) : 0;
		$topic_id = isset( $_GET['quiz_topic_id'] ) && ! is_array( $_GET['quiz_topic_id'] ) ? absint( wp_unslash( $_GET['quiz_topic_id'] ) ) : 0;
		$placement = self::course_quiz_placement( $course_id, $topic_id, $quiz_id );
		if ( ! $placement ) { return; }
		$questions = self::course_quiz_questions( $placement );
		$default_attempt_policy = self::quiz_default_attempt_policy( $placement->quiz_version_id );
		$default_result_release = self::quiz_default_result_release( $placement->quiz_version_id );
		$default_delivery_mode = self::quiz_default_delivery_mode( $placement->quiz_version_id );
		$premium_delivery = class_exists( 'TutorHelper_LMS_Premium' );
		$default_pass_mark = self::quiz_default_pass_mark( $placement->quiz_version_id );
		$latest_version_id = 'published' === get_post_meta( $quiz_id, TutorHelper_LMS_Quiz_Builder::META_STATUS, true ) ? absint( get_post_meta( $quiz_id, TutorHelper_LMS_Quiz_Builder::META_CURRENT_VERSION, true ) ) : 0;
		$latest_version_number = self::quiz_version_number( $latest_version_id );
		$is_outdated = $latest_version_id && $latest_version_id !== absint( $placement->quiz_version_id );
		$topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
		$links = self::course_quiz_question_topics( $placement->id );
		?>
		<dialog class="tutorhelper-lms-course-builder__modal" data-tutorhelper-lms-quiz-topic-editor data-auto-open aria-label="<?php esc_attr_e( 'Edit question topic links', 'tutorhelper-lms' ); ?>">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<header><h3><?php echo esc_html( sprintf( __( 'Edit quiz options: %s', 'tutorhelper-lms' ), get_the_title( $quiz_id ) ) ); ?></h3><p><?php esc_html_e( 'Choose the Topic used for each question and set Course-specific Quiz options. This does not change the reusable Question or Quiz.', 'tutorhelper-lms' ); ?></p></header>
				<?php self::content_action_fields( $course_id, 'save_quiz_question_topics', $topic_id ); ?><input type="hidden" name="content_id" value="<?php echo esc_attr( $quiz_id ); ?>" /><input type="hidden" name="update_quiz_version" value="0" />
				<div class="tutorhelper-lms-course-builder__quiz-settings">
					<p><label for="tutorhelper-lms-quiz-attempt-override"><strong><?php esc_html_e( 'Student attempts for this Course Topic', 'tutorhelper-lms' ); ?></strong></label><select id="tutorhelper-lms-quiz-attempt-override" name="attempt_policy_override"><option value="inherit" <?php selected( $placement->attempt_policy_override, 'inherit' ); ?>><?php echo esc_html( sprintf( __( 'Use the Quiz default — %s', 'tutorhelper-lms' ), 'single' === $default_attempt_policy ? __( 'One completed attempt', 'tutorhelper-lms' ) : __( 'Unlimited completed attempts', 'tutorhelper-lms' ) ) ); ?></option><option value="unlimited" <?php selected( $placement->attempt_policy_override, 'unlimited' ); ?>><?php esc_html_e( 'Allow unlimited completed attempts', 'tutorhelper-lms' ); ?></option><option value="single" <?php selected( $placement->attempt_policy_override, 'single' ); ?>><?php esc_html_e( 'Allow one completed attempt', 'tutorhelper-lms' ); ?></option></select></p>
					<p><label for="tutorhelper-lms-quiz-result-release-override"><strong><?php esc_html_e( 'Results and feedback for this Course Topic', 'tutorhelper-lms' ); ?></strong></label><select id="tutorhelper-lms-quiz-result-release-override" name="result_release_override"><option value="inherit" <?php selected( $placement->result_release_override ?? 'inherit', 'inherit' ); ?>><?php echo esc_html( sprintf( __( 'Use the Quiz default — %s', 'tutorhelper-lms' ), 'tutor' === $default_result_release ? __( 'Release when I choose', 'tutorhelper-lms' ) : __( 'Show immediately', 'tutorhelper-lms' ) ) ); ?></option><option value="immediate" <?php selected( $placement->result_release_override ?? 'inherit', 'immediate' ); ?>><?php esc_html_e( 'Show immediately', 'tutorhelper-lms' ); ?></option><option value="tutor" <?php selected( $placement->result_release_override ?? 'inherit', 'tutor' ); ?>><?php esc_html_e( 'Release when I choose', 'tutorhelper-lms' ); ?></option></select><span class="description"><?php esc_html_e( 'Held results keep scores, answers and feedback private until you release them.', 'tutorhelper-lms' ); ?></span></p>
					<p><label for="tutorhelper-lms-quiz-pass-mark-override"><strong><?php esc_html_e( 'Pass mark for this Course Topic', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-quiz-pass-mark-override" type="number" min="0" max="<?php echo esc_attr( absint( $placement->total_marks ?? 0 ) ); ?>" step="1" name="pass_mark_override" value="<?php echo null === $placement->pass_mark_override ? '' : esc_attr( absint( $placement->pass_mark_override ) ); ?>" placeholder="<?php echo esc_attr( sprintf( __( 'Quiz default: %d marks', 'tutorhelper-lms' ), $default_pass_mark ) ); ?>" /><span class="description"><?php echo esc_html( sprintf( __( 'Leave blank to use the Quiz default of %d marks. This affects only this Course Topic placement.', 'tutorhelper-lms' ), $default_pass_mark ) ); ?></span></p>
					<?php if ( $premium_delivery ) : ?>					<p><label for="tutorhelper-lms-quiz-delivery-override"><strong><?php esc_html_e( 'Student delivery for this Course Topic', 'tutorhelper-lms' ); ?></strong></label><select id="tutorhelper-lms-quiz-delivery-override" name="delivery_mode_override"><option value="inherit" <?php selected( $placement->delivery_mode_override ?? 'inherit', 'inherit' ); ?>><?php echo esc_html( sprintf( __( 'Use the Quiz default — %s', 'tutorhelper-lms' ), 'question' === $default_delivery_mode ? __( 'Question by question', 'tutorhelper-lms' ) : ( 'section' === $default_delivery_mode ? __( 'Section by section', 'tutorhelper-lms' ) : __( 'All at once', 'tutorhelper-lms' ) ) ) ); ?></option><option value="all" <?php selected( $placement->delivery_mode_override ?? 'inherit', 'all' ); ?>><?php esc_html_e( 'All at once', 'tutorhelper-lms' ); ?></option><option value="question" <?php selected( $placement->delivery_mode_override ?? 'inherit', 'question' ); ?>><?php esc_html_e( 'Question by question', 'tutorhelper-lms' ); ?></option><option value="section" <?php selected( $placement->delivery_mode_override ?? 'inherit', 'section' ); ?>><?php esc_html_e( 'Section by section (exam style)', 'tutorhelper-lms' ); ?></option></select></p>					<?php endif; ?>
				</div>
				<?php if ( $is_outdated ) : ?><aside class="tutorhelper-lms-course-builder__quiz-update"><strong><?php echo esc_html( sprintf( __( 'Version %d is available', 'tutorhelper-lms' ), $latest_version_number ) ); ?></strong><p><?php esc_html_e( 'Updating uses the latest Quiz questions and defaults while keeping this Course Topic’s question links, delivery style, result-release, attempt and pass-mark overrides.', 'tutorhelper-lms' ); ?></p><button class="button tutorhelper-lms-button--orange" type="submit" data-tutorhelper-lms-update-quiz-version><?php echo esc_html( sprintf( __( 'Update to version %d', 'tutorhelper-lms' ), $latest_version_number ) ); ?></button></aside><?php endif; ?>
				<div class="tutorhelper-lms-course-builder__quiz-topic-links"><?php foreach ( $questions as $question ) : $selected = isset( $links[ $question->question_id ] ) ? absint( $links[ $question->question_id ] ) : $topic_id; ?><label><span><strong><?php echo esc_html( $question->question_title ); ?></strong><small><?php echo esc_html( sprintf( __( '%1$s · %2$d marks', 'tutorhelper-lms' ), $question->question_type, absint( $question->max_marks ) ) ); ?></small></span><select name="question_topics[<?php echo esc_attr( $question->question_id ); ?>]"><option value="0"><?php esc_html_e( 'No Topic link', 'tutorhelper-lms' ); ?></option><?php foreach ( $topics as $topic ) : ?><option value="<?php echo esc_attr( $topic['id'] ); ?>" <?php selected( $selected, absint( $topic['id'] ) ); ?>><?php echo esc_html( $topic['title'] ); ?></option><?php endforeach; ?></select></label><?php endforeach; ?></div>
				<footer><a class="button tutorhelper-lms-button--grey" data-tutorhelper-lms-close-quiz-topic-modal href="<?php echo esc_url( self::builder_url( $course_id, self::STAGE_CONTENT ) ); ?>"><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></a><button class="button tutorhelper-lms-button--orange" type="submit"><?php esc_html_e( 'Save quiz options', 'tutorhelper-lms' ); ?></button></footer>
			</form>
		</dialog>
		<?php
	}

	private static function quiz_default_attempt_policy( $quiz_version_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		$json = $table ? $wpdb->get_var( $wpdb->prepare( "SELECT definition_json FROM {$table} WHERE id = %d", $quiz_version_id ) ) : ''; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads pinned Quiz policy for Course placement display.
		$definition = json_decode( $json, true );
		return is_array( $definition ) && isset( $definition['attempt_policy'] ) && 'single' === $definition['attempt_policy'] ? 'single' : 'unlimited';
	}


	private static function quiz_default_result_release( $quiz_version_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		$json = $table ? $wpdb->get_var( $wpdb->prepare( "SELECT definition_json FROM {$table} WHERE id = %d", $quiz_version_id ) ) : ''; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads pinned Quiz result-release default for Course placement display.
		$definition = json_decode( $json, true );
		return is_array( $definition ) && isset( $definition['result_release'] ) && 'tutor' === $definition['result_release'] ? 'tutor' : 'immediate';
	}

	private static function quiz_default_pass_mark( $quiz_version_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		$json = $table ? $wpdb->get_var( $wpdb->prepare( "SELECT definition_json FROM {$table} WHERE id = %d", $quiz_version_id ) ) : ''; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads pinned Quiz pass mark for Course placement display.
		$definition = json_decode( $json, true );
		return is_array( $definition ) ? absint( $definition['pass_mark'] ?? 0 ) : 0;
	}

	private static function course_quiz_placement( $course_id, $topic_id, $quiz_id ) {
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' );
		$versions = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT p.*, v.total_marks FROM {$table} p LEFT JOIN {$versions} v ON v.id = p.quiz_version_id WHERE p.course_id = %d AND p.topic_id = %d AND p.quiz_id = %d", $course_id, $topic_id, $quiz_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads one verified Course Quiz placement.
	}

	private static function course_quiz_questions( $placement ) {
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'quiz_question_placements' ); $versions = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT p.question_id, p.question_version_id, q.post_title AS question_title, v.question_type, v.max_marks FROM {$table} p INNER JOIN {$wpdb->posts} q ON q.ID = p.question_id INNER JOIN {$versions} v ON v.id = p.question_version_id WHERE p.quiz_version_id = %d ORDER BY p.sort_order ASC", $placement->quiz_version_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads immutable Question snapshot for Course Quiz placement.
	}

	private static function course_quiz_question_topics( $placement_id ) {
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'course_quiz_question_topics' ); $rows = $wpdb->get_results( $wpdb->prepare( "SELECT question_id, topic_id FROM {$table} WHERE course_quiz_placement_id = %d", $placement_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads Course-specific Question Topic overrides.
		$links = array(); foreach ( $rows as $row ) { $links[ absint( $row->question_id ) ] = absint( $row->topic_id ); } return $links;
	}

	private static function handle_quiz_question_topic_action( $course_id, $topic_id, $quiz_id, $redirect ) {
		$placement = self::course_quiz_placement( $course_id, $topic_id, $quiz_id ); if ( ! $placement ) { self::content_redirect( $redirect, false ); }
		$questions = self::course_quiz_questions( $placement ); $allowed_questions = wp_list_pluck( $questions, 'question_version_id', 'question_id' ); $course_topics = wp_list_pluck( apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id ), 'id' );
		$posted = isset( $_POST['question_topics'] ) && is_array( $_POST['question_topics'] ) ? wp_unslash( $_POST['question_topics'] ) : array();
		$attempt_policy = isset( $_POST['attempt_policy_override'] ) && ! is_array( $_POST['attempt_policy_override'] ) ? sanitize_key( wp_unslash( $_POST['attempt_policy_override'] ) ) : 'inherit';
		$delivery_mode = class_exists( 'TutorHelper_LMS_Premium' ) && isset( $_POST['delivery_mode_override'] ) && ! is_array( $_POST['delivery_mode_override'] ) ? sanitize_key( wp_unslash( $_POST['delivery_mode_override'] ) ) : 'inherit';
		$result_release = isset( $_POST['result_release_override'] ) && ! is_array( $_POST['result_release_override'] ) ? sanitize_key( wp_unslash( $_POST['result_release_override'] ) ) : 'inherit';
		$pass_mark_raw = isset( $_POST['pass_mark_override'] ) && ! is_array( $_POST['pass_mark_override'] ) ? trim( (string) wp_unslash( $_POST['pass_mark_override'] ) ) : '';
		$pass_mark_override = '' === $pass_mark_raw ? null : absint( $pass_mark_raw );
		if ( ! in_array( $attempt_policy, array( 'inherit', 'unlimited', 'single' ), true ) || ! in_array( $delivery_mode, array( 'inherit', 'all', 'question', 'section' ), true ) || ! in_array( $result_release, array( 'inherit', 'immediate', 'tutor' ), true ) || ( null !== $pass_mark_override && $pass_mark_override > absint( $placement->total_marks ?? 0 ) ) ) { self::content_redirect( $redirect, false ); }
		global $wpdb; $wpdb->update( TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' ), array( 'attempt_policy_override' => $attempt_policy, 'delivery_mode_override' => $delivery_mode, 'result_release_override' => $result_release, 'pass_mark_override' => $pass_mark_override, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $placement->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Saves Course-specific Quiz policy override.
		$table = TutorHelper_LMS_Free_Database::table( 'course_quiz_question_topics' ); $wpdb->delete( $table, array( 'course_quiz_placement_id' => $placement->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Replaces only Course-specific Question Topic mapping.
		foreach ( $allowed_questions as $question_id => $version_id ) { $linked_topic = isset( $posted[ $question_id ] ) ? absint( $posted[ $question_id ] ) : 0; if ( $linked_topic && ! in_array( $linked_topic, $course_topics, true ) ) { self::content_redirect( $redirect, false ); } $wpdb->insert( $table, array( 'course_quiz_placement_id' => $placement->id, 'question_id' => absint( $question_id ), 'question_version_id' => absint( $version_id ), 'topic_id' => $linked_topic, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ); } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Saves audited Course-specific Question Topic mapping.
		self::content_redirect( $redirect, true );
	}

	private static function available_published_quizzes( $attached_ids ) {
		$quizzes = get_posts( array( 'post_type' => TutorHelper_LMS_Quiz_Builder::POST_TYPE, 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$attached_ids = array_map( 'absint', $attached_ids );
		return array_values( array_filter( $quizzes, static function( $quiz ) use ( $attached_ids ) {
			return 'published' === get_post_meta( $quiz->ID, TutorHelper_LMS_Quiz_Builder::META_STATUS, true ) && absint( get_post_meta( $quiz->ID, TutorHelper_LMS_Quiz_Builder::META_CURRENT_VERSION, true ) ) && ! in_array( absint( $quiz->ID ), $attached_ids, true );
		} ) );
	}

	private static function quiz_version_number( $version_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		return $table ? absint( $wpdb->get_var( $wpdb->prepare( "SELECT version_number FROM {$table} WHERE id = %d", $version_id ) ) ) : 0; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads immutable Quiz version display metadata.
	}

	private static function quiz_default_delivery_mode( $quiz_version_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		$json = $table ? $wpdb->get_var( $wpdb->prepare( "SELECT definition_json FROM {$table} WHERE id = %d", $quiz_version_id ) ) : ''; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads pinned Quiz delivery default for Course placement display.
		$definition = json_decode( $json, true );
		$mode = is_array( $definition ) ? ( $definition['delivery_mode'] ?? 'all' ) : 'all';
		return in_array( $mode, array( 'all', 'question', 'section' ), true ) ? $mode : 'all';
	}

	private static function handle_quiz_version_update_action( $course_id, $topic_id, $quiz_id, $redirect ) {
		$placement = self::course_quiz_placement( $course_id, $topic_id, $quiz_id );
		$latest_version_id = absint( get_post_meta( $quiz_id, TutorHelper_LMS_Quiz_Builder::META_CURRENT_VERSION, true ) );
		$context = array(
			'placement_id'                    => $placement ? absint( $placement->id ) : 0,
			'course_quiz_version_id'          => $placement ? absint( $placement->quiz_version_id ) : 0,
			'latest_quiz_version_id'          => $latest_version_id,
			'course_quiz_version_number'      => $placement ? self::quiz_version_number( $placement->quiz_version_id ) : 0,
			'latest_quiz_version_number'      => self::quiz_version_number( $latest_version_id ),
		);
		if ( ! $placement ) {
			self::quiz_version_update_failure( $redirect, $quiz_id, 'placement_not_found', $context );
		}
		if ( 'published' !== get_post_meta( $quiz_id, TutorHelper_LMS_Quiz_Builder::META_STATUS, true ) || ! $latest_version_id ) {
			self::quiz_version_update_failure( $redirect, $quiz_id, 'latest_version_not_published', $context );
		}
		if ( $latest_version_id === absint( $placement->quiz_version_id ) ) {
			// A repeated browser request is harmless once the first request has advanced the placement.
			self::quiz_version_update_redirect( $redirect, 'lms_quiz_version_already_current', '1' );
		}
		global $wpdb;
		$versions = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		$latest_marks = absint( $wpdb->get_var( $wpdb->prepare( "SELECT total_marks FROM {$versions} WHERE id = %d", $latest_version_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Validates latest Quiz version before moving this Course placement.
		if ( null !== $placement->pass_mark_override && absint( $placement->pass_mark_override ) > $latest_marks ) {
			self::quiz_version_update_failure( $redirect, $quiz_id, 'pass_mark_exceeds_latest_total', $context );
		}
		$placement->quiz_version_id = $latest_version_id;
		$questions = self::course_quiz_questions( $placement );
		if ( ! $questions ) {
			self::quiz_version_update_failure( $redirect, $quiz_id, 'latest_version_has_no_questions', $context );
		}
		$links = self::course_quiz_question_topics( $placement->id );
		$links_table = TutorHelper_LMS_Free_Database::table( 'course_quiz_question_topics' );
		$latest_question_ids = array();
		foreach ( $questions as $question ) {
			$question_id = absint( $question->question_id );
			$latest_question_ids[] = $question_id;
			$topic_link = array_key_exists( $question_id, $links ) ? absint( $links[ $question_id ] ) : absint( $topic_id );
			if ( array_key_exists( $question_id, $links ) ) {
				$saved = $wpdb->update( $links_table, array( 'question_version_id' => absint( $question->question_version_id ), 'topic_id' => $topic_link, 'updated_at' => current_time( 'mysql', true ) ), array( 'course_quiz_placement_id' => $placement->id, 'question_id' => $question_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Preserves Course-specific Question Topic mapping while moving to latest Question version.
			} else {
				$saved = $wpdb->insert( $links_table, array( 'course_quiz_placement_id' => $placement->id, 'question_id' => $question_id, 'question_version_id' => absint( $question->question_version_id ), 'topic_id' => $topic_link, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds only new latest-Quiz Questions to this Course placement.
			}
			if ( false === $saved ) {
				self::quiz_version_update_failure( $redirect, $quiz_id, 'question_topic_mapping_save_failed', $context );
			}
		}
		$existing_question_ids = array_map( 'absint', array_keys( $links ) );
		foreach ( array_diff( $existing_question_ids, $latest_question_ids ) as $removed_question_id ) {
			if ( false === $wpdb->delete( $links_table, array( 'course_quiz_placement_id' => $placement->id, 'question_id' => $removed_question_id ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Removes mappings for Questions no longer in the updated Quiz.
				self::quiz_version_update_failure( $redirect, $quiz_id, 'question_topic_mapping_delete_failed', $context );
			}
		}
		$updated = $wpdb->update( TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' ), array( 'quiz_version_id' => $latest_version_id, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $placement->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Advances one Course placement to the selected immutable Quiz version.
		if ( false === $updated ) {
			self::quiz_version_update_failure( $redirect, $quiz_id, 'placement_version_save_failed', $context );
		}
		self::quiz_version_update_redirect( $redirect, 'lms_quiz_version_updated', '1' );
	}

	private static function quiz_version_update_redirect( $url, $key, $value ) {
		wp_safe_redirect( add_query_arg( sanitize_key( $key ), sanitize_text_field( $value ), $url ) );
		exit;
	}

	private static function quiz_version_update_failure( $redirect, $quiz_id, $reason, $context = array() ) {
		if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			TutorHelper_LMS_Diagnostics::error(
				'Course Quiz version update failed.',
				array_merge(
					$context,
					array(
						'component'      => 'lms',
						'operation'      => 'update_course_quiz_version',
						'entity_id'      => absint( $quiz_id ),
						'failure_reason' => sanitize_key( $reason ),
					)
				)
			);
		}
		self::quiz_version_update_redirect( $redirect, 'lms_quiz_version_error', sanitize_key( $reason ) );
	}


	private static function topic_quiz_placements( $course_id, $topic_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' );
		$versions = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT p.*, q.post_title AS quiz_title, v.total_marks, v.version_number FROM {$table} p INNER JOIN {$wpdb->posts} q ON q.ID = p.quiz_id INNER JOIN {$versions} v ON v.id = p.quiz_version_id WHERE p.course_id = %d AND p.topic_id = %d ORDER BY p.sort_order ASC, p.id ASC", absint( $course_id ), absint( $topic_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads explicit immutable Quiz placements for the Course Builder.
	}

	private static function handle_quiz_placement_action( $course_id, $topic_id, $quiz_id, $operation, $redirect ) {
		if ( ! self::course_has_topic( $course_id, $topic_id ) || TutorHelper_LMS_Quiz_Builder::POST_TYPE !== get_post_type( $quiz_id ) ) {
			self::content_redirect( $redirect, false );
		}
		$table = TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' );
		global $wpdb;
		if ( 'attach_quiz' === $operation ) {
			$version_id = absint( get_post_meta( $quiz_id, TutorHelper_LMS_Quiz_Builder::META_CURRENT_VERSION, true ) );
			if ( 'published' !== get_post_meta( $quiz_id, TutorHelper_LMS_Quiz_Builder::META_STATUS, true ) || ! $version_id ) { self::content_redirect( $redirect, false ); }
			$order = absint( $wpdb->get_var( $wpdb->prepare( "SELECT MAX(sort_order) FROM {$table} WHERE course_id = %d AND topic_id = %d", $course_id, $topic_id ) ) ) + 1; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Appends Course Quiz placement.
			$ok = false !== $wpdb->insert( $table, array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'quiz_id' => $quiz_id, 'quiz_version_id' => $version_id, 'sort_order' => $order, 'created_by' => get_current_user_id(), 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Creates immutable Course Quiz placement.
			self::content_redirect( $redirect, $ok );
		}
		$rows = self::topic_quiz_placements( $course_id, $topic_id );
		$ids = array_map( static function( $row ) { return absint( $row->quiz_id ); }, $rows );
		$index = array_search( $quiz_id, $ids, true );
		if ( false === $index ) { self::content_redirect( $redirect, false ); }
		if ( 'detach_quiz' === $operation ) {
			self::content_redirect( $redirect, false !== $wpdb->delete( $table, array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'quiz_id' => $quiz_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Removes Course Quiz placement only.
		}
		$direction = isset( $_POST['content_direction'] ) && ! is_array( $_POST['content_direction'] ) ? sanitize_key( wp_unslash( $_POST['content_direction'] ) ) : '';
		$target = 'up' === $direction ? $index - 1 : $index + 1;
		if ( ! in_array( $direction, array( 'up', 'down' ), true ) || ! isset( $ids[ $target ] ) ) { self::content_redirect( $redirect, false ); }
		$current = $ids[ $index ]; $ids[ $index ] = $ids[ $target ]; $ids[ $target ] = $current;
		foreach ( $ids as $position => $ordered_quiz_id ) {
			if ( false === $wpdb->update( $table, array( 'sort_order' => $position + 1, 'updated_at' => current_time( 'mysql', true ) ), array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'quiz_id' => $ordered_quiz_id ) ) ) { self::content_redirect( $redirect, false ); } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Reorders explicit Course Quiz placements.
		}
		self::content_redirect( $redirect, true );
	}

	private static function topic_lessons( $topic_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", 'tutorhelper_topic', absint( $topic_id ), 'tutorhelper_lesson' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Displays existing reusable Topic-to-Lesson ordering.
		$items = array();
		foreach ( $rows as $row ) {
			$lesson_id = absint( $row->child_id );
			if ( 'tutorhelper_lesson' === get_post_type( $lesson_id ) ) {
				$items[] = array( 'id' => $lesson_id, 'title' => get_the_title( $lesson_id ) );
			}
		}
		return $items;
	}

	private static function selected_stage() {
		$stage = isset( $_GET['builder_stage'] ) && ! is_array( $_GET['builder_stage'] ) ? sanitize_key( wp_unslash( $_GET['builder_stage'] ) ) : self::STAGE_DETAILS;
		return in_array( $stage, array( self::STAGE_DETAILS, self::STAGE_CONTENT, self::STAGE_STUDENTS ), true ) ? $stage : self::STAGE_DETAILS;
	}

	private static function render_stage_link( $course_id, $stage, $label, $selected ) {
		printf( '<a class="%1$s" href="%2$s" %3$s>%4$s</a>', esc_attr( 'tutorhelper-lms-course-builder__step' . ( $stage === $selected ? ' is-active' : '' ) ), esc_url( self::builder_url( $course_id, $stage ) ), $stage === $selected ? 'aria-current="step"' : '', esc_html( $label ) );
	}

	private static function render_notice() {
		if ( isset( $_GET['lms_updated'] ) ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Course saved.', 'tutorhelper-lms' ) . '</p></div>';
		}
		if ( isset( $_GET['lms_content_updated'] ) ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Course content updated.', 'tutorhelper-lms' ) . '</p></div>';
		}
		if ( isset( $_GET['lms_quiz_version_updated'] ) ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Course Quiz updated to the latest version. Course-specific options have been retained.', 'tutorhelper-lms' ) . '</p></div>';
		}
		if ( isset( $_GET['lms_quiz_version_already_current'] ) ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'This Course Quiz is already using the latest version.', 'tutorhelper-lms' ) . '</p></div>';
		}
		if ( isset( $_GET['lms_quiz_version_error'] ) ) {
			$reason = sanitize_key( wp_unslash( $_GET['lms_quiz_version_error'] ) );
			$message = 'pass_mark_exceeds_latest_total' === $reason
				? __( 'The Course pass-mark override is higher than the latest Quiz total. Update that pass mark before changing versions.', 'tutorhelper-lms' )
				: __( 'The Course Quiz could not be updated to the latest version. The reason has been recorded in TutorHelper diagnostics.', 'tutorhelper-lms' );
			echo '<div class="notice notice-error inline"><p>' . esc_html( $message ) . '</p></div>';
		}
		if ( isset( $_GET['lms_content_error'] ) ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'The Course content could not be updated. Check the selected item and try again.', 'tutorhelper-lms' ) . '</p></div>';
		}
		if ( isset( $_GET['lms_error'] ) ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'The Course could not be saved. Check the required fields and try again.', 'tutorhelper-lms' ) . '</p></div>';
		}
	}

	/** Remember where a native block editor session should return in the Course Builder. */
	public static function capture_block_editor_return_context() {
		$lesson_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
		$course_id = isset( $_GET['tutorhelper_lms_return_course'] ) ? absint( $_GET['tutorhelper_lms_return_course'] ) : 0;
		$topic_id = isset( $_GET['tutorhelper_lms_return_topic'] ) ? absint( $_GET['tutorhelper_lms_return_topic'] ) : 0;
		if ( 'tutorhelper_lesson' === get_post_type( $lesson_id ) && self::course_has_topic( $course_id, $topic_id ) && self::relationship_exists( 'tutorhelper_topic', $topic_id, 'tutorhelper_lesson', $lesson_id ) ) { update_user_meta( get_current_user_id(), 'tutorhelper_lms_lesson_editor_return', array( 'lesson_id' => $lesson_id, 'course_id' => $course_id, 'topic_id' => $topic_id ) ); }
	}
	public static function preserve_block_editor_return_context( $location, $post_id ) {
		$context = get_user_meta( get_current_user_id(), 'tutorhelper_lms_lesson_editor_return', true );
		if ( is_array( $context ) && absint( $context['lesson_id'] ?? 0 ) === absint( $post_id ) ) { return add_query_arg( array( 'tutorhelper_lms_return_course' => absint( $context['course_id'] ), 'tutorhelper_lms_return_topic' => absint( $context['topic_id'] ) ), $location ); }
		return $location;
	}
	public static function render_block_editor_return_link() {
		global $pagenow;
		if ( 'post.php' !== $pagenow || ! isset( $_GET['post'] ) || 'tutorhelper_lesson' !== get_post_type( absint( $_GET['post'] ) ) ) { return; }
		$context = get_user_meta( get_current_user_id(), 'tutorhelper_lms_lesson_editor_return', true );
		if ( is_array( $context ) && absint( $context['lesson_id'] ?? 0 ) === absint( $_GET['post'] ) ) { echo '<div class="notice notice-info"><p><a class="button" href="' . esc_url( self::lesson_editor_url( absint( $context['course_id'] ), absint( $context['topic_id'] ), absint( $context['lesson_id'] ) ) ) . '">' . esc_html__( 'Return to Course Builder', 'tutorhelper-lms' ) . '</a></p></div>'; }
	}

	private static function block_editor_url( $course_id, $topic_id, $lesson_id ) {
		return add_query_arg( array( 'post' => absint( $lesson_id ), 'action' => 'edit', 'tutorhelper_lms_return_course' => absint( $course_id ), 'tutorhelper_lms_return_topic' => absint( $topic_id ) ), admin_url( 'post.php' ) );
	}

	private static function resource_editor_url( $course_id, $parent_type, $parent_id ) {
		return add_query_arg( array( 'resource_parent_type' => sanitize_key( $parent_type ), 'resource_parent_id' => absint( $parent_id ) ), self::builder_url( $course_id, self::STAGE_CONTENT ) );
	}


	private static function topic_editor_url( $course_id, $topic_id ) {
		return add_query_arg( array( 'edit_topic_metadata' => absint( $topic_id ) ), self::builder_url( $course_id, self::STAGE_CONTENT ) );
	}

	private static function lesson_editor_url( $course_id, $topic_id, $lesson_id ) {
		return add_query_arg( array( 'edit_topic' => absint( $topic_id ), 'edit_lesson' => absint( $lesson_id ) ), self::builder_url( $course_id, self::STAGE_CONTENT ) );
	}

	public static function builder_url( $course_id, $stage = self::STAGE_DETAILS ) {
		return add_query_arg( array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => 'courses', 'builder' => absint( $course_id ) ? absint( $course_id ) : 'new', 'builder_stage' => sanitize_key( $stage ) ), admin_url( 'admin.php' ) );
	}

	private static function courses_url() {
		return add_query_arg( array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => 'courses' ), admin_url( 'admin.php' ) );
	}
}
