<?php
/**
 * Structured Course enrolment foundation.
 *
 * Academic Course context remains in student_courses. This class deliberately
 * stores only formal Course delivery enrolments, so Group associations do not
 * consume Course capacity or lose historic academic context.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Course_Enrolments {

	/**
	 * Enrol one student in a Course with a transaction-safe capacity check.
	 *
	 * @param int    $course_id Course post ID.
	 * @param int    $student_user_id Student user ID.
	 * @param string $source Enrolment source.
	 * @param bool   $require_open Whether enrolments must be open.
	 * @return int|WP_Error Enrolment ID on success.
	 */
	public static function enrol( $course_id, $student_user_id, $source = 'manual', $require_open = true ) {
		$course_id       = absint( $course_id );
		$student_user_id = absint( $student_user_id );
		$source          = sanitize_key( $source );

		if ( 'tutorhelper_course' !== get_post_type( $course_id ) || ! get_user_by( 'id', $student_user_id ) ) {
			return new WP_Error( 'invalid_course_enrolment', __( 'Choose a valid Course and student.', 'tutorhelper-lms' ) );
		}
		if ( 'running' !== TutorHelper_LMS_Course_Settings::lifecycle( $course_id ) ) {
			return new WP_Error( 'course_not_running', __( 'This Course is not currently running.', 'tutorhelper-lms' ) );
		}
		if ( $require_open && ! TutorHelper_LMS_Course_Settings::enrolments_open( $course_id ) ) {
			return new WP_Error( 'course_enrolments_closed', __( 'Enrolments for this Course are closed.', 'tutorhelper-lms' ) );
		}

		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'course_enrolments' );
		$now   = current_time( 'mysql', true );

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Serialises capacity checks for one Course.
		try {
			$locked = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE ID = %d FOR UPDATE", $course_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Row lock prevents concurrent final-place enrolments.
			if ( ! $locked ) {
				throw new RuntimeException( 'course_lock_failed' );
			}

			$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE course_id = %d AND student_user_id = %d AND active_key = 1 LIMIT 1", $course_id, $student_user_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checks this Course/student active enrolment only.
			if ( $existing ) {
				$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Ends the short enrolment transaction.
				return absint( $existing );
			}

			$capacity = TutorHelper_LMS_Course_Settings::capacity( $course_id );
			if ( $capacity > 0 ) {
				$active = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE course_id = %d AND status = %s", $course_id, 'active' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Counts only formal active Course enrolments.
				if ( $active >= $capacity ) {
					$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Capacity has not been mutated.
					return new WP_Error( 'course_at_capacity', __( 'This Course has reached its maximum enrolment capacity.', 'tutorhelper-lms' ) );
				}
			}

			$inserted = $wpdb->insert(
				$table,
				array(
					'course_id'       => $course_id,
					'student_user_id' => $student_user_id,
					'source'          => $source ? $source : 'manual',
					'status'          => 'active',
					'active_key'      => 1,
					'enrolled_at'     => $now,
					'created_at'      => $now,
					'updated_at'      => $now,
				),
				array( '%d', '%d', '%s', '%s', '%d', '%s', '%s', '%s' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Inserts one explicit Course delivery enrolment.

			if ( false === $inserted ) {
				throw new RuntimeException( 'enrolment_insert_failed' );
			}
			$id = absint( $wpdb->insert_id );
			$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Ends the short enrolment transaction.
			return $id;
		} catch ( Throwable $error ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Restores the enrolment state after an unexpected failure.
			if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
				TutorHelper_LMS_Diagnostics::error(
					'Course enrolment failed.',
					array(
						'operation'      => 'enrol_course',
						'course_id'      => $course_id,
						'failure_reason' => sanitize_key( $error->getMessage() ),
					)
				);
			}
			return new WP_Error( 'course_enrolment_failed', __( 'The Course enrolment could not be saved. Please try again.', 'tutorhelper-lms' ) );
		}
	}

	/**
	 * Retain a historic enrolment while ending active Course delivery.
	 *
	 * @param int    $enrolment_id Enrolment record ID.
	 * @param string $status completed or withdrawn.
	 * @param int    $student_user_id Expected student user ID, if known.
	 * @return bool|WP_Error
	 */
	public static function end( $enrolment_id, $status, $student_user_id = 0 ) {
		$enrolment_id = absint( $enrolment_id );
		$status       = sanitize_key( $status );
		$student_user_id = absint( $student_user_id );
		if ( ! in_array( $status, array( 'completed', 'withdrawn' ), true ) ) {
			return new WP_Error( 'invalid_enrolment_status', __( 'Choose a valid enrolment status.', 'tutorhelper-lms' ) );
		}
		global $wpdb;
		$where = array( 'id' => $enrolment_id, 'status' => 'active' );
		if ( $student_user_id ) {
			$where['student_user_id'] = $student_user_id;
		}
		$result = $wpdb->update(
			TutorHelper_LMS_Free_Database::table( 'course_enrolments' ),
			array(
				'status'     => $status,
				'active_key' => null,
				'ended_at'   => current_time( 'mysql', true ),
				'updated_at' => current_time( 'mysql', true ),
			),
			$where,
			array( '%s', '%s', '%s', '%s' ),
			$student_user_id ? array( '%d', '%s', '%d' ) : array( '%d', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Ends one explicit Course enrolment without deleting history.
		return false === $result ? new WP_Error( 'course_enrolment_end_failed', __( 'The Course enrolment could not be updated.', 'tutorhelper-lms' ) ) : (bool) $result;
	}

	/**
	 * Return all retained structured Course enrolments for one student.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return array
	 */
	public static function for_student( $student_user_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM " . TutorHelper_LMS_Free_Database::table( 'course_enrolments' ) . " WHERE student_user_id = %d ORDER BY FIELD(status, 'active', 'completed', 'withdrawn'), enrolled_at DESC", absint( $student_user_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads one student's retained structured Course delivery records.
	}

	/**
	 * Return active structured enrolment count for a Course.
	 *
	 * @param int $course_id Course post ID.
	 * @return int
	 */
	public static function active_count( $course_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM " . TutorHelper_LMS_Free_Database::table( 'course_enrolments' ) . " WHERE course_id = %d AND status = %s", absint( $course_id ), 'active' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Returns a Course capacity figure.
	}

	/**
	 * Return available structured places, or null for unlimited.
	 *
	 * @param int $course_id Course post ID.
	 * @return int|null
	 */
	public static function available_places( $course_id ) {
		$capacity = TutorHelper_LMS_Course_Settings::capacity( $course_id );
		return $capacity ? max( 0, $capacity - self::active_count( $course_id ) ) : null;
	}
}
