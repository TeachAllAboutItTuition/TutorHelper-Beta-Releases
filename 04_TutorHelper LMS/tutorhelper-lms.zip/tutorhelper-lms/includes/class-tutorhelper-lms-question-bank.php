<?php
/**
 * Core reusable Question Bank foundation.
 *
 * Q2b adds validated, type-specific answer definitions and Core publishing.
 * Quiz placement, learner delivery, attempts and imports remain later batches.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Question_Bank {

	const POST_TYPE           = 'tutorhelper_question';
	const META_CURRENT_VERSION = '_tutorhelper_lms_question_current_version';
	const META_STATUS          = '_tutorhelper_lms_question_status';
	const SAVE_ACTION          = 'tutorhelper_lms_save_question';

	/**
	 * Register Question Bank hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save_question' ) );
	}

	/**
	 * Return Core question types reserved for Q2.
	 *
	 * Essay, long-answer and file-upload responses are deliberately Premium
	 * functionality and are never offered by this Core-only screen.
	 *
	 * @return array
	 */
	public static function question_types() {
		$types = array(
			'single_choice'   => __( 'Single Choice', 'tutorhelper-lms' ),
			'multiple_choice' => __( 'Multiple Choice', 'tutorhelper-lms' ),
			'free_answer'     => __( 'Short Answer', 'tutorhelper-lms' ),
			'sort_answer'     => __( 'Put in Order', 'tutorhelper-lms' ),
			'matrix_sort'     => __( 'Matching Pairs', 'tutorhelper-lms' ),
			'cloze'           => __( 'Fill in the Blanks', 'tutorhelper-lms' ),
			'assessment'      => __( 'Survey / Rating Scale', 'tutorhelper-lms' ),
		);

		/**
		 * Lets Premium add manually marked Question types without making them
		 * available in Core-only installations.
		 *
		 * @param array $types Question type => label map.
		 */
		return apply_filters( 'tutorhelper_lms_question_types', $types );
	}

	/**
	 * Render the Question Bank Learning Hub workspace.
	 *
	 * @return void
	 */
	public static function render_section() {
		self::require_tutor();
		if ( function_exists( 'wp_enqueue_editor' ) ) {
			wp_enqueue_editor();
		}

		$editing_id = isset( $_GET['edit'] ) && ! is_array( $_GET['edit'] )
			? absint( wp_unslash( $_GET['edit'] ) )
			: 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only editor selection.
		$editing = $editing_id ? get_post( $editing_id ) : null;
		if ( ! $editing || self::POST_TYPE !== $editing->post_type ) {
			$editing = null;
		}

		self::render_notice();
		?>
		<section class="tutorhelper-main-section tutorhelper-lms-question-bank" aria-label="<?php esc_attr_e( 'Question Bank workspace', 'tutorhelper-lms' ); ?>">
			<div class="tutorhelper-main-section__body">
				<div class="tutorhelper-lms-library-grid">
					<section class="tutorhelper-lms-library-form">
						<h3><?php echo esc_html( $editing ? __( 'Edit Question', 'tutorhelper-lms' ) : __( 'Create Question', 'tutorhelper-lms' ) ); ?></h3>
						<p class="description"><?php esc_html_e( 'Configure reusable, objectively markable Core Questions here. Publishing freezes the validated definition in an immutable version; Quiz placement and student delivery follow in later batches.', 'tutorhelper-lms' ); ?></p>
						<form class="tutorhelper-lms-question-bank-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
							<input type="hidden" name="question_id" value="<?php echo esc_attr( $editing ? $editing->ID : 0 ); ?>" />
							<input type="hidden" name="question_search" value="<?php echo esc_attr( self::current_search() ); ?>" />
							<input type="hidden" name="question_page" value="<?php echo esc_attr( self::current_page() ); ?>" />
							<?php wp_nonce_field( self::SAVE_ACTION ); ?>

							<p>
								<label for="tutorhelper-lms-question-title"><strong><?php esc_html_e( 'Question title', 'tutorhelper-lms' ); ?></strong></label>
								<input id="tutorhelper-lms-question-title" class="regular-text" type="text" name="title" required value="<?php echo esc_attr( $editing ? $editing->post_title : '' ); ?>" />
								<span class="description"><?php esc_html_e( 'A tutor-facing label to help find this reusable Question later.', 'tutorhelper-lms' ); ?></span>
							</p>

							<p>
								<label for="tutorhelper-lms-question-type"><strong><?php esc_html_e( 'Question type', 'tutorhelper-lms' ); ?></strong></label>
								<?php
								$current_type = $editing ? self::current_question_type( $editing->ID ) : 'single_choice';
								?>
								<select id="tutorhelper-lms-question-type" name="question_type">
									<?php foreach ( self::question_types() as $type => $label ) : ?>
										<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $current_type, $type ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
								<span class="description"><?php esc_html_e( 'Essay, long-answer and file-upload questions are Premium assessment features.', 'tutorhelper-lms' ); ?></span>
							</p>

							<p>
								<label for="tutorhelper-lms-question-marks"><strong><?php esc_html_e( 'Maximum marks', 'tutorhelper-lms' ); ?></strong></label>
								<input id="tutorhelper-lms-question-marks" type="number" min="0" max="10000" step="1" name="max_marks" value="<?php echo esc_attr( $editing ? self::current_max_marks( $editing->ID ) : 1 ); ?>" />
								<span class="description" data-tutorhelper-lms-marks-help><?php esc_html_e( 'Assessment/survey questions are always ungraded and will save as zero marks.', 'tutorhelper-lms' ); ?></span>
							</p>

							<p>
								<label for="tutorhelper-lms-question-prompt"><strong><?php esc_html_e( 'Question prompt', 'tutorhelper-lms' ); ?></strong></label>
								<?php
								wp_editor(
									$editing ? $editing->post_content : '',
									'tutorhelper-lms-question-prompt',
									array(
										'textarea_name' => 'prompt',
										'textarea_rows' => 7,
										'media_buttons' => false,
										'teeny'         => false,
									)
								);
								?>
							</p>

							<?php
							$current_definition = $editing ? self::current_definition( $editing->ID ) : self::empty_definition( $current_type );
							self::render_answer_editor( $current_type, $current_definition );
							?>

							<p>
								<label for="tutorhelper-lms-question-explanation"><strong><?php esc_html_e( 'Student explanation (optional)', 'tutorhelper-lms' ); ?></strong></label>
								<textarea id="tutorhelper-lms-question-explanation" class="large-text" rows="4" name="student_explanation"><?php echo esc_textarea( $editing ? self::current_student_explanation( $editing->ID ) : '' ); ?></textarea>
								<span class="description"><?php esc_html_e( 'This text is visible to the student to help them answer. Do not add answers here.', 'tutorhelper-lms' ); ?></span>
							</p>
							<?php if ( 'assessment' !== $current_type ) : ?>
								<fieldset class="tutorhelper-lms-question-feedback" data-tutorhelper-lms-automatic-feedback><legend><strong><?php esc_html_e( 'Automatic marking feedback', 'tutorhelper-lms' ); ?></strong></legend><p class="description"><?php esc_html_e( 'Shown to the student after an automatically marked answer. You can use formatting and explanations.', 'tutorhelper-lms' ); ?></p>
									<label><strong><?php esc_html_e( 'Incorrect or partially correct', 'tutorhelper-lms' ); ?></strong></label><?php wp_editor( $editing ? self::current_definition_value( $editing->ID, 'incorrect_feedback', __( "That wasn't quite right.", 'tutorhelper-lms' ) ) : __( "That wasn't quite right.", 'tutorhelper-lms' ), 'tutorhelper_lms_question_incorrect_feedback', array( 'textarea_name' => 'incorrect_feedback', 'textarea_rows' => 4, 'media_buttons' => false, 'teeny' => false ) ); ?>
									<label><strong><?php esc_html_e( 'Correct answer', 'tutorhelper-lms' ); ?></strong></label><?php wp_editor( $editing ? self::current_definition_value( $editing->ID, 'correct_feedback', __( 'Correct!', 'tutorhelper-lms' ) ) : __( 'Correct!', 'tutorhelper-lms' ), 'tutorhelper_lms_question_correct_feedback', array( 'textarea_name' => 'correct_feedback', 'textarea_rows' => 4, 'media_buttons' => false, 'teeny' => false ) ); ?>
								</fieldset>
							<?php endif; ?>

							<p>
								<fieldset class="tutorhelper-lms-question-status">
								<legend><strong><?php esc_html_e( 'Question status', 'tutorhelper-lms' ); ?></strong></legend>
								<label><input type="radio" name="question_status" value="draft" <?php checked( $editing ? self::current_status( $editing->ID ) : 'draft', 'draft' ); ?> /> <?php esc_html_e( 'Save draft', 'tutorhelper-lms' ); ?></label>
								<label><input type="radio" name="question_status" value="published" <?php checked( $editing ? self::current_status( $editing->ID ) : 'draft', 'published' ); ?> /> <?php esc_html_e( 'Publish Question', 'tutorhelper-lms' ); ?></label>
								<span class="description"><?php esc_html_e( 'Editing a Question will not impact marks for previously submitted student answers.', 'tutorhelper-lms' ); ?></span>
							</fieldset>
								<button class="button button-primary tutorhelper-action-button" type="submit"><?php echo esc_html( $editing ? __( 'Save Question', 'tutorhelper-lms' ) : __( 'Create Question', 'tutorhelper-lms' ) ); ?></button>
								<?php if ( $editing ) : ?>
									<a class="button" href="<?php echo esc_url( self::tab_url() ); ?>"><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></a>
								<?php endif; ?>
							</p>
						</form>
					</section>

					<section>
						<?php self::render_question_table(); ?>
					</section>
				</div>
			</div>
		</section>
		<?php
	}

	/**
	 * Create one validated Core Question from a reviewed import record.
	 *
	 * Uses the same immutable-version data model as the Question Bank form. An
	 * import key makes repeat clicks and a re-upload of the same CSV safe: an
	 * existing imported Question is returned instead of duplicated.
	 *
	 * @param array $record Reviewed CSV preview record.
	 * @return array|WP_Error Array with question_id and created state.
	 */
	public static function create_from_import( $record ) {
		$type = sanitize_key( $record['type'] ?? '' );
		$types = self::question_types();
		if ( ! isset( $types[ $type ] ) ) {
			return new WP_Error( 'invalid_type', __( 'The imported Question type is not supported by this site.', 'tutorhelper-lms' ) );
		}
		$title = sanitize_text_field( $record['title'] ?? '' );
		$prompt = wp_kses_post( (string) ( $record['prompt'] ?? '' ) );
		$status = sanitize_key( $record['import_status'] ?? 'draft' );
		$import_key = sanitize_key( $record['id'] ?? '' );
		if ( '' === $title || '' === trim( wp_strip_all_tags( $prompt ) ) || '' === $import_key ) {
			return new WP_Error( 'missing_required', __( 'The imported Question needs a title, prompt and stable import key.', 'tutorhelper-lms' ) );
		}
		if ( ! in_array( $status, array( 'draft', 'published' ), true ) ) {
			$status = 'draft';
		}

		$existing = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_tutorhelper_lms_import_key',
				'meta_value'     => $import_key,
			)
		);
		if ( ! empty( $existing ) ) {
			return array( 'question_id' => absint( $existing[0] ), 'created' => false );
		}

		$configuration = self::import_configuration( $type, $record );
		$configuration_error = self::validate_configuration( $type, $configuration['answers'], $configuration['settings'] );
		if ( is_wp_error( $configuration_error ) ) {
			return $configuration_error;
		}
		$max_marks = absint( $record['marks'] ?? 0 );
		if ( 'matrix_sort' === $type ) {
			$max_marks = count( $configuration['answers']['pairs'] ?? array() );
		} elseif ( 'cloze' === $type ) {
			$max_marks = count( $configuration['answers']['blanks'] ?? array() );
		} elseif ( 'sort_answer' === $type ) {
			$max_marks = max( 0, count( $configuration['answers']['items'] ?? array() ) - ( ! empty( $configuration['settings']['exclude_final_item_mark'] ) ? 1 : 0 ) );
		} elseif ( 'assessment' === $type ) {
			$max_marks = 0;
		} elseif ( $max_marks < 1 || $max_marks > 10000 ) {
			return new WP_Error( 'invalid_marks', __( 'The imported maximum marks are invalid.', 'tutorhelper-lms' ) );
		}

		$manual_types = array_map( 'sanitize_key', (array) apply_filters( 'tutorhelper_lms_manual_question_types', array() ) );
		$definition = array(
			'question_type'       => $type,
			'prompt'              => $prompt,
			'student_explanation' => wp_kses_post( (string) ( $record['tip'] ?? '' ) ),
			'incorrect_feedback'  => ( 'assessment' === $type || in_array( $type, $manual_types, true ) ) ? '' : ( '' !== trim( wp_strip_all_tags( (string) ( $record['incorrect_feedback'] ?? '' ) ) ) ? wp_kses_post( $record['incorrect_feedback'] ) : __( "That wasn't quite right.", 'tutorhelper-lms' ) ),
			'correct_feedback'    => ( 'assessment' === $type || in_array( $type, $manual_types, true ) ) ? '' : ( '' !== trim( wp_strip_all_tags( (string) ( $record['correct_feedback'] ?? '' ) ) ) ? wp_kses_post( $record['correct_feedback'] ) : __( 'Correct!', 'tutorhelper-lms' ) ),
			'max_marks'           => $max_marks,
			'answers'             => $configuration['answers'],
			'settings'            => $configuration['settings'],
		);
		$question_id = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => self::POST_TYPE,
					'post_title'   => $title,
					'post_content' => $prompt,
					'post_status'  => 'publish',
				)
			),
			true
		);
		if ( is_wp_error( $question_id ) || ! $question_id ) {
			self::log_failure( 'import_question', 0, is_wp_error( $question_id ) ? $question_id : null, 'post_write_failed' );
			return is_wp_error( $question_id ) ? $question_id : new WP_Error( 'save_failed', __( 'The imported Question could not be created.', 'tutorhelper-lms' ) );
		}
		$question_id = absint( $question_id );
		$fingerprint = hash( 'sha256', wp_json_encode( self::canonical_definition( $definition ) ) );
		$version_id = self::create_version( $question_id, $definition, $fingerprint, 1 );
		if ( ! $version_id ) {
			wp_delete_post( $question_id, true );
			self::log_failure( 'import_question_version', $question_id, null, 'database_write_failed' );
			return new WP_Error( 'save_failed', __( 'The imported Question version could not be created.', 'tutorhelper-lms' ) );
		}
		update_post_meta( $question_id, self::META_CURRENT_VERSION, $version_id );
		update_post_meta( $question_id, self::META_STATUS, $status );
		update_post_meta( $question_id, '_tutorhelper_lms_import_key', $import_key );
		update_post_meta( $question_id, '_tutorhelper_lms_import_source_reference', sanitize_text_field( $record['source_reference'] ?? '' ) );
		return array( 'question_id' => $question_id, 'created' => true );
	}

	/**
	 * Turn temporary audit answer rows into the canonical Question definition.
	 *
	 * @param string $type Question type.
	 * @param array  $record Preview record.
	 * @return array
	 */
	private static function import_configuration( $type, $record ) {
		$rows = is_array( $record['answers'] ?? null ) ? $record['answers'] : array();
		$source_settings = is_array( $record['settings'] ?? null ) ? $record['settings'] : array();
		if ( in_array( $type, array( 'single_choice', 'multiple_choice' ), true ) ) {
			$options = array();
			$correct = array();
			foreach ( $rows as $row ) {
				$text = sanitize_text_field( $row['text'] ?? '' );
				if ( '' === $text ) {
					continue;
				}
				$index = count( $options );
				$options[] = $text;
				if ( ! empty( $row['correct'] ) ) {
					$correct[] = (string) $index;
				}
			}
			return array( 'answers' => array( 'options' => $options, 'correct' => $correct ), 'settings' => array() );
		}
		if ( 'free_answer' === $type ) {
			return array( 'answers' => array( 'accepted' => self::import_answer_lines( $rows ) ), 'settings' => array( 'match_case' => ! empty( $source_settings['match_case'] ) ) );
		}
		if ( 'sort_answer' === $type ) {
			return array( 'answers' => array( 'items' => self::import_answer_lines( $rows ) ), 'settings' => array( 'exclude_final_item_mark' => ! empty( $source_settings['exclude_final_item_mark'] ) ) );
		}
		if ( 'matrix_sort' === $type ) {
			$pairs = array();
			foreach ( $rows as $row ) {
				$left = sanitize_text_field( $row['text'] ?? '' );
				$right = sanitize_text_field( $row['match'] ?? '' );
				if ( '' !== $left && '' !== $right ) {
					$pairs[] = array( 'left' => $left, 'right' => $right );
				}
			}
			return array( 'answers' => array( 'pairs' => $pairs ), 'settings' => array() );
		}
		if ( 'cloze' === $type ) {
			return array( 'answers' => array( 'blanks' => self::import_answer_lines( $rows ) ), 'settings' => array() );
		}
		if ( 'assessment' === $type ) {
			$minimum = absint( $source_settings['scale_min'] ?? 1 );
			$maximum = absint( $source_settings['scale_max'] ?? 5 );
			return array( 'answers' => array(), 'settings' => array( 'scale_min' => $minimum, 'scale_max' => $maximum ) );
		}
		return array( 'answers' => array(), 'settings' => array() );
	}

	/**
	 * @param array $rows Temporary answer rows.
	 * @return array
	 */
	private static function import_answer_lines( $rows ) {
		$answers = array();
		foreach ( $rows as $row ) {
			$text = sanitize_text_field( $row['text'] ?? '' );
			if ( '' !== $text ) {
				$answers[] = $text;
			}
		}
		return $answers;
	}

	/**
	 * Save a draft Question and create a version when its definition changes.
	 *
	 * @return void
	 */
	public static function save_question() {
		self::require_tutor();
		check_admin_referer( self::SAVE_ACTION );

		$question_id = isset( $_POST['question_id'] ) && ! is_array( $_POST['question_id'] ) ? absint( wp_unslash( $_POST['question_id'] ) ) : 0;
		$title       = self::posted_text( 'title' );
		$type        = self::posted_key( 'question_type' );
		$prompt      = self::posted_html( 'prompt' );
		$explanation = self::posted_html( 'student_explanation' );
		$incorrect_feedback = self::clean_editor_html( self::posted_html( 'incorrect_feedback' ) );
		$correct_feedback = self::clean_editor_html( self::posted_html( 'correct_feedback' ) );
		$max_marks   = isset( $_POST['max_marks'] ) && ! is_array( $_POST['max_marks'] ) ? intval( wp_unslash( $_POST['max_marks'] ) ) : 0;
		$status      = self::posted_key( 'question_status' );
		$configuration = self::posted_configuration( $type );

		if ( '' === $title || '' === trim( wp_strip_all_tags( $prompt ) ) ) {
			self::redirect( add_query_arg( 'lms_question_error', 'missing_required', self::tab_url( $question_id ) ) );
		}

		$types = self::question_types();
		if ( ! isset( $types[ $type ] ) ) {
			self::redirect( add_query_arg( 'lms_question_error', 'invalid_type', self::tab_url( $question_id ) ) );
		}
		if ( ! in_array( $status, array( 'draft', 'published' ), true ) ) {
			$status = 'draft';
		}

		// Granular Core Question types award one mark for each defined item.
		if ( 'matrix_sort' === $type ) {
			$max_marks = count( $configuration['answers']['pairs'] ?? array() );
		} elseif ( 'cloze' === $type ) {
			$max_marks = count( $configuration['answers']['blanks'] ?? array() );
		} elseif ( 'sort_answer' === $type ) {
			$max_marks = max( 0, count( $configuration['answers']['items'] ?? array() ) - ( ! empty( $configuration['settings']['exclude_final_item_mark'] ) ? 1 : 0 ) );
		} elseif ( 'assessment' === $type ) {
			$max_marks = 0;
		} elseif ( $max_marks < 1 || $max_marks > 10000 ) {
			self::redirect( add_query_arg( 'lms_question_error', 'invalid_marks', self::tab_url( $question_id ) ) );
		}
		if ( 'published' === $status ) {
			$configuration_error = self::validate_configuration( $type, $configuration['answers'], $configuration['settings'] );
			if ( is_wp_error( $configuration_error ) ) {
				self::redirect( add_query_arg( 'lms_question_error', $configuration_error->get_error_code(), self::tab_url( $question_id ) ) );
			}
		}

		$is_existing = (bool) $question_id;
		if ( $question_id ) {
			$existing = get_post( $question_id );
			if ( ! $existing || self::POST_TYPE !== $existing->post_type ) {
				self::redirect( add_query_arg( 'lms_question_error', 'save_failed', self::tab_url() ) );
			}
		}

		$post_data = array(
			'post_type'    => self::POST_TYPE,
			'post_title'   => $title,
			'post_content' => $prompt,
			'post_status'  => 'publish',
		);
		if ( $question_id ) {
			$post_data['ID'] = $question_id;
			$result = wp_update_post( wp_slash( $post_data ), true );
		} else {
			$result = wp_insert_post( wp_slash( $post_data ), true );
		}

		if ( is_wp_error( $result ) || ! $result ) {
			self::log_failure( $question_id ? 'update_question' : 'create_question', $question_id, is_wp_error( $result ) ? $result : null, 'empty_post_id' );
			self::redirect( add_query_arg( 'lms_question_error', 'save_failed', self::tab_url( $question_id ) ) );
		}

		$question_id = absint( $result );
		$definition  = array(
			'question_type'       => $type,
			'prompt'              => $prompt,
			'student_explanation' => $explanation,
			'incorrect_feedback' => ( 'assessment' === $type || in_array( $type, array_map( 'sanitize_key', (array) apply_filters( 'tutorhelper_lms_manual_question_types', array() ) ), true ) ) ? '' : ( '' !== $incorrect_feedback ? $incorrect_feedback : __( "That wasn't quite right.", 'tutorhelper-lms' ) ),
			'correct_feedback'   => ( 'assessment' === $type || in_array( $type, array_map( 'sanitize_key', (array) apply_filters( 'tutorhelper_lms_manual_question_types', array() ) ), true ) ) ? '' : ( '' !== $correct_feedback ? $correct_feedback : __( 'Correct!', 'tutorhelper-lms' ) ),
			'max_marks'           => $max_marks,
			'answers'             => $configuration['answers'],
			'settings'            => $configuration['settings'],
		);
		$fingerprint = hash( 'sha256', wp_json_encode( self::canonical_definition( $definition ) ) );
		$current     = self::get_current_version( $question_id );

		if ( ! $current || $fingerprint !== (string) $current->content_fingerprint ) {
			$version_id = self::create_version( $question_id, $definition, $fingerprint, $current ? absint( $current->version_number ) + 1 : 1 );
			if ( ! $version_id ) {
				self::log_failure( 'create_question_version', $question_id, null, 'database_write_failed' );
				self::redirect( add_query_arg( 'lms_question_error', 'save_failed', self::tab_url( $question_id ) ) );
			}
			update_post_meta( $question_id, self::META_CURRENT_VERSION, $version_id );
			if ( ! self::propagate_current_version( $question_id, $version_id ) ) {
				self::log_failure( 'propagate_question_version', $question_id, null, 'placement_update_failed' );
				self::redirect( add_query_arg( 'lms_question_error', 'save_failed', self::tab_url( $question_id ) ) );
			}
		}

		update_post_meta( $question_id, self::META_STATUS, $status );
		// Return to a clear create form after every successful save. The list remains
		// visible so tutors can immediately choose another Question to edit.
		self::redirect( add_query_arg( 'lms_question_updated', $is_existing ? 'saved' : 'created', self::tab_url() ) );
	}

	/**
	 * Create an immutable Core Question Version.
	 *
	 * @param int    $question_id Question post ID.
	 * @param array  $definition  Canonical Question definition.
	 * @param string $fingerprint Deterministic content fingerprint.
	 * @param int    $number      Version number.
	 * @return int
	 */
	private static function create_version( $question_id, $definition, $fingerprint, $number ) {
		global $wpdb;

		$table = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		if ( '' === $table ) {
			return 0;
		}

		$inserted = $wpdb->insert(
			$table,
			array(
				'question_id'         => absint( $question_id ),
				'version_number'      => absint( $number ),
				'question_type'       => sanitize_key( $definition['question_type'] ),
				'definition_json'     => wp_json_encode( $definition ),
				'max_marks'           => absint( $definition['max_marks'] ),
				'content_fingerprint' => $fingerprint,
				'created_by'          => get_current_user_id(),
				'created_at'          => current_time( 'mysql', true ),
			),
			array( '%d', '%d', '%s', '%s', '%d', '%s', '%d', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Immutable Core Question Version write.

		return $inserted ? absint( $wpdb->insert_id ) : 0;
	}

	/**
	 * Return the current version row for a Question.
	 *
	 * @param int $question_id Question post ID.
	 * @return object|null
	 */
	private static function get_current_version( $question_id ) {
		global $wpdb;

		$version_id = absint( get_post_meta( $question_id, self::META_CURRENT_VERSION, true ) );
		$table      = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		if ( ! $version_id || '' === $table ) {
			return null;
		}

		return $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND question_id = %d", $version_id, $question_id )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct lookup of one immutable version row.
	}

	/**
	 * Return one value from the current Question definition.
	 *
	 * @param int    $question_id Question post ID.
	 * @param string $key         Definition key.
	 * @param mixed  $default     Default.
	 * @return mixed
	 */
	private static function current_definition_value( $question_id, $key, $default ) {
		$current = self::get_current_version( $question_id );
		$data    = $current ? json_decode( $current->definition_json, true ) : array();
		return is_array( $data ) && array_key_exists( $key, $data ) ? $data[ $key ] : $default;
	}

	/**
	 * Return the current immutable definition or a safe editor default.
	 *
	 * @param int $question_id Question post ID.
	 * @return array
	 */
	private static function current_definition( $question_id ) {
		$current = self::get_current_version( $question_id );
		$data    = $current ? json_decode( $current->definition_json, true ) : array();
		return is_array( $data ) ? wp_parse_args( $data, self::empty_definition( self::current_question_type( $question_id ) ) ) : self::empty_definition( self::current_question_type( $question_id ) );
	}

	private static function empty_definition( $type ) {
		return array(
			'question_type'       => sanitize_key( $type ),
			'prompt'              => '',
			'student_explanation' => '',
			'max_marks'           => 'assessment' === $type ? 0 : 1,
			'answers'             => array(),
			'settings'            => array(),
		);
	}

	private static function current_status( $question_id ) {
		$status = get_post_meta( $question_id, self::META_STATUS, true );
		return in_array( $status, array( 'draft', 'published' ), true ) ? $status : 'draft';
	}

	/**
	 * Render every configuration panel. JavaScript shows only the chosen type,
	 * while all inputs remain progressively understandable if JavaScript is off.
	 *
	 * @param string $type       Current type.
	 * @param array  $definition Current definition.
	 * @return void
	 */
	private static function render_answer_editor( $type, $definition ) {
		$answers  = isset( $definition['answers'] ) && is_array( $definition['answers'] ) ? $definition['answers'] : array();
		$settings = isset( $definition['settings'] ) && is_array( $definition['settings'] ) ? $definition['settings'] : array();
		$options  = isset( $answers['options'] ) && is_array( $answers['options'] ) ? $answers['options'] : array( '', '', '' );
		$correct  = isset( $answers['correct'] ) && is_array( $answers['correct'] ) ? $answers['correct'] : array();
		?>
		<fieldset class="tutorhelper-lms-answer-editor" id="tutorhelper-lms-answer-editor">
			<legend><strong><?php esc_html_e( 'Answer definition', 'tutorhelper-lms' ); ?></strong></legend>
			<p class="description"><?php esc_html_e( 'Answers here are used to automatically mark answers. Written response questions must be manually marked by the tutor.', 'tutorhelper-lms' ); ?></p>

			<div class="tutorhelper-lms-answer-panel" data-question-type="single_choice multiple_choice">
				<p><strong><?php esc_html_e( 'Answer options', 'tutorhelper-lms' ); ?></strong></p>
				<div class="tutorhelper-lms-answer-options" data-tutorhelper-lms-answer-options>
					<?php foreach ( array_pad( $options, 3, '' ) as $index => $option ) : ?>
						<label class="tutorhelper-lms-answer-option"><input type="checkbox" name="correct_options[]" value="<?php echo esc_attr( $index ); ?>" <?php checked( in_array( (string) $index, array_map( 'strval', $correct ), true ) ); ?> /> <textarea class="tutorhelper-lms-answer-option__text" rows="1" name="answer_options[]" placeholder="<?php echo esc_attr( sprintf( __( 'Option %d', 'tutorhelper-lms' ), $index + 1 ) ); ?>"><?php echo esc_textarea( $option ); ?></textarea> <button class="button-link-delete tutorhelper-lms-answer-option__remove" type="button" aria-label="<?php esc_attr_e( 'Remove answer option', 'tutorhelper-lms' ); ?>"><?php esc_html_e( 'Remove', 'tutorhelper-lms' ); ?></button></label>
					<?php endforeach; ?>
				</div>
				<button class="button tutorhelper-lms-answer-option__add" type="button" data-tutorhelper-lms-add-answer><?php esc_html_e( 'Add answer option', 'tutorhelper-lms' ); ?></button>
				<p class="description"><?php esc_html_e( 'Select the correct option. Use one selection for Single Choice; select every correct option for Multiple Choice.', 'tutorhelper-lms' ); ?></p>
			</div>

			<div class="tutorhelper-lms-answer-panel" data-question-type="free_answer">
				<label><strong><?php esc_html_e( 'Accepted answers', 'tutorhelper-lms' ); ?></strong><textarea class="large-text" rows="4" name="accepted_answers"><?php echo esc_textarea( implode( "\n", isset( $answers['accepted'] ) && is_array( $answers['accepted'] ) ? $answers['accepted'] : array() ) ); ?></textarea></label>
				<label><input type="checkbox" name="match_case" value="1" <?php checked( ! empty( $settings['match_case'] ) ); ?> /> <?php esc_html_e( 'Match letter case exactly', 'tutorhelper-lms' ); ?></label>
				<p class="description"><?php esc_html_e( 'Enter one accepted exact answer per line. Flexible language marking is not part of Core automatic marking.', 'tutorhelper-lms' ); ?></p>
			</div>

			<div class="tutorhelper-lms-answer-panel" data-question-type="sort_answer">
				<label><strong><?php esc_html_e( 'Correct order', 'tutorhelper-lms' ); ?></strong><textarea class="large-text" rows="5" name="sort_items"><?php echo esc_textarea( implode( "\n", isset( $answers['items'] ) && is_array( $answers['items'] ) ? $answers['items'] : array() ) ); ?></textarea></label>
				<label><input type="checkbox" name="exclude_final_item_mark" value="1" <?php checked( ! empty( $settings['exclude_final_item_mark'] ) ); ?> /> <?php esc_html_e( 'Award no mark for the final item', 'tutorhelper-lms' ); ?></label>
				<p class="description"><?php esc_html_e( 'One mark is awarded for each correctly placed item. You can exclude the final item where it is determined by the rest of the sequence.', 'tutorhelper-lms' ); ?></p>
			</div>

			<div class="tutorhelper-lms-answer-panel" data-question-type="matrix_sort">
				<label><strong><?php esc_html_e( 'Correct pairs', 'tutorhelper-lms' ); ?></strong><textarea class="large-text" rows="5" name="matrix_pairs"><?php echo esc_textarea( implode( "\n", self::matrix_pairs_to_lines( isset( $answers['pairs'] ) && is_array( $answers['pairs'] ) ? $answers['pairs'] : array() ) ) ); ?></textarea></label>
				<p class="description"><?php esc_html_e( 'Enter one pair per line using “left | right”.', 'tutorhelper-lms' ); ?></p>
			</div>

			<div class="tutorhelper-lms-answer-panel" data-question-type="cloze">
				<label><strong><?php esc_html_e( 'Blank answers', 'tutorhelper-lms' ); ?></strong><textarea class="large-text" rows="4" name="cloze_answers"><?php echo esc_textarea( implode( "\n", isset( $answers['blanks'] ) && is_array( $answers['blanks'] ) ? $answers['blanks'] : array() ) ); ?></textarea></label>
				<p class="description"><?php esc_html_e( 'Use {{1}}, {{2}}, and so on in the Question prompt. Enter the matching answer for each blank on a separate line.', 'tutorhelper-lms' ); ?></p>
			</div>

			<div class="tutorhelper-lms-answer-panel" data-question-type="assessment">
				<label><?php esc_html_e( 'Lowest scale value', 'tutorhelper-lms' ); ?> <input type="number" min="0" max="100" name="scale_min" value="<?php echo esc_attr( isset( $settings['scale_min'] ) ? absint( $settings['scale_min'] ) : 1 ); ?>" /></label>
				<label><?php esc_html_e( 'Highest scale value', 'tutorhelper-lms' ); ?> <input type="number" min="1" max="100" name="scale_max" value="<?php echo esc_attr( isset( $settings['scale_max'] ) ? absint( $settings['scale_max'] ) : 5 ); ?>" /></label>
				<p class="description"><?php esc_html_e( 'Assessment/survey Questions collect an ungraded response and cannot affect marks or pass/fail outcomes.', 'tutorhelper-lms' ); ?></p>
			</div>
			<?php
			/**
			 * Renders type-specific definition controls supplied by an active add-on.
			 *
			 * @param string $type       Current Question type.
			 * @param array  $definition Current immutable definition.
			 */
			do_action( 'tutorhelper_lms_question_answer_editor', $type, $definition );
			?>
		</fieldset>
		<script>
		(function () {
			var select = document.getElementById('tutorhelper-lms-question-type');
			var editor = document.getElementById('tutorhelper-lms-answer-editor');
			var marksInput = document.getElementById('tutorhelper-lms-question-marks');
			var marksHelp = document.querySelector('[data-tutorhelper-lms-marks-help]');
			if (!select || !editor) { return; }
			var manualTypes = <?php echo wp_json_encode( array_values( array_unique( array_map( 'sanitize_key', (array) apply_filters( 'tutorhelper_lms_manual_question_types', array() ) ) ) ) ); ?>;
			function showSelected() {
				var selected = select.value;
				Array.prototype.forEach.call(editor.querySelectorAll('[data-question-type]'), function (panel) {
					var visible = panel.getAttribute('data-question-type').split(' ').indexOf(selected) !== -1;
					panel.hidden = !visible;
				});
				var derived = ['sort_answer', 'matrix_sort', 'cloze'].indexOf(selected) !== -1;
				if (marksInput) { marksInput.disabled = derived; }
				var automaticFeedback = document.querySelector('[data-tutorhelper-lms-automatic-feedback]');
				if (automaticFeedback) {
					automaticFeedback.hidden = selected === 'assessment' || manualTypes.indexOf(selected) !== -1;
				}
				if (marksHelp) {
					marksHelp.textContent = derived
						? '<?php echo esc_js( __( 'Marks are calculated automatically from the items, pairs or blanks in this Question.', 'tutorhelper-lms' ) ); ?>'
						: (manualTypes.indexOf(selected) !== -1
							? '<?php echo esc_js( __( 'This response is marked by the tutor. Set the maximum marks available for the Question.', 'tutorhelper-lms' ) ); ?>'
							: '<?php echo esc_js( __( 'Assessment/survey questions are always ungraded and will save as zero marks.', 'tutorhelper-lms' ) ); ?>');
				}
			}
			function resizeTextArea(textarea) {
				textarea.style.height = 'auto';
				textarea.style.height = Math.max(textarea.scrollHeight, 38) + 'px';
			}
			function renumberOptions() {
				var options = editor.querySelectorAll('[data-tutorhelper-lms-answer-options] .tutorhelper-lms-answer-option');
				Array.prototype.forEach.call(options, function (option, index) {
					var checkbox = option.querySelector('input[type="checkbox"]');
					var text = option.querySelector('textarea');
					if (checkbox) { checkbox.value = index; }
					if (text) {
						text.placeholder = '<?php echo esc_js( __( 'Option', 'tutorhelper-lms' ) ); ?> ' + (index + 1);
						resizeTextArea(text);
					}
				});
			}
			editor.addEventListener('click', function (event) {
				var add = event.target.closest('[data-tutorhelper-lms-add-answer]');
				var remove = event.target.closest('.tutorhelper-lms-answer-option__remove');
				var list = editor.querySelector('[data-tutorhelper-lms-answer-options]');
				if (add && list) {
					var index = list.querySelectorAll('.tutorhelper-lms-answer-option').length;
					var label = document.createElement('label');
					label.className = 'tutorhelper-lms-answer-option';
					var checkbox = document.createElement('input');
					checkbox.type = 'checkbox'; checkbox.name = 'correct_options[]'; checkbox.value = index;
					var input = document.createElement('textarea'); input.rows = 1; input.className = 'tutorhelper-lms-answer-option__text'; input.name = 'answer_options[]'; input.placeholder = '<?php echo esc_js( __( 'Option', 'tutorhelper-lms' ) ); ?> ' + (index + 1);
					var removeButton = document.createElement('button');
					removeButton.type = 'button'; removeButton.className = 'button-link-delete tutorhelper-lms-answer-option__remove'; removeButton.textContent = '<?php echo esc_js( __( 'Remove', 'tutorhelper-lms' ) ); ?>'; removeButton.setAttribute('aria-label', '<?php echo esc_js( __( 'Remove answer option', 'tutorhelper-lms' ) ); ?>');
					label.appendChild(checkbox); label.appendChild(input); label.appendChild(removeButton); list.appendChild(label);
					renumberOptions(); input.focus(); return;
				}
				if (remove) {
					var option = remove.closest('.tutorhelper-lms-answer-option');
					if (option && list && list.querySelectorAll('.tutorhelper-lms-answer-option').length > 2) {
						option.remove(); renumberOptions();
					}
				}
			});
			editor.addEventListener('input', function (event) {
				if (event.target.matches('.tutorhelper-lms-answer-option__text')) {
					resizeTextArea(event.target);
				}
			});
			select.addEventListener('change', showSelected);
			renumberOptions();
			showSelected();
		}());
		</script>
		<?php
	}

	private static function matrix_pairs_to_lines( $pairs ) {
		$lines = array();
		foreach ( $pairs as $pair ) {
			if ( is_array( $pair ) && isset( $pair['left'], $pair['right'] ) ) {
				$lines[] = $pair['left'] . ' | ' . $pair['right'];
			}
		}
		return $lines;
	}

	/**
	 * Sanitize the selected type's answer payload without trusting hidden panels.
	 *
	 * @param string $type Question type.
	 * @return array
	 */
	private static function posted_configuration( $type ) {
		$lines = function ( $key ) {
			$value = isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
			return array_values( array_filter( array_map( 'sanitize_text_field', preg_split( '/\r\n|\r|\n/', (string) $value ) ), 'strlen' ) );
		};
		if ( in_array( $type, array( 'single_choice', 'multiple_choice' ), true ) ) {
			$raw = isset( $_POST['answer_options'] ) && is_array( $_POST['answer_options'] ) ? wp_unslash( $_POST['answer_options'] ) : array();
			$selected = isset( $_POST['correct_options'] ) && is_array( $_POST['correct_options'] ) ? array_map( 'absint', wp_unslash( $_POST['correct_options'] ) ) : array();
			$options = array();
			$correct = array();
			foreach ( $raw as $raw_index => $raw_option ) {
				$option = sanitize_text_field( $raw_option );
				if ( '' === $option ) {
					continue;
				}
				$new_index = count( $options );
				$options[] = $option;
				if ( in_array( absint( $raw_index ), $selected, true ) ) {
					$correct[] = (string) $new_index;
				}
			}
			return array( 'answers' => array( 'options' => $options, 'correct' => array_values( array_unique( $correct ) ) ), 'settings' => array() );
		}
		if ( 'free_answer' === $type ) {
			return array( 'answers' => array( 'accepted' => $lines( 'accepted_answers' ) ), 'settings' => array( 'match_case' => ! empty( $_POST['match_case'] ) ) );
		}
		if ( 'sort_answer' === $type ) {
			return array( 'answers' => array( 'items' => $lines( 'sort_items' ) ), 'settings' => array( 'exclude_final_item_mark' => ! empty( $_POST['exclude_final_item_mark'] ) ) );
		}
		if ( 'matrix_sort' === $type ) {
			$pairs = array();
			foreach ( $lines( 'matrix_pairs' ) as $line ) {
				$pair = array_map( 'trim', explode( '|', $line, 2 ) );
				if ( 2 === count( $pair ) && '' !== $pair[0] && '' !== $pair[1] ) { $pairs[] = array( 'left' => $pair[0], 'right' => $pair[1] ); }
			}
			return array( 'answers' => array( 'pairs' => $pairs ), 'settings' => array() );
		}
		if ( 'cloze' === $type ) {
			return array( 'answers' => array( 'blanks' => $lines( 'cloze_answers' ) ), 'settings' => array() );
		}
		if ( 'assessment' === $type ) {
			return array( 'answers' => array(), 'settings' => array( 'scale_min' => isset( $_POST['scale_min'] ) ? absint( wp_unslash( $_POST['scale_min'] ) ) : 1, 'scale_max' => isset( $_POST['scale_max'] ) ? absint( wp_unslash( $_POST['scale_max'] ) ) : 5 ) );
		}
		/**
		 * Allows Premium extensions to persist configuration for their registered
		 * Question types without introducing Premium controls into Core.
		 *
		 * @param array|null $configuration Extension configuration, when supplied.
		 * @param string     $type          Selected Question type.
		 */
		$extension_configuration = apply_filters( 'tutorhelper_lms_question_posted_configuration', null, $type );
		if ( is_array( $extension_configuration ) ) {
			return array(
				'answers'  => isset( $extension_configuration['answers'] ) && is_array( $extension_configuration['answers'] ) ? $extension_configuration['answers'] : array(),
				'settings' => isset( $extension_configuration['settings'] ) && is_array( $extension_configuration['settings'] ) ? $extension_configuration['settings'] : array(),
			);
		}
		return array( 'answers' => array(), 'settings' => array() );
	}

	private static function validate_configuration( $type, $answers, $settings ) {
		if ( in_array( $type, array( 'single_choice', 'multiple_choice' ), true ) ) {
			$count = isset( $answers['options'] ) ? count( $answers['options'] ) : 0;
			$correct = isset( $answers['correct'] ) ? count( $answers['correct'] ) : 0;
			if ( $count < 2 || ( 'single_choice' === $type && 1 !== $correct ) || ( 'multiple_choice' === $type && $correct < 1 ) ) {
				return new WP_Error( 'invalid_options' );
			}
		}
		if ( 'free_answer' === $type && empty( $answers['accepted'] ) ) { return new WP_Error( 'invalid_free_answer' ); }
		if ( 'sort_answer' === $type && count( isset( $answers['items'] ) ? $answers['items'] : array() ) < 2 ) { return new WP_Error( 'invalid_sort_answer' ); }
		if ( 'matrix_sort' === $type && count( isset( $answers['pairs'] ) ? $answers['pairs'] : array() ) < 2 ) { return new WP_Error( 'invalid_matrix_sort' ); }
		if ( 'cloze' === $type && empty( $answers['blanks'] ) ) { return new WP_Error( 'invalid_cloze' ); }
		if ( 'assessment' === $type && ( empty( $settings['scale_min'] ) || empty( $settings['scale_max'] ) || absint( $settings['scale_min'] ) >= absint( $settings['scale_max'] ) ) ) { return new WP_Error( 'invalid_assessment_scale' ); }
		return true;
	}

	private static function current_question_type( $question_id ) {
		return self::current_definition_value( $question_id, 'question_type', 'single_choice' );
	}

	private static function current_max_marks( $question_id ) {
		return absint( self::current_definition_value( $question_id, 'max_marks', 1 ) );
	}

	private static function current_student_explanation( $question_id ) {
		return self::current_definition_value( $question_id, 'student_explanation', '' );
	}

	/**
	 * Render the reusable Question list.
	 *
	 * @return void
	 */
	private static function render_question_table() {
		$search = self::current_search();
		$page = self::current_page();
		$query = new WP_Query(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => 20,
				'paged'          => $page,
				's'              => $search,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);
		$questions = $query->posts;
		$types = self::question_types();
		?>
		<h3><?php esc_html_e( 'Reusable Questions', 'tutorhelper-lms' ); ?></h3>
		<form class="tutorhelper-lms-question-search" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
			<input type="hidden" name="page" value="<?php echo esc_attr( TutorHelper_LMS_Learning_Hub::PAGE_SLUG ); ?>" />
			<input type="hidden" name="tab" value="questions" />
			<label for="tutorhelper-lms-question-search"><strong><?php esc_html_e( 'Search Questions', 'tutorhelper-lms' ); ?></strong></label>
			<input id="tutorhelper-lms-question-search" type="search" class="regular-text" name="question_search" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search titles and prompts…', 'tutorhelper-lms' ); ?>" />
			<button type="submit" class="button tutorhelper-lms-button--grey"><?php esc_html_e( 'Search', 'tutorhelper-lms' ); ?></button>
			<?php if ( '' !== $search ) : ?><a class="button tutorhelper-lms-button--grey" href="<?php echo esc_url( add_query_arg( array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => 'questions' ), admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'Clear search', 'tutorhelper-lms' ); ?></a><?php endif; ?>
		</form>
		<?php if ( empty( $questions ) ) : ?>
			<p><?php echo '' !== $search ? esc_html__( 'No Questions matched that search.', 'tutorhelper-lms' ) : esc_html__( 'No Questions yet. Create one here; it can later be placed into one or more Quizzes.', 'tutorhelper-lms' ); ?></p>
			<?php return; ?>
		<?php endif; ?>
		<p class="description"><?php echo esc_html( sprintf( _n( '%d Question found', '%d Questions found', absint( $query->found_posts ), 'tutorhelper-lms' ), absint( $query->found_posts ) ) ); ?></p>
		<div class="tutorhelper-lms-question-table-wrap"><table class="widefat striped">
			<thead><tr>
				<th><?php esc_html_e( 'Question', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Type', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Marks', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Version', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Action', 'tutorhelper-lms' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( $questions as $question ) : ?>
				<?php $current = self::get_current_version( $question->ID ); $type = $current ? $current->question_type : ''; ?>
				<tr>
					<td><strong><?php echo esc_html( $question->post_title ); ?></strong></td>
					<td><?php echo esc_html( isset( $types[ $type ] ) ? $types[ $type ] : __( 'Unknown', 'tutorhelper-lms' ) ); ?></td>
					<td><?php echo $current && 'assessment' !== $type ? esc_html( number_format_i18n( absint( $current->max_marks ) ) ) : esc_html__( 'Ungraded', 'tutorhelper-lms' ); ?></td>
					<td><?php echo esc_html( $current ? (string) absint( $current->version_number ) : '—' ); ?></td>
					<td><?php echo 'published' === self::current_status( $question->ID ) ? esc_html__( 'Published', 'tutorhelper-lms' ) : esc_html__( 'Draft', 'tutorhelper-lms' ); ?></td>
					<td><a class="button tutorhelper-action-button tutorhelper-lms-question-edit" href="<?php echo esc_url( self::tab_url( $question->ID ) ); ?>"><?php esc_html_e( 'Edit Question', 'tutorhelper-lms' ); ?></a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<?php if ( $query->max_num_pages > 1 ) : ?>
			<nav class="tablenav-pages tutorhelper-lms-question-pagination" aria-label="<?php esc_attr_e( 'Question pages', 'tutorhelper-lms' ); ?>">
				<?php
				echo wp_kses_post(
					paginate_links(
						array(
							'base'      => add_query_arg( 'question_page', '%#%', self::tab_url() ),
							'format'    => '',
							'current'   => $page,
							'total'     => absint( $query->max_num_pages ),
							'type'      => 'list',
							'prev_text' => __( 'Previous', 'tutorhelper-lms' ),
							'next_text' => __( 'Next', 'tutorhelper-lms' ),
						)
					)
				);
				?>
			</nav>
		<?php endif; ?>
		<?php
	}
	/**
	 * Return a stable canonical structure for content fingerprinting.
	 *
	 * @param array $definition Definition.
	 * @return array
	 */
	/**
	 * Make a new current Question version the source for every future Quiz attempt.
	 *
	 * Quiz and Course placement records point to the reusable Question version,
	 * whereas submitted attempts retain an independent JSON snapshot and are never
	 * touched by this update.
	 *
	 * @param int $question_id Question post ID.
	 * @param int $version_id New current Question version ID.
	 * @return bool
	 */
	private static function propagate_current_version( $question_id, $version_id ) {
		global $wpdb;
		$quiz_placements = TutorHelper_LMS_Free_Database::table( 'quiz_question_placements' );
		$topic_links = TutorHelper_LMS_Free_Database::table( 'course_quiz_question_topics' );
		$quiz_versions = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		$question_versions = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		if ( ! $quiz_placements || ! $quiz_versions || ! $question_versions ) { return false; }
		$quiz_version_ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT quiz_version_id FROM {$quiz_placements} WHERE question_id = %d", absint( $question_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finds reusable Quiz versions affected by the current Question edit.
		if ( false === $wpdb->update( $quiz_placements, array( 'question_version_id' => absint( $version_id ) ), array( 'question_id' => absint( $question_id ) ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Propagates reusable Question edits to future Quiz attempts only.
			return false;
		}
		if ( $topic_links && false === $wpdb->update( $topic_links, array( 'question_version_id' => absint( $version_id ), 'updated_at' => current_time( 'mysql', true ) ), array( 'question_id' => absint( $question_id ) ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Retains Course-specific Topic assignments while updating Question content.
			return false;
		}
		foreach ( array_filter( array_map( 'absint', (array) $quiz_version_ids ) ) as $quiz_version_id ) {
			$total_marks = absint( $wpdb->get_var( $wpdb->prepare( "SELECT SUM(CASE WHEN p.mark_override IS NULL THEN q.max_marks ELSE p.mark_override END) FROM {$quiz_placements} p INNER JOIN {$question_versions} q ON q.id = p.question_version_id WHERE p.quiz_version_id = %d", $quiz_version_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Refreshes the reusable Quiz maximum after a derived Question-mark change.
			if ( false === $wpdb->update( $quiz_versions, array( 'total_marks' => $total_marks ), array( 'id' => $quiz_version_id ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Keeps future Quiz and Course maximum marks in sync with the reusable Question.
				return false;
			}
		}
		return true;
	}

	private static function canonical_definition( $definition ) {
		return array(
			'question_type'       => sanitize_key( $definition['question_type'] ),
			'prompt'              => trim( wp_strip_all_tags( $definition['prompt'] ) ),
			'student_explanation' => trim( wp_strip_all_tags( $definition['student_explanation'] ) ),
			'incorrect_feedback'  => trim( wp_strip_all_tags( $definition['incorrect_feedback'] ?? '' ) ),
			'correct_feedback'    => trim( wp_strip_all_tags( $definition['correct_feedback'] ?? '' ) ),
			'max_marks'           => absint( $definition['max_marks'] ),
			'answers'             => $definition['answers'],
			'settings'            => $definition['settings'],
		);
	}

	/**
	 * Remove TinyMCE's transient selection bookmark before persisting editor HTML.
	 *
	 * @param string $html Submitted rich text.
	 * @return string
	 */
	private static function clean_editor_html( $html ) {
		$html = (string) $html;
		return preg_replace( "#<span\\b[^>]*\\bdata-mce-type=(?:'bookmark'|\"bookmark\")[^>]*>\\s*</span>#i", '', $html );
	}


	private static function posted_text( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	private static function posted_key( $key ) {
		return sanitize_key( self::posted_text( $key ) );
	}

	private static function posted_html( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? wp_kses_post( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	private static function require_tutor() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Questions.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
	}

	private static function tab_url( $edit_id = 0 ) {
		$args = array(
			'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG,
			'tab'  => 'questions',
		);
		$search = self::current_search();
		if ( '' !== $search ) {
			$args['question_search'] = $search;
		}
		$page = self::current_page();
		if ( $page > 1 ) {
			$args['question_page'] = $page;
		}
		if ( $edit_id ) {
			$args['edit'] = absint( $edit_id );
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/**
	 * @return string
	 */
	private static function current_search() {
		$value = $_REQUEST['question_search'] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only listing state, preserved through an authenticated save.
		return is_array( $value ) ? '' : sanitize_text_field( wp_unslash( $value ) );
	}

	/**
	 * @return int
	 */
	private static function current_page() {
		$value = $_REQUEST['question_page'] ?? 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only listing state, preserved through an authenticated save.
		return is_array( $value ) ? 1 : max( 1, absint( $value ) );
	}

	private static function redirect( $url ) {
		wp_safe_redirect( $url );
		exit;
	}

	private static function render_notice() {
		$updated = isset( $_GET['lms_question_updated'] ) && ! is_array( $_GET['lms_question_updated'] ) ? sanitize_key( wp_unslash( $_GET['lms_question_updated'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect notice.
		$error   = isset( $_GET['lms_question_error'] ) && ! is_array( $_GET['lms_question_error'] ) ? sanitize_key( wp_unslash( $_GET['lms_question_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect notice.
		$errors  = array(
			'missing_required' => __( 'Enter both a Question title and Question prompt.', 'tutorhelper-lms' ),
			'invalid_type'     => __( 'Choose a supported Core Question type.', 'tutorhelper-lms' ),
			'invalid_marks'             => __( 'Maximum marks must be a whole number between 1 and 10,000 for a graded Question.', 'tutorhelper-lms' ),
			'invalid_options'           => __( 'Add at least two options and select the required correct answer(s) before publishing.', 'tutorhelper-lms' ),
			'invalid_free_answer'       => __( 'Add at least one accepted answer before publishing.', 'tutorhelper-lms' ),
			'invalid_sort_answer'       => __( 'Add at least two items in the correct order before publishing.', 'tutorhelper-lms' ),
			'invalid_matrix_sort'       => __( 'Add at least two complete left/right pairs before publishing.', 'tutorhelper-lms' ),
			'invalid_cloze'             => __( 'Add an answer for each blank before publishing.', 'tutorhelper-lms' ),
			'invalid_assessment_scale'  => __( 'Choose a valid assessment scale with a lower and higher value.', 'tutorhelper-lms' ),
			'save_failed'               => __( 'The Question could not be saved. Please try again.', 'tutorhelper-lms' ),
		);
		if ( $updated ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Question saved successfully.', 'tutorhelper-lms' ) . '</p></div>';
		}
		if ( $error ) {
			echo '<div class="notice notice-error"><p>' . esc_html( isset( $errors[ $error ] ) ? $errors[ $error ] : __( 'The Question could not be saved. Please try again.', 'tutorhelper-lms' ) ) . '</p></div>';
		}
	}

	private static function log_failure( $operation, $question_id, $error, $reason ) {
		if ( ! class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			return;
		}
		$context = array(
			'operation'      => $operation,
			'entity_id'      => absint( $question_id ),
			'post_type'      => self::POST_TYPE,
			'failure_reason' => sanitize_key( $reason ),
		);
		if ( is_wp_error( $error ) ) {
			TutorHelper_LMS_Diagnostics::wp_error( 'Question Bank save failed.', $error, $context );
			return;
		}
		TutorHelper_LMS_Diagnostics::error( 'Question Bank save failed.', $context );
	}
}
