<?php
/**
 * Reusable rich-text and external-link Resource Library for TutorHelper LMS.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Resource_Library {

	const POST_TYPE = 'tutorhelper_resource';
	const SAVE_ACTION = 'tutorhelper_lms_save_resource';
	const DELETE_ACTION = 'tutorhelper_lms_delete_resource';
	const META_TYPE = '_tutorhelper_lms_resource_type';
	const META_EXTERNAL_URL = '_tutorhelper_lms_resource_external_url';
	const META_EXTERNAL_KIND = '_tutorhelper_lms_resource_external_kind';
	const META_ORIGIN = '_tutorhelper_lms_resource_origin';
	const META_THIRD_PARTY_CONFIRMED = '_tutorhelper_lms_resource_third_party_confirmed';
	const META_ATTRIBUTION = '_tutorhelper_lms_resource_attribution';
	const META_OWNER = '_tutorhelper_lms_resource_owner';
	const META_SOURCE_SYSTEM = '_tutorhelper_lms_resource_source_system';
	const META_SOURCE_ID = '_tutorhelper_lms_resource_source_id';
	const META_CURRENT_VERSION = '_tutorhelper_lms_resource_current_version';

	/** Register Resource Library routes. */
	public static function init() {
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save' ) );
		add_action( 'admin_post_' . self::DELETE_ACTION, array( __CLASS__, 'delete' ) );
	}

	/** Render the Learning Hub Resource Library workspace. */
	public static function render_section() {
		self::require_tutor();
		$editing = self::edited_resource();
		$resources = self::filtered_resources();
		?>
		<div class="tutorhelper-lms-resource-library">
			<?php self::render_notice(); ?>
			<?php do_action( 'tutorhelper_lms_resource_library_notices' ); ?>
			<section class="tutorhelper-lms-resource-library__form">
				<?php $form_open = (bool) $editing; ?>
				<button class="button tutorhelper-action-button tutorhelper-lms-button--orange tutorhelper-lms-resource-library__toggle" type="button" data-tutorhelper-lms-resource-toggle aria-expanded="<?php echo $form_open ? 'true' : 'false'; ?>" aria-controls="tutorhelper-lms-resource-editor"><?php echo esc_html( $editing ? __( 'Edit Resource', 'tutorhelper-lms' ) : __( 'Add Resource', 'tutorhelper-lms' ) ); ?></button>
				<div id="tutorhelper-lms-resource-editor" class="tutorhelper-lms-resource-library__editor" data-tutorhelper-lms-resource-editor<?php echo $form_open ? '' : ' hidden'; ?>>
					<h3><?php echo esc_html( $editing ? __( 'Edit Resource', 'tutorhelper-lms' ) : __( 'Create Resource', 'tutorhelper-lms' ) ); ?></h3>
					<p class="description"><?php esc_html_e( 'A Resource is a reusable master item. Attaching it to more than one Course, Topic or Lesson never copies the content.', 'tutorhelper-lms' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
						<input type="hidden" name="resource_id" value="<?php echo esc_attr( $editing ? $editing->ID : 0 ); ?>" />
						<?php wp_nonce_field( self::SAVE_ACTION ); ?>
						<p><label for="tutorhelper-lms-resource-title"><strong><?php esc_html_e( 'Resource title', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-resource-title" class="regular-text" type="text" name="title" required value="<?php echo esc_attr( $editing ? $editing->post_title : '' ); ?>" /></p>
						<p><label for="tutorhelper-lms-resource-type"><strong><?php esc_html_e( 'Resource type', 'tutorhelper-lms' ); ?></strong></label><select id="tutorhelper-lms-resource-type" name="resource_type" data-tutorhelper-lms-resource-type><?php foreach ( self::resource_types( self::type( $editing ? $editing->ID : 0 ) ) as $resource_type => $resource_label ) : ?><option value="<?php echo esc_attr( $resource_type ); ?>" <?php selected( self::type( $editing ? $editing->ID : 0 ), $resource_type ); ?>><?php echo esc_html( $resource_label ); ?></option><?php endforeach; ?></select></p>
						<?php do_action( 'tutorhelper_lms_resource_library_after_type_fields', $editing ); ?>
						<div data-tutorhelper-lms-resource-fields="rich_text">
							<p><label for="tutorhelper-lms-resource-content"><strong><?php esc_html_e( 'Resource content', 'tutorhelper-lms' ); ?></strong></label><?php wp_editor( $editing ? $editing->post_content : '', 'tutorhelper-lms-resource-content', array( 'textarea_name' => 'content', 'textarea_rows' => 9, 'media_buttons' => true, 'teeny' => false ) ); ?><span class="description"><?php esc_html_e( 'Write the teaching content that will be reused wherever this Resource is attached.', 'tutorhelper-lms' ); ?></span></p>
						</div>
						<div data-tutorhelper-lms-resource-fields="external_link">
							<p><label for="tutorhelper-lms-resource-link"><strong><?php esc_html_e( 'External HTTPS link', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-resource-link" class="regular-text" type="url" name="external_url" placeholder="https://" value="<?php echo esc_attr( $editing ? self::external_url( $editing->ID ) : '' ); ?>" /><span class="description"><?php esc_html_e( 'Only HTTPS links are accepted. TutorHelper will not make this link public or create a sharing link.', 'tutorhelper-lms' ); ?></span></p>
							<p><label for="tutorhelper-lms-resource-link-kind"><strong><?php esc_html_e( 'Link type', 'tutorhelper-lms' ); ?></strong></label><select id="tutorhelper-lms-resource-link-kind" name="external_kind"><option value="video" <?php selected( self::external_kind( $editing ? $editing->ID : 0 ), 'video' ); ?>><?php esc_html_e( 'Video', 'tutorhelper-lms' ); ?></option><option value="website" <?php selected( self::external_kind( $editing ? $editing->ID : 0 ), 'website' ); ?>><?php esc_html_e( 'Website', 'tutorhelper-lms' ); ?></option><option value="document" <?php selected( self::external_kind( $editing ? $editing->ID : 0 ), 'document' ); ?>><?php esc_html_e( 'Document', 'tutorhelper-lms' ); ?></option><option value="other" <?php selected( self::external_kind( $editing ? $editing->ID : 0 ), 'other' ); ?>><?php esc_html_e( 'Other', 'tutorhelper-lms' ); ?></option></select></p>
						</div>
						<p><label for="tutorhelper-lms-resource-origin"><strong><?php esc_html_e( 'Content origin', 'tutorhelper-lms' ); ?></strong></label><select id="tutorhelper-lms-resource-origin" name="origin" data-tutorhelper-lms-resource-origin><option value="tutor" <?php selected( self::origin( $editing ? $editing->ID : 0 ), 'tutor' ); ?>><?php esc_html_e( 'Created by me', 'tutorhelper-lms' ); ?></option><option value="third_party" <?php selected( self::origin( $editing ? $editing->ID : 0 ), 'third_party' ); ?>><?php esc_html_e( 'Third-party content', 'tutorhelper-lms' ); ?></option></select></p>
						<div data-tutorhelper-lms-resource-origin-fields="third_party">
							<p><label for="tutorhelper-lms-resource-attribution"><strong><?php esc_html_e( 'Source or attribution', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-resource-attribution" class="regular-text" type="text" name="attribution" value="<?php echo esc_attr( $editing ? self::attribution( $editing->ID ) : '' ); ?>" /><span class="description"><?php esc_html_e( 'Optional: record the creator, publisher or licence reference for your records.', 'tutorhelper-lms' ); ?></span></p>
							<p><label><input type="checkbox" name="third_party_confirmed" value="1" data-tutorhelper-lms-third-party-confirmed <?php checked( $editing && self::third_party_confirmed( $editing->ID ) ); ?> /> <?php esc_html_e( 'I confirm that I have the appropriate licence, permission or agreement to use this third-party content.', 'tutorhelper-lms' ); ?></label></p>
						</div>
						<?php self::render_term_picker( 'level_ids', 'tutorhelper_lms_level', __( 'Levels', 'tutorhelper-lms' ), $editing ? wp_get_object_terms( $editing->ID, 'tutorhelper_lms_level', array( 'fields' => 'ids' ) ) : array() ); ?>
						<?php self::render_term_picker( 'subject_ids', 'tutorhelper_lms_subject', __( 'Subjects', 'tutorhelper-lms' ), $editing ? wp_get_object_terms( $editing->ID, 'tutorhelper_lms_subject', array( 'fields' => 'ids' ) ) : array() ); ?>
						<div class="tutorhelper-lms-resource-library__associations">
							<?php self::render_content_picker( 'course_ids', 'tutorhelper_course', __( 'Courses', 'tutorhelper-lms' ), $editing ? self::associated_parent_ids( $editing->ID, 'tutorhelper_course' ) : array(), '' ); ?>
							<?php self::render_content_picker( 'topic_ids', 'tutorhelper_topic', __( 'Topics', 'tutorhelper-lms' ), $editing ? self::associated_parent_ids( $editing->ID, 'tutorhelper_topic' ) : array(), 'tutorhelper_course' ); ?>
							<?php self::render_content_picker( 'lesson_ids', 'tutorhelper_lesson', __( 'Lessons', 'tutorhelper-lms' ), $editing ? self::associated_parent_ids( $editing->ID, 'tutorhelper_lesson' ) : array(), 'tutorhelper_topic' ); ?>
						</div>
						<p><label><input type="checkbox" name="publish" value="1" <?php checked( ! $editing || 'publish' === $editing->post_status ); ?> /> <?php esc_html_e( 'Make this Resource available for future authorised learning use', 'tutorhelper-lms' ); ?></label></p>
						<p><button class="button button-primary tutorhelper-action-button" type="submit"><?php echo esc_html( $editing ? __( 'Save Resource', 'tutorhelper-lms' ) : __( 'Create Resource', 'tutorhelper-lms' ) ); ?></button><?php if ( $editing ) : ?> <a class="button" href="<?php echo esc_url( self::tab_url() ); ?>"><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></a><?php endif; ?></p>
					</form>
				</div>
			</section>
			<section>
				<h3><?php esc_html_e( 'Resource Library', 'tutorhelper-lms' ); ?></h3>
				<?php self::render_filters(); ?>
				<?php self::render_table( $resources ); ?>
			</section>
		</div>
		<?php
	}

	/** Save one Resource and its reusable academic associations. */
	public static function save() {
		self::require_tutor();
		check_admin_referer( self::SAVE_ACTION );
		$resource_id = self::posted_id( 'resource_id' );
		$is_new_resource = ! $resource_id;
		$title = sanitize_text_field( self::posted_value( 'title' ) );
		$type = sanitize_key( self::posted_value( 'resource_type' ) );
		$content = 'rich_text' === $type && isset( $_POST['content'] ) && ! is_array( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '';
		$url = self::sanitise_https_url( self::posted_value( 'external_url' ) );
		$external_kind = sanitize_key( self::posted_value( 'external_kind' ) );
		$origin = sanitize_key( self::posted_value( 'origin' ) );
		$third_party_confirmed = self::posted_bool( 'third_party_confirmed' );
		$attribution = sanitize_text_field( self::posted_value( 'attribution' ) );
		if ( '' === $title || ! array_key_exists( $type, self::known_resource_types() ) || ! in_array( $origin, array( 'tutor', 'third_party' ), true ) || ( 'external_link' === $type && ( '' === $url || ! in_array( $external_kind, self::external_kinds(), true ) ) ) || ( 'third_party' === $origin && ! $third_party_confirmed ) ) {
			self::redirect( 'resource_error' );
		}
		if ( $resource_id && self::POST_TYPE !== get_post_type( $resource_id ) ) {
			self::redirect( 'resource_error' );
		}
		$post = array( 'post_type' => self::POST_TYPE, 'post_title' => $title, 'post_content' => $content, 'post_status' => self::posted_bool( 'publish' ) ? 'publish' : 'draft' );
		if ( $resource_id ) { $post['ID'] = $resource_id; $resource_id = wp_update_post( wp_slash( $post ), true ); } else { $resource_id = wp_insert_post( wp_slash( $post ), true ); }
		if ( is_wp_error( $resource_id ) || ! $resource_id ) {
			self::log_error( 'save_resource', 0, is_wp_error( $resource_id ) ? $resource_id->get_error_code() : 'empty_resource_id' );
			self::redirect( 'resource_error' );
		}
		if ( ! get_post_meta( $resource_id, self::META_OWNER, true ) ) { update_post_meta( $resource_id, self::META_OWNER, get_current_user_id() ); }
		update_post_meta( $resource_id, self::META_TYPE, $type );
		update_post_meta( $resource_id, self::META_EXTERNAL_URL, 'external_link' === $type ? $url : '' );
		update_post_meta( $resource_id, self::META_EXTERNAL_KIND, 'external_link' === $type ? $external_kind : '' );
		update_post_meta( $resource_id, self::META_ORIGIN, $origin );
		update_post_meta( $resource_id, self::META_THIRD_PARTY_CONFIRMED, 'third_party' === $origin && $third_party_confirmed ? '1' : '0' );
		update_post_meta( $resource_id, self::META_ATTRIBUTION, 'third_party' === $origin ? $attribution : '' );
		if ( '' === get_post_meta( $resource_id, self::META_CURRENT_VERSION, true ) ) { update_post_meta( $resource_id, self::META_CURRENT_VERSION, 1 ); }
		if ( '' === get_post_meta( $resource_id, self::META_SOURCE_SYSTEM, true ) ) { update_post_meta( $resource_id, self::META_SOURCE_SYSTEM, 'tutorhelper_lms' ); }
		if ( '' === get_post_meta( $resource_id, self::META_SOURCE_ID, true ) ) { update_post_meta( $resource_id, self::META_SOURCE_ID, (string) $resource_id ); }
		wp_set_object_terms( $resource_id, self::posted_ids( 'level_ids' ), 'tutorhelper_lms_level', false );
		wp_set_object_terms( $resource_id, self::posted_ids( 'subject_ids' ), 'tutorhelper_lms_subject', false );
		self::replace_associations( $resource_id, 'tutorhelper_course', self::posted_ids( 'course_ids' ) );
		self::replace_associations( $resource_id, 'tutorhelper_topic', self::posted_ids( 'topic_ids' ) );
		self::replace_associations( $resource_id, 'tutorhelper_lesson', self::posted_ids( 'lesson_ids' ) );
		do_action( 'tutorhelper_lms_resource_library_saved', $resource_id, $is_new_resource, $type );
		self::redirect( 'resource_saved', $is_new_resource ? 0 : $resource_id );
	}

	/** Trash an unused Resource; master items with associations must be detached first. */
	public static function delete() {
		self::require_tutor();
		$resource_id = self::posted_id( 'resource_id' );
		check_admin_referer( self::DELETE_ACTION . '_' . $resource_id );
		if ( self::POST_TYPE !== get_post_type( $resource_id ) || self::has_associations( $resource_id ) || ! wp_trash_post( $resource_id ) ) {
			self::log_error( 'delete_resource', $resource_id, self::has_associations( $resource_id ) ? 'resource_in_use' : 'delete_failed' );
			self::redirect( 'resource_delete_error' );
		}
		self::redirect( 'resource_deleted' );
	}

	/** Render Resource search and context filters. */
	private static function render_filters() {
		$selected = self::filter_values();
		?>
		<form method="get" class="tutorhelper-lms-resource-library__filters">
			<input type="hidden" name="page" value="<?php echo esc_attr( TutorHelper_LMS_Learning_Hub::PAGE_SLUG ); ?>" /><input type="hidden" name="tab" value="resources" />
			<label><?php esc_html_e( 'Search', 'tutorhelper-lms' ); ?><input type="search" name="resource_search" value="<?php echo esc_attr( $selected['search'] ); ?>" /></label>
			<?php self::render_filter_select( 'resource_type', __( 'Type', 'tutorhelper-lms' ), array_merge( array( '' => __( 'All types', 'tutorhelper-lms' ) ), self::known_resource_types() ), $selected['type'] ); ?>
			<?php self::render_filter_select( 'resource_level', __( 'Level', 'tutorhelper-lms' ), self::term_options( 'tutorhelper_lms_level' ), $selected['level'] ); ?>
			<?php self::render_filter_select( 'resource_subject', __( 'Subject', 'tutorhelper-lms' ), self::term_options( 'tutorhelper_lms_subject' ), $selected['subject'] ); ?>
			<?php self::render_filter_select( 'resource_course', __( 'Course', 'tutorhelper-lms' ), self::content_options( 'tutorhelper_course' ), $selected['course'] ); ?>
			<?php self::render_filter_select( 'resource_topic', __( 'Topic', 'tutorhelper-lms' ), self::content_options( 'tutorhelper_topic' ), $selected['topic'] ); ?>
			<button class="button tutorhelper-action-button" type="submit"><?php esc_html_e( 'Filter', 'tutorhelper-lms' ); ?></button>
		</form>
		<?php
	}

	/** Render a compact Resource table. */
	private static function render_table( $resources ) {
		?><table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Resource', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Type', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Origin', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Academic links', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Actions', 'tutorhelper-lms' ); ?></th></tr></thead><tbody><?php if ( empty( $resources ) ) : ?><tr><td colspan="6"><?php esc_html_e( 'No Resources match these filters yet.', 'tutorhelper-lms' ); ?></td></tr><?php else : foreach ( $resources as $resource ) : ?><tr><td><strong><?php echo esc_html( $resource->post_title ); ?></strong><?php if ( 'external_link' === self::type( $resource->ID ) ) : ?><br /><a href="<?php echo esc_url( self::external_url( $resource->ID ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open external link', 'tutorhelper-lms' ); ?></a><?php endif; ?></td><td><span class="tutorhelper-lms-resource-library__type"><?php echo esc_html( self::type_label( $resource->ID ) ); ?></span></td><td><?php echo esc_html( self::origin_label( $resource->ID ) ); ?></td><td class="tutorhelper-lms-resource-library__links"><?php echo esc_html( self::link_summary( $resource->ID ) ); ?></td><td><?php echo esc_html( 'publish' === $resource->post_status ? __( 'Published', 'tutorhelper-lms' ) : __( 'Draft', 'tutorhelper-lms' ) ); ?></td><td><a class="button tutorhelper-action-button tutorhelper-lms-button--orange" href="<?php echo esc_url( add_query_arg( 'resource_edit', $resource->ID, self::tab_url() ) ); ?>"><?php esc_html_e( 'Edit', 'tutorhelper-lms' ); ?></a><form class="tutorhelper-lms-library-delete" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="<?php echo esc_attr( self::DELETE_ACTION ); ?>" /><input type="hidden" name="resource_id" value="<?php echo esc_attr( $resource->ID ); ?>" /><?php wp_nonce_field( self::DELETE_ACTION . '_' . $resource->ID ); ?><button class="button-link-delete" type="submit" <?php disabled( self::has_associations( $resource->ID ) ); ?>><?php esc_html_e( 'Delete', 'tutorhelper-lms' ); ?></button></form></td></tr><?php endforeach; endif; ?></tbody></table><?php
	}

	/** Return Resources filtered by the current catalogue controls. */
	private static function filtered_resources() {
		$filters = self::filter_values();
		$args = array( 'post_type' => self::POST_TYPE, 'post_status' => array( 'publish', 'draft', 'private' ), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 's' => $filters['search'] );
		$tax_query = array();
		if ( $filters['level'] ) { $tax_query[] = array( 'taxonomy' => 'tutorhelper_lms_level', 'field' => 'term_id', 'terms' => $filters['level'] ); }
		if ( $filters['subject'] ) { $tax_query[] = array( 'taxonomy' => 'tutorhelper_lms_subject', 'field' => 'term_id', 'terms' => $filters['subject'] ); }
		if ( $tax_query ) { $args['tax_query'] = $tax_query; }
		$resources = get_posts( $args );
		return array_values( array_filter( $resources, static function( $resource ) use ( $filters ) {
			if ( $filters['type'] && self::type( $resource->ID ) !== $filters['type'] ) { return false; }
			if ( $filters['course'] && ! in_array( $filters['course'], self::associated_parent_ids( $resource->ID, 'tutorhelper_course' ), true ) ) { return false; }
			if ( $filters['topic'] && ! in_array( $filters['topic'], self::associated_parent_ids( $resource->ID, 'tutorhelper_topic' ), true ) ) { return false; }
			return true;
		} ) );
	}

	/** Return current safe filter values. */
	private static function filter_values() {
		return array( 'search' => sanitize_text_field( self::query_value( 'resource_search' ) ), 'type' => sanitize_key( self::query_value( 'resource_type' ) ), 'level' => absint( self::query_value( 'resource_level' ) ), 'subject' => absint( self::query_value( 'resource_subject' ) ), 'course' => absint( self::query_value( 'resource_course' ) ), 'topic' => absint( self::query_value( 'resource_topic' ) ) );
	}

	/** Return all known Resource types, including safely retained Premium metadata. */
	private static function known_resource_types() {
		return array(
			'rich_text'     => __( 'Rich text resource', 'tutorhelper-lms' ),
			'external_link' => __( 'External HTTPS link', 'tutorhelper-lms' ),
			'private_file'  => __( 'Private uploaded file', 'tutorhelper-lms' ),
		);
	}
	/** Return Resource types available for selection in this installation. */
	private static function resource_types( $current_type = '' ) {
		$types = array(
			'rich_text'     => __( 'Rich text resource', 'tutorhelper-lms' ),
			'external_link' => __( 'External HTTPS link', 'tutorhelper-lms' ),
		);
		$types = apply_filters( 'tutorhelper_lms_resource_types', $types );
		$types = is_array( $types ) ? $types : array( 'rich_text' => __( 'Rich text resource', 'tutorhelper-lms' ) );
		$current_type = sanitize_key( $current_type );
		if ( 'private_file' === $current_type && ! isset( $types['private_file'] ) ) {
			$types['private_file'] = __( 'Private uploaded file (Premium unavailable)', 'tutorhelper-lms' );
		}
		return $types;
	}
	/** Return a saved Resource type. */
	private static function type( $resource_id ) { $type = sanitize_key( (string) get_post_meta( absint( $resource_id ), self::META_TYPE, true ) ); return array_key_exists( $type, self::known_resource_types() ) ? $type : 'rich_text'; }
	/** Return a saved HTTPS external link. */
	private static function external_url( $resource_id ) { return esc_url_raw( (string) get_post_meta( absint( $resource_id ), self::META_EXTERNAL_URL, true ), array( 'https' ) ); }
	/** Supported categorisations for external resource links. */
	private static function external_kinds() { return array( 'video', 'website', 'document', 'other' ); }
	/** Return a valid saved external link categorisation. */
	private static function external_kind( $resource_id ) { $kind = sanitize_key( (string) get_post_meta( absint( $resource_id ), self::META_EXTERNAL_KIND, true ) ); return in_array( $kind, self::external_kinds(), true ) ? $kind : 'website'; }
	/** Return a resource's declared content origin. */
	private static function origin( $resource_id ) { return 'third_party' === get_post_meta( absint( $resource_id ), self::META_ORIGIN, true ) ? 'third_party' : 'tutor'; }
	/** Return whether third-party content has been affirmatively confirmed. */
	private static function third_party_confirmed( $resource_id ) { return '1' === get_post_meta( absint( $resource_id ), self::META_THIRD_PARTY_CONFIRMED, true ); }
	/** Return an optional source / attribution record. */
	private static function attribution( $resource_id ) { return sanitize_text_field( (string) get_post_meta( absint( $resource_id ), self::META_ATTRIBUTION, true ) ); }
	/** Return an accessible resource type label. */
	private static function type_label( $resource_id ) { $type = self::type( $resource_id ); if ( 'external_link' === $type ) { return sprintf( __( 'External link · %s', 'tutorhelper-lms' ), ucfirst( self::external_kind( $resource_id ) ) ); } $types = self::known_resource_types(); return isset( $types[ $type ] ) ? $types[ $type ] : __( 'Rich text resource', 'tutorhelper-lms' ); }
	/** Return an accessible origin label. */
	private static function origin_label( $resource_id ) { return 'third_party' === self::origin( $resource_id ) ? __( 'Third party', 'tutorhelper-lms' ) : __( 'Tutor-created', 'tutorhelper-lms' ); }

	/** Render a Level/Subject multiple selector. */
	private static function render_term_picker( $field, $taxonomy, $label, $selected ) {
		$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'orderby' => 'name' ) );
		?><p><label for="<?php echo esc_attr( 'tutorhelper-lms-resource-' . $field ); ?>"><strong><?php echo esc_html( $label ); ?></strong></label><select id="<?php echo esc_attr( 'tutorhelper-lms-resource-' . $field ); ?>" name="<?php echo esc_attr( $field ); ?>[]" multiple size="5"><?php foreach ( is_array( $terms ) ? $terms : array() as $term ) : ?><option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( in_array( $term->term_id, array_map( 'absint', (array) $selected ), true ) ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select><span class="description"><?php esc_html_e( 'Hold Ctrl (Windows) or Command (Mac) to select more than one.', 'tutorhelper-lms' ); ?></span></p><?php
	}

	/** Render a Course/Topic/Lesson multiple selector, with parent context for progressive filtering. */
	private static function render_content_picker( $field, $post_type, $label, $selected, $filter_parent_type ) {
		$items = self::content_items( $post_type );
		$selected = array_map( 'absint', (array) $selected );
		$parent_attribute = $filter_parent_type ? ' data-tutorhelper-lms-resource-filter-parent="' . esc_attr( $filter_parent_type ) . '"' : '';
		?><section class="tutorhelper-lms-resource-library__association"><h4><?php echo esc_html( $label ); ?></h4><label class="screen-reader-text" for="<?php echo esc_attr( 'tutorhelper-lms-resource-' . $field ); ?>"><?php echo esc_html( $label ); ?></label><select id="<?php echo esc_attr( 'tutorhelper-lms-resource-' . $field ); ?>" name="<?php echo esc_attr( $field ); ?>[]" multiple size="5"<?php echo $parent_attribute; ?>><?php foreach ( $items as $item ) : ?><?php $parents = $filter_parent_type ? self::parent_ids_for_child( $item->ID, $filter_parent_type, $post_type ) : array(); ?><option value="<?php echo esc_attr( $item->ID ); ?>" data-tutorhelper-lms-resource-parent-ids="<?php echo esc_attr( implode( ',', $parents ) ); ?>" <?php selected( in_array( $item->ID, $selected, true ) ); ?>><?php echo esc_html( $item->post_title ); ?></option><?php endforeach; ?></select><p class="description"><?php echo esc_html( $filter_parent_type ? __( 'This list narrows automatically as you select its parent content. Existing selections remain visible so they are never removed unexpectedly.', 'tutorhelper-lms' ) : __( 'Choose every item that should use this master Resource.', 'tutorhelper-lms' ) ); ?></p></section><?php
	}

	/** Replace associations for one parent type without touching any other relationship type. */
	private static function replace_associations( $resource_id, $parent_type, $parent_ids ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$wpdb->delete( $table, array( 'parent_type' => $parent_type, 'child_type' => self::POST_TYPE, 'child_id' => absint( $resource_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Replaces one Resource's associations of a single parent type.
		foreach ( array_values( $parent_ids ) as $index => $parent_id ) {
			if ( $parent_type !== get_post_type( $parent_id ) ) { continue; }
			$wpdb->insert( $table, array( 'parent_type' => $parent_type, 'parent_id' => absint( $parent_id ), 'child_type' => self::POST_TYPE, 'child_id' => absint( $resource_id ), 'sort_order' => $index + 1, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds an explicit reusable Resource relationship.
		}
	}

	/** Return parent IDs that currently use one Resource. */
	private static function associated_parent_ids( $resource_id, $parent_type ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT parent_id FROM {$table} WHERE parent_type = %s AND child_type = %s AND child_id = %d ORDER BY sort_order ASC, id ASC", $parent_type, self::POST_TYPE, absint( $resource_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads explicit reusable Resource relationships.
		return array_map( 'absint', is_array( $ids ) ? $ids : array() );
	}

	/** Return parents of one reusable child content record. */
	private static function parent_ids_for_child( $child_id, $parent_type, $child_type ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT parent_id FROM {$table} WHERE parent_type = %s AND child_type = %s AND child_id = %d ORDER BY sort_order ASC, id ASC", $parent_type, $child_type, absint( $child_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads existing Course/Topic hierarchy for a progressive editor control.
		return array_map( 'absint', is_array( $ids ) ? $ids : array() );
	}

	/** Return whether a Resource remains associated to academic content. */
	private static function has_associations( $resource_id ) {
		return (bool) ( self::associated_parent_ids( $resource_id, 'tutorhelper_course' ) || self::associated_parent_ids( $resource_id, 'tutorhelper_topic' ) || self::associated_parent_ids( $resource_id, 'tutorhelper_lesson' ) );
	}

	/** Summarise academic relationships in a table cell. */
	private static function link_summary( $resource_id ) {
		$parts = array();
		foreach ( array( 'tutorhelper_course' => __( 'Course', 'tutorhelper-lms' ), 'tutorhelper_topic' => __( 'Topic', 'tutorhelper-lms' ), 'tutorhelper_lesson' => __( 'Lesson', 'tutorhelper-lms' ) ) as $type => $label ) {
			$count = count( self::associated_parent_ids( $resource_id, $type ) );
			if ( $count ) { $parts[] = sprintf( _n( '%1$d %2$s', '%1$d %2$ss', $count, 'tutorhelper-lms' ), $count, $label ); }
		}
		return $parts ? implode( ', ', $parts ) : __( 'Not linked yet', 'tutorhelper-lms' );
	}

	/** Render one filter selector. */
	private static function render_filter_select( $name, $label, $options, $selected ) {
		?><label><?php echo esc_html( $label ); ?><select name="<?php echo esc_attr( $name ); ?>"><?php foreach ( $options as $value => $option_label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( (string) $selected, (string) $value ); ?>><?php echo esc_html( $option_label ); ?></option><?php endforeach; ?></select></label><?php
	}

	/** Return taxonomy select options. */
	private static function term_options( $taxonomy ) {
		$options = array( '' => __( 'All', 'tutorhelper-lms' ) );
		$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'orderby' => 'name' ) );
		foreach ( is_array( $terms ) ? $terms : array() as $term ) { $options[ $term->term_id ] = $term->name; }
		return $options;
	}

	/** Return Course/Topic options. */
	private static function content_options( $post_type ) {
		$options = array( '' => __( 'All', 'tutorhelper-lms' ) );
		foreach ( self::content_items( $post_type ) as $item ) { $options[ $item->ID ] = $item->post_title; }
		return $options;
	}

	/** Return reusable academic content records. */
	private static function content_items( $post_type ) { return get_posts( array( 'post_type' => $post_type, 'post_status' => array( 'publish', 'draft', 'private' ), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ); }

	/** Return an edited Resource from the current safe view request. */
	private static function edited_resource() { $id = absint( self::query_value( 'resource_edit' ) ); $post = $id ? get_post( $id ) : null; return $post && self::POST_TYPE === $post->post_type ? $post : null; }
	/** Return one GET value. */
	private static function query_value( $name ) { return isset( $_GET[ $name ] ) && ! is_array( $_GET[ $name ] ) ? wp_unslash( $_GET[ $name ] ) : ''; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only library filters.
	/** Return a posted scalar value. */
	private static function posted_value( $name ) { return isset( $_POST[ $name ] ) && ! is_array( $_POST[ $name ] ) ? trim( (string) wp_unslash( $_POST[ $name ] ) ) : ''; } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Save action validates its nonce before use.
	/** Return posted IDs. */
	private static function posted_ids( $name ) { return isset( $_POST[ $name ] ) && is_array( $_POST[ $name ] ) ? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST[ $name ] ) ) ) ) ) : array(); } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Save action validates its nonce before use.
	/** Return one posted positive ID. */
	private static function posted_id( $name ) { return absint( self::posted_value( $name ) ); }
	/** Return one posted checkbox. */
	private static function posted_bool( $name ) { return '1' === self::posted_value( $name ); }
	/** Return valid HTTPS URL only. */
	private static function sanitise_https_url( $value ) { $url = esc_url_raw( $value, array( 'https' ) ); $parts = wp_parse_url( $url ); return $url && ! empty( $parts['host'] ) && 'https' === strtolower( (string) $parts['scheme'] ) ? $url : ''; }
	/** Redirect to the Resources tab. */
	private static function redirect( $notice, $edit = 0 ) { $args = array( 'resource_notice' => sanitize_key( $notice ) ); if ( $edit ) { $args['resource_edit'] = absint( $edit ); } wp_safe_redirect( add_query_arg( $args, self::tab_url() ) ); exit; }
	/** Resources tab URL. */
	private static function tab_url() { return add_query_arg( array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => 'resources' ), admin_url( 'admin.php' ) ); }
	/** Require TutorHelper tutor capability. */
	private static function require_tutor() { if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) { wp_die( esc_html__( 'You do not have permission to manage LMS Resources.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) ); } }
	/** Log a privacy-safe error. */
	private static function log_error( $operation, $entity_id, $reason ) { if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) { TutorHelper_LMS_Diagnostics::error( 'Resource Library operation failed.', array( 'component' => 'lms', 'operation' => sanitize_key( $operation ), 'entity_id' => absint( $entity_id ), 'failure_reason' => sanitize_key( $reason ) ) ); } }
	/** Render safe user-facing notices. */
	private static function render_notice() { $notice = sanitize_key( self::query_value( 'resource_notice' ) ); $messages = array( 'resource_saved' => array( 'success', __( 'Resource saved.', 'tutorhelper-lms' ) ), 'resource_deleted' => array( 'success', __( 'Resource deleted.', 'tutorhelper-lms' ) ), 'resource_error' => array( 'error', __( 'The Resource could not be saved. Check the required fields and, for third-party content, confirm that you have the appropriate permission.', 'tutorhelper-lms' ) ), 'resource_delete_error' => array( 'error', __( 'Detach this Resource from all Courses, Topics and Lessons before deleting it.', 'tutorhelper-lms' ) ) ); if ( isset( $messages[ $notice ] ) ) { echo '<div class="notice notice-' . esc_attr( $messages[ $notice ][0] ) . ' inline"><p>' . esc_html( $messages[ $notice ][1] ) . '</p></div>'; } }
}
