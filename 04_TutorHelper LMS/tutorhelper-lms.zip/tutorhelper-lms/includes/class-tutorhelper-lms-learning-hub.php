<?php
/**
 * TutorHelper LMS Learning Hub.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides the central LMS administration page.
 */
final class TutorHelper_LMS_Learning_Hub {

	/**
	 * LMS Learning Hub page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'tutorhelper-lms-learning-hub';

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 20 );
		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' )
		);
		add_action( 'wp_ajax_tutorhelper_lms_learning_hub_tab', array( __CLASS__, 'ajax_load_tab' ) );
	}

	/**
	 * Register LMS in the shared TutorHelper admin menu.
	 *
	 * @return void
	 */
	public static function register_menu() {
		if ( ! TutorHelper_LMS_Dependency::is_available() ) {
			return;
		}

		add_submenu_page(
			TutorHelper_Admin::MENU_SLUG,
			__( 'LMS Learning Hub', 'tutorhelper-lms' ),
			__( 'Learning Hub', 'tutorhelper-lms' ),
			TutorHelper_Admin::CAPABILITY,
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Reuse the established Booking Hub stylesheet on the LMS Hub only.
	 *
	 * Core owns the shared stylesheet; LMS deliberately does not copy it.
	 *
	 * @param string $hook_suffix Current WordPress admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'tutorhelper_page_' . self::PAGE_SLUG !== $hook_suffix ) {
			return;
		}

		if (
			! defined( 'TUTORHELPER_BOOKINGS_URL' )
			|| ! defined( 'TUTORHELPER_BOOKINGS_PATH' )
		) {
			return;
		}

		$asset_path = TUTORHELPER_BOOKINGS_PATH
			. 'assets/css/booking-hub.css';

		wp_enqueue_style(
			'tutorhelper-lms-learning-hub',
			TUTORHELPER_BOOKINGS_URL . 'assets/css/booking-hub.css',
			array(),
			file_exists( $asset_path )
				? (string) filemtime( $asset_path )
				: ( defined( 'TUTORHELPER_BOOKINGS_VERSION' )
					? TUTORHELPER_BOOKINGS_VERSION
					: TUTORHELPER_LMS_VERSION )
		);

		$library_style_path = TUTORHELPER_LMS_PATH . 'assets/css/tutorhelper-lms-learning-library.css';
		wp_enqueue_style(
			'tutorhelper-lms-learning-library',
			TUTORHELPER_LMS_URL . 'assets/css/tutorhelper-lms-learning-library.css',
			array( 'tutorhelper-lms-learning-hub' ),
			file_exists( $library_style_path ) ? (string) filemtime( $library_style_path ) : TUTORHELPER_LMS_VERSION
		);
		wp_enqueue_editor();

		$script_path = TUTORHELPER_LMS_PATH . 'assets/js/tutorhelper-lms-learning-hub.js';

		wp_enqueue_script(
			'tutorhelper-lms-learning-hub',
			TUTORHELPER_LMS_URL . 'assets/js/tutorhelper-lms-learning-hub.js',
			array( 'jquery' ),
			file_exists( $script_path )
				? (string) filemtime( $script_path )
				: TUTORHELPER_LMS_VERSION,
			true
		);

		wp_localize_script(
			'tutorhelper-lms-learning-hub',
			'tutorhelperLmsLearningHub',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => 'tutorhelper_lms_learning_hub_tab',
				'nonce'   => wp_create_nonce( 'tutorhelper_lms_learning_hub_tab' ),
			)
		);
	}

	/**
	 * Load one Learning Hub tab without refreshing the surrounding screen.
	 *
	 * @return void
	 */
	public static function ajax_load_tab() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to view this LMS section.', 'tutorhelper-lms' ),
				),
				403
			);
		}

		check_ajax_referer( 'tutorhelper_lms_learning_hub_tab', 'nonce' );

		$sections = self::get_sections();
		$tab      = isset( $_POST['tab'] ) && ! is_array( $_POST['tab'] )
			? sanitize_key( wp_unslash( $_POST['tab'] ) )
			: 'overview';
		$tab      = self::get_valid_tab( $tab, $sections );
		$question_edit = isset( $_POST['question_edit'] ) && ! is_array( $_POST['question_edit'] )
			? absint( wp_unslash( $_POST['question_edit'] ) )
			: 0;
		$previous_edit = isset( $_GET['edit'] ) ? $_GET['edit'] : null;

		// Keep edit navigation within the Question Bank workspace rather than
		// forcing a complete Learning Hub page reload.
		if ( 'questions' === $tab && $question_edit ) {
			$_GET['edit'] = $question_edit;
		}

		ob_start();
		self::render_tab_workspace( $tab, $sections );
		$html = ob_get_clean();

		// wp_editor() collects TinyMCE settings for the normal page footer. This
		// endpoint returns a fragment before that footer is printed, so include its
		// bootstrap with the fragment whenever it contains a rich-text editor.
		if ( false !== strpos( $html, 'wp-editor-area' ) ) {
			ob_start();
			if ( class_exists( 'WP_Editor' ) ) {
				WP_Editor::editor_js();
			} elseif ( class_exists( '_WP_Editors' ) ) {
				_WP_Editors::editor_js();
			}
			$html .= ob_get_clean();
		}

		if ( null === $previous_edit ) {
			unset( $_GET['edit'] );
		} else {
			$_GET['edit'] = $previous_edit;
		}

		wp_send_json_success(
			array(
				'html' => $html,
				'tab'  => $tab,
			)
		);
	}

	/**
	 * Render the LMS Learning Hub.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to access the LMS Learning Hub.',
					'tutorhelper-lms'
				)
			);
		}

		$sections     = self::get_sections();
		$selected_tab = self::get_selected_tab( $sections );
		?>
		<div class="wrap tutorhelper-booking-hub tutorhelper-lms-learning-hub">
			<?php self::render_hub_heading(); ?>

			<?php self::render_summary_cards(); ?>

			<nav
				class="tutorhelper-hub-tabs"
				aria-label="<?php echo esc_attr__( 'Learning content sections', 'tutorhelper-lms' ); ?>"
			>
				<?php foreach ( $sections as $section_key => $section ) : ?>
					<?php
					$classes = array(
						'tutorhelper-hub-tabs__tab',
						'is-available',
					);

					if ( $section_key === $selected_tab ) {
						$classes[] = 'is-active';
					}
					?>
					<a
						class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"
						href="<?php echo esc_url( self::get_tab_url( $section_key ) ); ?>"
						<?php echo $section_key === $selected_tab ? 'aria-current="page"' : ''; ?>
					>
						<span
							class="dashicons <?php echo esc_attr( $section['icon'] ); ?>"
							aria-hidden="true"
						></span>
						<span><?php echo esc_html( $section['label'] ); ?></span>
					</a>
				<?php endforeach; ?>
			</nav>

			<div class="tutorhelper-hub-workspace">
				<?php self::render_tab_workspace( $selected_tab, $sections ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the shared TutorHelper Hub-style banner.
	 *
	 * @return void
	 */
	private static function render_hub_heading() {
		?>
		<header class="tutorhelper-booking-hub__heading">
			<img
				src="<?php echo esc_url( TUTORHELPER_BOOKINGS_URL . 'assets/images/tutorhelper_logo.png' ); ?>"
				class="tutorhelper-booking-hub__logo"
				alt="<?php echo esc_attr__( 'TutorHelper', 'tutorhelper-lms' ); ?>"
			/>

			<div class="tutorhelper-booking-hub__heading-content">
				<h1><?php echo esc_html__( 'TutorHelper Learning Hub', 'tutorhelper-lms' ); ?></h1>
				<p>
					<?php
					echo esc_html__(
						'Manage subjects, courses, topics, lessons and student learning.',
						'tutorhelper-lms'
					);
					?>
				</p>
			</div>
		</header>
		<?php
	}

	/**
	 * Render Learning Hub content summary cards.
	 *
	 * @return void
	 */
	private static function render_summary_cards() {
		$cards = self::get_summary_cards();
		?>
		<div class="tutorhelper-hub-summary">
			<?php foreach ( $cards as $card ) : ?>
				<a
					class="tutorhelper-hub-summary__card is-available"
					href="<?php echo esc_url( $card['url'] ); ?>"
				>
					<span
						class="dashicons <?php echo esc_attr( $card['icon'] ); ?>"
						aria-hidden="true"
					></span>

					<div class="tutorhelper-hub-summary__content">
						<div class="tutorhelper-hub-summary__value">
							<?php echo esc_html( number_format_i18n( $card['value'] ) ); ?>
						</div>

						<div class="tutorhelper-hub-summary__label">
							<?php echo esc_html( $card['label'] ); ?>
						</div>

						<?php if ( ! empty( $card['description'] ) ) : ?>
							<div class="tutorhelper-hub-summary__status">
								<?php echo esc_html( $card['description'] ); ?>
							</div>
						<?php endif; ?>
					</div>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Return Learning Hub summary cards.
	 *
	 * Student enrolment and lesson links are introduced in a later free batch.
	 * Until then these totals accurately report zero.
	 *
	 * @return array[]
	 */
	private static function get_summary_cards() {
		$enrolled_students = self::get_enrolled_student_count();
		$linked_students   = self::get_linked_student_count();

		return array(
			array(
				'label' => __( 'Subjects', 'tutorhelper-lms' ),
				'icon'  => 'dashicons-book-alt',
				'value' => self::get_term_count( 'tutorhelper_lms_subject' ),
				'url'   => self::get_tab_url( 'subjects' ),
			),
			array(
				'label'       => __( 'Courses', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-welcome-learn-more',
				'value'       => self::get_content_count( 'tutorhelper_course' ),
				'description' => sprintf(
					/* translators: %s: Number of students enrolled on courses. */
					_n(
						'%s student enrolled',
						'%s students enrolled',
						$enrolled_students,
						'tutorhelper-lms'
					),
					number_format_i18n( $enrolled_students )
				),
				'url'         => self::get_tab_url( 'courses' ),
			),
			array(
				'label' => __( 'Topics', 'tutorhelper-lms' ),
				'icon'  => 'dashicons-category',
				'value' => self::get_content_count( 'tutorhelper_topic' ),
				'url'   => self::get_tab_url( 'topics' ),
			),
			array(
				'label' => __( 'Lessons', 'tutorhelper-lms' ),
				'icon'  => 'dashicons-media-document',
				'value' => self::get_content_count( 'tutorhelper_lesson' ),
				'url'   => self::get_tab_url( 'lessons' ),
			),
			array(
				'label'       => __( 'Students', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-groups',
				'value'       => $linked_students,
				'description' => __( 'Students linked to lessons', 'tutorhelper-lms' ),
				'url'         => self::get_tab_url( 'students' ),
			),
		);
	}

	/**
	 * Return the selected Learning Hub tab.
	 *
	 * @param array $sections Available section definitions.
	 * @return string
	 */
	private static function get_selected_tab( $sections ) {
		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only tab navigation.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only tab navigation.
			: 'overview';

		return self::get_valid_tab( $tab, $sections );
	}

	/**
	 * Validate a Learning Hub tab key.
	 *
	 * @param string $tab      Candidate tab key.
	 * @param array  $sections Available section definitions.
	 * @return string
	 */
	private static function get_valid_tab( $tab, $sections ) {
		return isset( $sections[ $tab ] ) ? $tab : 'overview';
	}

	/**
	 * Return a Learning Hub tab URL.
	 *
	 * @param string $tab Tab identifier.
	 * @return string
	 */
	private static function get_tab_url( $tab ) {
		return add_query_arg(
			array(
				'page' => self::PAGE_SLUG,
				'tab'  => sanitize_key( $tab ),
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Render the selected Learning Hub content view.
	 *
	 * @param string $selected_tab Current tab.
	 * @param array  $sections     Section definitions.
	 * @return void
	 */
	private static function render_tab_workspace( $selected_tab, $sections ) {
		if ( 'overview' === $selected_tab ) {
			self::render_overview_workspace();
			return;
		}

		$section = $sections[ $selected_tab ];
		$taxonomy = isset( $section['taxonomy'] ) ? $section['taxonomy'] : '';
		$post_type = isset( $section['post_type'] ) ? $section['post_type'] : '';

		/**
		 * Allow Premium LMS to render its own Learning Hub workspace, such as
		 * Submissions, before free LMS renders a generic fallback.
		 */
		$handled = apply_filters( 'tutorhelper_lms_learning_hub_render_tab', false, $selected_tab, $sections );
		if ( $handled ) {
			return;
		}

		?>
		<section class="tutorhelper-main-section">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php echo esc_html( $section['label'] ); ?></h2>
					<p><?php echo esc_html( $section['description'] ); ?></p>
				</div>
			</header>

			<div class="tutorhelper-main-section__body">
				<?php
				if ( 'resources' === $selected_tab && class_exists( 'TutorHelper_LMS_Resource_Library' ) ) {
					TutorHelper_LMS_Resource_Library::render_section();
				} elseif ( 'questions' === $selected_tab && class_exists( 'TutorHelper_LMS_Question_Bank' ) ) {
					TutorHelper_LMS_Question_Bank::render_section();
				} elseif ( 'quizzes' === $selected_tab && class_exists( 'TutorHelper_LMS_Quiz_Builder' ) ) {
					TutorHelper_LMS_Quiz_Builder::render_section();
				} elseif ( 'grade-systems' === $selected_tab && class_exists( 'TutorHelper_LMS_Grade_Systems' ) ) {
					TutorHelper_LMS_Grade_Systems::render_section();
				} elseif ( class_exists( 'TutorHelper_LMS_Learning_Library' ) && ( '' !== $taxonomy || '' !== $post_type ) ) {
					TutorHelper_LMS_Learning_Library::render_section( $selected_tab, $section );
				} elseif ( '' !== $taxonomy ) {
					self::render_term_table( $taxonomy, $section['label'] );
				} elseif ( '' !== $post_type ) {
					self::render_content_table( $post_type, $section['label'] );
				} else {
					self::render_students_workspace();
				}
				?>
			</div>
		</section>
		<?php
	}

	/**
	 * Render the overview workspace.
	 *
	 * @return void
	 */
	private static function render_overview_workspace() {
		$essentials = self::get_library_essentials();

		if ( $essentials['complete'] ) {
			self::render_library_dashboard();
			return;
		}

		self::render_library_onboarding( $essentials );
	}

	/**
	 * Return the live onboarding state for the essential learning content.
	 *
	 * Courses are deliberately excluded: tutors can use Topics and Lessons without
	 * creating a structured course.
	 *
	 * @return array
	 */
	private static function get_library_essentials() {
		$items = array(
			'levels' => array(
				'label'  => __( 'Level', 'tutorhelper-lms' ),
				'count'  => self::get_term_count( 'tutorhelper_lms_level' ),
				'tab'    => 'levels',
				'action' => __( 'Add a Level', 'tutorhelper-lms' ),
			),
			'subjects' => array(
				'label'  => __( 'Subject', 'tutorhelper-lms' ),
				'count'  => self::get_term_count( 'tutorhelper_lms_subject' ),
				'tab'    => 'subjects',
				'action' => __( 'Add a Subject', 'tutorhelper-lms' ),
			),
			'topics' => array(
				'label'  => __( 'Topic', 'tutorhelper-lms' ),
				'count'  => self::get_content_count( 'tutorhelper_topic' ),
				'tab'    => 'topics',
				'action' => __( 'Add a Topic', 'tutorhelper-lms' ),
			),
			'lessons' => array(
				'label'  => __( 'Lesson', 'tutorhelper-lms' ),
				'count'  => self::get_content_count( 'tutorhelper_lesson' ),
				'tab'    => 'lessons',
				'action' => __( 'Add a Lesson', 'tutorhelper-lms' ),
			),
		);

		$complete = 0;
		foreach ( $items as $key => $item ) {
			$items[ $key ]['complete'] = $item['count'] > 0;
			if ( $items[ $key ]['complete'] ) {
				$complete++;
			}
		}

		return array(
			'items'     => $items,
			'completed' => $complete,
			'total'     => count( $items ),
			'complete'  => count( $items ) === $complete,
		);
	}

	/**
	 * Render the first-use learning-library guide.
	 *
	 * @param array $essentials Live essential-content state.
	 * @return void
	 */
	private static function render_library_onboarding( $essentials ) {
		?>
		<section class="tutorhelper-lms-overview" aria-labelledby="tutorhelper-lms-overview-title">
			<div class="tutorhelper-lms-overview__intro">
				<h2 id="tutorhelper-lms-overview-title"><?php echo esc_html__( 'Build your learning library', 'tutorhelper-lms' ); ?></h2>
				<p><?php echo esc_html__( 'Organise your teaching materials into subjects, topics and lessons. You can use these resources for individual tuition or combine them into structured courses.', 'tutorhelper-lms' ); ?></p>
			</div>

			<?php self::render_library_hierarchy(); ?>

			<div class="tutorhelper-lms-overview__split">
				<?php self::render_library_explainer(); ?>
				<?php self::render_setup_checklist( $essentials ); ?>
			</div>
		</section>
		<?php
	}

	/**
	 * Render an accessible visual explanation of the learning hierarchy.
	 *
	 * @return void
	 */
	private static function render_library_hierarchy() {
		?>
		<section class="tutorhelper-lms-hierarchy" aria-labelledby="tutorhelper-lms-hierarchy-title">
			<h3 id="tutorhelper-lms-hierarchy-title"><?php echo esc_html__( 'A simple way to organise your materials', 'tutorhelper-lms' ); ?></h3>
			<div class="tutorhelper-lms-hierarchy__flow">
				<div class="tutorhelper-lms-hierarchy__item">
					<span class="tutorhelper-lms-hierarchy__type"><?php echo esc_html__( 'Level', 'tutorhelper-lms' ); ?></span>
					<strong><?php echo esc_html__( 'GCSE', 'tutorhelper-lms' ); ?></strong>
				</div>
				<span class="tutorhelper-lms-hierarchy__connector" aria-hidden="true">→</span>
				<div class="tutorhelper-lms-hierarchy__item">
					<span class="tutorhelper-lms-hierarchy__type"><?php echo esc_html__( 'Subject', 'tutorhelper-lms' ); ?></span>
					<strong><?php echo esc_html__( 'Computer Science', 'tutorhelper-lms' ); ?></strong>
				</div>
				<span class="tutorhelper-lms-hierarchy__connector" aria-hidden="true">→</span>
				<div class="tutorhelper-lms-hierarchy__item is-optional">
					<span class="tutorhelper-lms-hierarchy__type"><?php echo esc_html__( 'Course', 'tutorhelper-lms' ); ?></span>
					<strong><?php echo esc_html__( 'GCSE Computer Science — Paper 1', 'tutorhelper-lms' ); ?></strong>
					<span class="tutorhelper-lms-hierarchy__optional"><?php echo esc_html__( 'Optional', 'tutorhelper-lms' ); ?></span>
				</div>
				<span class="tutorhelper-lms-hierarchy__connector" aria-hidden="true">→</span>
				<div class="tutorhelper-lms-hierarchy__item">
					<span class="tutorhelper-lms-hierarchy__type"><?php echo esc_html__( 'Topic', 'tutorhelper-lms' ); ?></span>
					<strong><?php echo esc_html__( 'Computer Hardware', 'tutorhelper-lms' ); ?></strong>
				</div>
				<span class="tutorhelper-lms-hierarchy__connector" aria-hidden="true">→</span>
				<div class="tutorhelper-lms-hierarchy__lessons">
					<span class="tutorhelper-lms-hierarchy__type"><?php echo esc_html__( 'Lessons', 'tutorhelper-lms' ); ?></span>
					<div>
						<strong><?php echo esc_html__( 'CPU Architecture', 'tutorhelper-lms' ); ?></strong>
						<span><?php echo esc_html__( '20 minutes', 'tutorhelper-lms' ); ?></span>
					</div>
					<div>
						<strong><?php echo esc_html__( 'Primary Storage', 'tutorhelper-lms' ); ?></strong>
						<span><?php echo esc_html__( '15 minutes', 'tutorhelper-lms' ); ?></span>
					</div>
				</div>
			</div>
			<p class="screen-reader-text"><?php echo esc_html__( 'Level, Subject, optional Course, Topic, then individual Lessons.', 'tutorhelper-lms' ); ?></p>
		</section>
		<?php
	}

	/**
	 * Render the concise learning-library explanation.
	 *
	 * @return void
	 */
	private static function render_library_explainer() {
		$items = array(
			array( 'title' => __( 'Levels', 'tutorhelper-lms' ), 'text' => __( 'Levels describe the stage of learning, such as KS3, GCSE or A Level. Start by adding the levels you teach.', 'tutorhelper-lms' ) ),
			array( 'title' => __( 'Subjects', 'tutorhelper-lms' ), 'text' => __( 'Subjects organise the areas you teach, such as Computer Science, Mathematics or English. A subject can be used across different levels.', 'tutorhelper-lms' ) ),
			array( 'title' => __( 'Courses — Optional', 'tutorhelper-lms' ), 'text' => __( 'A course brings together related topics and lessons into a structured programme of study. You can create courses for self-study or longer learning programmes, but you do not need a course to teach individual students.', 'tutorhelper-lms' ) ),
			array( 'title' => __( 'Topics', 'tutorhelper-lms' ), 'text' => __( 'Topics group related lessons within a subject. For example, Computer Hardware might include lessons on the CPU, memory and storage.', 'tutorhelper-lms' ) ),
			array( 'title' => __( 'Lessons', 'tutorhelper-lms' ), 'text' => __( 'Lessons are individual learning activities. Each lesson can contain explanations, images, resources and an estimated study duration. Lessons can be reused when working with different students.', 'tutorhelper-lms' ) ),
		);
		?>
		<section class="tutorhelper-lms-overview__panel" aria-labelledby="tutorhelper-lms-explainer-title">
			<h3 id="tutorhelper-lms-explainer-title"><?php echo esc_html__( 'How does your learning library work?', 'tutorhelper-lms' ); ?></h3>
			<dl class="tutorhelper-lms-explainer">
				<?php foreach ( $items as $item ) : ?>
					<div>
						<dt><?php echo esc_html( $item['title'] ); ?></dt>
						<dd><?php echo esc_html( $item['text'] ); ?></dd>
					</div>
				<?php endforeach; ?>
			</dl>
		</section>
		<?php
	}

	/**
	 * Render the live onboarding checklist.
	 *
	 * @param array $essentials Live essential-content state.
	 * @return void
	 */
	private static function render_setup_checklist( $essentials ) {
		?>
		<section class="tutorhelper-lms-overview__panel tutorhelper-lms-setup" aria-labelledby="tutorhelper-lms-setup-title">
			<h3 id="tutorhelper-lms-setup-title"><?php echo esc_html__( 'Your learning library setup', 'tutorhelper-lms' ); ?></h3>
			<p class="tutorhelper-lms-setup__progress">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: Completed essentials. 2: Total essentials. */
						__( '%1$d of %2$d essentials created', 'tutorhelper-lms' ),
						$essentials['completed'],
						$essentials['total']
					)
				);
				?>
			</p>
			<ul class="tutorhelper-lms-setup__list">
				<?php foreach ( $essentials['items'] as $item ) : ?>
					<li class="<?php echo $item['complete'] ? 'is-complete' : 'is-incomplete'; ?>">
						<span class="dashicons <?php echo $item['complete'] ? 'dashicons-yes-alt' : 'dashicons-marker'; ?>" aria-hidden="true"></span>
						<span>
							<strong>
								<?php
								echo esc_html(
									$item['complete']
										? sprintf( __( '%s created', 'tutorhelper-lms' ), $item['label'] )
										: sprintf( __( 'Create your first %s', 'tutorhelper-lms' ), $item['label'] )
								);
								?>
							</strong>
							<?php if ( $item['complete'] ) : ?>
								<span><?php echo esc_html( number_format_i18n( $item['count'] ) ); ?></span>
							<?php endif; ?>
						</span>
						<a class="button button-secondary" href="<?php echo esc_url( self::get_tab_url( $item['tab'] ) ); ?>">
							<?php echo esc_html( $item['complete'] ? sprintf( __( 'View %s', 'tutorhelper-lms' ), $item['label'] ) : $item['action'] ); ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>
		<?php
	}

	/**
	 * Render the data-backed Overview after the essentials exist.
	 *
	 * @return void
	 */
	private static function render_library_dashboard() {
		$tasks = self::get_library_tasks();
		?>
		<section class="tutorhelper-lms-overview" aria-labelledby="tutorhelper-lms-dashboard-title">
			<div class="tutorhelper-lms-overview__intro">
				<h2 id="tutorhelper-lms-dashboard-title"><?php echo esc_html__( 'Your learning library', 'tutorhelper-lms' ); ?></h2>
				<p><?php echo esc_html__( 'Your teaching resources are ready to use. Continue building lessons, organise your topics and manage how students access your learning materials.', 'tutorhelper-lms' ); ?></p>
				<div class="tutorhelper-lms-overview__actions">
					<a class="button button-primary" href="<?php echo esc_url( self::get_tab_url( 'lessons' ) ); ?>"><?php echo esc_html__( 'Add a Lesson', 'tutorhelper-lms' ); ?></a>
					<a class="button button-secondary" href="<?php echo esc_url( self::get_tab_url( 'topics' ) ); ?>"><?php echo esc_html__( 'Manage Topics', 'tutorhelper-lms' ); ?></a>
					<a class="button button-secondary" href="<?php echo esc_url( self::get_tab_url( 'courses' ) ); ?>"><?php echo esc_html__( 'View Courses', 'tutorhelper-lms' ); ?></a>
					<a class="button button-secondary" href="<?php echo esc_url( self::get_tab_url( 'students' ) ); ?>"><?php echo esc_html__( 'View Students', 'tutorhelper-lms' ); ?></a>
				</div>
			</div>

			<div class="tutorhelper-lms-overview__split">
				<section class="tutorhelper-lms-overview__panel" aria-labelledby="tutorhelper-lms-tasks-title">
					<h3 id="tutorhelper-lms-tasks-title"><?php echo esc_html__( 'Tasks to do', 'tutorhelper-lms' ); ?></h3>
					<?php if ( empty( $tasks ) ) : ?>
						<p><?php echo esc_html__( 'Everything that can be checked here is up to date.', 'tutorhelper-lms' ); ?></p>
					<?php else : ?>
						<ul class="tutorhelper-lms-task-list">
							<?php foreach ( $tasks as $task ) : ?>
								<li>
									<span><?php echo esc_html( $task['text'] ); ?></span>
									<a href="<?php echo esc_url( self::get_tab_url( $task['tab'] ) ); ?>"><?php echo esc_html( $task['action'] ); ?></a>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</section>

				<?php self::render_library_usage(); ?>
			</div>

			<details class="tutorhelper-lms-help">
				<summary><?php echo esc_html__( 'How does the learning library work?', 'tutorhelper-lms' ); ?></summary>
				<?php self::render_library_hierarchy(); ?>
				<?php self::render_library_explainer(); ?>
			</details>
		</section>
		<?php
	}

	/**
	 * Return only tasks that can be calculated from the current library records.
	 *
	 * @return array
	 */
	private static function get_library_tasks() {
		$tasks = array();
		$draft_lessons = self::get_post_status_count( 'tutorhelper_lesson', 'draft' );

		if ( $draft_lessons > 0 ) {
			$tasks[] = array(
				'tab'    => 'lessons',
				'action' => __( 'Review lessons', 'tutorhelper-lms' ),
				'text'   => sprintf( _n( '%s draft lesson is waiting to be published.', '%s draft lessons are waiting to be published.', $draft_lessons, 'tutorhelper-lms' ), number_format_i18n( $draft_lessons ) ),
			);
		}

		$unlinked_lessons = self::get_unlinked_child_content_count( 'tutorhelper_lesson', 'tutorhelper_topic' );
		if ( $unlinked_lessons > 0 ) {
			$tasks[] = array(
				'tab'    => 'lessons',
				'action' => __( 'Manage lessons', 'tutorhelper-lms' ),
				'text'   => sprintf( _n( '%s lesson is not assigned to a topic.', '%s lessons are not assigned to a topic.', $unlinked_lessons, 'tutorhelper-lms' ), number_format_i18n( $unlinked_lessons ) ),
			);
		}

		$topics_without_lessons = self::get_unlinked_content_count( 'tutorhelper_topic', 'tutorhelper_lesson' );
		if ( $topics_without_lessons > 0 ) {
			$tasks[] = array(
				'tab'    => 'topics',
				'action' => __( 'Manage topics', 'tutorhelper-lms' ),
				'text'   => sprintf( _n( '%s topic has no lessons.', '%s topics have no lessons.', $topics_without_lessons, 'tutorhelper-lms' ), number_format_i18n( $topics_without_lessons ) ),
			);
		}

		$courses_without_topics = self::get_unlinked_content_count( 'tutorhelper_course', 'tutorhelper_topic' );
		if ( $courses_without_topics > 0 ) {
			$tasks[] = array(
				'tab'    => 'courses',
				'action' => __( 'Manage courses', 'tutorhelper-lms' ),
				'text'   => sprintf( _n( '%s course has no topics.', '%s courses have no topics.', $courses_without_topics, 'tutorhelper-lms' ), number_format_i18n( $courses_without_topics ) ),
			);
		}

		return $tasks;
	}

	/**
	 * Render compact, currently reliable library usage information.
	 *
	 * @return void
	 */
	private static function render_library_usage() {
		$published = self::get_post_status_count( 'tutorhelper_lesson', 'publish' );
		$draft     = self::get_post_status_count( 'tutorhelper_lesson', 'draft' );
		$recent    = get_posts(
			array(
				'post_type'      => 'tutorhelper_lesson',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => 4,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);
		?>
		<section class="tutorhelper-lms-overview__panel" aria-labelledby="tutorhelper-lms-usage-title">
			<h3 id="tutorhelper-lms-usage-title"><?php echo esc_html__( 'Library usage', 'tutorhelper-lms' ); ?></h3>
			<p class="tutorhelper-lms-usage__summary">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: Published lessons. 2: Draft lessons. */
						__( '%1$d published lessons and %2$d draft lessons.', 'tutorhelper-lms' ),
						$published,
						$draft
					)
				);
				?>
			</p>
			<?php if ( ! empty( $recent ) ) : ?>
				<h4><?php echo esc_html__( 'Recently updated lessons', 'tutorhelper-lms' ); ?></h4>
				<ul class="tutorhelper-lms-recent-list">
					<?php foreach ( $recent as $lesson ) : ?>
						<li>
							<strong><?php echo esc_html( get_the_title( $lesson ) ); ?></strong>
							<span><?php echo esc_html( get_the_modified_date( get_option( 'date_format' ), $lesson ) ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</section>
		<?php
	}

	/**
	 * Count active content records not used as a parent in a relationship.
	 *
	 * @param string $parent_type Parent post type.
	 * @param string $child_type  Expected child post type.
	 * @return int
	 */
	private static function get_unlinked_content_count( $parent_type, $child_type ) {
		global $wpdb;

		if ( ! class_exists( 'TutorHelper_LMS_Free_Database' ) ) {
			return 0;
		}

		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		if ( $table !== $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
			return 0;
		}

		$post_ids = get_posts(
			array(
				'post_type'      => $parent_type,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		if ( empty( $post_ids ) ) {
			return 0;
		}

		$linked_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT parent_id FROM {$table} WHERE parent_type = %s AND child_type = %s",
				$parent_type,
				$child_type
			)
		);

		return count( array_diff( array_map( 'absint', $post_ids ), array_map( 'absint', $linked_ids ) ) );
	}


	/**
	 * Count active content records not used as a child in a relationship.
	 *
	 * @param string $child_type  Child post type.
	 * @param string $parent_type Expected parent post type.
	 * @return int
	 */
	private static function get_unlinked_child_content_count( $child_type, $parent_type ) {
		global $wpdb;

		if ( ! class_exists( 'TutorHelper_LMS_Free_Database' ) ) {
			return 0;
		}

		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		if ( $table !== $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
			return 0;
		}

		$post_ids = get_posts(
			array(
				'post_type'      => $child_type,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		if ( empty( $post_ids ) ) {
			return 0;
		}

		$linked_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT child_id FROM {$table} WHERE child_type = %s AND parent_type = %s",
				$child_type,
				$parent_type
			)
		);

		return count( array_diff( array_map( 'absint', $post_ids ), array_map( 'absint', $linked_ids ) ) );
	}


	/**
	 * Return a post-type count for one status.
	 *
	 * @param string $post_type Post type.
	 * @param string $status    Post status.
	 * @return int
	 */
	private static function get_post_status_count( $post_type, $status ) {
		$counts = wp_count_posts( $post_type );

		return is_object( $counts ) && isset( $counts->{$status} ) ? absint( $counts->{$status} ) : 0;
	}

	/**
	 * Render a taxonomy list in the shared Hub workspace.
	 *
	 * @param string $taxonomy Taxonomy key.
	 * @param string $label    Singular/plural section label.
	 * @return void
	 */
	private static function render_term_table( $taxonomy, $label ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			?>
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: Learning content section name. */
						__( 'No %s have been created yet.', 'tutorhelper-lms' ),
						strtolower( $label )
					)
				);
				?>
			</p>
			<?php
			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php echo esc_html__( 'Name', 'tutorhelper-lms' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Description', 'tutorhelper-lms' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Courses', 'tutorhelper-lms' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $terms as $term ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $term->name ); ?></strong></td>
						<td><?php echo esc_html( $term->description ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $term->count ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Render a learning-content post list in the shared Hub workspace.
	 *
	 * @param string $post_type Learning content post type.
	 * @param string $label     Section label.
	 * @return void
	 */
	private static function render_content_table( $post_type, $label ) {
		$posts = get_posts(
			array(
				'post_type'      => $post_type,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		if ( empty( $posts ) ) {
			?>
			<p><?php echo esc_html( sprintf( __( 'No %s have been created yet.', 'tutorhelper-lms' ), strtolower( $label ) ) ); ?></p>
			<?php
			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php echo esc_html__( 'Title', 'tutorhelper-lms' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Status', 'tutorhelper-lms' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Last updated', 'tutorhelper-lms' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $posts as $post ) : ?>
					<tr>
						<td><strong><?php echo esc_html( get_the_title( $post ) ); ?></strong></td>
						<td><?php echo esc_html( ucwords( str_replace( '-', ' ', $post->post_status ) ) ); ?></td>
						<td><?php echo esc_html( get_the_modified_date( get_option( 'date_format' ), $post ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Render the student-learning workspace before relationships are introduced.
	 *
	 * @return void
	 */
	private static function render_students_workspace() {
		?>
		<p>
			<?php
				echo esc_html__(
					'Student enrolment and lesson links will appear here once the free learning-relationship workflow is introduced.',
					'tutorhelper-lms'
				);
			?>
		</p>
		<?php
	}

	/**
	 * Count a learning-content post type, excluding trashed and auto-draft items.
	 *
	 * @param string $post_type Learning content post type.
	 * @return int
	 */
	private static function get_content_count( $post_type ) {
		$counts = wp_count_posts( $post_type );

		if ( ! is_object( $counts ) ) {
			return 0;
		}

		$total = 0;
		foreach ( get_object_vars( $counts ) as $status => $count ) {
			if ( in_array( $status, array( 'trash', 'auto-draft', 'inherit' ), true ) ) {
				continue;
			}

			$total += absint( $count );
		}

		return $total;
	}

	/**
	 * Count all terms in a learning taxonomy.
	 *
	 * @param string $taxonomy Learning taxonomy.
	 * @return int
	 */
	private static function get_term_count( $taxonomy ) {
		$count = wp_count_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);

		return is_wp_error( $count ) ? 0 : absint( $count );
	}

	/**
	 * Return the number of enrolled students.
	 *
	 * @return int
	 */
	private static function get_enrolled_student_count() {
		return 0;
	}

	/**
	 * Return the number of unique students linked to lessons.
	 *
	 * @return int
	 */
	private static function get_linked_student_count() {
		return 0;
	}

	/**
	 * Return the free learning-content destinations.
	 *
	 * @return array[]
	 */
	private static function get_sections() {
		$sections = array(
			'overview' => array(
				'label'       => __( 'Overview', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-dashboard',
				'description' => __( 'Review your learning library.', 'tutorhelper-lms' ),
			),
			'levels' => array(
				'label'       => __( 'Levels', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-chart-bar',
				'taxonomy'    => 'tutorhelper_lms_level',
				'description' => __( 'Manage academic levels such as KS3, GCSE and A Level.', 'tutorhelper-lms' ),
			),
			'subjects' => array(
				'label'       => __( 'Subjects', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-book-alt',
				'taxonomy'    => 'tutorhelper_lms_subject',
				'description' => __( 'View subjects used by your learning content.', 'tutorhelper-lms' ),
			),
			'courses' => array(
				'label'       => __( 'Courses', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-welcome-learn-more',
				'post_type'   => 'tutorhelper_course',
				'description' => __( 'View your reusable courses.', 'tutorhelper-lms' ),
			),
			'resources' => array(
				'label'       => __( 'Resources', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-portfolio',
				'description' => __( 'Create reusable rich-text and external-link learning resources.', 'tutorhelper-lms' ),
			),
			'questions' => array(
				'label'       => __( 'Question Bank', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-editor-help',
				'description' => __( 'Create reusable automatically marked Questions for future Quizzes.', 'tutorhelper-lms' ),
			),
			'quizzes' => array(
				'label'       => __( 'Quizzes', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-forms',
				'description' => __( 'Build reusable Quizzes from published Question Bank Questions.', 'tutorhelper-lms' ),
			),
			'grade-systems' => array(
				'label'       => __( 'Grade systems', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-awards',
				'description' => __( 'Manage reusable grade labels and course-specific boundaries.', 'tutorhelper-lms' ),
			),
			'topics' => array(
				'label'       => __( 'Topics', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-category',
				'post_type'   => 'tutorhelper_topic',
				'description' => __( 'View reusable topics.', 'tutorhelper-lms' ),
			),
			'lessons' => array(
				'label'       => __( 'Lessons', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-media-document',
				'post_type'   => 'tutorhelper_lesson',
				'description' => __( 'View reusable lesson content and resources.', 'tutorhelper-lms' ),
			),
			'students' => array(
				'label'       => __( 'Students', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-groups',
				'description' => __( 'View student learning relationships.', 'tutorhelper-lms' ),
			),
		);

		return apply_filters( 'tutorhelper_lms_learning_hub_sections', $sections );
	}
}
