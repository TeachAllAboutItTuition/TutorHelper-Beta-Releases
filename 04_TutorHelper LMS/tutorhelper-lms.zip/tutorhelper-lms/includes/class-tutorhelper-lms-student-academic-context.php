<?php
/**
 * Direct student-to-course academic context.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages a student's direct academic-course associations.
 *
 * These records describe current or historic academic context. They do not
 * enrol a student into structured course delivery and they are never deleted
 * by a status change.
 */
final class TutorHelper_LMS_Student_Academic_Context {

	const SAVE_ACTION = 'tutorhelper_lms_save_student_academic_courses';
	const ENROLMENTS_ACTION = 'tutorhelper_lms_save_course_enrolments';

	/** Register safe Core extension points. */
	public static function init() {
		add_filter( 'tutorhelper_students_detail_sections', array( __CLASS__, 'add_student_section' ), 25, 2 );
		add_action( 'tutorhelper_students_detail_academic_courses', array( __CLASS__, 'render_student_section' ), 10, 2 );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save' ) );
		add_action( 'admin_post_' . self::ENROLMENTS_ACTION, array( __CLASS__, 'save_course_enrolments' ) );
		add_filter( 'tutorhelper_lms_student_academic_courses', array( __CLASS__, 'active_course_context' ), 10, 2 );
		add_action( 'tutorhelper_lms_group_course_exit', array( __CLASS__, 'record_group_course_exit' ), 10, 6 );
	}

	/** Add Academic Courses to the Core Student Details accordion. */
	public static function add_student_section( $sections, $student ) {
		if ( ! $student instanceof WP_User || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return $sections;
		}
		$sections[] = array(
			'id'          => 'academic-courses',
			'title'       => __( 'Academic Courses', 'tutorhelper-lms' ),
			'description' => __( 'Manage the courses that provide this student’s academic context.', 'tutorhelper-lms' ),
			'icon'        => 'dashicons-welcome-learn-more',
			'priority'    => 25,
			'action'      => 'tutorhelper_students_detail_academic_courses',
		);
		return $sections;
	}

	/** Render the direct-course association controls. */
	public static function render_student_section( $student ) {
		if ( ! $student instanceof WP_User || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}

		$records = self::courses_for_student( $student->ID );
		$group_courses = self::group_courses_for_student( $student->ID );
		$courses = get_posts(
			array(
				'post_type'      => 'tutorhelper_course',
				'post_status'    => 'publish',
				'numberposts'    => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'suppress_filters' => false,
			)
		);
		?>
		<?php if ( isset( $_GET['tutorhelper_lms_courses_saved'] ) ) : ?><div class="notice notice-success inline"><p><?php esc_html_e( 'Academic courses saved.', 'tutorhelper-lms' ); ?></p></div><?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form tutorhelper-lms-student-courses-form">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
			<input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student->ID ); ?>" />
			<?php wp_nonce_field( self::SAVE_ACTION . '_' . $student->ID ); ?>

			<p><?php esc_html_e( 'Academic courses can be linked directly or through a Group. Neither route enrols the student in structured course delivery.', 'tutorhelper-lms' ); ?></p>

			<?php if ( $group_courses ) : ?>
				<h4><?php esc_html_e( 'Assigned via Groups', 'tutorhelper-lms' ); ?></h4>
				<table class="widefat striped tutorhelper-student-table">
					<thead><tr><th><?php esc_html_e( 'Course', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Source', 'tutorhelper-lms' ); ?></th></tr></thead>
					<tbody><?php foreach ( $group_courses as $group_course ) : ?><tr><td><?php echo esc_html( get_the_title( $group_course['course_id'] ) ); ?></td><td><?php esc_html_e( 'Active', 'tutorhelper-lms' ); ?></td><td><?php echo esc_html( $group_course['source_label'] ); ?></td></tr><?php endforeach; ?></tbody>
				</table>
			<?php endif; ?>

			<?php if ( $records ) : ?>
				<h4><?php esc_html_e( 'Direct and retained associations', 'tutorhelper-lms' ); ?></h4>
				<table class="widefat striped tutorhelper-student-table">
					<thead><tr><th><?php esc_html_e( 'Course', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Source', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Added', 'tutorhelper-lms' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $records as $record ) : ?>
						<tr>
							<td><?php echo esc_html( get_the_title( $record->course_id ) ); ?></td>
							<td><select name="course_status[<?php echo esc_attr( absint( $record->course_id ) ); ?>]"><?php self::render_status_options( $record->status ); ?></select></td>
							<td><?php echo esc_html( self::source_label( $record ) ); ?></td>
							<td><?php echo esc_html( self::date_label( $record->enrolled_at ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="tutorhelper-student-muted"><?php esc_html_e( 'No direct academic courses have been linked yet.', 'tutorhelper-lms' ); ?></p>
			<?php endif; ?>

			<p>
				<label for="tutorhelper-lms-add-course"><strong><?php esc_html_e( 'Add academic course', 'tutorhelper-lms' ); ?></strong></label><br />
				<select id="tutorhelper-lms-add-course" name="add_course_id">
					<option value="0"><?php esc_html_e( 'Select a course', 'tutorhelper-lms' ); ?></option>
					<?php foreach ( $courses as $course ) : ?><option value="<?php echo esc_attr( $course->ID ); ?>"><?php echo esc_html( $course->post_title ); ?></option><?php endforeach; ?>
				</select>
			</p>
			<p><button type="submit" class="button button-primary tutorhelper-action-button"><?php esc_html_e( 'Save Academic Courses', 'tutorhelper-lms' ); ?></button></p>
		</form>
		<?php self::render_course_enrolments( $student ); ?>
		<?php
	}

	/**
	 * Render formal Course delivery enrolments without changing academic
	 * context or Group-derived Course associations.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	private static function render_course_enrolments( $student ) {
		$records = TutorHelper_LMS_Course_Enrolments::for_student( $student->ID );
		$courses = get_posts( array( 'post_type' => 'tutorhelper_course', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		?>
		<hr />
		<h4><?php esc_html_e( 'Structured Course enrolments', 'tutorhelper-lms' ); ?></h4>
		<p class="description"><?php esc_html_e( 'Formal Course places are separate from Academic Courses and Group links. Only active structured enrolments use capacity.', 'tutorhelper-lms' ); ?></p>
		<?php if ( isset( $_GET['tutorhelper_lms_enrolment_saved'] ) ) : ?><div class="notice notice-success inline"><p><?php esc_html_e( 'Course enrolments saved.', 'tutorhelper-lms' ); ?></p></div><?php endif; ?>
		<?php if ( isset( $_GET['tutorhelper_lms_enrolment_error'] ) ) : ?><div class="notice notice-error inline"><p><?php esc_html_e( 'The Course enrolment could not be saved. Check that the Course is running, open and has capacity.', 'tutorhelper-lms' ); ?></p></div><?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ENROLMENTS_ACTION ); ?>" />
			<input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student->ID ); ?>" />
			<?php wp_nonce_field( self::ENROLMENTS_ACTION . '_' . $student->ID ); ?>
			<?php if ( $records ) : ?><table class="widefat striped tutorhelper-student-table"><thead><tr><th><?php esc_html_e( 'Course', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Enrolled', 'tutorhelper-lms' ); ?></th></tr></thead><tbody><?php foreach ( $records as $record ) : ?><tr><td><?php echo esc_html( get_the_title( $record->course_id ) ); ?></td><td><?php if ( 'active' === $record->status ) : ?><select name="enrolment_status[<?php echo esc_attr( $record->id ); ?>]"><option value="active"><?php esc_html_e( 'Active', 'tutorhelper-lms' ); ?></option><option value="completed"><?php esc_html_e( 'Completed', 'tutorhelper-lms' ); ?></option><option value="withdrawn"><?php esc_html_e( 'Withdrawn', 'tutorhelper-lms' ); ?></option></select><?php else : echo esc_html( ucfirst( $record->status ) ); endif; ?></td><td><?php echo esc_html( self::date_label( $record->enrolled_at ) ); ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?>
			<p><label for="tutorhelper-lms-enrol-course"><strong><?php esc_html_e( 'Add structured Course enrolment', 'tutorhelper-lms' ); ?></strong></label><br /><select id="tutorhelper-lms-enrol-course" name="enrol_course_id"><option value="0"><?php esc_html_e( 'Select a Course', 'tutorhelper-lms' ); ?></option><?php foreach ( $courses as $course ) : ?><?php $places = TutorHelper_LMS_Course_Enrolments::available_places( $course->ID ); $eligible = 'running' === TutorHelper_LMS_Course_Settings::lifecycle( $course->ID ) && TutorHelper_LMS_Course_Settings::enrolments_open( $course->ID ) && ( null === $places || $places > 0 ); ?><option value="<?php echo esc_attr( $course->ID ); ?>" <?php disabled( ! $eligible ); ?>><?php echo esc_html( $course->post_title . ( $eligible ? '' : ' — ' . __( 'Unavailable', 'tutorhelper-lms' ) ) ); ?></option><?php endforeach; ?></select></p>
			<p><button type="submit" class="button button-secondary tutorhelper-action-button"><?php esc_html_e( 'Save Course enrolments', 'tutorhelper-lms' ); ?></button></p>
		</form>
		<?php
	}

	/**
	 * Save structured Course delivery enrolments separately from academic context.
	 *
	 * @return void
	 */
	public static function save_course_enrolments() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to manage Course enrolments.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$student_id = isset( $_POST['student_user_id'] ) ? absint( $_POST['student_user_id'] ) : 0;
		check_admin_referer( self::ENROLMENTS_ACTION . '_' . $student_id );
		if ( ! $student_id || ! get_user_by( 'id', $student_id ) ) {
			self::redirect_student_section( $student_id, 'tutorhelper_lms_enrolment_error' );
		}
		$statuses = isset( $_POST['enrolment_status'] ) && is_array( $_POST['enrolment_status'] ) ? wp_unslash( $_POST['enrolment_status'] ) : array();
		foreach ( $statuses as $enrolment_id => $status ) {
			$status = sanitize_key( $status );
			if ( in_array( $status, array( 'completed', 'withdrawn' ), true ) && is_numeric( $enrolment_id ) ) {
				$result = TutorHelper_LMS_Course_Enrolments::end( absint( $enrolment_id ), $status, $student_id );
				if ( is_wp_error( $result ) ) { self::redirect_student_section( $student_id, 'tutorhelper_lms_enrolment_error' ); }
			}
		}
		$course_id = isset( $_POST['enrol_course_id'] ) ? absint( $_POST['enrol_course_id'] ) : 0;
		if ( $course_id ) {
			$result = TutorHelper_LMS_Course_Enrolments::enrol( $course_id, $student_id );
			if ( is_wp_error( $result ) ) { self::redirect_student_section( $student_id, 'tutorhelper_lms_enrolment_error' ); }
		}
		self::redirect_student_section( $student_id, 'tutorhelper_lms_enrolment_saved' );
	}

	private static function redirect_student_section( $student_id, $notice ) {
		$url = wp_get_referer();
		$url = $url ? $url : admin_url( 'admin.php' );
		wp_safe_redirect( add_query_arg( sanitize_key( $notice ), '1', $url ) );
		exit;
	}

	/** Save status updates and an optional direct course link. */
	public static function save() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to manage academic courses.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$student_id = isset( $_POST['student_user_id'] ) ? absint( $_POST['student_user_id'] ) : 0;
		check_admin_referer( self::SAVE_ACTION . '_' . $student_id );

		$student = get_user_by( 'id', $student_id );
		if ( ! $student ) {
			TutorHelper_LMS_Diagnostics::error( 'Student academic course save rejected.', array( 'operation' => 'save_student_courses', 'failure_reason' => 'student_not_found' ) );
			self::redirect_back();
		}

		$statuses = isset( $_POST['course_status'] ) && is_array( $_POST['course_status'] ) ? wp_unslash( $_POST['course_status'] ) : array();
		foreach ( $statuses as $course_id => $status ) {
			self::update_status( $student_id, absint( $course_id ), $status );
		}

		$course_id = isset( $_POST['add_course_id'] ) ? absint( $_POST['add_course_id'] ) : 0;
		if ( $course_id ) {
			$result = self::add_course( $student_id, $course_id );
			if ( is_wp_error( $result ) ) {
				TutorHelper_LMS_Diagnostics::wp_error( 'Student academic course save failed.', $result, array( 'operation' => 'add_student_course', 'entity_id' => $course_id ) );
			}
		}

		self::redirect_back();
	}

	/** Return all retained direct associations for a student. */
	public static function courses_for_student( $student_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'student_courses' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE student_user_id = %d ORDER BY FIELD(status, 'active', 'completed', 'withdrawn'), enrolled_at DESC, course_id ASC", absint( $student_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads a student's retained academic context.
	}


	/** Return active Course associations currently derived from Pro Groups. */
	private static function group_courses_for_student( $student_id ) {
		if ( ! class_exists( 'TutorHelper_Pro_Groups' ) ) { return array(); }
		$items = array();
		foreach ( TutorHelper_Pro_Groups::get_student_group_courses( absint( $student_id ) ) as $context ) {
			$course_id = absint( $context['course_id'] ?? 0 );
			if ( ! $course_id || 'tutorhelper_course' !== get_post_type( $course_id ) ) { continue; }
			$names = array();
			foreach ( array_map( 'absint', $context['source_group_ids'] ?? array() ) as $group_id ) {
				$group = TutorHelper_Pro_Groups::get_by_id( $group_id );
				if ( $group ) { $names[] = $group->name; }
			}
			$items[] = array( 'course_id' => $course_id, 'source_label' => $names ? sprintf( __( 'Group: %s', 'tutorhelper-lms' ), implode( ', ', $names ) ) : __( 'Group link', 'tutorhelper-lms' ) );
		}
		return $items;
	}

	/**
	 * Retain a terminal academic association when Group membership ends.
	 *
	 * @param int    $student_id Student ID.
	 * @param int    $group_id Former Group ID.
	 * @param string $group_name Former Group name.
	 * @param array  $course_ids Course IDs from that Group.
	 * @param string $status Completed or withdrawn.
	 * @param array  $remaining_course_ids Courses still linked through other Groups.
	 */
	public static function record_group_course_exit( $student_id, $group_id, $group_name, $course_ids, $status, $remaining_course_ids ) {
		global $wpdb;
		$status = in_array( $status, array( 'completed', 'withdrawn' ), true ) ? $status : '';
		if ( ! $status ) { return; }
		$table = TutorHelper_LMS_Free_Database::table( 'student_courses' );
		$remaining = array_map( 'absint', is_array( $remaining_course_ids ) ? $remaining_course_ids : array() );
		$now = current_time( 'mysql', true );
		foreach ( array_values( array_unique( array_filter( array_map( 'absint', is_array( $course_ids ) ? $course_ids : array() ) ) ) ) as $course_id ) {
			if ( in_array( $course_id, $remaining, true ) || 'tutorhelper_course' !== get_post_type( $course_id ) ) { continue; }
			$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE student_user_id = %d AND course_id = %d LIMIT 1", absint( $student_id ), $course_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Preserves one retained association.
			if ( $existing && 'manual' === $existing->source && 'active' === $existing->status ) { continue; }
			$data = array( 'source' => 'group', 'source_group_id' => absint( $group_id ), 'source_label' => sanitize_text_field( $group_name ), 'status' => $status, 'ended_at' => $now, 'updated_at' => $now );
			if ( $existing ) {
				$wpdb->update( $table, $data, array( 'id' => absint( $existing->id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Updates retained Group history.
			} else {
				$data = array_merge( array( 'student_user_id' => absint( $student_id ), 'course_id' => $course_id, 'enrolled_at' => $now, 'created_at' => $now ), $data );
				$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds retained Group history.
			}
		}
	}


	/** Supply active direct courses to integrations such as Pro homework. */
	public static function active_course_context( $courses, $student_id ) {
		$courses = is_array( $courses ) ? $courses : array();
		foreach ( self::courses_for_student( $student_id ) as $record ) {
			if ( 'active' !== $record->status || 'tutorhelper_course' !== get_post_type( $record->course_id ) ) {
				continue;
			}
			$courses[] = array(
				'course_id'        => absint( $record->course_id ),
				'source'           => 'direct',
				'source_group_ids' => array(),
			);
		}
		return $courses;
	}

	/** Add or reactivate one direct association without deleting history. */
	private static function add_course( $student_id, $course_id ) {
		global $wpdb;
		if ( 'tutorhelper_course' !== get_post_type( $course_id ) ) {
			return new WP_Error( 'invalid_course', __( 'Select a valid LMS course.', 'tutorhelper-lms' ) );
		}
		$table = TutorHelper_LMS_Free_Database::table( 'student_courses' );
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE student_user_id = %d AND course_id = %d LIMIT 1", absint( $student_id ), absint( $course_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Resolves one direct association.
		$now = current_time( 'mysql', true );
		if ( $existing ) {
			$result = $wpdb->update( $table, array( 'status' => 'active', 'ended_at' => null, 'updated_at' => $now ), array( 'id' => absint( $existing ) ), array( '%s', '%s', '%s' ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reactivates only this association.
		} else {
			$result = $wpdb->insert( $table, array( 'student_user_id' => absint( $student_id ), 'course_id' => absint( $course_id ), 'source' => 'manual', 'status' => 'active', 'enrolled_at' => $now, 'created_at' => $now, 'updated_at' => $now ), array( '%d', '%d', '%s', '%s', '%s', '%s', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds one direct academic association.
		}
		return false === $result ? new WP_Error( 'student_course_save_failed', __( 'The academic course could not be saved.', 'tutorhelper-lms' ) ) : true;
	}

	/** Update status only for an existing direct association. */
	private static function update_status( $student_id, $course_id, $status ) {
		global $wpdb;
		$status = in_array( $status, array( 'active', 'completed', 'withdrawn' ), true ) ? $status : 'active';
		$table = TutorHelper_LMS_Free_Database::table( 'student_courses' );
		$data = array( 'status' => $status, 'updated_at' => current_time( 'mysql', true ) );
		$formats = array( '%s', '%s' );
		if ( 'active' === $status ) { $data['ended_at'] = null; $formats[] = '%s'; } else { $data['ended_at'] = current_time( 'mysql', true ); $formats[] = '%s'; }
		$wpdb->update( $table, $data, array( 'student_user_id' => absint( $student_id ), 'course_id' => absint( $course_id ) ), $formats, array( '%d', '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Retains historic association while updating status.
	}


	/** Translate a stored direct or retained association source. */
	private static function source_label( $record ) {
		if ( 'group' === $record->source ) {
			return $record->source_label ? sprintf( __( 'Former Group: %s', 'tutorhelper-lms' ), $record->source_label ) : __( 'Former Group', 'tutorhelper-lms' );
		}
		return __( 'Direct link', 'tutorhelper-lms' );
	}


	/** Output the supported statuses. */
	private static function render_status_options( $selected ) {
		$labels = array( 'active' => __( 'Active', 'tutorhelper-lms' ), 'completed' => __( 'Completed', 'tutorhelper-lms' ), 'withdrawn' => __( 'Withdrawn', 'tutorhelper-lms' ) );
		foreach ( $labels as $status => $label ) {
			printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $status ), selected( $status, $selected, false ), esc_html( $label ) );
		}
	}

	/** Format a retained association date. */
	private static function date_label( $date ) {
		$timestamp = $date ? strtotime( $date . ' UTC' ) : false;
		return $timestamp ? wp_date( get_option( 'date_format' ), $timestamp, wp_timezone() ) : '—';
	}

	/** Return safely to the Student Details screen. */
	private static function redirect_back() {
		$url = wp_get_referer();
		$url = $url ? $url : admin_url( 'admin.php' );
		wp_safe_redirect( add_query_arg( 'tutorhelper_lms_courses_saved', '1', $url ) );
		exit;
	}
}
