<?php
/**
 * Per-student, per-Course Lesson progress for formally enrolled learners.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Learner_Progress {

	const COMPLETE_ACTION = 'tutorhelper_lms_complete_lesson';

	/**
	 * Register Core-only progress handling.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'tutorhelper_lms_learner_lesson_viewed', array( __CLASS__, 'record_view' ), 10, 4 );
		add_action( 'tutorhelper_lms_learner_course_card', array( __CLASS__, 'render_course_card_progress' ), 10, 3 );
		add_action( 'tutorhelper_lms_learner_reader_controls', array( __CLASS__, 'render_reader_controls' ), 10, 5 );
		add_action( 'admin_post_' . self::COMPLETE_ACTION, array( __CLASS__, 'handle_complete_lesson' ) );
	}

	/**
	 * Store a non-destructive in-progress state when a formally enrolled learner
	 * opens an authorised Lesson. Individual tuition grants intentionally do not
	 * create Course completion records.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $course_id Course ID.
	 * @param int $topic_id Topic ID.
	 * @param int $lesson_id Lesson ID.
	 * @return void
	 */
	public static function record_view( $student_user_id, $course_id, $topic_id, $lesson_id ) {
		if ( ! self::is_formal_context( $student_user_id, $course_id, $topic_id, $lesson_id ) ) {
			return;
		}
		$current = self::state( $student_user_id, $course_id, $topic_id, $lesson_id );
		if ( 'complete' === ( $current['status'] ?? '' ) ) {
			return;
		}
		self::upsert( $student_user_id, $course_id, $topic_id, $lesson_id, 'in_progress' );
	}

	/**
	 * Render learner progress and a secure Resume button on a formal Course card.
	 *
	 * @param int    $course_id Course ID.
	 * @param int    $student_user_id Student user ID.
	 * @param string $base_url Student learning page URL.
	 * @return void
	 */
	public static function render_course_card_progress( $course_id, $student_user_id, $base_url ) {
		$progress = self::course_progress( $student_user_id, $course_id );
		$resume = self::resume_activity( $student_user_id, $course_id );
		?>
		<div class="tutorhelper-lms-progress" aria-label="<?php esc_attr_e( 'Course progress', 'tutorhelper-lms' ); ?>">
			<div class="tutorhelper-lms-progress__label">
				<span><?php esc_html_e( 'Course progress', 'tutorhelper-lms' ); ?></span>
				<span><?php echo esc_html( sprintf( _n( '%1$d of %2$d lesson complete', '%1$d of %2$d lessons complete', $progress['total'], 'tutorhelper-lms' ), $progress['complete'], $progress['total'] ) ); ?></span>
			</div>
			<progress value="<?php echo esc_attr( $progress['complete'] ); ?>" max="<?php echo esc_attr( max( 1, $progress['total'] ) ); ?>"><?php echo esc_html( $progress['percent'] ); ?>%</progress>
			<?php if ( $resume ) : ?>
				<?php $resume_url = 'quiz' === ( $resume['type'] ?? '' ) ? TutorHelper_LMS_Learner_Access::quiz_url( $base_url, $course_id, absint( $resume['placement_id'] ?? 0 ), $student_user_id ) : TutorHelper_LMS_Learner_Access::lesson_url( $base_url, $course_id, absint( $resume['topic_id'] ?? 0 ), absint( $resume['id'] ?? 0 ), 0, $student_user_id ); ?>
				<a class="tutorhelper-student-booking-notice__action tutorhelper-lms-progress__resume" href="<?php echo esc_url( $resume_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Resume course', 'tutorhelper-lms' ); ?><span class="screen-reader-text"> <?php esc_html_e( '(opens in a new tab)', 'tutorhelper-lms' ); ?></span></a>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render an explicit completion action inside the authorised reader.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @param int    $lesson_id Lesson ID.
	 * @param string $reader_token Opaque reader token.
	 * @param int    $page_number Current reader page number.
	 * @return void
	 */
	public static function render_reader_controls( $student_user_id, $course_id, $topic_id, $lesson_id, $reader_token, $page_number = 1, $total_pages = 1 ) {
		if ( ! self::is_formal_context( $student_user_id, $course_id, $topic_id, $lesson_id ) ) {
			return;
		}
		$state = self::state( $student_user_id, $course_id, $topic_id, $lesson_id );
		$is_final_page = absint( $page_number ) >= absint( $total_pages );
		?>
		<div class="tutorhelper-lms-textbook__progress" aria-live="polite">
			<?php if ( 'complete' === ( $state['status'] ?? '' ) ) : ?>
				<span class="tutorhelper-lms-textbook__status"><?php esc_html_e( 'Lesson complete', 'tutorhelper-lms' ); ?></span>
			<?php elseif ( ! $is_final_page ) : ?>
				<span class="tutorhelper-lms-textbook__completion-hint"><?php esc_html_e( 'Read to the final page to mark this Lesson complete.', 'tutorhelper-lms' ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render the final-page completion or onward navigation action.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @param int    $lesson_id Lesson ID.
	 * @param int    $page_number Current reader page.
	 * @param int    $total_pages Total reader pages.
	 * @param string $reader_token Opaque reader token.
	 * @param string $base_url Parent learning URL.
	 * @return void
	 */
	public static function render_navigation_action( $student_user_id, $course_id, $topic_id, $lesson_id, $page_number, $total_pages, $reader_token, $base_url ) {
		if ( ! self::is_formal_context( $student_user_id, $course_id, $topic_id, $lesson_id ) || absint( $page_number ) < absint( $total_pages ) ) {
			return;
		}
		$next = TutorHelper_LMS_Learner_Access::next_course_activity( $course_id, $topic_id, 'lesson', $lesson_id );
		if ( self::is_lesson_complete( $student_user_id, $course_id, $topic_id, $lesson_id ) ) {
			if ( $next ) {
				$url = 'quiz' === ( $next['type'] ?? '' ) ? TutorHelper_LMS_Learner_Access::quiz_url( $base_url, $course_id, absint( $next['placement_id'] ?? 0 ), $student_user_id ) : TutorHelper_LMS_Learner_Access::lesson_url( $base_url, $course_id, absint( $next['topic_id'] ?? 0 ), absint( $next['id'] ?? 0 ), 0, $student_user_id );
				echo '<a class="tutorhelper-lms-textbook__nav-button is-next" data-tutorhelper-lms-next-lesson href="' . esc_url( $url ) . '">' . esc_html__( 'Next Activity', 'tutorhelper-lms' ) . ' &rarr;</a>';
			} else {
				echo '<a class="tutorhelper-lms-textbook__nav-button is-next" href="' . esc_url( add_query_arg( TutorHelper_LMS_Learner_Access::COURSE_COMPLETE_QUERY, '1', TutorHelper_LMS_Learner_Access::course_url( $base_url, $course_id, $student_user_id ) ) ) . '">' . esc_html__( 'Finish Course', 'tutorhelper-lms' ) . ' &rarr;</a>';
			}
			return;
		}
		?>
		<form class="tutorhelper-lms-textbook__complete-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::COMPLETE_ACTION ); ?>" />
			<input type="hidden" name="reader_token" value="<?php echo esc_attr( $reader_token ); ?>" />
			<input type="hidden" name="reader_page" value="<?php echo esc_attr( absint( $page_number ) ); ?>" />
			<?php wp_nonce_field( 'tutorhelper_lms_complete_lesson_' . $reader_token ); ?>
			<button class="tutorhelper-lms-textbook__complete" type="submit"><?php esc_html_e( 'Mark lesson complete', 'tutorhelper-lms' ); ?></button>
		</form>
		<?php
	}

	/**
	 * Handle an explicit completion request and return to the same opaque reader.
	 *
	 * @return void
	 */
	public static function handle_complete_lesson() {
		$token = isset( $_POST['reader_token'] ) && ! is_array( $_POST['reader_token'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_POST['reader_token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below against this token.
		if ( ! is_user_logged_in() || ! TutorHelper_LMS_Learner_Access::is_current_student() || ! $token || ! check_admin_referer( 'tutorhelper_lms_complete_lesson_' . $token ) ) {
			wp_die( esc_html__( 'Your lesson completion request could not be verified.', 'tutorhelper-lms' ), 403 );
		}
		$context = TutorHelper_LMS_Learner_Access::context_for_current_reader_token( $token );
		$student_user_id = get_current_user_id();
		if ( ! $context || ! self::is_formal_context( $student_user_id, $context['course_id'], $context['topic_id'], $context['lesson_id'] ) ) {
			wp_die( esc_html__( 'This Lesson is no longer available.', 'tutorhelper-lms' ), 403 );
		}

		$page_number = isset( $_POST['reader_page'] ) && ! is_array( $_POST['reader_page'] ) ? absint( wp_unslash( $_POST['reader_page'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The request token nonce is verified above.
		if ( $page_number !== TutorHelper_LMS_Learner_Access::lesson_page_total( $context['lesson_id'] ) ) {
			wp_die( esc_html__( 'Please read to the final Lesson page before marking it complete.', 'tutorhelper-lms' ), 403 );
		}
		$result = self::upsert( $student_user_id, $context['course_id'], $context['topic_id'], $context['lesson_id'], 'complete' );
		$next = TutorHelper_LMS_Learner_Access::next_course_activity( $context['course_id'], $context['topic_id'], 'lesson', $context['lesson_id'] );
		$redirect = $next ? ( 'quiz' === ( $next['type'] ?? '' ) ? TutorHelper_LMS_Learner_Access::quiz_url( $context['base_url'], $context['course_id'], absint( $next['placement_id'] ?? 0 ), $student_user_id ) : TutorHelper_LMS_Learner_Access::lesson_url( $context['base_url'], $context['course_id'], absint( $next['topic_id'] ?? 0 ), absint( $next['id'] ?? 0 ), 0, $student_user_id ) ) : add_query_arg( TutorHelper_LMS_Learner_Access::COURSE_COMPLETE_QUERY, '1', TutorHelper_LMS_Learner_Access::course_url( $context['base_url'], $context['course_id'], $student_user_id ) );
		if ( is_wp_error( $result ) ) {
			$redirect = add_query_arg( 'tutorhelper_lms_progress_error', '1', $redirect );
		}
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Return progress for current published Course/Topic/Lesson contexts.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $course_id Course ID.
	 * @return array{complete:int,total:int,percent:int}
	 */
	public static function course_progress( $student_user_id, $course_id ) {
		$contexts = self::course_contexts( $course_id );
		$complete = 0;
		foreach ( $contexts as $context ) {
			$state = self::state( $student_user_id, $course_id, $context['topic_id'], $context['lesson_id'] );
			if ( 'complete' === ( $state['status'] ?? '' ) ) {
				$complete++;
			}
		}
		$total = count( $contexts );
		return array( 'complete' => $complete, 'total' => $total, 'percent' => $total ? (int) round( ( $complete / $total ) * 100 ) : 0 );
	}

	/**
	 * Return the latest in-progress eligible context, or the first incomplete
	 * Course Lesson, keeping Course ordering authoritative.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $course_id Course ID.
	 * @return array
	 */
	public static function resume_context( $student_user_id, $course_id ) {
		if ( ! TutorHelper_LMS_Learner_Access::can_view_course( $student_user_id, $course_id ) ) {
			return array();
		}
		$contexts = self::course_contexts( $course_id );
		if ( ! $contexts ) {
			return array();
		}
		$states = self::states_for_course( $student_user_id, $course_id );
		$latest = array();
		foreach ( $contexts as $context ) {
			$key = self::context_key( $context['topic_id'], $context['lesson_id'] );
			$state = $states[ $key ] ?? array();
			if ( 'in_progress' === ( $state['status'] ?? '' ) && ( empty( $latest ) || $state['last_viewed_at'] > $latest['last_viewed_at'] ) ) {
				$latest = array_merge( $context, array( 'last_viewed_at' => $state['last_viewed_at'] ) );
			}
		}
		if ( $latest ) {
			return $latest;
		}
		foreach ( $contexts as $context ) {
			$state = $states[ self::context_key( $context['topic_id'], $context['lesson_id'] ) ] ?? array();
			if ( 'complete' !== ( $state['status'] ?? '' ) ) {
				return $context;
			}
		}
		return $contexts[0];
	}

	/**
	 * Return the first incomplete activity that is currently available.
	 *
	 * This includes Quiz blockers, unlike the legacy lesson-only resume context.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $course_id Course ID.
	 * @return array
	 */
	public static function resume_activity( $student_user_id, $course_id ) {
		if ( ! TutorHelper_LMS_Learner_Access::can_view_course( $student_user_id, $course_id ) ) {
			return array();
		}
		foreach ( apply_filters( 'tutorhelper_lms_course_topics', array(), absint( $course_id ) ) as $topic ) {
			$topic_id = absint( $topic['id'] ?? 0 );
			foreach ( TutorHelper_LMS_Learner_Access::course_topic_activities( $course_id, $topic_id ) as $activity ) {
				$type = sanitize_key( $activity['type'] ?? '' );
				if ( 'lesson' === $type ) {
					if ( self::is_lesson_complete( $student_user_id, $course_id, $topic_id, absint( $activity['id'] ?? 0 ) ) || ! TutorHelper_LMS_Learner_Access::can_view_lesson( $student_user_id, $course_id, $topic_id, absint( $activity['id'] ?? 0 ) ) ) {
						continue;
					}
					return array( 'type' => 'lesson', 'topic_id' => $topic_id, 'id' => absint( $activity['id'] ?? 0 ) );
				}
				if ( 'quiz' === $type && ! self::has_completed_quiz_attempt( $student_user_id, absint( $activity['placement_id'] ?? 0 ) ) && TutorHelper_LMS_Learner_Access::can_view_quiz( $student_user_id, $course_id, absint( $activity['placement_id'] ?? 0 ) ) ) {
					return array( 'type' => 'quiz', 'topic_id' => $topic_id, 'id' => absint( $activity['id'] ?? 0 ), 'placement_id' => absint( $activity['placement_id'] ?? 0 ) );
				}
			}
		}
		return array();
	}

	/** Check whether a Quiz placement has at least one completed attempt. */
	private static function has_completed_quiz_attempt( $student_user_id, $placement_id ) {
		if ( ! class_exists( 'TutorHelper_LMS_Quiz_Attempts' ) ) {
			return false;
		}
		foreach ( TutorHelper_LMS_Quiz_Attempts::attempts_for_placement( $student_user_id, $placement_id ) as $attempt ) {
			if ( 'completed' === (string) $attempt->status ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Return the following current Course context after a completed Lesson.
	 *
	 * @return array
	 */
	public static function next_context( $course_id, $topic_id, $lesson_id ) {
		$contexts = self::course_contexts( $course_id );
		$found = false;
		foreach ( $contexts as $context ) {
			if ( $found ) {
				return $context;
			}
			if ( absint( $topic_id ) === absint( $context['topic_id'] ) && absint( $lesson_id ) === absint( $context['lesson_id'] ) ) {
				$found = true;
			}
		}
		return array();
	}

	/**
	 * Return whether this formal Course context is complete for one learner.
	 *
	 * @return bool
	 */
	public static function is_lesson_complete( $student_user_id, $course_id, $topic_id, $lesson_id ) {
		$state = self::state( $student_user_id, $course_id, $topic_id, $lesson_id );
		return 'complete' === ( $state['status'] ?? '' );
	}

	/**
	 * Safely persist a context status without deleting historic learner state.
	 *
	 * @return true|WP_Error
	 */
	private static function upsert( $student_user_id, $course_id, $topic_id, $lesson_id, $status ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'learner_lesson_state' );
		$now = current_time( 'mysql', true );
		$existing = self::state( $student_user_id, $course_id, $topic_id, $lesson_id );
		$data = array(
			'student_user_id' => absint( $student_user_id ),
			'course_id' => absint( $course_id ),
			'topic_id' => absint( $topic_id ),
			'lesson_id' => absint( $lesson_id ),
			'status' => $status,
			'last_viewed_at' => $now,
			'updated_at' => $now,
		);
		if ( 'complete' === $status ) {
			$data['completed_at'] = $now;
		}
		if ( ! $existing ) {
			$data['started_at'] = $now;
			$data['created_at'] = $now;
			$result = $wpdb->insert( $table, $data );
		} else {
			unset( $data['student_user_id'], $data['course_id'], $data['topic_id'], $data['lesson_id'] );
			$result = $wpdb->update( $table, $data, array( 'id' => absint( $existing['id'] ) ) );
		}
		if ( false === $result ) {
			if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
				TutorHelper_LMS_Diagnostics::error( 'Learner lesson progress could not be saved.', array( 'operation' => 'save_lesson_progress', 'student_user_id' => absint( $student_user_id ), 'course_id' => absint( $course_id ), 'topic_id' => absint( $topic_id ), 'lesson_id' => absint( $lesson_id ), 'db_error' => sanitize_text_field( $wpdb->last_error ) ) );
			}
			return new WP_Error( 'learner_progress_save_failed', __( 'Your lesson progress could not be saved. Please try again.', 'tutorhelper-lms' ) );
		}
		return true;
	}

	/**
	 * Return one state row, or an empty array.
	 *
	 * @return array
	 */
	private static function state( $student_user_id, $course_id, $topic_id, $lesson_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'learner_lesson_state' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE student_user_id = %d AND course_id = %d AND topic_id = %d AND lesson_id = %d LIMIT 1", absint( $student_user_id ), absint( $course_id ), absint( $topic_id ), absint( $lesson_id ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads private state for the current learner context.
		return is_array( $row ) ? $row : array();
	}

	/**
	 * Return existing state indexed by active Course context.
	 *
	 * @return array
	 */
	private static function states_for_course( $student_user_id, $course_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'learner_lesson_state' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE student_user_id = %d AND course_id = %d", absint( $student_user_id ), absint( $course_id ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads one learner's private state to find a safe resume target.
		$states = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$states[ self::context_key( $row['topic_id'], $row['lesson_id'] ) ] = $row;
		}
		return $states;
	}

	/**
	 * Return current published contexts in Course and Topic order.
	 *
	 * @return array
	 */
	private static function course_contexts( $course_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$contexts = array();
		foreach ( apply_filters( 'tutorhelper_lms_course_topics', array(), absint( $course_id ) ) as $topic ) {
			$topic_id = absint( $topic['id'] ?? 0 );
			if ( ! $topic_id ) {
				continue;
			}
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", 'tutorhelper_topic', $topic_id, 'tutorhelper_lesson' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads Course-owned ordered Lesson contexts for progress calculation.
			$activity_table = TutorHelper_LMS_Free_Database::table( 'course_topic_activities' );
			$activity_rows = $activity_table ? $wpdb->get_results( $wpdb->prepare( "SELECT activity_id, is_required FROM {$activity_table} WHERE course_id = %d AND topic_id = %d AND activity_type = %s", absint( $course_id ), $topic_id, 'lesson' ) ) : array(); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads Premium optional-activity flags without changing learner state.
			$activity_requirements = array();
			foreach ( is_array( $activity_rows ) ? $activity_rows : array() as $activity_row ) {
				$activity_requirements[ absint( $activity_row->activity_id ) ] = (bool) absint( $activity_row->is_required );
			}
			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				$lesson_id = absint( $row->child_id );
				if ( 'tutorhelper_lesson' === get_post_type( $lesson_id ) && 'publish' === get_post_status( $lesson_id ) && ( ! isset( $activity_requirements[ $lesson_id ] ) || $activity_requirements[ $lesson_id ] ) ) {
					$contexts[] = array( 'topic_id' => $topic_id, 'lesson_id' => $lesson_id );
				}
			}
		}
		return $contexts;
	}

	/**
	 * Confirm active formal Course enrolment and the current structural context.
	 *
	 * @return bool
	 */
	private static function is_formal_context( $student_user_id, $course_id, $topic_id, $lesson_id ) {
		return TutorHelper_LMS_Learner_Access::can_view_course( $student_user_id, $course_id )
			&& TutorHelper_LMS_Learner_Access::course_has_topic( $course_id, $topic_id )
			&& TutorHelper_LMS_Learner_Access::topic_has_lesson( $topic_id, $lesson_id );
	}

	/**
	 * Create a stable in-memory context lookup key.
	 *
	 * @return string
	 */
	private static function context_key( $topic_id, $lesson_id ) {
		return absint( $topic_id ) . ':' . absint( $lesson_id );
	}
}
