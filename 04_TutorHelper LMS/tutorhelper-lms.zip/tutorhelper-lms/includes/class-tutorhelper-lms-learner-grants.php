<?php
/**
 * Explicit individual-lesson sharing for TutorHelper LMS.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores auditable learner access grants without changing Course enrolment.
 */
final class TutorHelper_LMS_Learner_Grants {

	const SAVE_ACTION   = 'tutorhelper_lms_save_learner_grant';
	const REVOKE_ACTION = 'tutorhelper_lms_revoke_learner_grant';

	/**
	 * Register front-end access and tutor-management integration.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'tutorhelper_lms_learner_access', array( __CLASS__, 'add_active_grants' ), 20, 2 );
		add_filter( 'tutorhelper_lms_learner_can_view_lesson', array( __CLASS__, 'grant_allows_lesson' ), 20, 5 );
		add_action( 'tutorhelper_lms_render_learner_grants', array( __CLASS__, 'render_learner_grants' ), 20, 3 );

		if ( is_admin() ) {
			add_action( 'tutorhelper_students_detail_academic_courses', array( __CLASS__, 'render_tutor_controls' ), 30, 2 );
			add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save_grant' ) );
			add_action( 'admin_post_' . self::REVOKE_ACTION, array( __CLASS__, 'revoke_grant' ) );
		}
	}

	/**
	 * Add active individual Lesson grants to the learner access summary.
	 *
	 * @param array $access Existing access summary.
	 * @param int   $student_user_id Student user ID.
	 * @return array
	 */
	public static function add_active_grants( $access, $student_user_id ) {
		$access = is_array( $access ) ? $access : array();
		$access['grants'] = self::for_student( $student_user_id );
		return $access;
	}

	/**
	 * Allow a lesson when it is individually shared in this Course/Topic context.
	 *
	 * @param bool $allowed Existing decision.
	 * @param int  $student_user_id Student user ID.
	 * @param int  $course_id Course ID.
	 * @param int  $topic_id Topic ID.
	 * @param int  $lesson_id Lesson ID.
	 * @return bool
	 */
	public static function grant_allows_lesson( $allowed, $student_user_id, $course_id, $topic_id, $lesson_id ) {
		if ( $allowed ) {
			return true;
		}
		foreach ( self::for_student( $student_user_id ) as $grant ) {
			if ( 'lesson' === $grant['content_type'] && absint( $grant['content_id'] ) === absint( $lesson_id ) && absint( $grant['course_id'] ) === absint( $course_id ) && absint( $grant['topic_id'] ) === absint( $topic_id ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Return active grants for one student.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return array
	 */
	public static function for_student( $student_user_id ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, course_id, topic_id, content_type, content_id, source, granted_at FROM " . TutorHelper_LMS_Free_Database::table( 'learner_access_grants' ) . " WHERE student_user_id = %d AND status = %s ORDER BY granted_at DESC, id DESC",
				absint( $student_user_id ),
				'active'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Student access must reflect current tutor grants.
		$active_context_courses = self::tuition_course_context( $student_user_id );
		$grants = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! in_array( absint( $row->course_id ), $active_context_courses, true ) || 'lesson' !== $row->content_type || 'tutorhelper_lesson' !== get_post_type( $row->content_id ) || ! self::valid_context( $row->course_id, $row->topic_id, $row->content_id ) ) {
				continue;
			}
			$grants[] = array(
				'id'           => absint( $row->id ),
				'course_id'    => absint( $row->course_id ),
				'topic_id'     => absint( $row->topic_id ),
				'content_type' => 'lesson',
				'content_id'   => absint( $row->content_id ),
				'source'       => sanitize_key( $row->source ),
			);
		}
		return $grants;
	}

	/**
	 * Render individual learning cards for the student.
	 *
	 * @param array  $grants Active grants.
	 * @param int    $student_user_id Student user ID.
	 * @param string $base_url Parent page URL.
	 * @return void
	 */
	public static function render_learner_grants( $grants, $student_user_id, $base_url ) {
		$grants = is_array( $grants ) ? $grants : array();
		if ( empty( $grants ) ) {
			return;
		}
		?>
		<div class="tutorhelper-lms-learning__cards">
			<?php foreach ( $grants as $grant ) : ?>
				<article class="tutorhelper-lms-learning__card">
					<div class="tutorhelper-lms-learning__card-content">
						<p class="tutorhelper-lms-learning__eyebrow"><?php esc_html_e( 'Shared lesson', 'tutorhelper-lms' ); ?></p>
						<h4><?php echo esc_html( get_the_title( absint( $grant['content_id'] ) ) ); ?></h4>
						<p><?php echo esc_html( get_the_title( absint( $grant['course_id'] ) ) . ' · ' . get_the_title( absint( $grant['topic_id'] ) ) ); ?></p>
						<a class="tutorhelper-student-booking-notice__action" href="<?php echo esc_url( TutorHelper_LMS_Learner_Access::lesson_url( $base_url, $grant['course_id'], $grant['topic_id'], $grant['content_id'], 0, $student_user_id ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open lesson', 'tutorhelper-lms' ); ?><span class="screen-reader-text"> <?php esc_html_e( '(opens in a new tab)', 'tutorhelper-lms' ); ?></span></a>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render tutor controls in the existing Academic Courses student section.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render_tutor_controls( $student ) {
		if ( ! $student instanceof WP_User || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$contexts = self::tuition_course_context( $student->ID );
		$grants = self::for_student( $student->ID );
		$status = isset( $_GET['tutorhelper_lms_grant_saved'] ) ? 'grant_saved' : ( isset( $_GET['tutorhelper_lms_grant_revoked'] ) ? 'grant_revoked' : ( isset( $_GET['tutorhelper_lms_grant_error'] ) ? 'grant_error' : '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect notice.
		?>
		<hr />
		<section class="tutorhelper-lms-learner-grants">
			<h4><?php esc_html_e( 'Individual learning', 'tutorhelper-lms' ); ?></h4>
			<p class="description"><?php esc_html_e( 'Share a specific Lesson with this student. This does not enrol them on the full Course or use a Course place.', 'tutorhelper-lms' ); ?></p>
			<?php if ( 'grant_saved' === $status ) : ?><div class="notice notice-success inline"><p><?php esc_html_e( 'The Lesson is now shared with this student.', 'tutorhelper-lms' ); ?></p></div><?php elseif ( 'grant_revoked' === $status ) : ?><div class="notice notice-success inline"><p><?php esc_html_e( 'The Lesson is no longer shared with this student.', 'tutorhelper-lms' ); ?></p></div><?php elseif ( 'grant_error' === $status ) : ?><div class="notice notice-error inline"><p><?php esc_html_e( 'The Lesson could not be shared. Check the Course, Topic and Lesson selections and try again.', 'tutorhelper-lms' ); ?></p></div><?php endif; ?>
			<?php if ( empty( $contexts ) ) : ?>
				<p><?php esc_html_e( 'Add an active direct Academic Course or Group Course link before sharing individual learning.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
					<input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student->ID ); ?>" />
					<?php wp_nonce_field( self::SAVE_ACTION . '_' . $student->ID ); ?>
					<p><label for="tutorhelper-lms-grant-course"><strong><?php esc_html_e( 'Course context', 'tutorhelper-lms' ); ?></strong></label><br />
						<select id="tutorhelper-lms-grant-course" name="course_id" required>
							<option value=""><?php esc_html_e( 'Select a Course', 'tutorhelper-lms' ); ?></option>
							<?php foreach ( $contexts as $course_id ) : ?><option value="<?php echo esc_attr( $course_id ); ?>"><?php echo esc_html( get_the_title( $course_id ) ); ?></option><?php endforeach; ?>
						</select>
					</p>
					<p><label for="tutorhelper-lms-grant-topic"><strong><?php esc_html_e( 'Topic', 'tutorhelper-lms' ); ?></strong></label><br />
						<select id="tutorhelper-lms-grant-topic" name="topic_id" required>
							<option value=""><?php esc_html_e( 'Select a Topic', 'tutorhelper-lms' ); ?></option>
							<?php foreach ( self::topics_for_courses( $contexts ) as $topic ) : ?><option value="<?php echo esc_attr( $topic['id'] ); ?>" data-course-ids="<?php echo esc_attr( implode( ',', $topic['course_ids'] ) ); ?>"><?php echo esc_html( $topic['title'] ); ?></option><?php endforeach; ?>
						</select>
					</p>
					<p><label for="tutorhelper-lms-grant-lesson"><strong><?php esc_html_e( 'Lesson', 'tutorhelper-lms' ); ?></strong></label><br />
						<select id="tutorhelper-lms-grant-lesson" name="lesson_id" required>
							<option value=""><?php esc_html_e( 'Select a Lesson', 'tutorhelper-lms' ); ?></option>
							<?php foreach ( self::lessons_for_courses( $contexts ) as $lesson ) : ?><option value="<?php echo esc_attr( $lesson['id'] ); ?>" data-course-topic-pairs="<?php echo esc_attr( implode( ',', $lesson['contexts'] ) ); ?>"><?php echo esc_html( $lesson['title'] ); ?></option><?php endforeach; ?>
						</select>
					</p>
					<p><button type="submit" class="button button-primary tutorhelper-action-button"><?php esc_html_e( 'Share lesson', 'tutorhelper-lms' ); ?></button></p>
				</form>
				<?php self::render_filter_script(); ?>
			<?php endif; ?>

			<?php if ( $grants ) : ?>
				<table class="widefat striped tutorhelper-student-table">
					<thead><tr><th><?php esc_html_e( 'Lesson', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Course context', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Action', 'tutorhelper-lms' ); ?></th></tr></thead>
					<tbody><?php foreach ( $grants as $grant ) : ?><tr><td><?php echo esc_html( get_the_title( $grant['content_id'] ) ); ?></td><td><?php echo esc_html( get_the_title( $grant['course_id'] ) . ' · ' . get_the_title( $grant['topic_id'] ) ); ?></td><td><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="<?php echo esc_attr( self::REVOKE_ACTION ); ?>" /><input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student->ID ); ?>" /><input type="hidden" name="grant_id" value="<?php echo esc_attr( $grant['id'] ); ?>" /><?php wp_nonce_field( self::REVOKE_ACTION . '_' . $grant['id'] ); ?><button type="submit" class="button-link-delete"><?php esc_html_e( 'Stop sharing', 'tutorhelper-lms' ); ?></button></form></td></tr><?php endforeach; ?></tbody>
				</table>
			<?php endif; ?>
		</section>
		<?php
	}

	/** Save one explicit Lesson grant. */
	public static function save_grant() {
		self::require_tutor();
		$student_id = self::posted_id( 'student_user_id' );
		check_admin_referer( self::SAVE_ACTION . '_' . $student_id );
		$course_id = self::posted_id( 'course_id' );
		$topic_id = self::posted_id( 'topic_id' );
		$lesson_id = self::posted_id( 'lesson_id' );
		if ( ! self::is_valid_student_context( $student_id, $course_id ) || ! self::valid_context( $course_id, $topic_id, $lesson_id ) ) {
			self::redirect( $student_id, 'grant_error' );
		}
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'learner_access_grants' );
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE student_user_id = %d AND course_id = %d AND topic_id = %d AND content_type = %s AND content_id = %d AND status = %s LIMIT 1", $student_id, $course_id, $topic_id, 'lesson', $lesson_id, 'active' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Avoids duplicate active grants in one immutable learning context.
		if ( ! $existing ) {
			$result = $wpdb->insert( $table, array( 'student_user_id' => $student_id, 'course_id' => $course_id, 'topic_id' => $topic_id, 'content_type' => 'lesson', 'content_id' => $lesson_id, 'source' => 'tutor_share', 'status' => 'active', 'granted_at' => current_time( 'mysql', true ), 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( '%d', '%d', '%d', '%s', '%d', '%s', '%s', '%s', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Creates a deliberate, auditable learner entitlement.
			if ( false === $result ) {
				self::log_error( 'share_lesson', $lesson_id, 'grant_insert_failed' );
				self::redirect( $student_id, 'grant_error' );
			}
		}
		self::redirect( $student_id, 'grant_saved' );
	}

	/** Revoke one grant while retaining the audit record. */
	public static function revoke_grant() {
		self::require_tutor();
		$student_id = self::posted_id( 'student_user_id' );
		$grant_id = self::posted_id( 'grant_id' );
		check_admin_referer( self::REVOKE_ACTION . '_' . $grant_id );
		global $wpdb;
		$result = $wpdb->update( TutorHelper_LMS_Free_Database::table( 'learner_access_grants' ), array( 'status' => 'revoked', 'revoked_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $grant_id, 'student_user_id' => $student_id, 'status' => 'active' ), array( '%s', '%s', '%s' ), array( '%d', '%d', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Revokes one student-owned entitlement without deletion.
		if ( false === $result ) {
			self::log_error( 'revoke_lesson_share', $grant_id, 'grant_update_failed' );
			self::redirect( $student_id, 'grant_error' );
		}
		self::redirect( $student_id, 'grant_revoked' );
	}

	/** Return active direct/Group Course contexts. */
	private static function tuition_course_context( $student_id ) {
		return array_values(
			array_unique(
				array_filter(
					array_map(
						static function( $context ) {
							return absint( $context['course_id'] ?? 0 );
						},
						TutorHelper_LMS_Learner_Access::active_tuition_context( $student_id )
					)
				)
			)
		);
	}

	/** Return Topic choices and their valid Course parents. */
	private static function topics_for_courses( $course_ids ) {
		$topics = array();
		foreach ( array_map( 'absint', $course_ids ) as $course_id ) {
			foreach ( apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id ) as $topic ) {
				$topic_id = absint( $topic['id'] ?? 0 );
				if ( $topic_id ) {
					if ( ! isset( $topics[ $topic_id ] ) ) { $topics[ $topic_id ] = array( 'id' => $topic_id, 'title' => get_the_title( $topic_id ), 'course_ids' => array() ); }
					$topics[ $topic_id ]['course_ids'][] = $course_id;
				}
			}
		}
		return array_values( $topics );
	}

	/** Return Lesson choices and their valid Course/Topic contexts. */
	private static function lessons_for_courses( $course_ids ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$lessons = array();
		foreach ( self::topics_for_courses( $course_ids ) as $topic ) {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", 'tutorhelper_topic', $topic['id'], 'tutorhelper_lesson' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Lists reusable Lessons for a tutor's active Course context.
			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				$lesson_id = absint( $row->child_id );
				if ( 'tutorhelper_lesson' !== get_post_type( $lesson_id ) ) { continue; }
				if ( ! isset( $lessons[ $lesson_id ] ) ) { $lessons[ $lesson_id ] = array( 'id' => $lesson_id, 'title' => get_the_title( $lesson_id ), 'contexts' => array() ); }
				foreach ( $topic['course_ids'] as $course_id ) { $lessons[ $lesson_id ]['contexts'][] = $course_id . ':' . $topic['id']; }
			}
		}
		return array_values( $lessons );
	}

	/** Verify course, topic and lesson relationship integrity. */
	private static function valid_context( $course_id, $topic_id, $lesson_id ) {
		if ( 'tutorhelper_course' !== get_post_type( $course_id ) || 'tutorhelper_topic' !== get_post_type( $topic_id ) || 'tutorhelper_lesson' !== get_post_type( $lesson_id ) ) {
			return false;
		}
		return TutorHelper_LMS_Learner_Access::course_has_topic( $course_id, $topic_id ) && TutorHelper_LMS_Learner_Access::topic_has_lesson( $topic_id, $lesson_id );
	}

	/** Verify that this student still has the selected active tuition context. */
	private static function is_valid_student_context( $student_id, $course_id ) {
		return in_array( absint( $course_id ), self::tuition_course_context( $student_id ), true );
	}

	/** Render progressive Course/Topic/Lesson selector filtering. */
	private static function render_filter_script() {
		?>
		<script>
		(function () {
			var course = document.getElementById('tutorhelper-lms-grant-course');
			var topic = document.getElementById('tutorhelper-lms-grant-topic');
			var lesson = document.getElementById('tutorhelper-lms-grant-lesson');
			if (!course || !topic || !lesson) { return; }
			function update() {
				var courseId = course.value;
				Array.prototype.forEach.call(topic.options, function (option) {
					option.hidden = !!option.dataset.courseIds && option.dataset.courseIds.split(',').indexOf(courseId) === -1;
				});
				if (topic.selectedOptions[0] && topic.selectedOptions[0].hidden) { topic.value = ''; }
				var context = course.value + ':' + topic.value;
				Array.prototype.forEach.call(lesson.options, function (option) {
					option.hidden = !!option.dataset.courseTopicPairs && option.dataset.courseTopicPairs.split(',').indexOf(context) === -1;
				});
				if (lesson.selectedOptions[0] && lesson.selectedOptions[0].hidden) { lesson.value = ''; }
			}
			course.addEventListener('change', update);
			topic.addEventListener('change', update);
			update();
		}());
		</script>
		<?php
	}

	/** Require the established tutor capability. */
	private static function require_tutor() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to share individual learning.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
	}

	/** Return one safe submitted ID after the relevant handler verifies a nonce. */
	private static function posted_id( $field ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called only by handlers that verify their action nonce.
		$value = isset( $_POST[ $field ] ) && ! is_array( $_POST[ $field ] ) ? absint( wp_unslash( $_POST[ $field ] ) ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return $value;
	}

	/** Redirect back to Student Details with a short notice. */
	private static function redirect( $student_id, $notice ) {
		$url = wp_get_referer();
		$url = $url ? $url : admin_url( 'admin.php' );
		wp_safe_redirect( add_query_arg( 'tutorhelper_lms_' . sanitize_key( $notice ), '1', $url ) );
		exit;
	}

	/** Log privacy-safe operational failures. */
	private static function log_error( $operation, $entity_id, $reason ) {
		if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			TutorHelper_LMS_Diagnostics::error( 'Learner access grant operation failed.', array( 'component' => 'lms', 'operation' => sanitize_key( $operation ), 'entity_id' => absint( $entity_id ), 'failure_reason' => sanitize_key( $reason ) ) );
		}
	}
}
