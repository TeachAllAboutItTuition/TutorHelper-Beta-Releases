<?php
/**
 * Free LMS relationship schema.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Free_Database {

	/**
	 * Create or upgrade free-LMS relationship records.
	 *
	 * @return void
	 */
	public static function install_or_upgrade() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table( 'content_relationships' );
		$student_courses = self::table( 'student_courses' );
		$course_enrolments = self::table( 'course_enrolments' );
		$learner_access_grants = self::table( 'learner_access_grants' );
		$learner_notes = self::table( 'learner_notes' );
		$learner_annotations = self::table( 'learner_annotations' );
		$learner_lesson_state = self::table( 'learner_lesson_state' );
		$question_versions = self::table( 'question_versions' );
		$quiz_versions = self::table( 'quiz_versions' );
		$quiz_placements = self::table( 'quiz_question_placements' );
		$course_quiz_placements = self::table( 'course_quiz_placements', 'course_topic_activities', 'course_quiz_question_topics', 'quiz_attempts', 'quiz_attempt_responses' );
		$course_topic_activities = self::table( 'course_topic_activities' );
		$course_quiz_question_topics = self::table( 'course_quiz_question_topics' );
		$quiz_attempts = self::table( 'quiz_attempts' );
		$quiz_attempt_responses = self::table( 'quiz_attempt_responses' );
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL auto_increment,
			parent_type varchar(32) NOT NULL,
			parent_id bigint(20) unsigned NOT NULL,
			child_type varchar(32) NOT NULL,
			child_id bigint(20) unsigned NOT NULL,
			sort_order int(10) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY parent_child (parent_type,parent_id,child_type,child_id),
			KEY child_lookup (child_type,child_id,sort_order),
			KEY parent_lookup (parent_type,parent_id,sort_order)
		) {$charset};

		CREATE TABLE {$student_courses} (
			id bigint(20) unsigned NOT NULL auto_increment,
			student_user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			source varchar(20) NOT NULL DEFAULT 'manual',
			status varchar(20) NOT NULL DEFAULT 'active',
			source_group_id bigint(20) unsigned NOT NULL DEFAULT 0,
			source_label varchar(190) NOT NULL DEFAULT '',
			enrolled_at datetime NOT NULL,
			ended_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY student_course (student_user_id,course_id),
			KEY student_status (student_user_id,status),
			KEY source_group_id (source_group_id),
			KEY course_status (course_id,status)
		) {$charset};

		CREATE TABLE {$course_enrolments} (
			id bigint(20) unsigned NOT NULL auto_increment,
			course_id bigint(20) unsigned NOT NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			source varchar(20) NOT NULL DEFAULT 'manual',
			status varchar(20) NOT NULL DEFAULT 'active',
			active_key tinyint(3) unsigned NULL DEFAULT NULL,
			enrolled_at datetime NOT NULL,
			ended_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY active_student_course (course_id,student_user_id,active_key),
			KEY course_status (course_id,status),
			KEY student_status (student_user_id,status)
		) {$charset};

		CREATE TABLE {$learner_access_grants} (
			id bigint(20) unsigned NOT NULL auto_increment,
			student_user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			topic_id bigint(20) unsigned NOT NULL DEFAULT 0,
			content_type varchar(20) NOT NULL,
			content_id bigint(20) unsigned NOT NULL,
			source varchar(20) NOT NULL DEFAULT 'tutor_share',
			status varchar(20) NOT NULL DEFAULT 'active',
			granted_at datetime NOT NULL,
			revoked_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY student_status (student_user_id,status),
			KEY content_context (content_type,content_id,course_id,topic_id),
			KEY course_student (course_id,student_user_id,status)
		) {$charset};

		CREATE TABLE {$learner_annotations} (
			id bigint(20) unsigned NOT NULL auto_increment,
			student_user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			topic_id bigint(20) unsigned NOT NULL,
			lesson_id bigint(20) unsigned NOT NULL,
			page_key varchar(64) NOT NULL,
			annotation_type varchar(20) NOT NULL,
			start_offset int(10) unsigned NOT NULL,
			end_offset int(10) unsigned NOT NULL,
			selected_text text NOT NULL,
			note_content text NOT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY student_page (student_user_id,lesson_id,page_key),
			KEY context_page (course_id,topic_id,lesson_id,page_key)
		) {$charset};

		CREATE TABLE {$learner_lesson_state} (
			id bigint(20) unsigned NOT NULL auto_increment,
			student_user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			topic_id bigint(20) unsigned NOT NULL,
			lesson_id bigint(20) unsigned NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'not_started',
			started_at datetime NULL,
			completed_at datetime NULL,
			last_viewed_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY student_lesson_context (student_user_id,course_id,topic_id,lesson_id),
			KEY student_course_status (student_user_id,course_id,status),
			KEY course_student_status (course_id,student_user_id,status)
		) {$charset};

		CREATE TABLE {$learner_notes} (
			id bigint(20) unsigned NOT NULL auto_increment,
			student_user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			topic_id bigint(20) unsigned NOT NULL,
			lesson_id bigint(20) unsigned NOT NULL,
			page_key varchar(64) NOT NULL,
			note_content longtext NOT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY student_page_context (student_user_id,course_id,topic_id,lesson_id,page_key),
			KEY lesson_page (lesson_id,page_key),
			KEY student_lesson (student_user_id,lesson_id)
		) {$charset};

		CREATE TABLE {$question_versions} (
			id bigint(20) unsigned NOT NULL auto_increment,
			question_id bigint(20) unsigned NOT NULL,
			version_number int(10) unsigned NOT NULL,
			question_type varchar(32) NOT NULL,
			definition_json longtext NOT NULL,
			max_marks int(10) unsigned NOT NULL DEFAULT 0,
			content_fingerprint char(64) NOT NULL,
			created_by bigint(20) unsigned NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY question_version (question_id,version_number),
			KEY question_lookup (question_id,id),
			KEY fingerprint_lookup (content_fingerprint),
			KEY type_lookup (question_type)
		) {$charset};

		CREATE TABLE {$quiz_versions} (
			id bigint(20) unsigned NOT NULL auto_increment,
			quiz_id bigint(20) unsigned NOT NULL,
			version_number int(10) unsigned NOT NULL,
			definition_json longtext NOT NULL,
			total_marks int(10) unsigned NOT NULL DEFAULT 0,
			content_fingerprint char(64) NOT NULL,
			created_by bigint(20) unsigned NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY quiz_version (quiz_id,version_number),
			KEY quiz_lookup (quiz_id,id),
			KEY fingerprint_lookup (content_fingerprint)
		) {$charset};

		CREATE TABLE {$quiz_placements} (
			id bigint(20) unsigned NOT NULL auto_increment,
			quiz_version_id bigint(20) unsigned NOT NULL,
			quiz_id bigint(20) unsigned NOT NULL,
			question_id bigint(20) unsigned NOT NULL,
			question_version_id bigint(20) unsigned NOT NULL,
			sort_order int(10) unsigned NOT NULL DEFAULT 0,
			required tinyint(1) unsigned NOT NULL DEFAULT 1,
			mark_override int(10) unsigned NULL DEFAULT NULL,
			settings_json longtext NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY version_question (quiz_version_id,question_id),
			KEY version_order (quiz_version_id,sort_order),
			KEY quiz_question (quiz_id,question_id),
			KEY question_version (question_version_id)
		) {$charset};

		CREATE TABLE {$course_quiz_placements} (
			id bigint(20) unsigned NOT NULL auto_increment,
			course_id bigint(20) unsigned NOT NULL,
			topic_id bigint(20) unsigned NOT NULL,
			quiz_id bigint(20) unsigned NOT NULL,
			quiz_version_id bigint(20) unsigned NOT NULL,
			attempt_policy_override varchar(20) NOT NULL DEFAULT 'inherit',
			delivery_mode_override varchar(20) NOT NULL DEFAULT 'inherit',
			result_release_override varchar(20) NOT NULL DEFAULT 'inherit',
			pass_mark_override int(10) unsigned NULL DEFAULT NULL,
			sort_order int(10) unsigned NOT NULL DEFAULT 0,
			created_by bigint(20) unsigned NOT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY topic_quiz (topic_id,quiz_id),
			KEY course_topic_order (course_id,topic_id,sort_order),
			KEY quiz_lookup (quiz_id,quiz_version_id)
		) {$charset};

		CREATE TABLE {$course_topic_activities} (
			id bigint(20) unsigned NOT NULL auto_increment,
			course_id bigint(20) unsigned NOT NULL,
			topic_id bigint(20) unsigned NOT NULL,
			activity_type varchar(20) NOT NULL,
			activity_id bigint(20) unsigned NOT NULL,
			is_required tinyint(1) unsigned NOT NULL DEFAULT 1,
			sort_order int(10) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY topic_activity (course_id,topic_id,activity_type,activity_id),
			KEY topic_order (course_id,topic_id,sort_order)
		) {$charset};

		CREATE TABLE {$course_quiz_question_topics} (
			id bigint(20) unsigned NOT NULL auto_increment,
			course_quiz_placement_id bigint(20) unsigned NOT NULL,
			question_id bigint(20) unsigned NOT NULL,
			question_version_id bigint(20) unsigned NOT NULL,
			topic_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY placement_question (course_quiz_placement_id,question_id),
			KEY placement_topic (course_quiz_placement_id,topic_id),
			KEY question_version (question_version_id)
		) {$charset};

		CREATE TABLE {$quiz_attempts} (
			id bigint(20) unsigned NOT NULL auto_increment,
			student_user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			topic_id bigint(20) unsigned NOT NULL,
			course_quiz_placement_id bigint(20) unsigned NOT NULL,
			quiz_id bigint(20) unsigned NOT NULL,
			quiz_version_id bigint(20) unsigned NOT NULL,
			attempt_number int(10) unsigned NOT NULL DEFAULT 1,
			attempt_policy varchar(20) NOT NULL DEFAULT 'unlimited',
			status varchar(20) NOT NULL DEFAULT 'in_progress',
			snapshot_json longtext NOT NULL,
			started_at datetime NOT NULL,
			submitted_at datetime NULL,
			completed_at datetime NULL,
			time_taken_seconds int(10) unsigned NULL,
			tutor_feedback longtext NULL,
			feedback_updated_at datetime NULL,
			results_released_at datetime NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY student_placement_attempt (student_user_id,course_quiz_placement_id,attempt_number),
			KEY student_status (student_user_id,status),
			KEY course_quiz (course_id,quiz_id),
			KEY result_release (results_released_at)
		) {$charset};

		CREATE TABLE {$quiz_attempt_responses} (
			id bigint(20) unsigned NOT NULL auto_increment,
			attempt_id bigint(20) unsigned NOT NULL,
			question_id bigint(20) unsigned NOT NULL,
			question_version_id bigint(20) unsigned NOT NULL,
			response_json longtext NOT NULL,
			auto_mark_json longtext NOT NULL,
			tutor_feedback longtext NULL,
			status varchar(20) NOT NULL DEFAULT 'unanswered',
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY attempt_question (attempt_id,question_id),
			KEY attempt_status (attempt_id,status)
		) {$charset};";

		dbDelta( $sql );
		self::migrate_grade_system_post_type();
		self::migrate_existing_course_metadata();
		self::copy_page_notes_to_lesson_scope();
		update_option( 'tutorhelper_lms_free_db_version', TUTORHELPER_LMS_FREE_DB_VERSION, false );
	}

	/**
	 * Copy early LJ2c page notes into the confirmed lesson-wide note scope.
	 *
	 * Legacy page rows are intentionally retained. The migration is additive:
	 * a failed or interrupted upgrade can never remove private student notes.
	 *
	 * @return void
	 */
	private static function copy_page_notes_to_lesson_scope() {
		global $wpdb;

		$table = self::table( 'learner_notes' );
		$rows = $wpdb->get_results( "SELECT student_user_id, course_id, topic_id, lesson_id, page_key, note_content, created_at, updated_at FROM {$table} ORDER BY student_user_id ASC, course_id ASC, topic_id ASC, lesson_id ASC, created_at ASC, id ASC" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time additive preservation of student-owned notes while moving to the confirmed Lesson scope.
		$groups = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$key = absint( $row->student_user_id ) . ':' . absint( $row->course_id ) . ':' . absint( $row->topic_id ) . ':' . absint( $row->lesson_id );
			$groups[ $key ][] = $row;
		}

		foreach ( $groups as $notes ) {
			$first = $notes[0];
			$already_migrated = false;
			$content = array();
			$updated_at = $first->updated_at;
			foreach ( $notes as $note ) {
				if ( 'lesson' === $note->page_key ) {
					$already_migrated = true;
					break;
				}
				if ( '' !== trim( wp_strip_all_tags( $note->note_content ) ) ) {
					$content[] = $note->note_content;
				}
				if ( $note->updated_at > $updated_at ) {
					$updated_at = $note->updated_at;
				}
			}
			if ( $already_migrated || empty( $content ) ) {
				continue;
			}
			$wpdb->insert( $table, array(
				'student_user_id' => absint( $first->student_user_id ),
				'course_id'       => absint( $first->course_id ),
				'topic_id'        => absint( $first->topic_id ),
				'lesson_id'       => absint( $first->lesson_id ),
				'page_key'        => 'lesson',
				'note_content'    => implode( "\n\n", $content ),
				'created_at'      => $first->created_at,
				'updated_at'      => $updated_at,
			), array( '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Additive copy; legacy page notes remain intact for recovery.
		}
	}

	/**
	 * Repair the legacy Grade System post-type value where a non-strict
	 * database installation truncated the old over-length key.
	 *
	 * WordPress post types are limited to twenty characters. The original
	 * tutorhelper_grade_system key was twenty-four characters and therefore
	 * could not be registered or inserted reliably.
	 *
	 * @return void
	 */
	/**
	 * Give pre-CB1 Courses predictable metadata without changing their
	 * academic links, WordPress post status or student-facing access.
	 *
	 * @return void
	 */
	private static function migrate_existing_course_metadata() {
		$course_ids = get_posts(
			array(
				'post_type'      => 'tutorhelper_course',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		foreach ( $course_ids as $course_id ) {
			if ( '' === get_post_meta( $course_id, TutorHelper_LMS_Course_Settings::META_LIFECYCLE, true ) ) {
				$post = get_post( $course_id );
				update_post_meta( $course_id, TutorHelper_LMS_Course_Settings::META_LIFECYCLE, $post && 'publish' === $post->post_status ? 'running' : 'draft' );
			}
			if ( '' === get_post_meta( $course_id, TutorHelper_LMS_Course_Settings::META_ENROLMENTS_OPEN, true ) ) {
				update_post_meta( $course_id, TutorHelper_LMS_Course_Settings::META_ENROLMENTS_OPEN, '0' );
			}
			if ( '' === get_post_meta( $course_id, TutorHelper_LMS_Course_Settings::META_CAPACITY, true ) ) {
				update_post_meta( $course_id, TutorHelper_LMS_Course_Settings::META_CAPACITY, 0 );
			}
		}
	}

	private static function migrate_grade_system_post_type() {
		global $wpdb;

		$wpdb->update(
			$wpdb->posts,
			array( 'post_type' => 'th_lms_grade_system' ),
			array( 'post_type' => 'tutorhelper_grade_sy' ),
			array( '%s' ),
			array( '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- One-time repair of an impossible legacy post-type value.
	}

	/**
	 * Run the free-LMS migration where required.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( version_compare( (string) get_option( 'tutorhelper_lms_free_db_version', '' ), TUTORHELPER_LMS_FREE_DB_VERSION, '<' ) ) {
			self::install_or_upgrade();
		}
	}

	/**
	 * Return a known free-LMS table.
	 *
	 * @param string $name Table suffix.
	 * @return string
	 */
	public static function table( $name ) {
		global $wpdb;

		$allowed = array( 'content_relationships', 'student_courses', 'course_enrolments', 'learner_access_grants', 'learner_notes', 'learner_annotations', 'learner_lesson_state', 'question_versions', 'quiz_versions', 'quiz_question_placements', 'course_quiz_placements', 'course_topic_activities', 'course_quiz_question_topics', 'quiz_attempts', 'quiz_attempt_responses' );
		return in_array( $name, $allowed, true )
			? $wpdb->prefix . 'tutorhelper_lms_' . $name
			: '';
	}
}
