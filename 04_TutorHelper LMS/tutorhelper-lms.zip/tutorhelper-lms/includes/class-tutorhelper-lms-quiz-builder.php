<?php
/**
 * Core reusable Quiz Builder and immutable placement snapshots.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Quiz_Builder {

	const POST_TYPE            = 'tutorhelper_quiz';
	const META_CURRENT_VERSION = '_tutorhelper_lms_quiz_current_version';
	const META_STATUS          = '_tutorhelper_lms_quiz_status';
	const SAVE_ACTION          = 'tutorhelper_lms_save_quiz';
	const RELEASE_ACTION       = 'tutorhelper_lms_release_quiz_attempt';

	/**
	 * Register tutor-only Quiz Builder actions.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save_quiz' ) );
		add_action( 'admin_post_' . self::RELEASE_ACTION, array( __CLASS__, 'release_quiz_attempt' ) );
	}

	/**
	 * Render the reusable Quiz workspace.
	 *
	 * @return void
	 */
	public static function render_section() {
		self::require_tutor();

		$editing_id = isset( $_GET['edit_quiz'] ) && ! is_array( $_GET['edit_quiz'] )
			? absint( wp_unslash( $_GET['edit_quiz'] ) )
			: 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only editor selection.
		$editing = $editing_id ? get_post( $editing_id ) : null;
		if ( ! $editing || self::POST_TYPE !== $editing->post_type ) {
			$editing = null;
		}

		$current     = $editing ? self::get_current_version( $editing->ID ) : null;
		$definition  = $current ? self::decode_definition( $current->definition_json ) : self::empty_definition();
		$placements  = $current ? self::get_placements( $current->id ) : array();
		$selected    = self::selected_question_data( $placements );
		$premium_delivery = class_exists( 'TutorHelper_LMS_Premium' ) && TutorHelper_LMS_Premium::is_available();

		self::render_notice();
		?>
		<section class="tutorhelper-main-section tutorhelper-lms-quiz-builder" data-tutorhelper-lms-premium-delivery="<?php echo $premium_delivery ? '1' : '0'; ?>" aria-label="<?php esc_attr_e( 'Quiz Builder workspace', 'tutorhelper-lms' ); ?>">
			<div class="tutorhelper-main-section__body">
				<nav class="tutorhelper-lms-quiz-builder__tabs" aria-label="<?php esc_attr_e( 'Quiz workspace', 'tutorhelper-lms' ); ?>">
					<button class="is-active" type="button" data-tutorhelper-lms-quiz-tab="builder" aria-pressed="true"><?php esc_html_e( 'Quiz Builder', 'tutorhelper-lms' ); ?></button>
					<button type="button" data-tutorhelper-lms-quiz-tab="quizzes" aria-pressed="false"><?php esc_html_e( 'Current Quizzes', 'tutorhelper-lms' ); ?></button>
				</nav>

				<div data-tutorhelper-lms-quiz-panel="builder">
					<form class="tutorhelper-lms-quiz-builder__form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
						<input type="hidden" name="quiz_id" value="<?php echo esc_attr( $editing ? $editing->ID : 0 ); ?>" />
						<?php wp_nonce_field( self::SAVE_ACTION ); ?>

						<div class="tutorhelper-lms-quiz-builder__layout">
							<section class="tutorhelper-lms-quiz-builder__canvas">
								<h3><?php echo esc_html( $editing ? __( 'Edit Quiz', 'tutorhelper-lms' ) : __( 'Create Quiz', 'tutorhelper-lms' ) ); ?></h3>
								<p class="description"><?php esc_html_e( 'Build a reusable Quiz from published Questions. Drag Questions from the library into your Quiz, then drag them to set the order. Topic links are added when a Quiz is placed in a Course.', 'tutorhelper-lms' ); ?></p>
								<p>
									<label for="tutorhelper-lms-quiz-title"><strong><?php esc_html_e( 'Quiz title', 'tutorhelper-lms' ); ?></strong></label>
									<input id="tutorhelper-lms-quiz-title" class="regular-text" type="text" name="title" required value="<?php echo esc_attr( $editing ? $editing->post_title : '' ); ?>" />
								</p>
								<p>
									<label for="tutorhelper-lms-quiz-instructions"><strong><?php esc_html_e( 'Student instructions (optional)', 'tutorhelper-lms' ); ?></strong></label>
									<?php
									wp_editor(
										isset( $definition['instructions'] ) ? $definition['instructions'] : '',
										'tutorhelper-lms-quiz-instructions',
										array(
											'textarea_name' => 'instructions',
											'textarea_rows' => 5,
											'media_buttons' => false,
											'teeny'         => false,
										)
									);
									?>
									<span class="description"><?php esc_html_e( 'Shown to students when Quiz delivery is added. Do not include tutor-only marking guidance.', 'tutorhelper-lms' ); ?></span>
								</p>

								<fieldset class="tutorhelper-lms-quiz-builder__options">
									<legend><strong><?php esc_html_e( 'Quiz Options', 'tutorhelper-lms' ); ?></strong></legend>
									<div class="tutorhelper-lms-quiz-builder__options-grid">
										<div class="tutorhelper-lms-quiz-builder__option">
											<label for="tutorhelper-lms-quiz-attempt-policy"><strong><?php esc_html_e( 'Student attempts', 'tutorhelper-lms' ); ?></strong></label>
											<div class="tutorhelper-lms-quiz-builder__option-control"><select id="tutorhelper-lms-quiz-attempt-policy" name="attempt_policy">
												<option value="unlimited" <?php selected( isset( $definition['attempt_policy'] ) ? $definition['attempt_policy'] : 'unlimited', 'unlimited' ); ?>><?php esc_html_e( 'Allow unlimited completed attempts', 'tutorhelper-lms' ); ?></option>
												<option value="single" <?php selected( isset( $definition['attempt_policy'] ) ? $definition['attempt_policy'] : 'unlimited', 'single' ); ?>><?php esc_html_e( 'Allow one completed attempt', 'tutorhelper-lms' ); ?></option>
											</select><span class="tutorhelper-lms-quiz-builder__help" tabindex="0" role="img" aria-label="<?php esc_attr_e( 'A Course Topic placement can override this default for that delivery.', 'tutorhelper-lms' ); ?>"><span class="dashicons dashicons-editor-help" aria-hidden="true"></span><span class="tutorhelper-lms-quiz-builder__help-text"><?php esc_html_e( 'A Course Topic placement can override this default for that delivery.', 'tutorhelper-lms' ); ?></span></span></div>
										</div>
										<div class="tutorhelper-lms-quiz-builder__option">
											<label for="tutorhelper-lms-quiz-result-release"><strong><?php esc_html_e( 'Results and feedback', 'tutorhelper-lms' ); ?></strong></label>
											<div class="tutorhelper-lms-quiz-builder__option-control"><select id="tutorhelper-lms-quiz-result-release" name="result_release">
												<option value="immediate" <?php selected( $definition['result_release'] ?? 'immediate', 'immediate' ); ?>><?php esc_html_e( 'Show immediately', 'tutorhelper-lms' ); ?></option>
												<option value="tutor" <?php selected( $definition['result_release'] ?? 'immediate', 'tutor' ); ?>><?php esc_html_e( 'Release when I choose', 'tutorhelper-lms' ); ?></option>
											</select><span class="tutorhelper-lms-quiz-builder__help" tabindex="0" role="img" aria-label="<?php esc_attr_e( 'When held for tutor release, students can submit their Quiz but cannot see marks, answers or feedback until you release the result.', 'tutorhelper-lms' ); ?>"><span class="dashicons dashicons-editor-help" aria-hidden="true"></span><span class="tutorhelper-lms-quiz-builder__help-text"><?php esc_html_e( 'When held for tutor release, students can submit their Quiz but cannot see marks, answers or feedback until you release the result.', 'tutorhelper-lms' ); ?></span></span></div>
										</div>
										<div class="tutorhelper-lms-quiz-builder__option">
											<label for="tutorhelper-lms-quiz-pass-mark"><strong><?php esc_html_e( 'Pass mark', 'tutorhelper-lms' ); ?></strong></label>
											<div class="tutorhelper-lms-quiz-builder__option-control"><input id="tutorhelper-lms-quiz-pass-mark" type="number" min="0" step="1" name="pass_mark" required value="<?php echo esc_attr( absint( $definition['pass_mark'] ?? 0 ) ); ?>" /><span class="tutorhelper-lms-quiz-builder__help" tabindex="0" role="img" aria-label="<?php esc_attr_e( 'The number of marks needed to pass this reusable Quiz. A Course Topic placement can override it.', 'tutorhelper-lms' ); ?>"><span class="dashicons dashicons-editor-help" aria-hidden="true"></span><span class="tutorhelper-lms-quiz-builder__help-text"><?php esc_html_e( 'The number of marks needed to pass this reusable Quiz. A Course Topic placement can override it.', 'tutorhelper-lms' ); ?></span></span></div>
										</div>
										<div class="tutorhelper-lms-quiz-builder__option">
											<label for="tutorhelper-lms-quiz-pool-mode"><strong><?php esc_html_e( 'Question selection', 'tutorhelper-lms' ); ?></strong></label>
											<div class="tutorhelper-lms-quiz-builder__option-control"><select id="tutorhelper-lms-quiz-pool-mode" name="question_pool_mode">
												<option value="all" <?php selected( $definition['random_pool']['mode'] ?? 'all', 'all' ); ?>><?php esc_html_e( 'Use every Question', 'tutorhelper-lms' ); ?></option>
												<option value="random" <?php selected( $definition['random_pool']['mode'] ?? 'all', 'random' ); ?>><?php esc_html_e( 'Choose a random set for each attempt', 'tutorhelper-lms' ); ?></option>
											</select></div>
										</div>
										<div class="tutorhelper-lms-quiz-builder__option">
											<label for="tutorhelper-lms-quiz-pool-count"><strong><?php esc_html_e( 'Questions per random attempt', 'tutorhelper-lms' ); ?></strong></label>
											<div class="tutorhelper-lms-quiz-builder__option-control"><input id="tutorhelper-lms-quiz-pool-count" type="number" min="1" max="<?php echo esc_attr( max( 1, count( $selected ) ) ); ?>" step="1" name="random_question_count" value="<?php echo esc_attr( absint( $definition['random_pool']['questions_per_attempt'] ?? max( 1, count( $selected ) ) ) ); ?>" /><span class="tutorhelper-lms-quiz-builder__help" tabindex="0" role="img" aria-label="<?php esc_attr_e( 'Used only when random Question selection is chosen. The selected Question set is saved in each student attempt.', 'tutorhelper-lms' ); ?>"><span class="dashicons dashicons-editor-help" aria-hidden="true"></span><span class="tutorhelper-lms-quiz-builder__help-text"><?php esc_html_e( 'Used only when random Question selection is chosen. The selected Question set is saved in each student attempt.', 'tutorhelper-lms' ); ?></span></span></div>
										</div>

										<?php if ( $premium_delivery ) : ?>
											<div class="tutorhelper-lms-quiz-builder__option tutorhelper-lms-quiz-builder__option--premium">
												<label for="tutorhelper-lms-quiz-delivery-mode"><strong><?php esc_html_e( 'Premium student delivery', 'tutorhelper-lms' ); ?></strong></label>
												<div class="tutorhelper-lms-quiz-builder__option-control"><select id="tutorhelper-lms-quiz-delivery-mode" name="delivery_mode">
													<option value="all" <?php selected( $definition['delivery_mode'] ?? 'all', 'all' ); ?>><?php esc_html_e( 'All at once (Core default)', 'tutorhelper-lms' ); ?></option>
													<option value="question" <?php selected( $definition['delivery_mode'] ?? 'all', 'question' ); ?>><?php esc_html_e( 'Question by question', 'tutorhelper-lms' ); ?></option>
													<option value="section" <?php selected( $definition['delivery_mode'] ?? 'all', 'section' ); ?>><?php esc_html_e( 'Section by section (exam style)', 'tutorhelper-lms' ); ?></option>
												</select><span class="tutorhelper-lms-quiz-builder__help" tabindex="0" role="img" aria-label="<?php esc_attr_e( 'Question-by-question uses Learning Journey progress icons. For exam-style delivery, give consecutive Questions the same section name below.', 'tutorhelper-lms' ); ?>"><span class="dashicons dashicons-editor-help" aria-hidden="true"></span><span class="tutorhelper-lms-quiz-builder__help-text"><?php esc_html_e( 'Question-by-question uses Learning Journey progress icons. For exam-style delivery, give consecutive Questions the same section name below.', 'tutorhelper-lms' ); ?></span></span></div>
											</div>
										<?php endif; ?>
										<?php
										/**
										 * Render Premium-only Quiz modes.
										 *
										 * @param array $definition Current immutable Quiz definition.
										 * @param array $selected   Current Question-pool placements.
										 */
										do_action( 'tutorhelper_lms_quiz_builder_premium_options', $definition, $selected );
										?>
									</div>
								</fieldset>

								<fieldset class="tutorhelper-lms-quiz-builder__questions">
									<legend><strong><?php esc_html_e( 'Questions in this Quiz', 'tutorhelper-lms' ); ?></strong> <span class="tutorhelper-lms-quiz-builder__total"><?php esc_html_e( 'Total marks:', 'tutorhelper-lms' ); ?> <strong data-tutorhelper-lms-quiz-total>0</strong></span></legend>
									<p class="description"><?php esc_html_e( 'Drop Questions here, or use Add. Drag a Question to change its order. Move controls provide a keyboard alternative.', 'tutorhelper-lms' ); ?></p>
									<div class="tutorhelper-lms-quiz-builder__dropzone" data-tutorhelper-lms-quiz-canvas aria-live="polite">
										<?php foreach ( $selected as $question ) : ?>
											<?php self::render_selected_question( $question, $premium_delivery ); ?>
										<?php endforeach; ?>
									</div>
									<p class="tutorhelper-lms-quiz-builder__empty" data-tutorhelper-lms-quiz-empty <?php echo empty( $selected ) ? '' : 'hidden'; ?>><?php esc_html_e( 'Drag published Questions here to build this Quiz.', 'tutorhelper-lms' ); ?></p>
								</fieldset>

								<fieldset class="tutorhelper-lms-question-status">
									<legend><strong><?php esc_html_e( 'Quiz status', 'tutorhelper-lms' ); ?></strong></legend>
									<label><input type="radio" name="quiz_status" value="draft" <?php checked( $editing ? self::current_status( $editing->ID ) : 'draft', 'draft' ); ?> /> <?php esc_html_e( 'Save draft', 'tutorhelper-lms' ); ?></label>
									<label><input type="radio" name="quiz_status" value="published" <?php checked( $editing ? self::current_status( $editing->ID ) : 'draft', 'published' ); ?> /> <?php esc_html_e( 'Publish Quiz', 'tutorhelper-lms' ); ?></label>
									<span class="description"><?php esc_html_e( 'Publishing requires at least one published Question. Editing a Quiz will not affect a future student attempt snapshot.', 'tutorhelper-lms' ); ?></span>
								</fieldset>
								<p>
									<button class="button tutorhelper-lms-button--orange" type="submit"><?php echo esc_html( $editing ? __( 'Save Quiz', 'tutorhelper-lms' ) : __( 'Create Quiz', 'tutorhelper-lms' ) ); ?></button>
									<?php if ( $editing ) : ?><a class="button tutorhelper-lms-button--grey" href="<?php echo esc_url( self::tab_url() ); ?>"><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></a><?php endif; ?>
								</p>
							</section>

							<aside class="tutorhelper-lms-quiz-builder__library" aria-label="<?php esc_attr_e( 'Question library', 'tutorhelper-lms' ); ?>">
								<h3><?php esc_html_e( 'Question Bank', 'tutorhelper-lms' ); ?></h3>
								<label><span class="screen-reader-text"><?php esc_html_e( 'Search published Questions', 'tutorhelper-lms' ); ?></span><input class="regular-text" type="search" data-tutorhelper-lms-quiz-search placeholder="<?php esc_attr_e( 'Search Questions', 'tutorhelper-lms' ); ?>" /></label>
								<label><span class="screen-reader-text"><?php esc_html_e( 'Filter Questions by type', 'tutorhelper-lms' ); ?></span><select data-tutorhelper-lms-quiz-type><option value=""><?php esc_html_e( 'All Question types', 'tutorhelper-lms' ); ?></option><?php foreach ( TutorHelper_LMS_Question_Bank::question_types() as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
								<div class="tutorhelper-lms-quiz-builder__library-list" data-tutorhelper-lms-quiz-library>
									<?php self::render_question_library( $selected ); ?>
								</div>
							</aside>
						</div>
					</form>
					<?php if ( $editing ) : ?>
						<?php self::render_release_queue( $editing->ID ); ?>
					<?php endif; ?>
				</div>

				<div data-tutorhelper-lms-quiz-panel="quizzes" hidden>
					<?php self::render_quiz_table(); ?>
				</div>
			</div>
		</section>
		<?php
	}

	/**
	 * Save Quiz metadata and an immutable placement snapshot if it changed.
	 *
	 * @return void
	 */
	public static function save_quiz() {
		self::require_tutor();
		check_admin_referer( self::SAVE_ACTION );

		$quiz_id      = isset( $_POST['quiz_id'] ) && ! is_array( $_POST['quiz_id'] ) ? absint( wp_unslash( $_POST['quiz_id'] ) ) : 0;
		$title        = self::posted_text( 'title' );
		$instructions = self::posted_html( 'instructions' );
		$status       = self::posted_key( 'quiz_status' );
		$attempt_policy = self::posted_key( 'attempt_policy' );
		$pass_mark = isset( $_POST['pass_mark'] ) && ! is_array( $_POST['pass_mark'] ) ? absint( wp_unslash( $_POST['pass_mark'] ) ) : 0;
		$delivery_mode = self::posted_key( 'delivery_mode' );
		$result_release = self::posted_key( 'result_release' );
		$pool_mode = self::posted_key( 'question_pool_mode' );
		$random_question_count = isset( $_POST['random_question_count'] ) && ! is_array( $_POST['random_question_count'] ) ? absint( wp_unslash( $_POST['random_question_count'] ) ) : 0;
		$placements   = self::posted_placements();

		if ( '' === $title ) {
			self::redirect( add_query_arg( 'lms_quiz_error', 'missing_title', self::tab_url( $quiz_id ) ) );
		}
		if ( ! in_array( $status, array( 'draft', 'published' ), true ) ) {
			$status = 'draft';
		}
		if ( ! in_array( $attempt_policy, array( 'unlimited', 'single' ), true ) ) {
			$attempt_policy = 'unlimited';
		}
		if ( ! in_array( $delivery_mode, array( 'all', 'question', 'section' ), true ) || ! class_exists( 'TutorHelper_LMS_Premium' ) || ! TutorHelper_LMS_Premium::is_available() ) {
			$delivery_mode = 'all';
		}
		if ( ! in_array( $result_release, array( 'immediate', 'tutor' ), true ) ) {
			$result_release = 'immediate';
		}
		if ( ! in_array( $pool_mode, array( 'all', 'random' ), true ) ) {
			$pool_mode = 'all';
		}
		if ( 'random' === $pool_mode && ( $random_question_count < 1 || $random_question_count > count( $placements ) ) ) {
			self::redirect( add_query_arg( 'lms_quiz_error', 'invalid_random_question_count', self::tab_url( $quiz_id ) ) );
		}
		if ( 'published' === $status && empty( $placements ) ) {
			self::redirect( add_query_arg( 'lms_quiz_error', 'missing_questions', self::tab_url( $quiz_id ) ) );
		}

		$definition = array(
			'instructions'   => $instructions,
			'attempt_policy' => $attempt_policy,
			'pass_mark'      => $pass_mark,
			'delivery_mode'  => $delivery_mode,
			'result_release' => $result_release,
			'random_pool'    => self::normalise_random_pool( array( 'mode' => $pool_mode, 'questions_per_attempt' => $random_question_count ), count( $placements ) ),
			'placements'     => $placements,
		);
		$definition = apply_filters( 'tutorhelper_lms_quiz_definition_from_request', $definition, $placements, $quiz_id );
		if ( is_wp_error( $definition ) ) {
			self::redirect( add_query_arg( 'lms_quiz_error', sanitize_key( $definition->get_error_code() ), self::tab_url( $quiz_id ) ) );
		}
		$pass_mark = absint( $definition['pass_mark'] ?? 0 );
		$total_marks = self::placement_total_marks( $placements );
		if ( $pass_mark > $total_marks ) {
			self::redirect( add_query_arg( 'lms_quiz_error', 'invalid_pass_mark', self::tab_url( $quiz_id ) ) );
		}

		if ( $quiz_id ) {
			$existing = get_post( $quiz_id );
			if ( ! $existing || self::POST_TYPE !== $existing->post_type ) {
				self::redirect( add_query_arg( 'lms_quiz_error', 'save_failed', self::tab_url() ) );
			}
		}

		$post_data = array(
			'post_type'    => self::POST_TYPE,
			'post_title'   => $title,
			'post_content' => $instructions,
			'post_status'  => 'publish',
		);
		if ( $quiz_id ) {
			$post_data['ID'] = $quiz_id;
			$result = wp_update_post( wp_slash( $post_data ), true );
		} else {
			$result = wp_insert_post( wp_slash( $post_data ), true );
		}
		if ( is_wp_error( $result ) || ! $result ) {
			self::log_failure( $quiz_id ? 'update_quiz' : 'create_quiz', $quiz_id, is_wp_error( $result ) ? $result : null, 'post_write_failed' );
			self::redirect( add_query_arg( 'lms_quiz_error', 'save_failed', self::tab_url( $quiz_id ) ) );
		}

		$quiz_id    = absint( $result );
		$fingerprint = hash( 'sha256', wp_json_encode( self::canonical_definition( $definition ) ) );
		$current     = self::get_current_version( $quiz_id );
		if ( ! $current || $fingerprint !== (string) $current->content_fingerprint ) {
			$version_id = self::create_version( $quiz_id, $definition, $fingerprint, $current ? absint( $current->version_number ) + 1 : 1 );
			if ( ! $version_id ) {
				self::log_failure( 'create_quiz_version', $quiz_id, null, 'database_write_failed' );
				self::redirect( add_query_arg( 'lms_quiz_error', 'save_failed', self::tab_url( $quiz_id ) ) );
			}
			update_post_meta( $quiz_id, self::META_CURRENT_VERSION, $version_id );
		}

		update_post_meta( $quiz_id, self::META_STATUS, $status );
		self::redirect( add_query_arg( 'lms_quiz_updated', 'saved', self::tab_url( $quiz_id ) ) );
	}


	/**
	 * Create one immutable reusable Quiz from a reviewed import plan.
	 *
	 * @param array $record Reviewed source Quiz and resolved Question mappings.
	 * @return array|WP_Error
	 */
	public static function create_from_import( $record ) {
		$import_key = sanitize_key( $record['id'] ?? '' );
		$title = sanitize_text_field( $record['title'] ?? '' );
		if ( '' === $import_key || '' === $title ) {
			return new WP_Error( 'missing_import_quiz_details', __( 'The imported Quiz needs a title and stable source key.', 'tutorhelper-lms' ) );
		}
		$existing = get_posts( array( 'post_type' => self::POST_TYPE, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_tutorhelper_lms_import_key', 'meta_value' => $import_key ) );
		if ( ! empty( $existing ) ) {
			$quiz_id = absint( $existing[0] );
			return array( 'quiz_id' => $quiz_id, 'created' => false, 'status' => self::current_status( $quiz_id ) );
		}
		$placements = array();
		$seen_questions = array();
		foreach ( (array) ( $record['question_mappings'] ?? array() ) as $index => $mapping ) {
			$question_id = absint( $mapping['question_id'] ?? 0 );
			$version_id = absint( $mapping['question_version_id'] ?? 0 );
			if ( ! $question_id || ! $version_id || isset( $seen_questions[ $question_id ] ) || TutorHelper_LMS_Question_Bank::POST_TYPE !== get_post_type( $question_id ) || 'published' !== get_post_meta( $question_id, TutorHelper_LMS_Question_Bank::META_STATUS, true ) || ! self::question_version_belongs_to( $version_id, $question_id ) ) {
				return new WP_Error( 'import_quiz_question_unavailable', __( 'Every imported Quiz Question must be a current published Question before the Quiz can be created.', 'tutorhelper-lms' ) );
			}
			$seen_questions[ $question_id ] = true;
			$placements[] = array( 'question_id' => $question_id, 'question_version_id' => $version_id, 'sort_order' => $index + 1, 'section' => '' );
		}
		if ( empty( $placements ) ) {
			return new WP_Error( 'import_quiz_missing_questions', __( 'This imported Quiz has no reviewed published Questions.', 'tutorhelper-lms' ) );
		}
		$status = sanitize_key( $record['import_status'] ?? 'draft' );
		$status = in_array( $status, array( 'draft', 'published' ), true ) ? $status : 'draft';
		$total_marks = self::placement_total_marks( $placements );
		$passing_percentage = min( 100, absint( $record['passing_percentage'] ?? 0 ) );
		$pass_mark = $passing_percentage > 0 ? min( $total_marks, max( 1, (int) ceil( $total_marks * $passing_percentage / 100 ) ) ) : 0;
		$definition = array(
			'instructions'   => wp_kses_post( (string) ( $record['instructions'] ?? '' ) ),
			'attempt_policy' => 'single' === sanitize_key( $record['attempt_policy'] ?? '' ) ? 'single' : 'unlimited',
			'pass_mark'      => $pass_mark,
			'delivery_mode'  => 'all',
			'result_release' => 'immediate',
			'random_pool'    => self::normalise_random_pool( $record['random_pool'] ?? array(), count( $placements ) ),
			'placements'     => $placements,
		);
		$definition = apply_filters( 'tutorhelper_lms_quiz_import_definition', $definition, $record, $placements );
		if ( is_wp_error( $definition ) || ! is_array( $definition ) ) {
			return is_wp_error( $definition ) ? $definition : new WP_Error( 'invalid_import_quiz_definition', __( 'The imported Quiz settings could not be prepared.', 'tutorhelper-lms' ) );
		}
		$definition['random_pool'] = self::normalise_random_pool( $definition['random_pool'] ?? array(), count( $placements ) );
		$definition['placements'] = $placements;
		$definition['pass_mark'] = min( $total_marks, max( 0, absint( $definition['pass_mark'] ?? 0 ) ) );
		$definition['attempt_policy'] = 'single' === sanitize_key( $definition['attempt_policy'] ?? '' ) ? 'single' : 'unlimited';
		$definition['delivery_mode'] = in_array( sanitize_key( $definition['delivery_mode'] ?? '' ), array( 'all', 'question', 'section' ), true ) ? sanitize_key( $definition['delivery_mode'] ) : 'all';
		$definition['result_release'] = 'tutor' === sanitize_key( $definition['result_release'] ?? '' ) ? 'tutor' : 'immediate';
		$quiz_id = wp_insert_post( wp_slash( array( 'post_type' => self::POST_TYPE, 'post_title' => $title, 'post_content' => $definition['instructions'], 'post_status' => 'publish' ) ), true );
		if ( is_wp_error( $quiz_id ) || ! $quiz_id ) {
			return is_wp_error( $quiz_id ) ? $quiz_id : new WP_Error( 'save_failed', __( 'The imported Quiz could not be created.', 'tutorhelper-lms' ) );
		}
		$quiz_id = absint( $quiz_id );
		$fingerprint = hash( 'sha256', wp_json_encode( self::canonical_definition( $definition ) ) );
		$version_id = self::create_version( $quiz_id, $definition, $fingerprint, 1 );
		if ( ! $version_id ) {
			wp_delete_post( $quiz_id, true );
			return new WP_Error( 'save_failed', __( 'The imported Quiz version could not be created.', 'tutorhelper-lms' ) );
		}
		update_post_meta( $quiz_id, self::META_CURRENT_VERSION, $version_id );
		update_post_meta( $quiz_id, self::META_STATUS, $status );
		update_post_meta( $quiz_id, '_tutorhelper_lms_import_key', $import_key );
		update_post_meta( $quiz_id, '_tutorhelper_lms_import_source_reference', sanitize_text_field( $record['source_reference'] ?? $import_key ) );
		return array( 'quiz_id' => $quiz_id, 'created' => true, 'status' => $status );
	}

	/**
	 * Release a completed Quiz result held for tutor release.
	 *
	 * @return void
	 */
	public static function release_quiz_attempt() {
		self::require_tutor();

		$attempt_id = isset( $_POST['attempt_id'] ) && ! is_array( $_POST['attempt_id'] ) ? absint( wp_unslash( $_POST['attempt_id'] ) ) : 0;
		check_admin_referer( self::RELEASE_ACTION . '_' . $attempt_id );

		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$attempt = $table && $attempt_id ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $attempt_id ) ) : null; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- tutor action for one attempt.

		if ( ! $attempt || 'completed' !== $attempt->status ) {
			self::redirect( add_query_arg( 'lms_quiz_error', 'release_failed', self::tab_url() ) );
		}

		$snapshot = json_decode( (string) $attempt->snapshot_json, true );
		$quiz = is_array( $snapshot ) && isset( $snapshot['quiz'] ) && is_array( $snapshot['quiz'] ) ? $snapshot['quiz'] : array();
		if ( 'tutor' !== sanitize_key( $quiz['result_release'] ?? 'immediate' ) || ! empty( $attempt->results_released_at ) ) {
			self::redirect( add_query_arg( 'lms_quiz_error', 'release_failed', self::tab_url( absint( $attempt->quiz_id ) ) ) );
		}

		$released = $wpdb->update(
			$table,
			array( 'results_released_at' => current_time( 'mysql', true ) ),
			array(
				'id'                  => $attempt_id,
				'status'              => 'completed',
				'results_released_at' => null,
			),
			array( '%s' ),
			array( '%d', '%s', null )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- explicit tutor release update.

		if ( 1 !== (int) $released ) {
			self::log_failure( 'release_quiz_attempt', absint( $attempt->quiz_id ), null, 'database_write_failed' );
			self::redirect( add_query_arg( 'lms_quiz_error', 'release_failed', self::tab_url( absint( $attempt->quiz_id ) ) ) );
		}

		self::redirect( add_query_arg( 'lms_quiz_updated', 'results_released', self::tab_url( absint( $attempt->quiz_id ) ) ) );
	}

	/**
	 * Show completed attempts whose results are awaiting this tutor's release.
	 *
	 * @param int $quiz_id Quiz post ID.
	 * @return void
	 */
	private static function render_release_queue( $quiz_id ) {
		global $wpdb;

		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		if ( '' === $table ) {
			return;
		}

		$attempts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE quiz_id = %d AND status = %s AND results_released_at IS NULL ORDER BY submitted_at ASC, id ASC",
				absint( $quiz_id ),
				'completed'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- tutor release queue.

		$held_attempts = array();
		foreach ( is_array( $attempts ) ? $attempts : array() as $attempt ) {
			$snapshot = json_decode( (string) $attempt->snapshot_json, true );
			$quiz = is_array( $snapshot ) && isset( $snapshot['quiz'] ) && is_array( $snapshot['quiz'] ) ? $snapshot['quiz'] : array();
			if ( 'tutor' === sanitize_key( $quiz['result_release'] ?? 'immediate' ) ) {
				$held_attempts[] = $attempt;
			}
		}

		if ( empty( $held_attempts ) ) {
			return;
		}
		?>
		<section class="tutorhelper-lms-quiz-builder__release-queue" aria-labelledby="tutorhelper-lms-results-release-heading">
			<h3 id="tutorhelper-lms-results-release-heading"><?php esc_html_e( 'Results awaiting release', 'tutorhelper-lms' ); ?></h3>
			<p class="description"><?php esc_html_e( 'These students have completed this Quiz. Releasing a result makes its score, answers and feedback visible to that student.', 'tutorhelper-lms' ); ?></p>
			<table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Student', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Course', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Attempt', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Submitted', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Action', 'tutorhelper-lms' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $held_attempts as $attempt ) : ?>
					<?php
					$student = get_userdata( absint( $attempt->student_user_id ) );
					$course = get_post( absint( $attempt->course_id ) );
					?>
					<tr>
						<td><?php echo esc_html( $student ? $student->display_name : __( 'Unknown student', 'tutorhelper-lms' ) ); ?></td>
						<td><?php echo esc_html( $course ? $course->post_title : '—' ); ?></td>
						<td><?php echo esc_html( sprintf( __( 'Attempt %d', 'tutorhelper-lms' ), absint( $attempt->attempt_number ) ) ); ?></td>
						<td><?php echo esc_html( $attempt->submitted_at ? mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $attempt->submitted_at ) : '—' ); ?></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="<?php echo esc_attr( self::RELEASE_ACTION ); ?>" />
								<input type="hidden" name="attempt_id" value="<?php echo esc_attr( $attempt->id ); ?>" />
								<?php wp_nonce_field( self::RELEASE_ACTION . '_' . absint( $attempt->id ) ); ?>
								<button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Release results', 'tutorhelper-lms' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</section>
		<?php
	}

	private static function selected_question_data( $placements ) {
		$selected = array();
		$version_ids = wp_list_pluck( $placements, 'question_version_id' );
		$metadata = self::question_version_metadata( $version_ids );
		$types = TutorHelper_LMS_Question_Bank::question_types();

		foreach ( $placements as $placement ) {
			$question = get_post( $placement->question_id );
			if ( ! $question ) {
				continue;
			}
			$version_id = absint( $placement->question_version_id );
			$details = isset( $metadata[ $version_id ] ) ? $metadata[ $version_id ] : array( 'type' => '', 'marks' => 0 );
			$selected[] = array(
				'id'         => absint( $placement->question_id ),
				'version_id' => $version_id,
				'title'      => $question->post_title,
				'type'       => isset( $types[ $details['type'] ] ) ? $types[ $details['type'] ] : __( 'Question', 'tutorhelper-lms' ),
				'marks'      => absint( $details['marks'] ),
				'section'    => self::placement_section( $placement ),
			);
		}
		return $selected;
	}

	private static function render_selected_question( $question, $premium_delivery = false ) {
		?>
		<div class="tutorhelper-lms-quiz-builder__selected-question" draggable="true" data-tutorhelper-lms-quiz-selected data-question-id="<?php echo esc_attr( $question['id'] ); ?>" data-question-version="<?php echo esc_attr( $question['version_id'] ); ?>" data-question-marks="<?php echo esc_attr( $question['marks'] ); ?>">
			<span class="dashicons dashicons-move" aria-hidden="true"></span>
			<div><strong><?php echo esc_html( $question['title'] ); ?></strong><span><?php echo esc_html( $question['type'] ); ?></span></div>
			<span class="tutorhelper-lms-quiz-builder__marks"><?php echo esc_html( sprintf( _n( '%d mark', '%d marks', $question['marks'], 'tutorhelper-lms' ), $question['marks'] ) ); ?></span>
			<div class="tutorhelper-lms-quiz-builder__selected-actions">
				<button class="button tutorhelper-lms-button--grey tutorhelper-lms-quiz-builder__arrow" type="button" data-tutorhelper-lms-quiz-move="up" aria-label="<?php esc_attr_e( 'Move Question up', 'tutorhelper-lms' ); ?>" title="<?php esc_attr_e( 'Move up', 'tutorhelper-lms' ); ?>"><span class="dashicons dashicons-arrow-up-alt2" aria-hidden="true"></span></button>
				<button class="button tutorhelper-lms-button--grey tutorhelper-lms-quiz-builder__arrow" type="button" data-tutorhelper-lms-quiz-move="down" aria-label="<?php esc_attr_e( 'Move Question down', 'tutorhelper-lms' ); ?>" title="<?php esc_attr_e( 'Move down', 'tutorhelper-lms' ); ?>"><span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span></button>
				<button class="button tutorhelper-lms-button--grey" type="button" data-tutorhelper-lms-quiz-remove><?php esc_html_e( 'Remove', 'tutorhelper-lms' ); ?></button>
			</div>
			<input type="hidden" name="question_ids[]" value="<?php echo esc_attr( $question['id'] ); ?>" />
			<input type="hidden" name="question_versions[<?php echo esc_attr( $question['id'] ); ?>]" value="<?php echo esc_attr( $question['version_id'] ); ?>" />
			<input type="hidden" name="question_order[<?php echo esc_attr( $question['id'] ); ?>]" value="0" />
			<?php if ( $premium_delivery ) : ?><label class="tutorhelper-lms-quiz-builder__section-label"><?php esc_html_e( 'Section', 'tutorhelper-lms' ); ?><input type="text" name="question_sections[<?php echo esc_attr( $question['id'] ); ?>]" value="<?php echo esc_attr( $question['section'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'For example: Section A', 'tutorhelper-lms' ); ?>" /></label><?php endif; ?>
		</div>
		<?php
	}

	private static function render_question_library( $selected ) {
		$selected_ids = wp_list_pluck( $selected, 'id' );
		$questions = get_posts(
			array(
				'post_type'      => TutorHelper_LMS_Question_Bank::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		$versions = array();
		foreach ( $questions as $question ) {
			if ( 'published' !== get_post_meta( $question->ID, TutorHelper_LMS_Question_Bank::META_STATUS, true ) ) {
				continue;
			}
			$version_id = self::question_current_version_id( $question->ID );
			if ( $version_id ) {
				$versions[ $question->ID ] = $version_id;
			}
		}
		if ( empty( $versions ) ) {
			echo '<p>' . esc_html__( 'No published Questions are available yet. Publish a Question in the Question Bank first.', 'tutorhelper-lms' ) . '</p>';
			return;
		}
		$metadata = self::question_version_metadata( array_values( $versions ) );
		$labels = TutorHelper_LMS_Question_Bank::question_types();
		foreach ( $questions as $question ) {
			if ( ! isset( $versions[ $question->ID ] ) ) {
				continue;
			}
			$version_id = $versions[ $question->ID ];
			$details = isset( $metadata[ $version_id ] ) ? $metadata[ $version_id ] : array( 'type' => '', 'marks' => 0 );
			$type_key = $details['type'];
			$type = isset( $labels[ $type_key ] ) ? $labels[ $type_key ] : __( 'Question', 'tutorhelper-lms' );
			$marks = absint( $details['marks'] );
			?>
			<div class="tutorhelper-lms-quiz-builder__library-question" draggable="true" data-tutorhelper-lms-quiz-library-question data-question-id="<?php echo esc_attr( $question->ID ); ?>" data-question-version="<?php echo esc_attr( $version_id ); ?>" data-question-type="<?php echo esc_attr( $type_key ); ?>" data-question-title="<?php echo esc_attr( $question->post_title ); ?>" data-question-label="<?php echo esc_attr( $type ); ?>" data-question-marks="<?php echo esc_attr( $marks ); ?>" data-question-search="<?php echo esc_attr( strtolower( $question->post_title . ' ' . $type ) ); ?>">
				<div><strong><?php echo esc_html( $question->post_title ); ?></strong><span><?php echo esc_html( $type ); ?></span></div>
				<button class="button tutorhelper-lms-button--orange" type="button" data-tutorhelper-lms-quiz-add <?php disabled( in_array( $question->ID, $selected_ids, true ) ); ?>><?php echo in_array( $question->ID, $selected_ids, true ) ? esc_html__( 'Added', 'tutorhelper-lms' ) : esc_html__( 'Add', 'tutorhelper-lms' ); ?></button>
			</div>
			<?php
		}
	}

	private static function posted_placements() {
		$selected = isset( $_POST['question_ids'] ) && is_array( $_POST['question_ids'] ) ? array_unique( array_map( 'absint', wp_unslash( $_POST['question_ids'] ) ) ) : array();
		$orders = isset( $_POST['question_order'] ) && is_array( $_POST['question_order'] ) ? wp_unslash( $_POST['question_order'] ) : array();
		$sections = isset( $_POST['question_sections'] ) && is_array( $_POST['question_sections'] ) ? wp_unslash( $_POST['question_sections'] ) : array();
		$items = array();
		foreach ( $selected as $question_id ) {
			$question = get_post( $question_id );
			// Reusable Questions always resolve to their current definition for future
			// Quiz attempts. Submitted student attempts retain their own snapshots.
			$version_id = self::question_current_version_id( $question_id );
			if ( ! $question || TutorHelper_LMS_Question_Bank::POST_TYPE !== $question->post_type || ! $version_id ) {
				continue;
			}
			$items[] = array(
				'question_id' => $question_id,
				'question_version_id' => $version_id,
				'sort_order' => isset( $orders[ $question_id ] ) ? max( 1, absint( $orders[ $question_id ] ) ) : 9999,
				'section' => isset( $sections[ $question_id ] ) ? sanitize_text_field( $sections[ $question_id ] ) : '',
			);
		}
		usort( $items, function ( $left, $right ) { return $left['sort_order'] - $right['sort_order']; } );
		foreach ( $items as $index => $item ) {
			$items[ $index ]['sort_order'] = $index + 1;
		}
		return $items;
	}

	private static function question_version_belongs_to( $version_id, $question_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		return $table ? (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE id = %d AND question_id = %d", $version_id, $question_id ) ) : false; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- validates immutable Question Version ownership.
	}

	private static function create_version( $quiz_id, $definition, $fingerprint, $number ) {
		global $wpdb;

		$versions = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		$placements = TutorHelper_LMS_Free_Database::table( 'quiz_question_placements' );
		if ( '' === $versions || '' === $placements ) {
			return 0;
		}
		$inserted = $wpdb->insert(
			$versions,
			array(
				'quiz_id'             => absint( $quiz_id ),
				'version_number'      => absint( $number ),
				'definition_json'     => wp_json_encode( $definition ),
				'total_marks'         => self::placement_total_marks( $definition['placements'] ),
				'content_fingerprint' => $fingerprint,
				'created_by'          => get_current_user_id(),
				'created_at'          => current_time( 'mysql', true ),
			),
			array( '%d', '%d', '%s', '%d', '%s', '%d', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Immutable Quiz Version write.
		if ( ! $inserted ) {
			return 0;
		}
		$version_id = absint( $wpdb->insert_id );
		foreach ( $definition['placements'] as $placement ) {
			$stored = $wpdb->insert(
				$placements,
				array(
					'quiz_version_id'    => $version_id,
					'quiz_id'            => absint( $quiz_id ),
					'question_id'        => absint( $placement['question_id'] ),
					'question_version_id'=> absint( $placement['question_version_id'] ),
					'sort_order'         => absint( $placement['sort_order'] ),
					'required'           => 1,
					'mark_override'      => null,
					'settings_json'      => wp_json_encode( array( 'section' => sanitize_text_field( $placement['section'] ?? '' ) ) ),
					'created_at'         => current_time( 'mysql', true ),
				),
				array( '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%s', '%s' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Immutable Question Placement snapshot write.
			if ( ! $stored ) {
				self::log_failure( 'create_quiz_placement', $quiz_id, null, 'database_write_failed' );
				return 0;
			}
		}
		return $version_id;
	}

	private static function get_current_version( $quiz_id ) {
		global $wpdb;
		$version_id = absint( get_post_meta( $quiz_id, self::META_CURRENT_VERSION, true ) );
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		if ( ! $version_id || '' === $table ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND quiz_id = %d", $version_id, $quiz_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Immutable version lookup.
	}

	private static function get_placements( $version_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_question_placements' );
		if ( '' === $table ) {
			return array();
		}
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE quiz_version_id = %d ORDER BY sort_order ASC, id ASC", $version_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Immutable placement snapshot lookup.
	}


	/**
	 * Return the optional Premium section name stored on a Quiz Question placement.
	 *
	 * @param object $placement Quiz placement.
	 * @return string
	 */
	private static function placement_section( $placement ) {
		$settings = json_decode( (string) ( $placement->settings_json ?? '' ), true );
		return is_array( $settings ) ? sanitize_text_field( $settings['section'] ?? '' ) : '';
	}

	private static function question_current_version_id( $question_id ) {
		return absint( get_post_meta( $question_id, TutorHelper_LMS_Question_Bank::META_CURRENT_VERSION, true ) );
	}

	private static function question_type_label( $version_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		$type = $table ? $wpdb->get_var( $wpdb->prepare( "SELECT question_type FROM {$table} WHERE id = %d", $version_id ) ) : ''; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- one Question Version label lookup.
		$types = TutorHelper_LMS_Question_Bank::question_types();
		return isset( $types[ $type ] ) ? $types[ $type ] : __( 'Question', 'tutorhelper-lms' );
	}

	private static function question_version_metadata( $version_ids ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		$version_ids = array_values( array_unique( array_filter( array_map( 'absint', $version_ids ) ) ) );
		if ( '' === $table || empty( $version_ids ) ) {
			return array();
		}
		$placeholders = implode( ',', array_fill( 0, count( $version_ids ), '%d' ) );
		$query = $wpdb->prepare( "SELECT id, question_type, max_marks FROM {$table} WHERE id IN ({$placeholders})", $version_ids );
		$rows = $wpdb->get_results( $query ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk Question Version metadata lookup for Quiz builder.
		$metadata = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$metadata[ absint( $row->id ) ] = array(
				'type'  => sanitize_key( $row->question_type ),
				'marks' => absint( $row->max_marks ),
			);
		}
		return $metadata;
	}

	private static function placement_total_marks( $placements ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		$total = 0;
		foreach ( $placements as $placement ) {
			$marks = $table ? absint( $wpdb->get_var( $wpdb->prepare( "SELECT max_marks FROM {$table} WHERE id = %d", $placement['question_version_id'] ) ) ) : 0; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- snapshot mark total creation.
			$total += $marks;
		}
		return $total;
	}

	private static function render_quiz_table() {
		$quizzes = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => 50,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);
		?>
		<h3><?php esc_html_e( 'Reusable Quizzes', 'tutorhelper-lms' ); ?></h3>
		<?php if ( empty( $quizzes ) ) : ?>
			<p><?php esc_html_e( 'No Quizzes yet. Create one from your published Questions.', 'tutorhelper-lms' ); ?></p>
			<?php return; ?>
		<?php endif; ?>
		<table class="widefat striped">
			<thead><tr>
				<th><?php esc_html_e( 'Quiz', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Questions', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Marks', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Version', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Action', 'tutorhelper-lms' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( $quizzes as $quiz ) : ?>
				<?php $version = self::get_current_version( $quiz->ID ); $definition = $version ? self::decode_definition( $version->definition_json ) : self::empty_definition(); ?>
				<tr>
					<td><strong><?php echo esc_html( $quiz->post_title ); ?></strong></td>
					<td><?php echo esc_html( number_format_i18n( count( $definition['placements'] ) ) ); ?></td>
					<td><?php echo esc_html( $version ? number_format_i18n( absint( $version->total_marks ) ) : '0' ); ?></td>
					<td><?php echo esc_html( $version ? (string) absint( $version->version_number ) : '—' ); ?></td>
					<td><?php echo 'published' === self::current_status( $quiz->ID ) ? esc_html__( 'Published', 'tutorhelper-lms' ) : esc_html__( 'Draft', 'tutorhelper-lms' ); ?></td>
					<td><a class="button tutorhelper-action-button" href="<?php echo esc_url( self::tab_url( $quiz->ID ) ); ?>"><?php esc_html_e( 'Edit Quiz', 'tutorhelper-lms' ); ?></a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	private static function empty_definition() {
		return array( 'instructions' => '', 'attempt_policy' => 'unlimited', 'pass_mark' => 0, 'delivery_mode' => 'all', 'result_release' => 'immediate', 'random_pool' => array( 'mode' => 'all', 'questions_per_attempt' => 0 ), 'placements' => array() );
	}

	private static function decode_definition( $json ) {
		$definition = json_decode( $json, true );
		$definition = is_array( $definition ) ? $definition : array();
		$definition['instructions'] = isset( $definition['instructions'] ) ? $definition['instructions'] : '';
		$definition['attempt_policy'] = 'single' === sanitize_key( $definition['attempt_policy'] ?? '' ) ? 'single' : 'unlimited';
		$definition['pass_mark'] = absint( $definition['pass_mark'] ?? 0 );
		$definition['delivery_mode'] = in_array( sanitize_key( $definition['delivery_mode'] ?? '' ), array( 'all', 'question', 'section' ), true ) ? sanitize_key( $definition['delivery_mode'] ) : 'all';
		$definition['result_release'] = isset( $definition['result_release'] ) && in_array( $definition['result_release'], array( 'immediate', 'tutor' ), true ) ? $definition['result_release'] : 'immediate';
		$definition['placements'] = isset( $definition['placements'] ) && is_array( $definition['placements'] ) ? $definition['placements'] : array();
		$definition['random_pool'] = self::normalise_random_pool( $definition['random_pool'] ?? array(), count( $definition['placements'] ) );
		return $definition;
	}

	private static function normalise_random_pool( $pool, $placement_count ) {
		$pool = is_array( $pool ) ? $pool : array();
		$mode = 'random' === sanitize_key( $pool['mode'] ?? '' ) ? 'random' : 'all';
		$count = absint( $pool['questions_per_attempt'] ?? 0 );
		if ( 'random' === $mode && ( $count < 1 || $count > absint( $placement_count ) ) ) {
			$mode = 'all';
			$count = 0;
		}
		return array( 'mode' => $mode, 'questions_per_attempt' => 'random' === $mode ? $count : 0 );
	}

	private static function canonical_definition( $definition ) {
		$canonical = array(
			'instructions'   => trim( wp_strip_all_tags( $definition['instructions'] ) ),
			'attempt_policy' => $definition['attempt_policy'],
			'pass_mark'      => absint( $definition['pass_mark'] ),
			'delivery_mode'  => $definition['delivery_mode'],
			'result_release' => $definition['result_release'],
			'random_pool'    => self::normalise_random_pool( $definition['random_pool'] ?? array(), count( $definition['placements'] ?? array() ) ),
			'placements'     => $definition['placements'],
		);
		return apply_filters( 'tutorhelper_lms_quiz_canonical_definition', $canonical, $definition );
	}

	private static function current_status( $quiz_id ) {
		$status = get_post_meta( $quiz_id, self::META_STATUS, true );
		return in_array( $status, array( 'draft', 'published' ), true ) ? $status : 'draft';
	}

	private static function tab_url( $edit_id = 0 ) {
		$args = array(
			'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG,
			'tab'  => 'quizzes',
		);
		if ( $edit_id ) {
			$args['edit_quiz'] = absint( $edit_id );
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	private static function posted_text( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	private static function posted_key( $key ) {
		return sanitize_key( self::posted_text( $key ) );
	}

	private static function posted_html( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? wp_kses_post( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	private static function redirect( $url ) {
		wp_safe_redirect( $url );
		exit;
	}

	private static function render_notice() {
		$updated = isset( $_GET['lms_quiz_updated'] ) && ! is_array( $_GET['lms_quiz_updated'] ) ? sanitize_key( wp_unslash( $_GET['lms_quiz_updated'] ) ) : '';
		$error = isset( $_GET['lms_quiz_error'] ) && ! is_array( $_GET['lms_quiz_error'] ) ? sanitize_key( wp_unslash( $_GET['lms_quiz_error'] ) ) : '';
		$errors = array(
			'missing_title' => __( 'Enter a Quiz title.', 'tutorhelper-lms' ),
			'missing_questions' => __( 'Add at least one published Question before publishing this Quiz.', 'tutorhelper-lms' ),
			'invalid_pass_mark' => __( 'The pass mark cannot be higher than the Quiz total marks.', 'tutorhelper-lms' ),
			'invalid_random_question_count' => __( 'Choose at least one Question and no more Questions than are in the Quiz pool.', 'tutorhelper-lms' ),
			'save_failed' => __( 'The Quiz could not be saved. Please try again.', 'tutorhelper-lms' ),
			'release_failed' => __( 'The Quiz result could not be released. Please try again.', 'tutorhelper-lms' ),
		);
		$errors = apply_filters( 'tutorhelper_lms_quiz_errors', $errors );
		if ( $updated ) {
			$message = 'results_released' === $updated ? __( 'Quiz results released successfully.', 'tutorhelper-lms' ) : __( 'Quiz saved successfully.', 'tutorhelper-lms' );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
		}
		if ( $error ) {
			echo '<div class="notice notice-error"><p>' . esc_html( isset( $errors[ $error ] ) ? $errors[ $error ] : __( 'The Quiz could not be saved. Please try again.', 'tutorhelper-lms' ) ) . '</p></div>';
		}
	}

	private static function require_tutor() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Quizzes.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
	}

	private static function log_failure( $operation, $quiz_id, $error, $reason ) {
		if ( ! class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			return;
		}
		$context = array(
			'operation' => $operation,
			'entity_id' => absint( $quiz_id ),
			'post_type' => self::POST_TYPE,
			'failure_reason' => sanitize_key( $reason ),
		);
		if ( is_wp_error( $error ) ) {
			TutorHelper_LMS_Diagnostics::wp_error( 'Quiz Builder save failed.', $error, $context );
			return;
		}
		TutorHelper_LMS_Diagnostics::error( 'Quiz Builder save failed.', $context );
	}
}
