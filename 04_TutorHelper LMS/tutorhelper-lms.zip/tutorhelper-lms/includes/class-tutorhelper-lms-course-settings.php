<?php
/**
 * Course lifecycle, enrolment and metadata settings for free TutorHelper LMS.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Course_Settings {

	const TAG_TAXONOMY = 'tutorhelper_lms_course_tag';
	const META_LIFECYCLE = '_tutorhelper_lms_course_lifecycle';
	const META_ENROLMENTS_OPEN = '_tutorhelper_lms_enrolments_open';
	const META_CAPACITY = '_tutorhelper_lms_course_capacity';
	const META_COLOUR = '_tutorhelper_lms_course_colour';
	const META_ACCESS_STYLE = '_tutorhelper_lms_course_access_style';
	const META_STUDENT_INFORMATION = '_tutorhelper_lms_course_student_information';

	/**
	 * Register shared Course settings.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_taxonomy' ), 20 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Register an ordinary WordPress taxonomy for Course tags.
	 *
	 * @return void
	 */
	public static function register_taxonomy() {
		register_taxonomy(
			self::TAG_TAXONOMY,
			array( 'tutorhelper_course' ),
			array(
				'labels'       => array(
					'name'          => __( 'Course tags', 'tutorhelper-lms' ),
					'singular_name' => __( 'Course tag', 'tutorhelper-lms' ),
				),
				'public'       => false,
				'show_ui'      => false,
				'show_in_rest' => true,
				'hierarchical' => false,
			)
		);
	}

	/**
	 * Enqueue the native WordPress Media Library selector for Course images.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( false === strpos( (string) $hook_suffix, 'tutorhelper' ) ) {
			return;
		}
		wp_enqueue_media();
		$script_path = TUTORHELPER_LMS_PATH . 'assets/js/tutorhelper-lms-course-settings.js';
		wp_enqueue_script(
			'tutorhelper-lms-course-settings',
			TUTORHELPER_LMS_URL . 'assets/js/tutorhelper-lms-course-settings.js',
			array( 'jquery' ),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_LMS_VERSION,
			true
		);
		$builder_script_path = TUTORHELPER_LMS_PATH . 'assets/js/tutorhelper-lms-course-builder.js';
		wp_enqueue_script(
			'tutorhelper-lms-course-builder',
			TUTORHELPER_LMS_URL . 'assets/js/tutorhelper-lms-course-builder.js',
			array(),
			file_exists( $builder_script_path ) ? (string) filemtime( $builder_script_path ) : TUTORHELPER_LMS_VERSION,
			true
		);
		wp_localize_script( 'tutorhelper-lms-course-builder', 'tutorhelperLmsCourseBuilder', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( TutorHelper_LMS_Course_Builder::ORDER_AJAX_ACTION ) ) );
	}

	/**
	 * Return supported lifecycle labels.
	 *
	 * @return array<string,string>
	 */
	public static function lifecycle_labels() {
		return array(
			'draft'    => __( 'Draft', 'tutorhelper-lms' ),
			'running'  => __( 'Running', 'tutorhelper-lms' ),
			'closed'   => __( 'Closed', 'tutorhelper-lms' ),
			'archived' => __( 'Archived', 'tutorhelper-lms' ),
		);
	}

	/** Return the available Course navigation styles. */
	public static function access_style_labels() {
		$styles = array(
			'open'     => __( 'Open navigation', 'tutorhelper-lms' ),
			'in_order' => __( 'Complete activities in order', 'tutorhelper-lms' ),
		);
		return apply_filters( 'tutorhelper_lms_course_access_style_labels', $styles );
	}

	/**
	 * Render Course model fields within the existing Learning Hub Course form.
	 *
	 * @param int $course_id Course post ID, or zero for a new Course.
	 * @return void
	 */
	public static function render_fields( $course_id ) {
		$course_id = absint( $course_id );
		$lifecycle = self::lifecycle( $course_id );
		$capacity  = self::capacity( $course_id );
		$open      = self::enrolments_open( $course_id );
		$access_style = self::access_style( $course_id );
		$colour    = self::colour( $course_id );
		$colour_preset = isset( self::colour_presets()[ $colour ] ) ? $colour : ( self::is_hex_colour( $colour ) ? 'custom' : '' );
		$image_id  = $course_id ? get_post_thumbnail_id( $course_id ) : 0;
		$tags      = $course_id ? wp_get_object_terms( $course_id, self::TAG_TAXONOMY, array( 'fields' => 'names' ) ) : array();
		?>
		<fieldset class="tutorhelper-lms-library-choices">
			<legend><?php esc_html_e( 'Course details', 'tutorhelper-lms' ); ?></legend>
			<p class="description"><?php esc_html_e( 'Course lifecycle and enrolment availability are separate. Closing a Course or enrolments never removes existing academic links or records.', 'tutorhelper-lms' ); ?></p>
			<p><label for="tutorhelper-lms-course-lifecycle"><strong><?php esc_html_e( 'Lifecycle', 'tutorhelper-lms' ); ?></strong></label><br />
				<select id="tutorhelper-lms-course-lifecycle" name="course_lifecycle"><?php foreach ( self::lifecycle_labels() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $lifecycle, $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select>
			</p>
			<p><label><input type="checkbox" name="course_enrolments_open" value="1" <?php checked( $open ); ?> /> <?php esc_html_e( 'Allow new structured Course enrolments', 'tutorhelper-lms' ); ?></label></p>
			<p><label for="tutorhelper-lms-course-access-style"><strong><?php esc_html_e( 'Course navigation', 'tutorhelper-lms' ); ?></strong></label><br />
				<select id="tutorhelper-lms-course-access-style" name="course_access_style"><?php foreach ( self::access_style_labels() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $access_style, $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select>
				<span class="description"><?php esc_html_e( 'Open navigation lets students choose any activity. Complete activities in order unlocks the next lesson or Quiz only after the previous required activity is complete.', 'tutorhelper-lms' ); ?></span>
			</p>
			<p><label for="tutorhelper-lms-course-capacity"><strong><?php esc_html_e( 'Maximum structured enrolments', 'tutorhelper-lms' ); ?></strong></label><br />
				<input id="tutorhelper-lms-course-capacity" type="number" min="0" step="1" name="course_capacity" value="<?php echo esc_attr( $capacity ); ?>" />
				<span class="description"><?php esc_html_e( 'Use 0 for unlimited. Group academic links do not use capacity.', 'tutorhelper-lms' ); ?></span>
			</p>
			<p><label for="tutorhelper-lms-course-tags"><strong><?php esc_html_e( 'Course tags', 'tutorhelper-lms' ); ?></strong></label><br />
				<input id="tutorhelper-lms-course-tags" class="regular-text" type="text" name="course_tags" value="<?php echo esc_attr( implode( ', ', is_array( $tags ) ? $tags : array() ) ); ?>" />
				<span class="description"><?php esc_html_e( 'Separate tags with commas.', 'tutorhelper-lms' ); ?></span>
			</p>
			<p><label for="tutorhelper-lms-course-colour"><strong><?php esc_html_e( 'Course colour', 'tutorhelper-lms' ); ?></strong></label><br />
				<select id="tutorhelper-lms-course-colour" name="course_colour_preset"><?php foreach ( self::colour_presets() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $colour_preset, $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select>
				<input type="color" name="course_colour_custom" value="<?php echo esc_attr( self::is_hex_colour( $colour ) ? $colour : '#174957' ); ?>" aria-label="<?php esc_attr_e( 'Custom Course colour', 'tutorhelper-lms' ); ?>" />
				<span class="description"><?php esc_html_e( 'An optional visual cue. Course title and status always remain visible as text.', 'tutorhelper-lms' ); ?></span>
			</p>
			<p><strong><?php esc_html_e( 'Featured image', 'tutorhelper-lms' ); ?></strong></p>
			<div class="tutorhelper-lms-course-image-control" data-tutorhelper-lms-course-image>
				<input type="hidden" name="course_featured_image_id" value="<?php echo esc_attr( $image_id ); ?>" data-tutorhelper-lms-course-image-id />
				<span data-tutorhelper-lms-course-image-preview><?php if ( $image_id ) { echo wp_kses_post( wp_get_attachment_image( $image_id, 'thumbnail' ) ); } ?></span>
				<button type="button" class="button button-primary tutorhelper-action-button tutorhelper-lms-button--orange" data-tutorhelper-lms-course-image-select><?php esc_html_e( 'Choose image', 'tutorhelper-lms' ); ?></button>
				<button type="button" class="button tutorhelper-action-button tutorhelper-lms-button--grey" data-tutorhelper-lms-course-image-remove <?php disabled( ! $image_id ); ?>><?php esc_html_e( 'Remove image', 'tutorhelper-lms' ); ?></button>
			</div>
		</fieldset>
		<?php
	}

	/**
	 * Validate submitted Course model data before the post is saved.
	 *
	 * @return true|WP_Error
	 */
	public static function validate_posted_settings() {
		$lifecycle = self::posted_key( 'course_lifecycle', 'running' );
		if ( ! isset( self::lifecycle_labels()[ $lifecycle ] ) ) {
			return new WP_Error( 'invalid_course_lifecycle', __( 'Choose a valid Course lifecycle.', 'tutorhelper-lms' ) );
		}
		$access_style = self::posted_key( 'course_access_style', 'open' );
		if ( ! isset( self::access_style_labels()[ $access_style ] ) ) {
			return new WP_Error( 'invalid_course_access_style', __( 'Choose a valid Course navigation style.', 'tutorhelper-lms' ) );
		}
		$capacity = self::posted_value( 'course_capacity' );
		if ( '' === $capacity || ! ctype_digit( $capacity ) ) {
			return new WP_Error( 'invalid_course_capacity', __( 'Maximum enrolments must be a whole number of zero or more.', 'tutorhelper-lms' ) );
		}
		return true;
	}

	/**
	 * Save Course model data after the Course post has been saved.
	 *
	 * @param int $course_id Course post ID.
	 * @return void
	 */
	public static function save_posted_settings( $course_id ) {
		$course_id = absint( $course_id );
		$lifecycle = self::posted_key( 'course_lifecycle', 'running' );
		$capacity  = absint( self::posted_value( 'course_capacity' ) );
		$open      = self::posted_bool( 'course_enrolments_open' );
		$access_style = self::posted_key( 'course_access_style', 'open' );
		$preset    = self::posted_key( 'course_colour_preset', '' );
		$custom    = sanitize_hex_color( self::posted_value( 'course_colour_custom' ) );
		$colour    = 'custom' === $preset ? $custom : ( isset( self::colour_presets()[ $preset ] ) ? $preset : '' );

		update_post_meta( $course_id, self::META_LIFECYCLE, $lifecycle );
		update_post_meta( $course_id, self::META_CAPACITY, $capacity );
		update_post_meta( $course_id, self::META_ENROLMENTS_OPEN, $open ? '1' : '0' );
		update_post_meta( $course_id, self::META_ACCESS_STYLE, isset( self::access_style_labels()[ $access_style ] ) ? $access_style : 'open' );
		if ( $colour ) {
			update_post_meta( $course_id, self::META_COLOUR, $colour );
		} else {
			delete_post_meta( $course_id, self::META_COLOUR );
		}

		$image_id = absint( self::posted_value( 'course_featured_image_id' ) );
		if ( $image_id && 'attachment' === get_post_type( $image_id ) ) {
			set_post_thumbnail( $course_id, $image_id );
		} elseif ( ! $image_id ) {
			delete_post_thumbnail( $course_id );
		}

		$tags = array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', self::posted_value( 'course_tags' ) ) ) ) );
		wp_set_object_terms( $course_id, array_values( array_unique( $tags ) ), self::TAG_TAXONOMY, false );
	}

	/** Save the optional student-facing Course information panel. */
	public static function save_student_information( $course_id ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called only from Learning_Library::save() after its action nonce and capability check.
		$value = isset( $_POST['course_student_information'] ) && ! is_array( $_POST['course_student_information'] ) ? wp_kses_post( wp_unslash( $_POST['course_student_information'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		update_post_meta( absint( $course_id ), self::META_STUDENT_INFORMATION, $value );
	}

	/** Return rich student-facing Course information. */
	public static function student_information( $course_id ) {
		return (string) get_post_meta( absint( $course_id ), self::META_STUDENT_INFORMATION, true );
	}

	/** Return the current Course lifecycle. */
	public static function lifecycle( $course_id ) {
		$value = sanitize_key( (string) get_post_meta( absint( $course_id ), self::META_LIFECYCLE, true ) );
		return isset( self::lifecycle_labels()[ $value ] ) ? $value : 'running';
	}

	/** Return the configured Course navigation style, preserving open access for existing Courses. */
	public static function access_style( $course_id ) {
		$value = sanitize_key( (string) get_post_meta( absint( $course_id ), self::META_ACCESS_STYLE, true ) );
		return isset( self::access_style_labels()[ $value ] ) ? $value : 'open';
	}

	/** Return whether new structured enrolments are open. */
	public static function enrolments_open( $course_id ) {
		return '1' === (string) get_post_meta( absint( $course_id ), self::META_ENROLMENTS_OPEN, true );
	}

	/** Return the maximum number of active structured enrolments. */
	public static function capacity( $course_id ) {
		return max( 0, absint( get_post_meta( absint( $course_id ), self::META_CAPACITY, true ) ) );
	}

	/** Return the explicit Course colour or an empty value. */
	public static function colour( $course_id ) {
		$colour = (string) get_post_meta( absint( $course_id ), self::META_COLOUR, true );
		return isset( self::colour_presets()[ $colour ] ) || self::is_hex_colour( $colour ) ? $colour : '';
	}

	/** Accessible TutorHelper colour presets. */
	public static function colour_presets() {
		return array(
			''        => __( 'TutorHelper default', 'tutorhelper-lms' ),
			'#174957' => __( 'Navy', 'tutorhelper-lms' ),
			'#007c83' => __( 'Teal', 'tutorhelper-lms' ),
			'#c75b12' => __( 'Orange', 'tutorhelper-lms' ),
			'#5c6f35' => __( 'Green', 'tutorhelper-lms' ),
			'custom'  => __( 'Custom colour', 'tutorhelper-lms' ),
		);
	}

	/** Whether a value is a six-character hexadecimal CSS colour. */
	private static function is_hex_colour( $value ) {
		return (bool) preg_match( '/^#[a-f0-9]{6}$/i', (string) $value );
	}

	private static function posted_value( $name ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called only from Learning_Library::save() after its action nonce and capability check.
		$value = isset( $_POST[ $name ] ) && ! is_array( $_POST[ $name ] ) ? trim( (string) wp_unslash( $_POST[ $name ] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return $value;
	}

	private static function posted_bool( $name ) {
		return '1' === self::posted_value( $name );
	}

	private static function posted_key( $name, $default ) {
		$value = sanitize_key( self::posted_value( $name ) );
		return '' === $value ? $default : $value;
	}
}
