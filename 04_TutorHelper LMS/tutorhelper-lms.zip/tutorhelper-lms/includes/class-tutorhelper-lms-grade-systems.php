<?php
/**
 * Reusable grade systems and course-specific grade boundaries.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Grade_Systems {

	const SAVE_ACTION   = 'tutorhelper_lms_save_grade_system';
	const DELETE_ACTION = 'tutorhelper_lms_delete_grade_system';
	const META_TYPE     = '_tutorhelper_lms_grade_system_type';
	const META_GRADES   = '_tutorhelper_lms_grade_labels';
	const COURSE_SYSTEM = '_tutorhelper_lms_grade_system_id';
	const COURSE_BOUNDS = '_tutorhelper_lms_course_grade_boundaries';

	/**
	 * Register grade-system form handlers.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save' ) );
		add_action( 'admin_post_' . self::DELETE_ACTION, array( __CLASS__, 'delete' ) );
	}

	/**
	 * Render the Grade systems tab.
	 *
	 * @return void
	 */
	public static function render_section() {
		$edit_id = self::request_id( 'edit' );
		$editing = $edit_id ? get_post( $edit_id ) : null;
		if ( ! $editing || 'th_lms_grade_system' !== $editing->post_type ) {
			$editing = null;
		}

		$systems = self::systems();
		?>
		<?php self::render_notice(); ?>
		<div class="tutorhelper-lms-library-grid">
			<section class="tutorhelper-lms-library-form">
				<h3><?php echo esc_html( $editing ? __( 'Edit grade system', 'tutorhelper-lms' ) : __( 'Add grade system', 'tutorhelper-lms' ) ); ?></h3>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
					<input type="hidden" name="entity_id" value="<?php echo esc_attr( $editing ? $editing->ID : 0 ); ?>" />
					<?php wp_nonce_field( self::SAVE_ACTION ); ?>

					<p>
						<label for="tutorhelper-lms-grade-system-title"><strong><?php esc_html_e( 'Grade system name', 'tutorhelper-lms' ); ?></strong></label>
						<input id="tutorhelper-lms-grade-system-title" class="regular-text" type="text" name="title" required value="<?php echo esc_attr( $editing ? $editing->post_title : '' ); ?>" placeholder="<?php esc_attr_e( 'For example: A Level letter grades', 'tutorhelper-lms' ); ?>" />
					</p>

					<?php $type = $editing ? self::system_type( $editing->ID ) : 'grades'; ?>
					<p>
						<label for="tutorhelper-lms-grade-system-type"><strong><?php esc_html_e( 'System type', 'tutorhelper-lms' ); ?></strong></label>
						<select id="tutorhelper-lms-grade-system-type" name="system_type" data-tutorhelper-lms-grade-system-type>
							<option value="grades" <?php selected( 'grades', $type ); ?>><?php esc_html_e( 'Named grades with course boundaries', 'tutorhelper-lms' ); ?></option>
							<option value="percentage" <?php selected( 'percentage', $type ); ?>><?php esc_html_e( 'Percentage only', 'tutorhelper-lms' ); ?></option>
						</select>
					</p>

					<div data-tutorhelper-lms-grade-labels>
						<p>
							<label for="tutorhelper-lms-grade-labels"><strong><?php esc_html_e( 'Grade labels', 'tutorhelper-lms' ); ?></strong></label>
							<textarea id="tutorhelper-lms-grade-labels" class="large-text" rows="7" name="grade_labels" placeholder="<?php echo esc_attr__( "A*\nA\nB\nC", 'tutorhelper-lms' ); ?>"><?php echo esc_textarea( $editing ? implode( "\n", self::grade_labels( $editing->ID ) ) : '' ); ?></textarea>
						</p>
						<p class="description"><?php esc_html_e( 'Enter one grade per line, from highest to lowest. For example: A*, A, B, C, D, E.', 'tutorhelper-lms' ); ?></p>
					</div>

					<p><button class="button button-primary tutorhelper-action-button" type="submit"><?php echo esc_html( $editing ? __( 'Save grade system', 'tutorhelper-lms' ) : __( 'Create grade system', 'tutorhelper-lms' ) ); ?></button><?php if ( $editing ) : ?> <a class="button" href="<?php echo esc_url( self::tab_url() ); ?>"><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></a><?php endif; ?></p>
				</form>
			</section>

			<section>
				<?php self::render_system_table( $systems ); ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Render Course fields for selecting a reusable grade system and boundaries.
	 *
	 * @param int $course_id Course post ID, or zero while creating.
	 * @return void
	 */
	public static function render_course_fields( $course_id ) {
		$systems         = self::systems();
		$selected_system = $course_id ? absint( get_post_meta( $course_id, self::COURSE_SYSTEM, true ) ) : 0;
		$boundaries      = $course_id ? self::course_boundaries( $course_id ) : array();

		if ( empty( $systems ) ) {
			?>
			<p class="description"><?php esc_html_e( 'Create a reusable grade system in the Grade systems tab to add course-specific boundaries.', 'tutorhelper-lms' ); ?></p>
			<?php
			return;
		}
		?>
		<fieldset class="tutorhelper-lms-library-choices tutorhelper-lms-grade-boundaries">
			<legend><?php esc_html_e( 'Course grade boundaries', 'tutorhelper-lms' ); ?></legend>
			<p>
				<label for="tutorhelper-lms-course-grade-system"><strong><?php esc_html_e( 'Grade system', 'tutorhelper-lms' ); ?></strong></label>
				<select id="tutorhelper-lms-course-grade-system" name="grade_system_id" data-tutorhelper-lms-course-grade-system>
					<option value=""><?php esc_html_e( 'No grade system for this course', 'tutorhelper-lms' ); ?></option>
					<?php foreach ( $systems as $system ) : ?>
						<option value="<?php echo esc_attr( $system->ID ); ?>" <?php selected( $selected_system, $system->ID ); ?>><?php echo esc_html( $system->post_title ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>

			<?php foreach ( $systems as $system ) : ?>
				<?php $system_type = self::system_type( $system->ID ); ?>
				<div class="tutorhelper-lms-grade-boundaries__system <?php echo $selected_system === $system->ID ? 'is-active' : ''; ?>" data-tutorhelper-lms-grade-boundary-system="<?php echo esc_attr( $system->ID ); ?>" <?php echo $selected_system === $system->ID ? '' : 'hidden'; ?>>
					<?php if ( 'percentage' === $system_type ) : ?>
						<p class="description"><?php esc_html_e( 'This course uses raw percentage marks. No named grade boundaries are required.', 'tutorhelper-lms' ); ?></p>
					<?php else : ?>
						<p class="description"><?php esc_html_e( 'Set the minimum percentage needed for each grade in this course. Use values from highest grade to lowest grade.', 'tutorhelper-lms' ); ?></p>
						<div class="tutorhelper-lms-grade-boundaries__rows">
							<?php foreach ( self::grade_labels( $system->ID ) as $index => $grade ) : ?>
								<label>
									<span><?php echo esc_html( $grade ); ?></span>
									<input type="number" name="grade_boundaries[<?php echo esc_attr( $system->ID ); ?>][<?php echo esc_attr( $index ); ?>]" min="0" max="100" step="0.01" value="<?php echo esc_attr( isset( $boundaries[ $index ] ) && $selected_system === $system->ID ? $boundaries[ $index ] : '' ); ?>" data-tutorhelper-lms-grade-boundary-input />
									<span>%</span>
								</label>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</fieldset>
		<?php
	}

	/**
	 * Validate submitted Course grade settings before saving a course.
	 *
	 * @return true|WP_Error
	 */
	public static function validate_course_settings() {
		$system_id = self::posted_id( 'grade_system_id' );
		if ( ! $system_id ) {
			return true;
		}

		$system = get_post( $system_id );
		if ( ! $system || 'th_lms_grade_system' !== $system->post_type || 'trash' === $system->post_status ) {
			return new WP_Error( 'invalid_grade_system' );
		}

		if ( 'percentage' === self::system_type( $system_id ) ) {
			return true;
		}

		$labels = self::grade_labels( $system_id );
		$all    = self::posted_boundaries( $system_id );
		if ( count( $labels ) !== count( $all ) ) {
			return new WP_Error( 'missing_grade_boundaries' );
		}

		$previous = null;
		foreach ( $labels as $index => $label ) {
			if ( ! isset( $all[ $index ] ) || '' === $all[ $index ] || ! is_numeric( $all[ $index ] ) ) {
				return new WP_Error( 'missing_grade_boundaries' );
			}
			$value = (float) $all[ $index ];
			if ( $value < 0 || $value > 100 || ( null !== $previous && $value >= $previous ) ) {
				return new WP_Error( 'invalid_grade_boundaries' );
			}
			$previous = $value;
		}

		return true;
	}

	/**
	 * Save the selected grade system and its validated boundaries for one course.
	 *
	 * @param int $course_id Course post ID.
	 * @return void
	 */
	public static function save_course_settings( $course_id ) {
		$system_id = self::posted_id( 'grade_system_id' );
		if ( ! $system_id ) {
			delete_post_meta( $course_id, self::COURSE_SYSTEM );
			delete_post_meta( $course_id, self::COURSE_BOUNDS );
			return;
		}

		update_post_meta( $course_id, self::COURSE_SYSTEM, $system_id );
		if ( 'percentage' === self::system_type( $system_id ) ) {
			delete_post_meta( $course_id, self::COURSE_BOUNDS );
			return;
		}

		$boundaries = array();
		foreach ( self::posted_boundaries( $system_id ) as $index => $boundary ) {
			$boundaries[ absint( $index ) ] = (float) $boundary;
		}
		update_post_meta( $course_id, self::COURSE_BOUNDS, $boundaries );
	}

	/**
	 * Return a course's configured grade boundaries.
	 *
	 * This is the course-level default which a future assessment can override.
	 *
	 * @param int $course_id Course post ID.
	 * @return array
	 */
	public static function course_boundaries( $course_id ) {
		$boundaries = get_post_meta( $course_id, self::COURSE_BOUNDS, true );
		return is_array( $boundaries ) ? $boundaries : array();
	}


	/**
	 * Return the complete current grading context for one Course.
	 *
	 * This value is intentionally serialisable. Premium coursework snapshots it
	 * when feedback is released, so later Course boundary changes cannot alter
	 * historic outcomes.
	 *
	 * @param int $course_id Course post ID.
	 * @return array
	 */
	public static function grading_context_for_course( $course_id ) {
		$course_id = absint( $course_id );
		$system_id = absint( get_post_meta( $course_id, self::COURSE_SYSTEM, true ) );
		if ( ! $course_id || 'tutorhelper_course' !== get_post_type( $course_id ) || ! $system_id ) {
			return array();
		}
		$system = get_post( $system_id );
		if ( ! $system || 'th_lms_grade_system' !== $system->post_type || 'publish' !== $system->post_status ) {
			return array();
		}
		$type = self::system_type( $system_id );
		$labels = self::grade_labels( $system_id );
		$boundaries = self::course_boundaries( $course_id );
		$context = array(
			'course_id'          => $course_id,
			'course_title'       => get_the_title( $course_id ),
			'grade_system_id'    => $system_id,
			'grade_system_title' => $system->post_title,
			'type'               => $type,
			'labels'             => $labels,
			'boundaries'         => $boundaries,
		);
		$context['version'] = hash( 'sha256', wp_json_encode( $context ) );
		return $context;
	}

	/**
	 * Calculate an assessment result from a Course grade system.
	 *
	 * A supplied context is an immutable snapshot. This lets assessment attempts
	 * retain the boundaries that applied when they started, while older records
	 * safely fall back to the current Course configuration.
	 *
	 * @param int   $course_id Course ID.
	 * @param float $awarded   Awarded marks.
	 * @param float $available Available marks.
	 * @param array $context   Optional snapshotted grading context.
	 * @return array
	 */
	public static function grade_result_for_course( $course_id, $awarded, $available, $context = array() ) {
		$available = (float) $available;
		if ( $available <= 0 ) {
			return array();
		}

		$context = is_array( $context ) && ! empty( $context ) ? $context : self::grading_context_for_course( $course_id );
		$percentage = (int) round( ( (float) $awarded / $available ) * 100 );
		$result = array(
			'course_id'    => absint( $course_id ),
			'awarded_mark' => (float) $awarded,
			'available'    => $available,
			'percentage'   => $percentage,
			'grade_label'  => '',
			'context'      => $context,
		);

		if ( 'grades' !== ( $context['type'] ?? '' ) ) {
			return $result;
		}

		foreach ( (array) ( $context['labels'] ?? array() ) as $index => $label ) {
			if ( isset( $context['boundaries'][ $index ] ) && $percentage >= (float) $context['boundaries'][ $index ] ) {
				$result['grade_label'] = sanitize_text_field( $label );
				break;
			}
		}

		return $result;
	}

	/**
	 * Format a calculated course grade for learner and tutor displays.
	 *
	 * @param array $result Calculated assessment result.
	 * @return string
	 */
	public static function grade_result_label( $result ) {
		if ( ! is_array( $result ) || ! isset( $result['percentage'] ) ) {
			return '';
		}
		$percentage = (int) round( (float) $result['percentage'] );
		$formatted = (string) $percentage;
		$parts = array( $formatted . '%' );
		if ( ! empty( $result['grade_label'] ) ) {
			$parts[] = __( 'Grade', 'tutorhelper-lms' ) . ' ' . $result['grade_label'];
		}
		return implode( ' · ', $parts );
	}

	/**
	 * Save one reusable grade system.
	 *
	 * @return void
	 */
	public static function save() {
		self::require_tutor();
		check_admin_referer( self::SAVE_ACTION );

		$entity_id = self::posted_id( 'entity_id' );
		$title     = sanitize_text_field( self::posted_value( 'title' ) );
		$type      = self::posted_key( 'system_type' );
		$type      = in_array( $type, array( 'grades', 'percentage' ), true ) ? $type : 'grades';
		$labels    = self::posted_grade_labels();

		if ( '' === $title || ( 'grades' === $type && empty( $labels ) ) ) {
			self::redirect( 'missing_details', $entity_id );
		}

		$data = array(
			'post_type'   => 'th_lms_grade_system',
			'post_title'  => $title,
			'post_status' => 'publish',
		);
		if ( $entity_id ) {
			$data['ID'] = $entity_id;
			$post_id = wp_update_post( wp_slash( $data ), true );
		} else {
			$post_id = wp_insert_post( wp_slash( $data ), true );
		}

		if ( is_wp_error( $post_id ) || ! $post_id ) {
			if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
				if ( is_wp_error( $post_id ) ) {
					TutorHelper_LMS_Diagnostics::wp_error(
						'Grade system save failed.',
						$post_id,
						array(
							'operation' => $entity_id ? 'update_grade_system' : 'create_grade_system',
							'entity_id' => $entity_id,
							'post_type' => 'th_lms_grade_system',
						)
					);
				} else {
					TutorHelper_LMS_Diagnostics::error(
						'Grade system save did not return a post ID.',
						array(
							'operation'      => $entity_id ? 'update_grade_system' : 'create_grade_system',
							'entity_id'      => $entity_id,
							'post_type'      => 'th_lms_grade_system',
							'failure_reason' => 'empty_post_id',
						)
					);
				}
			}
			self::redirect( 'save_failed', $entity_id );
		}

		update_post_meta( $post_id, self::META_TYPE, $type );
		update_post_meta( $post_id, self::META_GRADES, 'percentage' === $type ? array() : $labels );
		self::redirect( 'saved' );
	}

	/**
	 * Delete a grade system only when no Course uses it.
	 *
	 * @return void
	 */
	public static function delete() {
		self::require_tutor();
		$system_id = self::posted_id( 'entity_id' );
		check_admin_referer( self::DELETE_ACTION . '_' . $system_id );

		if ( self::course_count( $system_id ) > 0 ) {
			self::redirect( 'in_use' );
		}

		$deleted = wp_trash_post( $system_id );
		if ( ! $deleted ) {
			if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
				TutorHelper_LMS_Diagnostics::error(
					'Grade system delete failed.',
					array(
						'operation'      => 'delete_grade_system',
						'entity_id'      => $system_id,
						'post_type'      => 'th_lms_grade_system',
						'failure_reason' => 'trash_post_failed',
					)
				);
			}
			self::redirect( 'delete_failed' );
		}
		self::redirect( 'deleted' );
	}

	/**
	 * Render the grade-system list.
	 *
	 * @param array $systems Grade system posts.
	 * @return void
	 */
	private static function render_system_table( $systems ) {
		?>
		<table class="widefat striped">
			<thead><tr>
				<th><?php esc_html_e( 'Grade system', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Grades', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Courses using it', 'tutorhelper-lms' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'tutorhelper-lms' ); ?></th>
			</tr></thead>
			<tbody>
				<?php if ( empty( $systems ) ) : ?>
					<tr><td colspan="4"><?php esc_html_e( 'No grade systems have been created yet.', 'tutorhelper-lms' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $systems as $system ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $system->post_title ); ?></strong></td>
							<td><?php echo esc_html( 'percentage' === self::system_type( $system->ID ) ? __( 'Percentage only', 'tutorhelper-lms' ) : implode( ', ', self::grade_labels( $system->ID ) ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( self::course_count( $system->ID ) ) ); ?></td>
							<td>
								<a href="<?php echo esc_url( add_query_arg( 'edit', $system->ID, self::tab_url() ) ); ?>"><?php esc_html_e( 'Edit', 'tutorhelper-lms' ); ?></a>
								<?php if ( 0 === self::course_count( $system->ID ) ) : ?>
									<form class="tutorhelper-lms-library-delete" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
										<input type="hidden" name="action" value="<?php echo esc_attr( self::DELETE_ACTION ); ?>" />
										<input type="hidden" name="entity_id" value="<?php echo esc_attr( $system->ID ); ?>" />
										<?php wp_nonce_field( self::DELETE_ACTION . '_' . $system->ID ); ?>
										<button type="submit" class="button-link-delete"><?php esc_html_e( 'Delete', 'tutorhelper-lms' ); ?></button>
									</form>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Return all active grade systems.
	 *
	 * @return array
	 */
	private static function systems() {
		return get_posts(
			array(
				'post_type'      => 'th_lms_grade_system',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
	}

	/**
	 * Return a system's grade labels.
	 *
	 * @param int $system_id Grade system post ID.
	 * @return array
	 */
	private static function grade_labels( $system_id ) {
		$labels = get_post_meta( $system_id, self::META_GRADES, true );
		return is_array( $labels ) ? array_values( array_filter( array_map( 'sanitize_text_field', $labels ) ) ) : array();
	}

	/**
	 * Return a grade system type.
	 *
	 * @param int $system_id Grade system post ID.
	 * @return string
	 */
	private static function system_type( $system_id ) {
		return 'percentage' === get_post_meta( $system_id, self::META_TYPE, true ) ? 'percentage' : 'grades';
	}

	/**
	 * Count published Courses linked to a system.
	 *
	 * @param int $system_id Grade system post ID.
	 * @return int
	 */
	private static function course_count( $system_id ) {
		$query = new WP_Query(
			array(
				'post_type'      => 'tutorhelper_course',
				'post_status'    => array( 'publish', 'draft', 'private', 'pending', 'future' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => self::COURSE_SYSTEM,
				'meta_value'     => absint( $system_id ),
			)
		);
		return absint( $query->found_posts );
	}

	/**
	 * Return sanitised grade labels supplied as lines of text.
	 *
	 * @return array
	 */
	private static function posted_grade_labels() {
		$raw = self::posted_value( 'grade_labels' );
		$labels = preg_split( '/\r\n|\r|\n/', $raw );
		$labels = array_values( array_filter( array_map( 'sanitize_text_field', is_array( $labels ) ? $labels : array() ) ) );
		return array_values( array_unique( $labels ) );
	}

	/**
	 * Return boundary values posted for one system.
	 *
	 * @param int $system_id Grade system ID.
	 * @return array
	 */
	private static function posted_boundaries( $system_id ) {
		$values = isset( $_POST['grade_boundaries'][ $system_id ] ) && is_array( $_POST['grade_boundaries'][ $system_id ] ) ? wp_unslash( $_POST['grade_boundaries'][ $system_id ] ) : array();
		$boundaries = array();
		foreach ( $values as $index => $value ) {
			$boundaries[ absint( $index ) ] = is_scalar( $value ) ? trim( (string) $value ) : '';
		}
		ksort( $boundaries );
		return $boundaries;
	}

	private static function posted_value( $name ) {
		return isset( $_POST[ $name ] ) && ! is_array( $_POST[ $name ] ) ? (string) wp_unslash( $_POST[ $name ] ) : '';
	}

	private static function posted_key( $name ) {
		return sanitize_key( self::posted_value( $name ) );
	}

	private static function posted_id( $name ) {
		return absint( self::posted_value( $name ) );
	}

	private static function request_id( $name ) {
		return isset( $_GET[ $name ] ) && ! is_array( $_GET[ $name ] ) ? absint( wp_unslash( $_GET[ $name ] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only edit selection.
	}

	private static function tab_url() {
		return add_query_arg(
			array(
				'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG,
				'tab'  => 'grade-systems',
			),
			admin_url( 'admin.php' )
		);
	}

	private static function redirect( $notice, $edit_id = 0 ) {
		$url = self::tab_url();
		if ( $edit_id ) {
			$url = add_query_arg( 'edit', absint( $edit_id ), $url );
		}
		wp_safe_redirect( add_query_arg( 'lms_grade_system', sanitize_key( $notice ), $url ) );
		exit;
	}

	private static function render_notice() {
		$notice = isset( $_GET['lms_grade_system'] ) && ! is_array( $_GET['lms_grade_system'] ) ? sanitize_key( wp_unslash( $_GET['lms_grade_system'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect notice.
		$messages = array(
			'saved'           => __( 'Grade system saved.', 'tutorhelper-lms' ),
			'deleted'         => __( 'Grade system deleted.', 'tutorhelper-lms' ),
			'missing_details' => __( 'Enter a grade system name and at least one grade label.', 'tutorhelper-lms' ),
			'in_use'          => __( 'This grade system is assigned to one or more Courses and cannot be deleted.', 'tutorhelper-lms' ),
			'save_failed'     => __( 'The grade system could not be saved. Please try again.', 'tutorhelper-lms' ),
			'delete_failed'   => __( 'The grade system could not be deleted. Please try again.', 'tutorhelper-lms' ),
		);
		if ( isset( $messages[ $notice ] ) ) {
			$class = in_array( $notice, array( 'saved', 'deleted' ), true ) ? 'notice-success' : 'notice-error';
			echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . esc_html( $messages[ $notice ] ) . '</p></div>';
		}
	}

	private static function require_tutor() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage grade systems.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
	}
}
