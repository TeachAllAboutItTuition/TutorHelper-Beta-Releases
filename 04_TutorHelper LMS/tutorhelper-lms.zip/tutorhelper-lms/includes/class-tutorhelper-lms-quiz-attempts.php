<?php
/**
 * Core Quiz attempt snapshots.
 *
 * @package TutorHelper_LMS
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_LMS_Quiz_Attempts {
	/**
	 * Create or return the student's resumable attempt for one authorised Course Quiz placement.
	 *
	 * Q4a intentionally creates snapshots only; answer input and automatic marking follow in Q4b.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param object $placement Course Quiz placement.
	 * @return object|WP_Error
	 */
	public static function create_or_resume( $student_user_id, $placement, $attempt_context = array() ) {
		global $wpdb;
		$attempts = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$question_placements = TutorHelper_LMS_Free_Database::table( 'quiz_question_placements' );
		$question_versions = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		if ( ! $attempts || ! $placement ) { return new WP_Error( 'quiz_attempt_unavailable', __( 'This Quiz is not currently available.', 'tutorhelper-lms' ) ); }

		$attempt_context = is_array( $attempt_context ) ? $attempt_context : array();
		$open_attempts = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$attempts} WHERE student_user_id = %d AND course_quiz_placement_id = %d AND status = %s ORDER BY id DESC", $student_user_id, $placement->id, 'in_progress' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Retrieves only compatible resumable attempts for this student.
		$open = null;
		foreach ( (array) $open_attempts as $candidate ) {
			$candidate_snapshot = json_decode( (string) $candidate->snapshot_json, true );
			$candidate_context = is_array( $candidate_snapshot['attempt_context'] ?? null ) ? $candidate_snapshot['attempt_context'] : array();
			if ( $candidate_context === $attempt_context ) {
				$open = $candidate;
				break;
			}
		}
		if ( $open ) {
			// Earlier Q4 snapshots stored a zero pass mark before Course defaults were available.
			// Upgrade only that legacy/inherited value; explicit non-zero Course overrides stay pinned.
			$open_snapshot = json_decode( (string) $open->snapshot_json, true );
			$open_definition = self::quiz_definition( $placement->quiz_version_id );
			$placement_pass_mark = isset( $placement->pass_mark_override ) ? $placement->pass_mark_override : null;
			$effective_pass_mark = ( null === $placement_pass_mark || '' === $placement_pass_mark || 0 === absint( $placement_pass_mark ) ) ? absint( $open_definition['pass_mark'] ?? 0 ) : absint( $placement_pass_mark );
			if ( is_array( $open_snapshot ) && 0 === absint( $open_snapshot['pass_mark'] ?? 0 ) && $effective_pass_mark > 0 ) {
				$open_snapshot['pass_mark'] = $effective_pass_mark;
				$wpdb->update( $attempts, array( 'snapshot_json' => wp_json_encode( $open_snapshot ) ), array( 'id' => absint( $open->id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Migrates an in-progress legacy Quiz snapshot to its inherited Course pass mark.
				$open->snapshot_json = wp_json_encode( $open_snapshot );
			}
			return $open;
		}

		$definition = self::quiz_definition( $placement->quiz_version_id );
		$policy = 'inherit' === $placement->attempt_policy_override ? sanitize_key( $definition['attempt_policy'] ?? 'unlimited' ) : sanitize_key( $placement->attempt_policy_override );
		$attempt_limit = 'single' === $policy ? 1 : ( 'limited' === $policy ? max( 1, absint( $definition['attempt_limit'] ?? 1 ) ) : 0 );
		$completed = absint( $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$attempts} WHERE student_user_id = %d AND course_quiz_placement_id = %d AND status = %s", $student_user_id, $placement->id, 'completed' ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Enforces completed-attempt limit only. Drafts are resumable and do not consume a limit.
		if ( $attempt_limit > 0 && $completed >= $attempt_limit ) {
			$message = 1 === $attempt_limit
				? __( 'You have completed the available Quiz attempt.', 'tutorhelper-lms' )
				: sprintf(
					/* translators: %d: Maximum number of completed Quiz attempts. */
					__( 'You have completed all %d available Quiz attempts.', 'tutorhelper-lms' ),
					$attempt_limit
				);
			return new WP_Error( 'quiz_attempt_limit', $message );
		}

		$questions = $wpdb->get_results( $wpdb->prepare( "SELECT p.question_id, p.question_version_id, p.sort_order, p.mark_override, p.settings_json, v.definition_json, v.max_marks FROM {$question_placements} p INNER JOIN {$question_versions} v ON v.id = p.question_version_id WHERE p.quiz_version_id = %d ORDER BY p.sort_order ASC", $placement->quiz_version_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Snapshots immutable Question definitions for one owned attempt.
		// Adaptive Practice is the only variable-size Question selection. Its Premium
		// filter takes the full selected pool and writes one immutable attempt snapshot.
		$questions = apply_filters( 'tutorhelper_lms_quiz_attempt_snapshot_questions', $questions, $definition, $placement, $student_user_id );
		if ( is_wp_error( $questions ) ) {
			return $questions;
		}
		$questions = is_array( $questions ) ? array_values( $questions ) : array();
		if ( empty( $questions ) ) {
			return new WP_Error( 'quiz_attempt_unavailable', __( 'This Quiz has no available Questions for this attempt.', 'tutorhelper-lms' ) );
		}

		// The displayed order is part of the immutable attempt snapshot. This
		// prevents answer placement from becoming a clue while keeping a draft
		// stable when the learner resumes or reviews it.
		$questions = self::shuffle_choice_options( $questions );
		$placement_pass_mark = isset( $placement->pass_mark_override ) ? $placement->pass_mark_override : null;
		$pass_mark = ( null === $placement_pass_mark || '' === $placement_pass_mark || 0 === absint( $placement_pass_mark ) ) ? absint( $definition['pass_mark'] ?? 0 ) : absint( $placement_pass_mark );
		$delivery_mode = 'inherit' === ( $placement->delivery_mode_override ?? 'inherit' ) ? ( $definition['delivery_mode'] ?? 'all' ) : $placement->delivery_mode_override;
		$definition['delivery_mode'] = in_array( $delivery_mode, array( 'all', 'question', 'section' ), true ) ? $delivery_mode : 'all';
		$result_release = 'inherit' === ( $placement->result_release_override ?? 'inherit' ) ? ( $definition['result_release'] ?? 'immediate' ) : $placement->result_release_override;
		$definition['result_release'] = 'tutor' === $result_release ? 'tutor' : 'immediate';
		$selected_question_ids = array();
		foreach ( $questions as $question ) {
			$selected_question_ids[] = absint( is_object( $question ) ? ( $question->question_id ?? 0 ) : ( $question['question_id'] ?? 0 ) );
		}
		$selected_question_ids = array_values( array_filter( array_unique( $selected_question_ids ) ) );
		$course_question_topics = array_values(
			array_filter(
				self::question_topics( $placement->id ),
				static function( $mapping ) use ( $selected_question_ids ) {
					return in_array( absint( $mapping['question_id'] ?? 0 ), $selected_question_ids, true );
				}
			)
		);
		$course_grading_context = class_exists( 'TutorHelper_LMS_Grade_Systems' ) ? TutorHelper_LMS_Grade_Systems::grading_context_for_course( absint( $placement->course_id ) ) : array();
		$snapshot = array( 'quiz' => $definition, 'attempt_policy' => $policy, 'attempt_limit' => $attempt_limit, 'pass_mark' => $pass_mark, 'questions' => $questions, 'course_question_topics' => $course_question_topics, 'course_grading_context' => $course_grading_context );
		if ( ! empty( $attempt_context ) ) {
			$snapshot['attempt_context'] = $attempt_context;
		}
		$snapshot = apply_filters( 'tutorhelper_lms_quiz_attempt_snapshot', $snapshot, $placement, $student_user_id );
		$number = $completed + 1;
		$inserted = $wpdb->insert( $attempts, array( 'student_user_id' => $student_user_id, 'course_id' => $placement->course_id, 'topic_id' => $placement->topic_id, 'course_quiz_placement_id' => $placement->id, 'quiz_id' => $placement->quiz_id, 'quiz_version_id' => $placement->quiz_version_id, 'attempt_number' => $number, 'attempt_policy' => $policy, 'status' => 'in_progress', 'snapshot_json' => wp_json_encode( $snapshot ), 'started_at' => current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Creates durable immutable Core attempt snapshot.
		return $inserted ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$attempts} WHERE id = %d", $wpdb->insert_id ) ) : new WP_Error( 'quiz_attempt_save_failed', __( 'Your Quiz could not be started. Please try again.', 'tutorhelper-lms' ) );
	}


	/**
	 * Store a student's in-progress draft answers for the snapshotted Questions.
	 *
	 * @param object $attempt Owned in-progress attempt.
	 * @param array  $responses Submitted answers keyed by Question ID.
	 * @return bool
	 */
	public static function save_draft_responses( $attempt, $responses, $visible_question_ids = array() ) {
		global $wpdb;
		if ( ! is_object( $attempt ) || 'in_progress' !== (string) $attempt->status || ! is_array( $responses ) || ! is_user_logged_in() || get_current_user_id() !== absint( $attempt->student_user_id ) ) {
			return false;
		}
		$attempts_table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$table          = TutorHelper_LMS_Free_Database::table( 'quiz_attempt_responses' );
		$current_status = $attempts_table ? $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$attempts_table} WHERE id = %d AND student_user_id = %d", absint( $attempt->id ), get_current_user_id() ) ) : '';
		if ( 'in_progress' !== (string) $current_status ) {
			return false;
		}
		$snapshot = json_decode( (string) $attempt->snapshot_json, true );
		$questions = is_array( $snapshot['questions'] ?? null ) ? $snapshot['questions'] : array();
		if ( ! $table ) {
			return false;
		}
		$visible_question_ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $visible_question_ids ) ) ) );
		foreach ( $questions as $question ) {
			$question_id = absint( is_array( $question ) ? ( $question['question_id'] ?? 0 ) : ( $question->question_id ?? 0 ) );
			$version_id  = absint( is_array( $question ) ? ( $question['question_version_id'] ?? 0 ) : ( $question->question_version_id ?? 0 ) );
			if ( ! $question_id || ! $version_id ) {
				continue;
			}
			// In question-by-question and section delivery the form contains only
			// the visible Question(s). Preserve every other saved answer rather
			// than replacing it with an empty value on this request.
			if ( ! empty( $visible_question_ids ) && ! in_array( $question_id, $visible_question_ids, true ) ) {
				continue;
			}
			if ( empty( $visible_question_ids ) && ! array_key_exists( $question_id, $responses ) ) {
				continue;
			}
			$raw_response = $responses[ $question_id ] ?? '';
			/**
			 * Extensions may safely sanitise response models that require a
			 * limited HTML subset, such as a Premium long-form response.
			 *
			 * @param mixed  $sanitised_response Null uses Core plain-text sanitation.
			 * @param mixed  $raw_response       Posted response value.
			 * @param array  $question           Pinned Question snapshot.
			 * @param object $attempt            Owned Quiz attempt.
			 */
			$response = apply_filters( 'tutorhelper_lms_sanitise_quiz_response', null, $raw_response, $question, $attempt );
			if ( null === $response ) {
				$definition_json = is_array( $question ) ? ( $question['definition_json'] ?? '' ) : ( $question->definition_json ?? '' );
				$definition      = json_decode( (string) $definition_json, true );
				$type            = sanitize_key( is_array( $definition ) ? ( $definition['question_type'] ?? '' ) : '' );
				if ( in_array( $type, array( 'sort_answer', 'matrix_sort' ), true ) ) {
					// These controls post a JSON collection. Decode before sanitising:
					// applying KSES to the JSON itself would corrupt image attributes.
					$decoded = is_string( $raw_response ) ? json_decode( $raw_response, true ) : $raw_response;
					$response = is_array( $decoded ) ? map_deep( $decoded, 'wp_kses_post' ) : array();
				} else {
					$response = is_array( $raw_response ) ? map_deep( wp_unslash( $raw_response ), 'sanitize_text_field' ) : sanitize_textarea_field( wp_unslash( $raw_response ) );
				}
			}
			$status = self::response_has_value( $response ) ? 'answered' : 'unanswered';
			$saved = $wpdb->replace(
				$table,
				array(
					'attempt_id'          => absint( $attempt->id ),
					'question_id'         => $question_id,
					'question_version_id' => $version_id,
					'response_json'       => wp_json_encode( $response ),
					'auto_mark_json'      => wp_json_encode( array() ),
					'status'              => $status,
					'updated_at'          => current_time( 'mysql', true ),
				),
				array( '%d', '%d', '%d', '%s', '%s', '%s', '%s' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Saves only the current student's owned attempt draft.
			if ( false === $saved ) {
				return false;
			}
		}
		return true;
	}


	/**
	 * Save final responses, automatically mark objective Questions and complete the attempt.
	 *
	 * @param object $attempt Attempt owned by the current student.
	 * @param array  $responses Submitted answers.
	 * @return array|WP_Error Completion summary.
	 */
	public static function submit( $attempt, $responses, $visible_question_ids = array() ) {
		global $wpdb;

		if ( ! is_object( $attempt ) || ! is_array( $responses ) || ! is_user_logged_in() || get_current_user_id() !== absint( $attempt->student_user_id ) ) {
			return new WP_Error( 'quiz_attempt_not_open', __( 'This Quiz attempt is not available for submission.', 'tutorhelper-lms' ) );
		}

		$attempts_table  = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$responses_table = TutorHelper_LMS_Free_Database::table( 'quiz_attempt_responses' );
		if ( ! $attempts_table || ! $responses_table || false === $wpdb->query( 'START TRANSACTION' ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Starts an atomic Quiz finalisation.
			return self::submission_error( $attempt, 'transaction_start_failed' );
		}

		$locked_attempt = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$attempts_table} WHERE id = %d AND student_user_id = %d FOR UPDATE",
				absint( $attempt->id ),
				get_current_user_id()
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Locks one student-owned attempt against duplicate completion.

		if ( ! $locked_attempt ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Closes an unsuccessful transaction.
			return self::submission_error( $attempt, 'attempt_not_found' );
		}

		if ( 'completed' === (string) $locked_attempt->status ) {
			$summary = self::completion_summary( $locked_attempt, true );
			if ( false === $wpdb->query( 'COMMIT' ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Completes the read-only idempotency transaction.
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Rolls back an unsuccessful commit.
				return self::submission_error( $attempt, 'completed_attempt_commit_failed' );
			}
			return $summary;
		}

		if ( 'in_progress' !== (string) $locked_attempt->status ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Closes an attempt in an unexpected state.
			return self::submission_error( $attempt, 'attempt_not_open' );
		}

		if ( ! self::save_draft_responses( $locked_attempt, $responses, $visible_question_ids ) ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Never retain partial final responses.
			return self::submission_error( $attempt, 'response_save_failed' );
		}

		$snapshot  = json_decode( (string) $locked_attempt->snapshot_json, true );
		$questions = is_array( $snapshot['questions'] ?? null ) ? $snapshot['questions'] : array();
		$stored    = self::draft_responses( $locked_attempt->id );
		$total     = 0;
		$available = 0;
		$now       = current_time( 'mysql', true );
		$time_taken_seconds = self::seconds_between( $locked_attempt->started_at, $now );
		$release_mode = self::result_release_mode( $snapshot );
		$has_manual_questions = self::snapshot_has_manual_questions( $snapshot );

		foreach ( $questions as $question ) {
			$question_id = absint( $question['question_id'] ?? 0 );
			$version_id  = absint( $question['question_version_id'] ?? 0 );
			if ( ! $question_id || ! $version_id ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Rejects an incomplete immutable snapshot.
				return self::submission_error( $attempt, 'invalid_question_snapshot' );
			}

			$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
			$definition = is_array( $definition ) ? $definition : array();
			$marks      = null === ( $question['mark_override'] ?? null ) ? absint( $question['max_marks'] ?? 0 ) : absint( $question['mark_override'] );
			$answer     = array_key_exists( $question_id, $stored ) ? $stored[ $question_id ] : '';
			$result     = self::mark_response( $definition, $answer, $marks );

			$total     += absint( $result['marks'] );
			$available += absint( $result['available'] ?? $marks );

			$written = $wpdb->replace(
				$responses_table,
				array(
					'attempt_id'          => absint( $locked_attempt->id ),
					'question_id'         => $question_id,
					'question_version_id' => $version_id,
					'response_json'       => wp_json_encode( $answer ),
					'auto_mark_json'      => wp_json_encode( $result ),
					'status'              => sanitize_key( $result['status'] ),
					'updated_at'          => $now,
				),
				array( '%d', '%d', '%d', '%s', '%s', '%s', '%s' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Atomically writes the raw response and its automatic mark.

			if ( false === $written ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Never retain a partly marked attempt.
				return self::submission_error( $attempt, 'mark_save_failed' );
			}
		}

		$finalised = $wpdb->update(
			$attempts_table,
			array(
				'status'              => 'completed',
				'submitted_at'        => $now,
				'completed_at'        => $now,
				'time_taken_seconds'  => $time_taken_seconds,
				// Manually marked Premium responses always remain private until a
				// tutor has entered marks and explicitly released the result.
				'results_released_at' => 'immediate' === $release_mode && ! $has_manual_questions ? $now : null,
			),
			array(
				'id'     => absint( $locked_attempt->id ),
				'status' => 'in_progress',
			),
			array( '%s', '%s', '%s', '%d', '%s' ),
			array( '%d', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Compares the expected state before completing an immutable attempt.

		if ( 1 !== (int) $finalised ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Leaves the attempt resumable if its state changed.
			return self::submission_error( $attempt, 'attempt_finalise_failed' );
		}

		if ( false === $wpdb->query( 'COMMIT' ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Makes responses, marks and completion visible together.
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Best-effort cleanup after a failed commit.
			return self::submission_error( $attempt, 'transaction_commit_failed' );
		}

		$passed = apply_filters( 'tutorhelper_lms_quiz_attempt_passed', $total >= absint( $snapshot['pass_mark'] ?? 0 ), $total, $available, $snapshot );
		$summary = array(
			'marks'             => $total,
			'available'         => $available,
			'passed'            => (bool) $passed,
			'already_completed' => false,
		);
		// Premium integrations may record a submitted immutable attempt, but may
		// never change the completed responses or score in this transaction.
		do_action( 'tutorhelper_lms_quiz_attempt_submitted', $locked_attempt, $summary );
		return $summary;
	}

	/**
	 * Return the immutable result-release policy for one attempt snapshot.
	 *
	 * @param array $snapshot Attempt snapshot.
	 * @return string
	 */
	private static function result_release_mode( $snapshot ) {
		$quiz = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
		return 'tutor' === sanitize_key( $quiz['result_release'] ?? 'immediate' ) ? 'tutor' : 'immediate';
	}

	/**
	 * Whether this snapshot includes an extension-provided manually marked type.
	 *
	 * @param array $snapshot Immutable attempt snapshot.
	 * @return bool
	 */
	private static function snapshot_has_manual_questions( $snapshot ) {
		$types = array_values( array_unique( array_map( 'sanitize_key', (array) apply_filters( 'tutorhelper_lms_manual_question_types', array() ) ) ) );
		if ( empty( $types ) ) {
			return false;
		}
		foreach ( (array) ( $snapshot['questions'] ?? array() ) as $question ) {
			$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
			if ( in_array( sanitize_key( is_array( $definition ) ? ( $definition['question_type'] ?? '' ) : '' ), $types, true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether a completed attempt may disclose marks, answers and feedback.
	 *
	 * @param object $attempt Attempt row.
	 * @return bool
	 */
	public static function results_released( $attempt ) {
		if ( ! is_object( $attempt ) || 'completed' !== (string) ( $attempt->status ?? '' ) ) {
			return false;
		}
		$snapshot = json_decode( (string) ( $attempt->snapshot_json ?? '' ), true );
		$released_at = trim( (string) ( $attempt->results_released_at ?? '' ) );
		$snapshot = is_array( $snapshot ) ? $snapshot : array();
		return ( ! self::snapshot_has_manual_questions( $snapshot ) && 'immediate' === self::result_release_mode( $snapshot ) ) || ( '' !== $released_at && '0000-00-00 00:00:00' !== $released_at );
	}

	/**
	 * Release one completed result whose immutable policy is tutor release.
	 *
	 * Callers must perform their own tutor authorisation before invoking this
	 * method. The conditional update prevents a duplicate release request from
	 * changing an already released immutable result.
	 *
	 * @param int $attempt_id Quiz attempt ID.
	 * @return true|WP_Error
	 */
	public static function release_results( $attempt_id ) {
		global $wpdb;

		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$attempt = $table ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", absint( $attempt_id ) ) ) : null; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- releases one immutable result.
		if ( ! $attempt || 'completed' !== (string) $attempt->status ) {
			return new WP_Error( 'quiz_attempt_unavailable', __( 'This Quiz result is not available for release.', 'tutorhelper-lms' ) );
		}
		$snapshot = json_decode( (string) $attempt->snapshot_json, true );
		$snapshot = is_array( $snapshot ) ? $snapshot : array();
		if ( ( 'tutor' !== self::result_release_mode( $snapshot ) && ! self::snapshot_has_manual_questions( $snapshot ) ) || self::results_released( $attempt ) ) {
			return new WP_Error( 'quiz_result_not_held', __( 'This Quiz result is not awaiting release.', 'tutorhelper-lms' ) );
		}

		$released = $wpdb->update(
			$table,
			array( 'results_released_at' => current_time( 'mysql', true ) ),
			array(
				'id'                  => absint( $attempt->id ),
				'status'              => 'completed',
				'results_released_at' => null,
			),
			array( '%s' ),
			array( '%d', '%s', null )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- marks one held result as released.

		return 1 === (int) $released ? true : new WP_Error( 'quiz_result_release_failed', __( 'The Quiz result could not be released. Please try again.', 'tutorhelper-lms' ) );
	}

	/**
	 * Return the stored result of an already-completed attempt.
	 *
	 * @param object $attempt Completed owned attempt.
	 * @param bool   $already_completed Whether this was a repeat submission.
	 * @return array
	 */
	private static function completion_summary( $attempt, $already_completed ) {
		$score = self::attempt_score( absint( $attempt->id ) );
		return array(
			'marks'             => absint( $score['marks'] ?? 0 ),
			'available'         => absint( $score['available'] ?? 0 ),
			'passed'            => 'pass' === ( $score['outcome'] ?? '' ),
			'already_completed' => (bool) $already_completed,
		);
	}

	/**
	 * Log a safe submission failure and return one learner-safe response.
	 *
	 * @param object $attempt Attempt whose submission failed.
	 * @param string $reason Safe technical failure reason.
	 * @return WP_Error
	 */
	private static function submission_error( $attempt, $reason ) {
		if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			TutorHelper_LMS_Diagnostics::error(
				'Quiz attempt submission failed.',
				array(
					'operation'      => 'quiz_attempt_submit',
					'entity_id'      => absint( $attempt->id ?? 0 ),
					'failure_reason' => sanitize_key( $reason ),
				)
			);
		}
		return new WP_Error( 'quiz_attempt_submit_failed', __( 'Your Quiz could not be submitted. Please try again.', 'tutorhelper-lms' ) );
	}

	private static function mark_response( $definition, $response, $marks ) {
		$type = sanitize_key( $definition['question_type'] ?? '' );
		$manual_types = array_values( array_unique( array_map( 'sanitize_key', (array) apply_filters( 'tutorhelper_lms_manual_question_types', array() ) ) ) );
		if ( in_array( $type, $manual_types, true ) ) {
			return array(
				'marks'          => 0,
				'available'      => absint( $marks ),
				'correct'        => null,
				'status'         => 'awaiting_marking',
				'feedback'       => '',
				'details'        => array(),
				'marking_source' => 'manual',
			);
		}
		$answers = is_array( $definition['answers'] ?? null ) ? $definition['answers'] : array();
		$settings = is_array( $definition['settings'] ?? null ) ? $definition['settings'] : array();
		if ( in_array( $type, array( 'sort_answer', 'matrix_sort' ), true ) && is_string( $response ) ) {
			$decoded_response = json_decode( $response, true );
			if ( is_array( $decoded_response ) ) { $response = $decoded_response; }
		}
		$correct = false; $awarded = 0; $available = $marks; $details = array();
		if ( 'single_choice' === $type ) {
			$correct = (string) $response === (string) ( $answers['correct'][0] ?? '' );
			$details = array( (string) $response => array( 'selected' => true, 'correct' => $correct ) );
		} elseif ( 'multiple_choice' === $type ) {
			$given = array_values( array_unique( array_map( 'strval', is_array( $response ) ? $response : array() ) ) );
			$wanted = array_values( array_unique( array_map( 'strval', $answers['correct'] ?? array() ) ) );
			sort( $given ); sort( $wanted );
			$correct = $given === $wanted;
			$hits = count( array_intersect( $given, $wanted ) );
			$awarded = $wanted ? (int) floor( $marks * $hits / count( $wanted ) ) : 0;
			foreach ( array_unique( array_merge( $given, $wanted ) ) as $option ) { $details[ $option ] = array( 'selected' => in_array( $option, $given, true ), 'correct' => in_array( $option, $wanted, true ) ); }
		} elseif ( 'free_answer' === $type ) {
			$given = trim( (string) $response );
			foreach ( (array) ( $answers['accepted'] ?? array() ) as $accepted ) {
				$match = ! empty( $settings['match_case'] ) ? $given === trim( $accepted ) : 0 === strcasecmp( $given, trim( $accepted ) );
				if ( $match ) { $correct = true; break; }
			}
		} elseif ( 'sort_answer' === $type ) {
			$items = array_values( (array) ( $answers['items'] ?? array() ) );
			$given = array_values( (array) $response );
			$awardable = max( 0, count( $items ) - ( ! empty( $settings['exclude_final_item_mark'] ) ? 1 : 0 ) );
			$available = $awardable;
			$hits = 0;
			foreach ( $items as $index => $item ) {
				$is_correct = (string) ( $given[ $index ] ?? '' ) === (string) $item;
				$details[ $index ] = array( 'correct' => $is_correct, 'awardable' => $index < $awardable );
				if ( $is_correct && $index < $awardable ) { $hits++; }
			}
			$correct = $hits === $awardable;
			$awarded = $hits;
		} elseif ( 'matrix_sort' === $type ) {
			$pairs = array_values( (array) ( $answers['pairs'] ?? array() ) );
			$given = is_array( $response ) ? $response : array();
			$available = count( $pairs );
			$hits = 0;
			foreach ( $pairs as $index => $pair ) {
				$is_correct = (string) ( $given[ $index ] ?? '' ) === (string) ( $pair['right'] ?? '' );
				$details[ $index ] = array( 'correct' => $is_correct );
				if ( $is_correct ) { $hits++; }
			}
			$correct = $hits === $available;
			$awarded = $hits;
		} elseif ( 'cloze' === $type ) {
			$blanks = TutorHelper_LMS_Question_Bank::cloze_blanks( $answers['blanks'] ?? array() );
			$cloze_scoring = TutorHelper_LMS_Question_Bank::cloze_scoring_settings( $settings );
			$given = is_array( $response ) ? $response : array();
			$available = TutorHelper_LMS_Question_Bank::cloze_marks_total( $blanks, $cloze_scoring );
			$awarded = 0;
			$correct_count = 0;
			foreach ( $blanks as $index => $blank ) {
				$blank_number = $index + 1;
				$submitted = trim( (string) ( $given[ $blank_number ] ?? '' ) );
				$is_correct = false;
				foreach ( (array) ( $blank['accepted'] ?? array() ) as $accepted ) {
					if ( 0 === strcasecmp( $submitted, trim( (string) $accepted ) ) ) {
						$is_correct = true;
						break;
					}
				}
				$marks_for_blank = absint( $blank['marks'] ?? 0 );
				$details[ $blank_number ] = array( 'correct' => $is_correct, 'marks' => $marks_for_blank, 'blank_id' => (string) ( $blank['id'] ?? '' ) );
				if ( $is_correct ) {
					$correct_count++;
					$awarded += $marks_for_blank;
				}
			}
			$correct = $correct_count === count( $blanks );
			if ( 'all_or_nothing' === $cloze_scoring['cloze_marking_mode'] ) {
				$awarded = $correct ? $available : 0;
			}
		} elseif ( 'assessment' === $type ) {
			return array( 'marks' => 0, 'available' => 0, 'correct' => null, 'status' => 'ungraded', 'feedback' => '', 'details' => array(), 'marking_source' => 'automatic' );
		}
		if ( $correct && ! in_array( $type, array( 'multiple_choice', 'sort_answer', 'matrix_sort', 'cloze' ), true ) ) { $awarded = $available; }
		$status = $correct ? 'correct' : ( $awarded ? 'partial' : 'incorrect' );
		return array( 'marks' => $awarded, 'available' => $available, 'correct' => $correct, 'status' => $status, 'feedback' => $correct ? ( $definition['correct_feedback'] ?? 'Correct!' ) : ( $definition['incorrect_feedback'] ?? "That wasn't quite right." ), 'details' => $details, 'marking_source' => 'automatic' );
	}

	/**
	 * Return whether a scalar or nested Quiz response contains an answer.
	 *
	 * @param mixed $response Response value.
	 * @return bool
	 */
	private static function response_has_value( $response ) {
		if ( is_array( $response ) ) {
			foreach ( $response as $value ) {
				if ( self::response_has_value( $value ) ) {
					return true;
				}
			}
			return false;
		}
		return '' !== trim( (string) $response );
	}

	/**
	 * Return saved draft responses keyed by Question ID.
	 *
	 * @param int $attempt_id Attempt ID.
	 * @return array
	 */
	public static function draft_responses( $attempt_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempt_responses' );
		if ( ! $table ) {
			return array();
		}
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT question_id, response_json FROM {$table} WHERE attempt_id = %d", absint( $attempt_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads student-owned draft responses for one rendered attempt.
		$responses = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$value = json_decode( (string) $row->response_json, true );
			$responses[ absint( $row->question_id ) ] = null === $value && JSON_ERROR_NONE !== json_last_error() ? '' : $value;
		}
		return $responses;
	}


	/**
	 * Return attempts owned by one student for a Course Quiz placement.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $placement_id Course Quiz placement ID.
	 * @return array
	 */
	public static function attempts_for_placement( $student_user_id, $placement_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		if ( ! $table ) { return array(); }
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE student_user_id = %d AND course_quiz_placement_id = %d ORDER BY attempt_number DESC, id DESC", absint( $student_user_id ), absint( $placement_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Lists only the current student's owned Course Quiz attempts.
	}

	/**
	 * Return one student-owned attempt for a Course Quiz placement.
	 *
	 * @param int $attempt_id Attempt ID.
	 * @param int $student_user_id Student user ID.
	 * @param int $placement_id Course Quiz placement ID.
	 * @return object|null
	 */
	public static function attempt_for_student( $attempt_id, $student_user_id, $placement_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		return $table ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND student_user_id = %d AND course_quiz_placement_id = %d", absint( $attempt_id ), absint( $student_user_id ), absint( $placement_id ) ) ) : null; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Verifies an attempt belongs to the current student and Course Quiz.
	}

	/**
	 * Return answer and marking data for a completed immutable attempt.
	 *
	 * @param int $attempt_id Attempt ID.
	 * @return array
	 */
	public static function reviewed_responses( $attempt_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempt_responses' );
		if ( ! $table ) { return array(); }
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT question_id, response_json, auto_mark_json, tutor_feedback, status FROM {$table} WHERE attempt_id = %d", absint( $attempt_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads immutable response and mark data for a student-owned review.
		$review = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$response = json_decode( (string) $row->response_json, true );
			$mark = json_decode( (string) $row->auto_mark_json, true );
			$mark = is_array( $mark ) ? $mark : array();
			$tutor_feedback = (string) ( $row->tutor_feedback ?? '' );
			if ( '' !== trim( $tutor_feedback ) ) {
				// This is an attempt-only override; the reusable Question feedback stays untouched.
				$mark['feedback'] = $tutor_feedback;
			}
			$review[ absint( $row->question_id ) ] = array(
				'answer'         => null === $response && JSON_ERROR_NONE !== json_last_error() ? '' : $response,
				'mark'           => $mark,
				'tutor_feedback' => $tutor_feedback,
				'status'         => sanitize_key( $row->status ),
			);
		}
		return $review;
	}

	/**
	 * Calculate stored automatic marks for a completed attempt.
	 *
	 * @param int $attempt_id Attempt ID.
	 * @return array{marks:int,available:int,ungraded:bool}
	 */
	public static function attempt_score( $attempt_id ) {
		global $wpdb;
		$marks = 0; $available = 0; $ungraded = false;
		$attempts = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$attempt = $attempts ? $wpdb->get_row( $wpdb->prepare( "SELECT snapshot_json FROM {$attempts} WHERE id = %d", absint( $attempt_id ) ) ) : null; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Supplies a legacy attempt's frozen maximum marks.
		$snapshot = $attempt ? json_decode( (string) $attempt->snapshot_json, true ) : array();
		$question_marks = array();
		foreach ( (array) ( $snapshot['questions'] ?? array() ) as $question ) {
			$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
			$question_marks[ absint( $question['question_id'] ?? 0 ) ] = self::question_available_marks( is_array( $definition ) ? $definition : array(), null === ( $question['mark_override'] ?? null ) ? absint( $question['max_marks'] ?? 0 ) : absint( $question['mark_override'] ) );
		}
		foreach ( self::reviewed_responses( $attempt_id ) as $question_id => $response ) {
			$mark = is_array( $response['mark'] ?? null ) ? $response['mark'] : array();
			$marks += absint( $mark['marks'] ?? 0 );
			$available += absint( $mark['available'] ?? ( $question_marks[ $question_id ] ?? 0 ) );
			if ( in_array( $mark['status'] ?? '', array( 'awaiting_marking', 'manual_pending' ), true ) ) { $ungraded = true; }
		}
		$pass_mark = absint( $snapshot['pass_mark'] ?? 0 );
		$passed = apply_filters( 'tutorhelper_lms_quiz_attempt_passed', $marks >= $pass_mark, $marks, $available, is_array( $snapshot ) ? $snapshot : array() );
		return array( 'marks' => $marks, 'available' => $available, 'ungraded' => $ungraded, 'pass_mark' => $pass_mark, 'outcome' => $ungraded ? 'pending' : ( $passed ? 'pass' : 'fail' ) );
	}

	/**
	 * Return automatic marks available for an immutable Question definition.
	 *
	 * @param array $definition Question definition.
	 * @param int   $fallback Stored Question maximum.
	 * @return int
	 */
	private static function question_available_marks( $definition, $fallback ) {
		$answers = is_array( $definition['answers'] ?? null ) ? $definition['answers'] : array();
		$settings = is_array( $definition['settings'] ?? null ) ? $definition['settings'] : array();
		$type = sanitize_key( $definition['question_type'] ?? '' );
		if ( 'matrix_sort' === $type ) { return count( $answers['pairs'] ?? array() ); }
		if ( 'cloze' === $type ) { return TutorHelper_LMS_Question_Bank::cloze_marks_total( $answers['blanks'] ?? array() ); }
		if ( 'sort_answer' === $type ) { return max( 0, count( $answers['items'] ?? array() ) - ( ! empty( $settings['exclude_final_item_mark'] ) ? 1 : 0 ) ); }
		return absint( $fallback );
	}

	/**
	 * Return the elapsed time retained for a Quiz attempt.
	 *
	 * Historic attempts safely fall back to their recorded start and completion
	 * timestamps; newly completed attempts persist the exact seconds.
	 *
	 * @param object $attempt Quiz attempt.
	 * @return int
	 */
	public static function time_taken_seconds( $attempt ) {
		if ( ! is_object( $attempt ) ) {
			return 0;
		}
		if ( null !== ( $attempt->time_taken_seconds ?? null ) && '' !== (string) $attempt->time_taken_seconds ) {
			return absint( $attempt->time_taken_seconds );
		}
		return self::seconds_between( $attempt->started_at ?? '', $attempt->submitted_at ?: ( $attempt->completed_at ?? '' ) );
	}

	/**
	 * Format an elapsed Quiz-attempt duration for learner and tutor displays.
	 *
	 * @param object $attempt Quiz attempt.
	 * @return string
	 */
	public static function time_taken_label( $attempt ) {
		$seconds = self::time_taken_seconds( $attempt );
		if ( $seconds < 60 ) {
			return sprintf( _n( '%d second', '%d seconds', $seconds, 'tutorhelper-lms' ), $seconds );
		}
		$minutes = (int) floor( $seconds / 60 );
		$remainder = $seconds % 60;
		return $remainder
			? sprintf( __( '%1$dm %2$ds', 'tutorhelper-lms' ), $minutes, $remainder )
			: sprintf( _n( '%d minute', '%d minutes', $minutes, 'tutorhelper-lms' ), $minutes );
	}

	/**
	 * Calculate a non-negative elapsed duration from two UTC database values.
	 *
	 * @param string $start UTC datetime.
	 * @param string $end UTC datetime.
	 * @return int
	 */
	private static function seconds_between( $start, $end ) {
		$started = strtotime( (string) $start . ' UTC' );
		$finished = strtotime( (string) $end . ' UTC' );
		return $started && $finished ? max( 0, $finished - $started ) : 0;
	}

	/**
	 * Summarise the learner's progress across the current Quiz Question pool.
	 *
	 * Completed attempts anywhere in the LMS count, matching adaptive practice
	 * selection: five correct responses means a Question is mastered.
	 *
	 * @param int $student_user_id Student ID.
	 * @param int $quiz_version_id Quiz version ID.
	 * @return array{mastered:int,attempted:int,unseen:int,total:int}
	 */
	public static function question_mastery_summary( $student_user_id, $quiz_version_id ) {
		global $wpdb;

		$empty = array( 'mastered' => 0, 'attempted' => 0, 'unseen' => 0, 'total' => 0 );
		$question_placements = TutorHelper_LMS_Free_Database::table( 'quiz_question_placements' );
		$attempts            = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$responses           = TutorHelper_LMS_Free_Database::table( 'quiz_attempt_responses' );
		if ( ! $question_placements || ! $attempts || ! $responses ) {
			return $empty;
		}

		$question_ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT question_id FROM {$question_placements} WHERE quiz_version_id = %d", absint( $quiz_version_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads the current Quiz pool for a learner-only progress summary.
		$question_ids = array_values( array_filter( array_map( 'absint', (array) $question_ids ) ) );
		if ( empty( $question_ids ) ) {
			return $empty;
		}

		$history = array();
		foreach ( $question_ids as $question_id ) {
			$history[ $question_id ] = array( 'attempts' => 0, 'correct' => 0 );
		}

		$placeholders = implode( ', ', array_fill( 0, count( $question_ids ), '%d' ) );
		$sql = "SELECT response.question_id, response.auto_mark_json
			FROM {$responses} response
			INNER JOIN {$attempts} attempt ON attempt.id = response.attempt_id
			WHERE attempt.student_user_id = %d
				AND attempt.status = 'completed'
				AND response.question_id IN ({$placeholders})";
		$args = array_merge( array( absint( $student_user_id ) ), $question_ids );
		$query = call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $sql ), $args ) );
		$rows = $wpdb->get_results( $query, ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Counts the current learner's historic automatic marks for this pool only.

		foreach ( (array) $rows as $row ) {
			$question_id = absint( $row['question_id'] ?? 0 );
			if ( ! isset( $history[ $question_id ] ) ) {
				continue;
			}
			$mark = json_decode( (string) ( $row['auto_mark_json'] ?? '' ), true );
			$mark = is_array( $mark ) ? $mark : array();
			$history[ $question_id ]['attempts']++;
			if ( 'correct' === sanitize_key( $mark['status'] ?? '' ) ) {
				$history[ $question_id ]['correct']++;
			}
		}

		$summary = $empty;
		$summary['total'] = count( $history );
		foreach ( $history as $progress ) {
			if ( absint( $progress['correct'] ) >= 5 ) {
				$summary['mastered']++;
			} elseif ( absint( $progress['attempts'] ) > 0 ) {
				$summary['attempted']++;
			} else {
				$summary['unseen']++;
			}
		}
		return $summary;
	}

	/**
	 * Shuffle single- and multiple-choice option display order without changing
	 * the original option keys used for saved answers and automatic marking.
	 *
	 * @param array $questions Attempt Question rows.
	 * @return array
	 */
	private static function shuffle_choice_options( $questions ) {
		foreach ( $questions as $index => $question ) {
			$definition_json = is_object( $question ) ? ( $question->definition_json ?? '' ) : ( $question['definition_json'] ?? '' );
			$definition = json_decode( (string) $definition_json, true );
			$definition = is_array( $definition ) ? $definition : array();
			$type = sanitize_key( $definition['question_type'] ?? '' );
			$options = is_array( $definition['answers']['options'] ?? null ) ? $definition['answers']['options'] : array();
			if ( ! in_array( $type, array( 'single_choice', 'multiple_choice' ), true ) || count( $options ) < 2 ) {
				continue;
			}

			$keys = array_keys( $options );
			shuffle( $keys );
			$shuffled = array();
			foreach ( $keys as $key ) {
				$shuffled[ $key ] = $options[ $key ];
			}
			$definition['answers']['options'] = $shuffled;
			if ( is_object( $question ) ) {
				$questions[ $index ]->definition_json = wp_json_encode( $definition );
			} else {
				$questions[ $index ]['definition_json'] = wp_json_encode( $definition );
			}
		}
		return $questions;
	}

	/**
	 * Return one immutable Quiz definition for read-only delivery decisions.
	 *
	 * @param int $version_id Quiz version ID.
	 * @return array
	 */
	public static function definition_for_version( $version_id ) {
		return self::quiz_definition( $version_id );
	}

	private static function quiz_definition( $version_id ) {
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'quiz_versions' );
		$json = $table ? $wpdb->get_var( $wpdb->prepare( "SELECT definition_json FROM {$table} WHERE id = %d", $version_id ) ) : ''; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads pinned Quiz definition.
		$data = json_decode( $json, true ); return is_array( $data ) ? $data : array();
	}
	private static function question_topics( $placement_id ) {
		global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'course_quiz_question_topics' ); if ( ! $table ) { return array(); }
		return $wpdb->get_results( $wpdb->prepare( "SELECT question_id, question_version_id, topic_id FROM {$table} WHERE course_quiz_placement_id = %d", $placement_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Captures Course-specific Topic mapping.
	}
}
