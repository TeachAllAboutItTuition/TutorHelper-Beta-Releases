<?php
/**
 * Read-only LearnDash migration preview for TutorHelper LMS.
 *
 * Uploads are parsed in the current administrator request and are never copied
 * into the WordPress Media Library or retained as source files.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Import {

	const SECTION_KEY   = 'import';
	const PREVIEW_ACTION = 'tutorhelper_lms_preview_import';
	const SAVE_MAPPING_ACTION = 'tutorhelper_lms_save_import_mapping';
	const SAVE_SANITISATION_ACTION = 'tutorhelper_lms_save_import_sanitisation';
	const EXECUTE_CSV_ACTION = 'tutorhelper_lms_execute_question_csv_import';
	const PREVIEW_TTL   = 15 * MINUTE_IN_SECONDS;

	/**
	 * Register the Learning Hub workspace and secure preview endpoint.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'tutorhelper_lms_learning_hub_sections', array( __CLASS__, 'add_section' ) );
		add_filter( 'tutorhelper_lms_learning_hub_render_tab', array( __CLASS__, 'render_tab' ), 10, 3 );
		add_action( 'admin_post_' . self::PREVIEW_ACTION, array( __CLASS__, 'preview_uploads' ) );
		add_action( 'admin_post_' . self::SAVE_MAPPING_ACTION, array( __CLASS__, 'save_mappings' ) );
		add_action( 'admin_post_' . self::SAVE_SANITISATION_ACTION, array( __CLASS__, 'save_sanitisation' ) );
		add_action( 'admin_post_' . self::EXECUTE_CSV_ACTION, array( __CLASS__, 'execute_csv_questions' ) );
	}

	/**
	 * Add Import alongside the other Learning Hub workspaces.
	 *
	 * @param array $sections Existing sections.
	 * @return array
	 */
	public static function add_section( $sections ) {
		$sections[ self::SECTION_KEY ] = array(
			'label'       => __( 'Import', 'tutorhelper-lms' ),
			'icon'        => 'dashicons-upload',
			'description' => __( 'Preview content from another LMS before creating anything here.', 'tutorhelper-lms' ),
		);
		return $sections;
	}

	/**
	 * Render the import workspace through the Learning Hub extension point.
	 *
	 * @param bool   $handled Whether another extension has rendered the tab.
	 * @param string $tab Selected tab.
	 * @param array  $sections Known Learning Hub sections.
	 * @return bool
	 */
	public static function render_tab( $handled, $tab, $sections ) {
		if ( $handled || self::SECTION_KEY !== $tab ) {
			return $handled;
		}
		self::render_workspace();
		return true;
	}

	/**
	 * Render friendly guidance, uploads and the current no-write preview.
	 *
	 * @return void
	 */
	private static function render_workspace() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$preview = get_transient( self::preview_key() );
		?>
		<section class="tutorhelper-main-section tutorhelper-lms-import">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'Import learning content', 'tutorhelper-lms' ); ?></h2>
					<p><?php esc_html_e( 'Bring across your Course structure and Quiz Question banks in a controlled, review-first way.', 'tutorhelper-lms' ); ?></p>
				</div>
			</header>
			<div class="tutorhelper-main-section__body">
				<?php self::render_notices(); ?>
				<details class="tutorhelper-lms-import__guide" open>
					<summary><?php esc_html_e( 'How to move LearnDash content across', 'tutorhelper-lms' ); ?></summary>
					<div class="tutorhelper-lms-import__guide-body">
						<ol>
							<li><?php esc_html_e( 'Export the Course structure from LearnDash, then save it as a JSON file.', 'tutorhelper-lms' ); ?></li>
							<li><?php esc_html_e( 'Export each Quiz separately from the LearnDash Quiz Import/Export tool. You can select several Quiz JSON files below.', 'tutorhelper-lms' ); ?></li>
							<li><?php esc_html_e( 'Upload the files and review the preview. This stage does not create, change or delete anything.', 'tutorhelper-lms' ); ?></li>
							<li><?php esc_html_e( 'Use the preview to check titles, Question totals and warnings before the import step is enabled.', 'tutorhelper-lms' ); ?></li>
						</ol>
						<div class="tutorhelper-lms-import__guide-grid">
							<div>
								<h3><?php esc_html_e( 'The preview can prepare', 'tutorhelper-lms' ); ?></h3>
								<p><?php esc_html_e( 'Course and Lesson titles/content, common Quiz settings, Question prompts, answer options, correct answers, feedback and marks for supported Question types.', 'tutorhelper-lms' ); ?></p>
							</div>
							<div>
								<h3><?php esc_html_e( 'It will not copy', 'tutorhelper-lms' ); ?></h3>
								<p><?php esc_html_e( 'Students, enrolments, previous attempts, grades, certificates, payments, reports, email rules, WordPress Media Library files or the contents of external links.', 'tutorhelper-lms' ); ?></p>
							</div>
						</div>
						<p class="description"><?php esc_html_e( 'If LearnDash used random Question pools, prerequisites, timed access, or a Question type TutorHelper does not yet support, the preview will flag it for review rather than guessing.', 'tutorhelper-lms' ); ?></p>
					</div>
				</details>

				<form class="tutorhelper-lms-import__form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::PREVIEW_ACTION ); ?>" />
					<?php wp_nonce_field( self::PREVIEW_ACTION ); ?>
					<div class="tutorhelper-lms-import__upload-grid">
						<label>
							<strong><?php esc_html_e( 'LearnDash Course JSON (optional)', 'tutorhelper-lms' ); ?></strong>
							<input type="file" name="learndash_course_file" accept=".json,application/json" />
							<span><?php esc_html_e( 'Use this for Course, Topic and Lesson structure.', 'tutorhelper-lms' ); ?></span>
						</label>
						<label>
							<strong><?php esc_html_e( 'LearnDash Quiz JSON files', 'tutorhelper-lms' ); ?></strong>
							<input type="file" name="learndash_quiz_files[]" accept=".json,application/json" multiple />
							<span><?php esc_html_e( 'Choose one or more exports from the LearnDash Quiz Import/Export tool.', 'tutorhelper-lms' ); ?></span>
						</label>
						<label>
							<strong><?php esc_html_e( 'TutorHelper Question CSV (optional)', 'tutorhelper-lms' ); ?></strong>
							<input type="file" name="tutorhelper_questions_csv_file" accept=".csv,text/csv" />
							<span><?php esc_html_e( 'Use the TutorHelper Question Bank CSV template to check Questions before creating any.', 'tutorhelper-lms' ); ?></span>
						</label>
					</div>
					<p class="description"><?php esc_html_e( 'The source JSON files are not saved to your Media Library or added to the plugin. TutorHelper keeps a short-lived private preview only while you review and correct the import.', 'tutorhelper-lms' ); ?></p>
					<button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Preview imports', 'tutorhelper-lms' ); ?></button>
				</form>

				<?php if ( is_array( $preview ) ) : ?>
					<?php self::render_preview( $preview ); ?>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	/**
	 * Parse uploaded JSON into a summary without creating any LMS records.
	 *
	 * @return void
	 */
	public static function preview_uploads() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to import learning content.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::PREVIEW_ACTION );

		$summary = array(
			'created_at' => current_time( 'timestamp' ),
			'course'     => null,
			'quizzes'    => array(),
			'csv_questions' => null,
			'errors'     => array(),
			'warnings'   => array(),
			'mappings'   => array(),
		);

		$course_file = self::single_uploaded_file( 'learndash_course_file' );
		if ( $course_file ) {
			$data = self::read_json_upload( $course_file, $summary['errors'] );
			if ( is_array( $data ) ) {
				$course = self::preview_course_export( $data );
				if ( is_wp_error( $course ) ) {
					$summary['errors'][] = $course->get_error_message();
				} else {
					$summary['course'] = $course;
				}
			}
		}

		foreach ( self::multiple_uploaded_files( 'learndash_quiz_files' ) as $quiz_file ) {
			$data = self::read_json_upload( $quiz_file, $summary['errors'] );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$quizzes = self::preview_quiz_export( $data, $quiz_file['name'] );
			if ( is_wp_error( $quizzes ) ) {
				$summary['errors'][] = $quizzes->get_error_message();
				continue;
			}
			$summary['quizzes'] = array_merge( $summary['quizzes'], $quizzes );
		}

		$csv_file = self::single_uploaded_file( 'tutorhelper_questions_csv_file' );
		if ( $csv_file ) {
			$csv_preview = self::preview_question_csv( $csv_file, $summary['errors'], $summary['warnings'] );
			if ( is_array( $csv_preview ) ) {
				$summary['csv_questions'] = $csv_preview;
			}
		}

		if ( ! $summary['course'] && empty( $summary['quizzes'] ) && empty( $summary['csv_questions'] ) && empty( $summary['errors'] ) ) {
			$summary['errors'][] = __( 'Choose at least one LearnDash Course JSON file, Quiz JSON file or TutorHelper Question CSV file to preview.', 'tutorhelper-lms' );
		}

		if ( ! empty( $summary['quizzes'] ) ) {
			foreach ( $summary['quizzes'] as $quiz ) {
				if ( ! empty( $quiz['uses_random_pool'] ) ) {
					$summary['warnings'][] = sprintf( __( '%s uses random Question selection. Its Question bank can be reviewed now; its random-practice settings will need a later TutorHelper mapping.', 'tutorhelper-lms' ), $quiz['title'] );
				}
				if ( ! empty( $quiz['time_limit'] ) ) {
					$summary['warnings'][] = sprintf( __( '%s has a LearnDash time limit. Timing is shown in the preview but will need a later TutorHelper exam-settings mapping.', 'tutorhelper-lms' ), $quiz['title'] );
				}
				if ( ! empty( $quiz['requires_premium'] ) ) {
					$summary['warnings'][] = sprintf( __( '%s includes written-answer Questions. They require TutorHelper LMS Premium when the import stage is enabled.', 'tutorhelper-lms' ), $quiz['title'] );
				}
				if ( ! empty( $quiz['unsupported_types'] ) ) {
					$summary['warnings'][] = sprintf( __( '%1$s includes unsupported LearnDash Question types: %2$s. They will not be created automatically.', 'tutorhelper-lms' ), $quiz['title'], implode( ', ', $quiz['unsupported_types'] ) );
				}
			}
		}

		set_transient( self::preview_key(), $summary, self::PREVIEW_TTL );
		wp_safe_redirect( add_query_arg( array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => self::SECTION_KEY, 'tutorhelper_lms_import_preview' => 'ready' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Return a validated optional single upload.
	 *
	 * @param string $field Form field name.
	 * @return array|null
	 */
	private static function single_uploaded_file( $field ) {
		if ( empty( $_FILES[ $field ] ) || ! is_array( $_FILES[ $field ] ) ) {
			return null;
		}
		$file = $_FILES[ $field ];
		return UPLOAD_ERR_NO_FILE === absint( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ? null : $file;
	}

	/**
	 * Normalise one multiple-file input.
	 *
	 * @param string $field Form field name.
	 * @return array[]
	 */
	private static function multiple_uploaded_files( $field ) {
		if ( empty( $_FILES[ $field ] ) || ! is_array( $_FILES[ $field ] ) || ! is_array( $_FILES[ $field ]['name'] ?? null ) ) {
			return array();
		}
		$files = array();
		foreach ( $_FILES[ $field ]['name'] as $index => $name ) {
			if ( UPLOAD_ERR_NO_FILE === absint( $_FILES[ $field ]['error'][ $index ] ?? UPLOAD_ERR_NO_FILE ) ) {
				continue;
			}
			$files[] = array(
				'name'     => $name,
				'type'     => $_FILES[ $field ]['type'][ $index ] ?? '',
				'tmp_name' => $_FILES[ $field ]['tmp_name'][ $index ] ?? '',
				'error'    => $_FILES[ $field ]['error'][ $index ] ?? UPLOAD_ERR_NO_FILE,
				'size'     => $_FILES[ $field ]['size'][ $index ] ?? 0,
			);
		}
		return $files;
	}

	/**
	 * Decode one temporary JSON upload while rejecting excessive or invalid files.
	 *
	 * @param array  $file Upload details.
	 * @param array &$errors Preview errors.
	 * @return array|null
	 */
	private static function read_json_upload( $file, &$errors ) {
		$name = sanitize_file_name( (string) ( $file['name'] ?? __( 'Uploaded file', 'tutorhelper-lms' ) ) );
		if ( UPLOAD_ERR_OK !== absint( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			$errors[] = sprintf( __( '%s could not be uploaded. Please try exporting it again.', 'tutorhelper-lms' ), $name );
			return null;
		}
		if ( strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) !== 'json' ) {
			$errors[] = sprintf( __( '%s is not a JSON file.', 'tutorhelper-lms' ), $name );
			return null;
		}
		if ( absint( $file['size'] ?? 0 ) > 10 * MB_IN_BYTES || ! is_uploaded_file( $file['tmp_name'] ?? '' ) ) {
			$errors[] = sprintf( __( '%s is too large or is not a valid upload.', 'tutorhelper-lms' ), $name );
			return null;
		}
		$raw = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reads one temporary administrator upload without retaining it.
		$data = is_string( $raw ) ? json_decode( $raw, true ) : null;
		if ( ! is_array( $data ) || JSON_ERROR_NONE !== json_last_error() ) {
			$errors[] = sprintf( __( '%s is not valid JSON.', 'tutorhelper-lms' ), $name );
			return null;
		}
		return $data;
	}

	/**
	 * Read and normalise the documented TutorHelper Question Bank CSV without
	 * retaining the uploaded source file or creating Question records.
	 *
	 * @param array  $file Upload details.
	 * @param array &$errors Preview errors.
	 * @param array &$warnings Preview warnings.
	 * @return array|null
	 */
	private static function preview_question_csv( $file, &$errors, &$warnings ) {
		$name = sanitize_file_name( (string) ( $file['name'] ?? __( 'Uploaded file', 'tutorhelper-lms' ) ) );
		if ( UPLOAD_ERR_OK !== absint( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			$errors[] = sprintf( __( '%s could not be uploaded. Please try again.', 'tutorhelper-lms' ), $name );
			return null;
		}
		if ( 'csv' !== strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) ) {
			$errors[] = sprintf( __( '%s is not a CSV file.', 'tutorhelper-lms' ), $name );
			return null;
		}
		if ( absint( $file['size'] ?? 0 ) > 10 * MB_IN_BYTES || ! is_uploaded_file( $file['tmp_name'] ?? '' ) ) {
			$errors[] = sprintf( __( '%s is too large or is not a valid upload.', 'tutorhelper-lms' ), $name );
			return null;
		}
		$handle = fopen( $file['tmp_name'], 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Reads one temporary administrator upload without retaining it.
		if ( ! $handle ) {
			$errors[] = sprintf( __( '%s could not be read.', 'tutorhelper-lms' ), $name );
			return null;
		}
		$headers = fgetcsv( $handle );
		$expected = array( 'source_reference', 'title', 'question_type', 'prompt', 'max_marks', 'student_explanation', 'incorrect_feedback', 'correct_feedback', 'answers_json', 'settings_json', 'status' );
		if ( is_array( $headers ) && isset( $headers[0] ) ) {
			$headers[0] = preg_replace( '/^\\xEF\\xBB\\xBF/', '', (string) $headers[0] );
		}
		if ( $expected !== $headers ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes the temporary upload handle.
			$errors[] = sprintf( __( '%s does not use the TutorHelper Question CSV template. Download a fresh template and keep its column headings in the same order.', 'tutorhelper-lms' ), $name );
			return null;
		}

		$records = array();
		$type_counts = array();
		$references = array();
		$row_number = 1;
		while ( false !== ( $row = fgetcsv( $handle ) ) ) {
			$row_number++;
			if ( array( null ) === $row || array() === $row ) {
				continue;
			}
			if ( count( $expected ) !== count( $row ) ) {
				$errors[] = sprintf( __( '%1$s row %2$d has the wrong number of columns.', 'tutorhelper-lms' ), $name, $row_number );
				continue;
			}
			$data = array_combine( $expected, $row );
			$record = self::normalise_question_csv_row( $data, $name, $row_number, $errors );
			if ( ! $record ) {
				continue;
			}
			$reference = $record['source_reference'];
			if ( '' === $reference ) {
				$warnings[] = sprintf( __( '%1$s row %2$d has no source reference. Add one before the final import so the Question can be traced back to its CSV row.', 'tutorhelper-lms' ), $name, $row_number );
			} elseif ( isset( $references[ $reference ] ) ) {
				$errors[] = sprintf( __( '%1$s has the source reference “%2$s” more than once (rows %3$d and %4$d). References must be unique.', 'tutorhelper-lms' ), $name, $reference, $references[ $reference ], $row_number );
			} else {
				$references[ $reference ] = $row_number;
			}
			$records[] = $record;
			$type_counts[ $record['label'] ] = absint( $type_counts[ $record['label'] ] ?? 0 ) + 1;
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes the temporary upload handle.
		if ( empty( $records ) ) {
			$errors[] = sprintf( __( '%s did not contain any valid Question rows to preview.', 'tutorhelper-lms' ), $name );
			return null;
		}
		return array(
			'source'      => $name,
			'title'       => __( 'TutorHelper Question CSV', 'tutorhelper-lms' ),
			'questions'   => count( $records ),
			'type_counts' => $type_counts,
			'records'     => $records,
		);
	}

	/**
	 * Convert one CSV row into the same temporary Question record used by the
	 * LearnDash audit. Problems are reported by row; no data is written to LMS.
	 *
	 * @param array  $data Row keyed by CSV heading.
	 * @param string $filename Safe CSV filename.
	 * @param int    $row_number CSV row number.
	 * @param array &$errors Preview errors.
	 * @return array|null
	 */
	private static function normalise_question_csv_row( $data, $filename, $row_number, &$errors ) {
		$type = sanitize_key( $data['question_type'] ?? '' );
		$types = array(
			'single_choice'   => __( 'Single choice', 'tutorhelper-lms' ),
			'multiple_choice' => __( 'Multiple choice', 'tutorhelper-lms' ),
			'free_answer'     => __( 'Short answer', 'tutorhelper-lms' ),
			'sort_answer'     => __( 'Sorting', 'tutorhelper-lms' ),
			'matrix_sort'     => __( 'Matching', 'tutorhelper-lms' ),
			'cloze'           => __( 'Fill in the blanks', 'tutorhelper-lms' ),
			'assessment'      => __( 'Assessment', 'tutorhelper-lms' ),
		);
		if ( ! isset( $types[ $type ] ) ) {
			$errors[] = sprintf( __( '%1$s row %2$d has an unsupported question_type.', 'tutorhelper-lms' ), $filename, $row_number );
			return null;
		}
		$answers_json = json_decode( (string) ( $data['answers_json'] ?? '' ), true );
		$settings_json = json_decode( (string) ( $data['settings_json'] ?? '' ), true );
		if ( ! is_array( $answers_json ) || JSON_ERROR_NONE !== json_last_error() || ! is_array( $settings_json ) ) {
			$errors[] = sprintf( __( '%1$s row %2$d needs valid JSON in both answers_json and settings_json.', 'tutorhelper-lms' ), $filename, $row_number );
			return null;
		}
		$status = sanitize_key( $data['status'] ?? '' );
		if ( ! in_array( $status, array( 'draft', 'published' ), true ) ) {
			$errors[] = sprintf( __( '%1$s row %2$d must use draft or published in the status column.', 'tutorhelper-lms' ), $filename, $row_number );
			return null;
		}
		$answers = self::normalise_csv_answers( $answers_json, $type );
		$record = array(
			'kind'               => 'question',
			'id'                 => 'csv-question-' . substr( sha1( $filename . '|' . $row_number . '|' . (string) ( $data['source_reference'] ?? '' ) ), 0, 16 ),
			'csv_row'            => $row_number,
			'source_reference'   => sanitize_text_field( $data['source_reference'] ?? '' ),
			'type'               => $type,
			'label'              => $types[ $type ],
			'status'             => 'supported',
			'import_status'      => $status,
			'title'              => sanitize_text_field( $data['title'] ?? '' ),
			'prompt'             => wp_kses_post( (string) ( $data['prompt'] ?? '' ) ),
			'marks'              => absint( $data['max_marks'] ?? 0 ),
			'tip'                => wp_kses_post( (string) ( $data['student_explanation'] ?? '' ) ),
			'incorrect_feedback' => wp_kses_post( (string) ( $data['incorrect_feedback'] ?? '' ) ),
			'correct_feedback'   => wp_kses_post( (string) ( $data['correct_feedback'] ?? '' ) ),
			'feedback_shared'    => false,
			'answers'            => $answers,
			'settings'           => $settings_json,
		);
		// Required-field gaps remain visible as clickable crosses in the audit
		// table, so a tutor can correct them in this temporary preview.
		return $record;
	}

	/**
	 * Map documented CSV answer shapes into temporary audit answer rows.
	 *
	 * @param array  $answers JSON answer object.
	 * @param string $type Question type.
	 * @return array
	 */
	private static function normalise_csv_answers( $answers, $type ) {
		$items = array();
		if ( in_array( $type, array( 'single_choice', 'multiple_choice' ), true ) ) {
			$correct = array_map( 'strval', is_array( $answers['correct'] ?? null ) ? $answers['correct'] : array() );
			foreach ( is_array( $answers['options'] ?? null ) ? $answers['options'] : array() as $index => $option ) {
				$items[] = array( 'text' => wp_kses_post( (string) $option ), 'correct' => in_array( (string) $index, $correct, true ), 'match' => '' );
			}
		} elseif ( 'free_answer' === $type ) {
			foreach ( is_array( $answers['accepted'] ?? null ) ? $answers['accepted'] : array() as $answer ) {
				$items[] = array( 'text' => wp_kses_post( (string) $answer ), 'correct' => true, 'match' => '' );
			}
		} elseif ( 'sort_answer' === $type ) {
			foreach ( is_array( $answers['items'] ?? null ) ? $answers['items'] : array() as $answer ) {
				$items[] = array( 'text' => wp_kses_post( (string) $answer ), 'correct' => true, 'match' => '' );
			}
		} elseif ( 'matrix_sort' === $type ) {
			foreach ( is_array( $answers['pairs'] ?? null ) ? $answers['pairs'] : array() as $pair ) {
				if ( is_array( $pair ) ) {
					$items[] = array( 'text' => wp_kses_post( (string) ( $pair['left'] ?? '' ) ), 'correct' => true, 'match' => sanitize_text_field( $pair['right'] ?? '' ) );
				}
			}
		} elseif ( 'cloze' === $type ) {
			foreach ( is_array( $answers['blanks'] ?? null ) ? $answers['blanks'] : array() as $answer ) {
				$items[] = array( 'text' => wp_kses_post( (string) $answer ), 'correct' => true, 'match' => '' );
			}
		}
		return $items;
	}

	/**
	 * Summarise the LearnDash Course JSON export without retaining its contents.
	 *
	 * @param array $data Decoded JSON.
	 * @return array|WP_Error
	 */
	private static function preview_course_export( $data ) {
		if ( ! isset( $data['courses'] ) || ! is_array( $data['courses'] ) ) {
			return new WP_Error( 'invalid_learndash_course', __( 'This file is not a recognised LearnDash Course JSON export.', 'tutorhelper-lms' ) );
		}
		$courses = array();
		foreach ( $data['courses'] as $index => $course ) {
			if ( ! is_array( $course ) ) {
				continue;
			}
			$title = sanitize_text_field( $course['title'] ?? '' );
			$courses[] = array(
				'id'          => 'course-' . absint( $index ),
				'title'       => $title,
				'has_content' => '' !== trim( wp_strip_all_tags( (string) ( $course['content'] ?? '' ) ) ),
			);
		}
		$lessons = array();
		foreach ( is_array( $data['lessons'] ?? null ) ? $data['lessons'] : array() as $index => $lesson ) {
			if ( ! is_array( $lesson ) ) {
				continue;
			}
			$lessons[] = array(
				'id'          => 'lesson-' . absint( $index ),
				'title'       => sanitize_text_field( $lesson['title'] ?? '' ),
				'has_content' => '' !== trim( wp_strip_all_tags( (string) ( $lesson['content'] ?? '' ) ) ),
			);
		}
		return array(
			'courses'      => $courses,
			'lessons'      => $lessons,
			'topics'       => self::title_list( $data['topics'] ?? array() ),
			'has_sections' => ! empty( $data['courses'][0]['course_sections'] ?? '' ),
		);
	}

	/**
	 * Summarise every Quiz in a LearnDash Quiz Import/Export JSON.
	 *
	 * @param array  $data Decoded JSON.
	 * @param string $filename Source filename.
	 * @return array[]|WP_Error
	 */
		private static function preview_quiz_export( $data, $filename ) {
		if ( ! isset( $data['master'], $data['question'] ) || ! is_array( $data['master'] ) || ! is_array( $data['question'] ) ) {
			return new WP_Error( 'invalid_learndash_quiz', sprintf( __( '%s is not a recognised LearnDash Quiz JSON export.', 'tutorhelper-lms' ), sanitize_file_name( $filename ) ) );
		}
		$quizzes = array();
		foreach ( $data['master'] as $master ) {
			if ( ! is_array( $master ) ) {
				continue;
			}
			$quiz_id = (string) absint( $master['_id'] ?? 0 );
			if ( '' === $quiz_id || '0' === $quiz_id ) {
				continue;
			}
			$post = is_array( $data['post'][ $quiz_id ] ?? null ) ? $data['post'][ $quiz_id ] : array();
			$settings = is_array( $data['post_meta'][ $quiz_id ]['_sfwd-quiz'][0] ?? null ) ? $data['post_meta'][ $quiz_id ]['_sfwd-quiz'][0] : array();
			$questions = is_array( $data['question'][ $quiz_id ] ?? null ) ? $data['question'][ $quiz_id ] : array();
			$type_counts = array();
			$unsupported = array();
			$requires_premium = false;
			$records = array();
			foreach ( $questions as $question_key => $question ) {
				if ( ! is_array( $question ) ) {
					continue;
				}
				$type = sanitize_key( $question['_answerType'] ?? '' );
				$mapping = self::map_question_type( $type );
				$label = $mapping['label'];
				$type_counts[ $label ] = absint( $type_counts[ $label ] ?? 0 ) + 1;
				if ( 'premium' === $mapping['status'] ) {
					$requires_premium = true;
				}
				if ( 'unsupported' === $mapping['status'] ) {
					$unsupported[] = $type ? $type : __( 'unknown', 'tutorhelper-lms' );
				}
				$answers = array();
				foreach ( is_array( $question['_answerData'] ?? null ) ? $question['_answerData'] : array() as $answer ) {
					if ( ! is_array( $answer ) ) {
						continue;
					}
					$answers[] = array(
						'text'    => wp_kses_post( (string) ( $answer['_answer'] ?? '' ) ),
						'correct' => ! empty( $answer['_correct'] ),
						'match'   => sanitize_text_field( $answer['_sortString'] ?? '' ),
					);
				}
				$records[] = array(
					'id'     => 'question-' . substr( sha1( sanitize_file_name( $filename ) . '|' . $quiz_id . '|' . $question_key ), 0, 16 ),
					'type'   => $type,
					'label'  => $label,
					'status' => $mapping['status'],
					'title'  => sanitize_text_field( $question['_title'] ?? '' ),
					'prompt' => wp_kses_post( (string) ( $question['_question'] ?? '' ) ),
					'marks'  => absint( $question['_points'] ?? 0 ),
					'correct_feedback' => wp_kses_post( (string) ( $question['_correctMsg'] ?? '' ) ),
					'incorrect_feedback' => wp_kses_post( (string) ( $question['_incorrectMsg'] ?? '' ) ),
					'feedback_shared' => ! empty( $question['_correctSameText'] ),
					'tip' => wp_kses_post( (string) ( $question['_tipMsg'] ?? '' ) ),
					'answers' => $answers,
				);
			}
			$time_limit = absint( $master['_timeLimit'] ?? $settings['sfwd-quiz_timeLimit'] ?? 0 );
			$quizzes[] = array(
				'source' => sanitize_file_name( $filename ),
				'title'  => sanitize_text_field( $post['post_title'] ?? $master['_name'] ?? __( 'Untitled Quiz', 'tutorhelper-lms' ) ),
				'questions' => count( $records ),
				'type_counts' => $type_counts,
				'records' => $records,
				'unsupported_types' => array_values( array_unique( $unsupported ) ),
				'requires_premium' => $requires_premium,
				'uses_random_pool' => ! empty( $master['_questionRandom'] ) || ! empty( $settings['sfwd-quiz_questionRandom'] ),
				'time_limit' => $time_limit,
				'passing_percentage' => absint( $settings['sfwd-quiz_passingpercentage'] ?? 0 ),
			);
		}
		return $quizzes;
	}

	/**
	 * Map a LearnDash Question type to its TutorHelper import category.
	 *
	 * @param string $type LearnDash answer type.
	 * @return array
	 */
		private static function map_question_type( $type ) {
		$map = array(
			'single' => array( 'label' => __( 'Single choice', 'tutorhelper-lms' ), 'status' => 'supported' ),
			'multiple' => array( 'label' => __( 'Multiple choice', 'tutorhelper-lms' ), 'status' => 'supported' ),
			'free_answer' => array( 'label' => __( 'Short answer', 'tutorhelper-lms' ), 'status' => 'supported' ),
			'sort_answer' => array( 'label' => __( 'Sorting', 'tutorhelper-lms' ), 'status' => 'supported' ),
			'matrix_sort_answer' => array( 'label' => __( 'Matching', 'tutorhelper-lms' ), 'status' => 'supported' ),
			'cloze_answer' => array( 'label' => __( 'Fill in the blanks', 'tutorhelper-lms' ), 'status' => 'supported' ),
			'essay' => array( 'label' => __( 'Written response', 'tutorhelper-lms' ), 'status' => 'premium' ),
		);
		return $map[ $type ] ?? array( 'label' => __( 'Unsupported', 'tutorhelper-lms' ), 'status' => 'unsupported' );
	}

	/**
	 * Produce a concise title list from a LearnDash content export.
	 *
	 * @param mixed $items Source records.
	 * @return array
	 */
	private static function title_list( $items ) {
		$titles = array();
		foreach ( is_array( $items ) ? $items : array() as $item ) {
			if ( is_array( $item ) ) {
				$titles[] = sanitize_text_field( $item['title'] ?? __( 'Untitled item', 'tutorhelper-lms' ) );
			}
		}
		return $titles;
	}

	/**
	 * Render a stored summary.
	 *
	 * @param array $preview Preview summary.
	 * @return void
	 */
	private static function render_preview( $preview ) {
		?>
		<section class="tutorhelper-lms-import__preview" aria-live="polite">
			<h3><?php esc_html_e( 'Import preview', 'tutorhelper-lms' ); ?></h3>
			<?php if ( ! empty( $preview['csv_questions']['execution'] ) ) : ?>
				<p><?php esc_html_e( 'This preview now includes the CSV Question creation results below. Course and Quiz imports remain review-only.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<p><?php esc_html_e( 'Nothing has been imported yet. This is a read-only check of the files you selected.', 'tutorhelper-lms' ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $preview['errors'] ) ) : ?>
				<div class="notice notice-error inline"><p><strong><?php esc_html_e( 'Files that need attention', 'tutorhelper-lms' ); ?></strong></p><ul><?php foreach ( $preview['errors'] as $error ) : ?><li><?php echo esc_html( $error ); ?></li><?php endforeach; ?></ul></div>
			<?php endif; ?>
			<?php if ( ! empty( $preview['warnings'] ) ) : ?>
				<div class="notice notice-warning inline"><p><strong><?php esc_html_e( 'Review before import', 'tutorhelper-lms' ); ?></strong></p><ul><?php foreach ( array_unique( $preview['warnings'] ) as $warning ) : ?><li><?php echo esc_html( $warning ); ?></li><?php endforeach; ?></ul></div>
			<?php endif; ?>

			<?php if ( ! empty( $preview['course'] ) ) : ?>
				<div class="tutorhelper-lms-import__preview-card">
					<h4><?php esc_html_e( 'Course structure', 'tutorhelper-lms' ); ?></h4>
					<p><?php echo esc_html( sprintf( _n( '%d Course', '%d Courses', count( $preview['course']['courses'] ), 'tutorhelper-lms' ), count( $preview['course']['courses'] ) ) ); ?> · <?php echo esc_html( sprintf( _n( '%d Lesson', '%d Lessons', count( $preview['course']['lessons'] ), 'tutorhelper-lms' ), count( $preview['course']['lessons'] ) ) ); ?> · <?php echo esc_html( sprintf( _n( '%d Topic', '%d Topics', count( $preview['course']['topics'] ), 'tutorhelper-lms' ), count( $preview['course']['topics'] ) ) ); ?></p>
					<?php if ( ! empty( $preview['course']['courses'] ) ) : ?><ul><?php foreach ( $preview['course']['courses'] as $course ) : ?><li><?php echo esc_html( $course['title'] ); ?><?php echo ! empty( $course['has_content'] ) ? esc_html__( ' — description found', 'tutorhelper-lms' ) : ''; ?></li><?php endforeach; ?></ul><?php endif; ?>
					<?php if ( ! empty( $preview['course']['lessons'] ) ) : ?><p><strong><?php esc_html_e( 'Lessons:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( implode( ', ', wp_list_pluck( $preview['course']['lessons'], 'title' ) ) ); ?></p><?php endif; ?>
					<?php if ( ! empty( $preview['course']['has_sections'] ) ) : ?><p class="description"><?php esc_html_e( 'LearnDash section headings were found and will be shown for placement review in the import stage.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
				</div>
				<?php self::render_course_audit( $preview ); ?>
				<?php self::render_lesson_audit( $preview ); ?>
			<?php endif; ?>

			<?php foreach ( $preview['quizzes'] as $quiz ) : ?>
				<div class="tutorhelper-lms-import__preview-card">
					<h4><?php echo esc_html( $quiz['title'] ); ?></h4>
					<p class="description"><?php echo esc_html( sprintf( __( 'Source: %s', 'tutorhelper-lms' ), $quiz['source'] ) ); ?></p>
					<p><strong><?php echo esc_html( sprintf( _n( '%d Question', '%d Questions', $quiz['questions'], 'tutorhelper-lms' ), $quiz['questions'] ) ); ?></strong><?php if ( $quiz['passing_percentage'] ) : ?> · <?php echo esc_html( sprintf( __( 'LearnDash pass mark: %d%%', 'tutorhelper-lms' ), $quiz['passing_percentage'] ) ); ?><?php endif; ?><?php if ( $quiz['time_limit'] ) : ?> · <?php echo esc_html( sprintf( __( 'Time limit: %d seconds', 'tutorhelper-lms' ), $quiz['time_limit'] ) ); ?><?php endif; ?></p>
					<?php if ( ! empty( $quiz['type_counts'] ) ) : ?><ul class="tutorhelper-lms-import__type-counts"><?php foreach ( $quiz['type_counts'] as $type => $count ) : ?><li><?php echo esc_html( sprintf( _n( '%1$d %2$s Question', '%1$d %2$s Questions', $count, 'tutorhelper-lms' ), $count, $type ) ); ?></li><?php endforeach; ?></ul><?php endif; ?>
				</div>
				<?php self::render_quiz_audit( $quiz ); ?>
			<?php endforeach; ?>
			<?php if ( ! empty( $preview['csv_questions'] ) ) : ?><?php $csv = $preview['csv_questions']; ?>
				<div class="tutorhelper-lms-import__preview-card">
					<h4><?php esc_html_e( 'TutorHelper Question CSV', 'tutorhelper-lms' ); ?></h4>
					<p class="description"><?php echo esc_html( sprintf( __( 'Source: %s', 'tutorhelper-lms' ), $csv['source'] ) ); ?></p>
					<p><strong><?php echo esc_html( sprintf( _n( '%d Question', '%d Questions', $csv['questions'], 'tutorhelper-lms' ), $csv['questions'] ) ); ?></strong></p>
					<?php if ( ! empty( $csv['type_counts'] ) ) : ?><ul class="tutorhelper-lms-import__type-counts"><?php foreach ( $csv['type_counts'] as $type => $count ) : ?><li><?php echo esc_html( sprintf( _n( '%1$d %2$s Question', '%1$d %2$s Questions', $count, 'tutorhelper-lms' ), $count, $type ) ); ?></li><?php endforeach; ?></ul><?php endif; ?>
				</div>
				<?php self::render_quiz_audit( $csv ); ?>
				<?php self::render_csv_execution( $csv ); ?>
			<?php endif; ?>
			<?php self::render_audit_dialog(); ?>
			<?php if ( ! empty( $preview['course'] ) ) : ?>
				<?php self::render_mapping_worksheet( $preview ); ?>
			<?php endif; ?>
			<p class="tutorhelper-lms-import__next-step"><strong><?php esc_html_e( 'Next step:', 'tutorhelper-lms' ); ?></strong> <?php esc_html_e( 'Approve the mapping and create the reviewed Course, Lessons, Questions and Quizzes in the next import stage.', 'tutorhelper-lms' ); ?></p>
		</section>
		<?php
	}

	/**
	 * Definitions and checks for the fields needed by each TutorHelper Question type.
	 *
	 * @param string $type LearnDash Question type.
	 * @return array
	 */
	private static function question_audit_definition( $type ) {
		$common = array(
			'title'  => __( 'Question title', 'tutorhelper-lms' ),
			'prompt' => __( 'Question prompt', 'tutorhelper-lms' ),
			'marks'  => __( 'Maximum marks', 'tutorhelper-lms' ),
		);
		$definitions = array(
			'single'             => array_merge( $common, array( 'options' => __( 'At least two answer options', 'tutorhelper-lms' ), 'correct' => __( 'One correct answer', 'tutorhelper-lms' ) ) ),
			'single_choice'      => array_merge( $common, array( 'options' => __( 'At least two answer options', 'tutorhelper-lms' ), 'correct' => __( 'One correct answer', 'tutorhelper-lms' ) ) ),
			'multiple'           => array_merge( $common, array( 'options' => __( 'At least two answer options', 'tutorhelper-lms' ), 'correct' => __( 'At least one correct answer', 'tutorhelper-lms' ) ) ),
			'multiple_choice'    => array_merge( $common, array( 'options' => __( 'At least two answer options', 'tutorhelper-lms' ), 'correct' => __( 'At least one correct answer', 'tutorhelper-lms' ) ) ),
			'free_answer'        => array_merge( $common, array( 'options' => __( 'Accepted answer', 'tutorhelper-lms' ) ) ),
			'sort_answer'        => array_merge( $common, array( 'options' => __( 'At least two items in order', 'tutorhelper-lms' ) ) ),
			'matrix_sort_answer' => array_merge( $common, array( 'pairs' => __( 'At least two matching pairs', 'tutorhelper-lms' ) ) ),
			'matrix_sort'        => array_merge( $common, array( 'pairs' => __( 'At least two matching pairs', 'tutorhelper-lms' ) ) ),
			'cloze_answer'       => array_merge( $common, array( 'pattern' => __( 'Fill-in pattern with answers in {braces}', 'tutorhelper-lms' ) ) ),
			'cloze'              => array_merge( $common, array( 'pattern' => __( 'Fill-in placeholders {{1}}, {{2}} and matching blank answers', 'tutorhelper-lms' ) ) ),
			'essay'              => $common,
			'assessment'         => array( 'title' => __( 'Question title', 'tutorhelper-lms' ), 'prompt' => __( 'Question prompt', 'tutorhelper-lms' ) ),
		);
		return $definitions[ $type ] ?? array(
			'title'  => __( 'Question title', 'tutorhelper-lms' ),
			'prompt' => __( 'Question prompt', 'tutorhelper-lms' ),
		);
	}

	/**
	 * Optional LearnDash fields that TutorHelper can retain without blocking import.
	 *
	 * @param string $type LearnDash Question type.
	 * @return array
	 */
	private static function question_audit_optional_definition( $type ) {
		$optional = array(
			'tip' => __( 'Student hint (optional)', 'tutorhelper-lms' ),
		);
		if ( in_array( $type, array( 'single', 'multiple', 'single_choice', 'multiple_choice' ), true ) ) {
			$optional = array_merge(
				array(
					'correct_feedback'   => __( 'Correct feedback (optional)', 'tutorhelper-lms' ),
					'incorrect_feedback' => __( 'Incorrect feedback (optional)', 'tutorhelper-lms' ),
				),
				$optional
			);
		}
		return $optional;
	}

	/**
	 * Evaluate an editable Question record against its type definition.
	 *
	 * @param array $record Stored temporary Question record.
	 * @return array
	 */
	private static function question_audit_status( $record ) {
		$answers = is_array( $record['answers'] ?? null ) ? $record['answers'] : array();
		$usable_answers = array_filter( $answers, static function( $answer ) {
			return '' !== trim( wp_strip_all_tags( (string) ( $answer['text'] ?? '' ) ) );
		} );
		$correct = array_filter( $answers, static function( $answer ) {
			return ! empty( $answer['correct'] );
		} );
		$pairs = array_filter( $answers, static function( $answer ) {
			return '' !== trim( wp_strip_all_tags( (string) ( $answer['text'] ?? '' ) ) ) && '' !== trim( (string) ( $answer['match'] ?? '' ) );
		} );
		$patterns = array_filter( $answers, static function( $answer ) {
			return 1 === preg_match( '/\\{[^{}]+\\}/', wp_strip_all_tags( (string) ( $answer['text'] ?? '' ) ) );
		} );
		$type = sanitize_key( $record['type'] ?? '' );
		$status = array(
			'title'  => '' !== trim( (string) ( $record['title'] ?? '' ) ),
			'prompt' => '' !== trim( wp_strip_all_tags( (string) ( $record['prompt'] ?? '' ) ) ),
			'marks'  => absint( $record['marks'] ?? 0 ) > 0,
			'correct_feedback' => '' !== trim( wp_strip_all_tags( (string) ( $record['correct_feedback'] ?? '' ) ) ),
			'incorrect_feedback' => '' !== trim( wp_strip_all_tags( (string) ( $record['incorrect_feedback'] ?? '' ) ) ) || ( ! empty( $record['feedback_shared'] ) && '' !== trim( wp_strip_all_tags( (string) ( $record['correct_feedback'] ?? '' ) ) ) ),
			'tip' => '' !== trim( wp_strip_all_tags( (string) ( $record['tip'] ?? '' ) ) ),
		);
		if ( in_array( $type, array( 'single', 'single_choice' ), true ) ) {
			$status['options'] = count( $usable_answers ) >= 2;
			$status['correct'] = 1 === count( $correct );
		} elseif ( in_array( $type, array( 'multiple', 'multiple_choice' ), true ) ) {
			$status['options'] = count( $usable_answers ) >= 2;
			$status['correct'] = count( $correct ) >= 1;
		} elseif ( 'free_answer' === $type || 'sort_answer' === $type ) {
			$status['options'] = 'sort_answer' === $type ? count( $usable_answers ) >= 2 : count( $usable_answers ) >= 1;
		} elseif ( in_array( $type, array( 'matrix_sort_answer', 'matrix_sort' ), true ) ) {
			$status['pairs'] = count( $pairs ) >= 2;
		} elseif ( 'cloze_answer' === $type ) {
			$status['pattern'] = count( $patterns ) >= 1;
		} elseif ( 'cloze' === $type ) {
			$placeholder_count = preg_match_all( '/\{\{[1-9][0-9]*\}\}/', wp_strip_all_tags( (string) ( $record['prompt'] ?? '' ) ), $matches );
			$status['pattern'] = $placeholder_count >= 1 && $placeholder_count === count( $usable_answers );
		} elseif ( ! in_array( $type, array( 'essay', 'assessment' ), true ) ) {
			$status['type'] = 'unsupported' !== ( $record['status'] ?? '' );
		}
		return $status;
	}

	/**
	 * Render Course audit results.
	 *
	 * @param array $preview Temporary preview.
	 * @return void
	 */
	private static function render_course_audit( $preview ) {
		$mapping = is_array( $preview['mappings'] ?? null ) ? $preview['mappings'] : array();
		$fields = array(
			'title'   => __( 'Course title', 'tutorhelper-lms' ),
			'subject' => __( 'Subject mapping', 'tutorhelper-lms' ),
			'grade'   => __( 'Grade system mapping', 'tutorhelper-lms' ),
		);
		?>
		<section class="tutorhelper-lms-import__audit">
			<h4><?php esc_html_e( 'Course import audit', 'tutorhelper-lms' ); ?></h4>
			<p class="description"><?php esc_html_e( 'Required before a Course can be created:', 'tutorhelper-lms' ); ?> <?php echo esc_html( implode( ' · ', $fields ) ); ?></p>
			<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Course', 'tutorhelper-lms' ); ?></th><?php foreach ( $fields as $label ) : ?><th><?php echo esc_html( $label ); ?></th><?php endforeach; ?></tr></thead>
				<tbody><?php foreach ( (array) ( $preview['course']['courses'] ?? array() ) as $index => $course ) : ?><?php $record = array( 'kind' => 'course', 'id' => absint( $index ), 'title' => (string) ( $course['title'] ?? '' ), 'mapping' => $mapping ); $status = array( 'title' => '' !== trim( $record['title'] ), 'subject' => absint( $mapping['course_subject_id'] ?? 0 ) > 0, 'grade' => absint( $mapping['course_grade_system_id'] ?? 0 ) > 0 ); ?><tr><th scope="row"><?php echo esc_html( $record['title'] ?: __( 'Untitled Course', 'tutorhelper-lms' ) ); ?></th><?php foreach ( $fields as $field => $label ) : ?><td><?php self::render_audit_indicator( $status[ $field ], $record, $field, $label ); ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody>
			</table></div>
		</section>
		<?php
	}

	/**
	 * Render Lesson audit results.
	 *
	 * @param array $preview Temporary preview.
	 * @return void
	 */
	private static function render_lesson_audit( $preview ) {
		$mapping = is_array( $preview['mappings'] ?? null ) ? $preview['mappings'] : array();
		$fields = array( 'title' => __( 'Lesson title', 'tutorhelper-lms' ), 'topic' => __( 'Topic plan', 'tutorhelper-lms' ) );
		?>
		<section class="tutorhelper-lms-import__audit">
			<h4><?php esc_html_e( 'Lesson import audit', 'tutorhelper-lms' ); ?></h4>
			<p class="description"><?php esc_html_e( 'Required before a Lesson can be created:', 'tutorhelper-lms' ); ?> <?php echo esc_html( implode( ' · ', $fields ) ); ?></p>
			<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Lesson', 'tutorhelper-lms' ); ?></th><?php foreach ( $fields as $label ) : ?><th><?php echo esc_html( $label ); ?></th><?php endforeach; ?></tr></thead>
				<tbody><?php foreach ( (array) ( $preview['course']['lessons'] ?? array() ) as $index => $lesson ) : ?><?php $lesson_title = is_array( $lesson ) ? (string) ( $lesson['title'] ?? '' ) : (string) $lesson; $lesson_mapping = is_array( $mapping['lessons'][ $index ] ?? null ) ? $mapping['lessons'][ $index ] : array(); $mode = $lesson_mapping['mode'] ?? ''; $topic_ready = ( 'course_topic' === $mode && absint( $lesson_mapping['topic_id'] ?? 0 ) > 0 ) || ( 'source_topic' === $mode && '' !== trim( (string) ( $lesson_mapping['source_topic'] ?? '' ) ) ) || ( 'new_topic' === $mode && '' !== trim( (string) ( $lesson_mapping['new_topic_name'] ?? '' ) ) ); $record = array( 'kind' => 'lesson', 'id' => absint( $index ), 'title' => $lesson_title, 'mapping' => $lesson_mapping ); ?><tr><th scope="row"><?php echo esc_html( $lesson_title ?: __( 'Untitled Lesson', 'tutorhelper-lms' ) ); ?></th><td><?php self::render_audit_indicator( '' !== trim( $lesson_title ), $record, 'title', $fields['title'] ); ?></td><td><?php self::render_audit_indicator( $topic_ready, $record, 'topic', $fields['topic'] ); ?></td></tr><?php endforeach; ?></tbody>
			</table></div>
		</section>
		<?php
	}

	/**
	 * Render Question audits grouped by source Question type.
	 *
	 * @param array $quiz Temporary Quiz preview.
	 * @return void
	 */
	private static function render_quiz_audit( $quiz ) {
		$groups = array();
		foreach ( (array) ( $quiz['records'] ?? array() ) as $record ) {
			$record['kind'] = 'question';
			$type = sanitize_key( $record['type'] ?? '' );
			$groups[ $type ][] = $record;
		}
		foreach ( $groups as $type => $records ) {
			$definition = self::question_audit_definition( $type );
			$optional_definition = self::question_audit_optional_definition( $type );
			$fields = array_merge( $definition, $optional_definition );
			$label = (string) ( $records[0]['label'] ?? __( 'Unsupported', 'tutorhelper-lms' ) );
			?>
			<section class="tutorhelper-lms-import__audit">
				<h4><?php echo esc_html( sprintf( __( '%1$s: %2$s', 'tutorhelper-lms' ), $quiz['title'], $label ) ); ?></h4>
				<p class="description"><strong><?php esc_html_e( 'Required fields:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( implode( ' · ', $definition ) ); ?></p>
				<?php if ( ! empty( $optional_definition ) ) : ?><p class="description"><strong><?php esc_html_e( 'Optional fields:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( implode( ' · ', $optional_definition ) ); ?> <?php esc_html_e( 'Optional fields do not block import; use the plus button to add one.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
				<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Question', 'tutorhelper-lms' ); ?></th><?php foreach ( $fields as $field_label ) : ?><th><?php echo esc_html( $field_label ); ?></th><?php endforeach; ?></tr></thead>
					<tbody><?php foreach ( $records as $record ) : ?><?php $status = self::question_audit_status( $record ); ?><tr><th scope="row"><?php echo esc_html( $record['title'] ?: __( 'Untitled Question', 'tutorhelper-lms' ) ); ?></th><?php foreach ( $fields as $field => $field_label ) : ?><td><?php self::render_audit_indicator( ! empty( $status[ $field ] ), $record, $field, $field_label, isset( $optional_definition[ $field ] ) ); ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody>
				</table></div>
			</section>
			<?php
		}
	}

	/**
	 * Render the explicit, CSV-only creation step after its audit.
	 *
	 * @param array $csv Temporary CSV preview.
	 * @return void
	 */
	private static function render_csv_execution( $csv ) {
		$records = is_array( $csv['records'] ?? null ) ? $csv['records'] : array();
		$ready = self::csv_records_ready( $records );
		$execution = is_array( $csv['execution'] ?? null ) ? $csv['execution'] : array();
		$remaining = 0;
		foreach ( $records as $record ) {
			if ( empty( $record['created_question_id'] ) ) {
				$remaining++;
			}
		}
		?>
		<section class="tutorhelper-lms-import__mapping tutorhelper-lms-import__csv-execution">
			<h3><?php esc_html_e( 'Create reviewed Questions', 'tutorhelper-lms' ); ?></h3>
			<?php if ( ! $ready ) : ?>
				<p><?php esc_html_e( 'Fix every required red-cross field above before Questions can be created.', 'tutorhelper-lms' ); ?></p>
			<?php elseif ( ! $remaining ) : ?>
				<p><?php esc_html_e( 'Every Question in this CSV preview has already been created. Re-running this preview will not duplicate them.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<p><?php echo esc_html( sprintf( _n( '%d reviewed CSV row is ready to create as a reusable Question.', '%d reviewed CSV rows are ready to create as reusable Questions.', $remaining, 'tutorhelper-lms' ), $remaining ) ); ?></p>
				<p class="description"><?php esc_html_e( 'This creates Questions only. It does not add them to a Quiz, Course or Topic. Each row keeps its CSV draft or published status.', 'tutorhelper-lms' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::EXECUTE_CSV_ACTION ); ?>" />
					<?php wp_nonce_field( self::EXECUTE_CSV_ACTION ); ?>
					<label><input type="checkbox" name="confirm_csv_question_create" value="1" required /> <?php esc_html_e( 'I have reviewed the audit and want to create these reusable Questions.', 'tutorhelper-lms' ); ?></label>
					<p><button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Create reviewed Questions', 'tutorhelper-lms' ); ?></button></p>
				</form>
			<?php endif; ?>
			<?php if ( ! empty( $execution['results'] ) ) : ?>
				<h4><?php esc_html_e( 'CSV creation results', 'tutorhelper-lms' ); ?></h4>
				<ul><?php foreach ( $execution['results'] as $result ) : ?><li><?php echo esc_html( $result ); ?></li><?php endforeach; ?></ul>
			<?php endif; ?>
		</section>
		<?php
	}

	/**
	 * Ensure every required audit field passes before an execution request.
	 *
	 * @param array $records Temporary CSV Question records.
	 * @return bool
	 */
	private static function csv_records_ready( $records ) {
		if ( empty( $records ) ) {
			return false;
		}
		foreach ( $records as $record ) {
			$status = self::question_audit_status( $record );
			foreach ( self::question_audit_definition( sanitize_key( $record['type'] ?? '' ) ) as $field => $unused_label ) {
				if ( empty( $status[ $field ] ) ) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Render a tick or a safe clickable fix control.
	 *
	 * @param bool   $passed Whether the field is ready.
	 * @param array  $record Editable temporary record.
	 * @param string $field Field identifier.
	 * @param string $label Human readable field label.
	 * @return void
	 */
	private static function render_audit_indicator( $passed, $record, $field, $label, $optional = false ) {
		if ( $passed ) {
			echo '<span class="dashicons dashicons-yes-alt tutorhelper-lms-import__audit-pass"><span class="screen-reader-text">' . esc_html__( 'Present', 'tutorhelper-lms' ) . '</span></span>';
			return;
		}
		if ( $optional ) {
			echo '<button type="button" class="button-link tutorhelper-lms-import__audit-fix is-optional" data-tutorhelper-lms-import-record="' . esc_attr( wp_json_encode( $record ) ) . '" data-tutorhelper-lms-import-field="' . esc_attr( $field ) . '" data-tutorhelper-lms-import-field-label="' . esc_attr( $label ) . '"><span class="dashicons dashicons-plus-alt2"></span><span class="screen-reader-text">' . esc_html( sprintf( __( 'Add %s', 'tutorhelper-lms' ), $label ) ) . '</span></button>';
			return;
		}
		echo '<button type="button" class="button-link tutorhelper-lms-import__audit-fix" data-tutorhelper-lms-import-record="' . esc_attr( wp_json_encode( $record ) ) . '" data-tutorhelper-lms-import-field="' . esc_attr( $field ) . '" data-tutorhelper-lms-import-field-label="' . esc_attr( $label ) . '"><span class="dashicons dashicons-dismiss"></span><span class="screen-reader-text">' . esc_html( sprintf( __( 'Fix %s', 'tutorhelper-lms' ), $label ) ) . '</span></button>';
	}

	/**
	 * Render one reusable dialog. JavaScript builds its field controls on demand.
	 *
	 * @return void
	 */
	private static function render_audit_dialog() {
		?>
		<dialog class="tutorhelper-lms-import__audit-dialog" data-tutorhelper-lms-import-dialog>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_SANITISATION_ACTION ); ?>" />
				<?php wp_nonce_field( self::SAVE_SANITISATION_ACTION ); ?>
				<input type="hidden" name="audit_kind" value="" />
				<input type="hidden" name="audit_id" value="" />
				<input type="hidden" name="audit_field" value="" />
				<div data-tutorhelper-lms-import-dialog-body></div>
				<p class="tutorhelper-lms-import__dialog-actions"><button type="button" class="button tutorhelper-lms-button--grey" data-tutorhelper-lms-import-close><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></button><button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Save preview correction', 'tutorhelper-lms' ); ?></button></p>
			</form>
		</dialog>
		<?php
	}

	/**
	 * Render temporary Course and Lesson mapping choices.
	 *
	 * These choices prepare the later execution plan; they do not create or
	 * modify Subjects, Grade Systems, Topics, Courses or Lessons.
	 *
	 * @param array $preview Current temporary preview.
	 * @return void
	 */
	private static function render_mapping_worksheet( $preview ) {
		$mapping = is_array( $preview['mappings'] ?? null ) ? $preview['mappings'] : array();
		$subjects = get_terms( array( 'taxonomy' => 'tutorhelper_lms_subject', 'hide_empty' => false ) );
		$grade_systems = get_posts( array( 'post_type' => 'th_lms_grade_system', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$existing_topics = get_posts( array( 'post_type' => 'tutorhelper_topic', 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$source_topics = is_array( $preview['course']['topics'] ?? null ) ? $preview['course']['topics'] : array();
		?>
		<section class="tutorhelper-lms-import__mapping">
			<h3><?php esc_html_e( 'Choose import mappings', 'tutorhelper-lms' ); ?></h3>
			<p><?php esc_html_e( 'These choices are saved only with this temporary preview. They do not create or alter any learning content until you approve the later import step.', 'tutorhelper-lms' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_MAPPING_ACTION ); ?>" />
				<?php wp_nonce_field( self::SAVE_MAPPING_ACTION ); ?>
				<div class="tutorhelper-lms-import__mapping-card">
					<h4><?php esc_html_e( 'Course mapping', 'tutorhelper-lms' ); ?></h4>
					<?php if ( ! empty( $preview['course']['courses'] ) ) : ?><p><strong><?php esc_html_e( 'Imported Course:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( implode( ', ', wp_list_pluck( $preview['course']['courses'], 'title' ) ) ); ?></p><?php endif; ?>
					<div class="tutorhelper-lms-import__mapping-fields">
						<label><?php esc_html_e( 'TutorHelper Subject', 'tutorhelper-lms' ); ?>
							<select name="course_subject_id"><option value=""><?php esc_html_e( 'Choose a Subject…', 'tutorhelper-lms' ); ?></option><?php foreach ( is_array( $subjects ) ? $subjects : array() as $subject ) : ?><option value="<?php echo esc_attr( $subject->term_id ); ?>" <?php selected( absint( $mapping['course_subject_id'] ?? 0 ), $subject->term_id ); ?>><?php echo esc_html( $subject->name ); ?></option><?php endforeach; ?></select>
						</label>
						<label><?php esc_html_e( 'Grade system', 'tutorhelper-lms' ); ?>
							<select name="course_grade_system_id"><option value=""><?php esc_html_e( 'Choose a grade system…', 'tutorhelper-lms' ); ?></option><?php foreach ( $grade_systems as $system ) : ?><option value="<?php echo esc_attr( $system->ID ); ?>" <?php selected( absint( $mapping['course_grade_system_id'] ?? 0 ), $system->ID ); ?>><?php echo esc_html( $system->post_title ); ?></option><?php endforeach; ?></select>
						</label>
					</div>
					<?php if ( empty( $subjects ) || empty( $grade_systems ) ) : ?><p class="description"><?php esc_html_e( 'If a dropdown is empty, you can create that reusable Subject or Grade System in Learning Hub before running the final import.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
				</div>
				<div class="tutorhelper-lms-import__mapping-card">
					<h4><?php esc_html_e( 'Lesson topic mapping', 'tutorhelper-lms' ); ?></h4>
					<p class="description"><?php esc_html_e( 'For each Lesson, choose whether it should use one existing TutorHelper Topic while you organise it later, use a Topic from this LearnDash export, or create a new Topic when the final import runs.', 'tutorhelper-lms' ); ?></p>
					<?php foreach ( (array) ( $preview['course']['lessons'] ?? array() ) as $index => $lesson ) : ?>
						<?php $lesson_title = is_array( $lesson ) ? (string) ( $lesson['title'] ?? '' ) : (string) $lesson; ?>
						<?php $lesson_mapping = is_array( $mapping['lessons'][ $index ] ?? null ) ? $mapping['lessons'][ $index ] : array(); ?>
						<div class="tutorhelper-lms-import__lesson-map">
							<h5><?php echo esc_html( $lesson_title ); ?></h5>
							<div class="tutorhelper-lms-import__mapping-fields">
								<label><?php esc_html_e( 'Plan', 'tutorhelper-lms' ); ?>
									<select name="lesson_mappings[<?php echo esc_attr( $index ); ?>][mode]">
										<option value="course_topic" <?php selected( $lesson_mapping['mode'] ?? 'course_topic', 'course_topic' ); ?>><?php esc_html_e( 'Use one existing TutorHelper Topic', 'tutorhelper-lms' ); ?></option>
										<option value="source_topic" <?php selected( $lesson_mapping['mode'] ?? '', 'source_topic' ); ?> <?php disabled( empty( $source_topics ) ); ?>><?php esc_html_e( 'Use an imported LearnDash Topic', 'tutorhelper-lms' ); ?></option>
										<option value="new_topic" <?php selected( $lesson_mapping['mode'] ?? '', 'new_topic' ); ?>><?php esc_html_e( 'Create a new Topic for this Lesson', 'tutorhelper-lms' ); ?></option>
									</select>
								</label>
								<label><?php esc_html_e( 'Existing TutorHelper Topic', 'tutorhelper-lms' ); ?>
									<select name="lesson_mappings[<?php echo esc_attr( $index ); ?>][topic_id]"><option value=""><?php esc_html_e( 'Choose a Topic…', 'tutorhelper-lms' ); ?></option><?php foreach ( $existing_topics as $topic ) : ?><option value="<?php echo esc_attr( $topic->ID ); ?>" <?php selected( absint( $lesson_mapping['topic_id'] ?? 0 ), $topic->ID ); ?>><?php echo esc_html( $topic->post_title ); ?></option><?php endforeach; ?></select>
								</label>
								<label><?php esc_html_e( 'Imported LearnDash Topic', 'tutorhelper-lms' ); ?>
									<select name="lesson_mappings[<?php echo esc_attr( $index ); ?>][source_topic]"><option value=""><?php echo empty( $source_topics ) ? esc_html__( 'No Topics in this export', 'tutorhelper-lms' ) : esc_html__( 'Choose an imported Topic…', 'tutorhelper-lms' ); ?></option><?php foreach ( $source_topics as $source_topic ) : ?><option value="<?php echo esc_attr( $source_topic ); ?>" <?php selected( $lesson_mapping['source_topic'] ?? '', $source_topic ); ?>><?php echo esc_html( $source_topic ); ?></option><?php endforeach; ?></select>
								</label>
								<label><?php esc_html_e( 'New Topic name', 'tutorhelper-lms' ); ?><input type="text" name="lesson_mappings[<?php echo esc_attr( $index ); ?>][new_topic_name]" value="<?php echo esc_attr( $lesson_mapping['new_topic_name'] ?? '' ); ?>" placeholder="<?php echo esc_attr( $lesson_title ); ?>" /></label>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
				<button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Save preview mappings', 'tutorhelper-lms' ); ?></button>
			</form>
		</section>
		<?php
	}

	/**
	 * Create the reviewed Question CSV rows as reusable Question Bank records.
	 *
	 * This endpoint deliberately ignores Course and Quiz source data. It only
	 * executes the CSV records currently held in the signed-in tutor's preview.
	 *
	 * @return void
	 */
	public static function execute_csv_questions() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to create imported Questions.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::EXECUTE_CSV_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) ) {
			wp_safe_redirect( self::import_url( 'expired' ) );
			exit;
		}
		$records = is_array( $preview['csv_questions']['records'] ?? null ) ? $preview['csv_questions']['records'] : array();
		if ( empty( $records ) ) {
			wp_safe_redirect( self::import_url( 'expired' ) );
			exit;
		}
		if ( empty( $_POST['confirm_csv_question_create'] ) ) {
			wp_safe_redirect( self::import_url( 'csv_confirmation_needed' ) );
			exit;
		}
		if ( ! empty( $preview['errors'] ) || ! self::csv_records_ready( $records ) ) {
			wp_safe_redirect( self::import_url( 'csv_review_needed' ) );
			exit;
		}
		$results = array();
		$created = 0;
		$existing = 0;
		$failed = 0;
		foreach ( $records as $index => $record ) {
			$title = (string) ( $record['title'] ?? __( 'Untitled Question', 'tutorhelper-lms' ) );
			if ( ! empty( $record['created_question_id'] ) ) {
				$results[] = sprintf( __( '%1$s — already created as Question #%2$d.', 'tutorhelper-lms' ), $title, absint( $record['created_question_id'] ) );
				$existing++;
				continue;
			}
			$result = TutorHelper_LMS_Question_Bank::create_from_import( $record );
			if ( is_wp_error( $result ) ) {
				$results[] = sprintf( __( '%1$s — could not be created: %2$s', 'tutorhelper-lms' ), $title, $result->get_error_message() );
				$preview['csv_questions']['records'][ $index ]['execution_error'] = $result->get_error_message();
				$failed++;
				continue;
			}
			$question_id = absint( $result['question_id'] ?? 0 );
			if ( ! $question_id ) {
				$results[] = sprintf( __( '%s — could not be created.', 'tutorhelper-lms' ), $title );
				$failed++;
				continue;
			}
			$preview['csv_questions']['records'][ $index ]['created_question_id'] = $question_id;
			unset( $preview['csv_questions']['records'][ $index ]['execution_error'] );
			if ( ! empty( $result['created'] ) ) {
				$results[] = sprintf( __( '%1$s — created as Question #%2$d.', 'tutorhelper-lms' ), $title, $question_id );
				$created++;
			} else {
				$results[] = sprintf( __( '%1$s — already created as Question #%2$d.', 'tutorhelper-lms' ), $title, $question_id );
				$existing++;
			}
		}
		$preview['csv_questions']['execution'] = array(
			'created'  => $created,
			'existing' => $existing,
			'failed'   => $failed,
			'results'  => $results,
		);
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		wp_safe_redirect( self::import_url( $failed ? 'csv_created_with_errors' : 'csv_created' ) );
		exit;
	}

	/**
	 * Store tutor mapping choices only in the current short-lived preview.
	 *
	 * @return void
	 */
	public static function save_mappings() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update import mappings.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::SAVE_MAPPING_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) || empty( $preview['course'] ) ) {
			wp_safe_redirect( self::import_url( 'expired' ) );
			exit;
		}
		$subject_id = isset( $_POST['course_subject_id'] ) ? absint( wp_unslash( $_POST['course_subject_id'] ) ) : 0;
		$grade_system_id = isset( $_POST['course_grade_system_id'] ) ? absint( wp_unslash( $_POST['course_grade_system_id'] ) ) : 0;
		$mappings = array(
			'course_subject_id' => self::valid_subject_id( $subject_id ),
			'course_grade_system_id' => self::valid_grade_system_id( $grade_system_id ),
			'lessons' => array(),
		);
		$posted_lessons = isset( $_POST['lesson_mappings'] ) && is_array( $_POST['lesson_mappings'] ) ? wp_unslash( $_POST['lesson_mappings'] ) : array();
		$source_topics = array_values( (array) ( $preview['course']['topics'] ?? array() ) );
		$lessons = array_values( (array) ( $preview['course']['lessons'] ?? array() ) );
		foreach ( $lessons as $index => $unused_lesson_title ) {
			$row = is_array( $posted_lessons[ $index ] ?? null ) ? $posted_lessons[ $index ] : array();
			$mode = sanitize_key( $row['mode'] ?? 'course_topic' );
			if ( ! in_array( $mode, array( 'course_topic', 'source_topic', 'new_topic' ), true ) ) {
				$mode = 'course_topic';
			}
			$mappings['lessons'][ $index ] = self::sanitise_lesson_mapping( $row, $source_topics );
		}
		$preview['mappings'] = $mappings;
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		wp_safe_redirect( self::import_url( 'mappings_saved' ) );
		exit;
	}

	/**
	 * Save a correction to the short-lived import preview only.
	 *
	 * @return void
	 */
	public static function save_sanitisation() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to correct import data.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::SAVE_SANITISATION_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) ) {
			wp_safe_redirect( self::import_url( 'expired' ) );
			exit;
		}
		$kind = isset( $_POST['audit_kind'] ) ? sanitize_key( wp_unslash( $_POST['audit_kind'] ) ) : '';
		$id = isset( $_POST['audit_id'] ) ? sanitize_text_field( wp_unslash( $_POST['audit_id'] ) ) : '';
		$field = isset( $_POST['audit_field'] ) ? sanitize_key( wp_unslash( $_POST['audit_field'] ) ) : '';
		if ( 'course' === $kind && isset( $preview['course']['courses'][ absint( $id ) ] ) ) {
			if ( 'title' === $field ) {
				$preview['course']['courses'][ absint( $id ) ]['title'] = isset( $_POST['audit_title'] ) ? sanitize_text_field( wp_unslash( $_POST['audit_title'] ) ) : '';
			} elseif ( 'subject' === $field ) {
				$preview['mappings']['course_subject_id'] = self::valid_subject_id( $_POST['course_subject_id'] ?? 0 );
			} elseif ( 'grade' === $field ) {
				$preview['mappings']['course_grade_system_id'] = self::valid_grade_system_id( $_POST['course_grade_system_id'] ?? 0 );
			}
		} elseif ( 'lesson' === $kind && isset( $preview['course']['lessons'][ absint( $id ) ] ) ) {
			$index = absint( $id );
			if ( 'title' === $field && is_array( $preview['course']['lessons'][ $index ] ) ) {
				$preview['course']['lessons'][ $index ]['title'] = isset( $_POST['audit_title'] ) ? sanitize_text_field( wp_unslash( $_POST['audit_title'] ) ) : '';
			} elseif ( 'topic' === $field ) {
				$preview['mappings']['lessons'][ $index ] = self::sanitise_lesson_mapping( array(
					'mode' => $_POST['lesson_mode'] ?? '',
					'topic_id' => $_POST['lesson_topic_id'] ?? 0,
					'source_topic' => $_POST['lesson_source_topic'] ?? '',
					'new_topic_name' => $_POST['lesson_new_topic_name'] ?? '',
				), $preview['course']['topics'] ?? array() );
			}
		} elseif ( 'question' === $kind ) {
			$records = array();
			foreach ( $preview['quizzes'] as &$quiz ) {
				$records[] =& $quiz['records'];
			}
			if ( ! empty( $preview['csv_questions']['records'] ) && is_array( $preview['csv_questions']['records'] ) ) {
				$records[] =& $preview['csv_questions']['records'];
			}
			foreach ( $records as &$record_group ) {
				foreach ( $record_group as &$record ) {
					if ( $id !== ( $record['id'] ?? '' ) ) {
						continue;
					}
					if ( 'title' === $field ) {
						$record['title'] = isset( $_POST['audit_title'] ) ? sanitize_text_field( wp_unslash( $_POST['audit_title'] ) ) : '';
					} elseif ( 'prompt' === $field ) {
						$record['prompt'] = isset( $_POST['audit_prompt'] ) ? wp_kses_post( wp_unslash( $_POST['audit_prompt'] ) ) : '';
					} elseif ( 'marks' === $field ) {
						$record['marks'] = isset( $_POST['audit_marks'] ) ? absint( wp_unslash( $_POST['audit_marks'] ) ) : 0;
					} elseif ( in_array( $field, array( 'options', 'correct', 'pairs', 'pattern' ), true ) ) {
						$record['answers'] = self::sanitise_answer_lines( $_POST['audit_answers'] ?? '', $_POST['audit_correct'] ?? '', $record['type'] ?? '' );
					} elseif ( in_array( $field, array( 'correct_feedback', 'incorrect_feedback', 'tip' ), true ) ) {
						$record[ $field ] = isset( $_POST['audit_text'] ) ? wp_kses_post( wp_unslash( $_POST['audit_text'] ) ) : '';
					}
					break 2;
				}
			}
			unset( $record, $record_group, $quiz );
		}
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		wp_safe_redirect( self::import_url( 'sanitised' ) );
		exit;
	}

	/**
	 * Convert editable modal lines into safe temporary answers.
	 *
	 * @param mixed  $lines Posted answer text.
	 * @param mixed  $correct Posted correct answer numbers.
	 * @param string $type Source Question type.
	 * @return array
	 */
	private static function sanitise_answer_lines( $lines, $correct, $type ) {
		$rows = preg_split( '/\\r\\n|\\r|\\n/', sanitize_textarea_field( wp_unslash( $lines ) ) );
		$correct_indexes = array_map( 'absint', preg_split( '/\\s*,\\s*/', sanitize_text_field( wp_unslash( $correct ) ) ) );
		$answers = array();
		foreach ( is_array( $rows ) ? $rows : array() as $index => $row ) {
			$row = trim( $row );
			if ( '' === $row ) {
				continue;
			}
			$match = '';
			if ( in_array( $type, array( 'matrix_sort_answer', 'matrix_sort' ), true ) && false !== strpos( $row, '=>' ) ) {
				list( $row, $match ) = array_map( 'trim', explode( '=>', $row, 2 ) );
			}
			$answers[] = array(
				'text' => wp_kses_post( $row ),
				'match' => sanitize_text_field( $match ),
				'correct' => in_array( $index + 1, $correct_indexes, true ),
			);
		}
		return $answers;
	}

	/**
	 * Validate a Subject selection from a temporary preview form.
	 *
	 * @param mixed $subject_id Subject term ID.
	 * @return int
	 */
	private static function valid_subject_id( $subject_id ) {
		$subject_id = absint( wp_unslash( $subject_id ) );
		return term_exists( $subject_id, 'tutorhelper_lms_subject' ) ? $subject_id : 0;
	}

	/**
	 * Validate a Grade System selection from a temporary preview form.
	 *
	 * @param mixed $grade_system_id Grade system post ID.
	 * @return int
	 */
	private static function valid_grade_system_id( $grade_system_id ) {
		$grade_system_id = absint( wp_unslash( $grade_system_id ) );
		return 'th_lms_grade_system' === get_post_type( $grade_system_id ) ? $grade_system_id : 0;
	}

	/**
	 * Validate one temporary Lesson mapping row.
	 *
	 * @param array $row Posted mapping data.
	 * @param array $source_topics Imported Topic titles.
	 * @return array
	 */
	private static function sanitise_lesson_mapping( $row, $source_topics ) {
		$mode = sanitize_key( $row['mode'] ?? 'course_topic' );
		if ( ! in_array( $mode, array( 'course_topic', 'source_topic', 'new_topic' ), true ) ) {
			$mode = 'course_topic';
		}
		$topic_id = absint( $row['topic_id'] ?? 0 );
		$source_topic = sanitize_text_field( $row['source_topic'] ?? '' );
		return array(
			'mode' => $mode,
			'topic_id' => 'tutorhelper_topic' === get_post_type( $topic_id ) ? $topic_id : 0,
			'source_topic' => in_array( $source_topic, array_values( (array) $source_topics ), true ) ? $source_topic : '',
			'new_topic_name' => sanitize_text_field( $row['new_topic_name'] ?? '' ),
		);
	}

	/**
	 * Build the Import tab URL carrying a compact preview notice.
	 *
	 * @param string $notice Notice identifier.
	 * @return string
	 */
	private static function import_url( $notice = '' ) {
		$args = array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => self::SECTION_KEY );
		if ( '' !== $notice ) {
			$args['tutorhelper_lms_import_preview'] = sanitize_key( $notice );
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	private static function render_notices() {
		$notice = isset( $_GET['tutorhelper_lms_import_preview'] ) ? sanitize_key( wp_unslash( $_GET['tutorhelper_lms_import_preview'] ) ) : '';
		if ( 'ready' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your files were checked. Review the preview below; no LMS content has been changed.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'mappings_saved' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your preview mappings were saved. No LMS content has been created or changed.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'sanitised' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your import-preview correction was saved. No LMS content has been created or changed.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'csv_confirmation_needed' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Confirm that you want to create the reviewed Questions before continuing.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'csv_review_needed' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Fix every required CSV audit field before creating Questions.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'csv_created' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your reviewed CSV Questions were created. They are ready in the Question Bank.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'csv_created_with_errors' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Some CSV Questions could not be created. Review the results below before trying again.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'expired' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'This preview has expired. Upload the export files again to start a new preview.', 'tutorhelper-lms' ) . '</p></div>';
		}
	}

	/**
	 * Return the current tutor's temporary preview key.
	 *
	 * @return string
	 */
	private static function preview_key() {
		return 'tutorhelper_lms_import_preview_' . get_current_user_id();
	}
}
