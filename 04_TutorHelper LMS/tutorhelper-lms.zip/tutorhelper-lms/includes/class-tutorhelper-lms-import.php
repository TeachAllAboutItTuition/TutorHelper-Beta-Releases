<?php
/**
 * Read-only LearnDash migration preview for TutorHelper LMS.
 *
 * Uploads are parsed in the current administrator request and are never copied
 * into the WordPress Media Library or retained as source files.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Import {

	const SECTION_KEY   = 'import';
	const PREVIEW_ACTION = 'tutorhelper_lms_preview_import';
	const SAVE_MAPPING_ACTION = 'tutorhelper_lms_save_import_mapping';
	const SAVE_SANITISATION_ACTION = 'tutorhelper_lms_save_import_sanitisation';
	const EXECUTE_CSV_ACTION = 'tutorhelper_lms_execute_question_csv_import';
	const EXECUTE_LEARNDASH_ACTION = 'tutorhelper_lms_execute_learndash_question_import';
	const EXECUTE_LEARNDASH_QUIZ_ACTION = 'tutorhelper_lms_execute_learndash_quiz_import';
	const SELECT_LOCAL_IMAGE_ACTION = 'tutorhelper_lms_select_import_media_image';
	const REFRESH_LEARNDASH_CREATION_ACTION = 'tutorhelper_lms_refresh_learndash_creation';
	const REFRESH_CSV_CREATION_ACTION = 'tutorhelper_lms_refresh_csv_creation';
	const SAVE_RUN_ACTION = 'tutorhelper_lms_save_import_run';
	const RESUME_RUN_ACTION = 'tutorhelper_lms_resume_import_run';
	const PREPARE_RUN_ACTION = 'tutorhelper_lms_prepare_import_run_batch';
	const PAUSE_RUN_ACTION = 'tutorhelper_lms_pause_import_run';
	const CHECK_EXTERNAL_IMAGE_ACTION = 'tutorhelper_lms_check_external_image';
	const SET_EXTERNAL_IMAGE_ACTION = 'tutorhelper_lms_set_external_image';
	const PREVIEW_TTL   = 15 * MINUTE_IN_SECONDS;

	/**
	 * Register the Learning Hub workspace and secure preview endpoint.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'tutorhelper_lms_learning_hub_sections', array( __CLASS__, 'add_section' ) );
		add_filter( 'tutorhelper_lms_learning_hub_render_tab', array( __CLASS__, 'render_tab' ), 10, 3 );
		add_action( 'admin_post_' . self::PREVIEW_ACTION, array( __CLASS__, 'preview_uploads' ) );
		add_action( 'admin_post_' . self::SAVE_MAPPING_ACTION, array( __CLASS__, 'save_mappings' ) );
		add_action( 'admin_post_' . self::SAVE_SANITISATION_ACTION, array( __CLASS__, 'save_sanitisation' ) );
		add_action( 'admin_post_' . self::EXECUTE_CSV_ACTION, array( __CLASS__, 'execute_csv_questions' ) );
		add_action( 'admin_post_' . self::EXECUTE_LEARNDASH_ACTION, array( __CLASS__, 'execute_learndash_questions' ) );
		add_action( 'admin_post_' . self::EXECUTE_LEARNDASH_QUIZ_ACTION, array( __CLASS__, 'execute_learndash_quizzes' ) );
		add_action( 'wp_ajax_tutorhelper_lms_select_import_media_image', array( __CLASS__, 'select_import_media_image' ) );
		add_action( 'wp_ajax_' . self::REFRESH_LEARNDASH_CREATION_ACTION, array( __CLASS__, 'refresh_learndash_creation' ) );
		add_action( 'wp_ajax_' . self::REFRESH_CSV_CREATION_ACTION, array( __CLASS__, 'refresh_csv_creation' ) );
		add_action( 'admin_post_' . self::SAVE_RUN_ACTION, array( __CLASS__, 'save_import_run' ) );
		add_action( 'admin_post_' . self::RESUME_RUN_ACTION, array( __CLASS__, 'resume_import_run' ) );
		add_action( 'admin_post_' . self::PREPARE_RUN_ACTION, array( __CLASS__, 'prepare_import_run_batch' ) );
		add_action( 'admin_post_' . self::PAUSE_RUN_ACTION, array( __CLASS__, 'pause_import_run' ) );
		add_action( 'admin_post_' . self::CHECK_EXTERNAL_IMAGE_ACTION, array( __CLASS__, 'check_external_image' ) );
		add_action( 'admin_post_' . self::SET_EXTERNAL_IMAGE_ACTION, array( __CLASS__, 'set_external_image_preference' ) );
		add_action( 'wp_ajax_tutorhelper_lms_refresh_external_image_table', array( __CLASS__, 'refresh_external_image_table' ) );
	}

	/**
	 * Add Import alongside the other Learning Hub workspaces.
	 *
	 * @param array $sections Existing sections.
	 * @return array
	 */
	public static function add_section( $sections ) {
		$sections[ self::SECTION_KEY ] = array(
			'label'       => __( 'Import', 'tutorhelper-lms' ),
			'icon'        => 'dashicons-upload',
			'description' => __( 'Preview content from another LMS before creating anything here.', 'tutorhelper-lms' ),
		);
		return $sections;
	}

	/**
	 * Render the import workspace through the Learning Hub extension point.
	 *
	 * @param bool   $handled Whether another extension has rendered the tab.
	 * @param string $tab Selected tab.
	 * @param array  $sections Known Learning Hub sections.
	 * @return bool
	 */
	public static function render_tab( $handled, $tab, $sections ) {
		if ( $handled || self::SECTION_KEY !== $tab ) {
			return $handled;
		}
		self::render_workspace();
		return true;
	}

	/**
	 * Render friendly guidance, uploads and the current no-write preview.
	 *
	 * @return void
	 */
	private static function render_workspace() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		wp_enqueue_media();
		$preview = get_transient( self::preview_key() );
		?>
		<section class="tutorhelper-main-section tutorhelper-lms-import">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'Import learning content', 'tutorhelper-lms' ); ?></h2>
					<p><?php esc_html_e( 'Bring across your Course structure and Quiz Question banks in a controlled, review-first way.', 'tutorhelper-lms' ); ?></p>
				</div>
			</header>
			<div class="tutorhelper-main-section__body">
				<?php self::render_notices(); ?>
				<?php self::render_saved_runs(); ?>
				<details class="tutorhelper-lms-import__guide" open>
					<summary><?php esc_html_e( 'How to move LearnDash content across', 'tutorhelper-lms' ); ?></summary>
					<div class="tutorhelper-lms-import__guide-body">
						<ol>
							<li><?php esc_html_e( 'Use the LearnDash export tools, or the WooNinjas export plugin, to export the Course structure and save its JSON file.', 'tutorhelper-lms' ); ?></li>
							<li><?php esc_html_e( 'Export each Quiz or Question bank from the LearnDash Quiz Import/Export tool. You can select several JSON files below.', 'tutorhelper-lms' ); ?></li>
							<li><?php esc_html_e( 'Upload the files and review the preview. This stage does not create, change or delete anything.', 'tutorhelper-lms' ); ?></li>
							<li><?php esc_html_e( 'Use the preview to check titles, Question totals, image sources and warnings before the import step is enabled.', 'tutorhelper-lms' ); ?></li>
						</ol>
						<div class="tutorhelper-lms-import__guide-grid">
							<div>
								<h3><?php esc_html_e( 'The preview can prepare', 'tutorhelper-lms' ); ?></h3>
								<p><?php esc_html_e( 'Course and Lesson titles/content, common Quiz settings including random Question pools and timed access, plus image-rich Question prompts, answers, feedback and marks for supported Question types.', 'tutorhelper-lms' ); ?></p>
							</div>
							<div>
								<h3><?php esc_html_e( 'This review will not create or copy', 'tutorhelper-lms' ); ?></h3>
								<p><?php esc_html_e( 'Students, enrolments, previous attempts, grades, certificates, payments, reports, email rules, WordPress Media Library files or the contents of external links.', 'tutorhelper-lms' ); ?></p>
							</div>
						</div>
						<p class="description"><?php esc_html_e( 'The preview supports image-rich Questions, random Question pools and timed access. It flags prerequisites and any Question type TutorHelper does not yet support for review rather than guessing.', 'tutorhelper-lms' ); ?></p>
						<section class="tutorhelper-lms-import__settings-review" aria-labelledby="tutorhelper-lms-import-settings-review">
							<h3 id="tutorhelper-lms-import-settings-review"><?php esc_html_e( 'LearnDash Quiz settings review', 'tutorhelper-lms' ); ?></h3>
							<div class="tutorhelper-lms-import__guide-grid">
								<div>
									<h4><?php esc_html_e( 'Imported', 'tutorhelper-lms' ); ?></h4>
									<p><?php esc_html_e( 'Compatible pass marks, completed-attempt limits, random Question pools, timers when Premium is active, start-screen behaviour and result-message rules are carried into the reviewed Quiz plan.', 'tutorhelper-lms' ); ?></p>
								</div>
								<div>
									<h4><?php esc_html_e( 'Adapted for TutorHelper', 'tutorhelper-lms' ); ?></h4>
									<p><?php esc_html_e( 'A LearnDash Quiz that does not autostart becomes a TutorHelper start screen: instructions are shown and the timer begins only after Begin Quiz. TutorHelper keeps accessible back navigation, its own progress display and its own answer-shuffle behaviour.', 'tutorhelper-lms' ); ?></p>
								</div>
								<div>
									<h4><?php esc_html_e( 'Not created by this import', 'tutorhelper-lms' ); ?></h4>
									<p><?php esc_html_e( 'No-back or forced-answer navigation, leaderboards, legacy statistics and IP locks, resume cookies, custom forms, email templates, certificates, students, enrolments or historical attempts are not copied. Prerequisites are flagged for review until TutorHelper prerequisite rules are available.', 'tutorhelper-lms' ); ?></p>
								</div>
							</div>
							<p class="description"><?php esc_html_e( 'This is intentional: TutorHelper does not silently recreate settings that would reduce accessibility, expose student identity, or need a different shared TutorHelper model. Badge awards will be the future replacement for certificate rules.', 'tutorhelper-lms' ); ?></p>
						</section>
					</div>
				</details>

				<form class="tutorhelper-lms-import__form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::PREVIEW_ACTION ); ?>" />
					<?php wp_nonce_field( self::PREVIEW_ACTION ); ?>
					<div class="tutorhelper-lms-import__upload-grid">
						<label>
							<strong><?php esc_html_e( 'LearnDash Course JSON (optional)', 'tutorhelper-lms' ); ?></strong>
							<input type="file" name="learndash_course_file" accept=".json,application/json" />
							<span><?php esc_html_e( 'Use this for Course, Topic and Lesson structure.', 'tutorhelper-lms' ); ?></span>
						</label>
						<label>
							<strong><?php esc_html_e( 'LearnDash Quiz JSON files', 'tutorhelper-lms' ); ?></strong>
							<input type="file" name="learndash_quiz_files[]" accept=".json,application/json" multiple />
							<span><?php esc_html_e( 'Choose one or more full Quiz exports from the LearnDash Quiz Import/Export tool.', 'tutorhelper-lms' ); ?></span>
						</label>
						<label>
							<strong><?php esc_html_e( 'LearnDash Quiz Question JSON files (optional)', 'tutorhelper-lms' ); ?></strong>
							<input type="file" name="learndash_quiz_question_files[]" accept=".json,application/json" multiple />
							<span><?php esc_html_e( 'Choose one or more Question-bank exports to review separately. They are scanned privately before an IM0 import run is saved.', 'tutorhelper-lms' ); ?></span>
						</label>
						<label>
							<strong><?php esc_html_e( 'TutorHelper Question CSV (optional)', 'tutorhelper-lms' ); ?></strong>
							<input type="file" name="tutorhelper_questions_csv_file" accept=".csv,text/csv" />
							<span><?php esc_html_e( 'Use the TutorHelper Question Bank CSV template to check Questions before creating any.', 'tutorhelper-lms' ); ?></span>
						</label>
					</div>
					<p class="description"><?php esc_html_e( 'The source JSON files are not saved to your Media Library or added to the plugin. TutorHelper keeps a short-lived private preview only while you review and correct the import.', 'tutorhelper-lms' ); ?></p>
					<button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Preview imports', 'tutorhelper-lms' ); ?></button>
				</form>

				<?php if ( is_array( $preview ) ) : ?>
					<?php self::render_preview( $preview ); ?>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	/**
	 * Parse uploaded JSON into a summary without creating any LMS records.
	 *
	 * @return void
	 */
	public static function preview_uploads() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to import learning content.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::PREVIEW_ACTION );

		$summary = array(
			'created_at' => current_time( 'timestamp' ),
			'course'     => null,
			'quizzes'    => array(),
			'csv_questions' => null,
			'errors'     => array(),
			'warnings'   => array(),
			'mappings'   => array(),
		);

		$course_file = self::single_uploaded_file( 'learndash_course_file' );
		if ( $course_file ) {
			$data = self::read_json_upload( $course_file, $summary['errors'] );
			if ( is_array( $data ) ) {
				$course = self::preview_course_export( $data );
				if ( is_wp_error( $course ) ) {
					$summary['errors'][] = $course->get_error_message();
				} else {
					$summary['course'] = $course;
				}
			}
		}

		foreach ( array( 'learndash_quiz_files', 'learndash_quiz_question_files' ) as $quiz_upload_field ) {
			foreach ( self::multiple_uploaded_files( $quiz_upload_field ) as $quiz_file ) {
				$data = self::read_json_upload( $quiz_file, $summary['errors'] );
				if ( ! is_array( $data ) ) {
					continue;
				}
				$quizzes = self::preview_quiz_export( $data, $quiz_file['name'] );
				if ( is_wp_error( $quizzes ) ) {
					$summary['errors'][] = $quizzes->get_error_message();
					continue;
				}
				$summary['quizzes'] = array_merge( $summary['quizzes'], $quizzes );
			}
		}

		$csv_file = self::single_uploaded_file( 'tutorhelper_questions_csv_file' );
		if ( $csv_file ) {
			$csv_preview = self::preview_question_csv( $csv_file, $summary['errors'], $summary['warnings'] );
			if ( is_array( $csv_preview ) ) {
				$summary['csv_questions'] = $csv_preview;
			}
		}

		if ( ! $summary['course'] && empty( $summary['quizzes'] ) && empty( $summary['csv_questions'] ) && empty( $summary['errors'] ) ) {
			$summary['errors'][] = __( 'Choose at least one LearnDash Course JSON file, LearnDash Quiz JSON file, LearnDash Quiz Question JSON file or TutorHelper Question CSV file to preview.', 'tutorhelper-lms' );
		}

		if ( ! empty( $summary['quizzes'] ) ) {
			foreach ( $summary['quizzes'] as $quiz ) {
				if ( ! empty( $quiz['uses_random_pool'] ) ) {
					$summary['warnings'][] = sprintf( __( '%1$s will create an Adaptive Practice Quiz with %2$d Questions per attempt after every reviewed Question is available.', 'tutorhelper-lms' ), $quiz['title'], absint( $quiz['random_question_count'] ?? 0 ) );
				}
				if ( ! empty( $quiz['time_limit'] ) ) {
					$summary['warnings'][] = sprintf( __( '%1$s will retain its %2$s time limit when TutorHelper LMS Premium is active; otherwise Quiz creation will remain blocked.', 'tutorhelper-lms' ), $quiz['title'], human_time_diff( 0, absint( $quiz['time_limit'] ) ) );
				}
				if ( ! empty( $quiz['requires_premium'] ) ) {
					$summary['warnings'][] = sprintf( __( '%s includes written-answer Questions. They require TutorHelper LMS Premium when the import stage is enabled.', 'tutorhelper-lms' ), $quiz['title'] );
				}
				if ( ! empty( $quiz['unsupported_types'] ) ) {
					$summary['warnings'][] = sprintf( __( '%1$s includes unsupported LearnDash Question types: %2$s. They will not be created automatically.', 'tutorhelper-lms' ), $quiz['title'], implode( ', ', $quiz['unsupported_types'] ) );
				}
			}
		}

		set_transient( self::preview_key(), $summary, self::PREVIEW_TTL );
		wp_safe_redirect( add_query_arg( array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => self::SECTION_KEY, 'tutorhelper_lms_import_preview' => 'ready' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Return a validated optional single upload.
	 *
	 * @param string $field Form field name.
	 * @return array|null
	 */
	private static function single_uploaded_file( $field ) {
		if ( empty( $_FILES[ $field ] ) || ! is_array( $_FILES[ $field ] ) ) {
			return null;
		}
		$file = $_FILES[ $field ];
		return UPLOAD_ERR_NO_FILE === absint( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ? null : $file;
	}

	/**
	 * Normalise one multiple-file input.
	 *
	 * @param string $field Form field name.
	 * @return array[]
	 */
	private static function multiple_uploaded_files( $field ) {
		if ( empty( $_FILES[ $field ] ) || ! is_array( $_FILES[ $field ] ) || ! is_array( $_FILES[ $field ]['name'] ?? null ) ) {
			return array();
		}
		$files = array();
		foreach ( $_FILES[ $field ]['name'] as $index => $name ) {
			if ( UPLOAD_ERR_NO_FILE === absint( $_FILES[ $field ]['error'][ $index ] ?? UPLOAD_ERR_NO_FILE ) ) {
				continue;
			}
			$files[] = array(
				'name'     => $name,
				'type'     => $_FILES[ $field ]['type'][ $index ] ?? '',
				'tmp_name' => $_FILES[ $field ]['tmp_name'][ $index ] ?? '',
				'error'    => $_FILES[ $field ]['error'][ $index ] ?? UPLOAD_ERR_NO_FILE,
				'size'     => $_FILES[ $field ]['size'][ $index ] ?? 0,
			);
		}
		return $files;
	}

	/**
	 * Decode one temporary JSON upload while rejecting excessive or invalid files.
	 *
	 * @param array  $file Upload details.
	 * @param array &$errors Preview errors.
	 * @return array|null
	 */
	private static function read_json_upload( $file, &$errors ) {
		$name = sanitize_file_name( (string) ( $file['name'] ?? __( 'Uploaded file', 'tutorhelper-lms' ) ) );
		if ( UPLOAD_ERR_OK !== absint( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			$errors[] = sprintf( __( '%s could not be uploaded. Please try exporting it again.', 'tutorhelper-lms' ), $name );
			return null;
		}
		if ( strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) !== 'json' ) {
			$errors[] = sprintf( __( '%s is not a JSON file.', 'tutorhelper-lms' ), $name );
			return null;
		}
		if ( absint( $file['size'] ?? 0 ) > 10 * MB_IN_BYTES || ! is_uploaded_file( $file['tmp_name'] ?? '' ) ) {
			$errors[] = sprintf( __( '%s is too large or is not a valid upload.', 'tutorhelper-lms' ), $name );
			return null;
		}
		$raw = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reads one temporary administrator upload without retaining it.
		$data = is_string( $raw ) ? json_decode( $raw, true ) : null;
		if ( ! is_array( $data ) || JSON_ERROR_NONE !== json_last_error() ) {
			$errors[] = sprintf( __( '%s is not valid JSON.', 'tutorhelper-lms' ), $name );
			return null;
		}
		return $data;
	}

	/**
	 * Read and normalise the documented TutorHelper Question Bank CSV without
	 * retaining the uploaded source file or creating Question records.
	 *
	 * @param array  $file Upload details.
	 * @param array &$errors Preview errors.
	 * @param array &$warnings Preview warnings.
	 * @return array|null
	 */
	private static function preview_question_csv( $file, &$errors, &$warnings ) {
		$name = sanitize_file_name( (string) ( $file['name'] ?? __( 'Uploaded file', 'tutorhelper-lms' ) ) );
		if ( UPLOAD_ERR_OK !== absint( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			$errors[] = sprintf( __( '%s could not be uploaded. Please try again.', 'tutorhelper-lms' ), $name );
			return null;
		}
		if ( 'csv' !== strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) ) {
			$errors[] = sprintf( __( '%s is not a CSV file.', 'tutorhelper-lms' ), $name );
			return null;
		}
		if ( absint( $file['size'] ?? 0 ) > 10 * MB_IN_BYTES || ! is_uploaded_file( $file['tmp_name'] ?? '' ) ) {
			$errors[] = sprintf( __( '%s is too large or is not a valid upload.', 'tutorhelper-lms' ), $name );
			return null;
		}
		$handle = fopen( $file['tmp_name'], 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Reads one temporary administrator upload without retaining it.
		if ( ! $handle ) {
			$errors[] = sprintf( __( '%s could not be read.', 'tutorhelper-lms' ), $name );
			return null;
		}
		$headers = fgetcsv( $handle );
		$expected = array( 'source_reference', 'title', 'question_type', 'prompt', 'max_marks', 'student_explanation', 'incorrect_feedback', 'correct_feedback', 'answers_json', 'settings_json', 'status' );
		if ( is_array( $headers ) && isset( $headers[0] ) ) {
			$headers[0] = preg_replace( '/^\\xEF\\xBB\\xBF/', '', (string) $headers[0] );
		}
		if ( $expected !== $headers ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes the temporary upload handle.
			$errors[] = sprintf( __( '%s does not use the TutorHelper Question CSV template. Download a fresh template and keep its column headings in the same order.', 'tutorhelper-lms' ), $name );
			return null;
		}

		$records = array();
		$type_counts = array();
		$references = array();
		$row_number = 1;
		while ( false !== ( $row = fgetcsv( $handle ) ) ) {
			$row_number++;
			if ( array( null ) === $row || array() === $row ) {
				continue;
			}
			if ( count( $expected ) !== count( $row ) ) {
				$errors[] = sprintf( __( '%1$s row %2$d has the wrong number of columns.', 'tutorhelper-lms' ), $name, $row_number );
				continue;
			}
			$data = array_combine( $expected, $row );
			$record = self::normalise_question_csv_row( $data, $name, $row_number, $errors );
			if ( ! $record ) {
				continue;
			}
			$reference = $record['source_reference'];
			if ( '' === $reference ) {
				$warnings[] = sprintf( __( '%1$s row %2$d has no source reference. Add one before the final import so the Question can be traced back to its CSV row.', 'tutorhelper-lms' ), $name, $row_number );
			} elseif ( isset( $references[ $reference ] ) ) {
				$errors[] = sprintf( __( '%1$s has the source reference “%2$s” more than once (rows %3$d and %4$d). References must be unique.', 'tutorhelper-lms' ), $name, $reference, $references[ $reference ], $row_number );
			} else {
				$references[ $reference ] = $row_number;
			}
			$records[] = $record;
			$type_counts[ $record['label'] ] = absint( $type_counts[ $record['label'] ] ?? 0 ) + 1;
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes the temporary upload handle.
		if ( empty( $records ) ) {
			$errors[] = sprintf( __( '%s did not contain any valid Question rows to preview.', 'tutorhelper-lms' ), $name );
			return null;
		}
		return array(
			'source'      => $name,
			'title'       => __( 'TutorHelper Question CSV', 'tutorhelper-lms' ),
			'questions'   => count( $records ),
			'type_counts' => $type_counts,
			'records'     => $records,
		);
	}

	/**
	 * Convert one CSV row into the same temporary Question record used by the
	 * LearnDash audit. Problems are reported by row; no data is written to LMS.
	 *
	 * @param array  $data Row keyed by CSV heading.
	 * @param string $filename Safe CSV filename.
	 * @param int    $row_number CSV row number.
	 * @param array &$errors Preview errors.
	 * @return array|null
	 */
	private static function normalise_question_csv_row( $data, $filename, $row_number, &$errors ) {
		$type = sanitize_key( $data['question_type'] ?? '' );
		$types = array(
			'single_choice'   => __( 'Single choice', 'tutorhelper-lms' ),
			'multiple_choice' => __( 'Multiple choice', 'tutorhelper-lms' ),
			'free_answer'     => __( 'Short answer', 'tutorhelper-lms' ),
			'sort_answer'     => __( 'Sorting', 'tutorhelper-lms' ),
			'matrix_sort'     => __( 'Matching', 'tutorhelper-lms' ),
			'cloze'           => __( 'Fill in the blanks', 'tutorhelper-lms' ),
			'assessment'      => __( 'Assessment', 'tutorhelper-lms' ),
		);
		if ( ! isset( $types[ $type ] ) ) {
			$errors[] = sprintf( __( '%1$s row %2$d has an unsupported question_type.', 'tutorhelper-lms' ), $filename, $row_number );
			return null;
		}
		$answers_json = json_decode( (string) ( $data['answers_json'] ?? '' ), true );
		$settings_json = json_decode( (string) ( $data['settings_json'] ?? '' ), true );
		if ( ! is_array( $answers_json ) || JSON_ERROR_NONE !== json_last_error() || ! is_array( $settings_json ) ) {
			$errors[] = sprintf( __( '%1$s row %2$d needs valid JSON in both answers_json and settings_json.', 'tutorhelper-lms' ), $filename, $row_number );
			return null;
		}
		$status = sanitize_key( $data['status'] ?? '' );
		if ( ! in_array( $status, array( 'draft', 'published' ), true ) ) {
			$errors[] = sprintf( __( '%1$s row %2$d must use draft or published in the status column.', 'tutorhelper-lms' ), $filename, $row_number );
			return null;
		}
		$answers = self::normalise_csv_answers( $answers_json, $type );
		$record = array(
			'kind'               => 'question',
			'id'                 => 'csv-question-' . substr( sha1( $filename . '|' . $row_number . '|' . (string) ( $data['source_reference'] ?? '' ) ), 0, 16 ),
			'csv_row'            => $row_number,
			'source_reference'   => sanitize_text_field( $data['source_reference'] ?? '' ),
			'type'               => $type,
			'label'              => $types[ $type ],
			'status'             => 'supported',
			'import_status'      => $status,
			'title'              => sanitize_text_field( $data['title'] ?? '' ),
			'prompt'             => wp_kses_post( (string) ( $data['prompt'] ?? '' ) ),
			'marks'              => absint( $data['max_marks'] ?? 0 ),
			'tip'                => wp_kses_post( (string) ( $data['student_explanation'] ?? '' ) ),
			'incorrect_feedback' => wp_kses_post( (string) ( $data['incorrect_feedback'] ?? '' ) ),
			'correct_feedback'   => wp_kses_post( (string) ( $data['correct_feedback'] ?? '' ) ),
			'feedback_shared'    => false,
			'answers'            => $answers,
			'settings'           => $settings_json,
		);
		// Required-field gaps remain visible as clickable crosses in the audit
		// table, so a tutor can correct them in this temporary preview.
		return $record;
	}

	/**
	 * Map documented CSV answer shapes into temporary audit answer rows.
	 *
	 * @param array  $answers JSON answer object.
	 * @param string $type Question type.
	 * @return array
	 */
	private static function normalise_csv_answers( $answers, $type ) {
		$items = array();
		if ( in_array( $type, array( 'single_choice', 'multiple_choice' ), true ) ) {
			$correct = array_map( 'strval', is_array( $answers['correct'] ?? null ) ? $answers['correct'] : array() );
			foreach ( is_array( $answers['options'] ?? null ) ? $answers['options'] : array() as $index => $option ) {
				$items[] = array( 'text' => wp_kses_post( (string) $option ), 'correct' => in_array( (string) $index, $correct, true ), 'match' => '' );
			}
		} elseif ( 'free_answer' === $type ) {
			foreach ( is_array( $answers['accepted'] ?? null ) ? $answers['accepted'] : array() as $answer ) {
				$items[] = array( 'text' => wp_kses_post( (string) $answer ), 'correct' => true, 'match' => '' );
			}
		} elseif ( 'sort_answer' === $type ) {
			foreach ( is_array( $answers['items'] ?? null ) ? $answers['items'] : array() as $answer ) {
				$items[] = array( 'text' => wp_kses_post( (string) $answer ), 'correct' => true, 'match' => '' );
			}
		} elseif ( 'matrix_sort' === $type ) {
			foreach ( is_array( $answers['pairs'] ?? null ) ? $answers['pairs'] : array() as $pair ) {
				if ( is_array( $pair ) ) {
					$items[] = array( 'text' => wp_kses_post( (string) ( $pair['left'] ?? '' ) ), 'correct' => true, 'match' => wp_kses_post( (string) ( $pair['right'] ?? '' ) ) );
				}
			}
		} elseif ( 'cloze' === $type ) {
			foreach ( is_array( $answers['blanks'] ?? null ) ? $answers['blanks'] : array() as $answer ) {
				$items[] = array( 'text' => wp_kses_post( (string) $answer ), 'correct' => true, 'match' => '' );
			}
		}
		return $items;
	}

	/**
	 * Summarise the LearnDash Course JSON export without retaining its contents.
	 *
	 * @param array $data Decoded JSON.
	 * @return array|WP_Error
	 */
	private static function preview_course_export( $data ) {
		if ( ! isset( $data['courses'] ) || ! is_array( $data['courses'] ) ) {
			return new WP_Error( 'invalid_learndash_course', __( 'This file is not a recognised LearnDash Course JSON export.', 'tutorhelper-lms' ) );
		}
		$courses = array();
		foreach ( $data['courses'] as $index => $course ) {
			if ( ! is_array( $course ) ) {
				continue;
			}
			$title = sanitize_text_field( $course['title'] ?? '' );
			$courses[] = array(
				'id'          => 'course-' . absint( $index ),
				'title'       => $title,
				'has_content' => '' !== trim( wp_strip_all_tags( (string) ( $course['content'] ?? '' ) ) ),
			);
		}
		$lessons = array();
		foreach ( is_array( $data['lessons'] ?? null ) ? $data['lessons'] : array() as $index => $lesson ) {
			if ( ! is_array( $lesson ) ) {
				continue;
			}
			$lessons[] = array(
				'id'          => 'lesson-' . absint( $index ),
				'title'       => sanitize_text_field( $lesson['title'] ?? '' ),
				'has_content' => '' !== trim( wp_strip_all_tags( (string) ( $lesson['content'] ?? '' ) ) ),
			);
		}
		return array(
			'courses'      => $courses,
			'lessons'      => $lessons,
			'topics'       => self::title_list( $data['topics'] ?? array() ),
			'has_sections' => ! empty( $data['courses'][0]['course_sections'] ?? '' ),
		);
	}

	/**
	 * Summarise every Quiz in a LearnDash Quiz Import/Export JSON.
	 *
	 * @param array  $data Decoded JSON.
	 * @param string $filename Source filename.
	 * @return array[]|WP_Error
	 */
		private static function preview_quiz_export( $data, $filename ) {
		if ( ! isset( $data['master'], $data['question'] ) || ! is_array( $data['master'] ) || ! is_array( $data['question'] ) ) {
			return new WP_Error( 'invalid_learndash_quiz', sprintf( __( '%s is not a recognised LearnDash Quiz JSON export.', 'tutorhelper-lms' ), sanitize_file_name( $filename ) ) );
		}
		$quizzes = array();
		foreach ( $data['master'] as $master ) {
			if ( ! is_array( $master ) ) {
				continue;
			}
			$quiz_id = (string) absint( $master['_id'] ?? 0 );
			if ( '' === $quiz_id || '0' === $quiz_id ) {
				continue;
			}
			$post = is_array( $data['post'][ $quiz_id ] ?? null ) ? $data['post'][ $quiz_id ] : array();
			$settings = is_array( $data['post_meta'][ $quiz_id ]['_sfwd-quiz'][0] ?? null ) ? $data['post_meta'][ $quiz_id ]['_sfwd-quiz'][0] : array();
			$questions = is_array( $data['question'][ $quiz_id ] ?? null ) ? $data['question'][ $quiz_id ] : array();
			$type_counts = array();
			$unsupported = array();
			$requires_premium = false;
			$records = array();
			foreach ( $questions as $question_key => $question ) {
				if ( ! is_array( $question ) ) {
					continue;
				}
				$type = sanitize_key( $question['_answerType'] ?? '' );
				$mapping = self::map_question_type( $type );
				$label = $mapping['label'];
				$type_counts[ $label ] = absint( $type_counts[ $label ] ?? 0 ) + 1;
				if ( 'premium' === $mapping['status'] ) {
					$requires_premium = true;
				}
				if ( 'unsupported' === $mapping['status'] ) {
					$unsupported[] = $type ? $type : __( 'unknown', 'tutorhelper-lms' );
				}
				$answers = array();
				foreach ( is_array( $question['_answerData'] ?? null ) ? $question['_answerData'] : array() as $answer_index => $answer ) {
					if ( ! is_array( $answer ) ) {
						continue;
					}
					$source_answer_id = (string) ( $answer['_id'] ?? '' );
					$answers[] = array(
						'id'        => '' !== $source_answer_id ? 'learndash-answer-' . sanitize_key( $source_answer_id ) : 'learndash-answer-' . substr( sha1( $quiz_id . '|' . $question_key . '|' . $answer_index ), 0, 16 ),
						'text'      => wp_kses_post( (string) ( $answer['_answer'] ?? '' ) ),
						'html'      => ! empty( $answer['_html'] ),
						'correct'   => ! empty( $answer['_correct'] ),
						'match'     => wp_kses_post( (string) ( $answer['_sortString'] ?? '' ) ),
						'match_html'=> false !== stripos( (string) ( $answer['_sortString'] ?? '' ), '<' ),
					);
				}
				$source_question_id = absint( $question['_id'] ?? $question_key );
				$source_reference = 'learndash-question-' . $source_question_id;
				$record_prompt = wp_kses_post( (string) ( $question['_question'] ?? '' ) );
				$source_question_points = $question['_points'] ?? 0;
				$record_marks = absint( $source_question_points );
				$cloze = array();
				if ( 'cloze_answer' === $type ) {
					$source_pattern = implode( '', array_map( static function( $answer ) {
						return is_array( $answer ) ? (string) ( $answer['_answer'] ?? '' ) : '';
					}, (array) ( $question['_answerData'] ?? array() ) ) );
					$cloze = self::parse_learndash_cloze_pattern( $source_pattern, ! empty( $question['_answerPointsActivated'] ), $source_question_points );
					$record_prompt .= (string) ( $cloze['prompt'] ?? '' );
					$answers = (array) ( $cloze['answer_rows'] ?? array() );
					if ( ! empty( $cloze['mapped_marks'] ) ) {
						$record_marks = absint( $cloze['mapped_marks'] );
					}
				}
				$records[] = array(
					'id'     => $source_reference,
					'source_reference' => $source_reference,
					'source_type' => $type,
					'type'   => $mapping['target_type'],
					'label'  => $label,
					'status' => $mapping['status'],
					'import_status' => 'draft',
					'settings' => array(),
					'title'  => sanitize_text_field( $question['_title'] ?? '' ),
					'prompt' => $record_prompt,
					'marks'  => $record_marks,
					'correct_feedback' => wp_kses_post( (string) ( $question['_correctMsg'] ?? '' ) ),
					'incorrect_feedback' => wp_kses_post( (string) ( $question['_incorrectMsg'] ?? '' ) ),
					'feedback_shared' => ! empty( $question['_correctSameText'] ),
					'tip' => wp_kses_post( (string) ( $question['_tipMsg'] ?? '' ) ),
					'answers' => $answers,
					'cloze' => $cloze,
				);
			}
			$uses_random_pool = ! empty( $master['_questionRandom'] ) || ! empty( $settings['sfwd-quiz_questionRandom'] );
			$random_question_count = absint( $master['_showMaxQuestionValue'] ?? $settings['sfwd-quiz_showMaxQuestionValue'] ?? 0 );
			if ( $uses_random_pool && $random_question_count < 1 ) {
				// LearnDash can randomise the full pool without exposing a maximum count.
				$random_question_count = count( $records );
			}
			$source_time_limit = absint( $master['_timeLimit'] ?? 0 );
			if ( ! $source_time_limit ) {
				$source_time_limit = absint( $settings['sfwd-quiz_timeLimit'] ?? 0 );
			}
			$time_limit_enabled = array_key_exists( 'sfwd-quiz_quiz_time_limit_enabled', $settings ) ? 'on' === $settings['sfwd-quiz_quiz_time_limit_enabled'] : $source_time_limit > 0;
			$time_limit = $time_limit_enabled ? $source_time_limit : 0;
			$source_run_once = ! empty( $master['_quizRunOnce'] ) || ! empty( $settings['sfwd-quiz_quizRunOnce'] );
			$retry_restrictions = ! empty( $settings['sfwd-quiz_retry_restrictions'] ) && 'on' === (string) $settings['sfwd-quiz_retry_restrictions'];
			$retry_repeats = isset( $settings['sfwd-quiz_repeats'] ) ? trim( (string) $settings['sfwd-quiz_repeats'] ) : '';
			$attempt_policy = 'unlimited';
			$attempt_limit = 0;
			if ( $source_run_once ) {
				$attempt_policy = 'limited';
				$attempt_limit = 1;
			} elseif ( $retry_restrictions && '' !== $retry_repeats && is_numeric( $retry_repeats ) ) {
				// LearnDash stores permitted repeats after the first attempt: 0 means one completed attempt.
				$attempt_policy = 'limited';
				$attempt_limit = absint( $retry_repeats ) + 1;
			}
			$source_autostart = ! empty( $master['_autostart'] ) || ( isset( $settings['sfwd-quiz_autostart'] ) && 'on' === (string) $settings['sfwd-quiz_autostart'] );
			$source_result_text = is_array( $master['_resultText'] ?? null ) ? $master['_resultText'] : array();
			$result_texts = is_array( $source_result_text['text'] ?? null ) ? $source_result_text['text'] : array();
			$result_thresholds = is_array( $source_result_text['prozent'] ?? null ) ? $source_result_text['prozent'] : array();
			$result_active = is_array( $source_result_text['activ'] ?? null ) ? $source_result_text['activ'] : array();
			$result_message_rules = array();
			foreach ( $result_texts as $result_index => $result_text ) {
				if ( isset( $result_active[ $result_index ] ) && empty( $result_active[ $result_index ] ) ) {
					continue;
				}
				$result_text = wp_kses_post( (string) $result_text );
				if ( '' === trim( wp_strip_all_tags( $result_text ) ) ) {
					continue;
				}
				$result_message_rules[] = array(
					'minimum_percentage' => min( 100, absint( $result_thresholds[ $result_index ] ?? 0 ) ),
					'message' => $result_text,
				);
			}
			$source_reference = 'learndash-quiz-' . $quiz_id;
			$quizzes[] = array(
				'id' => $source_reference,
				'source_reference' => $source_reference,
				'source' => sanitize_file_name( $filename ),
				'title'  => sanitize_text_field( $post['post_title'] ?? $master['_name'] ?? __( 'Untitled Quiz', 'tutorhelper-lms' ) ),
				'instructions' => wp_kses_post( (string) ( $post['post_content'] ?? '' ) ),
				'attempt_policy' => $attempt_policy,
				'attempt_limit' => $attempt_limit,
				'show_start_screen' => ! $source_autostart,
				'result_message_rules' => $result_message_rules,
				'questions' => count( $records ),
				'type_counts' => $type_counts,
				'records' => $records,
				'unsupported_types' => array_values( array_unique( $unsupported ) ),
				'requires_premium' => $requires_premium,
				'uses_random_pool' => $uses_random_pool,
				'random_question_count' => $uses_random_pool ? $random_question_count : 0,
				'time_limit' => $time_limit,
				'passing_percentage' => absint( $settings['sfwd-quiz_passingpercentage'] ?? 0 ),
			);
		}
		return $quizzes;
	}


	/**
	 * Convert LearnDash's source-only Cloze grammar into a preview-safe Core
	 * definition without changing the uploaded export. LearnDash's own parser
	 * uses a broad regular expression; this scanner deliberately ignores HTML
	 * tags, honours escaped delimiters and reports incomplete source syntax.
	 *
	 * @param string $source_pattern LearnDash \`_answer\` value.
	 * @param bool   $answer_points_activated Whether LearnDash answer scoring is active.
	 * @param int    $question_points LearnDash Question points.
	 * @return array
	 */
	private static function parse_learndash_cloze_pattern( $source_pattern, $answer_points_activated, $question_points ) {
		$source_pattern = (string) $source_pattern;
		$result = array(
			'raw_pattern' => $source_pattern,
			'prompt' => '',
			'blanks' => array(),
			'answer_rows' => array(),
			'status' => 'blocked',
			'warnings' => array(),
			'answer_points_activated' => (bool) $answer_points_activated,
			'question_points' => $question_points,
			'mapped_marks' => 0,
		);
		if ( '' === trim( wp_strip_all_tags( $source_pattern ) ) ) {
			$result['warnings'][] = __( 'The LearnDash fill-in pattern is empty.', 'tutorhelper-lms' );
			return $result;
		}

		$output = '';
		$length = strlen( $source_pattern );
		$gap_number = 0;
		$in_tag = false;
		$quote = '';
		for ( $index = 0; $index < $length; $index++ ) {
			$character = $source_pattern[ $index ];
			if ( $in_tag ) {
				$output .= $character;
				if ( '' !== $quote && $character === $quote ) {
					$quote = '';
				} elseif ( '' === $quote && ( '"' === $character || "'" === $character ) ) {
					$quote = $character;
				} elseif ( '' === $quote && '>' === $character ) {
					$in_tag = false;
				}
				continue;
			}
			if ( '<' === $character ) {
				$in_tag = true;
				$output .= $character;
				continue;
			}
			if ( '\\' === $character && $index + 1 < $length && ( '{' === $source_pattern[ $index + 1 ] || '}' === $source_pattern[ $index + 1 ] || '[' === $source_pattern[ $index + 1 ] || ']' === $source_pattern[ $index + 1 ] || '|' === $source_pattern[ $index + 1 ] ) ) {
				$output .= $source_pattern[ ++$index ];
				continue;
			}
			if ( '}' === $character ) {
				$result['warnings'][] = sprintf( __( 'Unexpected closing brace near character %d.', 'tutorhelper-lms' ), $index + 1 );
				return $result;
			}
			if ( '{' !== $character ) {
				$output .= $character;
				continue;
			}

			$end = $index + 1;
			$body = '';
			$closed = false;
			for ( ; $end < $length; $end++ ) {
				$next = $source_pattern[ $end ];
				if ( '\\' === $next && $end + 1 < $length ) {
					$body .= $source_pattern[ ++$end ];
					continue;
				}
				if ( '{' === $next ) {
					$result['warnings'][] = sprintf( __( 'Nested opening brace in gap %d.', 'tutorhelper-lms' ), $gap_number + 1 );
					return $result;
				}
				if ( '}' === $next ) {
					$closed = true;
					break;
				}
				$body .= $next;
			}
			if ( ! $closed ) {
				$result['warnings'][] = sprintf( __( 'Unclosed opening brace in gap %d.', 'tutorhelper-lms' ), $gap_number + 1 );
				return $result;
			}
			$gap = self::parse_learndash_cloze_gap( $body, $gap_number + 1, $answer_points_activated );
			if ( is_wp_error( $gap ) ) {
				$result['warnings'][] = $gap->get_error_message();
				return $result;
			}
			$gap_number++;
			$gap['id'] = 'blank-' . $gap_number;
			$result['blanks'][] = $gap;
			$result['answer_rows'][] = array(
				'id' => $gap['id'],
				'text' => (string) $gap['accepted'][0],
				'accepted' => $gap['accepted'],
				'marks' => $gap['marks'],
				'source_points' => $gap['source_points'],
				'correct' => true,
				'html' => false,
				'match' => '',
				'match_html' => false,
			);
			$output .= '{{' . $gap_number . '}}';
			$index = $end;
		}

		if ( 0 === $gap_number ) {
			$result['warnings'][] = __( 'No LearnDash fill-in gaps were found in the source pattern.', 'tutorhelper-lms' );
			return $result;
		}
		$result['prompt'] = wp_kses_post( $output );
		$marks = array_sum( array_map( static function( $blank ) { return absint( $blank['marks'] ?? 0 ); }, $result['blanks'] ) );
		$result['mapped_marks'] = $marks;
		$result['status'] = 'ready';

		if ( ! $answer_points_activated && '' !== (string) $question_points && ( ! is_numeric( $question_points ) || ! is_finite( (float) $question_points ) || (float) $question_points < 0 || (float) $question_points !== (float) absint( $question_points ) ) ) {
			$result['status'] = 'warning';
			$result['warnings'][] = __( 'This LearnDash Question has a non-whole or unsupported Question points value. Choose whole TutorHelper gap marks before creating it.', 'tutorhelper-lms' );
		} elseif ( ! $answer_points_activated && absint( $question_points ) > 0 && absint( $question_points ) !== $marks ) {
			$result['status'] = 'warning';
			$result['warnings'][] = sprintf( __( 'LearnDash awards %1$d mark(s) for this Question, while the default one-mark-per-gap conversion totals %2$d. Review the gap marks before creating it.', 'tutorhelper-lms' ), absint( $question_points ), $marks );
		}
		foreach ( $result['blanks'] as $blank ) {
			$points = array_values( array_unique( array_map( 'strval', (array) ( $blank['source_points'] ?? array() ) ) ) );
			if ( ! empty( $blank['invalid_points'] ) ) {
				$result['status'] = 'warning';
				$result['warnings'][] = sprintf( __( 'Gap %d has a non-whole or unsupported LearnDash points value. Choose a whole TutorHelper gap mark before creating it.', 'tutorhelper-lms' ), absint( $blank['number'] ?? 0 ) );
			}
			if ( $answer_points_activated && count( $points ) > 1 ) {
				$result['status'] = 'warning';
				$result['warnings'][] = sprintf( __( 'Gap %d has different LearnDash points for accepted alternatives. Choose one TutorHelper gap mark before creating it.', 'tutorhelper-lms' ), absint( $blank['number'] ?? 0 ) );
			}
		}
		return $result;
	}

	/**
	 * Parse one LearnDash \`{...}\` gap. Bracketed alternatives remain one gap.
	 *
	 * @param string $body Gap source without braces.
	 * @param int    $number Gap number.
	 * @param bool   $answer_points_activated Whether \`|points\` is active.
	 * @return array|WP_Error
	 */
	private static function parse_learndash_cloze_gap( $body, $number, $answer_points_activated ) {
		$body = (string) $body;
		$values = array();
		$shared_point = null;
		if ( '' === trim( $body ) ) {
			return new WP_Error( 'empty_cloze_gap', sprintf( __( 'Gap %d has no accepted answer.', 'tutorhelper-lms' ), $number ) );
		}
		if ( '[' === $body[0] ) {
			$offset = 0;
			$length = strlen( $body );
			while ( $offset < $length && '[' === $body[ $offset ] ) {
				$close = strpos( $body, ']', $offset + 1 );
				if ( false === $close ) {
					return new WP_Error( 'unclosed_cloze_alternative', sprintf( __( 'Gap %d has an unclosed alternative.', 'tutorhelper-lms' ), $number ) );
				}
				$values[] = substr( $body, $offset + 1, $close - $offset - 1 );
				$offset = $close + 1;
			}
			$remainder = substr( $body, $offset );
			if ( '' !== $remainder ) {
				if ( '|' !== $remainder[0] ) {
					return new WP_Error( 'malformed_cloze_alternatives', sprintf( __( 'Gap %d has malformed bracketed alternatives.', 'tutorhelper-lms' ), $number ) );
				}
				// LearnDash also exports one shared points value after a list such as
				// {[fungi|yeast|fungal]|1}. Every pipe inside the brackets is an accepted alternative.
				$shared_point = trim( substr( $remainder, 1 ) );
			}
		} else {
			if ( false !== strpos( $body, '[' ) || false !== strpos( $body, ']' ) ) {
				return new WP_Error( 'malformed_cloze_brackets', sprintf( __( 'Gap %d mixes bracketed and unbracketed answer syntax.', 'tutorhelper-lms' ), $number ) );
			}
			$values[] = $body;
		}

		$accepted = array();
		$source_points = array();
		$invalid_points = false;
		if ( null !== $shared_point ) {
			foreach ( $values as $value ) {
				foreach ( explode( '|', $value ) as $alternative ) {
					$answer = trim( html_entity_decode( (string) $alternative, ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' ) );
					if ( '' === $answer ) {
						return new WP_Error( 'empty_cloze_answer', sprintf( __( 'Gap %d contains an empty accepted answer.', 'tutorhelper-lms' ), $number ) );
					}
					$accepted[] = $answer;
				}
			}
			if ( ! is_numeric( $shared_point ) || ! is_finite( (float) $shared_point ) || (float) $shared_point < 0 || (float) $shared_point !== (float) absint( $shared_point ) ) {
				$invalid_points = true;
				$source_points[] = $shared_point;
			} else {
				$source_points[] = absint( $shared_point );
			}
		} else {
			foreach ( $values as $value ) {
				$parts = explode( '|', $value );
				$alternative_list = count( $parts ) > 2 || ( 2 === count( $parts ) && ! is_numeric( trim( $parts[1] ) ) && '[' === $body[0] );
				if ( $alternative_list ) {
					foreach ( $parts as $alternative ) {
						$answer = trim( html_entity_decode( (string) $alternative, ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' ) );
						if ( '' === $answer ) {
							return new WP_Error( 'empty_cloze_answer', sprintf( __( 'Gap %d contains an empty accepted answer.', 'tutorhelper-lms' ), $number ) );
						}
						$accepted[] = $answer;
					}
					$source_points[] = 1;
					continue;
				}
				$answer = trim( html_entity_decode( (string) $parts[0], ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' ) );
				if ( '' === $answer ) {
					return new WP_Error( 'empty_cloze_answer', sprintf( __( 'Gap %d contains an empty accepted answer.', 'tutorhelper-lms' ), $number ) );
				}
				$accepted[] = $answer;
				$point = 1;
				if ( isset( $parts[1] ) ) {
					$point = trim( $parts[1] );
					if ( ! is_numeric( $point ) || ! is_finite( (float) $point ) || (float) $point < 0 || (float) $point !== (float) absint( $point ) ) {
						$invalid_points = true;
						$source_points[] = $point;
						continue;
					}
					$point = absint( $point );
				}
				$source_points[] = $point;
			}
		}
		$accepted = array_values( array_unique( $accepted ) );
		$marks = $invalid_points ? 0 : ( $answer_points_activated ? max( $source_points ) : 1 );
		return array(
			'number' => $number,
			'accepted' => $accepted,
			'marks' => $marks,
			'source_points' => $source_points,
			'invalid_points' => $invalid_points,
		);
	}

	/**
	 * Map a LearnDash Question type to its TutorHelper import category.
	 *
	 * @param string $type LearnDash answer type.
	 * @return array
	 */
		private static function map_question_type( $type ) {
		$map = array(
			'single' => array( 'label' => __( 'Single choice', 'tutorhelper-lms' ), 'status' => 'supported', 'target_type' => 'single_choice' ),
			'multiple' => array( 'label' => __( 'Multiple choice', 'tutorhelper-lms' ), 'status' => 'supported', 'target_type' => 'multiple_choice' ),
			'free_answer' => array( 'label' => __( 'Short answer', 'tutorhelper-lms' ), 'status' => 'supported', 'target_type' => 'free_answer' ),
			'sort_answer' => array( 'label' => __( 'Sorting', 'tutorhelper-lms' ), 'status' => 'supported', 'target_type' => 'sort_answer' ),
			'matrix_sort_answer' => array( 'label' => __( 'Matching', 'tutorhelper-lms' ), 'status' => 'supported', 'target_type' => 'matrix_sort' ),
			'cloze_answer' => array( 'label' => __( 'Fill in the blanks', 'tutorhelper-lms' ), 'status' => 'supported', 'target_type' => 'cloze' ),
			'essay' => array( 'label' => __( 'Written response', 'tutorhelper-lms' ), 'status' => 'premium', 'target_type' => 'essay' ),
		);
		return $map[ $type ] ?? array( 'label' => __( 'Unsupported', 'tutorhelper-lms' ), 'status' => 'unsupported', 'target_type' => '' );
	}

	/**
	 * Produce a concise title list from a LearnDash content export.
	 *
	 * @param mixed $items Source records.
	 * @return array
	 */
	private static function title_list( $items ) {
		$titles = array();
		foreach ( is_array( $items ) ? $items : array() as $item ) {
			if ( is_array( $item ) ) {
				$titles[] = sanitize_text_field( $item['title'] ?? __( 'Untitled item', 'tutorhelper-lms' ) );
			}
		}
		return $titles;
	}

	/**
	 * Render a stored summary.
	 *
	 * @param array $preview Preview summary.
	 * @return void
	 */
	private static function render_preview( $preview ) {
		$media_decisions = is_array( $preview['media_decisions'] ?? null ) ? $preview['media_decisions'] : array();
		?>
		<section class="tutorhelper-lms-import__preview" aria-live="polite">
			<h3><?php esc_html_e( 'Import preview', 'tutorhelper-lms' ); ?></h3>
			<?php self::render_save_run_action( $preview ); ?>
			<?php if ( ! empty( $preview['csv_questions']['execution'] ) ) : ?>
				<p><?php esc_html_e( 'This preview now includes the CSV Question creation results below. Course and Quiz imports remain review-only.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<p><?php esc_html_e( 'Nothing has been imported yet. This is a read-only check of the files you selected.', 'tutorhelper-lms' ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $preview['errors'] ) ) : ?>
				<div class="notice notice-error inline"><p><strong><?php esc_html_e( 'Files that need attention', 'tutorhelper-lms' ); ?></strong></p><ul><?php foreach ( $preview['errors'] as $error ) : ?><li><?php echo esc_html( $error ); ?></li><?php endforeach; ?></ul></div>
			<?php endif; ?>
			<?php if ( ! empty( $preview['warnings'] ) ) : ?>
				<div class="notice notice-warning inline"><p><strong><?php esc_html_e( 'Review before import', 'tutorhelper-lms' ); ?></strong></p><ul><?php foreach ( array_unique( $preview['warnings'] ) as $warning ) : ?><li><?php echo esc_html( $warning ); ?></li><?php endforeach; ?></ul></div>
			<?php endif; ?>

			<?php if ( ! empty( $preview['course'] ) ) : ?>
				<div class="tutorhelper-lms-import__preview-card">
					<h4><?php esc_html_e( 'Course structure', 'tutorhelper-lms' ); ?></h4>
					<p><?php echo esc_html( sprintf( _n( '%d Course', '%d Courses', count( $preview['course']['courses'] ), 'tutorhelper-lms' ), count( $preview['course']['courses'] ) ) ); ?> · <?php echo esc_html( sprintf( _n( '%d Lesson', '%d Lessons', count( $preview['course']['lessons'] ), 'tutorhelper-lms' ), count( $preview['course']['lessons'] ) ) ); ?> · <?php echo esc_html( sprintf( _n( '%d Topic', '%d Topics', count( $preview['course']['topics'] ), 'tutorhelper-lms' ), count( $preview['course']['topics'] ) ) ); ?></p>
					<?php if ( ! empty( $preview['course']['courses'] ) ) : ?><ul><?php foreach ( $preview['course']['courses'] as $course ) : ?><li><?php echo esc_html( $course['title'] ); ?><?php echo ! empty( $course['has_content'] ) ? esc_html__( ' — description found', 'tutorhelper-lms' ) : ''; ?></li><?php endforeach; ?></ul><?php endif; ?>
					<?php if ( ! empty( $preview['course']['lessons'] ) ) : ?><p><strong><?php esc_html_e( 'Lessons:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( implode( ', ', wp_list_pluck( $preview['course']['lessons'], 'title' ) ) ); ?></p><?php endif; ?>
					<?php if ( ! empty( $preview['course']['has_sections'] ) ) : ?><p class="description"><?php esc_html_e( 'LearnDash section headings were found and will be shown for placement review in the import stage.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
				</div>
				<?php self::render_course_audit( $preview ); ?>
				<?php self::render_lesson_audit( $preview ); ?>
			<?php endif; ?>

			<?php foreach ( $preview['quizzes'] as $quiz ) : ?>
				<div class="tutorhelper-lms-import__preview-card">
					<h4><?php echo esc_html( $quiz['title'] ); ?></h4>
					<p class="description"><?php echo esc_html( sprintf( __( 'Source: %s', 'tutorhelper-lms' ), $quiz['source'] ) ); ?></p>
					<p><strong><?php echo esc_html( sprintf( _n( '%d Question', '%d Questions', $quiz['questions'], 'tutorhelper-lms' ), $quiz['questions'] ) ); ?></strong><?php if ( $quiz['passing_percentage'] ) : ?> · <?php echo esc_html( sprintf( __( 'LearnDash pass mark: %d%%', 'tutorhelper-lms' ), $quiz['passing_percentage'] ) ); ?><?php endif; ?><?php if ( $quiz['time_limit'] ) : ?> · <?php echo esc_html( sprintf( __( 'Time limit: %d seconds', 'tutorhelper-lms' ), $quiz['time_limit'] ) ); ?><?php endif; ?></p>
					<?php if ( ! empty( $quiz['type_counts'] ) ) : ?><ul class="tutorhelper-lms-import__type-counts"><?php foreach ( $quiz['type_counts'] as $type => $count ) : ?><li><?php echo esc_html( sprintf( _n( '%1$d %2$s Question', '%1$d %2$s Questions', $count, 'tutorhelper-lms' ), $count, $type ) ); ?></li><?php endforeach; ?></ul><?php endif; ?>
				</div>
				<?php self::render_quiz_audit( $quiz, $media_decisions ); ?>
				<?php self::render_quiz_media_inventory( $quiz, $media_decisions ); ?>
			<?php endforeach; ?>
			<?php self::render_learndash_execution( $preview ); ?>
			<?php self::render_learndash_quiz_execution( $preview ); ?>
			<?php if ( ! empty( $preview['csv_questions'] ) ) : ?><?php $csv = $preview['csv_questions']; ?>
				<div class="tutorhelper-lms-import__preview-card">
					<h4><?php esc_html_e( 'TutorHelper Question CSV', 'tutorhelper-lms' ); ?></h4>
					<p class="description"><?php echo esc_html( sprintf( __( 'Source: %s', 'tutorhelper-lms' ), $csv['source'] ) ); ?></p>
					<p><strong><?php echo esc_html( sprintf( _n( '%d Question', '%d Questions', $csv['questions'], 'tutorhelper-lms' ), $csv['questions'] ) ); ?></strong></p>
					<?php if ( ! empty( $csv['type_counts'] ) ) : ?><ul class="tutorhelper-lms-import__type-counts"><?php foreach ( $csv['type_counts'] as $type => $count ) : ?><li><?php echo esc_html( sprintf( _n( '%1$d %2$s Question', '%1$d %2$s Questions', $count, 'tutorhelper-lms' ), $count, $type ) ); ?></li><?php endforeach; ?></ul><?php endif; ?>
				</div>
				<?php self::render_quiz_audit( $csv, $media_decisions ); ?>
				<?php self::render_quiz_media_inventory( $csv, $media_decisions ); ?>
				<?php self::render_csv_execution( $csv, $media_decisions ); ?>
			<?php endif; ?>
			<?php self::render_audit_dialog(); ?>
			<?php if ( ! empty( $preview['course'] ) ) : ?>
				<?php self::render_mapping_worksheet( $preview ); ?>
			<?php endif; ?>
			<p class="tutorhelper-lms-import__next-step"><strong><?php esc_html_e( 'Next step:', 'tutorhelper-lms' ); ?></strong> <?php esc_html_e( 'Approve the mapping and create the reviewed Course, Lessons, Questions and Quizzes in the next import stage.', 'tutorhelper-lms' ); ?></p>
		</section>
		<?php
	}

	/**
	 * Definitions and checks for the fields needed by each TutorHelper Question type.
	 *
	 * @param string $type LearnDash Question type.
	 * @return array
	 */
	private static function question_audit_definition( $type ) {
		$common = array(
			'title'  => __( 'Question title', 'tutorhelper-lms' ),
			'prompt' => __( 'Question prompt', 'tutorhelper-lms' ),
			'marks'  => __( 'Maximum marks', 'tutorhelper-lms' ),
		);
		$definitions = array(
			'single'             => array_merge( $common, array( 'options' => __( 'At least two answer options', 'tutorhelper-lms' ), 'correct' => __( 'One correct answer', 'tutorhelper-lms' ) ) ),
			'single_choice'      => array_merge( $common, array( 'options' => __( 'At least two answer options', 'tutorhelper-lms' ), 'correct' => __( 'One correct answer', 'tutorhelper-lms' ) ) ),
			'multiple'           => array_merge( $common, array( 'options' => __( 'At least two answer options', 'tutorhelper-lms' ), 'correct' => __( 'At least one correct answer', 'tutorhelper-lms' ) ) ),
			'multiple_choice'    => array_merge( $common, array( 'options' => __( 'At least two answer options', 'tutorhelper-lms' ), 'correct' => __( 'At least one correct answer', 'tutorhelper-lms' ) ) ),
			'free_answer'        => array_merge( $common, array( 'options' => __( 'Accepted answer', 'tutorhelper-lms' ) ) ),
			'sort_answer'        => array_merge( $common, array( 'options' => __( 'At least two items in order', 'tutorhelper-lms' ) ) ),
			'matrix_sort_answer' => array_merge( $common, array( 'pairs' => __( 'At least two matching pairs', 'tutorhelper-lms' ) ) ),
			'matrix_sort'        => array_merge( $common, array( 'pairs' => __( 'At least two matching pairs', 'tutorhelper-lms' ) ) ),
			'cloze_answer'       => array_merge( $common, array( 'pattern' => __( 'Fill-in pattern with answers in {braces}', 'tutorhelper-lms' ) ) ),
			'cloze'              => array_merge( $common, array( 'pattern' => __( 'Fill-in placeholders {{1}}, {{2}} and matching blank answers', 'tutorhelper-lms' ) ) ),
			'essay'              => $common,
			'assessment'         => array( 'title' => __( 'Question title', 'tutorhelper-lms' ), 'prompt' => __( 'Question prompt', 'tutorhelper-lms' ) ),
		);
		return $definitions[ $type ] ?? array(
			'title'  => __( 'Question title', 'tutorhelper-lms' ),
			'prompt' => __( 'Question prompt', 'tutorhelper-lms' ),
		);
	}

	/**
	 * Optional LearnDash fields that TutorHelper can retain without blocking import.
	 *
	 * @param string $type LearnDash Question type.
	 * @return array
	 */
	private static function question_audit_optional_definition( $type ) {
		$optional = array(
			'tip' => __( 'Student hint (optional)', 'tutorhelper-lms' ),
		);
		if ( in_array( $type, array( 'single', 'multiple', 'single_choice', 'multiple_choice' ), true ) ) {
			$optional = array_merge(
				array(
					'correct_feedback'   => __( 'Correct feedback (optional)', 'tutorhelper-lms' ),
					'incorrect_feedback' => __( 'Incorrect feedback (optional)', 'tutorhelper-lms' ),
				),
				$optional
			);
		}
		return $optional;
	}

	/**
	 * Evaluate an editable Question record against its type definition.
	 *
	 * @param array $record Stored temporary Question record.
	 * @return array
	 */
	private static function question_audit_status( $record ) {
		$answers = is_array( $record['answers'] ?? null ) ? $record['answers'] : array();
		$has_content = static function( $value ) {
			$value = (string) $value;
			return '' !== trim( wp_strip_all_tags( $value ) ) || false !== stripos( $value, '<img' );
		};
		$usable_answers = array_filter( $answers, static function( $answer ) use ( $has_content ) {
			return $has_content( $answer['text'] ?? '' );
		} );
		$correct = array_filter( $answers, static function( $answer ) {
			return ! empty( $answer['correct'] );
		} );
		$pairs = array_filter( $answers, static function( $answer ) use ( $has_content ) {
			return $has_content( $answer['text'] ?? '' ) && $has_content( $answer['match'] ?? '' );
		} );
		$patterns = array_filter( $answers, static function( $answer ) {
			return 1 === preg_match( '/\\{[^{}]+\\}/', wp_strip_all_tags( (string) ( $answer['text'] ?? '' ) ) );
		} );
		$type = sanitize_key( $record['type'] ?? '' );
		$status = array(
			'title'  => '' !== trim( (string) ( $record['title'] ?? '' ) ),
			'prompt' => $has_content( $record['prompt'] ?? '' ),
			'marks'  => absint( $record['marks'] ?? 0 ) > 0,
			'correct_feedback' => $has_content( $record['correct_feedback'] ?? '' ),
			'incorrect_feedback' => $has_content( $record['incorrect_feedback'] ?? '' ) || ( ! empty( $record['feedback_shared'] ) && $has_content( $record['correct_feedback'] ?? '' ) ),
			'tip' => $has_content( $record['tip'] ?? '' ),
		);
		if ( in_array( $type, array( 'single', 'single_choice' ), true ) ) {
			$status['options'] = count( $usable_answers ) >= 2;
			$status['correct'] = 1 === count( $correct );
		} elseif ( in_array( $type, array( 'multiple', 'multiple_choice' ), true ) ) {
			$status['options'] = count( $usable_answers ) >= 2;
			$status['correct'] = count( $correct ) >= 1;
		} elseif ( 'free_answer' === $type || 'sort_answer' === $type ) {
			$status['options'] = 'sort_answer' === $type ? count( $usable_answers ) >= 2 : count( $usable_answers ) >= 1;
		} elseif ( in_array( $type, array( 'matrix_sort_answer', 'matrix_sort' ), true ) ) {
			$status['pairs'] = count( $pairs ) >= 2;
		} elseif ( 'cloze_answer' === $type ) {
			$status['pattern'] = count( $patterns ) >= 1;
		} elseif ( 'cloze' === $type ) {
			$cloze = is_array( $record['cloze'] ?? null ) ? $record['cloze'] : array();
			$placeholder_count = preg_match_all( '/\{\{[1-9][0-9]*\}\}/', wp_strip_all_tags( (string) ( $record['prompt'] ?? '' ) ), $matches );
			$status['pattern'] = ( empty( $cloze ) || 'ready' === ( $cloze['status'] ?? '' ) ) && $placeholder_count >= 1 && $placeholder_count === count( $usable_answers );
		} elseif ( ! in_array( $type, array( 'essay', 'assessment' ), true ) ) {
			$status['type'] = 'unsupported' !== ( $record['status'] ?? '' );
		}
		return $status;
	}

	/**
	 * Render Course audit results.
	 *
	 * @param array $preview Temporary preview.
	 * @return void
	 */
	private static function render_course_audit( $preview ) {
		$mapping = is_array( $preview['mappings'] ?? null ) ? $preview['mappings'] : array();
		$fields = array(
			'title'   => __( 'Course title', 'tutorhelper-lms' ),
			'subject' => __( 'Subject mapping', 'tutorhelper-lms' ),
			'grade'   => __( 'Grade system mapping', 'tutorhelper-lms' ),
		);
		?>
		<section class="tutorhelper-lms-import__audit">
			<h4><?php esc_html_e( 'Course import audit', 'tutorhelper-lms' ); ?></h4>
			<p class="description"><?php esc_html_e( 'Required before a Course can be created:', 'tutorhelper-lms' ); ?> <?php echo esc_html( implode( ' · ', $fields ) ); ?></p>
			<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Course', 'tutorhelper-lms' ); ?></th><?php foreach ( $fields as $label ) : ?><th><?php echo esc_html( $label ); ?></th><?php endforeach; ?></tr></thead>
				<tbody><?php foreach ( (array) ( $preview['course']['courses'] ?? array() ) as $index => $course ) : ?><?php $record = array( 'kind' => 'course', 'id' => absint( $index ), 'title' => (string) ( $course['title'] ?? '' ), 'mapping' => $mapping ); $status = array( 'title' => '' !== trim( $record['title'] ), 'subject' => absint( $mapping['course_subject_id'] ?? 0 ) > 0, 'grade' => absint( $mapping['course_grade_system_id'] ?? 0 ) > 0 ); ?><tr><th scope="row"><?php echo esc_html( $record['title'] ?: __( 'Untitled Course', 'tutorhelper-lms' ) ); ?></th><?php foreach ( $fields as $field => $label ) : ?><td><?php self::render_audit_indicator( $status[ $field ], $record, $field, $label ); ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody>
			</table></div>
		</section>
		<?php
	}

	/**
	 * Render Lesson audit results.
	 *
	 * @param array $preview Temporary preview.
	 * @return void
	 */
	private static function render_lesson_audit( $preview ) {
		$mapping = is_array( $preview['mappings'] ?? null ) ? $preview['mappings'] : array();
		$fields = array( 'title' => __( 'Lesson title', 'tutorhelper-lms' ), 'topic' => __( 'Topic plan', 'tutorhelper-lms' ) );
		?>
		<section class="tutorhelper-lms-import__audit">
			<h4><?php esc_html_e( 'Lesson import audit', 'tutorhelper-lms' ); ?></h4>
			<p class="description"><?php esc_html_e( 'Required before a Lesson can be created:', 'tutorhelper-lms' ); ?> <?php echo esc_html( implode( ' · ', $fields ) ); ?></p>
			<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Lesson', 'tutorhelper-lms' ); ?></th><?php foreach ( $fields as $label ) : ?><th><?php echo esc_html( $label ); ?></th><?php endforeach; ?></tr></thead>
				<tbody><?php foreach ( (array) ( $preview['course']['lessons'] ?? array() ) as $index => $lesson ) : ?><?php $lesson_title = is_array( $lesson ) ? (string) ( $lesson['title'] ?? '' ) : (string) $lesson; $lesson_mapping = is_array( $mapping['lessons'][ $index ] ?? null ) ? $mapping['lessons'][ $index ] : array(); $mode = $lesson_mapping['mode'] ?? ''; $topic_ready = ( 'course_topic' === $mode && absint( $lesson_mapping['topic_id'] ?? 0 ) > 0 ) || ( 'source_topic' === $mode && '' !== trim( (string) ( $lesson_mapping['source_topic'] ?? '' ) ) ) || ( 'new_topic' === $mode && '' !== trim( (string) ( $lesson_mapping['new_topic_name'] ?? '' ) ) ); $record = array( 'kind' => 'lesson', 'id' => absint( $index ), 'title' => $lesson_title, 'mapping' => $lesson_mapping ); ?><tr><th scope="row"><?php echo esc_html( $lesson_title ?: __( 'Untitled Lesson', 'tutorhelper-lms' ) ); ?></th><td><?php self::render_audit_indicator( '' !== trim( $lesson_title ), $record, 'title', $fields['title'] ); ?></td><td><?php self::render_audit_indicator( $topic_ready, $record, 'topic', $fields['topic'] ); ?></td></tr><?php endforeach; ?></tbody>
			</table></div>
		</section>
		<?php
	}

	/**
	 * Build a read-only image inventory for one Question record.
	 *
	 * The original image URL is retained as source evidence. A relative uploads
	 * path is derived only for a safe lookup against the current site's Media
	 * Library; this preview never requests, downloads or creates media.
	 *
	 * @param array $record Preview Question record.
	 * @return array
	 */
	private static function record_image_inventory( $record, $media_decisions = array() ) {
		$assets = array();
		$fields = array(
			'prompt'             => __( 'Question prompt', 'tutorhelper-lms' ),
			'correct_feedback'   => __( 'Correct feedback', 'tutorhelper-lms' ),
			'incorrect_feedback' => __( 'Incorrect feedback', 'tutorhelper-lms' ),
			'tip'                => __( 'Student hint', 'tutorhelper-lms' ),
		);
		foreach ( $fields as $field => $label ) {
			self::collect_import_images( $assets, (string) ( $record[ $field ] ?? '' ), $label );
		}
		foreach ( (array) ( $record['answers'] ?? array() ) as $index => $answer ) {
			$number = absint( $index ) + 1;
			self::collect_import_images( $assets, (string) ( $answer['text'] ?? '' ), sprintf( __( 'Answer %d', 'tutorhelper-lms' ), $number ) );
			if ( '' !== trim( (string) ( $answer['match'] ?? '' ) ) ) {
				self::collect_import_images( $assets, (string) $answer['match'], sprintf( __( 'Matching pair %d — right side', 'tutorhelper-lms' ), $number ) );
			}
		}
		foreach ( $assets as &$asset ) {
			$asset = self::resolve_import_image( $asset, $media_decisions );
		}
		unset( $asset );
		return array_values( $assets );
	}

	/**
	 * Collect image tags from one rich source field.
	 *
	 * @param array  $assets Image inventory keyed by source URL.
	 * @param string $html Rich source HTML.
	 * @param string $location Human-readable source location.
	 * @return void
	 */
	private static function collect_import_images( &$assets, $html, $location ) {
		foreach ( self::extract_import_images( $html ) as $image ) {
			$key = sha1( $image['source_url'] );
			if ( ! isset( $assets[ $key ] ) ) {
				$assets[ $key ] = array(
					'id'          => 'import-image-' . substr( $key, 0, 16 ),
					'source_url'  => $image['source_url'],
					'alts'        => array(),
					'dimensions'  => array(),
					'locations'   => array(),
					'occurrences' => 0,
				);
			}
			$assets[ $key ]['occurrences']++;
			if ( '' !== $image['alt'] ) {
				$assets[ $key ]['alts'][] = $image['alt'];
				$assets[ $key ]['alts'] = array_values( array_unique( $assets[ $key ]['alts'] ) );
			}
			if ( '' !== $image['dimensions'] ) {
				$assets[ $key ]['dimensions'][] = $image['dimensions'];
				$assets[ $key ]['dimensions'] = array_values( array_unique( $assets[ $key ]['dimensions'] ) );
			}
			$assets[ $key ]['locations'][] = $location;
			$assets[ $key ]['locations'] = array_values( array_unique( $assets[ $key ]['locations'] ) );
		}
	}

	/**
	 * Extract safe metadata from image tags without fetching their source URLs.
	 *
	 * @param string $html Rich source HTML.
	 * @return array[]
	 */
	private static function extract_import_images( $html ) {
		$images = array();
		if ( '' === trim( $html ) || ! preg_match_all( '/<img\b[^>]*>/i', $html, $tags ) ) {
			return $images;
		}
		foreach ( $tags[0] as $tag ) {
			$source_url = trim( html_entity_decode( self::import_image_tag_attribute( $tag, 'src' ), ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' ) );
			if ( '' === $source_url ) {
				continue;
			}
			$width = sanitize_text_field( self::import_image_tag_attribute( $tag, 'width' ) );
			$height = sanitize_text_field( self::import_image_tag_attribute( $tag, 'height' ) );
			$images[] = array(
				'source_url' => $source_url,
				'alt'        => sanitize_text_field( html_entity_decode( self::import_image_tag_attribute( $tag, 'alt' ), ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' ) ),
				'dimensions' => $width || $height ? trim( $width . ( $height ? ' × ' . $height : '' ) ) : '',
			);
		}
		return $images;
	}

	/**
	 * Read one HTML attribute from a previously sanitised image tag.
	 *
	 * @param string $tag Image tag.
	 * @param string $attribute Attribute name.
	 * @return string
	 */
	private static function import_image_tag_attribute( $tag, $attribute ) {
		$pattern = '/\b' . preg_quote( $attribute, '/' ) . '\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i';
		if ( ! preg_match( $pattern, $tag, $matches ) ) {
			return '';
		}
		return (string) ( $matches[1] ?? $matches[2] ?? $matches[3] ?? '' );
	}

	/**
	 * Resolve a source image against the current Media Library by its stable
	 * uploads-relative path. A remote URL is never requested by this lookup.
	 *
	 * @param array $asset Source image inventory item.
	 * @return array
	 */
	private static function resolve_import_image( $asset, $media_decisions = array() ) {
		$source_url = (string) ( $asset['source_url'] ?? '' );
		$parsed = wp_parse_url( $source_url );
		$scheme = strtolower( (string) ( $parsed['scheme'] ?? '' ) );
		$host = strtolower( (string) ( $parsed['host'] ?? '' ) );
		$path = (string) ( $parsed['path'] ?? '' );
		$uploads = wp_get_upload_dir();
		$upload_path = (string) wp_parse_url( (string) ( $uploads['baseurl'] ?? '' ), PHP_URL_PATH );
		$current_hosts = array_filter( array_unique( array(
			strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ),
			strtolower( (string) wp_parse_url( site_url(), PHP_URL_HOST ) ),
		) ) );
		$relative_path = self::import_upload_relative_path( $path, $upload_path );
		$is_current_site = '' === $host || in_array( $host, $current_hosts, true );
		$decision = is_array( $media_decisions[ $asset['id'] ] ?? null ) ? $media_decisions[ $asset['id'] ] : array();
		$selected_attachment_id = absint( $decision['local_attachment_id'] ?? 0 );
		$attachment_id = $relative_path ? self::find_import_media_attachment( $relative_path ) : 0;
		if ( $selected_attachment_id && 'attachment' === get_post_type( $selected_attachment_id ) && wp_attachment_is_image( $selected_attachment_id ) ) {
			$attachment_id = $selected_attachment_id;
		}

		$asset['relative_path'] = $relative_path;
		$asset['attachment_id'] = $attachment_id;
		$asset['selected_local_attachment'] = $selected_attachment_id && $attachment_id === $selected_attachment_id;
		$asset['thumbnail_url'] = $attachment_id ? (string) wp_get_attachment_image_url( $attachment_id, 'thumbnail' ) : '';
		$asset['attachment_url'] = $attachment_id ? (string) wp_get_attachment_url( $attachment_id ) : '';
		$asset['source_label'] = self::import_image_source_label( $source_url, $relative_path );
		$asset['can_check_external'] = ! $attachment_id && ! $is_current_site && in_array( $scheme, array( 'http', 'https' ), true );
		$asset['external_decision'] = $decision;
		$asset['using_external'] = ! empty( $asset['external_decision']['use_external'] ) && 'valid' === sanitize_key( $asset['external_decision']['validation']['state'] ?? '' );
		if ( ! empty( $asset['selected_local_attachment'] ) && ! empty( $asset['attachment_url'] ) ) {
			$selected_path = (string) wp_parse_url( (string) $asset['attachment_url'], PHP_URL_PATH );
			$selected_relative_path = self::import_upload_relative_path( $selected_path, $upload_path );
			$asset['display_source_url'] = (string) $asset['attachment_url'];
			$asset['display_source_label'] = self::import_image_source_label( $asset['display_source_url'], $selected_relative_path );
		} else {
			$asset['display_source_url'] = $asset['using_external'] ? $source_url : (string) ( $asset['attachment_url'] ?: $source_url );
			$asset['display_source_label'] = $asset['using_external'] ? $source_url : $asset['source_label'];
		}
		$asset['thumbnail_is_external'] = false;
		if ( $asset['using_external'] ) {
			// The browser loads this only after the tutor explicitly chooses the link.
			$asset['thumbnail_url'] = $source_url;
			$asset['thumbnail_is_external'] = true;
		}
		if ( $attachment_id ) {
			$asset['status'] = 'available';
			$asset['status_label'] = ! empty( $asset['selected_local_attachment'] ) ? __( 'Media Library replacement selected', 'tutorhelper-lms' ) : __( 'Available in current Media Library', 'tutorhelper-lms' );
		} elseif ( $relative_path && $is_current_site ) {
			$asset['status'] = 'current_missing';
			$asset['status_label'] = __( 'Current-site upload not found', 'tutorhelper-lms' );
		} elseif ( $relative_path ) {
			$asset['status'] = 'source_upload_missing';
			$asset['status_label'] = __( 'Source WordPress upload not found locally', 'tutorhelper-lms' );
		} elseif ( in_array( $scheme, array( 'http', 'https' ), true ) ) {
			$asset['status'] = 'external';
			$asset['status_label'] = __( 'External image needs confirmation', 'tutorhelper-lms' );
		} else {
			$asset['status'] = 'invalid';
			$asset['status_label'] = __( 'Image source needs review', 'tutorhelper-lms' );
		}
		return $asset;
	}

	/**
	 * Return an uploads-relative path from a WordPress source URL, if present.
	 *
	 * @param string $path URL path.
	 * @param string $current_upload_path Current uploads base URL path.
	 * @return string
	 */
	private static function import_upload_relative_path( $path, $current_upload_path ) {
		$path = rawurldecode( '/' . ltrim( (string) $path, '/' ) );
		$current_upload_path = '/' . trim( rawurldecode( (string) $current_upload_path ), '/' );
		if ( '/' !== $current_upload_path && 0 === strpos( $path, trailingslashit( $current_upload_path ) ) ) {
			return ltrim( substr( $path, strlen( trailingslashit( $current_upload_path ) ) ), '/' );
		}
		$needle = '/wp-content/uploads/';
		$position = strpos( $path, $needle );
		return false === $position ? '' : ltrim( substr( $path, $position + strlen( $needle ) ), '/' );
	}

	/**
	 * Find a current attachment by WordPress's stored uploads-relative path.
	 *
	 * @param string $relative_path Uploads-relative file path.
	 * @return int
	 */
	private static function find_import_media_attachment( $relative_path ) {
		static $matches = array();
		$relative_path = ltrim( (string) $relative_path, '/' );
		if ( isset( $matches[ $relative_path ] ) ) {
			return $matches[ $relative_path ];
		}
		global $wpdb;
		$attachment_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT pm.post_id
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = '_wp_attached_file'
					AND pm.meta_value = %s
					AND p.post_type = 'attachment'
					AND p.post_status != 'trash'
				LIMIT 1",
				$relative_path
			)
		);
		$matches[ $relative_path ] = $attachment_id;
		return $attachment_id;
	}

	/**
	 * Prepare a compact safe label for a potentially long source URL.
	 *
	 * @param string $source_url Original source URL.
	 * @param string $relative_path Optional uploads-relative path.
	 * @return string
	 */
	private static function import_image_source_label( $source_url, $relative_path ) {
		if ( '' !== $relative_path ) {
			return 'uploads/' . $relative_path;
		}
		$parsed = wp_parse_url( $source_url );
		$label = trim( (string) ( $parsed['host'] ?? '' ) . (string) ( $parsed['path'] ?? $source_url ) );
		return strlen( $label ) > 96 ? substr( $label, 0, 93 ) . '…' : $label;
	}

	/**
	 * Render the image inventory below one Quiz or Question-bank audit.
	 *
	 * @param array $quiz Preview Quiz or CSV Question-bank data.
	 * @return void
	 */
	private static function render_quiz_media_inventory( $quiz, $media_decisions = array() ) {
		$assets = array();
		foreach ( (array) ( $quiz['records'] ?? array() ) as $record ) {
			foreach ( self::record_image_inventory( $record, $media_decisions ) as $asset ) {
				$key = (string) ( $asset['id'] ?? '' );
				if ( ! isset( $assets[ $key ] ) ) {
					$assets[ $key ] = $asset;
					continue;
				}
				$assets[ $key ]['occurrences'] += absint( $asset['occurrences'] ?? 0 );
				$assets[ $key ]['locations'] = array_values( array_unique( array_merge( $assets[ $key ]['locations'], $asset['locations'] ) ) );
				$assets[ $key ]['alts'] = array_values( array_unique( array_merge( $assets[ $key ]['alts'], $asset['alts'] ) ) );
				$assets[ $key ]['dimensions'] = array_values( array_unique( array_merge( $assets[ $key ]['dimensions'], $asset['dimensions'] ) ) );
			}
		}
		if ( empty( $assets ) ) {
			return;
		}
		$counts = array_count_values( wp_list_pluck( $assets, 'status' ) );
		?>
		<?php $inventory_id = 'tutorhelper-lms-import-media-' . substr( sha1( (string) ( $quiz['source'] ?? '' ) . '|' . (string) ( $quiz['title'] ?? '' ) ), 0, 12 ); ?>
		<section class="tutorhelper-lms-import__media-inventory">
			<h4><?php echo esc_html( sprintf( __( '%s: image review', 'tutorhelper-lms' ), (string) ( $quiz['title'] ?? __( 'Question bank', 'tutorhelper-lms' ) ) ) ); ?></h4>
			<p class="description"><?php esc_html_e( 'The original source URL is retained. An uploads-relative path is used only to check the current Media Library. TutorHelper does not download, copy or create an image during review.', 'tutorhelper-lms' ); ?></p>
			<?php if ( array_filter( $assets, static function( $asset ) { return ! empty( $asset['can_check_external'] ); } ) ) : ?>
				<div class="tutorhelper-lms-import__external-warning"><strong><?php esc_html_e( 'External image links are a risk.', 'tutorhelper-lms' ); ?></strong> <?php esc_html_e( 'An image can be changed, moved or deleted by the other site, which would leave it unavailable in a future quiz. Check a source only when you need to assess it, then explicitly choose whether the later import may retain that external link. No image is copied during this review.', 'tutorhelper-lms' ); ?></div>
			<?php endif; ?>
			<ul class="tutorhelper-lms-import__media-summary">
				<li><strong><?php echo esc_html( count( $assets ) ); ?></strong> <?php esc_html_e( 'unique images', 'tutorhelper-lms' ); ?></li>
				<li><strong><?php echo esc_html( absint( $counts['available'] ?? 0 ) ); ?></strong> <?php esc_html_e( 'available locally', 'tutorhelper-lms' ); ?></li>
				<li><strong><?php echo esc_html( absint( $counts['current_missing'] ?? 0 ) + absint( $counts['source_upload_missing'] ?? 0 ) ); ?></strong> <?php esc_html_e( 'uploads needing review', 'tutorhelper-lms' ); ?></li>
				<li><strong><?php echo esc_html( absint( $counts['external'] ?? 0 ) ); ?></strong> <?php esc_html_e( 'external sources', 'tutorhelper-lms' ); ?></li>
			</ul>
			<div id="<?php echo esc_attr( $inventory_id ); ?>" class="tutorhelper-lms-import__media-table-region" data-tutorhelper-lms-import-media-table-region>
				<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Image', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Source / upload path', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Current site', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'External link', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Used in', 'tutorhelper-lms' ); ?></th></tr></thead>
					<tbody><?php $asset_position = 0; $asset_count = count( $assets ); foreach ( $assets as $asset ) : ?><?php $asset_position++; $asset['tooltip_opens_upward'] = $asset_position > max( 1, $asset_count - 2 ); ?>
						<tr>
							<td><span class="tutorhelper-lms-import__media-status is-<?php echo esc_attr( $asset['status'] ); ?>"><?php echo esc_html( $asset['status_label'] ); ?></span></td>
							<td><?php self::render_import_image_icon( $asset ); ?></td>
							<td><code title="<?php echo esc_attr( $asset['display_source_url'] ); ?>"><?php echo esc_html( $asset['display_source_label'] ); ?></code><?php if ( ! empty( $asset['thumbnail_url'] ) ) : ?><small class="tutorhelper-lms-import__image-preview-hint"><?php esc_html_e( 'Hover over image icon to preview image', 'tutorhelper-lms' ); ?></small><?php elseif ( ! empty( $asset['dimensions'] ) ) : ?><small><?php echo esc_html( implode( ', ', $asset['dimensions'] ) ); ?></small><?php endif; ?></td>
							<td><?php if ( ! empty( $asset['attachment_id'] ) ) : ?><a href="<?php echo esc_url( get_edit_post_link( absint( $asset['attachment_id'] ), 'raw' ) ); ?>"><?php echo esc_html( ! empty( $asset['selected_local_attachment'] ) ? sprintf( __( 'Media #%d selected', 'tutorhelper-lms' ), absint( $asset['attachment_id'] ) ) : sprintf( __( 'Media #%d found', 'tutorhelper-lms' ), absint( $asset['attachment_id'] ) ) ); ?></a><?php else : ?><span class="description"><?php esc_html_e( 'No matching attachment', 'tutorhelper-lms' ); ?></span><?php endif; ?><?php self::render_local_image_control( $asset ); ?></td>
							<td><?php self::render_external_image_control( $asset ); ?></td>
							<td><strong><?php echo esc_html( sprintf( _n( '%d use', '%d uses', absint( $asset['occurrences'] ), 'tutorhelper-lms' ), absint( $asset['occurrences'] ) ) ); ?></strong><br /><?php echo esc_html( implode( ' · ', $asset['locations'] ) ); ?><?php if ( ! empty( $asset['alts'] ) ) : ?><small><?php echo esc_html( sprintf( __( 'Alt text: %s', 'tutorhelper-lms' ), implode( ' | ', $asset['alts'] ) ) ); ?></small><?php endif; ?></td>
						</tr>
					<?php endforeach; ?></tbody>
				</table></div>
			</div>
		</section>
		<?php
	}


	/**
	 * Render deliberate per-asset controls for a remote image source.
	 *
	 * A link is checked only after the tutor asks for it. A valid response does
	 * not opt the tutor in: a separate action is required to retain the link in
	 * a later import.
	 *
	 * @param array $asset Resolved image asset.
	 * @return void
	 */
	private static function render_external_image_control( $asset ) {
		if ( empty( $asset['can_check_external'] ) ) {
			echo '<span class="description">' . esc_html__( 'Not an external source', 'tutorhelper-lms' ) . '</span>';
			return;
		}
		$decision = is_array( $asset['external_decision'] ?? null ) ? $asset['external_decision'] : array();
		$validation = is_array( $decision['validation'] ?? null ) ? $decision['validation'] : array();
		$validation_state = sanitize_key( $validation['state'] ?? '' );
		$image_id = sanitize_key( $asset['id'] ?? '' );
		if ( 'valid' === $validation_state ) {
			$using_external = ! empty( $decision['use_external'] );
			?>
			<strong class="tutorhelper-lms-import__external-result is-valid"><?php esc_html_e( 'Image response confirmed', 'tutorhelper-lms' ); ?></strong>
			<small><?php echo esc_html( sprintf( __( 'HTTP %1$d · %2$s', 'tutorhelper-lms' ), absint( $validation['http_status'] ?? 0 ), (string) ( $validation['content_type'] ?? __( 'image response', 'tutorhelper-lms' ) ) ) ); ?></small>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-import__external-action" data-tutorhelper-lms-pending-label="<?php esc_attr_e( 'Updating…', 'tutorhelper-lms' ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SET_EXTERNAL_IMAGE_ACTION ); ?>" />
				<input type="hidden" name="tutorhelper_lms_external_operation" value="set" />
				<input type="hidden" name="external_image_id" value="<?php echo esc_attr( $image_id ); ?>" />
				<input type="hidden" name="external_image_preference" value="<?php echo esc_attr( $using_external ? 'do_not_use' : 'use' ); ?>" />
				<?php wp_nonce_field( self::SET_EXTERNAL_IMAGE_ACTION . '_' . $image_id ); ?>
				<button type="submit" class="button tutorhelper-lms-button--grey"><?php echo esc_html( $using_external ? __( 'Do not use external link', 'tutorhelper-lms' ) : __( 'Use external link', 'tutorhelper-lms' ) ); ?></button>
			</form>
			<?php if ( $using_external ) : ?><small class="tutorhelper-lms-import__external-choice"><?php esc_html_e( 'Tutor choice saved for this private review.', 'tutorhelper-lms' ); ?></small><?php endif; ?>
			<?php
			return;
		}
		if ( '' !== $validation_state ) {
			echo '<strong class="tutorhelper-lms-import__external-result is-invalid">' . esc_html( (string) ( $validation['label'] ?? __( 'Could not confirm image response', 'tutorhelper-lms' ) ) ) . '</strong>';
			if ( ! empty( $validation['detail'] ) ) {
				echo '<small>' . esc_html( (string) $validation['detail'] ) . '</small>';
			}
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-import__external-action" data-tutorhelper-lms-pending-label="<?php esc_attr_e( 'Checking…', 'tutorhelper-lms' ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::CHECK_EXTERNAL_IMAGE_ACTION ); ?>" />
			<input type="hidden" name="tutorhelper_lms_external_operation" value="check" />
			<input type="hidden" name="external_image_id" value="<?php echo esc_attr( $image_id ); ?>" />
			<?php wp_nonce_field( self::CHECK_EXTERNAL_IMAGE_ACTION . '_' . $image_id ); ?>
			<button type="submit" class="button tutorhelper-lms-button--grey"><?php echo esc_html( '' === $validation_state ? __( 'Check external image', 'tutorhelper-lms' ) : __( 'Check again', 'tutorhelper-lms' ) ); ?></button>
		</form>
		<?php
	}


	/**
	 * Let the tutor map an unresolved import image to an existing Media Library
	 * attachment. The source image is never uploaded, downloaded or copied.
	 *
	 * @param array $asset Resolved source image.
	 * @return void
	 */
	private static function render_local_image_control( $asset ) {
		$image_id = sanitize_key( $asset['id'] ?? '' );
		if ( '' === $image_id || ( ! empty( $asset['attachment_id'] ) && empty( $asset['selected_local_attachment'] ) ) ) {
			return;
		}
		$label = ! empty( $asset['selected_local_attachment'] ) ? __( 'Choose a different Media Library image', 'tutorhelper-lms' ) : __( 'Choose an image from Media Library', 'tutorhelper-lms' );
		?>
		<button type="button" class="button tutorhelper-lms-button--grey tutorhelper-lms-import__select-local-image" data-tutorhelper-lms-import-image-id="<?php echo esc_attr( $image_id ); ?>" data-tutorhelper-lms-import-image-nonce="<?php echo esc_attr( wp_create_nonce( self::SELECT_LOCAL_IMAGE_ACTION . '_' . $image_id ) ); ?>" data-tutorhelper-lms-pending-label="<?php esc_attr_e( 'Updating…', 'tutorhelper-lms' ); ?>"><?php echo esc_html( $label ); ?></button>
		<?php
	}

	/**
	 * Save a tutor-selected existing Media Library image to the temporary preview.
	 *
	 * @return void
	 */
	public static function select_import_media_image() {
		self::require_import_tutor();
		$image_id = sanitize_key( wp_unslash( $_POST['external_image_id'] ?? '' ) );
		check_ajax_referer( self::SELECT_LOCAL_IMAGE_ACTION . '_' . $image_id );
		$attachment_id = absint( $_POST['attachment_id'] ?? 0 );
		if ( 'attachment' !== get_post_type( $attachment_id ) || ! wp_attachment_is_image( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Choose an existing image from the Media Library.', 'tutorhelper-lms' ) ), 400 );
		}
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) ) {
			wp_send_json_error( array( 'message' => __( 'This import preview has expired. Upload the source files again.', 'tutorhelper-lms' ) ), 410 );
		}
		if ( ! self::preview_image_by_id( $preview, $image_id ) ) {
			wp_send_json_error( array( 'message' => __( 'This source image is no longer part of the current preview.', 'tutorhelper-lms' ) ), 404 );
		}
		$decision = is_array( $preview['media_decisions'][ $image_id ] ?? null ) ? $preview['media_decisions'][ $image_id ] : array();
		$decision['local_attachment_id'] = $attachment_id;
		$decision['use_external'] = false;
		$preview['media_decisions'][ $image_id ] = $decision;
		self::persist_durable_run( $preview );
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		$quiz = self::quiz_for_image( $preview, $image_id );
		if ( ! is_array( $quiz ) ) {
			wp_send_json_error( array( 'message' => __( 'The image review table could not be refreshed.', 'tutorhelper-lms' ) ), 500 );
		}
		ob_start();
		self::render_quiz_media_inventory( $quiz, (array) $preview['media_decisions'] );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/**
	 * Find the Question bank whose image review includes a source image.
	 *
	 * @param array  $preview Current preview.
	 * @param string $image_id Source image ID.
	 * @return array|null
	 */
	private static function quiz_for_image( $preview, $image_id ) {
		$groups = (array) ( $preview['quizzes'] ?? array() );
		if ( ! empty( $preview['csv_questions']['records'] ) && is_array( $preview['csv_questions']['records'] ) ) {
			$groups[] = $preview['csv_questions'];
		}
		foreach ( $groups as $quiz ) {
			foreach ( (array) ( $quiz['records'] ?? array() ) as $record ) {
				foreach ( self::record_image_inventory( $record ) as $asset ) {
					if ( hash_equals( (string) ( $asset['id'] ?? '' ), (string) $image_id ) ) {
						return $quiz;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Resolve a preview asset from its opaque ID without trusting posted URLs.
	 *
	 * @param array  $preview Current private preview.
	 * @param string $image_id Image inventory ID.
	 * @return array|null
	 */
	private static function preview_image_by_id( $preview, $image_id ) {
		$groups = array();
		foreach ( (array) ( $preview['quizzes'] ?? array() ) as $quiz ) {
			$groups[] = (array) ( $quiz['records'] ?? array() );
		}
		if ( ! empty( $preview['csv_questions']['records'] ) && is_array( $preview['csv_questions']['records'] ) ) {
			$groups[] = $preview['csv_questions']['records'];
		}
		foreach ( $groups as $records ) {
			foreach ( $records as $record ) {
				foreach ( self::record_image_inventory( $record ) as $asset ) {
					if ( hash_equals( (string) ( $asset['id'] ?? '' ), $image_id ) ) {
						return $asset;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Check one tutor-requested remote image with WordPress's safe HTTP client.
	 *
	 * @param string $source_url External image URL.
	 * @return array Compact validation result.
	 */
	private static function validate_external_image_url( $source_url ) {
		$source_url = esc_url_raw( $source_url );
		if ( ! wp_http_validate_url( $source_url ) ) {
			return array(
				'state' => 'blocked',
				'label' => __( 'Unsafe or invalid external URL', 'tutorhelper-lms' ),
				'detail' => __( 'The source could not be requested safely.', 'tutorhelper-lms' ),
			);
		}
		$response = wp_safe_remote_get(
			$source_url,
			array(
				'timeout'             => 8,
				'redirection'         => 2,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 8192,
				'user-agent'          => 'TutorHelper LMS image review',
			)
		);
		if ( is_wp_error( $response ) ) {
			return array(
				'state' => 'unavailable',
				'label' => __( 'External image could not be reached', 'tutorhelper-lms' ),
				'detail' => sanitize_text_field( $response->get_error_message() ),
			);
		}
		$http_status = absint( wp_remote_retrieve_response_code( $response ) );
		$content_type = strtolower( trim( (string) wp_remote_retrieve_header( $response, 'content-type' ) ) );
		$content_type = trim( strtok( $content_type, ';' ) );
		if ( $http_status < 200 || $http_status >= 300 ) {
			return array(
				'state'       => 'unavailable',
				'label'       => __( 'External image returned an error', 'tutorhelper-lms' ),
				'detail'      => sprintf( __( 'The server returned HTTP %d.', 'tutorhelper-lms' ), $http_status ),
				'http_status' => $http_status,
			);
		}
		if ( 0 !== strpos( $content_type, 'image/' ) ) {
			return array(
				'state'        => 'not_image',
				'label'        => __( 'External URL did not return an image', 'tutorhelper-lms' ),
				'detail'       => $content_type ? sprintf( __( 'The server reported %s.', 'tutorhelper-lms' ), $content_type ) : __( 'The server did not provide an image content type.', 'tutorhelper-lms' ),
				'http_status'  => $http_status,
				'content_type' => $content_type,
			);
		}
		return array(
			'state'        => 'valid',
			'label'        => __( 'Image response confirmed', 'tutorhelper-lms' ),
			'http_status'  => $http_status,
			'content_type' => $content_type,
		);
	}

	/**
	 * Save the result of one tutor-requested safe external-image check.
	 *
	 * @return void
	 */
	public static function check_external_image() {
		self::require_import_tutor();
		$image_id = isset( $_POST['external_image_id'] ) ? sanitize_key( wp_unslash( $_POST['external_image_id'] ) ) : '';
		check_admin_referer( self::CHECK_EXTERNAL_IMAGE_ACTION . '_' . $image_id );
		$preview = get_transient( self::preview_key() );
		$asset = is_array( $preview ) ? self::preview_image_by_id( $preview, $image_id ) : null;
		if ( ! is_array( $preview ) || ! $asset || empty( $asset['can_check_external'] ) ) {
			self::redirect_import( 'external_image_not_found', absint( $preview['_run_id'] ?? 0 ) );
		}
		$previous = is_array( $preview['media_decisions'][ $image_id ] ?? null ) ? $preview['media_decisions'][ $image_id ] : array();
		$validation = self::validate_external_image_url( (string) $asset['source_url'] );
		$preview['media_decisions'][ $image_id ] = array(
			'source_url'   => (string) $asset['source_url'],
			'validation'   => $validation,
			'use_external' => 'valid' === ( $validation['state'] ?? '' ) ? ! empty( $previous['use_external'] ) : false,
		);
		self::persist_durable_run( $preview );
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		self::redirect_import( 'external_image_checked', absint( $preview['_run_id'] ?? 0 ) );
	}

	/**
	 * Save an explicit tutor choice to retain or reject a confirmed external URL.
	 *
	 * @return void
	 */
	public static function set_external_image_preference() {
		self::require_import_tutor();
		$image_id = isset( $_POST['external_image_id'] ) ? sanitize_key( wp_unslash( $_POST['external_image_id'] ) ) : '';
		check_admin_referer( self::SET_EXTERNAL_IMAGE_ACTION . '_' . $image_id );
		$preview = get_transient( self::preview_key() );
		$asset = is_array( $preview ) ? self::preview_image_by_id( $preview, $image_id ) : null;
		$decision = is_array( $preview['media_decisions'][ $image_id ] ?? null ) ? $preview['media_decisions'][ $image_id ] : array();
		if ( ! is_array( $preview ) || ! $asset || empty( $asset['can_check_external'] ) || 'valid' !== ( $decision['validation']['state'] ?? '' ) ) {
			self::redirect_import( 'external_image_not_found', absint( $preview['_run_id'] ?? 0 ) );
		}
		$decision['use_external'] = 'use' === sanitize_key( wp_unslash( $_POST['external_image_preference'] ?? '' ) );
		$preview['media_decisions'][ $image_id ] = $decision;
		self::persist_durable_run( $preview );
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		self::redirect_import( $decision['use_external'] ? 'external_image_enabled' : 'external_image_disabled', absint( $preview['_run_id'] ?? 0 ) );
	}

	/**
	 * Return the Quiz or Question-bank preview which contains one image asset.
	 *
	 * @param array  $preview Current private preview.
	 * @param string $image_id Image inventory ID.
	 * @return array|null
	 */
	private static function preview_quiz_by_image_id( $preview, $image_id ) {
		$groups = (array) ( $preview['quizzes'] ?? array() );
		if ( ! empty( $preview['csv_questions']['records'] ) && is_array( $preview['csv_questions']['records'] ) ) {
			$groups[] = (array) $preview['csv_questions'];
		}
		foreach ( $groups as $quiz ) {
			foreach ( (array) ( $quiz['records'] ?? array() ) as $record ) {
				foreach ( self::record_image_inventory( $record, (array) ( $preview['media_decisions'] ?? array() ) ) as $asset ) {
					if ( hash_equals( (string) ( $asset['id'] ?? '' ), $image_id ) ) {
						return $quiz;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Apply one external-image action and return only its refreshed audit table.
	 *
	 * The old admin-post route remains as a no-JavaScript fallback. JavaScript
	 * callers use this endpoint so the page never navigates away from the table.
	 *
	 * @return void
	 */
	public static function refresh_external_image_table() {
		self::require_import_tutor();
		$operation = isset( $_POST['tutorhelper_lms_external_operation'] ) ? sanitize_key( wp_unslash( $_POST['tutorhelper_lms_external_operation'] ) ) : '';
		$image_id = isset( $_POST['external_image_id'] ) ? sanitize_key( wp_unslash( $_POST['external_image_id'] ) ) : '';
		$nonce_action = 'check' === $operation ? self::CHECK_EXTERNAL_IMAGE_ACTION : ( 'set' === $operation ? self::SET_EXTERNAL_IMAGE_ACTION : '' );
		if ( ! $nonce_action || ! check_ajax_referer( $nonce_action . '_' . $image_id, '_wpnonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Your image-review request could not be verified. Please refresh the Import page and try again.', 'tutorhelper-lms' ) ), 403 );
		}
		$preview = get_transient( self::preview_key() );
		$asset = is_array( $preview ) ? self::preview_image_by_id( $preview, $image_id ) : null;
		if ( ! is_array( $preview ) || ! $asset || empty( $asset['can_check_external'] ) ) {
			wp_send_json_error( array( 'message' => __( 'That external image is no longer available in this preview.', 'tutorhelper-lms' ) ), 404 );
		}
		if ( 'check' === $operation ) {
			$previous = is_array( $preview['media_decisions'][ $image_id ] ?? null ) ? $preview['media_decisions'][ $image_id ] : array();
			$validation = self::validate_external_image_url( (string) $asset['source_url'] );
			$preview['media_decisions'][ $image_id ] = array(
				'source_url'   => (string) $asset['source_url'],
				'validation'   => $validation,
				'use_external' => 'valid' === ( $validation['state'] ?? '' ) ? ! empty( $previous['use_external'] ) : false,
			);
		} else {
			$decision = is_array( $preview['media_decisions'][ $image_id ] ?? null ) ? $preview['media_decisions'][ $image_id ] : array();
			if ( 'valid' !== ( $decision['validation']['state'] ?? '' ) ) {
				wp_send_json_error( array( 'message' => __( 'Confirm that this URL returns an image before choosing it for the review.', 'tutorhelper-lms' ) ), 422 );
			}
			$decision['use_external'] = 'use' === sanitize_key( wp_unslash( $_POST['external_image_preference'] ?? '' ) );
			$preview['media_decisions'][ $image_id ] = $decision;
		}
		self::persist_durable_run( $preview );
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		$quiz = self::preview_quiz_by_image_id( $preview, $image_id );
		if ( ! $quiz ) {
			wp_send_json_error( array( 'message' => __( 'The refreshed image-review table could not be found.', 'tutorhelper-lms' ) ), 404 );
		}
		ob_start();
		self::render_quiz_media_inventory( $quiz, (array) ( $preview['media_decisions'] ?? array() ) );
		$html = (string) ob_get_clean();
		wp_send_json_success( array( 'html' => $html ) );
	}

	/**
	 * Render a focusable image icon and a local-only thumbnail on hover/focus.
	 *
	 * @param array $asset Resolved image item.
	 * @return void
	 */
	private static function render_import_image_icon( $asset ) {
		if ( ! empty( $asset['thumbnail_url'] ) ) {
			$alt = ! empty( $asset['alts'][0] ) ? (string) $asset['alts'][0] : __( 'Imported image preview', 'tutorhelper-lms' );
			$thumbnail_label = ! empty( $asset['thumbnail_is_external'] ) ? __( 'Selected external source thumbnail', 'tutorhelper-lms' ) : __( 'Current Media Library thumbnail', 'tutorhelper-lms' );
			echo '<span class="tutorhelper-lms-import__image-icon has-thumbnail' . ( ! empty( $asset['thumbnail_is_external'] ) ? ' is-external' : '' ) . ( ! empty( $asset['tooltip_opens_upward'] ) ? ' opens-upward' : '' ) . '" tabindex="0"><span class="dashicons dashicons-format-image" aria-hidden="true"></span><span class="tutorhelper-lms-import__image-tooltip"><img src="' . esc_url( $asset['thumbnail_url'] ) . '" alt="' . esc_attr( $alt ) . '" /><span>' . esc_html( $thumbnail_label ) . '</span></span><span class="screen-reader-text">' . esc_html( $thumbnail_label ) . '</span></span>';
			return;
		}
		echo '<span class="tutorhelper-lms-import__image-icon is-unavailable" tabindex="0" title="' . esc_attr( $asset['status_label'] ) . '"><span class="dashicons dashicons-format-image" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html( $asset['status_label'] ) . '</span></span>';
	}

	/**
	 * Identify whether a Question uses images in its prompt or answer content.
	 *
	 * @param array $record Temporary Question record.
	 * @return array{prompt:bool,answers:bool}
	 */
	private static function question_image_usage( $record ) {
		$usage = array(
			'prompt'  => ! empty( self::extract_import_images( (string) ( $record['prompt'] ?? '' ) ) ),
			'answers' => false,
		);
		foreach ( (array) ( $record['answers'] ?? array() ) as $answer ) {
			if ( ! empty( self::extract_import_images( (string) ( $answer['text'] ?? '' ) ) ) || ! empty( self::extract_import_images( (string) ( $answer['match'] ?? '' ) ) ) ) {
				$usage['answers'] = true;
				break;
			}
		}
		return $usage;
	}

	/**
	 * Render an image-use indicator without making the audit cell editable.
	 *
	 * @param bool   $has_image Whether the Question field includes an image.
	 * @param string $label Human-readable image use label.
	 * @return void
	 */
	private static function render_question_image_usage_indicator( $has_image, $label ) {
		$state = $has_image ? 'is-present' : 'is-absent';
		$text = $has_image ? sprintf( __( '%s found', 'tutorhelper-lms' ), $label ) : sprintf( __( 'No %s', 'tutorhelper-lms' ), strtolower( $label ) );
		echo '<span class="tutorhelper-lms-import__question-image-use ' . esc_attr( $state ) . '" title="' . esc_attr( $text ) . '"><span class="dashicons ' . esc_attr( $has_image ? 'dashicons-format-image' : 'dashicons-minus' ) . '" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html( $text ) . '</span></span>';
	}

	/**
	 * Render Question audits grouped by source Question type.
	 *
	 * @param array $quiz Temporary Quiz preview.
	 * @return void
	 */
	private static function render_quiz_audit( $quiz, $media_decisions = array() ) {
		$groups = array();
		foreach ( (array) ( $quiz['records'] ?? array() ) as $record ) {
			$record['kind'] = 'question';
			$record['media_images'] = self::record_image_inventory( $record, $media_decisions );
		// External thumbnails are deliberately confined to the opted-in audit table.
		foreach ( $record['media_images'] as &$image ) {
			if ( ! empty( $image['thumbnail_is_external'] ) ) {
				$image['thumbnail_url'] = '';
			}
		}
		unset( $image );
			$type = sanitize_key( $record['type'] ?? '' );
			$groups[ $type ][] = $record;
		}
		foreach ( $groups as $type => $records ) {
			$definition = self::question_audit_definition( $type );
			$optional_definition = self::question_audit_optional_definition( $type );
			$fields = array_merge( $definition, $optional_definition );
			$label = (string) ( $records[0]['label'] ?? __( 'Unsupported', 'tutorhelper-lms' ) );
			?>
			<section class="tutorhelper-lms-import__audit">
				<h4><?php echo esc_html( sprintf( __( '%1$s: %2$s', 'tutorhelper-lms' ), $quiz['title'], $label ) ); ?></h4>
				<p class="description"><strong><?php esc_html_e( 'Required fields:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( implode( ' · ', $definition ) ); ?></p>
				<?php if ( ! empty( $optional_definition ) ) : ?><p class="description"><strong><?php esc_html_e( 'Optional fields:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( implode( ' · ', $optional_definition ) ); ?> <?php esc_html_e( 'Optional fields do not block import; use the plus button to add one.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
				<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Question', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Prompt image', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Answer image', 'tutorhelper-lms' ); ?></th><?php foreach ( $fields as $field_label ) : ?><th><?php echo esc_html( $field_label ); ?></th><?php endforeach; ?></tr></thead>
					<tbody><?php foreach ( $records as $record ) : ?><?php $status = self::question_audit_status( $record ); $image_usage = self::question_image_usage( $record ); ?><tr><th scope="row"><?php echo esc_html( $record['title'] ?: __( 'Untitled Question', 'tutorhelper-lms' ) ); ?></th><td><?php self::render_question_image_usage_indicator( $image_usage['prompt'], __( 'Prompt image', 'tutorhelper-lms' ) ); ?></td><td><?php self::render_question_image_usage_indicator( $image_usage['answers'], __( 'Answer image', 'tutorhelper-lms' ) ); ?></td><?php foreach ( $fields as $field => $field_label ) : ?><td><?php self::render_audit_indicator( ! empty( $status[ $field ] ), $record, $field, $field_label, isset( $optional_definition[ $field ] ) ); ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody>
				</table></div>
			</section>
			<?php
		}
	}

	/**
	 * Return reviewed LearnDash Question records with their source Quiz context.
	 *
	 * @param array $preview Private import preview.
	 * @return array[]
	 */
	private static function learndash_import_items( $preview ) {
		$items = array();
		foreach ( (array) ( $preview['quizzes'] ?? array() ) as $quiz_index => $quiz ) {
			foreach ( (array) ( $quiz['records'] ?? array() ) as $record_index => $record ) {
				$items[] = array( 'quiz_index' => $quiz_index, 'record_index' => $record_index, 'quiz_title' => (string) ( $quiz['title'] ?? __( 'LearnDash Question bank', 'tutorhelper-lms' ) ), 'record' => $record );
			}
		}
		return $items;
	}

	/**
	 * Replace a reviewed source image with its selected current-site attachment.
	 * Unresolved sources never reach Question creation.
	 *
	 * @param array $record Preview Question record.
	 * @param array $media_decisions Tutor image decisions.
	 * @return array|WP_Error
	 */
	private static function prepare_record_for_question_creation( $record, $media_decisions, $force_draft = true ) {
		if ( 'cloze' === ( $record['type'] ?? '' ) && ! empty( $record['cloze'] ) && 'ready' !== ( $record['cloze']['status'] ?? '' ) ) {
			return new WP_Error( 'cloze_review_needed', __( 'Resolve the LearnDash fill-in pattern before creating this Question.', 'tutorhelper-lms' ) );
		}
		$replacements = array();
		foreach ( self::record_image_inventory( $record, $media_decisions ) as $asset ) {
			if ( ! empty( $asset['attachment_id'] ) && ! empty( $asset['attachment_url'] ) ) {
				$replacements[ (string) $asset['source_url'] ] = (string) $asset['attachment_url'];
			} elseif ( empty( $asset['using_external'] ) ) {
				return new WP_Error( 'unresolved_image', __( 'Resolve every image source before creating this Question.', 'tutorhelper-lms' ) );
			}
		}
		foreach ( array( 'prompt', 'correct_feedback', 'incorrect_feedback', 'tip' ) as $field ) {
			$record[ $field ] = strtr( (string) ( $record[ $field ] ?? '' ), $replacements );
		}
		foreach ( (array) ( $record['answers'] ?? array() ) as $index => $answer ) {
			$record['answers'][ $index ]['text'] = strtr( (string) ( $answer['text'] ?? '' ), $replacements );
			$record['answers'][ $index ]['match'] = strtr( (string) ( $answer['match'] ?? '' ), $replacements );
		}
		if ( $force_draft ) {
			$record['import_status'] = 'draft';
		}
		return $record;
	}

	/**
	 * Render the confirmed LearnDash Question creation gate.
	 *
	 * @param array $preview Private import preview.
	 * @return void
	 */
	private static function render_learndash_execution( $preview ) {
		$items = self::learndash_import_items( $preview );
		if ( empty( $items ) ) {
			return;
		}
		$media_decisions = (array) ( $preview['media_decisions'] ?? array() );
		$ready = true;
		?>
		<section id="tutorhelper-lms-learndash-creation-review" class="tutorhelper-lms-import__mapping tutorhelper-lms-import__learndash-execution" data-tutorhelper-lms-learndash-creation-region>
			<h3><?php esc_html_e( 'Create reviewed LearnDash Questions', 'tutorhelper-lms' ); ?></h3>
			<p><?php esc_html_e( 'This creates supported reusable Questions in the Question Bank after review. Choose whether they begin as Draft or Published. It does not create Quizzes, placements, Courses, Media Library files, students or attempts.', 'tutorhelper-lms' ); ?></p>
			<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Source Question', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Creation readiness', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Existing Question Bank match', 'tutorhelper-lms' ); ?></th></tr></thead>
				<tbody><?php foreach ( $items as $item ) : ?><?php $prepared = self::prepare_record_for_question_creation( $item['record'], $media_decisions ); $record_ready = 'supported' === ( $item['record']['status'] ?? '' ) && ! is_wp_error( $prepared ); $inspection = $record_ready ? TutorHelper_LMS_Question_Bank::inspect_import_record( $prepared ) : null; $record_ready = $record_ready && ! is_wp_error( $inspection ); if ( 'supported' === ( $item['record']['status'] ?? '' ) ) { $ready = $ready && $record_ready; } ?><tr>
					<th scope="row"><?php echo esc_html( $item['quiz_title'] . ' — ' . ( $item['record']['title'] ?: __( 'Untitled Question', 'tutorhelper-lms' ) ) ); ?></th>
					<td><?php if ( 'supported' !== ( $item['record']['status'] ?? '' ) ) : ?><span class="tutorhelper-lms-import__creation-state is-blocked"><?php esc_html_e( 'Not included in this Core creation step', 'tutorhelper-lms' ); ?></span><?php elseif ( $record_ready ) : ?><span class="tutorhelper-lms-import__creation-state is-ready"><?php esc_html_e( 'Ready for Question Bank creation', 'tutorhelper-lms' ); ?></span><?php else : ?><span class="tutorhelper-lms-import__creation-state is-blocked"><?php echo esc_html( is_wp_error( $prepared ) ? $prepared->get_error_message() : $inspection->get_error_message() ); ?></span><?php endif; ?></td>
					<td><?php if ( ! $record_ready ) : ?><span class="description"><?php esc_html_e( 'Resolve the creation gate first.', 'tutorhelper-lms' ); ?></span><?php elseif ( ! empty( $inspection['source_question_id'] ) ) : ?><strong><?php echo esc_html( sprintf( __( 'Question #%d will be reused from its source ID.', 'tutorhelper-lms' ), absint( $inspection['source_question_id'] ) ) ); ?></strong><?php elseif ( ! empty( $inspection['content_question_ids'] ) ) : ?><label><?php esc_html_e( 'Identical content found:', 'tutorhelper-lms' ); ?><select form="tutorhelper-lms-learndash-creation" name="learndash_duplicate_choices[<?php echo esc_attr( sanitize_key( $item['record']['id'] ) ); ?>]" required><option value=""><?php esc_html_e( 'Choose how to handle this duplicate…', 'tutorhelper-lms' ); ?></option><?php foreach ( $inspection['content_question_ids'] as $question_id ) : ?><option value="reuse-<?php echo esc_attr( $question_id ); ?>"><?php echo esc_html( sprintf( __( 'Reuse Question #%1$d — %2$s', 'tutorhelper-lms' ), $question_id, get_the_title( $question_id ) ) ); ?></option><?php endforeach; ?><option value="create"><?php esc_html_e( 'Create a separate Question', 'tutorhelper-lms' ); ?></option></select></label><small><?php esc_html_e( 'Choose deliberately so later Quiz imports retain the intended Question reference.', 'tutorhelper-lms' ); ?></small><?php else : ?><span class="tutorhelper-lms-import__creation-state is-ready"><?php esc_html_e( 'No duplicate / existing question found.', 'tutorhelper-lms' ); ?></span><?php endif; ?></td>
				</tr><?php endforeach; ?></tbody>
			</table></div>
			<p class="tutorhelper-lms-import__creation-recheck"><button type="button" class="button tutorhelper-lms-button--grey tutorhelper-lms-import__recheck-learndash-creation" data-tutorhelper-lms-learndash-creation-nonce="<?php echo esc_attr( wp_create_nonce( self::REFRESH_LEARNDASH_CREATION_ACTION ) ); ?>" data-tutorhelper-lms-pending-label="<?php esc_attr_e( 'Rechecking…', 'tutorhelper-lms' ); ?>"><?php esc_html_e( 'Recheck question status', 'tutorhelper-lms' ); ?></button><span class="description"><?php esc_html_e( 'Use this after correcting required fields or image sources.', 'tutorhelper-lms' ); ?></span></p>
			<?php if ( $ready ) : ?><form id="tutorhelper-lms-learndash-creation" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-import__creation-form"><input type="hidden" name="action" value="<?php echo esc_attr( self::EXECUTE_LEARNDASH_ACTION ); ?>" /><?php wp_nonce_field( self::EXECUTE_LEARNDASH_ACTION ); ?><label class="tutorhelper-lms-import__creation-status"><span><?php esc_html_e( 'Create Questions as', 'tutorhelper-lms' ); ?></span><select name="learndash_question_status"><option value="draft"><?php esc_html_e( 'Draft', 'tutorhelper-lms' ); ?></option><option value="published"><?php esc_html_e( 'Published', 'tutorhelper-lms' ); ?></option></select></label><label><input type="checkbox" name="confirm_learndash_question_create" value="1" required /> <?php esc_html_e( 'I have reviewed the required fields, images and duplicate choices and want to add these reusable Questions to the Question Bank.', 'tutorhelper-lms' ); ?></label><p><button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Add reviewed LearnDash Questions to the Question Bank', 'tutorhelper-lms' ); ?></button></p></form><?php else : ?><p class="description"><?php esc_html_e( 'Recheck the question status after correcting every required field and image source. Creation is enabled only when all supported Questions are ready.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
			<?php if ( ! empty( $preview['learndash_execution']['results'] ) ) : ?><h4><?php esc_html_e( 'LearnDash Question creation results', 'tutorhelper-lms' ); ?></h4><ul><?php foreach ( $preview['learndash_execution']['results'] as $result ) : ?><li><?php echo esc_html( $result ); ?></li><?php endforeach; ?></ul><?php endif; ?>
		</section>
		<?php
	}


	/**
	 * Re-render the Question creation review after tutor corrections without
	 * sending the tutor back to the top of the Import workspace.
	 *
	 * @return void
	 */
	public static function refresh_learndash_creation() {
		self::require_import_tutor();
		check_ajax_referer( self::REFRESH_LEARNDASH_CREATION_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) ) {
			wp_send_json_error( array( 'message' => __( 'This import preview has expired. Upload the source files again.', 'tutorhelper-lms' ) ), 410 );
		}
		ob_start();
		self::render_learndash_execution( $preview );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/**
	 * Re-render the CSV creation review after image or field corrections.
	 *
	 * @return void
	 */
	public static function refresh_csv_creation() {
		self::require_import_tutor();
		check_ajax_referer( self::REFRESH_CSV_CREATION_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) || empty( $preview['csv_questions'] ) ) {
			wp_send_json_error( array( 'message' => __( 'This CSV import preview has expired. Upload the file again.', 'tutorhelper-lms' ) ), 410 );
		}
		ob_start();
		self::render_csv_execution( (array) $preview['csv_questions'], (array) ( $preview['media_decisions'] ?? array() ) );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/**
	 * Confirm the reviewed LearnDash Questions as reusable draft records.
	 *
	 * @return void
	 */
	public static function execute_learndash_questions() {
		self::require_import_tutor();
		check_admin_referer( self::EXECUTE_LEARNDASH_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) || empty( $_POST['confirm_learndash_question_create'] ) ) {
			self::redirect_import( is_array( $preview ) ? 'learndash_creation_confirmation_needed' : 'expired', absint( $preview['_run_id'] ?? 0 ) );
		}
		$choices = isset( $_POST['learndash_duplicate_choices'] ) && is_array( $_POST['learndash_duplicate_choices'] ) ? wp_unslash( $_POST['learndash_duplicate_choices'] ) : array();
		$creation_status = sanitize_key( wp_unslash( $_POST['learndash_question_status'] ?? 'draft' ) );
		if ( ! in_array( $creation_status, array( 'draft', 'published' ), true ) ) {
			$creation_status = 'draft';
		}
		$media_decisions = (array) ( $preview['media_decisions'] ?? array() );
		$results = array(); $created = 0; $reused = 0; $failed = 0;
		foreach ( $preview['quizzes'] as &$quiz ) {
			foreach ( (array) ( $quiz['records'] ?? array() ) as $record_index => &$record ) {
				if ( 'supported' !== ( $record['status'] ?? '' ) ) { continue; }
				$title = (string) ( $record['title'] ?? __( 'Untitled Question', 'tutorhelper-lms' ) );
				$prepared = self::prepare_record_for_question_creation( $record, $media_decisions );
				if ( ! is_wp_error( $prepared ) ) {
					$prepared['import_status'] = $creation_status;
				}
				$inspection = is_wp_error( $prepared ) ? $prepared : TutorHelper_LMS_Question_Bank::inspect_import_record( $prepared );
				if ( is_wp_error( $inspection ) ) { $record['execution_error'] = $inspection->get_error_message(); $results[] = sprintf( __( '%1$s — not created: %2$s', 'tutorhelper-lms' ), $title, $inspection->get_error_message() ); $failed++; continue; }
				if ( ! empty( $inspection['source_question_id'] ) ) {
					$result = TutorHelper_LMS_Question_Bank::reuse_imported_question( $prepared, absint( $inspection['source_question_id'] ) );
				} elseif ( ! empty( $inspection['content_question_ids'] ) ) {
					$choice = sanitize_text_field( $choices[ sanitize_key( $record['id'] ?? '' ) ] ?? '' );
					if ( 'create' === $choice ) { $result = TutorHelper_LMS_Question_Bank::create_from_import( $prepared ); }
					elseif ( 1 === preg_match( '/^reuse-(\d+)$/', $choice, $matches ) && in_array( absint( $matches[1] ), array_map( 'absint', $inspection['content_question_ids'] ), true ) ) { $result = TutorHelper_LMS_Question_Bank::reuse_imported_question( $prepared, absint( $matches[1] ) ); }
					else { $result = new WP_Error( 'duplicate_choice_needed', __( 'Choose whether to reuse the matching Question or create a separate one.', 'tutorhelper-lms' ) ); }
				} else { $result = TutorHelper_LMS_Question_Bank::create_from_import( $prepared ); }
				if ( is_wp_error( $result ) || ! absint( $result['question_id'] ?? 0 ) ) { $message = is_wp_error( $result ) ? $result->get_error_message() : __( 'The Question could not be created.', 'tutorhelper-lms' ); $record['execution_error'] = $message; $results[] = sprintf( __( '%1$s — not created: %2$s', 'tutorhelper-lms' ), $title, $message ); $failed++; continue; }
				$record['created_question_id'] = absint( $result['question_id'] ); unset( $record['execution_error'] );
				if ( ! empty( $result['created'] ) ) { $created++; $results[] = sprintf( __( '%1$s — created as %2$s Question #%3$d.', 'tutorhelper-lms' ), $title, 'published' === $creation_status ? __( 'Published', 'tutorhelper-lms' ) : __( 'Draft', 'tutorhelper-lms' ), absint( $result['question_id'] ) ); } else { $reused++; $results[] = sprintf( __( '%1$s — mapped to existing Question #%2$d.', 'tutorhelper-lms' ), $title, absint( $result['question_id'] ) ); }
			}
		}
		unset( $record, $quiz );
		$preview['learndash_execution'] = array( 'created' => $created, 'reused' => $reused, 'failed' => $failed, 'results' => $results );
		self::persist_durable_run( $preview ); set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		self::redirect_import( $failed ? 'learndash_created_with_errors' : 'learndash_created', absint( $preview['_run_id'] ?? 0 ) );
	}


	/**
	 * Build a no-write Quiz creation plan from the reviewed Question source map.
	 *
	 * @param array $preview Private preview state.
	 * @return array
	 */
	private static function learndash_quiz_plans( $preview ) {
		$plans = array();
		foreach ( (array) ( $preview['quizzes'] ?? array() ) as $index => $quiz ) {
			$record = array(
				'id' => sanitize_key( $quiz['id'] ?? '' ),
				'source_reference' => sanitize_text_field( $quiz['source_reference'] ?? '' ),
				'title' => sanitize_text_field( $quiz['title'] ?? '' ),
				'instructions' => wp_kses_post( $quiz['instructions'] ?? '' ),
				'attempt_policy' => in_array( sanitize_key( $quiz['attempt_policy'] ?? '' ), array( 'single', 'limited' ), true ) ? 'limited' : 'unlimited',
				'attempt_limit' => max( 0, absint( $quiz['attempt_limit'] ?? ( 'single' === sanitize_key( $quiz['attempt_policy'] ?? '' ) ? 1 : 0 ) ) ),
				'show_start_screen' => ! empty( $quiz['show_start_screen'] ),
				'result_message_rules' => is_array( $quiz['result_message_rules'] ?? null ) ? $quiz['result_message_rules'] : array(),
				'passing_percentage' => min( 100, absint( $quiz['passing_percentage'] ?? 0 ) ),
				'time_limit' => absint( $quiz['time_limit'] ?? 0 ),
				// LearnDash random Question pools map to one Adaptive Practice pool, rather than
				// TutorHelper's separate standard-random Quiz mode.
				'practice' => array(
					'mode'                  => ! empty( $quiz['uses_random_pool'] ) ? 'adaptive' : 'standard',
					'questions_per_attempt' => absint( $quiz['random_question_count'] ?? 0 ),
					'pass_percentage'       => max( 1, min( 100, absint( $quiz['passing_percentage'] ?? 50 ) ?: 50 ) ),
				),
				'random_pool' => array(
					'mode' => 'all',
					'questions_per_attempt' => 0,
				),
			);
			$blockers = array();
			$mappings = array();
			foreach ( (array) ( $quiz['records'] ?? array() ) as $question ) {
				$title = sanitize_text_field( $question['title'] ?? __( 'Untitled Question', 'tutorhelper-lms' ) );
				if ( 'supported' !== ( $question['status'] ?? '' ) ) {
					$blockers[] = sprintf( __( '%1$s is not a supported Question for this Quiz creation step.', 'tutorhelper-lms' ), $title );
					continue;
				}
				$mapping = TutorHelper_LMS_Question_Bank::import_mapping( sanitize_key( $question['id'] ?? '' ) );
				if ( ! is_array( $mapping ) ) {
					$blockers[] = sprintf( __( '%1$s has not yet been created or reused in the Question Bank.', 'tutorhelper-lms' ), $title );
					continue;
				}
				if ( 'published' !== ( $mapping['status'] ?? '' ) ) {
					$blockers[] = sprintf( __( '%1$s is a draft Question. Publish it before creating this Quiz.', 'tutorhelper-lms' ), $title );
					continue;
				}
				$mappings[] = $mapping;
			}
			if ( 'adaptive' === ( $record['practice']['mode'] ?? 'standard' ) && ( $record['practice']['questions_per_attempt'] < 1 || $record['practice']['questions_per_attempt'] > count( $quiz['records'] ?? array() ) ) ) {
				$blockers[] = __( 'The LearnDash random Question count is missing or is outside this Quiz Question pool.', 'tutorhelper-lms' );
			}
			if ( 'adaptive' === ( $record['practice']['mode'] ?? 'standard' ) && ( ! class_exists( 'TutorHelper_LMS_Adaptive_Practice' ) || ! class_exists( 'TutorHelper_LMS_Premium' ) || ! TutorHelper_LMS_Premium::is_available() ) ) {
				$blockers[] = __( 'This LearnDash random Question pool is imported as an Adaptive Practice Quiz. Activate TutorHelper LMS Premium before creating it.', 'tutorhelper-lms' );
			}
			if ( $record['time_limit'] > 0 && ( ! class_exists( 'TutorHelper_LMS_Timed_Quizzes' ) || ! class_exists( 'TutorHelper_LMS_Premium' ) || ! TutorHelper_LMS_Premium::is_available() ) ) {
				$blockers[] = __( 'This Quiz has a time limit. Activate TutorHelper LMS Premium before creating it so the timing is not lost.', 'tutorhelper-lms' );
			}
			$record['question_mappings'] = $mappings;
			$plans[] = array( 'index' => absint( $index ), 'quiz' => $quiz, 'record' => $record, 'blockers' => array_values( array_unique( $blockers ) ) );
		}
		return $plans;
	}

	/**
	 * Return existing Course Topics available for an optional imported Quiz placement.
	 *
	 * @return array
	 */
	private static function import_course_topics() {
		$choices = array();
		$courses = get_posts( array( 'post_type' => 'tutorhelper_course', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		foreach ( $courses as $course ) {
			foreach ( (array) apply_filters( 'tutorhelper_lms_course_topics', array(), $course->ID ) as $topic ) {
				$topic_id = absint( $topic['id'] ?? 0 );
				if ( $topic_id && 'tutorhelper_topic' === get_post_type( $topic_id ) ) {
					$choices[ $topic_id ] = array( 'course_id' => absint( $course->ID ), 'course_title' => get_the_title( $course->ID ), 'topic_title' => sanitize_text_field( $topic['title'] ?? get_the_title( $topic_id ) ) );
				}
			}
		}
		return $choices;
	}

	/**
	 * Render the safe reviewed LearnDash Quiz creation and optional placement step.
	 *
	 * @param array $preview Private preview state.
	 * @return void
	 */
	private static function render_learndash_quiz_execution( $preview ) {
		$plans = self::learndash_quiz_plans( $preview );
		if ( empty( $plans ) ) {
			return;
		}
		$topics = self::import_course_topics();
		$all_ready = true;
		foreach ( $plans as $plan ) {
			$all_ready = $all_ready && empty( $plan['blockers'] );
		}
		?>
		<section class="tutorhelper-lms-import__mapping tutorhelper-lms-import__learndash-execution">
			<h3><?php esc_html_e( 'Create reviewed LearnDash Quizzes', 'tutorhelper-lms' ); ?></h3>
			<p><?php esc_html_e( 'This uses the reviewed, published Question Bank records as immutable Quiz versions. You may optionally place a published Quiz in an existing Course Topic. It never creates or changes Course, student, enrolment, attempt or Media Library data.', 'tutorhelper-lms' ); ?></p>
			<div class="tutorhelper-lms-import__audit-scroll"><table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Source Quiz', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Mapped settings', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Creation readiness', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Optional Course Topic', 'tutorhelper-lms' ); ?></th></tr></thead>
				<tbody><?php foreach ( $plans as $plan ) : ?><?php $quiz = $plan['quiz']; $record = $plan['record']; ?>
					<tr><th scope="row"><?php echo esc_html( $record['title'] ); ?><small><?php echo esc_html( sprintf( _n( '%d reviewed Question', '%d reviewed Questions', absint( $quiz['questions'] ?? 0 ), 'tutorhelper-lms' ), absint( $quiz['questions'] ?? 0 ) ) ); ?></small></th>
					<td>
						<?php
						$settings = array();
						if ( $record['passing_percentage'] ) {
							$settings[] = sprintf( __( '%d%% pass mark', 'tutorhelper-lms' ), $record['passing_percentage'] );
						}
						if ( 'limited' === $record['attempt_policy'] ) {
							$attempt_limit = max( 1, absint( $record['attempt_limit'] ?? 1 ) );
							/* translators: %d: Maximum number of completed Quiz attempts. */
							$settings[] = sprintf( _n( '%d completed attempt', '%d completed attempts', $attempt_limit, 'tutorhelper-lms' ), $attempt_limit );
						}
						if ( ! empty( $record['show_start_screen'] ) ) {
							$settings[] = __( 'start screen', 'tutorhelper-lms' );
						}
						if ( ! empty( $record['result_message_rules'] ) ) {
							$result_rule_count = count( $record['result_message_rules'] );
							/* translators: %d: Number of imported Quiz result-message rules. */
							$settings[] = sprintf( _n( '%d result message rule', '%d result message rules', $result_rule_count, 'tutorhelper-lms' ), $result_rule_count );
						}
						if ( 'adaptive' === ( $record['practice']['mode'] ?? 'standard' ) ) {
							$settings[] = sprintf( __( 'Adaptive practice · %d Questions per attempt', 'tutorhelper-lms' ), $record['practice']['questions_per_attempt'] );
						}
						if ( $record['time_limit'] ) {
							$settings[] = sprintf( __( '%d-minute timer', 'tutorhelper-lms' ), (int) ceil( $record['time_limit'] / MINUTE_IN_SECONDS ) );
						}
						echo esc_html( $settings ? implode( ' · ', $settings ) : __( 'Default TutorHelper Quiz settings', 'tutorhelper-lms' ) );
						?>
					</td>
					<td><?php if ( empty( $plan['blockers'] ) ) : ?><span class="tutorhelper-lms-import__creation-state is-ready"><?php esc_html_e( 'Ready to create', 'tutorhelper-lms' ); ?></span><?php else : ?><span class="tutorhelper-lms-import__creation-state is-blocked"><?php echo esc_html( implode( ' ', $plan['blockers'] ) ); ?></span><?php endif; ?></td>
					<td><?php if ( ! empty( $topics ) ) : ?><select form="tutorhelper-lms-learndash-quiz-creation" name="learndash_quiz_topics[<?php echo esc_attr( $plan['index'] ); ?>]"><option value=""><?php esc_html_e( 'Do not place in a Course yet', 'tutorhelper-lms' ); ?></option><?php foreach ( $topics as $topic_id => $topic ) : ?><option value="<?php echo esc_attr( $topic_id ); ?>"><?php echo esc_html( $topic['course_title'] . ' — ' . $topic['topic_title'] ); ?></option><?php endforeach; ?></select><?php else : ?><span class="description"><?php esc_html_e( 'Create a Course and Topic first if you want to place this Quiz now.', 'tutorhelper-lms' ); ?></span><?php endif; ?></td></tr>
				<?php endforeach; ?></tbody>
			</table></div>
			<?php if ( $all_ready ) : ?><form id="tutorhelper-lms-learndash-quiz-creation" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-import__creation-form"><input type="hidden" name="action" value="<?php echo esc_attr( self::EXECUTE_LEARNDASH_QUIZ_ACTION ); ?>" /><?php wp_nonce_field( self::EXECUTE_LEARNDASH_QUIZ_ACTION ); ?><label class="tutorhelper-lms-import__creation-status"><span><?php esc_html_e( 'Create Quizzes as', 'tutorhelper-lms' ); ?></span><select name="learndash_quiz_status"><option value="draft"><?php esc_html_e( 'Draft', 'tutorhelper-lms' ); ?></option><option value="published"><?php esc_html_e( 'Published', 'tutorhelper-lms' ); ?></option></select></label><p class="description"><?php esc_html_e( 'Draft Quizzes are never placed in a Course. Published Quizzes are placed only where you have selected a Course Topic above.', 'tutorhelper-lms' ); ?></p><label><input type="checkbox" name="confirm_learndash_quiz_create" value="1" required /> <?php esc_html_e( 'I have checked the Quiz settings, reviewed Questions and optional Course Topic placements.', 'tutorhelper-lms' ); ?></label><p><button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Create reviewed LearnDash Quizzes', 'tutorhelper-lms' ); ?></button></p></form><?php else : ?><p class="description"><?php esc_html_e( 'Create or publish every reviewed Question and resolve any timing or source setting shown above before Quiz creation is enabled.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
			<?php if ( ! empty( $preview['learndash_quiz_execution']['results'] ) ) : ?><h4><?php esc_html_e( 'LearnDash Quiz creation results', 'tutorhelper-lms' ); ?></h4><ul><?php foreach ( $preview['learndash_quiz_execution']['results'] as $result ) : ?><li><?php echo esc_html( $result ); ?></li><?php endforeach; ?></ul><?php endif; ?>
		</section>
		<?php
	}

	/**
	 * Create only reviewed Quiz definitions, then optionally place published ones.
	 *
	 * @return void
	 */
	public static function execute_learndash_quizzes() {
		self::require_import_tutor();
		check_admin_referer( self::EXECUTE_LEARNDASH_QUIZ_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) || empty( $_POST['confirm_learndash_quiz_create'] ) ) {
			self::redirect_import( is_array( $preview ) ? 'learndash_quiz_confirmation_needed' : 'expired', absint( $preview['_run_id'] ?? 0 ) );
		}
		$plans = self::learndash_quiz_plans( $preview );
		foreach ( $plans as $plan ) {
			if ( ! empty( $plan['blockers'] ) ) {
				self::redirect_import( 'learndash_quiz_review_needed', absint( $preview['_run_id'] ?? 0 ) );
			}
		}
		$status = sanitize_key( wp_unslash( $_POST['learndash_quiz_status'] ?? 'draft' ) );
		$status = in_array( $status, array( 'draft', 'published' ), true ) ? $status : 'draft';
		$posted_topics = isset( $_POST['learndash_quiz_topics'] ) && is_array( $_POST['learndash_quiz_topics'] ) ? wp_unslash( $_POST['learndash_quiz_topics'] ) : array();
		$topics = self::import_course_topics();
		$results = array();
		$created = 0;
		$reused = 0;
		$failed = 0;
		foreach ( $plans as $plan ) {
			$record = $plan['record'];
			$record['import_status'] = $status;
			$result = TutorHelper_LMS_Quiz_Builder::create_from_import( $record );
			if ( is_wp_error( $result ) || ! absint( $result['quiz_id'] ?? 0 ) ) {
				$message = is_wp_error( $result ) ? $result->get_error_message() : __( 'The Quiz could not be created.', 'tutorhelper-lms' );
				$results[] = sprintf( __( '%1$s — not created: %2$s', 'tutorhelper-lms' ), $record['title'], $message );
				$failed++;
				continue;
			}
			$quiz_id = absint( $result['quiz_id'] );
			$quiz_status = sanitize_key( $result['status'] ?? $status );
			if ( ! empty( $result['created'] ) ) { $created++; } else { $reused++; }
			$message = sprintf( ! empty( $result['created'] ) ? __( '%1$s — created as %2$s Quiz #%3$d.', 'tutorhelper-lms' ) : __( '%1$s — existing %2$s Quiz #%3$d was retained.', 'tutorhelper-lms' ), $record['title'], 'published' === $quiz_status ? __( 'Published', 'tutorhelper-lms' ) : __( 'Draft', 'tutorhelper-lms' ), $quiz_id );
			$topic_id = absint( $posted_topics[ $plan['index'] ] ?? 0 );
			if ( 'published' === $quiz_status && $topic_id && isset( $topics[ $topic_id ] ) ) {
				$placement = TutorHelper_LMS_Course_Builder::attach_imported_quiz( absint( $topics[ $topic_id ]['course_id'] ), $topic_id, $quiz_id );
				if ( is_wp_error( $placement ) ) {
					$message .= ' ' . sprintf( __( 'Not placed: %s', 'tutorhelper-lms' ), $placement->get_error_message() );
					$failed++;
				} else {
					$message .= ' ' . ( ! empty( $placement['created'] ) ? __( 'Placed in the selected Course Topic.', 'tutorhelper-lms' ) : __( 'Already placed in the selected Course Topic.', 'tutorhelper-lms' ) );
				}
			} elseif ( $topic_id && isset( $topics[ $topic_id ] ) && 'draft' === $quiz_status ) {
				$message .= ' ' . __( 'It remains a draft, so it was not placed in the Course Topic.', 'tutorhelper-lms' );
			}
			$results[] = $message;
		}
		$preview['learndash_quiz_execution'] = array( 'created' => $created, 'reused' => $reused, 'failed' => $failed, 'results' => $results );
		self::persist_durable_run( $preview );
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		self::redirect_import( $failed ? 'learndash_quizzes_created_with_errors' : 'learndash_quizzes_created', absint( $preview['_run_id'] ?? 0 ) );
	}

	/**
	 * Render the explicit, CSV-only creation step after its audit.
	 *
	 * @param array $csv Temporary CSV preview.
	 * @return void
	 */
	private static function render_csv_execution( $csv, $media_decisions = array() ) {
		$records = is_array( $csv['records'] ?? null ) ? $csv['records'] : array();
		$blockers = self::csv_record_readiness( $records, $media_decisions );
		$ready = empty( $blockers );
		$execution = is_array( $csv['execution'] ?? null ) ? $csv['execution'] : array();
		$remaining = 0;
		foreach ( $records as $record ) {
			if ( empty( $record['created_question_id'] ) ) {
				$remaining++;
			}
		}
		?>
		<section id="tutorhelper-lms-csv-creation-review" class="tutorhelper-lms-import__mapping tutorhelper-lms-import__csv-execution" data-tutorhelper-lms-csv-creation-region>
			<h3><?php esc_html_e( 'Create reviewed CSV Questions', 'tutorhelper-lms' ); ?></h3>
			<p class="description"><?php esc_html_e( 'CSV image sources use the same private Media Library and external-link review as LearnDash Questions. No image is copied or created during review.', 'tutorhelper-lms' ); ?></p>
			<?php if ( ! $ready ) : ?>
				<p><?php esc_html_e( 'Resolve every required audit field and image source before Questions can be created.', 'tutorhelper-lms' ); ?></p>
				<?php if ( ! empty( $blockers ) ) : ?><ul class="tutorhelper-lms-import__creation-blockers"><?php foreach ( $blockers as $blocker ) : ?><li><?php echo esc_html( $blocker ); ?></li><?php endforeach; ?></ul><?php endif; ?>
			<?php elseif ( ! $remaining ) : ?>
				<p><?php esc_html_e( 'Every Question in this CSV preview has already been created. Re-running this preview will not duplicate them.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<p><?php echo esc_html( sprintf( _n( '%d reviewed CSV row is ready to create as a reusable Question.', '%d reviewed CSV rows are ready to create as reusable Questions.', $remaining, 'tutorhelper-lms' ), $remaining ) ); ?></p>
				<p class="description"><?php esc_html_e( 'This creates Questions only. It does not add them to a Quiz, Course or Topic. Each row keeps its CSV draft or published status.', 'tutorhelper-lms' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::EXECUTE_CSV_ACTION ); ?>" />
					<?php wp_nonce_field( self::EXECUTE_CSV_ACTION ); ?>
					<label><input type="checkbox" name="confirm_csv_question_create" value="1" required /> <?php esc_html_e( 'I have reviewed the audit and image choices and want to create these reusable Questions.', 'tutorhelper-lms' ); ?></label>
					<p><button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Create reviewed CSV Questions', 'tutorhelper-lms' ); ?></button></p>
				</form>
			<?php endif; ?>
			<p class="tutorhelper-lms-import__creation-recheck"><button type="button" class="button tutorhelper-lms-button--grey tutorhelper-lms-import__recheck-csv-creation" data-tutorhelper-lms-csv-creation-nonce="<?php echo esc_attr( wp_create_nonce( self::REFRESH_CSV_CREATION_ACTION ) ); ?>" data-tutorhelper-lms-pending-label="<?php esc_attr_e( 'Rechecking…', 'tutorhelper-lms' ); ?>"><?php esc_html_e( 'Recheck question status', 'tutorhelper-lms' ); ?></button><span class="description"><?php esc_html_e( 'Use this after correcting required fields or image sources.', 'tutorhelper-lms' ); ?></span></p>
			<?php if ( ! empty( $execution['results'] ) ) : ?>
				<h4><?php esc_html_e( 'CSV creation results', 'tutorhelper-lms' ); ?></h4>
				<ul><?php foreach ( $execution['results'] as $result ) : ?><li><?php echo esc_html( $result ); ?></li><?php endforeach; ?></ul>
			<?php endif; ?>
		</section>
		<?php
	}
	/**
	 * Ensure every required audit field passes before an execution request.
	 *
	 * @param array $records Temporary CSV Question records.
	 * @return bool
	 */
	private static function csv_records_ready( $records, $media_decisions = array() ) {
		return empty( self::csv_record_readiness( $records, $media_decisions ) );
	}

	/**
	 * Return the current creation blockers for a reviewed CSV preview.
	 *
	 * This reuses the LearnDash image-resolution gate, while preserving each
	 * CSV row's requested draft or published status.
	 *
	 * @param array $records CSV preview records.
	 * @param array $media_decisions Tutor image decisions.
	 * @return string[]
	 */
	private static function csv_record_readiness( $records, $media_decisions = array() ) {
		if ( empty( $records ) ) {
			return array( __( 'No CSV Question rows are available for creation.', 'tutorhelper-lms' ) );
		}
		$blockers = array();
		foreach ( $records as $record ) {
			$title = (string) ( $record['title'] ?? __( 'Untitled Question', 'tutorhelper-lms' ) );
			$status = self::question_audit_status( $record );
			foreach ( self::question_audit_definition( sanitize_key( $record['type'] ?? '' ) ) as $field => $label ) {
				if ( empty( $status[ $field ] ) ) {
					$blockers[] = sprintf( __( '%1$s — review %2$s.', 'tutorhelper-lms' ), $title, $label );
					continue 2;
				}
			}
			$prepared = self::prepare_record_for_question_creation( $record, $media_decisions, false );
			if ( is_wp_error( $prepared ) ) {
				$blockers[] = sprintf( __( '%1$s — %2$s', 'tutorhelper-lms' ), $title, $prepared->get_error_message() );
				continue;
			}
			$inspection = TutorHelper_LMS_Question_Bank::inspect_import_record( $prepared );
			if ( is_wp_error( $inspection ) ) {
				$blockers[] = sprintf( __( '%1$s — %2$s', 'tutorhelper-lms' ), $title, $inspection->get_error_message() );
			}
		}
		return array_values( array_unique( $blockers ) );
	}
	/**
	 * Render a tick or a safe clickable fix control.
	 *
	 * @param bool   $passed Whether the field is ready.
	 * @param array  $record Editable temporary record.
	 * @param string $field Field identifier.
	 * @param string $label Human readable field label.
	 * @return void
	 */
	private static function render_audit_indicator( $passed, $record, $field, $label, $optional = false ) {
		$attributes = ' type="button" aria-haspopup="dialog" data-tutorhelper-lms-import-record="' . esc_attr( wp_json_encode( $record ) ) . '" data-tutorhelper-lms-import-field="' . esc_attr( $field ) . '" data-tutorhelper-lms-import-field-label="' . esc_attr( $label ) . '"';
		if ( $passed ) {
			echo '<button' . $attributes . ' class="tutorhelper-lms-import__audit-fix is-present"><span class="dashicons dashicons-yes-alt tutorhelper-lms-import__audit-pass" aria-hidden="true"></span><span class="dashicons dashicons-edit" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html( sprintf( __( 'View or edit %s', 'tutorhelper-lms' ), $label ) ) . '</span></button>';
			return;
		}
		if ( $optional ) {
			echo '<button' . $attributes . ' class="tutorhelper-lms-import__audit-fix is-optional"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html( sprintf( __( 'Add %s', 'tutorhelper-lms' ), $label ) ) . '</span></button>';
			return;
		}
		echo '<button' . $attributes . ' class="tutorhelper-lms-import__audit-fix is-failing"><span class="dashicons dashicons-dismiss" aria-hidden="true"></span><span class="tutorhelper-lms-import__audit-fix-label">' . esc_html__( 'Fix', 'tutorhelper-lms' ) . '</span><span class="screen-reader-text"> ' . esc_html( sprintf( __( '%s field needs review', 'tutorhelper-lms' ), $label ) ) . '</span></button>';
	}

	/**
	 * Render one reusable dialog. JavaScript builds its field controls on demand.
	 *
	 * @return void
	 */
	private static function render_audit_dialog() {
		?>
		<dialog class="tutorhelper-lms-import__audit-dialog" data-tutorhelper-lms-import-dialog>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_SANITISATION_ACTION ); ?>" />
				<?php wp_nonce_field( self::SAVE_SANITISATION_ACTION ); ?>
				<input type="hidden" name="audit_kind" value="" />
				<input type="hidden" name="audit_id" value="" />
				<input type="hidden" name="audit_field" value="" />
				<div data-tutorhelper-lms-import-dialog-body></div>
				<p class="tutorhelper-lms-import__dialog-actions"><button type="button" class="button tutorhelper-lms-button--grey" data-tutorhelper-lms-import-close><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></button><button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Save preview correction', 'tutorhelper-lms' ); ?></button></p>
			</form>
		</dialog>
		<?php
	}

	/**
	 * Render temporary Course and Lesson mapping choices.
	 *
	 * These choices prepare the later execution plan; they do not create or
	 * modify Subjects, Grade Systems, Topics, Courses or Lessons.
	 *
	 * @param array $preview Current temporary preview.
	 * @return void
	 */
	private static function render_mapping_worksheet( $preview ) {
		$mapping = is_array( $preview['mappings'] ?? null ) ? $preview['mappings'] : array();
		$subjects = get_terms( array( 'taxonomy' => 'tutorhelper_lms_subject', 'hide_empty' => false ) );
		$grade_systems = get_posts( array( 'post_type' => 'th_lms_grade_system', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$existing_topics = get_posts( array( 'post_type' => 'tutorhelper_topic', 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$source_topics = is_array( $preview['course']['topics'] ?? null ) ? $preview['course']['topics'] : array();
		?>
		<section class="tutorhelper-lms-import__mapping">
			<h3><?php esc_html_e( 'Choose import mappings', 'tutorhelper-lms' ); ?></h3>
			<p><?php esc_html_e( 'These choices are saved only with this temporary preview. They do not create or alter any learning content until you approve the later import step.', 'tutorhelper-lms' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_MAPPING_ACTION ); ?>" />
				<?php wp_nonce_field( self::SAVE_MAPPING_ACTION ); ?>
				<div class="tutorhelper-lms-import__mapping-card">
					<h4><?php esc_html_e( 'Course mapping', 'tutorhelper-lms' ); ?></h4>
					<?php if ( ! empty( $preview['course']['courses'] ) ) : ?><p><strong><?php esc_html_e( 'Imported Course:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( implode( ', ', wp_list_pluck( $preview['course']['courses'], 'title' ) ) ); ?></p><?php endif; ?>
					<div class="tutorhelper-lms-import__mapping-fields">
						<label><?php esc_html_e( 'TutorHelper Subject', 'tutorhelper-lms' ); ?>
							<select name="course_subject_id"><option value=""><?php esc_html_e( 'Choose a Subject…', 'tutorhelper-lms' ); ?></option><?php foreach ( is_array( $subjects ) ? $subjects : array() as $subject ) : ?><option value="<?php echo esc_attr( $subject->term_id ); ?>" <?php selected( absint( $mapping['course_subject_id'] ?? 0 ), $subject->term_id ); ?>><?php echo esc_html( $subject->name ); ?></option><?php endforeach; ?></select>
						</label>
						<label><?php esc_html_e( 'Grade system', 'tutorhelper-lms' ); ?>
							<select name="course_grade_system_id"><option value=""><?php esc_html_e( 'Choose a grade system…', 'tutorhelper-lms' ); ?></option><?php foreach ( $grade_systems as $system ) : ?><option value="<?php echo esc_attr( $system->ID ); ?>" <?php selected( absint( $mapping['course_grade_system_id'] ?? 0 ), $system->ID ); ?>><?php echo esc_html( $system->post_title ); ?></option><?php endforeach; ?></select>
						</label>
					</div>
					<?php if ( empty( $subjects ) || empty( $grade_systems ) ) : ?><p class="description"><?php esc_html_e( 'If a dropdown is empty, you can create that reusable Subject or Grade System in Learning Hub before running the final import.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
				</div>
				<div class="tutorhelper-lms-import__mapping-card">
					<h4><?php esc_html_e( 'Lesson topic mapping', 'tutorhelper-lms' ); ?></h4>
					<p class="description"><?php esc_html_e( 'For each Lesson, choose whether it should use one existing TutorHelper Topic while you organise it later, use a Topic from this LearnDash export, or create a new Topic when the final import runs.', 'tutorhelper-lms' ); ?></p>
					<?php foreach ( (array) ( $preview['course']['lessons'] ?? array() ) as $index => $lesson ) : ?>
						<?php $lesson_title = is_array( $lesson ) ? (string) ( $lesson['title'] ?? '' ) : (string) $lesson; ?>
						<?php $lesson_mapping = is_array( $mapping['lessons'][ $index ] ?? null ) ? $mapping['lessons'][ $index ] : array(); ?>
						<div class="tutorhelper-lms-import__lesson-map">
							<h5><?php echo esc_html( $lesson_title ); ?></h5>
							<div class="tutorhelper-lms-import__mapping-fields">
								<label><?php esc_html_e( 'Plan', 'tutorhelper-lms' ); ?>
									<select name="lesson_mappings[<?php echo esc_attr( $index ); ?>][mode]">
										<option value="course_topic" <?php selected( $lesson_mapping['mode'] ?? 'course_topic', 'course_topic' ); ?>><?php esc_html_e( 'Use one existing TutorHelper Topic', 'tutorhelper-lms' ); ?></option>
										<option value="source_topic" <?php selected( $lesson_mapping['mode'] ?? '', 'source_topic' ); ?> <?php disabled( empty( $source_topics ) ); ?>><?php esc_html_e( 'Use an imported LearnDash Topic', 'tutorhelper-lms' ); ?></option>
										<option value="new_topic" <?php selected( $lesson_mapping['mode'] ?? '', 'new_topic' ); ?>><?php esc_html_e( 'Create a new Topic for this Lesson', 'tutorhelper-lms' ); ?></option>
									</select>
								</label>
								<label><?php esc_html_e( 'Existing TutorHelper Topic', 'tutorhelper-lms' ); ?>
									<select name="lesson_mappings[<?php echo esc_attr( $index ); ?>][topic_id]"><option value=""><?php esc_html_e( 'Choose a Topic…', 'tutorhelper-lms' ); ?></option><?php foreach ( $existing_topics as $topic ) : ?><option value="<?php echo esc_attr( $topic->ID ); ?>" <?php selected( absint( $lesson_mapping['topic_id'] ?? 0 ), $topic->ID ); ?>><?php echo esc_html( $topic->post_title ); ?></option><?php endforeach; ?></select>
								</label>
								<label><?php esc_html_e( 'Imported LearnDash Topic', 'tutorhelper-lms' ); ?>
									<select name="lesson_mappings[<?php echo esc_attr( $index ); ?>][source_topic]"><option value=""><?php echo empty( $source_topics ) ? esc_html__( 'No Topics in this export', 'tutorhelper-lms' ) : esc_html__( 'Choose an imported Topic…', 'tutorhelper-lms' ); ?></option><?php foreach ( $source_topics as $source_topic ) : ?><option value="<?php echo esc_attr( $source_topic ); ?>" <?php selected( $lesson_mapping['source_topic'] ?? '', $source_topic ); ?>><?php echo esc_html( $source_topic ); ?></option><?php endforeach; ?></select>
								</label>
								<label><?php esc_html_e( 'New Topic name', 'tutorhelper-lms' ); ?><input type="text" name="lesson_mappings[<?php echo esc_attr( $index ); ?>][new_topic_name]" value="<?php echo esc_attr( $lesson_mapping['new_topic_name'] ?? '' ); ?>" placeholder="<?php echo esc_attr( $lesson_title ); ?>" /></label>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
				<button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Save preview mappings', 'tutorhelper-lms' ); ?></button>
			</form>
		</section>
		<?php
	}

	/**
	 * Create the reviewed Question CSV rows as reusable Question Bank records.
	 *
	 * This endpoint deliberately ignores Course and Quiz source data. It only
	 * executes the CSV records currently held in the signed-in tutor's preview.
	 *
	 * @return void
	 */
	public static function execute_csv_questions() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to create imported Questions.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::EXECUTE_CSV_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) ) {
			wp_safe_redirect( self::import_url( 'expired' ) );
			exit;
		}
		$records = is_array( $preview['csv_questions']['records'] ?? null ) ? $preview['csv_questions']['records'] : array();
		if ( empty( $records ) ) {
			wp_safe_redirect( self::import_url( 'expired' ) );
			exit;
		}
		if ( empty( $_POST['confirm_csv_question_create'] ) ) {
			wp_safe_redirect( self::import_url( 'csv_confirmation_needed' ) );
			exit;
		}
		$media_decisions = (array) ( $preview['media_decisions'] ?? array() );
		if ( ! empty( $preview['errors'] ) || ! self::csv_records_ready( $records, $media_decisions ) ) {
			wp_safe_redirect( self::import_url( 'csv_review_needed' ) );
			exit;
		}
		$results = array();
		$created = 0;
		$existing = 0;
		$failed = 0;
		foreach ( $records as $index => $record ) {
			$title = (string) ( $record['title'] ?? __( 'Untitled Question', 'tutorhelper-lms' ) );
			if ( ! empty( $record['created_question_id'] ) ) {
				$results[] = sprintf( __( '%1$s — already created as Question #%2$d.', 'tutorhelper-lms' ), $title, absint( $record['created_question_id'] ) );
				$existing++;
				continue;
			}
			$prepared = self::prepare_record_for_question_creation( $record, $media_decisions, false );
			$result = is_wp_error( $prepared ) ? $prepared : TutorHelper_LMS_Question_Bank::create_from_import( $prepared );
			if ( is_wp_error( $result ) ) {
				$results[] = sprintf( __( '%1$s — could not be created: %2$s', 'tutorhelper-lms' ), $title, $result->get_error_message() );
				$preview['csv_questions']['records'][ $index ]['execution_error'] = $result->get_error_message();
				$failed++;
				continue;
			}
			$question_id = absint( $result['question_id'] ?? 0 );
			if ( ! $question_id ) {
				$results[] = sprintf( __( '%s — could not be created.', 'tutorhelper-lms' ), $title );
				$failed++;
				continue;
			}
			$preview['csv_questions']['records'][ $index ]['created_question_id'] = $question_id;
			unset( $preview['csv_questions']['records'][ $index ]['execution_error'] );
			if ( ! empty( $result['created'] ) ) {
				$results[] = sprintf( __( '%1$s — created as Question #%2$d.', 'tutorhelper-lms' ), $title, $question_id );
				$created++;
			} else {
				$results[] = sprintf( __( '%1$s — already created as Question #%2$d.', 'tutorhelper-lms' ), $title, $question_id );
				$existing++;
			}
		}
		$preview['csv_questions']['execution'] = array(
			'created'  => $created,
			'existing' => $existing,
			'failed'   => $failed,
			'results'  => $results,
		);
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		wp_safe_redirect( self::import_url( $failed ? 'csv_created_with_errors' : 'csv_created' ) );
		exit;
	}

	/**
	 * Store tutor mapping choices only in the current short-lived preview.
	 *
	 * @return void
	 */
	public static function save_mappings() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update import mappings.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::SAVE_MAPPING_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) || empty( $preview['course'] ) ) {
			wp_safe_redirect( self::import_url( 'expired' ) );
			exit;
		}
		$subject_id = isset( $_POST['course_subject_id'] ) ? absint( wp_unslash( $_POST['course_subject_id'] ) ) : 0;
		$grade_system_id = isset( $_POST['course_grade_system_id'] ) ? absint( wp_unslash( $_POST['course_grade_system_id'] ) ) : 0;
		$mappings = array(
			'course_subject_id' => self::valid_subject_id( $subject_id ),
			'course_grade_system_id' => self::valid_grade_system_id( $grade_system_id ),
			'lessons' => array(),
		);
		$posted_lessons = isset( $_POST['lesson_mappings'] ) && is_array( $_POST['lesson_mappings'] ) ? wp_unslash( $_POST['lesson_mappings'] ) : array();
		$source_topics = array_values( (array) ( $preview['course']['topics'] ?? array() ) );
		$lessons = array_values( (array) ( $preview['course']['lessons'] ?? array() ) );
		foreach ( $lessons as $index => $unused_lesson_title ) {
			$row = is_array( $posted_lessons[ $index ] ?? null ) ? $posted_lessons[ $index ] : array();
			$mode = sanitize_key( $row['mode'] ?? 'course_topic' );
			if ( ! in_array( $mode, array( 'course_topic', 'source_topic', 'new_topic' ), true ) ) {
				$mode = 'course_topic';
			}
			$mappings['lessons'][ $index ] = self::sanitise_lesson_mapping( $row, $source_topics );
		}
		$preview['mappings'] = $mappings;
		self::persist_durable_run( $preview );
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		wp_safe_redirect( self::import_url( 'mappings_saved' ) );
		exit;
	}

	/**
	 * Save a correction to the short-lived import preview only.
	 *
	 * @return void
	 */
	public static function save_sanitisation() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to correct import data.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::SAVE_SANITISATION_ACTION );
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) ) {
			wp_safe_redirect( self::import_url( 'expired' ) );
			exit;
		}
		$kind = isset( $_POST['audit_kind'] ) ? sanitize_key( wp_unslash( $_POST['audit_kind'] ) ) : '';
		$id = isset( $_POST['audit_id'] ) ? sanitize_text_field( wp_unslash( $_POST['audit_id'] ) ) : '';
		$field = isset( $_POST['audit_field'] ) ? sanitize_key( wp_unslash( $_POST['audit_field'] ) ) : '';
		if ( 'course' === $kind && isset( $preview['course']['courses'][ absint( $id ) ] ) ) {
			if ( 'title' === $field ) {
				$preview['course']['courses'][ absint( $id ) ]['title'] = isset( $_POST['audit_title'] ) ? sanitize_text_field( wp_unslash( $_POST['audit_title'] ) ) : '';
			} elseif ( 'subject' === $field ) {
				$preview['mappings']['course_subject_id'] = self::valid_subject_id( $_POST['course_subject_id'] ?? 0 );
			} elseif ( 'grade' === $field ) {
				$preview['mappings']['course_grade_system_id'] = self::valid_grade_system_id( $_POST['course_grade_system_id'] ?? 0 );
			}
		} elseif ( 'lesson' === $kind && isset( $preview['course']['lessons'][ absint( $id ) ] ) ) {
			$index = absint( $id );
			if ( 'title' === $field && is_array( $preview['course']['lessons'][ $index ] ) ) {
				$preview['course']['lessons'][ $index ]['title'] = isset( $_POST['audit_title'] ) ? sanitize_text_field( wp_unslash( $_POST['audit_title'] ) ) : '';
			} elseif ( 'topic' === $field ) {
				$preview['mappings']['lessons'][ $index ] = self::sanitise_lesson_mapping( array(
					'mode' => $_POST['lesson_mode'] ?? '',
					'topic_id' => $_POST['lesson_topic_id'] ?? 0,
					'source_topic' => $_POST['lesson_source_topic'] ?? '',
					'new_topic_name' => $_POST['lesson_new_topic_name'] ?? '',
				), $preview['course']['topics'] ?? array() );
			}
		} elseif ( 'question' === $kind ) {
			$records = array();
			foreach ( $preview['quizzes'] as &$quiz ) {
				$records[] =& $quiz['records'];
			}
			if ( ! empty( $preview['csv_questions']['records'] ) && is_array( $preview['csv_questions']['records'] ) ) {
				$records[] =& $preview['csv_questions']['records'];
			}
			foreach ( $records as &$record_group ) {
				foreach ( $record_group as &$record ) {
					if ( $id !== ( $record['id'] ?? '' ) ) {
						continue;
					}
					if ( 'title' === $field ) {
						$record['title'] = isset( $_POST['audit_title'] ) ? sanitize_text_field( wp_unslash( $_POST['audit_title'] ) ) : '';
					} elseif ( 'prompt' === $field ) {
						$record['prompt'] = isset( $_POST['audit_prompt'] ) ? wp_kses_post( wp_unslash( $_POST['audit_prompt'] ) ) : '';
					} elseif ( 'marks' === $field ) {
						$record['marks'] = isset( $_POST['audit_marks'] ) ? absint( wp_unslash( $_POST['audit_marks'] ) ) : 0;
					} elseif ( 'pattern' === $field && 'cloze' === ( $record['type'] ?? '' ) ) {
						$record = self::sanitise_cloze_preview_correction(
							$record,
							$_POST['audit_cloze_blanks'] ?? array(),
							array(
								'cloze_marking_mode' => isset( $_POST['audit_cloze_marking_mode'] ) ? sanitize_key( wp_unslash( $_POST['audit_cloze_marking_mode'] ) ) : '',
								'cloze_total_marks'  => isset( $_POST['audit_cloze_total_marks'] ) ? absint( wp_unslash( $_POST['audit_cloze_total_marks'] ) ) : 0,
							)
						);
					} elseif ( in_array( $field, array( 'options', 'correct', 'pairs', 'pattern' ), true ) ) {
						$record['answers'] = self::sanitise_answer_lines( $_POST['audit_answers'] ?? '', $_POST['audit_correct'] ?? '', $record['type'] ?? '', $record['answers'] ?? array() );
					} elseif ( in_array( $field, array( 'correct_feedback', 'incorrect_feedback', 'tip' ), true ) ) {
						$record[ $field ] = isset( $_POST['audit_text'] ) ? wp_kses_post( wp_unslash( $_POST['audit_text'] ) ) : '';
					}
					break 2;
				}
			}
			unset( $record, $record_group, $quiz );
		}
		self::persist_durable_run( $preview );
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		wp_safe_redirect( self::import_url( 'sanitised', absint( $preview['_run_id'] ?? 0 ) ) );
		exit;
	}


	/**
	 * Apply an explicit tutor decision to a temporary LearnDash Cloze conversion.
	 *
	 * @param array $record Preview Question record.
	 * @param mixed $posted Posted blank rows.
	 * @return array
	 */
	private static function sanitise_cloze_preview_correction( $record, $posted, $posted_scoring = array() ) {
		$rows = is_array( $posted ) ? wp_unslash( $posted ) : array();
		$answers = array();
		$blanks = array();
		foreach ( array_values( $rows ) as $index => $row ) {
			$accepted = array();
			foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $row['accepted'] ?? '' ) ) as $alternative ) {
				$alternative = trim( sanitize_text_field( html_entity_decode( $alternative, ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' ) ) );
				if ( '' !== $alternative ) {
					$accepted[] = $alternative;
				}
			}
			$accepted = array_values( array_unique( $accepted ) );
			$marks = isset( $row['marks'] ) && is_numeric( $row['marks'] ) && is_finite( (float) $row['marks'] ) ? (float) $row['marks'] : -1;
			if ( empty( $accepted ) || $marks < 0 || $marks !== (float) absint( $marks ) ) {
				continue;
			}
			$number = $index + 1;
			$id = sanitize_key( $row['id'] ?? '' ) ?: 'blank-' . $number;
			$blanks[] = array( 'id' => $id, 'number' => $number, 'accepted' => $accepted, 'marks' => absint( $marks ), 'source_points' => array() );
			$answers[] = array( 'id' => $id, 'text' => $accepted[0], 'accepted' => $accepted, 'marks' => absint( $marks ), 'source_points' => array(), 'correct' => true, 'html' => false, 'match' => '', 'match_html' => false );
		}
		$existing_settings = is_array( $record['settings'] ?? null ) ? $record['settings'] : array();
		$posted_scoring = is_array( $posted_scoring ) ? $posted_scoring : array();
		$per_blank_marks = array_sum( array_map( static function( $blank ) { return absint( $blank['marks'] ); }, $blanks ) );
		$scoring_settings = TutorHelper_LMS_Question_Bank::cloze_scoring_settings(
			array(
				'cloze_marking_mode' => $posted_scoring['cloze_marking_mode'] ?? ( $existing_settings['cloze_marking_mode'] ?? 'per_blank' ),
				'cloze_total_marks'  => $posted_scoring['cloze_total_marks'] ?? ( $existing_settings['cloze_total_marks'] ?? $per_blank_marks ),
			)
		);
		$placeholder_count = preg_match_all( '/\{\{[1-9][0-9]*\}\}/', wp_strip_all_tags( (string) ( $record['prompt'] ?? '' ) ), $matches );
		$prompt_matches = TutorHelper_LMS_Question_Bank::cloze_prompt_matches_blanks( (string) ( $record['prompt'] ?? '' ), $blanks );
		$record['answers'] = $answers;
		$record['settings'] = array_merge( $existing_settings, $scoring_settings );
		$record['marks'] = TutorHelper_LMS_Question_Bank::cloze_marks_total( $blanks, $scoring_settings );
		$record['cloze'] = array_merge(
			is_array( $record['cloze'] ?? null ) ? $record['cloze'] : array(),
			array(
				'blanks' => $blanks,
				'answer_rows' => $answers,
				'marking_mode' => $scoring_settings['cloze_marking_mode'],
				'total_marks' => $record['marks'],
				'mapped_marks' => $record['marks'],
				'status' => $prompt_matches && ! empty( $blanks ) && $record['marks'] > 0 ? 'ready' : 'blocked',
				'warnings' => $prompt_matches && ! empty( $blanks ) && $record['marks'] > 0 ? array() : array( __( 'The TutorHelper placeholders must be sequential and match the reviewed blanks.', 'tutorhelper-lms' ) ),
				'tutor_approved' => true,
			)
		);
		return $record;
	}

	/**
	 * Convert editable modal lines into safe temporary answers.
	 *
	 * @param mixed  $lines Posted answer text.
	 * @param mixed  $correct Posted correct answer numbers.
	 * @param string $type Source Question type.
	 * @return array
	 */
	private static function sanitise_answer_lines( $lines, $correct, $type, $existing_answers = array() ) {
		$rows = preg_split( '/\\r\\n|\\r|\\n/', (string) wp_unslash( $lines ) );
		$correct_indexes = array_map( 'absint', preg_split( '/\\s*,\\s*/', sanitize_text_field( wp_unslash( $correct ) ) ) );
		$answers = array();
		foreach ( is_array( $rows ) ? $rows : array() as $index => $row ) {
			$row = trim( wp_kses_post( $row ) );
			if ( '' === $row ) {
				continue;
			}
			$match = '';
			if ( in_array( $type, array( 'matrix_sort_answer', 'matrix_sort' ), true ) && false !== strpos( $row, '=>' ) ) {
				list( $row, $match ) = array_map( 'trim', explode( '=>', $row, 2 ) );
			}
			$existing = is_array( $existing_answers[ $index ] ?? null ) ? $existing_answers[ $index ] : array();
			$answers[] = array(
				'id'       => sanitize_key( $existing['id'] ?? '' ) ?: 'edited-answer-' . substr( sha1( $type . '|' . $index . '|' . $row . '|' . $match ), 0, 16 ),
				'text'     => $row,
				'html'     => false !== stripos( $row, '<' ),
				'match'    => wp_kses_post( $match ),
				'match_html' => false !== stripos( $match, '<' ),
				'correct'  => in_array( $index + 1, $correct_indexes, true ),
			);
		}
		return $answers;
	}

	/**
	 * Validate a Subject selection from a temporary preview form.
	 *
	 * @param mixed $subject_id Subject term ID.
	 * @return int
	 */
	private static function valid_subject_id( $subject_id ) {
		$subject_id = absint( wp_unslash( $subject_id ) );
		return term_exists( $subject_id, 'tutorhelper_lms_subject' ) ? $subject_id : 0;
	}

	/**
	 * Validate a Grade System selection from a temporary preview form.
	 *
	 * @param mixed $grade_system_id Grade system post ID.
	 * @return int
	 */
	private static function valid_grade_system_id( $grade_system_id ) {
		$grade_system_id = absint( wp_unslash( $grade_system_id ) );
		return 'th_lms_grade_system' === get_post_type( $grade_system_id ) ? $grade_system_id : 0;
	}

	/**
	 * Validate one temporary Lesson mapping row.
	 *
	 * @param array $row Posted mapping data.
	 * @param array $source_topics Imported Topic titles.
	 * @return array
	 */
	private static function sanitise_lesson_mapping( $row, $source_topics ) {
		$mode = sanitize_key( $row['mode'] ?? 'course_topic' );
		if ( ! in_array( $mode, array( 'course_topic', 'source_topic', 'new_topic' ), true ) ) {
			$mode = 'course_topic';
		}
		$topic_id = absint( $row['topic_id'] ?? 0 );
		$source_topic = sanitize_text_field( $row['source_topic'] ?? '' );
		return array(
			'mode' => $mode,
			'topic_id' => 'tutorhelper_topic' === get_post_type( $topic_id ) ? $topic_id : 0,
			'source_topic' => in_array( $source_topic, array_values( (array) $source_topics ), true ) ? $source_topic : '',
			'new_topic_name' => sanitize_text_field( $row['new_topic_name'] ?? '' ),
		);
	}


	/**
	 * Save the current reviewed preview as a durable tutor-owned IM0 run.
	 *
	 * @return void
	 */
	public static function save_import_run() {
		self::require_import_tutor();
		check_admin_referer( self::SAVE_RUN_ACTION );
		if ( empty( $_POST['confirm_import_run_save'] ) ) {
			self::redirect_import( 'run_confirmation_needed' );
		}
		$preview = get_transient( self::preview_key() );
		if ( ! is_array( $preview ) ) {
			self::redirect_import( 'expired' );
		}
		$result = TutorHelper_LMS_Import_Runs::create_from_preview( get_current_user_id(), $preview );
		if ( is_wp_error( $result ) ) {
			self::redirect_import( 'run_save_failed' );
		}
		$run = $result['run'];
		$preview['_run_id'] = absint( $run['id'] );
		TutorHelper_LMS_Import_Runs::save_snapshot( $run['id'], get_current_user_id(), $preview );
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		self::redirect_import( ! empty( $result['created'] ) ? 'run_saved' : 'run_already_saved', $run['id'] );
	}

	/**
	 * Restore a durable run into the familiar review UI.
	 *
	 * @return void
	 */
	public static function resume_import_run() {
		self::require_import_tutor();
		$run_id = isset( $_POST['import_run_id'] ) ? absint( wp_unslash( $_POST['import_run_id'] ) ) : 0;
		check_admin_referer( self::RESUME_RUN_ACTION . '_' . $run_id );
		$run = TutorHelper_LMS_Import_Runs::resume( $run_id, get_current_user_id() );
		if ( ! $run ) {
			self::redirect_import( 'run_not_found' );
		}
		$preview = json_decode( (string) $run['snapshot_json'], true );
		if ( ! is_array( $preview ) ) {
			self::redirect_import( 'run_restore_failed', $run_id );
		}
		$preview['_run_id'] = $run_id;
		set_transient( self::preview_key(), $preview, self::PREVIEW_TTL );
		self::redirect_import( 'run_resumed', $run_id );
	}

	/**
	 * Prepare the next bounded, no-write source manifest batch.
	 *
	 * @return void
	 */
	public static function prepare_import_run_batch() {
		self::require_import_tutor();
		$run_id = isset( $_POST['import_run_id'] ) ? absint( wp_unslash( $_POST['import_run_id'] ) ) : 0;
		check_admin_referer( self::PREPARE_RUN_ACTION . '_' . $run_id );
		$result = TutorHelper_LMS_Import_Runs::prepare_next_batch( $run_id, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			self::redirect_import( 'run_prepare_failed', $run_id );
		}
		self::redirect_import( ! empty( $result['complete'] ) ? 'run_prepared' : 'run_batch_prepared', $run_id );
	}

	/**
	 * Pause a durable manifest preparation run at its last completed item.
	 *
	 * @return void
	 */
	public static function pause_import_run() {
		self::require_import_tutor();
		$run_id = isset( $_POST['import_run_id'] ) ? absint( wp_unslash( $_POST['import_run_id'] ) ) : 0;
		check_admin_referer( self::PAUSE_RUN_ACTION . '_' . $run_id );
		$run = TutorHelper_LMS_Import_Runs::pause( $run_id, get_current_user_id() );
		self::redirect_import( $run ? 'run_paused' : 'run_not_found', $run_id );
	}

	/**
	 * Render the tutor's recent, private import runs and their bounded actions.
	 *
	 * @return void
	 */
	private static function render_saved_runs() {
		$runs = TutorHelper_LMS_Import_Runs::get_runs_for_tutor( get_current_user_id() );
		if ( empty( $runs ) ) {
			return;
		}
		?>
		<section class="tutorhelper-lms-import__saved-runs">
			<h3><?php esc_html_e( 'Saved import runs', 'tutorhelper-lms' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Saved runs retain your reviewed source data and a per-record manifest. Preparing a run does not create or change LMS content.', 'tutorhelper-lms' ); ?></p>
			<table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Run', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Progress', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Updated', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Actions', 'tutorhelper-lms' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $runs as $run ) : ?>
					<tr>
						<td>#<?php echo esc_html( (string) $run['id'] ); ?></td>
						<td><?php echo esc_html( ucwords( str_replace( '_', ' ', $run['status'] ) ) ); ?></td>
						<td><?php echo esc_html( sprintf( __( '%1$d of %2$d records prepared', 'tutorhelper-lms' ), absint( $run['processed_items'] ), absint( $run['total_items'] ) ) ); ?></td>
						<td><?php echo esc_html( get_date_from_gmt( $run['updated_at'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ); ?></td>
						<td><?php self::render_run_buttons( $run ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php self::render_run_result_log(); ?>
		</section>
		<?php
	}

	/**
	 * Show a bounded per-record manifest log for the selected or newest run.
	 *
	 * @return void
	 */
	private static function render_run_result_log() {
		$requested = isset( $_GET['import_run'] ) && ! is_array( $_GET['import_run'] ) ? absint( wp_unslash( $_GET['import_run'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only run-log selection.
		$runs = TutorHelper_LMS_Import_Runs::get_runs_for_tutor( get_current_user_id(), 1 );
		$run_id = $requested ? $requested : absint( $runs[0]['id'] ?? 0 );
		$results = $run_id ? TutorHelper_LMS_Import_Runs::get_item_results( $run_id, get_current_user_id(), 20 ) : array();
		if ( ! $run_id || empty( $results ) ) {
			return;
		}
		?>
		<div class="tutorhelper-lms-import__run-log">
			<h4><?php echo esc_html( sprintf( __( 'Run #%d manifest results', 'tutorhelper-lms' ), $run_id ) ); ?></h4>
			<p class="description"><?php esc_html_e( 'Showing the first 20 prepared records. These are review records only; target IDs remain empty until a later confirmed creation stage.', 'tutorhelper-lms' ); ?></p>
			<table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Source record', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th><th><?php esc_html_e( 'Result', 'tutorhelper-lms' ); ?></th></tr></thead><tbody>
			<?php foreach ( $results as $result ) : ?>
				<tr><td><?php echo esc_html( $result['source_kind'] . ': ' . $result['source_key'] ); ?></td><td><?php echo esc_html( ucwords( str_replace( '_', ' ', $result['status'] ) ) ); ?></td><td><?php echo esc_html( $result['result_message'] ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		</div>
		<?php
	}

	/**
	 * @param array $run Durable run.
	 * @return void
	 */
	private static function render_run_buttons( $run ) {
		$run_id = absint( $run['id'] );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-import__run-action">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::RESUME_RUN_ACTION ); ?>" />
			<input type="hidden" name="import_run_id" value="<?php echo esc_attr( $run_id ); ?>" />
			<?php wp_nonce_field( self::RESUME_RUN_ACTION . '_' . $run_id ); ?>
			<button type="submit" class="button tutorhelper-lms-button--grey"><?php esc_html_e( 'Open review', 'tutorhelper-lms' ); ?></button>
		</form>
		<?php if ( 'preparing' === $run['status'] ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-import__run-action">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::PREPARE_RUN_ACTION ); ?>" />
				<input type="hidden" name="import_run_id" value="<?php echo esc_attr( $run_id ); ?>" />
				<?php wp_nonce_field( self::PREPARE_RUN_ACTION . '_' . $run_id ); ?>
				<button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Prepare next 200', 'tutorhelper-lms' ); ?></button>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-import__run-action">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::PAUSE_RUN_ACTION ); ?>" />
				<input type="hidden" name="import_run_id" value="<?php echo esc_attr( $run_id ); ?>" />
				<?php wp_nonce_field( self::PAUSE_RUN_ACTION . '_' . $run_id ); ?>
				<button type="submit" class="button"><?php esc_html_e( 'Pause', 'tutorhelper-lms' ); ?></button>
			</form>
		<?php endif; ?>
		<?php
	}

	/**
	 * @param array $preview Current transient review.
	 * @return void
	 */
	private static function render_save_run_action( $preview ) {
		$run_id = absint( $preview['_run_id'] ?? 0 );
		if ( $run_id ) {
			$run = TutorHelper_LMS_Import_Runs::get_run( $run_id, get_current_user_id() );
			if ( $run ) {
				echo '<p class="notice notice-info inline"><strong>' . esc_html__( 'Saved import run:', 'tutorhelper-lms' ) . '</strong> ' . esc_html( sprintf( __( 'Run #%d is durable and can be resumed after this page expires.', 'tutorhelper-lms' ), $run_id ) ) . '</p>';
				return;
			}
		}
		?>
		<form class="tutorhelper-lms-import__save-run" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_RUN_ACTION ); ?>" />
			<?php wp_nonce_field( self::SAVE_RUN_ACTION ); ?>
			<label><input type="checkbox" name="confirm_import_run_save" value="1" /> <?php esc_html_e( 'Save this reviewed source data as a private, resumable import run. This still will not create LMS content.', 'tutorhelper-lms' ); ?></label>
			<button type="submit" class="button tutorhelper-lms-button--orange"><?php esc_html_e( 'Save import run', 'tutorhelper-lms' ); ?></button>
		</form>
		<?php
	}

	/**
	 * Keep edits made in the familiar preview view in its durable run too.
	 *
	 * @param array $preview Preview state.
	 * @return void
	 */
	private static function persist_durable_run( $preview ) {
		$run_id = absint( $preview['_run_id'] ?? 0 );
		if ( $run_id ) {
			TutorHelper_LMS_Import_Runs::save_snapshot( $run_id, get_current_user_id(), $preview );
		}
	}

	/**
	 * @return void
	 */
	private static function require_import_tutor() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage import runs.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
	}

	/**
	 * @param string $notice Notice key.
	 * @param int    $run_id Optional run ID.
	 * @return void
	 */
	private static function redirect_import( $notice, $run_id = 0 ) {
		wp_safe_redirect( self::import_url( $notice, $run_id ) );
		exit;
	}

	/**
	 * Build the Import tab URL carrying a compact preview notice.
	 *
	 * @param string $notice Notice identifier.
	 * @return string
	 */
	private static function import_url( $notice = '', $run_id = 0 ) {
		$args = array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => self::SECTION_KEY );
		if ( absint( $run_id ) ) {
			$args['import_run'] = absint( $run_id );
		}
		if ( '' !== $notice ) {
			$args['tutorhelper_lms_import_preview'] = sanitize_key( $notice );
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	private static function render_notices() {
		$notice = isset( $_GET['tutorhelper_lms_import_preview'] ) ? sanitize_key( wp_unslash( $_GET['tutorhelper_lms_import_preview'] ) ) : '';
		if ( 'ready' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your files were checked. Review the preview below; no LMS content has been changed.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'mappings_saved' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your preview mappings were saved. No LMS content has been created or changed.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'sanitised' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your import-preview correction was saved. No LMS content has been created or changed.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'external_image_checked' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'The external source was checked. Choose whether to retain it only if the result confirms an image response.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'external_image_enabled' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'The external image link is selected for this private review. It remains dependent on the source site and no image has been copied.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'external_image_disabled' === $notice ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'The external image link will not be retained by this private review.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'external_image_not_found' === $notice ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'That external image is no longer available in this preview. No LMS content has been changed.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'learndash_creation_confirmation_needed' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Confirm that you want to create the reviewed LearnDash Questions before continuing.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'learndash_created' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'The reviewed LearnDash Questions were created as drafts or mapped to existing Questions. Review the result list below.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'learndash_created_with_errors' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Some LearnDash Questions were not created. Review the result list below and correct the remaining items.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'learndash_quiz_confirmation_needed' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Confirm that you want to create the reviewed LearnDash Quizzes before continuing.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'learndash_quiz_review_needed' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Create and publish every reviewed Question, then resolve every Quiz setting shown in the creation review before continuing.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'learndash_quizzes_created' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'The reviewed LearnDash Quizzes were created. Review the result list below.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'learndash_quizzes_created_with_errors' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Some LearnDash Quizzes were not created or placed. Review the result list below.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'csv_confirmation_needed' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Confirm that you want to create the reviewed Questions before continuing.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'csv_review_needed' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Fix every required CSV audit field before creating Questions.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'csv_created' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your reviewed CSV Questions were created. They are ready in the Question Bank.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'csv_created_with_errors' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Some CSV Questions could not be created. Review the results below before trying again.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'run_confirmation_needed' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Confirm that you want to save the reviewed source data before creating a durable import run.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'run_saved' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Your import run was saved. Prepare it in bounded batches when you are ready; no LMS content has been created.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'run_already_saved' === $notice ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'An identical active import run already exists, so it has been reused instead of duplicated.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'run_resumed' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'The saved import run was restored to this review screen.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'run_batch_prepared' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'A bounded manifest batch was prepared. You can pause safely or prepare the next batch. No LMS content has been created.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'run_prepared' === $notice ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'This import run now has a complete review manifest. It is ready for the later confirmed LearnDash creation stage.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'run_paused' === $notice ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'The import run was paused at its last completed manifest record.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( in_array( $notice, array( 'run_not_found', 'run_restore_failed', 'run_save_failed', 'run_prepare_failed' ), true ) ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'The import run could not be completed. No LMS content has been created.', 'tutorhelper-lms' ) . '</p></div>';
		} elseif ( 'expired' === $notice ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'This preview has expired. Upload the export files again to start a new preview.', 'tutorhelper-lms' ) . '</p></div>';
		}
	}

	/**
	 * Return the current tutor's temporary preview key.
	 *
	 * @return string
	 */
	private static function preview_key() {
		return 'tutorhelper_lms_import_preview_' . get_current_user_id();
	}
}
