<?php
/**
 * Privacy-conscious LMS diagnostics bridge.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends LMS operational failures to the established TutorHelper diagnostics log.
 */
final class TutorHelper_LMS_Diagnostics {

	/**
	 * Log an LMS error without recording learning content, student data or secrets.
	 *
	 * @param string $message Short technical message.
	 * @param array  $context Safe technical context only.
	 * @return void
	 */
	public static function error( $message, $context = array() ) {
		$context = self::safe_context( $context );

		if ( class_exists( 'TutorHelper_Logger' ) ) {
			TutorHelper_Logger::error( $message, $context );
			return;
		}

		/*
		 * Core normally supplies TutorHelper_Logger. This fallback preserves a
		 * minimal trace for an unexpected load-order problem without exposing
		 * submitted content or personal information.
		 */
		error_log(
			'TutorHelper LMS error: '
			. sanitize_text_field( $message )
			. ' '
			. wp_json_encode( $context )
		);
	}

	/**
	 * Log a WordPress error using its code only.
	 *
	 * Error messages and error data can contain server or user information, so
	 * they are deliberately not copied to diagnostics.
	 *
	 * @param string   $message Short technical message.
	 * @param WP_Error $error   WordPress error.
	 * @param array    $context Safe technical context.
	 * @return void
	 */
	public static function wp_error( $message, $error, $context = array() ) {
		if ( is_wp_error( $error ) ) {
			$context['wp_error_code'] = sanitize_key( $error->get_error_code() );
		}

		self::error( $message, $context );
	}

	/**
	 * Whitelist the only LMS diagnostic context fields currently required.
	 *
	 * @param array $context Candidate context.
	 * @return array
	 */
	private static function safe_context( $context ) {
		if ( ! is_array( $context ) ) {
			return array(
				'component' => 'lms',
			);
		}

		$allowed = array(
			'component',
			'operation',
			'entity_id',
			'post_type',
			'tab',
			'wp_error_code',
			'failure_reason',
			'placement_id',
			'course_quiz_version_id',
			'latest_quiz_version_id',
			'course_quiz_version_number',
			'latest_quiz_version_number',
		);
		$safe = array(
			'component' => 'lms',
		);

		foreach ( $allowed as $key ) {
			if ( ! isset( $context[ $key ] ) ) {
				continue;
			}

			if ( in_array( $key, array( 'entity_id', 'placement_id', 'course_quiz_version_id', 'latest_quiz_version_id', 'course_quiz_version_number', 'latest_quiz_version_number' ), true ) ) {
				$safe[ $key ] = absint( $context[ $key ] );
			} else {
				$safe[ $key ] = sanitize_key( $context[ $key ] );
			}
		}

		return $safe;
	}
}
