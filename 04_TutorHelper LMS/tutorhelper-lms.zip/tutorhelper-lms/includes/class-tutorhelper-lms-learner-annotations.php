<?php
/**
 * Private reader text annotations.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Learner_Annotations {

	const SAVE_ACTION = 'tutorhelper_lms_save_annotation';
	const DELETE_ACTION = 'tutorhelper_lms_delete_annotation';

	public static function init() {
		add_action( 'wp_ajax_' . self::SAVE_ACTION, array( __CLASS__, 'ajax_save' ) );
		add_action( 'wp_ajax_' . self::DELETE_ACTION, array( __CLASS__, 'ajax_delete' ) );
	}

	public static function for_page( $student_user_id, $course_id, $topic_id, $lesson_id, $page_key ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, annotation_type, start_offset, end_offset, selected_text, note_content FROM " . TutorHelper_LMS_Free_Database::table( 'learner_annotations' ) . " WHERE student_user_id = %d AND course_id = %d AND topic_id = %d AND lesson_id = %d AND page_key = %s ORDER BY start_offset DESC, id DESC", absint( $student_user_id ), absint( $course_id ), absint( $topic_id ), absint( $lesson_id ), sanitize_key( $page_key ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Retrieves student-owned annotations only within an authorised reader page.
		$annotations = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$annotations[] = array(
				'id' => absint( $row->id ),
				'type' => 'sticky' === $row->annotation_type ? 'sticky' : 'highlight',
				'start' => absint( $row->start_offset ),
				'end' => absint( $row->end_offset ),
				'text' => (string) $row->selected_text,
				'note' => (string) $row->note_content,
			);
		}
		return $annotations;
	}

	public static function render_toolbar() {
		?>
		<div class="tutorhelper-lms-textbook__annotation-tools" role="toolbar" aria-label="<?php esc_attr_e( 'Lesson tools', 'tutorhelper-lms' ); ?>">
			<button type="button" class="tutorhelper-lms-textbook__tool-button" data-tutorhelper-lms-highlight aria-label="<?php esc_attr_e( 'Highlight selected text', 'tutorhelper-lms' ); ?>" title="<?php esc_attr_e( 'Highlight selected text', 'tutorhelper-lms' ); ?>"><span class="tutorhelper-lms-textbook__tool-icon tutorhelper-lms-textbook__tool-icon--highlight" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Highlight selected text', 'tutorhelper-lms' ); ?></span></button>
			<button type="button" class="tutorhelper-lms-textbook__tool-button" data-tutorhelper-lms-sticky aria-label="<?php esc_attr_e( 'Add a sticky note to selected text', 'tutorhelper-lms' ); ?>" title="<?php esc_attr_e( 'Add a sticky note to selected text', 'tutorhelper-lms' ); ?>"><span class="tutorhelper-lms-textbook__tool-icon tutorhelper-lms-textbook__tool-icon--sticky" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Add a sticky note to selected text', 'tutorhelper-lms' ); ?></span></button>
			<button type="button" data-tutorhelper-lms-toggle-notes aria-expanded="true"><?php esc_html_e( 'Hide notes', 'tutorhelper-lms' ); ?></button>
		</div>
		<details class="tutorhelper-lms-textbook__annotation-index" data-tutorhelper-lms-annotation-index>
			<summary><?php esc_html_e( 'My annotations on this page', 'tutorhelper-lms' ); ?></summary>
			<ul data-tutorhelper-lms-annotation-list></ul>
		</details>
		<dialog class="tutorhelper-lms-textbook__sticky-dialog" data-tutorhelper-lms-sticky-dialog>
			<form method="dialog">
				<h4 data-tutorhelper-lms-sticky-title><?php esc_html_e( 'Add sticky note', 'tutorhelper-lms' ); ?></h4>
				<p data-tutorhelper-lms-sticky-selection></p>
				<label for="tutorhelper-lms-sticky-note"><?php esc_html_e( 'Your private sticky note', 'tutorhelper-lms' ); ?></label>
				<textarea id="tutorhelper-lms-sticky-note" data-tutorhelper-lms-sticky-content rows="5" maxlength="2000"></textarea>
				<p class="tutorhelper-lms-textbook__notes-help"><?php esc_html_e( 'Only you can see this note.', 'tutorhelper-lms' ); ?></p>
				<div class="tutorhelper-lms-textbook__sticky-actions">
					<button type="submit" value="cancel"><?php esc_html_e( 'Cancel', 'tutorhelper-lms' ); ?></button>
					<button type="button" data-tutorhelper-lms-sticky-save><?php esc_html_e( 'Save sticky note', 'tutorhelper-lms' ); ?></button>
					<button type="button" data-tutorhelper-lms-annotation-delete hidden><?php esc_html_e( 'Delete', 'tutorhelper-lms' ); ?></button>
				</div>
			</form>
		</dialog>
		<?php
	}

	public static function ajax_save() {
		if ( ! self::verify_nonce( self::SAVE_ACTION ) ) {
			self::log( 'save_annotation', 0, 'invalid_nonce' );
			wp_send_json_error( array( 'message' => __( 'Your annotation could not be saved. Please try again.', 'tutorhelper-lms' ) ), 403 );
		}
		$context = self::authorised_context();
		$id = self::posted_id( 'annotation_id' );
		$type = self::posted_type();
		$start = self::posted_id( 'start_offset' );
		$end = self::posted_id( 'end_offset' );
		$text = self::posted_text( 'selected_text', 2000 );
		$note = self::posted_text( 'note_content', 2000 );
		if ( ! $context ) {
			self::log( 'save_annotation', 0, 'lesson_access_denied' );
			wp_send_json_error( array( 'message' => __( 'Your annotation could not be saved. Please try again.', 'tutorhelper-lms' ) ), 403 );
		}
		global $wpdb;
		if ( $id ) {
			$result = $wpdb->update( TutorHelper_LMS_Free_Database::table( 'learner_annotations' ), array( 'note_content' => $note, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id, 'student_user_id' => get_current_user_id(), 'course_id' => $context['course_id'], 'topic_id' => $context['topic_id'], 'lesson_id' => $context['lesson_id'], 'page_key' => $context['page_key'], 'annotation_type' => 'sticky' ), array( '%s', '%s' ), array( '%d', '%d', '%d', '%d', '%d', '%s', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Updates only the current student's sticky note in its authorised reader context.
			if ( false === $result || 0 === $result ) {
				self::log( 'update_annotation', $context['lesson_id'], 'database_write_failed' );
				wp_send_json_error( array( 'message' => __( 'Your annotation could not be saved. Please try again.', 'tutorhelper-lms' ) ), 403 );
			}
			wp_send_json_success();
		}
		if ( $end <= $start || '' === trim( $text ) ) {
			self::log( 'save_annotation', 0, 'invalid_annotation' );
			wp_send_json_error( array( 'message' => __( 'Your annotation could not be saved. Please try again.', 'tutorhelper-lms' ) ), 403 );
		}
		$result = $wpdb->insert( TutorHelper_LMS_Free_Database::table( 'learner_annotations' ), array( 'student_user_id' => get_current_user_id(), 'course_id' => $context['course_id'], 'topic_id' => $context['topic_id'], 'lesson_id' => $context['lesson_id'], 'page_key' => $context['page_key'], 'annotation_type' => $type, 'start_offset' => $start, 'end_offset' => $end, 'selected_text' => $text, 'note_content' => $note, 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( '%d', '%d', '%d', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Creates a student-owned annotation in an authorised reader context.
		if ( false === $result ) {
			self::log( 'save_annotation', $context['lesson_id'], 'database_write_failed' );
			wp_send_json_error( array( 'message' => __( 'Your annotation could not be saved. Please try again.', 'tutorhelper-lms' ) ), 500 );
		}
		wp_send_json_success();
	}

	public static function ajax_delete() {
		if ( ! self::verify_nonce( self::DELETE_ACTION ) ) {
			self::log( 'delete_annotation', 0, 'invalid_nonce' );
			wp_send_json_error( array(), 403 );
		}
		$context = self::authorised_context();
		$id = self::posted_id( 'annotation_id' );
		global $wpdb;
		$result = $context ? $wpdb->delete( TutorHelper_LMS_Free_Database::table( 'learner_annotations' ), array( 'id' => $id, 'student_user_id' => get_current_user_id(), 'course_id' => $context['course_id'], 'topic_id' => $context['topic_id'], 'lesson_id' => $context['lesson_id'], 'page_key' => $context['page_key'] ), array( '%d', '%d', '%d', '%d', '%d', '%s' ) ) : false; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Deletes only the current student's annotation from the active authorised page.
		if ( false === $result ) {
			self::log( 'delete_annotation', $context['lesson_id'] ?? 0, 'delete_failed' );
			wp_send_json_error( array(), 403 );
		}
		wp_send_json_success();
	}

	private static function authorised_context() {
		if ( ! TutorHelper_LMS_Learner_Access::is_current_student() ) { return array(); }
		$token = self::posted_text( 'reader_token', 32 );
		$context = TutorHelper_LMS_Learner_Access::context_for_current_reader_token( $token );
		$page_key = TutorHelper_LMS_Learner_Access::lesson_page_key( $context['lesson_id'] ?? 0, self::posted_id( 'page_number' ) );
		if ( ! $context || ! $page_key || ! TutorHelper_LMS_Learner_Access::can_view_lesson( get_current_user_id(), $context['course_id'], $context['topic_id'], $context['lesson_id'] ) ) { return array(); }
		$context['page_key'] = $page_key;
		return $context;
	}

	private static function verify_nonce( $action ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- This method validates the submitted action nonce.
		$nonce = isset( $_POST['nonce'] ) && ! is_array( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return (bool) wp_verify_nonce( $nonce, $action );
	}

	private static function posted_id( $key ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called after an action-specific nonce is verified.
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? absint( wp_unslash( $_POST[ $key ] ) ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	private static function posted_text( $key, $max ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called after an action-specific nonce is verified.
		$value = isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return substr( $value, 0, $max );
	}

	private static function posted_type() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called after an action-specific nonce is verified.
		$type = isset( $_POST['annotation_type'] ) && ! is_array( $_POST['annotation_type'] ) ? sanitize_key( wp_unslash( $_POST['annotation_type'] ) ) : 'highlight';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return in_array( $type, array( 'highlight', 'sticky' ), true ) ? $type : 'highlight';
	}

	private static function log( $operation, $lesson_id, $reason ) {
		if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			TutorHelper_LMS_Diagnostics::error( 'Learner annotation operation failed.', array( 'component' => 'lms', 'operation' => $operation, 'entity_id' => $lesson_id, 'failure_reason' => $reason ) );
		}
	}
}
