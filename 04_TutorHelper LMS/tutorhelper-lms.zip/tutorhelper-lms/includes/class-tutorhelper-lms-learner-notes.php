<?php
/**
 * Private student Lesson notes.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Learner_Notes {

	const ACTION = 'tutorhelper_lms_save_lesson_note';
	const MAX_LENGTH = 12000;

	public static function init() {
		add_action( 'wp_ajax_' . self::ACTION, array( __CLASS__, 'ajax_save' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'fallback_save' ) );
	}

	/**
	 * Render one student's private note for the whole Lesson.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @param int    $lesson_id Lesson ID.
	 * @param string $page_key Lesson scope key (currently always lesson).
	 * @param string $reader_token Opaque reader token.
	 * @param string $return_url Safe reader URL.
	 * @return void
	 */
	public static function render_panel( $student_user_id, $course_id, $topic_id, $lesson_id, $page_key, $reader_token, $return_url ) {
		$note = self::note_for( $student_user_id, $course_id, $topic_id, $lesson_id, $page_key );
		?>
		<aside class="tutorhelper-lms-textbook__notes" aria-labelledby="tutorhelper-lms-lesson-notes-title">
			<div class="tutorhelper-lms-textbook__notes-heading">
				<p><?php esc_html_e( 'My notes', 'tutorhelper-lms' ); ?></p>
				<h4 id="tutorhelper-lms-lesson-notes-title"><?php esc_html_e( 'Notes for this lesson', 'tutorhelper-lms' ); ?></h4>
			</div>
			<form class="tutorhelper-lms-textbook__notes-form" data-tutorhelper-lms-note-form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
				<input type="hidden" name="reader_token" value="<?php echo esc_attr( $reader_token ); ?>" />
				<input type="hidden" name="return_url" value="<?php echo esc_url( $return_url ); ?>" />
				<?php wp_nonce_field( self::ACTION, 'nonce' ); ?>
				<label class="screen-reader-text" for="tutorhelper-lms-note-<?php echo esc_attr( md5( $reader_token . $page_key ) ); ?>"><?php esc_html_e( 'Your private notes for this Lesson', 'tutorhelper-lms' ); ?></label>
				<textarea id="tutorhelper-lms-note-<?php echo esc_attr( md5( $reader_token . $page_key ) ); ?>" class="tutorhelper-lms-textbook__notes-source" name="note_content" rows="10" maxlength="<?php echo esc_attr( self::MAX_LENGTH ); ?>" placeholder="<?php esc_attr_e( 'Write your notes here…', 'tutorhelper-lms' ); ?>"><?php echo esc_textarea( wp_strip_all_tags( $note ) ); ?></textarea>
				<div class="tutorhelper-lms-textbook__notes-toolbar" data-tutorhelper-lms-note-toolbar role="toolbar" aria-label="<?php esc_attr_e( 'Note formatting', 'tutorhelper-lms' ); ?>">
					<button type="button" data-note-command="bold" aria-label="<?php esc_attr_e( 'Bold', 'tutorhelper-lms' ); ?>"><strong>B</strong></button>
					<button type="button" data-note-command="italic" aria-label="<?php esc_attr_e( 'Italic', 'tutorhelper-lms' ); ?>"><em>I</em></button>
					<button type="button" data-note-command="insertUnorderedList" aria-label="<?php esc_attr_e( 'Bulleted list', 'tutorhelper-lms' ); ?>">&bull; <?php esc_html_e( 'List', 'tutorhelper-lms' ); ?></button>
				</div>
				<div class="tutorhelper-lms-textbook__notes-editor" data-tutorhelper-lms-note-editor contenteditable="true" role="textbox" aria-multiline="true" aria-label="<?php esc_attr_e( 'Your private notes for this Lesson', 'tutorhelper-lms' ); ?>"><?php echo wp_kses( $note, self::allowed_html() ); ?></div>
				<p class="tutorhelper-lms-textbook__notes-help"><?php esc_html_e( 'Only you can see these notes. Use bold, italic or a simple list if helpful.', 'tutorhelper-lms' ); ?></p>
				<div class="tutorhelper-lms-textbook__notes-actions">
					<button type="submit" class="tutorhelper-lms-textbook__save-note"><?php esc_html_e( 'Save notes', 'tutorhelper-lms' ); ?></button>
					<button type="button" class="tutorhelper-lms-textbook__copy-notes" data-tutorhelper-lms-copy-notes><?php esc_html_e( 'Copy notes', 'tutorhelper-lms' ); ?></button>
					<button type="button" class="tutorhelper-lms-textbook__retry-note" data-tutorhelper-lms-note-retry hidden><?php esc_html_e( 'Retry save', 'tutorhelper-lms' ); ?></button>
					<p class="tutorhelper-lms-textbook__notes-status" data-tutorhelper-lms-note-status role="status" aria-live="polite"></p>
				</div>
			</form>
		</aside>
		<?php
	}

	public static function ajax_save() {
		if ( ! self::valid_nonce() ) {
			self::log_failure( 'save_note', 0, 'invalid_nonce' );
			wp_send_json_error( array( 'message' => __( 'Your notes could not be saved. Please try again.', 'tutorhelper-lms' ) ), 403 );
		}
		$result = self::save_from_request();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => __( 'Your notes could not be saved. Please try again.', 'tutorhelper-lms' ) ), 403 );
		}
		wp_send_json_success( array( 'message' => __( 'Your notes have been saved.', 'tutorhelper-lms' ) ) );
	}

	public static function fallback_save() {
		if ( ! self::valid_nonce() ) {
			self::log_failure( 'save_note', 0, 'invalid_nonce' );
			wp_die( esc_html__( 'Your notes could not be saved. Please return to the Lesson and try again.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$result = self::save_from_request();
		$return_url = self::safe_return_url();
		$status = is_wp_error( $result ) ? 'error' : 'saved';
		wp_safe_redirect( add_query_arg( 'tutorhelper_lms_note_status', $status, $return_url ) );
		exit;
	}

	/**
	 * Retrieve one private page note.
	 *
	 * @return string
	 */
	private static function note_for( $student_user_id, $course_id, $topic_id, $lesson_id, $page_key ) {
		global $wpdb;
		$value = $wpdb->get_var( $wpdb->prepare( "SELECT note_content FROM " . TutorHelper_LMS_Free_Database::table( 'learner_notes' ) . " WHERE student_user_id = %d AND course_id = %d AND topic_id = %d AND lesson_id = %d AND page_key = %s LIMIT 1", absint( $student_user_id ), absint( $course_id ), absint( $topic_id ), absint( $lesson_id ), sanitize_key( $page_key ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Retrieves one student-owned private note in an authorised reader context.
		return is_string( $value ) ? $value : '';
	}

	/**
	 * Save or deliberately clear the current student's page note.
	 *
	 * @return true|WP_Error
	 */
	private static function save_from_request() {
		if ( ! is_user_logged_in() || ! TutorHelper_LMS_Learner_Access::is_current_student() ) {
			self::log_failure( 'save_note', 0, 'student_access_denied' );
			return new WP_Error( 'forbidden' );
		}
		$context = TutorHelper_LMS_Learner_Access::context_for_current_reader_token( self::posted_token() );
		if ( ! $context || ! TutorHelper_LMS_Learner_Access::can_view_lesson( get_current_user_id(), $context['course_id'], $context['topic_id'], $context['lesson_id'] ) ) {
			self::log_failure( 'save_note', 0, 'lesson_access_denied' );
			return new WP_Error( 'forbidden' );
		}
		$content = self::posted_note();
		return self::persist( get_current_user_id(), $context, 'lesson', $content );
	}

	private static function persist( $student_user_id, $context, $page_key, $content ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'learner_notes' );
		$where = array(
			'student_user_id' => absint( $student_user_id ),
			'course_id'       => absint( $context['course_id'] ),
			'topic_id'        => absint( $context['topic_id'] ),
			'lesson_id'       => absint( $context['lesson_id'] ),
			'page_key'        => sanitize_key( $page_key ),
		);
		$now = current_time( 'mysql', true );
		if ( '' === $content ) {
			$result = $wpdb->delete( $table, $where, array( '%d', '%d', '%d', '%d', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Removes only the current student's deliberately cleared private note.
			if ( false === $result ) {
				self::log_failure( 'delete_note', $context['lesson_id'], 'delete_failed' );
				return new WP_Error( 'save_failed' );
			}
			return true;
		}

		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE student_user_id = %d AND course_id = %d AND topic_id = %d AND lesson_id = %d AND page_key = %s LIMIT 1", $where['student_user_id'], $where['course_id'], $where['topic_id'], $where['lesson_id'], $where['page_key'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finds one student-owned private note before an update or insert.
		$result = $existing
			? $wpdb->update( $table, array( 'note_content' => $content, 'updated_at' => $now ), array( 'id' => absint( $existing ), 'student_user_id' => $where['student_user_id'] ), array( '%s', '%s' ), array( '%d', '%d' ) )
			: $wpdb->insert( $table, array_merge( $where, array( 'note_content' => $content, 'created_at' => $now, 'updated_at' => $now ) ), array( '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s' ) );
		if ( false === $result ) {
			self::log_failure( $existing ? 'update_note' : 'create_note', $context['lesson_id'], 'database_write_failed' );
			return new WP_Error( 'save_failed' );
		}
		return true;
	}

	/**
	 * Allow only basic, safe learner-owned note formatting.
	 *
	 * @return array
	 */
	private static function allowed_html() {
		return array(
			'p'      => array(),
			'div'    => array(),
			'br'     => array(),
			'strong' => array(),
			'b'      => array(),
			'em'     => array(),
			'i'      => array(),
			'ul'     => array(),
			'ol'     => array(),
			'li'     => array(),
		);
	}

	private static function valid_nonce() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- This method itself validates the submitted action nonce.
		$nonce = isset( $_POST['nonce'] ) && ! is_array( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return (bool) wp_verify_nonce( $nonce, self::ACTION );
	}

	private static function posted_token() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called after an action-specific nonce is checked.
		$token = isset( $_POST['reader_token'] ) && ! is_array( $_POST['reader_token'] ) ? (string) wp_unslash( $_POST['reader_token'] ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ? $token : '';
	}

	private static function posted_id( $key ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called after an action-specific nonce is checked.
		$value = isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? absint( wp_unslash( $_POST[ $key ] ) ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return $value;
	}

	private static function posted_note() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called after an action-specific nonce is checked.
		$note = isset( $_POST['note_content'] ) && ! is_array( $_POST['note_content'] ) ? wp_kses( wp_unslash( $_POST['note_content'] ), self::allowed_html() ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$plain_text = wp_strip_all_tags( $note );
		if ( self::MAX_LENGTH < strlen( $plain_text ) ) {
			$plain_text = function_exists( 'mb_substr' ) ? mb_substr( $plain_text, 0, self::MAX_LENGTH ) : substr( $plain_text, 0, self::MAX_LENGTH );
			$note = esc_html( $plain_text );
		}
		return trim( $note );
	}

	private static function safe_return_url() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called after an action-specific nonce is checked.
		$url = isset( $_POST['return_url'] ) && ! is_array( $_POST['return_url'] ) ? esc_url_raw( wp_unslash( $_POST['return_url'] ) ) : home_url( '/' );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return wp_validate_redirect( $url, home_url( '/' ) );
	}

	private static function log_failure( $operation, $lesson_id, $reason ) {
		if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			TutorHelper_LMS_Diagnostics::error( 'Learner note operation failed.', array( 'component' => 'lms', 'operation' => sanitize_key( $operation ), 'entity_id' => absint( $lesson_id ), 'failure_reason' => sanitize_key( $reason ) ) );
		}
	}
}
