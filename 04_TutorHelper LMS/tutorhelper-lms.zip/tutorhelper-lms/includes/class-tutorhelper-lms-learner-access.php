<?php
/**
 * Student-facing learner access and My Courses entry point.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves student access without converting academic context into enrolment.
 *
 * Formal active enrolments authorise a Running Course. Direct and Group-derived
 * academic associations are shown as tuition context only; they do not grant
 * a Course, Topic or Lesson automatically.
 */
final class TutorHelper_LMS_Learner_Access {

	const SHORTCODE     = 'tutorhelper_lms_learning';
	const DASHBOARD_TAB = 'learning';
	const COURSE_QUERY  = 'tutorhelper_lms_course';
	const TOPIC_QUERY   = 'tutorhelper_lms_topic';
	const LESSON_QUERY  = 'tutorhelper_lms_lesson';
	const QUIZ_QUERY    = 'tutorhelper_lms_quiz';
	const QUIZ_PAGE_QUERY = 'tutorhelper_lms_quiz_page';
	const READER_QUERY  = 'tutorhelper_lms_reader';
	const COURSE_READER_QUERY = 'tutorhelper_lms_course_reader';
	const PAGE_QUERY    = 'tutorhelper_lms_page';
	const COURSE_PAGE_QUERY = 'tutorhelper_lms_course_page';
	const COURSE_COMPLETE_QUERY = 'tutorhelper_lms_course_complete';
	const READER_TTL    = DAY_IN_SECONDS;

	/**
	 * Register Core-only learner entry points.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode( self::SHORTCODE, array( __CLASS__, 'render_shortcode' ) );
		add_filter( 'tutorhelper_student_dashboard_tabs', array( __CLASS__, 'register_dashboard_tab' ), 20, 2 );
		add_filter( 'tutorhelper_student_dashboard_heading', array( __CLASS__, 'dashboard_heading' ), 20, 3 );
		add_filter( 'tutorhelper_student_dashboard_introduction', array( __CLASS__, 'dashboard_introduction' ), 20, 3 );
		add_action( 'tutorhelper_student_dashboard_tab_content', array( __CLASS__, 'render_dashboard_tab' ), 20, 3 );
		add_action( 'wp_ajax_tutorhelper_lms_load_reader_page', array( __CLASS__, 'ajax_load_reader_page' ) );
		add_action( 'wp_ajax_tutorhelper_lms_save_reader_mode', array( __CLASS__, 'ajax_save_reader_mode' ) );

		if ( ! is_admin() ) {
			add_action( 'template_redirect', array( __CLASS__, 'maybe_render_reader_page' ), 1 );
		}
	}

	/**
	 * Render the protected Lesson Reader outside the Student Dashboard shell.
	 *
	 * A reader token is deliberately handled before the host page shortcode
	 * renders, so a new Lesson tab contains only the reader rather than a
	 * second dashboard. The token is still resolved for the logged-in student
	 * and render_lesson_viewer() repeats the entitlement check.
	 *
	 * @return void
	 */
	public static function maybe_render_reader_page() {
		if ( ! self::has_reader_request() && ! self::has_course_reader_request() ) {
			return;
		}

		self::enqueue_assets();
		self::enqueue_reader_script();
		$base_url = get_permalink();
		if ( ! $base_url ) {
			$base_url = home_url( '/' );
		}

		$student_user_id = is_user_logged_in() ? get_current_user_id() : 0;
		$lesson_context = self::is_student( $student_user_id ) ? self::requested_reader_context( $student_user_id ) : array();
		$course_context = self::is_student( $student_user_id ) && ! $lesson_context ? self::requested_course_reader_context( $student_user_id ) : array();

		nocache_headers();
		?>
		<!doctype html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>" />
			<meta name="viewport" content="width=device-width, initial-scale=1" />
			<?php wp_head(); ?>
		</head>
		<body <?php body_class( 'tutorhelper-lms-reader-body' ); ?>>
		<?php wp_body_open(); ?>
		<main class="tutorhelper-lms-reader-page" id="tutorhelper-lms-reader-page">
			<div class="tutorhelper-lms-reader-page__inner">
				<?php
				if ( ! $student_user_id || ! self::is_student( $student_user_id ) ) {
					self::render_reader_login_notice( $base_url );
				} elseif ( $lesson_context ) {
					self::render_lesson_viewer( $student_user_id, $lesson_context['course_id'], $lesson_context['topic_id'], $lesson_context['lesson_id'], self::requested_id( self::PAGE_QUERY ), $base_url, self::requested_reader_token() );
				} elseif ( $course_context ) {
					$placement_id = self::requested_id( self::QUIZ_QUERY );
					if ( $placement_id ) {
						self::render_quiz_player( $student_user_id, $course_context['course_id'], $placement_id, $base_url );
					} else {
						self::render_course_menu_reader( $student_user_id, $course_context['course_id'], $base_url );
					}
				} else {
					self::render_reader_link_unavailable( $base_url );
				}
				?>
			</div>
		</main>
		<?php wp_footer(); ?>
		</body>
		</html>
		<?php
		exit;
	}

	/**
	 * Load one authorised Lesson page without reloading the reader document.
	 *
	 * @return void
	 */
	public static function ajax_load_reader_page() {
		check_ajax_referer( 'tutorhelper_lms_reader_navigation', 'nonce' );

		if ( ! is_user_logged_in() || ! self::is_student( get_current_user_id() ) ) {
			wp_send_json_error( array( 'message' => __( 'Please log in with your student account to continue reading.', 'tutorhelper-lms' ) ), 403 );
		}

		$token = self::posted_reader_token();
		$context = self::reader_context_for_token( get_current_user_id(), $token );
		if ( ! $context || ! self::can_view_lesson( get_current_user_id(), $context['course_id'], $context['topic_id'], $context['lesson_id'] ) ) {
			wp_send_json_error( array( 'message' => __( 'This Lesson link is no longer available. Please return to My Courses and open the Lesson again.', 'tutorhelper-lms' ) ), 403 );
		}

		$total_pages = self::lesson_page_total( $context['lesson_id'] );
		$page_number = min( max( 1, self::posted_id( self::PAGE_QUERY ) ), max( 1, $total_pages ) );
		$base_url = self::reader_base_url( $context );
		ob_start();
		self::render_lesson_page_fragment( $context['lesson_id'], $page_number, $base_url, $context['course_id'], $context['topic_id'], get_current_user_id(), $token );
		$html = ob_get_clean();
		ob_start();
		do_action( 'tutorhelper_lms_learner_reader_controls', get_current_user_id(), $context['course_id'], $context['topic_id'], $context['lesson_id'], $token, $page_number, $total_pages );
		$progress_html = ob_get_clean();

		wp_send_json_success( array( 'html' => $html, 'progress_html' => $progress_html ) );
	}

	/**
	 * Save a private student display preference for the authenticated Reader.
	 *
	 * @return void
	 */
	public static function ajax_save_reader_mode() {
		check_ajax_referer( 'tutorhelper_lms_reader_mode', 'nonce' );
		if ( ! is_user_logged_in() || ! self::is_student( get_current_user_id() ) ) {
			wp_send_json_error( array( 'message' => __( 'Please log in with your student account to change the reader view.', 'tutorhelper-lms' ) ), 403 );
		}
		$token = self::posted_reader_token();
		$context = self::reader_context_for_token( get_current_user_id(), $token );
		if ( ! $context || ! self::can_view_lesson( get_current_user_id(), $context['course_id'], $context['topic_id'], $context['lesson_id'] ) ) {
			wp_send_json_error( array( 'message' => __( 'This Lesson is no longer available.', 'tutorhelper-lms' ) ), 403 );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified by check_ajax_referer() above.
		$mode = isset( $_POST['reader_mode'] ) && ! is_array( $_POST['reader_mode'] ) ? sanitize_key( wp_unslash( $_POST['reader_mode'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		if ( ! in_array( $mode, array( 'all', 'reading', 'notes' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Choose a valid reader view.', 'tutorhelper-lms' ) ), 400 );
		}
		$current_mode = self::reader_display_mode( get_current_user_id() );
		if ( $mode !== $current_mode && false === update_user_meta( get_current_user_id(), 'tutorhelper_lms_reader_display_mode', $mode ) ) {
			if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
				TutorHelper_LMS_Diagnostics::error( 'Learner reader view preference could not be saved.', array( 'operation' => 'save_reader_mode', 'student_user_id' => get_current_user_id() ) );
			}
			wp_send_json_error( array( 'message' => __( 'Your reader view could not be saved. Please try again.', 'tutorhelper-lms' ) ), 500 );
		}
		wp_send_json_success( array( 'mode' => $mode, 'message' => __( 'Your reading view has been saved.', 'tutorhelper-lms' ) ) );
	}

	/**
	 * Render a sign-in notice for the protected standalone reader.
	 *
	 * @param string $base_url Parent page URL.
	 * @return void
	 */
	private static function render_reader_login_notice( $base_url ) {
		$lesson_token = isset( $_GET[ self::READER_QUERY ] ) && ! is_array( $_GET[ self::READER_QUERY ] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_GET[ self::READER_QUERY ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Creates a safe redirect target for a read-only reader request.
		$course_token = isset( $_GET[ self::COURSE_READER_QUERY ] ) && ! is_array( $_GET[ self::COURSE_READER_QUERY ] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_GET[ self::COURSE_READER_QUERY ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Creates a safe redirect target for a read-only Course menu request.
		$page = self::requested_id( self::PAGE_QUERY );
		$reader_url = add_query_arg( array_filter( array( self::READER_QUERY => $lesson_token, self::COURSE_READER_QUERY => $course_token, self::PAGE_QUERY => $page ) ), $base_url );
		$login_url = class_exists( 'TutorHelper_Settings' ) ? TutorHelper_Settings::get_login_url() : wp_login_url();
		$login_url = add_query_arg( 'redirect_to', $reader_url, $login_url );
		echo '<div class="tutorhelper-lms-learning__denied" role="status"><p>' . esc_html__( 'Please log in with your student account to open this Lesson.', 'tutorhelper-lms' ) . '</p><p><a class="tutorhelper-student-booking-notice__action" href="' . esc_url( $login_url ) . '">' . esc_html__( 'Log in', 'tutorhelper-lms' ) . '</a></p></div>';
	}

	/**
	 * Add My Courses to the established Core Student Dashboard.
	 *
	 * @param array $tabs Existing dashboard tabs.
	 * @param int   $student_user_id Current student ID.
	 * @return array
	 */
	public static function register_dashboard_tab( $tabs, $student_user_id ) {
		$tabs = is_array( $tabs ) ? $tabs : array();
		$tabs[ self::DASHBOARD_TAB ] = __( 'My Courses', 'tutorhelper-lms' );
		return $tabs;
	}

	/**
	 * Use student-friendly text when the Learning dashboard tab is active.
	 *
	 * @param string $heading Existing heading.
	 * @param string $active_tab Active dashboard tab.
	 * @param int    $student_user_id Current student ID.
	 * @return string
	 */
	public static function dashboard_heading( $heading, $active_tab, $student_user_id ) {
		return self::DASHBOARD_TAB === $active_tab ? __( 'My Courses', 'tutorhelper-lms' ) : $heading;
	}

	/**
	 * Use student-friendly text when the Learning dashboard tab is active.
	 *
	 * @param string $introduction Existing introduction.
	 * @param string $active_tab Active dashboard tab.
	 * @param int    $student_user_id Current student ID.
	 * @return string
	 */
	public static function dashboard_introduction( $introduction, $active_tab, $student_user_id ) {
		return self::DASHBOARD_TAB === $active_tab ? __( 'Find your Courses and the individual learning your tutor has shared with you.', 'tutorhelper-lms' ) : $introduction;
	}

	/**
	 * Render the LMS-owned dashboard tab.
	 *
	 * @param string $active_tab Active dashboard tab.
	 * @param int    $student_user_id Current student ID.
	 * @param bool   $is_tutor_preview Whether the viewer is a tutor previewing the dashboard.
	 * @return void
	 */
	public static function render_dashboard_tab( $active_tab, $student_user_id, $is_tutor_preview ) {
		if ( self::DASHBOARD_TAB !== $active_tab ) {
			return;
		}
		if ( $is_tutor_preview || ! self::is_student( $student_user_id ) ) {
			echo '<div class="tutorhelper-student-dashboard__empty"><p>' . esc_html__( 'My Courses is available when viewing the dashboard as a student.', 'tutorhelper-lms' ) . '</p></div>';
			return;
		}
		self::enqueue_assets();
		self::render_learning( $student_user_id, get_permalink() );
	}

	/**
	 * Render the standalone shortcode.
	 *
	 * @return string
	 */
	public static function render_shortcode() {
		if ( ! is_user_logged_in() ) {
			$login_url = class_exists( 'TutorHelper_Settings' ) ? TutorHelper_Settings::get_login_url() : wp_login_url();
			$current_url = get_permalink();
			if ( $current_url ) {
				$login_url = add_query_arg( 'redirect_to', $current_url, $login_url );
			}
			return '<div class="tutorhelper-student-booking-notice tutorhelper-student-booking-notice--warning" role="status"><p>' . esc_html__( 'Please log in to view your learning.', 'tutorhelper-lms' ) . '</p><p><a class="tutorhelper-student-booking-notice__action" href="' . esc_url( $login_url ) . '">' . esc_html__( 'Log in', 'tutorhelper-lms' ) . '</a></p></div>';
		}

		$student_user_id = get_current_user_id();
		if ( ! self::is_student( $student_user_id ) ) {
			return '<div class="tutorhelper-student-booking-notice tutorhelper-student-booking-notice--warning" role="status"><p>' . esc_html__( 'This learning area is available to registered students.', 'tutorhelper-lms' ) . '</p></div>';
		}

		self::enqueue_assets();
		ob_start();
		?>
		<section class="tutorhelper-student-dashboard tutorhelper-lms-learning-page">
			<header class="tutorhelper-student-dashboard__header">
				<p class="tutorhelper-student-dashboard__eyebrow"><?php esc_html_e( 'Student learning', 'tutorhelper-lms' ); ?></p>
				<h2 class="tutorhelper-student-dashboard__heading"><?php esc_html_e( 'My Courses', 'tutorhelper-lms' ); ?></h2>
				<p class="tutorhelper-student-dashboard__introduction"><?php esc_html_e( 'Find your Courses and the individual learning your tutor has shared with you.', 'tutorhelper-lms' ); ?></p>
			</header>
			<?php self::render_learning( $student_user_id, get_permalink() ); ?>
		</section>
		<?php
		return ob_get_clean();
	}

	/**
	 * Return a learner's access summary.
	 *
	 * The return value deliberately separates full Course access from tuition
	 * context. Future explicit Lesson/Resource grants can extend it through the
	 * filter without changing Course enrolment or academic-history records.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return array{courses:array,tuition_context:array,grants:array}
	 */
	public static function resolve( $student_user_id ) {
		$student_user_id = absint( $student_user_id );
		$courses = self::formal_courses( $student_user_id );
		$tuition_context = self::active_tuition_context( $student_user_id, $courses );
		$access = array(
			'courses'         => $courses,
			'tuition_context' => $tuition_context,
			'grants'          => array(),
		);
		$access = apply_filters( 'tutorhelper_lms_learner_access', $access, $student_user_id );
		return is_array( $access ) ? $access : array( 'courses' => array(), 'tuition_context' => array(), 'grants' => array() );
	}

	/**
	 * Return active individual-tuition Course context without running access
	 * filters. This lets grant records expire from learner access when the
	 * underlying direct/Group association ends.
	 *
	 * @param int   $student_user_id Student user ID.
	 * @param array $formal_courses Optional already-resolved formal Courses.
	 * @return array
	 */
	public static function active_tuition_context( $student_user_id, $formal_courses = null ) {
		$formal_courses = is_array( $formal_courses ) ? $formal_courses : self::formal_courses( $student_user_id );
		$formal_course_ids = array_map( static function( $course ) { return absint( $course['course_id'] ?? 0 ); }, $formal_courses );
		return array_values(
			array_filter(
				self::academic_course_context( $student_user_id ),
				static function( $context ) use ( $formal_course_ids ) {
					return ! in_array( absint( $context['course_id'] ?? 0 ), $formal_course_ids, true );
				}
			)
		);
	}

	/**
	 * Check whether a student has formal access to a Course.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $course_id Course post ID.
	 * @return bool
	 */
	public static function can_view_course( $student_user_id, $course_id ) {
		foreach ( self::formal_courses( $student_user_id ) as $course ) {
			if ( absint( $course['course_id'] ) === absint( $course_id ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check a Course/Topic/Lesson context before any learner content is shown.
	 *
	 * A formal Course enrolment authorises its ordered Lessons. Individual
	 * tuition access must be supplied by an explicit grant filter.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $course_id Course ID.
	 * @param int $topic_id Topic ID.
	 * @param int $lesson_id Lesson ID.
	 * @return bool
	 */
	public static function can_view_lesson( $student_user_id, $course_id, $topic_id, $lesson_id ) {
		if ( ! self::course_has_topic( $course_id, $topic_id ) || ! self::topic_has_lesson( $topic_id, $lesson_id ) ) {
			return false;
		}
		if ( self::can_view_course( $student_user_id, $course_id ) ) {
			return self::can_view_course_activity( $student_user_id, $course_id, $topic_id, 'lesson', $lesson_id );
		}
		return (bool) apply_filters( 'tutorhelper_lms_learner_can_view_lesson', false, absint( $student_user_id ), absint( $course_id ), absint( $topic_id ), absint( $lesson_id ) );
	}

	/** Check a placed Course Quiz before its player can be opened. */
	public static function can_view_quiz( $student_user_id, $course_id, $placement_id ) {
		$placement = self::course_quiz_placement( $course_id, $placement_id );
		return $placement && self::can_view_course_activity( $student_user_id, $course_id, absint( $placement->topic_id ), 'quiz', absint( $placement->quiz_id ), absint( $placement->id ) );
	}

	/**
	 * Apply the Course navigation style to one formal Course activity.
	 *
	 * Completed activities remain available. Optional activities do not block the
	 * main route when Premium later marks them as side quests.
	 */
	public static function can_view_course_activity( $student_user_id, $course_id, $topic_id, $type, $activity_id, $placement_id = 0 ) {
		if ( ! self::can_view_course( $student_user_id, $course_id ) ) {
			return false;
		}
		$style = class_exists( 'TutorHelper_LMS_Course_Settings' ) ? TutorHelper_LMS_Course_Settings::access_style( $course_id ) : 'open';
		if ( 'open' === $style ) {
			return true;
		}
		if ( 'in_order' !== $style ) {
			$decision = apply_filters( 'tutorhelper_lms_course_activity_access', null, absint( $student_user_id ), absint( $course_id ), absint( $topic_id ), sanitize_key( $type ), absint( $activity_id ), absint( $placement_id ), $style );
			return null !== $decision ? (bool) $decision : false;
		}
		$activities = self::course_activities( $course_id );
		foreach ( $activities as $index => $activity ) {
			if ( ! self::activity_matches( $activity, $topic_id, $type, $activity_id, $placement_id ) ) {
				continue;
			}
			if ( self::is_course_activity_complete( $student_user_id, $course_id, $activity ) ) {
				return true;
			}
			foreach ( array_slice( $activities, 0, $index ) as $previous ) {
				if ( ! empty( $previous['required'] ) && ! self::is_course_activity_complete( $student_user_id, $course_id, $previous ) ) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	/** Return the next visible Course activity after a current lesson or Quiz. */
	public static function next_course_activity( $course_id, $topic_id, $type, $activity_id, $placement_id = 0 ) {
		$activities = self::course_activities( $course_id );
		foreach ( $activities as $index => $activity ) {
			if ( self::activity_matches( $activity, $topic_id, $type, $activity_id, $placement_id ) ) {
				return $activities[ $index + 1 ] ?? array();
			}
		}
		return array();
	}


	/**
	 * Return an opaque, student-scoped Course-menu URL.
	 *
	 * @param string $base_url Parent learning page URL.
	 * @param int    $course_id Course post ID.
	 * @param int    $student_user_id Student user ID; defaults to current user.
	 * @return string
	 */
	public static function course_url( $base_url, $course_id, $student_user_id = 0 ) {
		$student_user_id = absint( $student_user_id ? $student_user_id : get_current_user_id() );
		$token = self::create_course_reader_token( $student_user_id, $course_id, $base_url );
		if ( ! $token ) {
			return remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::READER_QUERY, self::COURSE_READER_QUERY, self::PAGE_QUERY ), $base_url );
		}
		return add_query_arg( self::COURSE_READER_QUERY, $token, remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::READER_QUERY, self::COURSE_READER_QUERY, self::PAGE_QUERY ), $base_url ) );
	}

	/**
	 * Return an authorised Quiz player URL within the student Course reader.
	 *
	 * @param string $base_url Parent page URL.
	 * @param int    $course_id Course ID.
	 * @param int    $placement_id Course Quiz placement ID.
	 * @param int    $student_user_id Student ID.
	 * @return string
	 */
	public static function quiz_url( $base_url, $course_id, $placement_id, $student_user_id = 0 ) {
		$url = self::course_url( $base_url, $course_id, $student_user_id );
		$url = add_query_arg( self::QUIZ_QUERY, absint( $placement_id ), $url );
		return apply_filters( 'tutorhelper_lms_quiz_url', $url, $base_url, absint( $course_id ), absint( $placement_id ), absint( $student_user_id ) );
	}

	/**
	 * Return an opaque, student-scoped Lesson Reader URL.
	 *
	 * The link hides internal post IDs but is not the access control layer:
	 * render_lesson_viewer() still validates the current student's enrolment
	 * or explicit grant before content is displayed.
	 *
	 * @param string $base_url Parent page URL.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @param int    $lesson_id Lesson ID.
	 * @param int    $page Optional reader page number.
	 * @param int    $student_user_id Student user ID; defaults to the current user.
	 * @return string
	 */
	public static function lesson_url( $base_url, $course_id, $topic_id, $lesson_id, $page = 0, $student_user_id = 0 ) {
		$student_user_id = absint( $student_user_id ? $student_user_id : get_current_user_id() );
		$token = self::create_reader_token( $student_user_id, $course_id, $topic_id, $lesson_id, $base_url );
		if ( ! $token ) {
			return remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::READER_QUERY, self::COURSE_READER_QUERY, self::PAGE_QUERY ), $base_url );
		}

		$args = array( self::READER_QUERY => $token );
		if ( absint( $page ) ) {
			$args[ self::PAGE_QUERY ] = absint( $page );
		}
		return add_query_arg( $args, remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::READER_QUERY, self::PAGE_QUERY ), $base_url ) );
	}

	/**
	 * Render either the authorised Course overview or the learner's list.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param string $base_url Page hosting the dashboard or shortcode.
	 * @return void
	 */
	private static function render_learning( $student_user_id, $base_url ) {
		$page_number = self::requested_id( self::PAGE_QUERY );
		$reader_context = self::requested_reader_context( $student_user_id );
		if ( $reader_context ) {
			self::render_lesson_viewer( $student_user_id, $reader_context['course_id'], $reader_context['topic_id'], $reader_context['lesson_id'], $page_number, $base_url, self::requested_reader_token() );
			return;
		}
		if ( self::has_reader_request() ) {
			self::render_reader_link_unavailable( $base_url );
			return;
		}

		$course_id = self::requested_course_id();
		if ( self::requested_id( self::LESSON_QUERY ) ) {
			self::render_reader_link_unavailable( $base_url );
			return;
		}
		if ( $course_id ) {
			self::render_course_overview( $student_user_id, $course_id, $base_url );
			return;
		}

		$access = self::resolve( $student_user_id );
		?>
		<div class="tutorhelper-lms-learning" data-tutorhelper-lms-learning>
			<section class="tutorhelper-lms-learning__section" aria-labelledby="tutorhelper-lms-my-courses">
				<div class="tutorhelper-lms-learning__section-header">
					<div>
						<h3 id="tutorhelper-lms-my-courses"><?php esc_html_e( 'My Courses', 'tutorhelper-lms' ); ?></h3>
						<p><?php esc_html_e( 'Courses where you have an active place.', 'tutorhelper-lms' ); ?></p>
					</div>
					<span class="tutorhelper-student-dashboard__count" aria-label="<?php echo esc_attr( sprintf( _n( '%d Course', '%d Courses', count( $access['courses'] ), 'tutorhelper-lms' ), count( $access['courses'] ) ) ); ?>"><?php echo esc_html( count( $access['courses'] ) ); ?></span>
				</div>
				<?php if ( empty( $access['courses'] ) ) : ?>
					<div class="tutorhelper-student-dashboard__empty"><p><?php esc_html_e( 'No courses yet. Your tutor will add a Course here when you are enrolled.', 'tutorhelper-lms' ); ?></p></div>
				<?php else : ?>
					<div class="tutorhelper-lms-learning__cards">
						<?php foreach ( $access['courses'] as $course ) : self::render_course_card( $course, $base_url ); endforeach; ?>
					</div>
				<?php endif; ?>
			</section>

			<?php if ( ! empty( $access['tuition_context'] ) || ! empty( $access['grants'] ) ) : ?>
				<section class="tutorhelper-lms-learning__section" aria-labelledby="tutorhelper-lms-individual-learning">
					<div class="tutorhelper-lms-learning__section-header">
						<div>
							<h3 id="tutorhelper-lms-individual-learning"><?php esc_html_e( 'Individual tuition learning', 'tutorhelper-lms' ); ?></h3>
							<p><?php esc_html_e( 'Lessons and resources your tutor has shared for your individual learning.', 'tutorhelper-lms' ); ?></p>
						</div>
					</div>
					<?php self::render_tuition_context( $access['tuition_context'] ); ?>
					<?php do_action( 'tutorhelper_lms_render_learner_grants', $access['grants'], $student_user_id, $base_url ); ?>
				</section>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render an authorised Course summary without exposing Lesson content.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course post ID.
	 * @param string $base_url Parent page URL.
	 * @return void
	 */
	private static function render_course_overview( $student_user_id, $course_id, $base_url ) {
		if ( ! self::can_view_course( $student_user_id, $course_id ) ) {
			status_header( 403 );
			echo '<div class="tutorhelper-lms-learning__denied" role="alert"><p>' . esc_html__( 'You do not have access to this Course.', 'tutorhelper-lms' ) . '</p><p><a class="tutorhelper-student-booking-notice__action" href="' . esc_url( remove_query_arg( self::COURSE_QUERY, $base_url ) ) . '">' . esc_html__( 'Return to My Courses', 'tutorhelper-lms' ) . '</a></p></div>';
			return;
		}

		$course = get_post( $course_id );
		if ( ! $course || 'tutorhelper_course' !== $course->post_type ) {
			status_header( 404 );
			echo '<div class="tutorhelper-lms-learning__denied" role="alert"><p>' . esc_html__( 'This Course is not available.', 'tutorhelper-lms' ) . '</p></div>';
			return;
		}
		$topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
		?>
		<div class="tutorhelper-lms-course-overview">
			<p><a class="tutorhelper-lms-learning__back" href="<?php echo esc_url( remove_query_arg( self::COURSE_QUERY, $base_url ) ); ?>">&larr; <?php esc_html_e( 'Back to My Courses', 'tutorhelper-lms' ); ?></a></p>
			<article class="tutorhelper-lms-course-overview__card">
				<?php if ( has_post_thumbnail( $course_id ) ) : ?><div class="tutorhelper-lms-course-overview__image"><?php echo wp_kses_post( get_the_post_thumbnail( $course_id, 'medium' ) ); ?></div><?php endif; ?>
				<div>
					<p class="tutorhelper-lms-learning__eyebrow"><?php esc_html_e( 'Course overview', 'tutorhelper-lms' ); ?></p>
					<h3><?php echo esc_html( get_the_title( $course_id ) ); ?></h3>
					<?php if ( $course->post_excerpt ) : ?><p><?php echo esc_html( $course->post_excerpt ); ?></p><?php endif; ?>
				</div>
			</article>
			<?php if ( $course->post_content ) : ?><div class="tutorhelper-lms-course-overview__content"><?php echo wp_kses_post( apply_filters( 'the_content', $course->post_content ) ); ?></div><?php endif; ?>
			<section aria-labelledby="tutorhelper-lms-course-topics">
				<h4 id="tutorhelper-lms-course-topics"><?php esc_html_e( 'Course topics', 'tutorhelper-lms' ); ?></h4>
				<?php if ( empty( $topics ) ) : ?>
					<p><?php esc_html_e( 'Your tutor has not added Course topics yet.', 'tutorhelper-lms' ); ?></p>
				<?php else : ?>
					<ol class="tutorhelper-lms-course-overview__topics">
						<?php foreach ( $topics as $topic ) : ?>
							<?php $topic_id = absint( $topic['id'] ?? 0 ); ?>
							<li>
								<strong><?php echo esc_html( $topic['title'] ?? '' ); ?></strong>
								<?php $lessons = self::topic_lessons( $topic_id ); ?>
								<?php if ( $lessons ) : ?><ol><?php foreach ( $lessons as $lesson ) : ?><li><a href="<?php echo esc_url( self::lesson_url( $base_url, $course_id, $topic_id, $lesson['id'], 0, $student_user_id ) ); ?>" ><?php echo esc_html( $lesson['title'] ); ?></a></li><?php endforeach; ?></ol><?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ol>
				<?php endif; ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Return active formal enrolments for Running Courses.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return array
	 */
	private static function formal_courses( $student_user_id ) {
		$items = array();
		foreach ( TutorHelper_LMS_Course_Enrolments::for_student( $student_user_id ) as $enrolment ) {
			$course_id = absint( $enrolment->course_id );
			if ( 'active' !== $enrolment->status || 'tutorhelper_course' !== get_post_type( $course_id ) || 'publish' !== get_post_status( $course_id ) || 'running' !== TutorHelper_LMS_Course_Settings::lifecycle( $course_id ) ) {
				continue;
			}
			$items[] = array( 'course_id' => $course_id, 'source' => 'formal_enrolment' );
		}
		return $items;
	}

	/**
	 * Return active direct and Group-derived Course context without access.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return array
	 */
	private static function academic_course_context( $student_user_id ) {
		$contexts = array();
		foreach ( TutorHelper_LMS_Student_Academic_Context::courses_for_student( $student_user_id ) as $record ) {
			$course_id = absint( $record->course_id );
			if ( 'active' === $record->status && 'tutorhelper_course' === get_post_type( $course_id ) && 'publish' === get_post_status( $course_id ) && 'running' === TutorHelper_LMS_Course_Settings::lifecycle( $course_id ) ) {
				$contexts[ $course_id ] = array( 'course_id' => $course_id, 'source' => 'direct' );
			}
		}
		if ( class_exists( 'TutorHelper_Pro_Groups' ) ) {
			foreach ( TutorHelper_Pro_Groups::get_student_group_courses( $student_user_id ) as $context ) {
				$course_id = absint( $context['course_id'] ?? 0 );
				if ( $course_id && 'tutorhelper_course' === get_post_type( $course_id ) && 'publish' === get_post_status( $course_id ) && 'running' === TutorHelper_LMS_Course_Settings::lifecycle( $course_id ) ) {
					$contexts[ $course_id ] = array( 'course_id' => $course_id, 'source' => 'group' );
				}
			}
		}
		return array_values( $contexts );
	}

	/**
	 * Render context without providing a Course navigation link.
	 *
	 * @param array $contexts Academic contexts.
	 * @return void
	 */
	private static function render_tuition_context( $contexts ) {
		if ( empty( $contexts ) ) {
			return;
		}
		?>
		<ul class="tutorhelper-lms-learning__context-list">
			<?php foreach ( $contexts as $context ) : ?>
				<li><strong><?php echo esc_html( get_the_title( absint( $context['course_id'] ) ) ); ?></strong><span><?php esc_html_e( 'Course context — your tutor will share individual learning here.', 'tutorhelper-lms' ); ?></span></li>
			<?php endforeach; ?>
		</ul>
		<?php
	}

	/**
	 * Render one formal Course card.
	 *
	 * @param array  $course Course access data.
	 * @param string $base_url Page URL.
	 * @return void
	 */
	private static function render_course_card( $course, $base_url ) {
		$course_id = absint( $course['course_id'] );
		?>
		<article class="tutorhelper-lms-learning__card">
			<?php if ( has_post_thumbnail( $course_id ) ) : ?><div class="tutorhelper-lms-learning__card-image"><?php echo wp_kses_post( get_the_post_thumbnail( $course_id, 'medium' ) ); ?></div><?php endif; ?>
			<div class="tutorhelper-lms-learning__card-content">
				<p class="tutorhelper-lms-learning__eyebrow"><?php esc_html_e( 'Enrolled Course', 'tutorhelper-lms' ); ?></p>
				<h4><?php echo esc_html( get_the_title( $course_id ) ); ?></h4>
				<?php if ( get_the_excerpt( $course_id ) ) : ?><p><?php echo esc_html( get_the_excerpt( $course_id ) ); ?></p><?php endif; ?>
				<?php do_action( 'tutorhelper_lms_learner_course_card', $course_id, get_current_user_id(), $base_url ); ?>
				<a class="tutorhelper-student-booking-notice__action" href="<?php echo esc_url( self::course_url( $base_url, $course_id, get_current_user_id() ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open Course', 'tutorhelper-lms' ); ?><span class="screen-reader-text"> <?php esc_html_e( '(opens in a new tab)', 'tutorhelper-lms' ); ?></span></a>
			</div>
		</article>
		<?php
	}



	/**
	 * Render an authorised Quiz attempt, retaining draft answers in Core.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param int    $placement_id Course Quiz placement ID.
	 * @param string $base_url Parent learning URL.
	 * @return void
	 */
	private static function render_quiz_player( $student_user_id, $course_id, $placement_id, $base_url ) {
		$placement = self::course_quiz_placement( $course_id, $placement_id );
		if ( ! $placement || ! class_exists( 'TutorHelper_LMS_Quiz_Attempts' ) ) {
			status_header( 404 );
			self::render_reader_link_unavailable( $base_url );
			return;
		}
		$player_context = apply_filters( 'tutorhelper_lms_quiz_player_context', array(), $student_user_id, $course_id, $placement, $base_url );
		if ( empty( $player_context ) && ! self::can_view_quiz( $student_user_id, $course_id, $placement->id ) ) {
			status_header( 403 );
			?><div class="tutorhelper-lms-textbook"><div class="tutorhelper-lms-learning__denied" role="status"><p><?php esc_html_e( 'Complete the previous required activity to unlock this Quiz.', 'tutorhelper-lms' ); ?></p></div></div><?php
			return;
		}
		if ( is_wp_error( $player_context ) ) {
			status_header( 403 );
			?>
			<div class="tutorhelper-lms-textbook"><div class="tutorhelper-lms-learning__denied" role="status"><p><?php echo esc_html( $player_context->get_error_message() ); ?></p></div></div>
			<?php
			return;
		}
		$has_player_context = ! empty( $player_context );
		$attempts = TutorHelper_LMS_Quiz_Attempts::attempts_for_placement( $student_user_id, $placement->id );
		$requested_review_id = isset( $_GET['tutorhelper_lms_quiz_attempt'] ) && ! is_array( $_GET['tutorhelper_lms_quiz_attempt'] ) ? absint( wp_unslash( $_GET['tutorhelper_lms_quiz_attempt'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reads a student-owned attempt only.
		$start_new_attempt = isset( $_GET['tutorhelper_lms_quiz_new_attempt'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Starts an authorised attempt only after policy validation.
		$posted_attempt_id = isset( $_POST['quiz_attempt_id'] ) && ! is_array( $_POST['quiz_attempt_id'] ) ? absint( wp_unslash( $_POST['quiz_attempt_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The matching attempt nonce is verified before any response is saved.
		$posted_attempt = $posted_attempt_id ? TutorHelper_LMS_Quiz_Attempts::attempt_for_student( $posted_attempt_id, $student_user_id, $placement->id ) : null;
		if ( $posted_attempt_id && ! $posted_attempt ) {
			status_header( 403 );
			self::render_reader_link_unavailable( $base_url );
			return;
		}
		if ( $posted_attempt && 'completed' === (string) $posted_attempt->status ) {
			self::render_quiz_attempt_review( $student_user_id, $course_id, $placement, $posted_attempt, $base_url );
			return;
		}
		$open_attempt = $posted_attempt;
		if ( ! $open_attempt ) {
			foreach ( $attempts as $existing_attempt ) {
				if ( 'in_progress' === (string) $existing_attempt->status ) { $open_attempt = $existing_attempt; break; }
			}
		}
		if ( $requested_review_id ) {
			$review_attempt = TutorHelper_LMS_Quiz_Attempts::attempt_for_student( $requested_review_id, $student_user_id, $placement->id );
			if ( $review_attempt && 'completed' === (string) $review_attempt->status ) {
				self::render_quiz_attempt_review( $student_user_id, $course_id, $placement, $review_attempt, $base_url );
				return;
			}
		}
		$completed_attempts = array_filter( $attempts, static function ( $existing_attempt ) { return 'completed' === (string) $existing_attempt->status; } );
		// Completed work takes precedence over a stray draft: reopening a Quiz should
		// always show its attempt history until the learner explicitly chooses Try again.
		if ( $completed_attempts && ! $start_new_attempt && ! $posted_attempt && ! $has_player_context ) {
			self::render_quiz_attempt_history( $student_user_id, $course_id, $placement, $attempts, $base_url );
			return;
		}
		$attempt = $posted_attempt ? $posted_attempt : TutorHelper_LMS_Quiz_Attempts::create_or_resume( $student_user_id, $placement, $player_context );
		if ( is_wp_error( $attempt ) ) {
			?>
			<div class="tutorhelper-lms-textbook"><p><a class="tutorhelper-lms-learning__back" href="<?php echo esc_url( self::course_url( $base_url, $course_id, $student_user_id ) ); ?>">&larr; <?php esc_html_e( 'Back to Course', 'tutorhelper-lms' ); ?></a></p><div class="tutorhelper-lms-learning__denied" role="status"><p><?php echo esc_html( $attempt->get_error_message() ); ?></p></div></div>
			<?php
			return;
		}
		$deadline_reached = (bool) apply_filters( 'tutorhelper_lms_quiz_attempt_expired', false, $attempt );
		if ( $deadline_reached && 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			$auto_submitted = TutorHelper_LMS_Quiz_Attempts::submit( $attempt, TutorHelper_LMS_Quiz_Attempts::draft_responses( $attempt->id ) );
			if ( ! is_wp_error( $auto_submitted ) ) {
				$completed_attempt = TutorHelper_LMS_Quiz_Attempts::attempt_for_student( $attempt->id, $student_user_id, $placement->id );
				self::render_quiz_attempt_review( $student_user_id, $course_id, $placement, $completed_attempt ? $completed_attempt : $attempt, $base_url );
				return;
			}
		}
		$saved = false; $submitted = false; $response_error = null;
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['tutorhelper_lms_quiz_draft_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tutorhelper_lms_quiz_draft_nonce'] ) ), 'tutorhelper_lms_quiz_draft_' . absint( $attempt->id ) ) ) {
			$responses = isset( $_POST['response'] ) && is_array( $_POST['response'] ) ? wp_unslash( $_POST['response'] ) : array();
			$visible_question_ids = isset( $_POST['visible_questions'] ) && is_array( $_POST['visible_questions'] ) ? array_map( 'absint', wp_unslash( $_POST['visible_questions'] ) ) : array();
			$responses = apply_filters( 'tutorhelper_lms_quiz_player_posted_responses', $responses, $attempt, $visible_question_ids );
			$response_error = is_wp_error( $responses ) ? $responses : null;
			if ( $response_error ) {
				$submitted = false;
				$saved     = false;
			} else {
				$submitted = ( $deadline_reached || ! empty( $_POST['quiz_submit'] ) ) ? TutorHelper_LMS_Quiz_Attempts::submit( $attempt, $responses, $visible_question_ids ) : false;
				$saved = $submitted ? ! is_wp_error( $submitted ) : TutorHelper_LMS_Quiz_Attempts::save_draft_responses( $attempt, $responses, $visible_question_ids );
			}
		}
		$snapshot = json_decode( (string) $attempt->snapshot_json, true );
		$quiz = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
		$questions = is_array( $snapshot['questions'] ?? null ) ? $snapshot['questions'] : array();
		$responses = TutorHelper_LMS_Quiz_Attempts::draft_responses( $attempt->id );
		$delivery_mode = self::quiz_delivery_mode( $quiz );
		$groups = self::quiz_delivery_groups( $questions, $delivery_mode );
		$requested_page = isset( $_POST['quiz_page'] ) ? absint( wp_unslash( $_POST['quiz_page'] ) ) : self::requested_id( self::QUIZ_PAGE_QUERY );
		$current_page = min( max( 1, $requested_page ? $requested_page : 1 ), max( 1, count( $groups ) ) );
		$visible_question_indexes = isset( $groups[ $current_page - 1 ]['indexes'] ) ? $groups[ $current_page - 1 ]['indexes'] : array_keys( $questions );
		$maximum_marks = 0;
		foreach ( $questions as $quiz_question ) {
			$maximum_marks += self::quiz_question_marks( $quiz_question );
		}
		$pass_mark = absint( $snapshot['pass_mark'] ?? ( $quiz['pass_mark'] ?? 0 ) );
		$pass_requirement_label = apply_filters(
			'tutorhelper_lms_quiz_attempt_requirement_label',
			sprintf( __( 'You must score %1$d out of %2$d to pass', 'tutorhelper-lms' ), $pass_mark, $maximum_marks ),
			$snapshot,
			$pass_mark,
			$maximum_marks
		);
		if ( $submitted && ! is_wp_error( $submitted ) ) {
			$completed_attempt = TutorHelper_LMS_Quiz_Attempts::attempt_for_student( $attempt->id, $student_user_id, $placement->id );
			self::render_quiz_attempt_review( $student_user_id, $course_id, $placement, $completed_attempt ? $completed_attempt : $attempt, $base_url );
			return;
		}
		?>
		<div class="tutorhelper-lms-textbook tutorhelper-lms-textbook--quiz">
			<p><a class="tutorhelper-lms-learning__back" href="<?php echo esc_url( self::course_url( $base_url, $course_id, $student_user_id ) ); ?>">&larr; <?php esc_html_e( 'Back to Course', 'tutorhelper-lms' ); ?></a></p>
			<article class="tutorhelper-lms-textbook__reader">
				<header class="tutorhelper-lms-textbook__header">
					<div>
						<p class="tutorhelper-lms-textbook__eyebrow"><?php echo esc_html( get_the_title( $course_id ) . ' · ' . __( 'Quiz', 'tutorhelper-lms' ) ); ?></p>
						<h3><?php echo esc_html( $quiz['title'] ?? get_the_title( absint( $placement->quiz_id ) ) ); ?></h3>
						<?php if ( ! empty( $quiz['instructions'] ) ) : ?><div class="tutorhelper-lms-quiz__instructions"><?php echo wp_kses_post( apply_filters( 'the_content', $quiz['instructions'] ) ); ?></div><?php endif; ?>
					</div>
					<div class="tutorhelper-lms-quiz__summary-pills"><span class="tutorhelper-lms-textbook__status"><?php echo esc_html( sprintf( __( 'Attempt %d', 'tutorhelper-lms' ), absint( $attempt->attempt_number ) ) ); ?></span><span class="tutorhelper-lms-quiz__maximum-marks"><?php echo esc_html( $pass_requirement_label ); ?></span></div>
				</header>
				<?php if ( $response_error ) : ?><p class="notice notice-error inline"><span><?php echo esc_html( $response_error->get_error_message() ); ?></span></p><?php elseif ( $submitted && ! is_wp_error( $submitted ) ) : ?><p class="notice notice-success inline"><span><?php esc_html_e( 'Your Quiz has been submitted and automatically marked.', 'tutorhelper-lms' ); ?></span></p><?php elseif ( $saved ) : ?><p class="notice notice-success inline"><span><?php esc_html_e( 'Your draft answers have been saved.', 'tutorhelper-lms' ); ?></span></p><?php endif; ?>
				<?php do_action( 'tutorhelper_lms_quiz_player_summary', $attempt, $snapshot ); ?>
				<?php self::render_quiz_progress_tracker( $groups, $current_page, $delivery_mode, $responses, $questions ); ?>
				<?php if ( 'section' === $delivery_mode && ! empty( $groups[ $current_page - 1 ]['title'] ) ) : ?><h4 class="tutorhelper-lms-quiz__section-title"><?php echo esc_html( $groups[ $current_page - 1 ]['title'] ); ?></h4><?php endif; ?>
				<form method="post" class="tutorhelper-lms-quiz__form" autocomplete="off" enctype="multipart/form-data">
					<?php wp_nonce_field( 'tutorhelper_lms_quiz_draft_' . absint( $attempt->id ), 'tutorhelper_lms_quiz_draft_nonce' ); ?>
					<input type="hidden" name="quiz_attempt_id" value="<?php echo esc_attr( absint( $attempt->id ) ); ?>" />
					<ol class="tutorhelper-lms-quiz__questions">
						<?php foreach ( $visible_question_indexes as $index ) : ?>
							<?php $question = $questions[ $index ]; ?>
							<?php
							$question_id = absint( $question['question_id'] ?? 0 );
							$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
							$definition = is_array( $definition ) ? $definition : array();
							$type = sanitize_key( $definition['question_type'] ?? '' );
							$answer = $responses[ $question_id ] ?? '';
							$options = is_array( $definition['answers']['options'] ?? null ) ? $definition['answers']['options'] : array();
							$marks = self::quiz_question_marks( $question, $definition );
							?>
							<li class="tutorhelper-lms-quiz__question">
								<input type="hidden" name="visible_questions[]" value="<?php echo esc_attr( $question_id ); ?>" />
								<h4><?php echo esc_html( sprintf( __( 'Question %d', 'tutorhelper-lms' ), $index + 1 ) ); ?> <span><?php echo esc_html( sprintf( _n( '%d mark', '%d marks', $marks, 'tutorhelper-lms' ), $marks ) ); ?></span></h4>
								<?php if ( 'cloze' !== $type ) : ?><div class="tutorhelper-lms-quiz__prompt"><?php echo wp_kses_post( apply_filters( 'the_content', $definition['prompt'] ?? '' ) ); ?></div><?php endif; ?>
								<?php self::render_quiz_question_response( $attempt->id, $question_id, $definition, $type, $answer ); ?>
							</li>
						<?php endforeach; ?>
					</ol>
					<div class="tutorhelper-lms-quiz__actions">
						<?php if ( $current_page > 1 ) : ?><button type="submit" class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--secondary" name="quiz_page" value="<?php echo esc_attr( $current_page - 1 ); ?>"><?php esc_html_e( 'Save and go back', 'tutorhelper-lms' ); ?></button><?php endif; ?>
						<button type="submit" class="tutorhelper-lms-quiz__button <?php echo esc_attr( $current_page < count( $groups ) ? 'tutorhelper-lms-quiz__button--primary' : 'tutorhelper-lms-quiz__button--secondary' ); ?>" name="quiz_page" value="<?php echo esc_attr( $current_page < count( $groups ) ? $current_page + 1 : $current_page ); ?>"><?php echo esc_html( $current_page < count( $groups ) ? __( 'Save and continue', 'tutorhelper-lms' ) : __( 'Save draft answers', 'tutorhelper-lms' ) ); ?></button><?php if ( $current_page === count( $groups ) ) : ?><button type="submit" class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--primary" name="quiz_submit" value="1"><?php esc_html_e( 'Submit Quiz', 'tutorhelper-lms' ); ?></button><?php endif; ?>
					</div>
					<p class="description"><?php esc_html_e( 'Click Save draft answers to return to this Quiz later, or Submit Quiz to complete the Quiz.', 'tutorhelper-lms' ); ?></p>
				</form>
			</article>
		</div>
		<?php
	}


	/**
	 * Render the learner's immutable, read-only marked attempt.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param object $placement Course Quiz placement.
	 * @param object $attempt Student-owned completed attempt.
	 * @param string $base_url Parent learning URL.
	 * @return void
	 */
	private static function render_quiz_attempt_review( $student_user_id, $course_id, $placement, $attempt, $base_url ) {
		if ( ! TutorHelper_LMS_Quiz_Attempts::results_released( $attempt ) ) {
			self::render_quiz_results_pending( $student_user_id, $course_id, $placement, $attempt, $base_url );
			return;
		}

		$snapshot = json_decode( (string) $attempt->snapshot_json, true );
		$quiz = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
		$questions = is_array( $snapshot['questions'] ?? null ) ? $snapshot['questions'] : array();
		$review = TutorHelper_LMS_Quiz_Attempts::reviewed_responses( $attempt->id );
		$score = TutorHelper_LMS_Quiz_Attempts::attempt_score( $attempt->id );
		$grade_result = self::quiz_grade_result( $course_id, $score, $snapshot );
		$score_label = self::quiz_score_label( $score, $grade_result );
		$pass_mark = absint( $snapshot['pass_mark'] ?? 0 );
		$percentage = $score['available'] > 0 ? (int) round( ( 100 * $score['marks'] ) / $score['available'] ) : 0;
		$review_pass_label = apply_filters(
			'tutorhelper_lms_quiz_attempt_review_pass_label',
			sprintf( __( '%1$d%% · Pass mark: %2$d', 'tutorhelper-lms' ), $percentage, $pass_mark ),
			$snapshot,
			$percentage,
			$pass_mark
		);
		$outcome = sanitize_key( $score['outcome'] );
		$outcome_label = 'pass' === $outcome ? __( 'Pass', 'tutorhelper-lms' ) : ( 'fail' === $outcome ? __( 'Fail', 'tutorhelper-lms' ) : __( 'Awaiting marking', 'tutorhelper-lms' ) );
		?>
		<div class="tutorhelper-lms-textbook tutorhelper-lms-textbook--quiz">
			<p><a class="tutorhelper-lms-learning__back" href="<?php echo esc_url( self::quiz_url( $base_url, $course_id, $placement->id, $student_user_id ) ); ?>">&larr; <?php esc_html_e( 'Back to attempts', 'tutorhelper-lms' ); ?></a></p>
			<article class="tutorhelper-lms-textbook__reader">
				<header class="tutorhelper-lms-textbook__header">
					<div>
						<p class="tutorhelper-lms-textbook__eyebrow"><?php echo esc_html( get_the_title( $course_id ) . ' · ' . __( 'Quiz feedback', 'tutorhelper-lms' ) ); ?></p>
						<h3><?php echo esc_html( $quiz['title'] ?? get_the_title( absint( $placement->quiz_id ) ) ); ?></h3>
						<p><?php echo esc_html( sprintf( __( 'Attempt %1$d submitted %2$s · Time taken: %3$s', 'tutorhelper-lms' ), absint( $attempt->attempt_number ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $attempt->submitted_at ?: $attempt->completed_at ) ), TutorHelper_LMS_Quiz_Attempts::time_taken_label( $attempt ) ) ); ?></p>
					</div>
					<div class="tutorhelper-lms-quiz__summary-pills"><span class="tutorhelper-lms-textbook__status"><?php echo esc_html( $score_label ); ?></span><span class="tutorhelper-lms-quiz__result is-<?php echo esc_attr( $outcome ); ?>"><?php echo esc_html( $outcome_label ); ?></span><span class="tutorhelper-lms-quiz__maximum-marks"><?php echo esc_html( $review_pass_label ); ?></span></div>
				</header>
				<?php do_action( 'tutorhelper_lms_quiz_attempt_review_meta', $attempt, $snapshot ); ?>
				<?php if ( $score['ungraded'] ) : ?><p class="tutorhelper-lms-quiz__marking-notice"><?php esc_html_e( 'Some questions need your tutor to mark them before your final score is available.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
				<?php if ( ! empty( $attempt->tutor_feedback ) ) : ?><section class="tutorhelper-lms-quiz__feedback"><h4><?php esc_html_e( 'Tutor feedback', 'tutorhelper-lms' ); ?></h4><?php echo wp_kses_post( wpautop( $attempt->tutor_feedback ) ); ?></section><?php endif; ?>
				<ol class="tutorhelper-lms-quiz__questions tutorhelper-lms-quiz__questions--review">
					<?php foreach ( $questions as $index => $question ) : ?>
						<?php
						$question_id = absint( $question['question_id'] ?? 0 );
						$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
						$definition = is_array( $definition ) ? $definition : array();
						$type = sanitize_key( $definition['question_type'] ?? '' );
						$marks = self::quiz_question_marks( $question, $definition );
						$response = $review[ $question_id ] ?? array( 'answer' => '', 'mark' => array( 'status' => 'ungraded' ) );
						$mark = is_array( $response['mark'] ?? null ) ? $response['mark'] : array();
						$status = sanitize_key( $mark['status'] ?? ( $response['status'] ?? 'ungraded' ) );
						$label = 'correct' === $status ? __( 'Correct!', 'tutorhelper-lms' ) : ( 'partial' === $status ? __( 'Nearly There!', 'tutorhelper-lms' ) : ( 'awaiting_marking' === $status ? __( 'Tutor marking needed', 'tutorhelper-lms' ) : ( 'manual_marked' === $status ? __( 'Tutor marked', 'tutorhelper-lms' ) : ( 'ungraded' === $status ? __( 'Recorded (ungraded)', 'tutorhelper-lms' ) : __( 'Incorrect', 'tutorhelper-lms' ) ) ) ) );
						$icon = 'correct' === $status ? 'yes-alt' : ( 'partial' === $status ? 'marker' : ( 'awaiting_marking' === $status ? 'clock' : ( 'manual_marked' === $status ? 'edit' : ( 'ungraded' === $status ? 'chart-bar' : 'dismiss' ) ) ) );
						?>
						<li class="tutorhelper-lms-quiz__question tutorhelper-lms-quiz__question--review is-<?php echo esc_attr( $status ); ?>">
							<h4><span class="tutorhelper-lms-quiz__feedback-label"><span class="dashicons dashicons-<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span><?php echo esc_html( sprintf( __( 'Question %1$d · %2$s', 'tutorhelper-lms' ), $index + 1, $label ) ); ?></span><span><?php echo esc_html( 'ungraded' === $status ? sprintf( _n( '%d mark', '%d marks', $marks, 'tutorhelper-lms' ), $marks ) : sprintf( __( '%1$d / %2$d marks', 'tutorhelper-lms' ), absint( $mark['marks'] ?? 0 ), absint( $mark['available'] ?? $marks ) ) ); ?></span></h4>
							<?php if ( 'cloze' !== $type ) : ?><div class="tutorhelper-lms-quiz__prompt"><?php echo wp_kses_post( apply_filters( 'the_content', $definition['prompt'] ?? '' ) ); ?></div><?php endif; ?>
							<?php self::render_quiz_read_only_answer( $definition, $type, $response['answer'] ?? '', $status, $mark, $question_id, $attempt ); ?>
							<?php if ( 'awaiting_marking' === $status ) : ?><p class="tutorhelper-lms-quiz__manual-marking"><?php esc_html_e( 'Marks will be shown once your tutor has marked this question.', 'tutorhelper-lms' ); ?></p><?php elseif ( 'ungraded' === $status ) : ?><p class="tutorhelper-lms-quiz__manual-marking"><?php esc_html_e( 'Your response has been recorded but does not count towards the Quiz score.', 'tutorhelper-lms' ); ?></p><?php elseif ( ! empty( $mark['feedback'] ) ) : ?><div class="tutorhelper-lms-quiz__feedback"><?php echo wp_kses_post( wpautop( $mark['feedback'] ) ); ?></div><?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ol>
				<?php
				$attempts_url = self::quiz_url( $base_url, $course_id, $placement->id, $student_user_id );
				$can_try_again = 'single' !== sanitize_key( $attempt->attempt_policy );
				$next_activity_url = self::next_quiz_activity_url( $student_user_id, $course_id, $placement, $base_url );
				?>
				<div class="tutorhelper-lms-quiz__actions tutorhelper-lms-quiz__review-actions">
					<a class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--secondary" href="<?php echo esc_url( $attempts_url ); ?>"><?php esc_html_e( 'View My Attempts', 'tutorhelper-lms' ); ?></a>
					<?php if ( $can_try_again ) : ?><a class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--primary" href="<?php echo esc_url( add_query_arg( 'tutorhelper_lms_quiz_new_attempt', '1', $attempts_url ) ); ?>"><?php esc_html_e( 'Try Again', 'tutorhelper-lms' ); ?></a><?php endif; ?>
					<?php if ( $next_activity_url ) : ?><a class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--secondary" href="<?php echo esc_url( $next_activity_url ); ?>"><?php esc_html_e( 'Next Activity', 'tutorhelper-lms' ); ?></a><?php else : ?><a class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--secondary" href="<?php echo esc_url( add_query_arg( self::COURSE_COMPLETE_QUERY, '1', self::course_url( $base_url, $course_id, $student_user_id ) ) ); ?>"><?php esc_html_e( 'Finish Course', 'tutorhelper-lms' ); ?></a><?php endif; ?>
				</div>
			</article>
		</div>
		<?php
	}

	/**
	 * Return the next activity in the current Topic after this Quiz placement.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param object $placement Current Course Quiz placement.
	 * @param string $base_url Parent learning URL.
	 * @return string
	 */
	private static function next_quiz_activity_url( $student_user_id, $course_id, $placement, $base_url ) {
		$next = self::next_course_activity( $course_id, absint( $placement->topic_id ), 'quiz', absint( $placement->quiz_id ), absint( $placement->id ) );
		if ( ! $next ) {
			return '';
		}
		return 'quiz' === ( $next['type'] ?? '' )
			? self::quiz_url( $base_url, $course_id, absint( $next['placement_id'] ?? 0 ), $student_user_id )
			: self::lesson_url( $base_url, $course_id, absint( $next['topic_id'] ?? 0 ), absint( $next['id'] ?? 0 ), 0, $student_user_id );
	}


	/**
	 * Return learner-facing marks for a snapshotted Question.
	 *
	 * Item-based Questions derive their maximum from their immutable answer
	 * definition, so placement-level overrides cannot contradict automatic
	 * one-mark-per-item marking.
	 *
	 * @param array $question   Snapshotted Question placement.
	 * @param array $definition Optional decoded Question definition.
	 * @return int
	 */
	private static function quiz_question_marks( $question, $definition = array() ) {
		$definition = is_array( $definition ) && ! empty( $definition ) ? $definition : json_decode( (string) ( $question['definition_json'] ?? '' ), true );
		$definition = is_array( $definition ) ? $definition : array();
		$answers    = is_array( $definition['answers'] ?? null ) ? $definition['answers'] : array();
		$settings   = is_array( $definition['settings'] ?? null ) ? $definition['settings'] : array();
		$type       = sanitize_key( $definition['question_type'] ?? '' );

		if ( 'cloze' === $type ) {
			return count( (array) ( $answers['blanks'] ?? array() ) );
		}
		if ( 'matrix_sort' === $type ) {
			return count( (array) ( $answers['pairs'] ?? array() ) );
		}
		if ( 'sort_answer' === $type ) {
			return max( 0, count( (array) ( $answers['items'] ?? array() ) ) - ( ! empty( $settings['exclude_final_item_mark'] ) ? 1 : 0 ) );
		}
		return null === ( $question['mark_override'] ?? null ) ? absint( $question['max_marks'] ?? 0 ) : absint( $question['mark_override'] );
	}

	/**
	 * Render a submitted response without controls, retaining the student's exact answer.
	 *
	 * @param array  $definition Immutable Question definition.
	 * @param string $type Question type.
	 * @param mixed  $answer Submitted response.
	 * @param string $status Stored mark status.
	 * @param int    $question_id Question ID.
	 * @param object $attempt     Immutable Quiz attempt being reviewed.
	 * @return void
	 */
	public static function render_quiz_read_only_answer( $definition, $type, $answer, $status, $mark, $question_id, $attempt = null ) {
		$custom_answer = apply_filters( 'tutorhelper_lms_quiz_read_only_response_html', '', $definition, $type, $answer, $status, $mark, $question_id, $attempt );
		if ( is_string( $custom_answer ) && '' !== $custom_answer ) {
			echo wp_kses_post( $custom_answer );
			return;
		}
		$answers = is_array( $definition['answers'] ?? null ) ? $definition['answers'] : array();
		$details = is_array( $mark['details'] ?? null ) ? $mark['details'] : array();
		$state = in_array( $status, array( 'correct', 'partial', 'incorrect' ), true ) ? $status : 'ungraded';
		if ( in_array( $type, array( 'single_choice', 'multiple_choice' ), true ) ) {
			$selected = 'multiple_choice' === $type ? array_map( 'strval', (array) $answer ) : array( (string) $answer );
			$correct_options = array_map( 'strval', (array) ( $answers['correct'] ?? array() ) );
			echo '<ul class="tutorhelper-lms-quiz__review-options">';
			foreach ( (array) ( $answers['options'] ?? array() ) as $option_index => $option ) {
				$option_key = (string) $option_index;
				$detail = is_array( $details[ $option_key ] ?? null ) ? $details[ $option_key ] : array();
				$is_selected = array_key_exists( 'selected', $detail ) ? ! empty( $detail['selected'] ) : in_array( $option_key, $selected, true );
				$is_correct_option = array_key_exists( 'correct', $detail ) ? ! empty( $detail['correct'] ) : in_array( $option_key, $correct_options, true );
				$item_state = ! $is_selected ? 'unselected' : ( $is_correct_option ? 'correct' : 'incorrect' );
				$icon = 'correct' === $item_state ? 'yes-alt' : ( 'incorrect' === $item_state ? 'dismiss' : '' );
				echo '<li class="is-' . esc_attr( $item_state ) . '">';
				if ( $icon ) {
					echo '<span class="dashicons dashicons-' . esc_attr( $icon ) . '" aria-hidden="true"></span>';
				}
				echo esc_html( $option ) . '</li>';
			}
			echo '</ul>';
			return;
		}
		if ( 'sort_answer' === $type ) {
			echo '<ol class="tutorhelper-lms-quiz__review-sort">';
			foreach ( self::response_array( $answer ) as $index => $item ) {
				$detail = $details[ $index ] ?? array( 'correct' => $state === 'correct', 'awardable' => true );
				$item_state = ! empty( $detail['correct'] ) ? 'correct' : 'incorrect';
				echo '<li class="is-' . esc_attr( $item_state ) . '"><span class="dashicons dashicons-' . esc_attr( 'correct' === $item_state ? 'yes-alt' : 'dismiss' ) . '" aria-hidden="true"></span>' . esc_html( $item ) . '</li>';
			}
			echo '</ol>';
			return;
		}
		if ( 'matrix_sort' === $type ) {
			$pairs = is_array( $answers['pairs'] ?? null ) ? $answers['pairs'] : array();
			$submitted_answers = is_array( $answer ) ? $answer : self::response_array( $answer );
			echo '<div class="tutorhelper-lms-quiz__review-matching">';
			foreach ( $pairs as $pair_index => $pair ) {
				$detail = $details[ $pair_index ] ?? array( 'correct' => $state === 'correct' );
				$item_state = ! empty( $detail['correct'] ) ? 'correct' : 'incorrect';
				echo '<div class="tutorhelper-lms-quiz__review-match-row"><strong>' . esc_html( $pair['left'] ?? '' ) . '</strong><span class="is-' . esc_attr( $item_state ) . '"><span class="dashicons dashicons-' . esc_attr( 'correct' === $item_state ? 'yes-alt' : 'dismiss' ) . '" aria-hidden="true"></span>' . esc_html( $submitted_answers[ $pair_index ] ?? '' ) . '</span></div>';
			}
			echo '</div>';
			return;
		}
		if ( 'cloze' === $type ) {
			$prompt = wpautop( wp_kses_post( (string) ( $definition['prompt'] ?? '' ) ) );
			$values = is_array( $answer ) ? $answer : array();
			$prompt = preg_replace_callback( '/\{\{(\d+)\}\}/', static function ( $matches ) use ( $values, $details, $state ) {
				$number = absint( $matches[1] );
				$detail = $details[ $number ] ?? array( 'correct' => $state === 'correct' );
				$item_state = ! empty( $detail['correct'] ) ? 'correct' : 'incorrect';
				return '<span class="tutorhelper-lms-quiz__review-cloze is-' . esc_attr( $item_state ) . '"><span class="dashicons dashicons-' . esc_attr( 'correct' === $item_state ? 'yes-alt' : 'dismiss' ) . '" aria-hidden="true"></span>' . esc_html( $values[ $number ] ?? '' ) . '</span>';
			}, $prompt );
			echo '<div class="tutorhelper-lms-quiz__cloze">' . $prompt . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Sanitised prompt has only escaped answer spans injected.
			return;
		}
		echo '<div class="tutorhelper-lms-quiz__review-answer is-' . esc_attr( $state ) . '">' . nl2br( esc_html( is_array( $answer ) ? implode( ', ', $answer ) : $answer ) ) . '</div>';
	}

	/**
	 * Render the student-safe completion state before a tutor releases results.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param object $placement Course Quiz placement.
	 * @param object $attempt Student-owned completed attempt.
	 * @param string $base_url Parent learning URL.
	 * @return void
	 */
	private static function render_quiz_results_pending( $student_user_id, $course_id, $placement, $attempt, $base_url ) {
		$snapshot = json_decode( (string) $attempt->snapshot_json, true );
		$quiz = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
		$submitted = $attempt->submitted_at ?: $attempt->completed_at;
		?>
		<div class="tutorhelper-lms-textbook tutorhelper-lms-textbook--quiz">
			<p><a class="tutorhelper-lms-learning__back" href="<?php echo esc_url( self::quiz_url( $base_url, $course_id, $placement->id, $student_user_id ) ); ?>">&larr; <?php esc_html_e( 'Back to attempts', 'tutorhelper-lms' ); ?></a></p>
			<article class="tutorhelper-lms-textbook__reader">
				<header class="tutorhelper-lms-textbook__header">
					<div>
						<p class="tutorhelper-lms-textbook__eyebrow"><?php echo esc_html( get_the_title( $course_id ) . ' · ' . __( 'Quiz results', 'tutorhelper-lms' ) ); ?></p>
						<h3><?php echo esc_html( $quiz['title'] ?? get_the_title( absint( $placement->quiz_id ) ) ); ?></h3>
						<p><?php echo esc_html( sprintf( __( 'Attempt %d submitted %s', 'tutorhelper-lms' ), absint( $attempt->attempt_number ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $submitted ) ) ) ); ?></p>
					</div>
					<div class="tutorhelper-lms-quiz__summary-pills"><span class="tutorhelper-lms-quiz__result is-pending"><?php esc_html_e( 'Results pending release', 'tutorhelper-lms' ); ?></span></div>
				</header>
				<p class="tutorhelper-lms-quiz__marking-notice"><?php esc_html_e( 'Your Quiz has been submitted. Your tutor will release your marks and feedback when they are ready.', 'tutorhelper-lms' ); ?></p>
			</article>
		</div>
		<?php
	}

	/**
	 * Render completed attempts and an explicit, policy-safe retake action.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param object $placement Course Quiz placement.
	 * @param array  $attempts Student-owned attempts.
	 * @param string $base_url Parent learning URL.
	 * @return void
	 */
	private static function render_quiz_attempt_history( $student_user_id, $course_id, $placement, $attempts, $base_url ) {
		$completed = array_values( array_filter( $attempts, static function ( $attempt ) { return 'completed' === (string) $attempt->status; } ) );
		$drafts    = array_values( array_filter( $attempts, static function ( $attempt ) { return 'in_progress' === (string) $attempt->status; } ) );
		$draft     = ! empty( $drafts ) ? $drafts[0] : null;
		$policy    = $completed ? sanitize_key( $completed[0]->attempt_policy ) : 'unlimited';
		$can_retake = 'single' !== $policy;
		?>
		<div class="tutorhelper-lms-textbook tutorhelper-lms-textbook--quiz">
			<p><a class="tutorhelper-lms-learning__back" href="<?php echo esc_url( self::course_url( $base_url, $course_id, $student_user_id ) ); ?>">&larr; <?php esc_html_e( 'Back to Course', 'tutorhelper-lms' ); ?></a></p>
			<article class="tutorhelper-lms-textbook__reader tutorhelper-lms-quiz__attempt-history">
				<h3><?php echo esc_html( get_the_title( absint( $placement->quiz_id ) ) ); ?></h3>
				<p><?php esc_html_e( 'Your submitted attempts are shown below. Open an attempt to review your answers and feedback.', 'tutorhelper-lms' ); ?></p>
				<table><thead><tr><th scope="col"><?php esc_html_e( 'Attempt', 'tutorhelper-lms' ); ?></th><th scope="col"><?php esc_html_e( 'Submitted', 'tutorhelper-lms' ); ?></th><th scope="col"><?php esc_html_e( 'Time taken', 'tutorhelper-lms' ); ?></th><th scope="col"><?php esc_html_e( 'Score', 'tutorhelper-lms' ); ?></th><th scope="col"><?php esc_html_e( 'Result', 'tutorhelper-lms' ); ?></th><th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Action', 'tutorhelper-lms' ); ?></span></th></tr></thead><tbody>
					<?php foreach ( $completed as $attempt ) : ?>
						<?php
						$released = TutorHelper_LMS_Quiz_Attempts::results_released( $attempt );
						$score = $released ? TutorHelper_LMS_Quiz_Attempts::attempt_score( $attempt->id ) : null;
						$attempt_snapshot = $released ? json_decode( (string) $attempt->snapshot_json, true ) : array();
						$attempt_grade_result = $released ? self::quiz_grade_result( $course_id, $score, is_array( $attempt_snapshot ) ? $attempt_snapshot : array() ) : array();
						?>
						<tr>
							<th scope="row"><?php echo esc_html( sprintf( __( 'Attempt %d', 'tutorhelper-lms' ), absint( $attempt->attempt_number ) ) ); ?></th>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $attempt->submitted_at ?: $attempt->completed_at ) ) ); ?></td>
							<td><?php echo esc_html( TutorHelper_LMS_Quiz_Attempts::time_taken_label( $attempt ) ); ?></td>
							<td><?php if ( $released ) : ?><?php echo esc_html( self::quiz_score_label( $score, $attempt_grade_result ) ); ?><?php if ( $score['ungraded'] ) : ?> <span><?php esc_html_e( '· tutor marking pending', 'tutorhelper-lms' ); ?></span><?php endif; ?><?php else : ?><?php esc_html_e( 'Results pending release', 'tutorhelper-lms' ); ?><?php endif; ?></td>
							<td><?php if ( $released ) : ?><span class="tutorhelper-lms-quiz__result is-<?php echo esc_attr( $score['outcome'] ); ?>"><?php echo esc_html( 'pass' === $score['outcome'] ? __( 'Pass', 'tutorhelper-lms' ) : ( 'fail' === $score['outcome'] ? __( 'Fail', 'tutorhelper-lms' ) : __( 'Awaiting marking', 'tutorhelper-lms' ) ) ); ?></span><?php else : ?><span class="tutorhelper-lms-quiz__result is-pending"><?php esc_html_e( 'Awaiting release', 'tutorhelper-lms' ); ?></span><?php endif; ?></td>
							<td><?php if ( $released ) : ?><a class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--secondary" href="<?php echo esc_url( add_query_arg( 'tutorhelper_lms_quiz_attempt', absint( $attempt->id ), self::quiz_url( $base_url, $course_id, $placement->id, $student_user_id ) ) ); ?>"><?php esc_html_e( 'View feedback', 'tutorhelper-lms' ); ?></a><?php else : ?><span><?php esc_html_e( 'Please wait', 'tutorhelper-lms' ); ?></span><?php endif; ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody></table>
				<?php $mastery = TutorHelper_LMS_Quiz_Attempts::question_mastery_summary( $student_user_id, absint( $placement->quiz_version_id ) ); ?>
				<?php if ( $mastery['total'] > 0 ) : ?>
					<section class="tutorhelper-lms-quiz__mastery" aria-labelledby="tutorhelper-lms-quiz-mastery-title">
						<h4 id="tutorhelper-lms-quiz-mastery-title"><?php esc_html_e( 'Your Question practice', 'tutorhelper-lms' ); ?></h4>
						<p><?php esc_html_e( 'Progress across all Questions in this Quiz.', 'tutorhelper-lms' ); ?></p>
						<div class="tutorhelper-lms-quiz__mastery-chart" role="img" aria-label="<?php echo esc_attr( sprintf( __( '%1$d mastered, %2$d attempted and %3$d unseen Questions.', 'tutorhelper-lms' ), $mastery['mastered'], $mastery['attempted'], $mastery['unseen'] ) ); ?>">
							<?php foreach ( array( 'mastered' => __( 'Mastered', 'tutorhelper-lms' ), 'attempted' => __( 'Attempted', 'tutorhelper-lms' ), 'unseen' => __( 'Unseen', 'tutorhelper-lms' ) ) as $state => $label ) : ?>
								<?php $count = absint( $mastery[ $state ] ); $height = max( 8, (int) round( ( $count / $mastery['total'] ) * 100 ) ); ?>
								<div class="tutorhelper-lms-quiz__mastery-column tutorhelper-lms-quiz__mastery-column--<?php echo esc_attr( $state ); ?>">
									<strong><?php echo esc_html( $count ); ?></strong>
									<span class="tutorhelper-lms-quiz__mastery-bar" style="height: <?php echo esc_attr( $height ); ?>%"></span>
									<span><?php echo esc_html( $label ); ?></span>
								</div>
							<?php endforeach; ?>
						</div>
					</section>
				<?php endif; ?>
				<?php if ( $draft ) : ?><p><a class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--primary" href="<?php echo esc_url( add_query_arg( 'tutorhelper_lms_quiz_new_attempt', '1', self::quiz_url( $base_url, $course_id, $placement->id, $student_user_id ) ) ); ?>"><?php esc_html_e( 'Resume saved attempt', 'tutorhelper-lms' ); ?></a></p><?php elseif ( $can_retake ) : ?><p><a class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--primary" href="<?php echo esc_url( add_query_arg( 'tutorhelper_lms_quiz_new_attempt', '1', self::quiz_url( $base_url, $course_id, $placement->id, $student_user_id ) ) ); ?>"><?php esc_html_e( 'Start a new attempt', 'tutorhelper-lms' ); ?></a></p><?php else : ?><p class="tutorhelper-lms-quiz__attempt-limit"><?php esc_html_e( 'You have submitted the maximum number of attempts for this Quiz.', 'tutorhelper-lms' ); ?></p><?php endif; ?>
			</article>
		</div>
		<?php
	}


	/**
	 * Calculate the Course grade for one Quiz score.
	 *
	 * @param int   $course_id Course ID.
	 * @param array $score Quiz score.
	 * @param array $snapshot Immutable attempt snapshot.
	 * @return array
	 */
	private static function quiz_grade_result( $course_id, $score, $snapshot ) {
		if ( ! class_exists( 'TutorHelper_LMS_Grade_Systems' ) || ! is_array( $score ) ) {
			return array();
		}
		$context = is_array( $snapshot['course_grading_context'] ?? null ) ? $snapshot['course_grading_context'] : array();
		return TutorHelper_LMS_Grade_Systems::grade_result_for_course( $course_id, $score['marks'] ?? 0, $score['available'] ?? 0, $context );
	}

	/**
	 * Format score, percentage and Course grade together.
	 *
	 * @param array $score Quiz score.
	 * @param array $grade_result Calculated Course grade.
	 * @return string
	 */
	private static function quiz_score_label( $score, $grade_result ) {
		$marks = absint( $score['marks'] ?? 0 );
		$available = absint( $score['available'] ?? 0 );
		$label = sprintf( _n( '%1$d / %2$d mark', '%1$d / %2$d marks', $available, 'tutorhelper-lms' ), $marks, $available );
		if ( class_exists( 'TutorHelper_LMS_Grade_Systems' ) ) {
			$grade_label = TutorHelper_LMS_Grade_Systems::grade_result_label( $grade_result );
			if ( '' !== $grade_label ) {
				$label .= ' · ' . $grade_label;
			}
		}
		return $label;
	}

	/**
	 * Apply Premium delivery only when the add-on is active.
	 *
	 * @param array $quiz Quiz version definition.
	 * @return string
	 */
	private static function quiz_delivery_mode( $quiz ) {
		$mode = sanitize_key( $quiz['delivery_mode'] ?? 'all' );
		return class_exists( 'TutorHelper_LMS_Premium' ) && TutorHelper_LMS_Premium::is_available() && in_array( $mode, array( 'question', 'section' ), true ) ? $mode : 'all';
	}

	/**
	 * Group Questions into Core all-at-once, Premium single-question, or named sections.
	 *
	 * @param array  $questions Attempt Question snapshot.
	 * @param string $mode Delivery mode.
	 * @return array
	 */
	private static function quiz_delivery_groups( $questions, $mode ) {
		if ( 'all' === $mode ) {
			return array( array( 'title' => '', 'indexes' => array_keys( $questions ) ) );
		}
		if ( 'question' === $mode ) {
			$groups = array();
			foreach ( array_keys( $questions ) as $index ) {
				$groups[] = array( 'title' => '', 'indexes' => array( $index ) );
			}
			return $groups;
		}
		$groups = array();
		$current_title = '';
		foreach ( $questions as $index => $question ) {
			$settings = json_decode( (string) ( $question['settings_json'] ?? '' ), true );
			$title = is_array( $settings ) ? sanitize_text_field( $settings['section'] ?? '' ) : '';
			$title = '' !== $title ? $title : __( 'Untitled section', 'tutorhelper-lms' );
			if ( $title !== $current_title ) {
				$groups[] = array( 'title' => $title, 'indexes' => array() );
				$current_title = $title;
			}
			$groups[ count( $groups ) - 1 ]['indexes'][] = $index;
		}
		return $groups;
	}

	/**
	 * Render the Premium learning-journey style Question progress tracker.
	 *
	 * @param array  $groups Delivery groups.
	 * @param int    $current_page Current group.
	 * @param string $mode Delivery mode.
	 * @param array  $responses Draft responses.
	 * @param array  $questions Snapshot questions.
	 * @return void
	 */
	private static function render_quiz_progress_tracker( $groups, $current_page, $mode, $responses, $questions ) {
		if ( 'all' === $mode || ! class_exists( 'TutorHelper_LMS_Journey_Themes' ) ) {
			return;
		}
		$theme = TutorHelper_LMS_Journey_Themes::manifest();
		if ( empty( $theme['is_complete'] ) ) {
			return;
		}
		?>
		<ol class="tutorhelper-lms-quiz__progress" aria-label="<?php esc_attr_e( 'Quiz progress', 'tutorhelper-lms' ); ?>">
			<?php foreach ( $groups as $index => $group ) : ?>
				<?php $position = $index + 1; $key = $position === $current_page ? 'lesson_current' : ( $position < $current_page ? 'lesson_complete' : 'lesson_not_started' ); ?>
				<li class="<?php echo $position === $current_page ? 'is-current' : ( $position < $current_page ? 'is-complete' : '' ); ?>"><img src="<?php echo esc_url( $theme['assets'][ $key ]['url'] ); ?>" alt="" /><span class="screen-reader-text"><?php echo esc_html( sprintf( __( '%1$s %2$d of %3$d', 'tutorhelper-lms' ), 'section' === $mode ? __( 'Section', 'tutorhelper-lms' ) : __( 'Question', 'tutorhelper-lms' ), $position, count( $groups ) ) ); ?></span></li>
			<?php endforeach; ?>
		</ol>
		<?php
	}

	/**
	 * Render the correct interactive response control for a Core Question model.
	 *
	 * @param int    $attempt_id Attempt ID.
	 * @param int    $question_id Question ID.
	 * @param array  $definition Pinned Question definition.
	 * @param string $type Question type.
	 * @param mixed  $answer Saved response.
	 * @return void
	 */
	private static function render_quiz_question_response( $attempt_id, $question_id, $definition, $type, $answer ) {
		$custom_response = apply_filters( 'tutorhelper_lms_quiz_question_response_html', '', $attempt_id, $question_id, $definition, $type, $answer );
		if ( is_string( $custom_response ) && '' !== $custom_response ) {
			echo $custom_response; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted extension markup must retain learner form controls.
			return;
		}
		$answers = is_array( $definition['answers'] ?? null ) ? $definition['answers'] : array();
		if ( in_array( $type, array( 'single_choice', 'multiple_choice' ), true ) && ! empty( $answers['options'] ) ) {
			foreach ( $answers['options'] as $option_index => $option ) {
				?><label><input type="<?php echo 'multiple_choice' === $type ? 'checkbox' : 'radio'; ?>" name="response[<?php echo esc_attr( $question_id ); ?>]<?php echo 'multiple_choice' === $type ? '[]' : ''; ?>" value="<?php echo esc_attr( $option_index ); ?>" <?php checked( 'multiple_choice' === $type ? in_array( (string) $option_index, array_map( 'strval', is_array( $answer ) ? $answer : array() ), true ) : (string) $option_index === (string) $answer ); ?> /> <?php echo esc_html( $option ); ?></label><br /><?php
			}
			return;
		}
		if ( 'free_answer' === $type ) {
			?><label class="screen-reader-text" for="<?php echo esc_attr( 'tutorhelper-lms-quiz-response-' . $question_id ); ?>"><?php esc_html_e( 'Your answer', 'tutorhelper-lms' ); ?></label><input class="tutorhelper-lms-quiz__short-answer" id="<?php echo esc_attr( 'tutorhelper-lms-quiz-response-' . $question_id ); ?>" type="text" autocomplete="off" name="response[<?php echo esc_attr( $question_id ); ?>]" value="<?php echo esc_attr( $answer ); ?>" /><?php
			return;
		}
		if ( 'sort_answer' === $type ) {
			$items = self::response_array( $answer );
			$items = $items ? $items : self::seeded_shuffle( is_array( $answers['items'] ?? null ) ? $answers['items'] : array(), $attempt_id . ':' . $question_id );
			?><input type="hidden" name="response[<?php echo esc_attr( $question_id ); ?>]" value="<?php echo esc_attr( wp_json_encode( $items ) ); ?>" data-tutorhelper-lms-sort-response /><ul class="tutorhelper-lms-quiz__sortable" data-tutorhelper-lms-sort-list><?php foreach ( $items as $item ) : ?><li draggable="true" data-tutorhelper-lms-sort-item><span class="dashicons dashicons-move" aria-hidden="true"></span><?php echo esc_html( $item ); ?></li><?php endforeach; ?></ul><p class="description"><?php esc_html_e( 'Drag the boxes into the correct order.', 'tutorhelper-lms' ); ?></p><?php
			return;
		}
		if ( 'matrix_sort' === $type ) {
			$pairs = is_array( $answers['pairs'] ?? null ) ? $answers['pairs'] : array();
			$right = self::seeded_shuffle( array_values( wp_list_pluck( $pairs, 'right' ) ), $attempt_id . ':matrix:' . $question_id );
			$saved = self::response_array( $answer );
			?><input type="hidden" name="response[<?php echo esc_attr( $question_id ); ?>]" value="<?php echo esc_attr( wp_json_encode( $saved ) ); ?>" data-tutorhelper-lms-match-response /><div class="tutorhelper-lms-quiz__matching" data-tutorhelper-lms-matching><div class="tutorhelper-lms-quiz__matching-bank" data-tutorhelper-lms-match-bank><?php foreach ( $right as $item ) : ?><span class="tutorhelper-lms-quiz__match-token" draggable="true" data-tutorhelper-lms-match-token><span class="dashicons dashicons-move" aria-hidden="true"></span><?php echo esc_html( $item ); ?></span><?php endforeach; ?></div><?php foreach ( $pairs as $pair_index => $pair ) : ?><div class="tutorhelper-lms-quiz__match-row"><strong><?php echo esc_html( $pair['left'] ?? '' ); ?></strong><span class="tutorhelper-lms-quiz__match-target" data-tutorhelper-lms-match-target data-left="<?php echo esc_attr( $pair_index ); ?>"><?php echo esc_html( $saved[ $pair_index ] ?? '' ); ?></span></div><?php endforeach; ?></div><p class="description"><?php esc_html_e( 'Drag each answer into the matching row.', 'tutorhelper-lms' ); ?></p><?php
			return;
		}
		if ( 'cloze' === $type ) {
			$prompt = wpautop( wp_kses_post( (string) ( $definition['prompt'] ?? '' ) ) );
			$values = is_array( $answer ) ? $answer : array();
			$prompt = preg_replace_callback(
				'/\{\{(\d+)\}\}/',
				static function ( $matches ) use ( $question_id, $values ) {
					$number = absint( $matches[1] );
					return '<label class="screen-reader-text" for="' . esc_attr( 'tutorhelper-lms-cloze-' . $question_id . '-' . $number ) . '">' . esc_html( sprintf( __( 'Blank %d', 'tutorhelper-lms' ), $number ) ) . '</label><input id="' . esc_attr( 'tutorhelper-lms-cloze-' . $question_id . '-' . $number ) . '" class="tutorhelper-lms-quiz__cloze-input" type="text" autocomplete="off" name="response[' . esc_attr( $question_id ) . '][' . esc_attr( $number ) . ']" value="' . esc_attr( $values[ $number ] ?? '' ) . '" />';
				},
				$prompt
			);
			echo '<div class="tutorhelper-lms-quiz__cloze">' . $prompt . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Question HTML is sanitised before safe input elements are injected.
			return;
		}
		if ( 'assessment' === $type ) {
			$min = absint( $definition['settings']['scale_min'] ?? 1 ); $max = max( $min, absint( $definition['settings']['scale_max'] ?? 5 ) );
			?><label><?php esc_html_e( 'Your response', 'tutorhelper-lms' ); ?> <select name="response[<?php echo esc_attr( $question_id ); ?>]"><option value=""><?php esc_html_e( 'Choose an option', 'tutorhelper-lms' ); ?></option><?php for ( $score = $min; $score <= $max; $score++ ) : ?><option value="<?php echo esc_attr( $score ); ?>" <?php selected( (string) $score, (string) $answer ); ?>><?php echo esc_html( $score ); ?></option><?php endfor; ?></select></label><?php
			return;
		}
		?><label class="screen-reader-text" for="<?php echo esc_attr( 'tutorhelper-lms-quiz-response-' . $question_id ); ?>"><?php esc_html_e( 'Your answer', 'tutorhelper-lms' ); ?></label><textarea id="<?php echo esc_attr( 'tutorhelper-lms-quiz-response-' . $question_id ); ?>" name="response[<?php echo esc_attr( $question_id ); ?>]" rows="4"><?php echo esc_textarea( is_array( $answer ) ? implode( "\n", $answer ) : $answer ); ?></textarea><?php
	}

	private static function response_array( $answer ) {
		if ( is_array( $answer ) ) { return array_values( $answer ); }
		$value = json_decode( (string) $answer, true );
		return is_array( $value ) ? array_values( $value ) : array();
	}

	private static function seeded_shuffle( $items, $seed ) {
		$items = array_values( array_filter( (array) $items, 'is_scalar' ) );
		usort( $items, static function ( $left, $right ) use ( $seed ) { return strcmp( md5( $seed . '|' . $left ), md5( $seed . '|' . $right ) ); } );
		return $items;
	}

	/**
	 * Render a standalone, authorised Course menu for an enrolled learner.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param string $base_url Parent learning URL.
	 * @return void
	 */
	private static function render_course_menu_reader( $student_user_id, $course_id, $base_url ) {
		if ( ! self::can_view_course( $student_user_id, $course_id ) ) {
			status_header( 403 );
			self::render_reader_link_unavailable( $base_url );
			return;
		}
		$course = get_post( $course_id );
		if ( ! $course || 'tutorhelper_course' !== $course->post_type || 'publish' !== $course->post_status ) {
			status_header( 404 );
			self::render_reader_link_unavailable( $base_url );
			return;
		}
		if ( self::requested_id( self::COURSE_COMPLETE_QUERY ) ) {
			self::render_course_complete_screen( $student_user_id, $course_id, $base_url );
			return;
		}
		$topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
		$topic_count = count( $topics );
		$topics_per_page = 10;
		$topic_page = max( 1, self::requested_id( self::COURSE_PAGE_QUERY ) );
		$total_topic_pages = max( 1, (int) ceil( $topic_count / $topics_per_page ) );
		$topic_page = min( $topic_page, $total_topic_pages );
		$topic_offset = ( $topic_page - 1 ) * $topics_per_page;
		$page_topics = array_slice( $topics, $topic_offset, $topics_per_page );
		?>
		<div class="tutorhelper-lms-textbook tutorhelper-lms-textbook--course-menu" data-tutorhelper-lms-course-overview data-course-key="<?php echo esc_attr( 'course-' . $course_id ); ?>">
			<nav class="tutorhelper-lms-course-overview__breadcrumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'tutorhelper-lms' ); ?>">
				<a href="<?php echo esc_url( remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::READER_QUERY, self::COURSE_READER_QUERY, self::PAGE_QUERY ), $base_url ) ); ?>">&larr; <?php esc_html_e( 'My Learning', 'tutorhelper-lms' ); ?></a>
				<span aria-hidden="true">&rsaquo;</span>
				<span aria-current="page"><?php echo esc_html( get_the_title( $course_id ) ); ?></span>
			</nav>
			<article class="tutorhelper-lms-course-overview__reader">
				<header class="tutorhelper-lms-course-overview__hero">
					<div class="tutorhelper-lms-course-overview__hero-heading">
						<div>
							<p class="tutorhelper-lms-textbook__eyebrow"><?php esc_html_e( 'TutorHelper LMS · My Course', 'tutorhelper-lms' ); ?></p>
							<h3><?php echo esc_html( get_the_title( $course_id ) ); ?></h3>
						</div>
						<button type="button" class="tutorhelper-lms-course-overview__expand" data-tutorhelper-lms-expand-course aria-pressed="false"><?php esc_html_e( 'Expand course view', 'tutorhelper-lms' ); ?></button>
					</div>
					<p><?php echo esc_html( $course->post_excerpt ? $course->post_excerpt : __( 'Explore topics and lessons, continue studying or revisit something you have already learned.', 'tutorhelper-lms' ) ); ?></p>
					<div class="tutorhelper-lms-course-overview__meta">
						<span><?php echo esc_html( sprintf( _n( '%d Topic', '%d Topics', $topic_count, 'tutorhelper-lms' ), $topic_count ) ); ?></span>
						<span><?php esc_html_e( 'Course', 'tutorhelper-lms' ); ?></span>
					</div>
				</header>
				<?php do_action( 'tutorhelper_lms_learner_course_view_before_list', $student_user_id, $course_id, $base_url, $topics ); ?>
				<div class="tutorhelper-lms-course-overview__core-list" data-tutorhelper-lms-core-course-list>
					<div class="tutorhelper-lms-course-overview__controls">
						<button type="button" data-tutorhelper-lms-expand-topics><?php esc_html_e( 'Expand all topics', 'tutorhelper-lms' ); ?></button>
						<button type="button" data-tutorhelper-lms-collapse-topics><?php esc_html_e( 'Collapse all topics', 'tutorhelper-lms' ); ?></button>
					</div>
					<?php self::render_course_topics_accordion( $student_user_id, $course_id, $base_url, $page_topics, $topic_offset, $topic_page ); ?>
					<?php self::render_course_topic_pagination( $course_id, $base_url, $topic_page, $total_topic_pages ); ?>
				</div>
			</article>
		</div>
		<?php
	}

	/**
	 * Render a simple, Core-only end-of-Course confirmation.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param string $base_url Parent learning URL.
	 * @return void
	 */
	private static function render_course_complete_screen( $student_user_id, $course_id, $base_url ) {
		$progress = class_exists( 'TutorHelper_LMS_Learner_Progress' ) ? TutorHelper_LMS_Learner_Progress::course_progress( $student_user_id, $course_id ) : array( 'complete' => 0, 'total' => 0, 'percent' => 0 );
		?>
		<div class="tutorhelper-lms-textbook tutorhelper-lms-textbook--course-complete">
			<p><a class="tutorhelper-lms-learning__back" href="<?php echo esc_url( remove_query_arg( array( self::COURSE_COMPLETE_QUERY, self::COURSE_PAGE_QUERY ), $base_url ) ); ?>">&larr; <?php esc_html_e( 'Back to My Learning', 'tutorhelper-lms' ); ?></a></p>
			<section class="tutorhelper-lms-course-complete" aria-labelledby="tutorhelper-lms-course-complete-title">
				<p class="tutorhelper-lms-textbook__eyebrow"><?php esc_html_e( 'Course complete', 'tutorhelper-lms' ); ?></p>
				<h3 id="tutorhelper-lms-course-complete-title"><?php echo esc_html( get_the_title( $course_id ) ); ?></h3>
				<p><?php esc_html_e( 'You have completed every Lesson currently included in this Course.', 'tutorhelper-lms' ); ?></p>
				<p class="tutorhelper-lms-course-complete__progress"><?php echo esc_html( sprintf( _n( '%1$d of %2$d Lesson complete', '%1$d of %2$d Lessons complete', $progress['total'], 'tutorhelper-lms' ), $progress['complete'], $progress['total'] ) ); ?></p>
				<p><a class="tutorhelper-student-booking-notice__action" href="<?php echo esc_url( self::course_url( $base_url, $course_id, $student_user_id ) ); ?>"><?php esc_html_e( 'Review Course', 'tutorhelper-lms' ); ?></a></p>
			</section>
		</div>
		<?php
	}

	/**
	 * Render ordered Course Topics as accessible, progressively enhanced cards.
	 *
	 * Lesson links are created only from the current authorised Course structure.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param string $base_url Parent learning URL.
	 * @param array  $topics Authorised Topics in Course order.
	 * @return void
	 */
	private static function render_course_topics_accordion( $student_user_id, $course_id, $base_url, $topics, $topic_offset = 0, $topic_page = 1 ) {
		if ( empty( $topics ) ) {
			echo '<p class="tutorhelper-lms-course-overview__empty">' . esc_html__( 'Your tutor has not added any Course topics yet.', 'tutorhelper-lms' ) . '</p>';
			return;
		}
		?>
		<ol class="tutorhelper-lms-course-overview__topic-list">
			<?php foreach ( $topics as $index => $topic ) : ?>
				<?php
				$topic_id = absint( $topic['id'] ?? 0 );
				$activities = $topic_id ? self::course_topic_activities( $course_id, $topic_id ) : array();
				$topic_number = absint( $topic_offset ) + $index + 1;
				$panel_id = 'tutorhelper-lms-course-topic-' . $topic_number;
				?>
				<li class="tutorhelper-lms-course-overview__topic-card" data-tutorhelper-lms-topic-card data-topic-key="<?php echo esc_attr( 'topic-' . $topic_number ); ?>">
					<button type="button" class="tutorhelper-lms-course-overview__topic-toggle" aria-expanded="false" aria-controls="<?php echo esc_attr( $panel_id ); ?>" data-tutorhelper-lms-topic-toggle>
						<span class="tutorhelper-lms-course-overview__topic-accent" aria-hidden="true"></span>
						<span class="tutorhelper-lms-course-overview__topic-title"><?php echo esc_html( sprintf( __( '%1$d. %2$s', 'tutorhelper-lms' ), $topic_number, $topic['title'] ?? '' ) ); ?></span>
						<span class="tutorhelper-lms-course-overview__topic-count"><?php echo esc_html( sprintf( _n( '%d activity', '%d activities', count( $activities ), 'tutorhelper-lms' ), count( $activities ) ) ); ?></span>
						<span class="tutorhelper-lms-course-overview__topic-icon" aria-hidden="true"></span>
					</button>
					<div id="<?php echo esc_attr( $panel_id ); ?>" class="tutorhelper-lms-course-overview__lesson-list" data-tutorhelper-lms-topic-panel>
						<?php if ( empty( $activities ) ) : ?>
							<p><?php esc_html_e( 'There are no activities in this Topic yet.', 'tutorhelper-lms' ); ?></p>
						<?php else : ?>
							<ol>
								<?php foreach ( $activities as $activity ) : ?>
									<?php
									$is_side_quest = empty( $activity['required'] );
									$is_quiz = 'quiz' === $activity['type'];
									$unlocked = $is_quiz ? self::can_view_quiz( $student_user_id, $course_id, $activity['placement_id'] ) : self::can_view_lesson( $student_user_id, $course_id, $topic_id, $activity['id'] );
									$available_from = apply_filters( 'tutorhelper_lms_activity_available_from_label', '', $course_id, $topic_id, $activity['type'], $activity['id'] );
									$link = $is_quiz ? self::quiz_url( $base_url, $course_id, $activity['placement_id'], $student_user_id ) : self::lesson_url( $base_url, $course_id, $topic_id, $activity['id'], 0, $student_user_id );
									?>
									<li class="<?php echo esc_attr( ( $is_quiz ? 'tutorhelper-lms-course-overview__quiz' : '' ) . ( $is_side_quest ? ' is-side-quest' : '' ) . ( $unlocked ? '' : ' is-locked' ) ); ?>">
										<?php if ( $unlocked ) : ?><a href="<?php echo esc_url( add_query_arg( self::COURSE_PAGE_QUERY, absint( $topic_page ), $link ) ); ?>#<?php echo esc_attr( 'topic-' . $topic_number ); ?>"><?php else : ?><span aria-disabled="true"><?php endif; ?>
											<span class="tutorhelper-lms-course-overview__lesson-icon" aria-hidden="true"></span><span class="tutorhelper-lms-course-overview__activity-title"><?php echo esc_html( $activity['title'] ); ?><?php if ( $available_from ) : ?><span class="tutorhelper-lms-course-overview__available-from"><?php echo esc_html( $available_from ); ?></span><?php endif; ?><?php if ( $is_side_quest ) : ?><span class="tutorhelper-lms-course-overview__side-quest-label"><?php esc_html_e( 'Side quest · optional', 'tutorhelper-lms' ); ?></span><?php endif; ?></span>
											<?php if ( ! $unlocked ) : ?><span class="tutorhelper-lms-course-overview__locked-icon" aria-hidden="true" title="<?php esc_attr_e( 'Locked — complete the previous activity', 'tutorhelper-lms' ); ?>">🔒</span><span class="screen-reader-text"><?php esc_html_e( 'Locked — complete the previous activity', 'tutorhelper-lms' ); ?></span><?php endif; ?>
											<?php if ( $unlocked ) : ?><span class="screen-reader-text"> <?php echo esc_html( $is_quiz ? __( 'Open Quiz', 'tutorhelper-lms' ) : __( 'Open Lesson', 'tutorhelper-lms' ) ); ?></span><span class="tutorhelper-lms-course-overview__lesson-arrow" aria-hidden="true">&rsaquo;</span><?php endif; ?>
										<?php echo $unlocked ? '</a>' : '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup chosen above. ?>
									</li>
								<?php endforeach; ?>
							</ol>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ol>
		<?php
	}

	/**
	 * Render compact server-side Course Topic pagination when needed.
	 *
	 * @param int    $course_id Course ID.
	 * @param string $base_url Parent learning URL.
	 * @param int    $current_page Current Topic page.
	 * @param int    $total_pages Total Topic pages.
	 * @return void
	 */
	private static function render_course_topic_pagination( $course_id, $base_url, $current_page, $total_pages ) {
		if ( $total_pages < 2 ) {
			return;
		}
		?>
		<nav class="tutorhelper-lms-course-overview__pagination" aria-label="<?php esc_attr_e( 'Course Topic pages', 'tutorhelper-lms' ); ?>">
			<?php if ( $current_page > 1 ) : ?><a href="<?php echo esc_url( add_query_arg( self::COURSE_PAGE_QUERY, $current_page - 1, self::course_url( $base_url, $course_id ) ) ); ?>">&larr; <?php esc_html_e( 'Previous Topics', 'tutorhelper-lms' ); ?></a><?php endif; ?>
			<span><?php echo esc_html( sprintf( __( 'Topics page %1$d of %2$d', 'tutorhelper-lms' ), $current_page, $total_pages ) ); ?></span>
			<?php if ( $current_page < $total_pages ) : ?><a href="<?php echo esc_url( add_query_arg( self::COURSE_PAGE_QUERY, $current_page + 1, self::course_url( $base_url, $course_id ) ) ); ?>"><?php esc_html_e( 'Next Topics', 'tutorhelper-lms' ); ?> &rarr;</a><?php endif; ?>
		</nav>
		<?php
	}

	/**
	 * Render the current Course’s ordered Topic/Lesson outline.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param string $base_url Parent learning URL.
	 * @param bool   $expanded Whether the standalone Course menu should be open.
	 * @return void
	 */
	private static function render_course_outline( $student_user_id, $course_id, $base_url, $expanded = false ) {
		$topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
		?>
		<details class="tutorhelper-lms-textbook__course-menu" <?php echo $expanded ? 'open' : ''; ?>>
			<summary><?php esc_html_e( 'Course menu', 'tutorhelper-lms' ); ?></summary>
			<?php if ( empty( $topics ) ) : ?>
				<p><?php esc_html_e( 'Your tutor has not added any Course activities yet.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<ol>
					<?php foreach ( $topics as $topic ) : $topic_id = absint( $topic['id'] ?? 0 ); $activities = self::course_topic_activities( $course_id, $topic_id ); ?>
						<li><strong><?php echo esc_html( $topic['title'] ?? '' ); ?></strong>
							<?php if ( $activities ) : ?><ol><?php foreach ( $activities as $activity ) : $is_quiz = 'quiz' === ( $activity['type'] ?? '' ); $unlocked = $is_quiz ? self::can_view_quiz( $student_user_id, $course_id, absint( $activity['placement_id'] ?? 0 ) ) : self::can_view_lesson( $student_user_id, $course_id, $topic_id, absint( $activity['id'] ?? 0 ) ); ?>
								<li><?php if ( $unlocked ) : ?><a href="<?php echo esc_url( $is_quiz ? self::quiz_url( $base_url, $course_id, absint( $activity['placement_id'] ?? 0 ), $student_user_id ) : self::lesson_url( $base_url, $course_id, $topic_id, absint( $activity['id'] ?? 0 ), 0, $student_user_id ) ); ?>"><?php echo esc_html( $activity['title'] ?? '' ); ?></a><?php else : ?><span aria-disabled="true"><?php echo esc_html( $activity['title'] ?? '' ); ?> <span aria-hidden="true" title="<?php esc_attr_e( 'Locked — complete the previous activity', 'tutorhelper-lms' ); ?>">🔒</span><span class="screen-reader-text"><?php esc_html_e( 'Locked — complete the previous activity', 'tutorhelper-lms' ); ?></span></span><?php endif; ?></li>
							<?php endforeach; ?></ol><?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ol>
			<?php endif; ?>
		</details>
		<?php
	}
	/**
	 * Render a Lesson only after resolving the complete student context.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @param int    $lesson_id Lesson ID.
	 * @param string $base_url Parent page URL.
	 * @return void
	 */
	private static function render_lesson_viewer( $student_user_id, $course_id, $topic_id, $lesson_id, $page_number, $base_url, $reader_token = '' ) {
		if ( ! self::can_view_lesson( $student_user_id, $course_id, $topic_id, $lesson_id ) ) {
			status_header( 403 );
			echo '<div class="tutorhelper-lms-learning__denied" role="alert"><p>' . esc_html__( 'You do not have access to this Lesson.', 'tutorhelper-lms' ) . '</p><p><a class="tutorhelper-student-booking-notice__action" href="' . esc_url( remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::PAGE_QUERY ), $base_url ) ) . '">' . esc_html__( 'Return to My Courses', 'tutorhelper-lms' ) . '</a></p></div>';
			return;
		}

		if ( self::can_view_course( $student_user_id, $course_id ) ) {
			do_action( 'tutorhelper_lms_learner_lesson_viewed', $student_user_id, $course_id, $topic_id, $lesson_id );
		}

		$lesson = get_post( $lesson_id );
		if ( ! $lesson || 'tutorhelper_lesson' !== $lesson->post_type || 'publish' !== $lesson->post_status ) {
			status_header( 404 );
			echo '<div class="tutorhelper-lms-learning__denied" role="alert"><p>' . esc_html__( 'This Lesson is not currently available.', 'tutorhelper-lms' ) . '</p></div>';
			return;
		}

		$pages = self::lesson_pages( $lesson );
		$total_pages = count( $pages );
		$page_number = min( max( 1, absint( $page_number ) ), $total_pages );
		$page = $pages[ $page_number - 1 ];
		$back_url = self::can_view_course( $student_user_id, $course_id ) ? self::course_url( $base_url, $course_id, $student_user_id ) : remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::READER_QUERY, self::COURSE_READER_QUERY, self::PAGE_QUERY ), $base_url );
		$reader_mode = self::reader_display_mode( $student_user_id );
		?>
		<div class="tutorhelper-lms-textbook">
			<p><a class="tutorhelper-lms-learning__back" href="<?php echo esc_url( $back_url ); ?>">&larr; <?php esc_html_e( 'Back to My Learning', 'tutorhelper-lms' ); ?></a></p>
			<article class="tutorhelper-lms-textbook__reader is-view-<?php echo esc_attr( $reader_mode ); ?>" data-tutorhelper-lms-reader-modes>
				<header class="tutorhelper-lms-textbook__header">
					<div>
						<p class="tutorhelper-lms-textbook__eyebrow"><?php esc_html_e( 'TutorHelper LMS · My Textbook', 'tutorhelper-lms' ); ?></p>
						<nav class="tutorhelper-lms-textbook__breadcrumbs" aria-label="<?php esc_attr_e( 'Lesson location', 'tutorhelper-lms' ); ?>">
							<?php if ( self::can_view_course( $student_user_id, $course_id ) ) : ?><a href="<?php echo esc_url( self::course_url( $base_url, $course_id, $student_user_id ) ); ?>"><?php echo esc_html( get_the_title( $course_id ) ); ?></a><span aria-hidden="true">&rsaquo;</span><?php endif; ?>
							<span><?php echo esc_html( get_the_title( $topic_id ) ); ?></span><span aria-hidden="true">&rsaquo;</span><span aria-current="page"><?php echo esc_html( get_the_title( $lesson_id ) ); ?></span>
						</nav>
						<h3><?php echo esc_html( get_the_title( $lesson_id ) ); ?></h3>
						<p class="tutorhelper-lms-textbook__context"><?php echo esc_html( html_entity_decode( get_the_title( $topic_id ), ENT_QUOTES, get_bloginfo( 'charset' ) ) . ' · ' . html_entity_decode( get_the_title( $course_id ), ENT_QUOTES, get_bloginfo( 'charset' ) ) ); ?></p>
					</div>
					<span class="tutorhelper-lms-textbook__status"><?php esc_html_e( 'Ready to read', 'tutorhelper-lms' ); ?></span>
				</header>
				<div class="tutorhelper-lms-textbook__view-controls" role="group" aria-label="<?php esc_attr_e( 'Reading view', 'tutorhelper-lms' ); ?>">
					<button type="button" data-tutorhelper-lms-reader-mode="all" aria-pressed="<?php echo 'all' === $reader_mode ? 'true' : 'false'; ?>"><?php esc_html_e( 'Navigation mode', 'tutorhelper-lms' ); ?></button>
					<button type="button" data-tutorhelper-lms-reader-mode="reading" aria-pressed="<?php echo 'reading' === $reader_mode ? 'true' : 'false'; ?>"><?php esc_html_e( 'Reading mode', 'tutorhelper-lms' ); ?></button>
					<button type="button" data-tutorhelper-lms-reader-mode="notes" aria-pressed="<?php echo 'notes' === $reader_mode ? 'true' : 'false'; ?>"><?php esc_html_e( 'Notes mode', 'tutorhelper-lms' ); ?></button>
					<span class="screen-reader-text" aria-live="polite" data-tutorhelper-lms-reader-mode-status></span>
				</div>
				<div data-tutorhelper-lms-progress-region><?php do_action( 'tutorhelper_lms_learner_reader_controls', $student_user_id, $course_id, $topic_id, $lesson_id, $reader_token, $page_number, $total_pages ); ?></div>

				<?php if ( class_exists( 'TutorHelper_LMS_Learner_Annotations' ) ) : ?>
					<?php TutorHelper_LMS_Learner_Annotations::render_toolbar(); ?>
				<?php endif; ?>

				<div class="tutorhelper-lms-textbook__reader-layout">
					<?php if ( self::can_view_course( $student_user_id, $course_id ) ) : self::render_course_outline( $student_user_id, $course_id, $base_url ); endif; ?>
					<div class="tutorhelper-lms-textbook__workspace">
					<div class="tutorhelper-lms-textbook__lesson" data-tutorhelper-lms-page-region>
						<?php self::render_lesson_page_region( $lesson_id, $page, $page_number, $total_pages, $base_url, $course_id, $topic_id, $student_user_id, $reader_token ); ?>
					</div>
					<?php if ( $reader_token && class_exists( 'TutorHelper_LMS_Learner_Notes' ) ) : ?>
						<?php TutorHelper_LMS_Learner_Notes::render_panel( $student_user_id, $course_id, $topic_id, $lesson_id, 'lesson', $reader_token, add_query_arg( array( self::READER_QUERY => $reader_token, self::PAGE_QUERY => $page_number ), $base_url ) ); ?>
					<?php endif; ?>
					</div>
				</div>
			</article>
		</div>
		<?php
	}

	/**
	 * Render the swappable Lesson-page region without replacing Lesson notes.
	 *
	 * @param int    $lesson_id Lesson ID.
	 * @param array  $page Current page data.
	 * @param int    $page_number Current one-based page number.
	 * @param int    $total_pages Total page count.
	 * @param string $base_url Reader base URL.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @param int    $student_user_id Student user ID.
	 * @return void
	 */
	private static function render_lesson_page_region( $lesson_id, $page, $page_number, $total_pages, $base_url, $course_id, $topic_id, $student_user_id, $reader_token = '' ) {
		?>
		<section class="tutorhelper-lms-textbook__page" aria-labelledby="tutorhelper-lms-textbook-page-title">
			<div class="tutorhelper-lms-textbook__page-meta">
				<span><?php esc_html_e( 'Lesson', 'tutorhelper-lms' ); ?></span>
				<span><?php
					/* translators: 1: current page number, 2: total page count. */
					echo esc_html( sprintf( __( 'Page %1$d of %2$d', 'tutorhelper-lms' ), $page_number, $total_pages ) );
					?></span>
			</div>
			<?php if ( 1 === $page_number && has_post_thumbnail( $lesson_id ) ) : ?>
				<div class="tutorhelper-lms-textbook__featured-image"><?php echo wp_kses_post( get_the_post_thumbnail( $lesson_id, 'large' ) ); ?></div>
			<?php endif; ?>
			<?php $annotations = class_exists( 'TutorHelper_LMS_Learner_Annotations' ) ? TutorHelper_LMS_Learner_Annotations::for_page( $student_user_id, $course_id, $topic_id, $lesson_id, $page['id'] ?? '' ) : array(); ?>
			<div id="tutorhelper-lms-textbook-page-title" class="tutorhelper-lms-textbook__content" data-tutorhelper-lms-annotation-content data-page-number="<?php echo esc_attr( $page_number ); ?>" data-annotations="<?php echo esc_attr( wp_json_encode( $annotations ) ); ?>"><?php echo self::lesson_content_html( $page['content'] ?? '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- lesson_content_html returns a restricted, allowed HTML set. ?></div>
		</section>
		<?php self::render_lesson_navigation( $base_url, $course_id, $topic_id, $lesson_id, $page_number, $total_pages, $student_user_id, $reader_token ); ?>
		<?php
	}

	/**
	 * Render only the requested, authorised Lesson page for asynchronous navigation.
	 *
	 * @param int    $lesson_id Lesson ID.
	 * @param int    $page_number Requested page number.
	 * @param string $base_url Reader base URL.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @param int    $student_user_id Student user ID.
	 * @return void
	 */
	private static function render_lesson_page_fragment( $lesson_id, $page_number, $base_url, $course_id, $topic_id, $student_user_id, $reader_token = '' ) {
		$lesson = get_post( $lesson_id );
		if ( ! $lesson || 'tutorhelper_lesson' !== $lesson->post_type || 'publish' !== $lesson->post_status ) {
			return;
		}
		$pages = self::lesson_pages( $lesson );
		$total_pages = count( $pages );
		$page_number = min( max( 1, absint( $page_number ) ), $total_pages );
		self::render_lesson_page_region( $lesson_id, $pages[ $page_number - 1 ], $page_number, $total_pages, $base_url, $course_id, $topic_id, $student_user_id, $reader_token );
	}

	/**
	 * Return one or more intact reading pages from native WordPress page breaks.
	 *
	 * Existing/imported content without a page-break delimiter intentionally
	 * remains one complete page. LJ2a stores no reading state, so the simple
	 * generated identifiers are not persisted yet.
	 *
	 * @param WP_Post $lesson Lesson post.
	 * @return array<int,array{id:string,content:string}>
	 */
	private static function lesson_pages( $lesson ) {
		$content = (string) $lesson->post_content;
		$parts = preg_split( '/<!--\\s*(?:wp:)?nextpage\\s*-->/i', $content );
		$parts = is_array( $parts ) ? $parts : array( $content );
		$pages = array();
		foreach ( $parts as $index => $part ) {
			if ( '' === trim( $part ) && count( $parts ) > 1 ) {
				continue;
			}
			$pages[] = array(
				'id'      => 1 === count( $parts ) ? 'source' : 'page-' . ( $index + 1 ),
				'content' => $part,
			);
		}
		return $pages ? array_values( $pages ) : array( array( 'id' => 'source', 'content' => '' ) );
	}

	/**
	 * Render trusted lesson content with oEmbed iframe support retained.
	 *
	 * @param string $content Page content.
	 * @return string
	 */
	private static function lesson_content_html( $content ) {
		$allowed = wp_kses_allowed_html( 'post' );
		$allowed['iframe'] = array(
			'src'             => true,
			'width'           => true,
			'height'          => true,
			'title'           => true,
			'frameborder'     => true,
			'allow'           => true,
			'allowfullscreen' => true,
			'loading'         => true,
			'referrerpolicy'  => true,
			'class'           => true,
			'style'           => true,
		);
		return wp_kses( apply_filters( 'the_content', $content ), $allowed );
	}

	/**
	 * Render accessible previous, next and direct page navigation.
	 *
	 * @param string $base_url Base learner URL.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @param int    $lesson_id Lesson ID.
	 * @param int    $page_number Current page number.
	 * @param int    $total_pages Total page count.
	 * @param int    $student_user_id Student user ID.
	 * @return void
	 */
	private static function render_lesson_navigation( $base_url, $course_id, $topic_id, $lesson_id, $page_number, $total_pages, $student_user_id, $reader_token = '' ) {
		?>
		<nav class="tutorhelper-lms-textbook__navigation" aria-label="<?php esc_attr_e( 'Lesson pages', 'tutorhelper-lms' ); ?>">
			<?php if ( 1 < $page_number ) : ?>
				<a class="tutorhelper-lms-textbook__nav-button is-previous" href="<?php echo esc_url( self::lesson_url( $base_url, $course_id, $topic_id, $lesson_id, $page_number - 1, $student_user_id ) ); ?>">&larr; <?php esc_html_e( 'Previous', 'tutorhelper-lms' ); ?></a>
			<?php else : ?>
				<span class="tutorhelper-lms-textbook__nav-button is-disabled" aria-disabled="true">&larr; <?php esc_html_e( 'Previous', 'tutorhelper-lms' ); ?></span>
			<?php endif; ?>

			<ol class="tutorhelper-lms-textbook__page-list">
				<?php for ( $page = 1; $page <= $total_pages; $page++ ) : ?>
					<li>
						<?php if ( $page === $page_number ) : ?>
							<span aria-current="page"><?php echo esc_html( $page ); ?></span>
						<?php else : ?>
							<a href="<?php echo esc_url( self::lesson_url( $base_url, $course_id, $topic_id, $lesson_id, $page, $student_user_id ) ); ?>"><span class="screen-reader-text"><?php
									/* translators: %d: lesson page number. */
									echo esc_html( sprintf( __( 'Page %d', 'tutorhelper-lms' ), $page ) );
									?></span><?php echo esc_html( $page ); ?></a>
						<?php endif; ?>
					</li>
				<?php endfor; ?>
			</ol>

			<?php if ( $page_number < $total_pages ) : ?>
				<a class="tutorhelper-lms-textbook__nav-button is-next" href="<?php echo esc_url( self::lesson_url( $base_url, $course_id, $topic_id, $lesson_id, $page_number + 1, $student_user_id ) ); ?>"><?php esc_html_e( 'Next', 'tutorhelper-lms' ); ?> &rarr;</a>
			<?php elseif ( $reader_token && class_exists( 'TutorHelper_LMS_Learner_Progress' ) && self::can_view_course( $student_user_id, $course_id ) ) : ?>
				<?php TutorHelper_LMS_Learner_Progress::render_navigation_action( $student_user_id, $course_id, $topic_id, $lesson_id, $page_number, $total_pages, $reader_token, $base_url ); ?>
			<?php else : ?>
				<span class="tutorhelper-lms-textbook__nav-button is-disabled" aria-disabled="true"><?php esc_html_e( 'Next', 'tutorhelper-lms' ); ?> &rarr;</span>
			<?php endif; ?>
		</nav>
		<?php
	}


	/**
	 * Return the ordered learner activities for a Course Topic.
	 *
	 * The Course-owned activity order is authoritative; the legacy Lesson
	 * relationship is retained only as a backward-compatible fallback.
	 *
	 * @param int $course_id Course ID.
	 * @param int $topic_id Topic ID.
	 * @return array
	 */
	/** Return every current Course activity in its tutor-defined sequence. */
	private static function course_activities( $course_id ) {
		$activities = array();
		foreach ( apply_filters( 'tutorhelper_lms_course_topics', array(), absint( $course_id ) ) as $topic ) {
			$topic_id = absint( $topic['id'] ?? 0 );
			foreach ( self::course_topic_activities( $course_id, $topic_id ) as $activity ) {
				$activity['topic_id'] = $topic_id;
				$activities[] = $activity;
			}
		}
		return $activities;
	}

	/** Match an activity against a trusted Course context. */
	private static function activity_matches( $activity, $topic_id, $type, $activity_id, $placement_id = 0 ) {
		if ( absint( $activity['topic_id'] ?? 0 ) !== absint( $topic_id ) || sanitize_key( $activity['type'] ?? '' ) !== sanitize_key( $type ) || absint( $activity['id'] ?? 0 ) !== absint( $activity_id ) ) {
			return false;
		}
		return 'quiz' !== sanitize_key( $type ) || ! absint( $placement_id ) || absint( $activity['placement_id'] ?? 0 ) === absint( $placement_id );
	}

	/** Check whether a prior ordered activity has been completed by this learner. */
	private static function is_course_activity_complete( $student_user_id, $course_id, $activity ) {
		if ( 'lesson' === ( $activity['type'] ?? '' ) ) {
			return class_exists( 'TutorHelper_LMS_Learner_Progress' ) && TutorHelper_LMS_Learner_Progress::is_lesson_complete( $student_user_id, $course_id, absint( $activity['topic_id'] ?? 0 ), absint( $activity['id'] ?? 0 ) );
		}
		if ( 'quiz' !== ( $activity['type'] ?? '' ) || ! class_exists( 'TutorHelper_LMS_Quiz_Attempts' ) ) {
			return false;
		}
		foreach ( TutorHelper_LMS_Quiz_Attempts::attempts_for_placement( $student_user_id, absint( $activity['placement_id'] ?? 0 ) ) as $attempt ) {
			if ( 'completed' === (string) $attempt->status ) {
				return true;
			}
		}
		return false;
	}

	public static function course_topic_activities( $course_id, $topic_id ) {
		global $wpdb;
		$course_id = absint( $course_id );
		$topic_id = absint( $topic_id );
		$table = TutorHelper_LMS_Free_Database::table( 'course_topic_activities' );
		$placements = TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' );
		$rows = $table ? $wpdb->get_results( $wpdb->prepare( "SELECT activity_type, activity_id, is_required FROM {$table} WHERE course_id = %d AND topic_id = %d ORDER BY sort_order ASC, id ASC", $course_id, $topic_id ), ARRAY_A ) : array(); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads ordered Course activities for an authorised learner.
		$activities = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$type = sanitize_key( $row['activity_type'] ?? '' );
			$id = absint( $row['activity_id'] ?? 0 );
			if ( 'lesson' === $type && 'tutorhelper_lesson' === get_post_type( $id ) && 'publish' === get_post_status( $id ) ) {
				$activities[] = array( 'type' => 'lesson', 'id' => $id, 'title' => get_the_title( $id ), 'required' => ! isset( $row['is_required'] ) || (bool) absint( $row['is_required'] ) );
			} elseif ( 'quiz' === $type && $placements ) {
				$placement = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$placements} WHERE quiz_id = %d AND course_id = %d AND topic_id = %d", $id, $course_id, $topic_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Resolves the Course-owned Quiz placement.
				if ( $placement && 'publish' === get_post_status( absint( $placement->quiz_id ) ) ) {
					$activities[] = array( 'type' => 'quiz', 'id' => absint( $placement->quiz_id ), 'placement_id' => absint( $placement->id ), 'title' => get_the_title( absint( $placement->quiz_id ) ), 'required' => ! isset( $row['is_required'] ) || (bool) absint( $row['is_required'] ) );
				}
			}
		}
		if ( ! empty( $activities ) || ! empty( $rows ) ) {
			return $activities;
		}
		foreach ( self::topic_lessons( $topic_id ) as $lesson ) {
			$activities[] = array( 'type' => 'lesson', 'id' => absint( $lesson['id'] ), 'title' => $lesson['title'], 'required' => true );
		}
		return $activities;
	}

	/**
	 * Return a Quiz placement only when it belongs to the current Course.
	 *
	 * @param int $course_id Course ID.
	 * @param int $placement_id Placement ID.
	 * @return object|null
	 */
	private static function course_quiz_placement( $course_id, $placement_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' );
		return $table ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND course_id = %d", absint( $placement_id ), absint( $course_id ) ) ) : null; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Verifies a Course-scoped Quiz route.
	}

	/**
	 * Return ordered Lesson IDs and titles for one Topic.
	 *
	 * @param int $topic_id Topic ID.
	 * @return array
	 */
	private static function topic_lessons( $topic_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", 'tutorhelper_topic', absint( $topic_id ), 'tutorhelper_lesson' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads ordered reusable Lessons for an authorised Topic.
		$lessons = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$lesson_id = absint( $row->child_id );
			if ( 'tutorhelper_lesson' === get_post_type( $lesson_id ) ) {
				$lessons[] = array( 'id' => $lesson_id, 'title' => get_the_title( $lesson_id ) );
			}
		}
		return $lessons;
	}

	/**
	 * Return whether a Topic is attached to a Course.
	 *
	 * @param int $course_id Course ID.
	 * @param int $topic_id Topic ID.
	 * @return bool
	 */
	public static function course_has_topic( $course_id, $topic_id ) {
		foreach ( apply_filters( 'tutorhelper_lms_course_topics', array(), absint( $course_id ) ) as $topic ) {
			if ( absint( $topic['id'] ?? 0 ) === absint( $topic_id ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Return whether a Lesson is attached to a Topic.
	 *
	 * @param int $topic_id Topic ID.
	 * @param int $lesson_id Lesson ID.
	 * @return bool
	 */
	public static function topic_has_lesson( $topic_id, $lesson_id ) {
		foreach ( self::topic_lessons( $topic_id ) as $lesson ) {
			if ( absint( $lesson['id'] ) === absint( $lesson_id ) ) {
				return true;
			}
		}
		return false;
	}


	/**
	 * Create a short-lived, student-scoped Course menu token.
	 *
	 * @return string
	 */
	private static function create_course_reader_token( $student_user_id, $course_id, $base_url ) {
		$student_user_id = absint( $student_user_id );
		$course_id = absint( $course_id );
		$base_url = self::clean_reader_base_url( $base_url );
		if ( ! $student_user_id || ! $course_id || ! $base_url ) {
			return '';
		}
		$token = wp_generate_password( 32, false, false );
		set_transient( self::course_reader_transient_key( $student_user_id, $token ), array( 'course_id' => $course_id, 'base_url' => $base_url ), self::READER_TTL );
		return $token;
	}

	/**
	 * Resolve the current student's opaque Course menu request.
	 *
	 * @return array
	 */
	private static function requested_course_reader_context( $student_user_id ) {
		if ( ! self::has_course_reader_request() ) {
			return array();
		}
		$token = (string) wp_unslash( $_GET[ self::COURSE_READER_QUERY ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only opaque Course navigation.
		if ( ! preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ) {
			return array();
		}
		$context = get_transient( self::course_reader_transient_key( absint( $student_user_id ), $token ) );
		if ( ! is_array( $context ) || ! absint( $context['course_id'] ?? 0 ) ) {
			return array();
		}
		$base_url = self::clean_reader_base_url( $context['base_url'] ?? '' );
		return $base_url ? array( 'course_id' => absint( $context['course_id'] ), 'base_url' => $base_url ) : array();
	}

	/**
	 * Return whether an opaque Course menu was requested.
	 *
	 * @return bool
	 */
	private static function has_course_reader_request() {
		return isset( $_GET[ self::COURSE_READER_QUERY ] ) && ! is_array( $_GET[ self::COURSE_READER_QUERY ] ) && '' !== (string) wp_unslash( $_GET[ self::COURSE_READER_QUERY ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only opaque Course navigation.
	}

	/**
	 * Return the transient key for one student-scoped Course menu token.
	 *
	 * @return string
	 */
	private static function course_reader_transient_key( $student_user_id, $token ) {
		return 'tutorhelper_lms_course_reader_' . absint( $student_user_id ) . '_' . $token;
	}

	/**
	 * Store an opaque reader context for a student.
	 *
	 * The random token is scoped to the student by its transient key. It avoids
	 * exposing WordPress post IDs while retaining the existing authorisation
	 * check when the reader is opened.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $course_id Course ID.
	 * @param int $topic_id Topic ID.
	 * @param int    $lesson_id Lesson ID.
	 * @param string $base_url Student Portal URL that created the link.
	 * @return string
	 */
	private static function create_reader_token( $student_user_id, $course_id, $topic_id, $lesson_id, $base_url ) {
		$student_user_id = absint( $student_user_id );
		$course_id = absint( $course_id );
		$topic_id = absint( $topic_id );
		$lesson_id = absint( $lesson_id );
		$base_url = self::clean_reader_base_url( $base_url );
		if ( ! $student_user_id || ! $course_id || ! $topic_id || ! $lesson_id || ! $base_url ) {
			return '';
		}

		$token = wp_generate_password( 32, false, false );
		set_transient(
			self::reader_transient_key( $student_user_id, $token ),
			array(
				'course_id' => $course_id,
				'topic_id'  => $topic_id,
				'lesson_id' => $lesson_id,
				'base_url'  => $base_url,
			),
			self::READER_TTL
		);
		return $token;
	}

	/**
	 * Return whether the current user is a registered TutorHelper student.
	 *
	 * @return bool
	 */
	public static function is_current_student() {
		return is_user_logged_in() && self::is_student( get_current_user_id() );
	}

	/**
	 * Resolve a reader token only for the current student.
	 *
	 * @param string $token Opaque reader token.
	 * @return array{course_id:int,topic_id:int,lesson_id:int,base_url:string}
	 */
	public static function context_for_current_reader_token( $token ) {
		return self::is_current_student() ? self::reader_context_for_token( get_current_user_id(), $token ) : array();
	}

	/**
	 * Return a safe saved Reader display preference for a student.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return string
	 */
	private static function reader_display_mode( $student_user_id ) {
		$mode = sanitize_key( (string) get_user_meta( absint( $student_user_id ), 'tutorhelper_lms_reader_display_mode', true ) );
		return in_array( $mode, array( 'all', 'reading', 'notes' ), true ) ? $mode : 'all';
	}

	/**
	 * Return the current structural page key for one Lesson page number.
	 *
	 * @param int $lesson_id Lesson ID.
	 * @param int $page_number One-based page number.
	 * @return string
	 */
	public static function lesson_page_total( $lesson_id ) {
		$lesson = get_post( absint( $lesson_id ) );
		return $lesson && 'tutorhelper_lesson' === $lesson->post_type ? count( self::lesson_pages( $lesson ) ) : 0;
	}

	public static function lesson_page_key( $lesson_id, $page_number ) {
		$lesson = get_post( absint( $lesson_id ) );
		if ( ! $lesson || 'tutorhelper_lesson' !== $lesson->post_type ) {
			return '';
		}
		$pages = self::lesson_pages( $lesson );
		$page_number = absint( $page_number );
		return isset( $pages[ $page_number - 1 ]['id'] ) ? sanitize_key( $pages[ $page_number - 1 ]['id'] ) : '';
	}

	/**
	 * Resolve the current student's opaque reader token.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return array{course_id:int,topic_id:int,lesson_id:int}
	 */
	private static function requested_reader_context( $student_user_id ) {
		if ( ! self::has_reader_request() ) {
			return array();
		}
		$token = (string) wp_unslash( $_GET[ self::READER_QUERY ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only opaque reader navigation.
		return self::reader_context_for_token( $student_user_id, $token );
	}

	/**
	 * Resolve one well-formed opaque token for its owning student.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param string $token Opaque reader token.
	 * @return array{course_id:int,topic_id:int,lesson_id:int,base_url:string}
	 */
	private static function reader_context_for_token( $student_user_id, $token ) {
		if ( ! preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ) {
			return array();
		}
		$context = get_transient( self::reader_transient_key( absint( $student_user_id ), $token ) );
		if ( ! is_array( $context ) ) {
			return array();
		}
		$base_url = self::clean_reader_base_url( $context['base_url'] ?? '' );
		$context = array(
			'course_id' => absint( $context['course_id'] ?? 0 ),
			'topic_id'  => absint( $context['topic_id'] ?? 0 ),
			'lesson_id' => absint( $context['lesson_id'] ?? 0 ),
			'base_url'  => $base_url,
		);
		return $context['course_id'] && $context['topic_id'] && $context['lesson_id'] && $context['base_url'] ? $context : array();
	}

	/**
	 * Return the stored, same-site Student Portal URL for reader links.
	 *
	 * @param array $context Reader context.
	 * @return string
	 */
	private static function reader_base_url( $context ) {
		return self::clean_reader_base_url( $context['base_url'] ?? '' );
	}

	/**
	 * Accept only a same-site base URL and remove learner query arguments.
	 *
	 * @param string $base_url Candidate URL.
	 * @return string
	 */
	private static function clean_reader_base_url( $base_url ) {
		$base_url = esc_url_raw( (string) $base_url );
		$base_url = wp_validate_redirect( $base_url, '' );
		if ( ! $base_url ) {
			return '';
		}
		return remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::READER_QUERY, self::COURSE_READER_QUERY, self::PAGE_QUERY ), $base_url );
	}

	/**
	 * Return the current opaque reader token when it has the expected form.
	 *
	 * @return string
	 */
	private static function requested_reader_token() {
		if ( ! self::has_reader_request() ) {
			return '';
		}
		$token = (string) wp_unslash( $_GET[ self::READER_QUERY ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only opaque reader navigation.
		return preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ? $token : '';
	}

	/**
	 * Return whether an opaque reader token was requested.
	 *
	 * @return bool
	 */
	private static function has_reader_request() {
		return isset( $_GET[ self::READER_QUERY ] ) && ! is_array( $_GET[ self::READER_QUERY ] ) && '' !== (string) wp_unslash( $_GET[ self::READER_QUERY ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only opaque reader navigation.
	}

	/**
	 * Return a safe transient key for one student-scoped reader token.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param string $token Opaque reader token.
	 * @return string
	 */
	private static function reader_transient_key( $student_user_id, $token ) {
		return 'tutorhelper_lms_reader_' . absint( $student_user_id ) . '_' . $token;
	}

	/**
	 * Render a safe recovery screen when a reader link has expired or is invalid.
	 *
	 * @param string $base_url Parent page URL.
	 * @return void
	 */
	private static function render_reader_link_unavailable( $base_url ) {
		$base_url = remove_query_arg( array( self::COURSE_QUERY, self::TOPIC_QUERY, self::LESSON_QUERY, self::READER_QUERY, self::COURSE_READER_QUERY, self::PAGE_QUERY ), $base_url );
		echo '<div class="tutorhelper-lms-learning__denied" role="alert"><p>' . esc_html__( 'This Lesson link is no longer available. Please return to My Courses and open the Lesson again.', 'tutorhelper-lms' ) . '</p><p><a class="tutorhelper-student-booking-notice__action" href="' . esc_url( $base_url ) . '">' . esc_html__( 'Return to My Courses', 'tutorhelper-lms' ) . '</a></p></div>';
	}

	/**
	 * Read a Course ID from a read-only query parameter.
	 *
	 * @return int
	 */
	private static function requested_course_id() {
		return self::requested_id( self::COURSE_QUERY );
	}

	/**
	 * Read the submitted reader token after AJAX nonce verification.
	 *
	 * @return string
	 */
	private static function posted_reader_token() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called only after ajax_load_reader_page() verifies its nonce.
		$token = isset( $_POST[ self::READER_QUERY ] ) && ! is_array( $_POST[ self::READER_QUERY ] ) ? (string) wp_unslash( $_POST[ self::READER_QUERY ] ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ? $token : '';
	}

	/**
	 * Read a submitted positive integer after AJAX nonce verification.
	 *
	 * @param string $key Field key.
	 * @return int
	 */
	private static function posted_id( $key ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called only after ajax_load_reader_page() verifies its nonce.
		$value = isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? absint( wp_unslash( $_POST[ $key ] ) ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return $value;
	}

	/**
	 * Read one safe numeric value from the learner view query.
	 *
	 * @param string $key Query key.
	 * @return int
	 */
	private static function requested_id( $key ) {
		return isset( $_GET[ $key ] ) && ! is_array( $_GET[ $key ] ) ? absint( wp_unslash( $_GET[ $key ] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only learner navigation.
	}

	/**
	 * Return whether this user is a TutorHelper student.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private static function is_student( $user_id ) {
		return class_exists( 'TutorHelper_Students' ) && TutorHelper_Students::get_student( absint( $user_id ) ) instanceof WP_User;
	}

	/**
	 * Enqueue secure progressive-enhancement navigation for the standalone reader.
	 *
	 * @return void
	 */
	private static function enqueue_reader_script() {
		$path = TUTORHELPER_LMS_PATH . 'assets/js/tutorhelper-lms-reader.js';
		wp_enqueue_script(
			'tutorhelper-lms-reader',
			TUTORHELPER_LMS_URL . 'assets/js/tutorhelper-lms-reader.js',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_LMS_VERSION,
			true
		);
		$quiz_path = TUTORHELPER_LMS_PATH . 'assets/js/tutorhelper-lms-quiz-player.js';
		wp_enqueue_script(
			'tutorhelper-lms-quiz-player',
			TUTORHELPER_LMS_URL . 'assets/js/tutorhelper-lms-quiz-player.js',
			array(),
			file_exists( $quiz_path ) ? (string) filemtime( $quiz_path ) : TUTORHELPER_LMS_VERSION,
			true
		);

		wp_localize_script(
			'tutorhelper-lms-reader',
			'tutorhelperLmsReader',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'action'     => 'tutorhelper_lms_load_reader_page',
				'nonce'      => wp_create_nonce( 'tutorhelper_lms_reader_navigation' ),
				'noteAction' => 'tutorhelper_lms_save_lesson_note',
				'noteError'  => __( 'Your notes could not be saved. Please try again.', 'tutorhelper-lms' ),
				'annotationNonce' => wp_create_nonce( 'tutorhelper_lms_save_annotation' ),
				'annotationDeleteNonce' => wp_create_nonce( 'tutorhelper_lms_delete_annotation' ),
				'annotationError' => __( 'Your annotation could not be saved. Please try again.', 'tutorhelper-lms' ),
				'readerModeAction' => 'tutorhelper_lms_save_reader_mode',
				'readerModeNonce' => wp_create_nonce( 'tutorhelper_lms_reader_mode' ),
			)
		);
	}

	/**
	 * Enqueue a small LMS layer on pages that render learner content.
	 *
	 * @return void
	 */
	private static function enqueue_assets() {
		wp_enqueue_style( 'dashicons' );
		$path = TUTORHELPER_LMS_PATH . 'assets/css/tutorhelper-lms-learning.css';
		wp_enqueue_style(
			'tutorhelper-lms-learning',
			TUTORHELPER_LMS_URL . 'assets/css/tutorhelper-lms-learning.css',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_LMS_VERSION
		);
	}
}
