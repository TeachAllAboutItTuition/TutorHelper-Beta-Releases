<?php
/**
 * Plugin Name:       TutorHelper LMS Premium
 * Plugin URI:        https://tutorhelper.co.uk/
 * Description:       Premium coursework, secure submissions, marking and storage for TutorHelper LMS.
 * Version: 1.0.36
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Requires Plugins:  tutorhelper-bookings, tutorhelper-lms, tutorhelper-pro
 * Author:            Holly Billinghurst
 * Author URI:        https://tutorhelper.co.uk/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tutorhelper-lms
 * Domain Path:       /languages
 *
 * @package TutorHelper_LMS_Premium
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TUTORHELPER_LMS_PREMIUM_VERSION', '1.0.39' );

// Shared schema identifier retained for existing LMS records during the package split.
if ( ! defined( 'TUTORHELPER_LMS_DB_VERSION' ) ) {
	define( 'TUTORHELPER_LMS_DB_VERSION', '0.1.2' );
}
define( 'TUTORHELPER_LMS_PREMIUM_FILE', __FILE__ );
define( 'TUTORHELPER_LMS_PREMIUM_PATH', plugin_dir_path( TUTORHELPER_LMS_PREMIUM_FILE ) );
define( 'TUTORHELPER_LMS_PREMIUM_URL', plugin_dir_url( TUTORHELPER_LMS_PREMIUM_FILE ) );

/**
 * Keep activation harmless if WordPress has not loaded the free LMS files yet.
 *
 * @return void
 */
function tutorhelper_lms_premium_activate() {
	if ( class_exists( 'TutorHelper_LMS' ) ) {
		TutorHelper_LMS::activate();
	}
}
register_activation_hook( TUTORHELPER_LMS_PREMIUM_FILE, 'tutorhelper_lms_premium_activate' );

add_action(
	'plugins_loaded',
	static function() {
		if ( ! class_exists( 'TutorHelper_LMS_Dependency' ) ) {
			TutorHelper_LMS_Premium_Bootstrap::dependency_notice();
			return;
		}

		$required_files = array(
			'includes/class-tutorhelper-lms-database.php',
			'includes/class-tutorhelper-lms-private-files.php',
			'includes/class-tutorhelper-lms-resource-files.php',
			'includes/class-tutorhelper-lms-resource-delivery.php',
			'includes/class-tutorhelper-lms-learning-delivery.php',
			'includes/class-tutorhelper-lms-quiz-homework.php',
			'includes/class-tutorhelper-lms-secrets.php',
			'includes/storage/interface-tutorhelper-lms-storage-provider.php',
			'includes/storage/class-tutorhelper-lms-storage-registry.php',
			'includes/storage/class-tutorhelper-lms-local-storage-provider.php',
			'includes/storage/google/class-google-auth.php',
			'includes/storage/google/class-google-provider.php',
			'includes/storage/google/class-google-settings.php',
			'includes/class-tutorhelper-lms-private-storage.php',
			'includes/class-tutorhelper-lms-settings.php',
			'includes/class-tutorhelper-lms-premium.php',
			'includes/class-tutorhelper-lms-submissions.php',
			'includes/class-tutorhelper-lms-quiz-written-responses.php',
			'includes/class-tutorhelper-lms-quiz-annotations.php',
			'includes/class-tutorhelper-lms-homework-annotations.php',
			'includes/class-tutorhelper-lms-marked-files.php',
			'includes/class-tutorhelper-lms-adaptive-practice.php',
			'includes/class-tutorhelper-lms-timed-quizzes.php',
			'includes/class-tutorhelper-lms-gradebook.php',
			'includes/class-tutorhelper-lms-course-progression.php',
			'includes/class-tutorhelper-lms-journey-themes.php',
			'includes/class-tutorhelper-lms.php',
		);

		$missing_files = array_filter(
			$required_files,
			static function( $file ) {
				return ! is_readable( TUTORHELPER_LMS_PREMIUM_PATH . $file );
			}
		);

		if ( ! empty( $missing_files ) ) {
			TutorHelper_LMS_Premium_Bootstrap::incomplete_package_notice();
			return;
		}

		foreach ( $required_files as $file ) {
			require_once TUTORHELPER_LMS_PREMIUM_PATH . $file;
		}

		TutorHelper_LMS::instance()->run();
	},
	31
);

/**
 * Minimal notices which remain safe before the main Premium classes load.
 */
final class TutorHelper_LMS_Premium_Bootstrap {

	/**
	 * Show the missing-free-plugin notice.
	 *
	 * @return void
	 */
	public static function dependency_notice() {
		if ( is_admin() ) {
			add_action( 'admin_notices', array( __CLASS__, 'render_dependency_notice' ) );
		}
	}

	/**
	 * Show the incomplete-package notice.
	 *
	 * @return void
	 */
	public static function incomplete_package_notice() {
		if ( is_admin() ) {
			add_action( 'admin_notices', array( __CLASS__, 'render_incomplete_package_notice' ) );
		}
	}

	/**
	 * Render missing free LMS notice.
	 *
	 * @return void
	 */
	public static function render_dependency_notice() {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'TutorHelper LMS Premium requires the free TutorHelper LMS plugin to be active.', 'tutorhelper-lms' ) . '</p></div>';
		}
	}

	/**
	 * Render incomplete package notice without exposing server paths.
	 *
	 * @return void
	 */
	public static function render_incomplete_package_notice() {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'TutorHelper LMS Premium is incomplete and has not been loaded. Reinstall the complete Premium plugin ZIP before activating it again.', 'tutorhelper-lms' ) . '</p></div>';
		}
	}
}
