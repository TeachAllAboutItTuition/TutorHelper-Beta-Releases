=== TutorHelper LMS Premium ===
Requires at least: 6.4
Requires PHP: 7.4
Requires Plugins: tutorhelper-bookings, tutorhelper-lms, tutorhelper-pro
Stable tag: 1.0.34
License: GPLv2 or later

Private companion package for TutorHelper LMS. Includes secure coursework submissions, Google Drive storage, marking and feedback workflows. Requires a valid TutorHelper LMS Premium licence.

== Changelog ==

= 1.0.29 =

* 🆕 New Feature: Adds the Premium Classic Steps Course Journey alongside the Core List View for formally enrolled learners.
* ♿ Improvement: Journey nodes retain visible text status, keyboard links and responsive layouts while Core completion records remain the source of truth.



= 1.0.28 =

* 🆕 New Feature: Registers the Premium Classic Stepping Stones Learning Journey theme and verifies its packaged artwork.
* 🛡️ Improvement: Uses plugin-relative, allowlisted image paths with tutor-only asset preview and safe missing-asset fallback.



= 1.0.24 =

* 🆕 New Feature: Uploads private Resource Library master files to configured Google Drive or verified protected WordPress storage.
* 🛡️ Improvement: Stores reusable generic file references without public Media Library URLs or Google sharing links.
* 🚀 Improvement: Uses bounded resumable Google Drive uploads for Resource files, avoiding full-file PHP memory reads.


= 1.0.23 =

* 🆕 New Feature: Adds a provider-independent private-file record foundation for future resources and Lesson Notes.
* 🛡️ Improvement: Safely backfills existing submission-file metadata without moving or changing stored coursework files.

= 1.0.22 =

* 🎨 Improvement: Uses dashboard-style Course controls and updates only the student Gradebook content when switching Courses.
* 🐛 Fix: Restores released LMS marks and feedback to the student lesson details panel.
* 🐛 Fix: Updates the marked submission row in Learning Hub without refreshing the page.

= 1.0.21 =

* ✨ Improvement: Adds a visual student Topic Gradebook shortcode and tutor-accessible individual progress view.

= 1.0.20 =

* ✨ New: Adds a course Gradebook foundation showing submitted coursework, marks, released Grade snapshots and feedback status.

= 1.0.19 =

* 🎨 Improvement: Removes duplicate student homework details when LMS presents marked work and places the submitted-file link after tutor feedback.

= 1.0.18 =

* 🐛 Fix: Automatically marks tutor-reviewed LMS homework complete in the linked Pro lesson, without affecting manual homework completion.

= 1.0.17 =

* 🎨 Improvement: Shows marked homework, the submitted file or link, tutor feedback, mark and Grade together on the student dashboard.
