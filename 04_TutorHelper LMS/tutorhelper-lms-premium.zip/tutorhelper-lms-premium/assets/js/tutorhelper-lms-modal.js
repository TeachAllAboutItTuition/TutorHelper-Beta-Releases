( function() {
	'use strict';

	var lastTrigger = null;

	function closeDialog( dialog ) {
		if ( dialog && dialog.open ) {
			dialog.close();
		}
	}

	function initialiseEditor( textarea ) {
		if ( ! textarea || ! window.wp || ! wp.editor || textarea.dataset.editorReady ) { return; }
		textarea.dataset.editorReady = '1';
		if ( window.tinymce && tinymce.get( textarea.id ) ) {
			wp.editor.remove( textarea.id );
		}
		wp.editor.initialize( textarea.id, { tinymce: true, quicktags: false, mediaButtons: false } );
	}


	function updateLiveGrade( input ) {
		var form = input.closest( '[data-tutorhelper-lms-marking-form]' );
		var output = form && form.querySelector( '[data-tutorhelper-lms-live-grade]' );
		var value = output && output.querySelector( '[data-tutorhelper-lms-live-grade-value]' );
		if ( ! output || ! value ) { return; }
		var mark = parseFloat( input.value );
		var maximum = parseFloat( output.getAttribute( 'data-max-mark' ) || '0' );
		if ( isNaN( mark ) || maximum <= 0 ) {
			value.textContent = 'Enter a mark to calculate the percentage and grade.';
			return;
		}
		var percentage = Math.round( ( mark / maximum * 100 ) * 100 ) / 100;
		var context = {};
		try { context = JSON.parse( output.getAttribute( 'data-grading-context' ) || '{}' ); } catch ( error ) { context = {}; }
		var label = '';
		if ( context.type === 'grades' && Array.isArray( context.labels ) && context.boundaries ) {
			context.labels.some( function( grade, index ) {
				if ( Object.prototype.hasOwnProperty.call( context.boundaries, index ) && percentage >= parseFloat( context.boundaries[ index ] ) ) {
					label = grade;
					return true;
				}
				return false;
			} );
		}
		value.textContent = percentage + '%' + ( label ? ' · Grade ' + label : '' );
	}

	function openMarkingWorkspace( submissionId, trigger ) {
		var config = window.tutorhelperLmsMarking || {};
		if ( ! config.ajaxUrl || ! config.loadAction || ! config.nonce || ! submissionId ) {
			window.alert( ( config && config.failed ) || 'The marking workspace is not available on this screen. Please refresh and try again.' );
			return;
		}
		var body = new FormData(); body.append( 'action', config.loadAction ); body.append( 'nonce', config.nonce ); body.append( 'submission_id', submissionId );
		fetch( config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } ).then( function( response ) {
			if ( ! response.ok ) { throw new Error( config.failed ); }
			return response.json();
		} ).then( function( result ) {
			if ( ! result.success ) { throw new Error( result.data && result.data.message ? result.data.message : config.failed ); }
			var wrap = document.createElement( 'div' ); wrap.innerHTML = result.data.html; var dialog = wrap.querySelector( 'dialog' );
			if ( ! dialog ) { throw new Error( config.failed ); }
			dialog.removeAttribute( 'open' );
			document.body.appendChild( dialog );
			lastTrigger = trigger;
			if ( typeof dialog.showModal === 'function' ) { dialog.showModal(); } else { dialog.setAttribute( 'open', 'open' ); }
			dialog.querySelectorAll( '[data-tutorhelper-lms-editor], [data-tutorhelper-lms-question-feedback-editor]' ).forEach( initialiseEditor );
			dialog.addEventListener( 'close', function() { dialog.remove(); if ( lastTrigger ) { lastTrigger.focus(); lastTrigger = null; } } );
		} ).catch( function( error ) { window.alert( error.message || config.failed || 'The marking workspace could not be loaded.' ); } );
	}

	function openQuizReviewWorkspace( attemptId, trigger ) {
		var config = window.tutorhelperLmsQuizReview || {};
		if ( ! config.ajaxUrl || ! config.loadAction || ! config.nonce || ! attemptId ) {
			window.alert( ( config && config.failed ) || 'The Quiz review workspace is not available on this screen. Please refresh and try again.' );
			return;
		}
		var body = new FormData(); body.append( 'action', config.loadAction ); body.append( 'nonce', config.nonce ); body.append( 'attempt_id', attemptId );
		fetch( config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } ).then( function( response ) {
			if ( ! response.ok ) { throw new Error( config.failed ); }
			return response.json();
		} ).then( function( result ) {
			if ( ! result.success ) { throw new Error( result.data && result.data.message ? result.data.message : config.failed ); }
			var wrap = document.createElement( 'div' ); wrap.innerHTML = result.data.html; var dialog = wrap.querySelector( 'dialog' );
			if ( ! dialog ) { throw new Error( config.failed ); }
			dialog.removeAttribute( 'open' );
			document.body.appendChild( dialog );
			lastTrigger = trigger;
			if ( typeof dialog.showModal === 'function' ) { dialog.showModal(); } else { dialog.setAttribute( 'open', 'open' ); }
			dialog.querySelectorAll( '[data-tutorhelper-lms-editor], [data-tutorhelper-lms-question-feedback-editor]' ).forEach( initialiseEditor );
			dialog.addEventListener( 'close', function() { dialog.remove(); if ( lastTrigger ) { lastTrigger.focus(); lastTrigger = null; } } );
		} ).catch( function( error ) { window.alert( error.message || config.failed || 'The Quiz review workspace could not be loaded.' ); } );
	}

	document.addEventListener( 'click', function( event ) {
		var markButton = event.target.closest( '[data-tutorhelper-lms-mark-submission]' );
		if ( markButton ) { event.preventDefault(); openMarkingWorkspace( markButton.getAttribute( 'data-tutorhelper-lms-mark-submission' ), markButton ); return; }
		var quizButton = event.target.closest( '[data-tutorhelper-lms-review-quiz]' );
		if ( quizButton ) { event.preventDefault(); openQuizReviewWorkspace( quizButton.getAttribute( 'data-tutorhelper-lms-review-quiz' ), quizButton ); return; }
		var previewFile = event.target.closest( '[data-tutorhelper-lms-quiz-file-preview]' );
		if ( previewFile ) {
			event.preventDefault();
			var preview = document.getElementById( previewFile.getAttribute( 'data-tutorhelper-lms-quiz-file-preview' ) );
			if ( ! preview ) { return; }
			var showing = ! preview.hidden;
			preview.hidden = showing;
			previewFile.setAttribute( 'aria-expanded', showing ? 'false' : 'true' );
			previewFile.textContent = showing ? 'Preview file' : 'Hide preview';
			if ( ! showing && ! preview.querySelector( 'iframe' ) ) {
				var frame = document.createElement( 'iframe' );
				frame.className = 'tutorhelper-lms-quiz-review__file-preview-frame';
				frame.src = previewFile.getAttribute( 'data-preview-url' );
				frame.title = previewFile.getAttribute( 'data-preview-title' ) || 'File preview';
				frame.loading = 'lazy';
				preview.appendChild( frame );
			}
			return;
		}
		var editQuestionFeedback = event.target.closest( '[data-tutorhelper-lms-edit-question-feedback]' );
		if ( editQuestionFeedback ) {
			event.preventDefault();
			var feedbackId = editQuestionFeedback.getAttribute( 'data-tutorhelper-lms-edit-question-feedback' );
			var editorWrap = document.getElementById( feedbackId + '-editor' );
			var feedbackTextarea = document.getElementById( feedbackId );
			var feedbackEnabled = document.querySelector( '[data-tutorhelper-lms-question-feedback-enabled="' + feedbackId + '"]' );
			if ( editorWrap && feedbackTextarea ) {
				editorWrap.hidden = false;
				if ( feedbackEnabled ) { feedbackEnabled.value = '1'; }
				initialiseEditor( feedbackTextarea );
				editQuestionFeedback.hidden = true;
			}
			return;
		}
		var openButton = event.target.closest( '[data-tutorhelper-lms-modal-open]' );
		var closeButton = event.target.closest( '[data-tutorhelper-lms-modal-close]' );

		if ( openButton ) {
			var dialog = document.getElementById( openButton.getAttribute( 'data-tutorhelper-lms-modal-open' ) );

			if ( ! dialog ) {
				return;
			}

			lastTrigger = openButton;
			if ( dialog.open ) {
				dialog.focus();
				return;
			}

			try {
				if ( typeof dialog.showModal === 'function' ) {
					dialog.showModal();
				} else {
					dialog.setAttribute( 'open', 'open' );
				}
			} catch ( error ) {
				lastTrigger = null;
				window.alert( 'The homework submission form could not be opened. Please refresh and try again.' );
			}

			return;
		}

		if ( closeButton ) {
			closeDialog( closeButton.closest( 'dialog' ) );
		}
	} );

	document.addEventListener( 'submit', function( event ) {
		var quizReviewForm = event.target.closest( '.tutorhelper-lms-quiz-review-form' );
		if ( quizReviewForm ) {
			quizReviewForm.querySelectorAll( '[data-tutorhelper-lms-editor], [data-tutorhelper-lms-question-feedback-editor]' ).forEach( function( editor ) {
				if ( window.tinymce && tinymce.get( editor.id ) ) {
					tinymce.get( editor.id ).save();
				}
			} );
		}
	} );

	document.addEventListener( 'input', function( event ) {
		var markInput = event.target.closest( '[data-tutorhelper-lms-marking-form] input[name="awarded_mark"]' );
		if ( markInput ) { updateLiveGrade( markInput ); return; }
		var zoom = event.target.closest( '[data-tutorhelper-lms-image-zoom]' );
		if ( ! zoom ) { return; }
		var image = document.getElementById( zoom.getAttribute( 'data-tutorhelper-lms-image-zoom' ) );
		if ( image ) { image.style.width = zoom.value + '%'; }
	} );

	function prepareHomeworkMarkedPdf( form, status ) {
		if ( ! form.hasAttribute( 'data-tutorhelper-lms-homework-pdf' ) || ! form.querySelector( '[name="release_feedback"]:checked' ) ) {
			return Promise.resolve();
		}
		if ( typeof window.TutorHelperLmsFlattenHomeworkPdf !== 'function' ) {
			return Promise.reject( new Error( 'The marked PDF could not be prepared. Refresh the marking workspace and try again.' ) );
		}
		if ( status ) { status.textContent = 'Preparing the flattened marked PDF…'; }
		return window.TutorHelperLmsFlattenHomeworkPdf( form.querySelector( '[name="submission_id"]' ).value );
	}

	document.addEventListener( 'submit', function( event ) {
		var form = event.target.closest( '[data-tutorhelper-lms-marking-form]' );
		if ( ! form ) { return; }
		event.preventDefault();
		var config = window.tutorhelperLmsMarking || {}; var editor = form.querySelector( '[data-tutorhelper-lms-editor]' );
		var status = form.querySelector( '[data-tutorhelper-lms-marking-status]' );
		prepareHomeworkMarkedPdf( form, status ).then( function() {
			var body = new FormData( form );
			if ( editor && window.tinymce && tinymce.get( editor.id ) ) { body.set( 'feedback', tinymce.get( editor.id ).getContent() ); }
			body.append( 'action', config.saveAction ); body.append( 'nonce', config.saveNonce );
			if ( status ) { status.textContent = 'Saving…'; }
			return fetch( config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } ).then( function( response ) { return response.json(); } );
		} ).then( function( result ) {
			if ( ! result.success ) { throw new Error( result.data && result.data.message ? result.data.message : config.failed ); }
			if ( status ) { status.textContent = result.data.message || 'Saved.'; }
			var data = result.data || {};
			var row = data.submissionId ? document.querySelector( '[data-tutorhelper-lms-submission-row="' + data.submissionId + '"]' ) : null;
			if ( row ) {
				var statusCell = row.querySelector( '[data-tutorhelper-lms-submission-status]' );
				var actionsCell = row.querySelector( '[data-tutorhelper-lms-submission-actions]' );
				if ( statusCell && data.statusHtml ) { statusCell.innerHTML = data.statusHtml; }
				if ( actionsCell && data.actionsHtml ) { actionsCell.innerHTML = data.actionsHtml; }
			}
			closeDialog( form.closest( 'dialog' ) );
		} ).catch( function( error ) { if ( status ) { status.textContent = error.message || config.failed; } } );
	} );

	document.querySelectorAll( '.tutorhelper-lms-modal' ).forEach( function( dialog ) {
		dialog.addEventListener( 'close', function() {
			if ( lastTrigger ) {
				lastTrigger.focus();
				lastTrigger = null;
			}
		} );
	} );
}() );
