( function() {
	'use strict';

	var rowsPerPage = 10;

	function initialiseAssessmentRecords( scope ) {
		( scope || document ).querySelectorAll( '[data-tutorhelper-lms-gradebook-assessment-records]' ).forEach( function( records ) {
			if ( ! records.getAttribute( 'data-tutorhelper-lms-gradebook-topic-filter' ) ) {
				records.setAttribute( 'data-tutorhelper-lms-gradebook-topic-filter', '' );
			}
			renderAssessmentRecords( records, 1 );
		} );
	}

	function renderAssessmentRecords( records, requestedPage ) {
		var selectedTopic = records.getAttribute( 'data-tutorhelper-lms-gradebook-topic-filter' ) || '';
		var rows = Array.prototype.slice.call( records.querySelectorAll( '[data-tutorhelper-lms-gradebook-record]' ) );
		var matchedRows = rows.filter( function( row ) {
			var topics = ( row.getAttribute( 'data-tutorhelper-lms-gradebook-topics' ) || '' ).split( ',' );
			return ! selectedTopic || topics.indexOf( selectedTopic ) !== -1;
		} );
		var pageCount = Math.max( 1, Math.ceil( matchedRows.length / rowsPerPage ) );
		var page = Math.min( Math.max( 1, requestedPage || 1 ), pageCount );
		var start = ( page - 1 ) * rowsPerPage;
		var end = start + rowsPerPage;
		var pagination = records.querySelector( '[data-tutorhelper-lms-gradebook-pagination]' );
		var previous = records.querySelector( '[data-tutorhelper-lms-gradebook-page="previous"]' );
		var next = records.querySelector( '[data-tutorhelper-lms-gradebook-page="next"]' );
		var status = records.querySelector( '[data-tutorhelper-lms-gradebook-page-status]' );
		var empty = records.querySelector( '[data-tutorhelper-lms-gradebook-no-results]' );

		rows.forEach( function( row ) {
			row.hidden = matchedRows.indexOf( row ) === -1 || matchedRows.indexOf( row ) < start || matchedRows.indexOf( row ) >= end;
		} );
		records.setAttribute( 'data-tutorhelper-lms-gradebook-current-page', page );
		if ( pagination ) {
			pagination.hidden = matchedRows.length <= rowsPerPage;
		}
		if ( previous ) {
			previous.disabled = page <= 1;
		}
		if ( next ) {
			next.disabled = page >= pageCount;
		}
		if ( status ) {
			status.textContent = matchedRows.length ? 'Page ' + page + ' of ' + pageCount : '';
		}
		if ( empty ) {
			empty.hidden = !! matchedRows.length;
		}
	}

	document.addEventListener( 'DOMContentLoaded', function() {
		initialiseAssessmentRecords( document );
	} );

	document.addEventListener( 'click', function( event ) {
		var button = event.target.closest( '[data-tutorhelper-lms-gradebook-course]' );
		if ( ! button ) {
			return;
		}

		var picker = button.closest( '[data-tutorhelper-lms-gradebook-picker]' );
		var gradebook = button.closest( '.tutorhelper-lms-student-gradebook' );
		var progress = gradebook && gradebook.querySelector( '[data-tutorhelper-lms-gradebook-progress]' );
		var config = window.tutorhelperLmsGradebook || {};
		var courseId = button.getAttribute( 'data-tutorhelper-lms-gradebook-course' );

		if ( ! picker || ! progress || ! courseId || ! config.ajaxUrl || ! config.action || ! config.nonce || button.getAttribute( 'aria-selected' ) === 'true' ) {
			return;
		}

		event.preventDefault();
		picker.querySelectorAll( '[data-tutorhelper-lms-gradebook-course]' ).forEach( function( option ) {
			var selected = option === button;
			option.classList.toggle( 'is-active', selected );
			option.setAttribute( 'aria-selected', selected ? 'true' : 'false' );
			option.disabled = true;
		} );
		progress.setAttribute( 'aria-busy', 'true' );

		var body = new FormData();
		body.append( 'action', config.action );
		body.append( 'nonce', config.nonce );
		body.append( 'course_id', courseId );

		fetch( config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function( response ) {
				if ( ! response.ok ) {
					throw new Error( config.failed );
				}
				return response.json();
			} )
			.then( function( result ) {
				if ( ! result.success || ! result.data || ! result.data.html ) {
					throw new Error( result.data && result.data.message ? result.data.message : config.failed );
				}
				progress.innerHTML = result.data.html;
				initialiseAssessmentRecords( progress );
			} )
			.catch( function( error ) {
				window.alert( error.message || config.failed || 'The Gradebook could not be updated.' );
			} )
			.finally( function() {
				picker.querySelectorAll( '[data-tutorhelper-lms-gradebook-course]' ).forEach( function( option ) {
					option.disabled = false;
				} );
				progress.removeAttribute( 'aria-busy' );
			} );
	} );

	document.addEventListener( 'click', function( event ) {
		var topicButton = event.target.closest( '[data-tutorhelper-lms-gradebook-topic]' );
		var clearButton = event.target.closest( '[data-tutorhelper-lms-gradebook-clear-filter]' );
		var pageButton = event.target.closest( '[data-tutorhelper-lms-gradebook-page]' );
		if ( ! topicButton && ! clearButton && ! pageButton ) {
			return;
		}

		var source = topicButton || clearButton || pageButton;
		var records = pageButton ? pageButton.closest( '[data-tutorhelper-lms-gradebook-assessment-records]' ) : null;
		var progress = source.closest( '[data-tutorhelper-lms-gradebook-topic-progress]' );
		if ( ! records && progress ) {
			records = progress.querySelector( '[data-tutorhelper-lms-gradebook-assessment-records]' );
		}
		if ( ! records ) {
			return;
		}
		event.preventDefault();

		if ( topicButton || clearButton ) {
			var selectedTopic = topicButton ? topicButton.getAttribute( 'data-tutorhelper-lms-gradebook-topic' ) : '';
			var label = records.querySelector( '[data-tutorhelper-lms-gradebook-filter-label]' );
			var clear = records.querySelector( '[data-tutorhelper-lms-gradebook-clear-filter]' );
			if ( progress ) {
				progress.querySelectorAll( '[data-tutorhelper-lms-gradebook-topic]' ).forEach( function( button ) {
					var active = !! selectedTopic && button.getAttribute( 'data-tutorhelper-lms-gradebook-topic' ) === selectedTopic;
					button.classList.toggle( 'is-active', active );
					button.setAttribute( 'aria-pressed', active ? 'true' : 'false' );
				} );
			}
			records.setAttribute( 'data-tutorhelper-lms-gradebook-topic-filter', selectedTopic );
			if ( clear ) {
				clear.hidden = ! selectedTopic;
			}
			if ( label ) {
				if ( ! selectedTopic ) {
					label.textContent = 'Showing all released assessments.';
				} else {
					var activeCard = progress && progress.querySelector( '[data-tutorhelper-lms-gradebook-topic].is-active h4' );
					label.textContent = activeCard ? 'Showing results for ' + activeCard.textContent + '.' : 'Showing filtered results.';
				}
			}
			renderAssessmentRecords( records, 1 );
			return;
		}

		var currentPage = parseInt( records.getAttribute( 'data-tutorhelper-lms-gradebook-current-page' ) || '1', 10 );
		renderAssessmentRecords( records, currentPage + ( pageButton.getAttribute( 'data-tutorhelper-lms-gradebook-page' ) === 'next' ? 1 : -1 ) );
	} );
}() );
