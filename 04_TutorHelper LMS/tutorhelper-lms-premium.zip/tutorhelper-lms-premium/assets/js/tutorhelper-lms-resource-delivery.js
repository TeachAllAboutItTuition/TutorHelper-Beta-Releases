( function () {
	'use strict';
	const config = window.tutorhelperLmsResourceDelivery;
	if ( ! config ) { return; }

	function ids( value ) { return String( value || '' ).split( ',' ).map( Number ).filter( Boolean ); }
	function shares( first, second ) { return first.some( function ( id ) { return second.includes( id ); } ); }
	function filterResources( form ) {
		if ( ! form ) { return; }
		const shell = form.querySelector( '[data-tutorhelper-lms-homework-resources]' );
		if ( ! shell ) { return; }
		const course = form.querySelector( '[data-follow-up-course]' );
		const courseId = course ? Number( course.value || 0 ) : 0;
		const topicIds = Array.from( form.querySelectorAll( 'input[name="homework_topic_ids[]"]:checked' ) ).map( function ( field ) { return Number( field.value ); } );
		const search = shell.querySelector( '[data-tutorhelper-lms-resource-search]' );
		const query = search ? search.value.trim().toLowerCase() : '';
		const context = shell.querySelector( '[data-tutorhelper-lms-resource-context]' );
		const empty = shell.querySelector( '[data-tutorhelper-lms-resource-empty]' );
		const ready = Boolean( courseId && topicIds.length );
		let visible = 0;
		if ( context ) { context.textContent = ready ? 'Showing Resources linked to the selected Course or Topics. Search to refine further.' : 'Select a Course and at least one Topic to view matching Resources.'; }
		shell.querySelectorAll( '[data-tutorhelper-lms-resource-row]' ).forEach( function ( row ) {
			const input = row.querySelector( 'input[name="homework_resource_ids[]"]' );
			const resourceCourses = ids( row.dataset.resourceCourseIds );
			const resourceTopics = ids( row.dataset.resourceTopicIds );
			const courseMatch = resourceCourses.length ? resourceCourses.includes( courseId ) : true;
			const topicMatch = resourceTopics.length ? shares( resourceTopics, topicIds ) : resourceCourses.includes( courseId );
			const contextual = courseMatch && topicMatch;
			const searchMatch = ! query || row.textContent.toLowerCase().includes( query );
			// Keep an already-selected Resource visible so changing context never silently removes it.
			const show = Boolean( input && input.checked ) || ( ready && contextual && searchMatch );
			row.hidden = ! show;
			if ( show ) { visible++; }
		} );
		if ( empty ) { empty.hidden = ! ready || visible > 0; }
	}

	function markPrevious( form, previous ) {
		const prior = Array.isArray( previous ) ? previous.map( Number ) : [];
		form.querySelectorAll( 'input[name="homework_resource_ids[]"]' ).forEach( function ( input ) {
			const badge = input.closest( 'label' ).querySelector( '[data-tutorhelper-lms-previous-resource]' );
			if ( badge ) { badge.hidden = ! prior.includes( Number( input.value ) ); }
		} );
	}
	document.addEventListener( 'tutorhelper:follow-up-loaded', async function ( event ) {
		const form = event.detail && event.detail.form;
		const sourceId = Number( event.detail && event.detail.followUp && event.detail.followUp.homework_source_id || 0 );
		const bookingId = Number( form && form.elements.booking_id && form.elements.booking_id.value || 0 );
		if ( ! form ) { return; }
		form.querySelectorAll( 'input[name="homework_resource_ids[]"]' ).forEach( function ( input ) { input.checked = false; } );
		filterResources( form );
		if ( ! sourceId ) { return; }
		const body = new FormData(); body.append( 'action', config.action ); body.append( 'nonce', config.nonce ); body.append( 'source_id', String( sourceId ) ); body.append( 'booking_id', String( bookingId ) );
		try {
			const response = await fetch( config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } );
			const result = await response.json(); if ( ! result.success ) { return; }
			const selected = ( result.data.resourceIds || [] ).map( Number );
			form.querySelectorAll( 'input[name="homework_resource_ids[]"]' ).forEach( function ( input ) { input.checked = selected.includes( Number( input.value ) ); } );
			markPrevious( form, result.data.previousResourceIds || [] ); filterResources( form );
		} catch ( error ) { /* The homework form remains usable if the optional hints cannot load. */ }
	} );
	document.addEventListener( 'tutorhelper:follow-up-academic-context-changed', function ( event ) { filterResources( event.detail && event.detail.form ); } );
	document.addEventListener( 'input', function ( event ) { if ( event.target.matches( '[data-tutorhelper-lms-resource-search]' ) ) { filterResources( event.target.closest( 'form' ) ); } } );
	document.addEventListener( 'change', function ( event ) { if ( event.target.matches( '[data-follow-up-course], input[name="homework_topic_ids[]"], input[name="homework_resource_ids[]"]' ) ) { filterResources( event.target.closest( 'form' ) ); } } );
} )();
