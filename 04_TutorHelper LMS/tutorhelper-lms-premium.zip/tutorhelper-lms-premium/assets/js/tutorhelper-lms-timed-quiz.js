(function () {
	"use strict";

	function formatDuration(seconds) {
		seconds = Math.max(0, Math.floor(seconds));
		var minutes = Math.floor(seconds / 60);
		var remainder = seconds % 60;
		return minutes + ":" + String(remainder).padStart(2, "0");
	}

	function submitAtDeadline(timer) {
		var form = document.querySelector(".tutorhelper-lms-quiz__form");
		if (!form || form.dataset.tutorhelperLmsDeadlineSubmitted === "1") {
			return;
		}
		form.dataset.tutorhelperLmsDeadlineSubmitted = "1";
		var submit = document.createElement("input");
		submit.type = "hidden";
		submit.name = "quiz_submit";
		submit.value = "1";
		form.appendChild(submit);
		form.submit();
	}

	function initialise(timer) {
		var deadline = parseInt(timer.getAttribute("data-deadline"), 10);
		var output = timer.querySelector("[data-tutorhelper-lms-quiz-countdown]");
		var toggle = timer.querySelector("[data-tutorhelper-lms-hide-timer]");
		if (!deadline || !output) {
			return;
		}

		function tick() {
			var remaining = deadline - Math.floor(Date.now() / 1000);
			output.textContent = formatDuration(remaining);
			if (remaining <= 0) {
				timer.classList.add("is-finished");
				window.clearInterval(interval);
				submitAtDeadline(timer);
			}
		}

		if (toggle) {
			toggle.addEventListener("click", function () {
			var hidden = timer.classList.toggle("is-hidden");
			toggle.textContent = hidden ? "Show timer" : "Hide timer";
			toggle.setAttribute("aria-pressed", hidden ? "true" : "false");
			});
		}
		tick();
		var interval = window.setInterval(tick, 1000);
	}

	function initialiseBuilderToggle(toggle) {
		var container = toggle.closest(".tutorhelper-lms-quiz-builder__option");
		var settings = container ? container.querySelector("[data-tutorhelper-lms-timed-quiz-settings]") : null;
		var duration = settings ? settings.querySelector("[name=timed_quiz_minutes]") : null;
		if (!settings) {
			return;
		}
		function update() {
			settings.hidden = !toggle.checked;
			if (duration) {
				duration.required = toggle.checked;
			}
		}
		toggle.addEventListener("change", update);
		update();
	}

	function initialiseAll() {
		document.querySelectorAll("[data-tutorhelper-lms-quiz-timer]").forEach(initialise);
		document.querySelectorAll("[data-tutorhelper-lms-timed-quiz-toggle]").forEach(initialiseBuilderToggle);
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", initialiseAll);
	} else {
		initialiseAll();
	}
}());