( function () {
	'use strict';
	const config = window.tutorhelperLmsLearningDelivery;
	if ( ! config ) { return; }

	function ids( value ) { return String( value || '' ).split( ',' ).map( Number ).filter( Boolean ); }
	function shares( first, second ) { return first.some( function ( id ) { return second.includes( id ); } ); }

	function filterLessons( form ) {
		if ( ! form ) { return; }
		const shell = form.querySelector( '[data-tutorhelper-lms-homework-lessons]' );
		if ( ! shell ) { return; }
		const course = form.querySelector( '[data-follow-up-course]' );
		const courseId = course ? Number( course.value || 0 ) : 0;
		const topicIds = Array.from( form.querySelectorAll( 'input[name="homework_topic_ids[]"]:checked' ) ).map( function ( field ) { return Number( field.value ); } );
		const search = shell.querySelector( '[data-tutorhelper-lms-lesson-search]' );
		const query = search ? search.value.trim().toLowerCase() : '';
		const context = shell.querySelector( '[data-tutorhelper-lms-lesson-context]' );
		const empty = shell.querySelector( '[data-tutorhelper-lms-lesson-empty]' );
		const ready = Boolean( courseId && topicIds.length );
		let visible = 0;
		if ( context ) { context.textContent = ready ? 'Showing Lessons linked to the selected Course and Topics. Search to refine further.' : 'Select a Course and at least one Topic to view matching Lessons.'; }
		shell.querySelectorAll( '[data-tutorhelper-lms-lesson-row]' ).forEach( function ( row ) {
			const input = row.querySelector( 'input[name="homework_lesson_ids[]"]' );
			const contexts = String( row.dataset.lessonContexts || '' ).split( ',' );
			const contextual = topicIds.some( function ( topicId ) { return contexts.includes( String( courseId ) + ':' + String( topicId ) ); } );
			const searchMatch = ! query || row.textContent.toLowerCase().includes( query );
			const show = Boolean( input && input.checked ) || ( ready && contextual && searchMatch );
			row.hidden = ! show;
			if ( show ) { visible++; }
		} );
		if ( empty ) { empty.hidden = ! ready || visible > 0; }
	}

	function filterQuizzes( form ) {
		if ( ! form ) { return; }
		const shell = form.querySelector( '[data-tutorhelper-lms-homework-quiz]' );
		const select = form.querySelector( '[data-tutorhelper-lms-homework-quiz-select]' );
		if ( ! shell || ! select ) { return; }
		const course = form.querySelector( '[data-follow-up-course]' );
		const courseId = course ? Number( course.value || 0 ) : 0;
		const context = shell.querySelector( '[data-tutorhelper-lms-homework-quiz-context]' );
		let available = 0;
		Array.from( select.options ).forEach( function ( option ) {
			if ( ! option.value || '0' === option.value ) { return; }
			const matches = Boolean( courseId && Number( option.dataset.tutorhelperLmsQuizCourse || 0 ) === courseId );
			option.hidden = ! matches;
			option.disabled = ! matches;
			if ( matches ) { available++; }
		} );
		const selected = select.options[ select.selectedIndex ];
		if ( selected && selected.value && '0' !== selected.value && selected.disabled ) { select.value = '0'; }
		select.disabled = ! courseId;
		if ( context ) {
			context.textContent = ! courseId
				? 'Select a Course above to see its placed Quizzes.'
				: ( available ? 'Showing Quizzes linked to the selected Course.' : 'No placed Quizzes were found for the selected Course.' );
		}
	}

	function syncQuizHomeworkFields( form ) {
		if ( ! form ) { return; }
		const shell = form.querySelector( '[data-tutorhelper-lms-homework-quiz]' );
		const select = form.querySelector( '[data-tutorhelper-lms-homework-quiz-select]' );
		if ( ! shell || ! select ) { return; }
		const linked = Number( select.value || 0 ) > 0;
		const submission = form.querySelector( 'input[name="homework_submission_enabled"]' );
		const assessment = form.querySelector( 'select[name="homework_assessment_type"]' );
		const maximum = form.querySelector( 'input[name="homework_max_mark"]' );
		const notice = shell.querySelector( '[data-tutorhelper-lms-homework-quiz-notice]' );
		if ( linked && ! shell.dataset.tutorhelperLmsQuizControlsManaged ) {
			shell.dataset.tutorhelperLmsQuizControlsManaged = '1';
			if ( submission ) { shell.dataset.tutorhelperLmsSubmissionChecked = submission.checked ? '1' : '0'; }
			if ( assessment ) { shell.dataset.tutorhelperLmsAssessmentType = assessment.value; }
		}
		if ( linked ) {
			if ( submission ) { submission.checked = false; submission.disabled = true; }
			if ( assessment ) { assessment.value = 'marked'; assessment.disabled = true; }
			if ( maximum ) { maximum.disabled = true; maximum.placeholder = 'Set from first Quiz attempt'; }
		} else if ( shell.dataset.tutorhelperLmsQuizControlsManaged ) {
			if ( submission ) { submission.disabled = false; submission.checked = '1' === shell.dataset.tutorhelperLmsSubmissionChecked; }
			if ( assessment ) { assessment.disabled = false; assessment.value = shell.dataset.tutorhelperLmsAssessmentType || 'completion'; }
			if ( maximum ) { maximum.disabled = false; maximum.placeholder = ''; }
			delete shell.dataset.tutorhelperLmsQuizControlsManaged;
		}
		if ( notice ) { notice.hidden = ! linked; }
	}

	function markPrevious( form, previous ) {
		const prior = Array.isArray( previous ) ? previous.map( Number ) : [];
		form.querySelectorAll( 'input[name="homework_lesson_ids[]"]' ).forEach( function ( input ) {
			const badge = input.closest( 'label' ).querySelector( '[data-tutorhelper-lms-previous-lesson]' );
			if ( badge ) { badge.hidden = ! prior.includes( Number( input.value ) ); }
		} );
	}

	document.addEventListener( 'tutorhelper:follow-up-loaded', async function ( event ) {
		const form = event.detail && event.detail.form;
		const sourceId = Number( event.detail && event.detail.followUp && event.detail.followUp.homework_source_id || 0 );
		if ( ! form ) { return; }
		form.querySelectorAll( 'input[name="homework_lesson_ids[]"]' ).forEach( function ( input ) { input.checked = false; } );
		const quizSelect = form.querySelector( '[data-tutorhelper-lms-homework-quiz-select]' );
		if ( quizSelect ) { quizSelect.value = '0'; }
		filterLessons( form );
		filterQuizzes( form );
		syncQuizHomeworkFields( form );
		if ( ! sourceId ) { return; }
		const body = new FormData();
		body.append( 'action', config.action );
		body.append( 'nonce', config.nonce );
		body.append( 'source_id', String( sourceId ) );
		try {
			const response = await fetch( config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } );
			const result = await response.json();
			if ( ! result.success ) { return; }
			const selected = ( result.data.lessonIds || [] ).map( Number );
			form.querySelectorAll( 'input[name="homework_lesson_ids[]"]' ).forEach( function ( input ) { input.checked = selected.includes( Number( input.value ) ); } );
			if ( quizSelect ) { quizSelect.value = String( Number( result.data.quizPlacementId || 0 ) ); }
			markPrevious( form, result.data.previousLessonIds || [] );
			filterLessons( form );
			filterQuizzes( form );
			syncQuizHomeworkFields( form );
		} catch ( error ) {
			// The homework form remains usable if optional Lesson hints cannot load.
		}
	} );

	document.addEventListener( 'tutorhelper:follow-up-academic-context-changed', function ( event ) {
		const form = event.detail && event.detail.form;
		filterLessons( form );
		filterQuizzes( form );
		syncQuizHomeworkFields( form );
	} );
	document.addEventListener( 'input', function ( event ) {
		if ( event.target.matches( '[data-tutorhelper-lms-lesson-search]' ) ) { filterLessons( event.target.closest( 'form' ) ); }
	} );
	document.addEventListener( 'change', function ( event ) {
		if ( event.target.matches( '[data-follow-up-course], input[name="homework_topic_ids[]"], input[name="homework_lesson_ids[]"]' ) ) {
			const form = event.target.closest( 'form' );
			filterLessons( form );
			filterQuizzes( form );
			syncQuizHomeworkFields( form );
		}
		if ( event.target.matches( '[data-tutorhelper-lms-homework-quiz-select]' ) ) { syncQuizHomeworkFields( event.target.closest( 'form' ) ); }
	} );
} )();
