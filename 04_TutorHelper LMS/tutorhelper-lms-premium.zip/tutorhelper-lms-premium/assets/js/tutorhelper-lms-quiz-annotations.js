( function() {
	'use strict';

	var config = window.tutorhelperLmsQuizAnnotations || {};
	var stampGroups = [
		{
			id: 'general',
			label: 'General script',
			stamps: [
				[ 'seen', 'SEEN', 'Examiner has seen blank, extra or rough work.' ],
				[ 'tick', '✓', 'Creditworthy point or valid step.' ],
				[ 'cross', '✗', 'Incorrect statement or invalid working.' ],
				[ 'nr', 'NR', 'No response.' ],
				[ 'bod', 'BoD', 'Benefit of the doubt.' ],
				[ 'tv', 'TV', 'Too vague.' ],
				[ 'i', 'I', 'Irrelevant.' ],
				[ 'rep', 'REP', 'Repetition of an already credited point.' ],
				[ 'con', 'CON', 'Contradiction.' ]
			]
		},
		{
			id: 'extended',
			label: 'Extended response',
			stamps: [
				[ 'ao1', 'AO1', 'Knowledge and understanding.' ],
				[ 'ao2', 'AO2', 'Application.' ],
				[ 'ao3', 'AO3', 'Analysis and evaluation.' ],
				[ 'ku', 'KU', 'Knowledge and understanding.' ],
				[ 'dev', 'DEV', 'Developed point.' ],
				[ 'eval', 'EVAL', 'Evaluation.' ],
				[ 'l1', 'L1', 'Level 1.' ],
				[ 'l2', 'L2', 'Level 2.' ],
				[ 'l3', 'L3', 'Level 3.' ],
				[ 'l4', 'L4', 'Level 4.' ],
				[ 'eg', 'EG', 'Relevant example, case study or quotation.' ],
				[ 'omission', '^', 'Unclear expression or required word/phrase omitted.' ]
			]
		},
		{
			id: 'maths-science',
			label: 'Maths & Science',
			stamps: [
				[ 'm', 'M', 'Method mark.' ],
				[ 'a', 'A', 'Accuracy mark.' ],
				[ 'b', 'B', 'Independent mark.' ],
				[ 'ecf', 'ECF', 'Error carried forward / follow-through.' ],
				[ 'ft', 'FT', 'Follow-through.' ],
				[ 'ae', 'AE', 'Arithmetic error.' ],
				[ 'sf', 'SF', 'Significant figures.' ],
				[ 'unit', 'Unit', 'Missing or incorrect unit.' ],
				[ 'isw', 'ISW', 'Ignore subsequent working.' ]
			]
		}
	];
	var stampMap = {};
	stampGroups.forEach( function( group ) {
		group.stamps.forEach( function( stamp ) {
			stampMap[ stamp[ 0 ] ] = { id: stamp[ 0 ], label: stamp[ 1 ], description: stamp[ 2 ] };
		} );
	} );

	function normaliseDocument( annotation ) {
		return annotation && Array.isArray( annotation.items ) ? annotation : { version: 1, items: [] };
	}

	function request( action, values ) {
		var body = new URLSearchParams();
		Object.keys( values || {} ).forEach( function( key ) {
			if ( Array.isArray( values[ key ] ) ) {
				values[ key ].forEach( function( value ) {
					body.append( key + '[]', value );
				} );
				return;
			}
			body.append( key, values[ key ] );
		} );
		body.append( 'action', action );
		return fetch( config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} ).then( function( response ) {
			return response.json();
		} );
	}

	function pointForEvent( event, canvas ) {
		var bounds = canvas.getBoundingClientRect();
		return {
			x: Math.max( 0, Math.min( 1, ( event.clientX - bounds.left ) / bounds.width ) ),
			y: Math.max( 0, Math.min( 1, ( event.clientY - bounds.top ) / bounds.height ) )
		};
	}

	function resizeCanvas( canvas, image ) {
		if ( ! image.naturalWidth || ! image.naturalHeight ) {
			return false;
		}
		canvas.width = image.naturalWidth;
		canvas.height = image.naturalHeight;
		return true;
	}

	function drawStamp( context, item, width, height ) {
		var stamp = stampMap[ item.stamp ] || { label: item.stamp || '' };
		var label = stamp.label;
		var size = Math.max( 18, Math.round( width * ( item.scale || 0.06 ) ) );
		var x = item.x * width;
		var y = item.y * height;
		context.save();
		context.textAlign = 'center';
		context.textBaseline = 'middle';
		context.lineJoin = 'round';
		context.font = '800 ' + size + 'px Arial, sans-serif';
		context.strokeStyle = '#ffffff';
		context.lineWidth = Math.max( 3, Math.round( size * 0.16 ) );
		context.strokeText( label, x, y );
		context.fillStyle = item.stamp === 'cross' ? '#c83f39' : '#174957';
		context.fillText( label, x, y );
		context.restore();
	}

	function drawStroke( context, item, width, height ) {
		if ( ! item.points || item.points.length < 2 ) {
			return;
		}
		context.save();
		context.strokeStyle = item.colour || '#d3483f';
		context.lineWidth = Math.max( 2, width * ( item.width || 0.004 ) );
		context.lineCap = 'round';
		context.lineJoin = 'round';
		context.beginPath();
		item.points.forEach( function( point, index ) {
			var x = point.x * width;
			var y = point.y * height;
			if ( index === 0 ) {
				context.moveTo( x, y );
			} else {
				context.lineTo( x, y );
			}
		} );
		context.stroke();
		context.restore();
	}

	function redraw( canvas, annotation ) {
		var context = canvas.getContext( '2d' );
		context.clearRect( 0, 0, canvas.width, canvas.height );
		normaliseDocument( annotation ).items.forEach( function( item ) {
			if ( item.type === 'stamp' ) {
				drawStamp( context, item, canvas.width, canvas.height );
			} else if ( item.type === 'stroke' ) {
				drawStroke( context, item, canvas.width, canvas.height );
			}
		} );
	}

	function stampButton( stamp, extraClass, draggable ) {
		var button = document.createElement( 'button' );
		button.type = 'button';
		button.className = 'button tutorhelper-lms-annotation-stamp ' + ( extraClass || '' );
		button.textContent = stamp.label;
		button.title = stamp.label + ': ' + stamp.description;
		button.dataset.annotationTool = 'stamp';
		button.dataset.annotationValue = stamp.id;
		button.draggable = false !== draggable;
		return button;
	}

	function updatePreview( wrapper, annotation ) {
		var image = wrapper.querySelector( 'img' );
		var canvas = wrapper.querySelector( 'canvas' );
		if ( ! image || ! canvas ) {
			return;
		}
		wrapper.dataset.annotation = JSON.stringify( annotation );
		function draw() {
			if ( resizeCanvas( canvas, image ) ) {
				redraw( canvas, annotation );
			}
		}
		if ( image.complete ) {
			draw();
		} else {
			image.addEventListener( 'load', draw, { once: true } );
		}
	}

	function updateMatchingPreviews( attemptId, questionId, submissionId, annotation ) {
		document.querySelectorAll( '[data-tutorhelper-lms-quiz-annotation-display], [data-tutorhelper-lms-homework-annotation-display]' ).forEach( function( wrapper ) {
			if ( ( submissionId && String( wrapper.dataset.submissionId || '' ) === String( submissionId ) ) || ( ! submissionId && String( wrapper.dataset.attemptId || '' ) === String( attemptId ) && String( wrapper.dataset.questionId || '' ) === String( questionId ) ) ) {
				updatePreview( wrapper, annotation );
			}
		} );
	}

	function renderFavourites( tray, favourites, selected, setTool, saveFavourites, editing ) {
		tray.innerHTML = '';
		tray.classList.toggle( 'is-editing', !! editing );
		if ( ! favourites.length ) {
			var empty = document.createElement( 'p' );
			empty.className = 'tutorhelper-lms-annotation-favourites__empty';
			empty.textContent = editing ? 'Drag stamps here to make your personal set.' : 'Choose Edit My stamps to add stamps.';
			tray.appendChild( empty );
		}
		favourites.forEach( function( id, position ) {
			var stamp = stampMap[ id ];
			if ( ! stamp ) {
				return;
			}
			var item = document.createElement( 'span' );
			item.className = 'tutorhelper-lms-annotation-favourite';
			item.dataset.stampId = id;
			item.draggable = !! editing;
			var button = stampButton( stamp, 'is-favourite', editing );
			button.classList.toggle( 'is-active', selected.tool === 'stamp' && selected.stamp === id );
			item.appendChild( button );
			if ( editing ) {
				var move = function( direction ) {
					var current = favourites.indexOf( id );
					var next = current + direction;
					if ( next < 0 || next >= favourites.length ) {
						return;
					}
					favourites.splice( current, 1 );
					favourites.splice( next, 0, id );
					renderFavourites( tray, favourites, selected, setTool, saveFavourites, editing );
					saveFavourites();
				};
				var previous = document.createElement( 'button' );
				previous.type = 'button';
				previous.className = 'tutorhelper-lms-annotation-favourite-move';
				previous.textContent = '←';
				previous.setAttribute( 'aria-label', 'Move ' + stamp.label + ' left' );
				previous.disabled = position === 0;
				previous.addEventListener( 'click', function( event ) {
					event.stopPropagation();
					move( -1 );
				} );
				var next = document.createElement( 'button' );
				next.type = 'button';
				next.className = 'tutorhelper-lms-annotation-favourite-move';
				next.textContent = '→';
				next.setAttribute( 'aria-label', 'Move ' + stamp.label + ' right' );
				next.disabled = position === favourites.length - 1;
				next.addEventListener( 'click', function( event ) {
					event.stopPropagation();
					move( 1 );
				} );
				var remove = document.createElement( 'button' );
				remove.type = 'button';
				remove.className = 'tutorhelper-lms-annotation-favourite-remove';
				remove.setAttribute( 'aria-label', 'Remove ' + stamp.label + ' from My stamps' );
				remove.textContent = '×';
				remove.addEventListener( 'click', function( event ) {
					event.stopPropagation();
					favourites.splice( favourites.indexOf( id ), 1 );
					renderFavourites( tray, favourites, selected, setTool, saveFavourites, editing );
					saveFavourites();
				} );
				item.appendChild( previous );
				item.appendChild( next );
				item.appendChild( remove );
			}
			tray.appendChild( item );
		} );
	}
	function createWorkspace( payload, trigger, workspaceConfig ) {
		var annotation = normaliseDocument( payload.annotation );
		var favourites = Array.isArray( payload.favourites ) ? payload.favourites.filter( function( id ) { return !! stampMap[ id ]; } ) : [ 'tick', 'cross', 'nr', 'bod', 'ft' ];
		var dialog = document.createElement( 'dialog' );
		dialog.className = 'tutorhelper-lms-modal tutorhelper-lms-annotation-modal';
		dialog.innerHTML = '<div class="tutorhelper-lms-modal__header"><h2></h2><button type="button" class="button-link tutorhelper-lms-modal__close" aria-label="Close image marking">×</button></div><div class="tutorhelper-lms-modal__body"><p class="description">Select a stamp, then click the image to place it. Choose Draw to annotate freehand; Eraser removes drawn ink only. Right-click a stamp to remove it.</p><section class="tutorhelper-lms-annotation-favourites-wrap"><div class="tutorhelper-lms-annotation-section-heading"><h3>My stamps</h3><button type="button" class="button tutorhelper-lms-annotation-edit-stamps">Edit My stamps</button></div><div class="tutorhelper-lms-annotation-favourites" aria-label="My marking stamps"></div><p class="description tutorhelper-lms-annotation-edit-help" hidden>Drag stamps into My stamps, drag to reorder them, or use × to remove one. Select Done editing stamps when finished.</p></section><div class="tutorhelper-lms-annotation-draw-tools"><button type="button" class="button tutorhelper-lms-annotation-tool is-active" data-annotation-tool="draw">Draw</button><button type="button" class="button tutorhelper-lms-annotation-tool" data-annotation-tool="eraser">Eraser</button><label>Colour <input type="color" value="#d3483f" data-tutorhelper-lms-annotation-colour /></label><label>Pen width <input type="range" min="1" max="12" value="4" data-tutorhelper-lms-annotation-width /><output data-tutorhelper-lms-annotation-width-output>4</output></label></div><div class="tutorhelper-lms-annotation-toolbar" hidden></div><div class="tutorhelper-lms-annotation-stage"><img alt="" /><canvas aria-label="Image marking canvas"></canvas><p class="tutorhelper-lms-annotation-loading"><span class="tutorhelper-lms-annotation-spinner" aria-hidden="true"></span> Loading image…</p></div><p class="tutorhelper-lms-annotation-status" role="status"></p><div class="tutorhelper-lms-modal__actions"><button type="button" class="button tutorhelper-lms-annotation-undo">Undo last</button><button type="button" class="button tutorhelper-lms-annotation-clear">Clear annotations</button><button type="button" class="button button-primary tutorhelper-lms-annotation-save">Save annotations</button></div></div>';
		document.body.appendChild( dialog );

		var title = dialog.querySelector( 'h2' );
		var image = dialog.querySelector( 'img' );
		var canvas = dialog.querySelector( 'canvas' );
		var stage = dialog.querySelector( '.tutorhelper-lms-annotation-stage' );
		var drawTools = dialog.querySelector( '.tutorhelper-lms-annotation-draw-tools' );
		var toolbar = dialog.querySelector( '.tutorhelper-lms-annotation-toolbar' );
		var favouritesTray = dialog.querySelector( '.tutorhelper-lms-annotation-favourites' );
		var editButton = dialog.querySelector( '.tutorhelper-lms-annotation-edit-stamps' );
		var editHelp = dialog.querySelector( '.tutorhelper-lms-annotation-edit-help' );
		var colourInput = dialog.querySelector( '[data-tutorhelper-lms-annotation-colour]' );
		var widthInput = dialog.querySelector( '[data-tutorhelper-lms-annotation-width]' );
		var widthOutput = dialog.querySelector( '[data-tutorhelper-lms-annotation-width-output]' );
		var status = dialog.querySelector( '.tutorhelper-lms-annotation-status' );
		var selected = { tool: 'draw', stamp: '' };
		var storedDrawing = payload.drawing || {};
		var drawing = {
			colour: /^#[0-9a-f]{6}$/i.test( storedDrawing.colour || '' ) ? storedDrawing.colour : '#d3483f',
			width: Math.max( 1, Math.min( 12, Number( storedDrawing.width ) || 4 ) )
		};
		var drawingSaveTimer = 0;
		var activeStroke = null;
		var erasing = false;
		var editingMyStamps = false;
		var markInput = document.querySelector( '[data-tutorhelper-lms-question-mark-attempt="' + payload.attemptId + '"][data-tutorhelper-lms-question-mark-question="' + payload.questionId + '"]' );
		var markIsManual = !! ( markInput && markInput.value !== '' );
		var syncingTickMark = false;

		function syncTickMark() {
			if ( ! markInput || markIsManual ) {
				return;
			}
			var ticks = annotation.items.filter( function( item ) { return item.type === 'stamp' && item.stamp === 'tick'; } ).length;
			syncingTickMark = true;
			markInput.value = String( ticks );
			markInput.dispatchEvent( new Event( 'input', { bubbles: true } ) );
			status.textContent = ticks > Number( markInput.max ) ? 'There are ' + ticks + ' tick stamps, which is above the question maximum of ' + markInput.max + '.' : 'Question mark auto-filled from ' + ticks + ' tick stamp' + ( ticks === 1 ? '' : 's' ) + '.';
			syncingTickMark = false;
		}
		if ( markInput ) {
			markInput.addEventListener( 'input', function() {
				if ( ! syncingTickMark ) {
					markIsManual = true;
				}
			} );
		}

		title.textContent = payload.filename || trigger.dataset.fileTitle || 'Mark image';
		colourInput.value = drawing.colour;
		widthInput.value = String( drawing.width );
		widthOutput.textContent = String( drawing.width );
		syncTickMark();

		function saveDrawing() {
			window.clearTimeout( drawingSaveTimer );
			drawingSaveTimer = window.setTimeout( function() {
				request( config.saveDrawingAction, {
					nonce: config.drawingNonce,
					colour: drawing.colour,
					width: drawing.width
				} ).then( function( response ) {
					if ( ! response || ! response.success ) {
						throw new Error( response && response.data && response.data.message ? response.data.message : 'Drawing preference could not be saved.' );
					}
					drawing = response.data.drawing || drawing;
				} ).catch( function( error ) {
					status.textContent = error.message || 'Drawing preference could not be saved.';
				} );
			}, 300 );
		}

		function saveFavourites() {
			request( config.saveFavouritesAction, {
				nonce: config.favouritesNonce,
				favourites: favourites
			} ).then( function( response ) {
				if ( ! response || ! response.success ) {
					throw new Error( response && response.data && response.data.message ? response.data.message : 'My stamps could not be saved.' );
				}
				favourites = Array.isArray( response.data.favourites ) ? response.data.favourites : favourites;
				renderFavourites( favouritesTray, favourites, selected, setTool, saveFavourites, editingMyStamps );
			} ).catch( function( error ) {
				status.textContent = error.message || 'My stamps could not be saved.';
			} );
		}

		function setTool( tool, stamp ) {
			selected.tool = tool;
			selected.stamp = stamp || '';
			dialog.querySelectorAll( '[data-annotation-tool]' ).forEach( function( button ) {
				button.classList.toggle( 'is-active', button.dataset.annotationTool === tool && ( tool !== 'stamp' || button.dataset.annotationValue === stamp ) );
			} );
			drawTools.classList.toggle( 'is-drawing', tool === 'draw' );
			stage.classList.toggle( 'is-drawing', tool === 'draw' );
			stage.classList.toggle( 'is-erasing', tool === 'eraser' );
			renderFavourites( favouritesTray, favourites, selected, setTool, saveFavourites, editingMyStamps );
		}

		function setEditingMyStamps( enabled ) {
			editingMyStamps = !! enabled;
			toolbar.hidden = ! editingMyStamps;
			editHelp.hidden = ! editingMyStamps;
			editButton.textContent = editingMyStamps ? 'Done editing stamps' : 'Edit My stamps';
			editButton.classList.toggle( 'is-active', editingMyStamps );
			renderFavourites( favouritesTray, favourites, selected, setTool, saveFavourites, editingMyStamps );
		}

		editButton.addEventListener( 'click', function() {
			setEditingMyStamps( ! editingMyStamps );
		} );
		colourInput.addEventListener( 'input', function() {
			drawing.colour = colourInput.value;
			saveDrawing();
		} );
		widthInput.addEventListener( 'input', function() {
			drawing.width = Number( widthInput.value );
			widthOutput.textContent = String( drawing.width );
			saveDrawing();
		} );
		drawTools.addEventListener( 'click', function( event ) {
			var button = event.target.closest( '[data-annotation-tool]' );
			if ( button ) {
				setTool( button.dataset.annotationTool, '' );
			}
		} );

		stampGroups.forEach( function( group ) {
			var groupDetails = document.createElement( 'details' );
			groupDetails.className = 'tutorhelper-lms-annotation-group';
			groupDetails.open = group.id === 'general';
			groupDetails.dataset.groupId = group.id;
			var summary = document.createElement( 'summary' );
			summary.textContent = group.label;
			var grid = document.createElement( 'div' );
			grid.className = 'tutorhelper-lms-annotation-stamp-grid';
			group.stamps.forEach( function( sourceStamp ) {
				grid.appendChild( stampButton( { id: sourceStamp[ 0 ], label: sourceStamp[ 1 ], description: sourceStamp[ 2 ] }, '', true ) );
			} );
			groupDetails.appendChild( summary );
			groupDetails.appendChild( grid );
			groupDetails.addEventListener( 'dragover', function( event ) {
				if ( ! editingMyStamps ) {
					return;
				}
				event.preventDefault();
				event.dataTransfer.dropEffect = 'move';
				groupDetails.classList.add( 'is-drop-target' );
			} );
			groupDetails.addEventListener( 'dragleave', function() {
				groupDetails.classList.remove( 'is-drop-target' );
			} );
			groupDetails.addEventListener( 'drop', function( event ) {
				if ( ! editingMyStamps ) {
					return;
				}
				event.preventDefault();
				groupDetails.classList.remove( 'is-drop-target' );
				var id = event.dataTransfer.getData( 'text/plain' );
				var index = favourites.indexOf( id );
				if ( index !== -1 ) {
					favourites.splice( index, 1 );
					renderFavourites( favouritesTray, favourites, selected, setTool, saveFavourites, editingMyStamps );
					saveFavourites();
				}
			} );
			toolbar.appendChild( groupDetails );
		} );

		toolbar.addEventListener( 'click', function( event ) {
			var button = event.target.closest( '[data-annotation-tool]' );
			if ( button ) {
				setTool( button.dataset.annotationTool, button.dataset.annotationValue );
			}
		} );
		toolbar.addEventListener( 'dragstart', function( event ) {
			if ( ! editingMyStamps ) {
				return;
			}
			var button = event.target.closest( '[data-annotation-value]' );
			if ( button ) {
				event.dataTransfer.setData( 'text/plain', button.dataset.annotationValue );
				event.dataTransfer.effectAllowed = 'copy';
			}
		} );

		favouritesTray.addEventListener( 'click', function( event ) {
			var button = event.target.closest( '[data-annotation-tool="stamp"]' );
			if ( button ) {
				setTool( 'stamp', button.dataset.annotationValue );
			}
		} );
		favouritesTray.addEventListener( 'dragstart', function( event ) {
			if ( ! editingMyStamps ) {
				return;
			}
			var item = event.target.closest( '[data-stamp-id]' );
			if ( item ) {
				event.dataTransfer.setData( 'text/plain', item.dataset.stampId );
				event.dataTransfer.effectAllowed = 'move';
				item.classList.add( 'is-dragging' );
			}
		} );
		favouritesTray.addEventListener( 'dragend', function( event ) {
			var item = event.target.closest( '[data-stamp-id]' );
			if ( item ) {
				item.classList.remove( 'is-dragging' );
			}
		} );
		favouritesTray.addEventListener( 'dragover', function( event ) {
			if ( ! editingMyStamps ) {
				return;
			}
			event.preventDefault();
			event.dataTransfer.dropEffect = 'copy';
			favouritesTray.classList.add( 'is-drop-target' );
		} );
		favouritesTray.addEventListener( 'dragleave', function() {
			favouritesTray.classList.remove( 'is-drop-target' );
		} );
		favouritesTray.addEventListener( 'drop', function( event ) {
			if ( ! editingMyStamps ) {
				return;
			}
			event.preventDefault();
			favouritesTray.classList.remove( 'is-drop-target' );
			var id = event.dataTransfer.getData( 'text/plain' );
			if ( ! stampMap[ id ] ) {
				return;
			}
			var currentIndex = favourites.indexOf( id );
			if ( currentIndex !== -1 ) {
				favourites.splice( currentIndex, 1 );
			}
			var target = event.target.closest( '[data-stamp-id]' );
			var targetIndex = target ? favourites.indexOf( target.dataset.stampId ) : -1;
			if ( targetIndex === -1 ) {
				favourites.push( id );
			} else {
				favourites.splice( targetIndex, 0, id );
			}
			favourites = favourites.slice( 0, 16 );
			renderFavourites( favouritesTray, favourites, selected, setTool, saveFavourites, editingMyStamps );
			saveFavourites();
		} );
		renderFavourites( favouritesTray, favourites, selected, setTool, saveFavourites, editingMyStamps );
		setTool( 'draw' );

		function ready() {
			var loading = dialog.querySelector( '.tutorhelper-lms-annotation-loading' );
			if ( loading ) {
				loading.remove();
			}
			if ( resizeCanvas( canvas, image ) ) {
				redraw( canvas, annotation );
			}
		}

		function eraseAt( point ) {
			var radius = 0.008 + ( drawing.width * 0.002 );
			var removed = false;
			for ( var index = annotation.items.length - 1; index >= 0; index-- ) {
				var item = annotation.items[ index ];
				if ( item.type !== 'stroke' || ! item.points ) {
					continue;
				}
				var touchesStroke = item.points.some( function( strokePoint ) {
					var xDistance = strokePoint.x - point.x;
					var yDistance = strokePoint.y - point.y;
					return Math.sqrt( ( xDistance * xDistance ) + ( yDistance * yDistance ) ) <= radius;
				} );
				if ( touchesStroke ) {
					annotation.items.splice( index, 1 );
					removed = true;
				}
			}
			if ( removed ) {
				redraw( canvas, annotation );
				status.textContent = 'Drawn ink erased.';
			}
		}

		canvas.addEventListener( 'pointerdown', function( event ) {
			if ( event.button !== 0 || ! canvas.width || ! canvas.height ) {
				return;
			}
			var point = pointForEvent( event, canvas );
			if ( selected.tool === 'stamp' ) {
				annotation.items.push( { type: 'stamp', stamp: selected.stamp, x: point.x, y: point.y, scale: 0.06 } );
				redraw( canvas, annotation );
				syncTickMark();
				return;
			}
			if ( selected.tool === 'eraser' ) {
				erasing = true;
				canvas.setPointerCapture( event.pointerId );
				eraseAt( point );
				return;
			}
			activeStroke = {
				type: 'stroke',
				colour: drawing.colour,
				width: drawing.width * 0.0035,
				points: [ point ]
			};
			annotation.items.push( activeStroke );
			canvas.setPointerCapture( event.pointerId );
			redraw( canvas, annotation );
		} );

		canvas.addEventListener( 'pointermove', function( event ) {
			if ( erasing ) {
				eraseAt( pointForEvent( event, canvas ) );
				return;
			}
			if ( ! activeStroke ) {
				return;
			}
			activeStroke.points.push( pointForEvent( event, canvas ) );
			redraw( canvas, annotation );
		} );

		function finishStroke() {
			if ( activeStroke && activeStroke.points.length < 2 ) {
				annotation.items.pop();
				redraw( canvas, annotation );
			}
			activeStroke = null;
			erasing = false;
		}
		canvas.addEventListener( 'pointerup', finishStroke );
		canvas.addEventListener( 'pointercancel', finishStroke );
		canvas.addEventListener( 'contextmenu', function( event ) {
			event.preventDefault();
			var point = pointForEvent( event, canvas );
			for ( var index = annotation.items.length - 1; index >= 0; index-- ) {
				var item = annotation.items[ index ];
				if ( item.type !== 'stamp' ) {
					continue;
				}
				var radius = Math.max( item.scale || 0.06, 0.04 );
				if ( Math.abs( point.x - item.x ) <= radius && Math.abs( point.y - item.y ) <= radius ) {
					annotation.items.splice( index, 1 );
					redraw( canvas, annotation );
					syncTickMark();
					status.textContent = 'Stamp removed.';
					return;
				}
			}
		} );

		dialog.querySelector( '.tutorhelper-lms-annotation-undo' ).addEventListener( 'click', function() {
			annotation.items.pop();
			redraw( canvas, annotation );
			syncTickMark();
		} );
		dialog.querySelector( '.tutorhelper-lms-annotation-clear' ).addEventListener( 'click', function() {
			if ( annotation.items.length && window.confirm( 'Clear every stamp and drawing from this image?' ) ) {
				annotation.items = [];
				redraw( canvas, annotation );
				syncTickMark();
			}
		} );
		dialog.querySelector( '.tutorhelper-lms-annotation-save' ).addEventListener( 'click', function( event ) {
			var button = event.currentTarget;
			button.disabled = true;
			status.textContent = 'Saving annotations…';
			request( workspaceConfig.saveAction, {
				nonce: workspaceConfig.saveNonce,
				submission_id: payload.submissionId || 0,
				attempt_id: payload.attemptId || 0,
				question_id: payload.questionId || 0,
				annotation: JSON.stringify( annotation )
			} ).then( function( response ) {
				if ( ! response || ! response.success ) {
					throw new Error( response && response.data && response.data.message ? response.data.message : workspaceConfig.saveFailed );
				}
				annotation = normaliseDocument( response.data.annotation );
				redraw( canvas, annotation );
				updateMatchingPreviews( payload.attemptId, payload.questionId, payload.submissionId, annotation );
				status.textContent = 'Annotations saved. The marking preview has been updated.';
			} ).catch( function( error ) {
				status.textContent = error.message || workspaceConfig.saveFailed;
			} ).finally( function() {
				button.disabled = false;
			} );
		} );

		dialog.querySelector( '.tutorhelper-lms-modal__close' ).addEventListener( 'click', function() {
			dialog.close();
		} );
		dialog.addEventListener( 'close', function() {
			dialog.remove();
			trigger.focus();
		} );
		image.addEventListener( 'load', ready );
		image.addEventListener( 'error', function() {
			var loading = dialog.querySelector( '.tutorhelper-lms-annotation-loading' );
			if ( loading ) {
				loading.remove();
			}
			status.textContent = 'The original image could not be loaded. Close this window and try Mark image again.';
		} );
		image.src = payload.imageUrl;
		if ( typeof dialog.showModal === 'function' ) {
			dialog.showModal();
		} else {
			dialog.setAttribute( 'open', 'open' );
		}
	}

	function openWorkspace( trigger ) {
		var workspaceConfig = trigger.hasAttribute( 'data-tutorhelper-lms-homework-annotation' ) ? ( window.tutorhelperLmsHomeworkAnnotations || {} ) : config;
		var requestData = { nonce: workspaceConfig.nonce };
		if ( trigger.hasAttribute( 'data-tutorhelper-lms-homework-annotation' ) ) {
			requestData.submission_id = trigger.dataset.submissionId;
		} else {
			requestData.attempt_id = trigger.dataset.tutorhelperLmsQuizAnnotation;
			requestData.question_id = trigger.dataset.questionId;
		}
		trigger.disabled = true;
		request( workspaceConfig.loadAction, requestData ).then( function( response ) {
			if ( ! response || ! response.success ) { throw new Error( response && response.data && response.data.message ? response.data.message : workspaceConfig.loadFailed ); }
			createWorkspace( response.data, trigger, workspaceConfig );
		} ).catch( function( error ) { window.alert( error.message || workspaceConfig.loadFailed ); } ).finally( function() { trigger.disabled = false; } );
	}

	document.addEventListener( 'click', function( event ) {
		var trigger = event.target.closest( '[data-tutorhelper-lms-quiz-annotation][data-file-type="image"], [data-tutorhelper-lms-homework-annotation][data-file-type="image"]' );
		if ( trigger ) {
			event.preventDefault();
			openWorkspace( trigger );
		}
	} );

	function initialisePreviews( root ) {
		if ( root.matches && root.matches( '[data-tutorhelper-lms-quiz-annotation-display]' ) ) {
			var ownAnnotation;
			try {
				ownAnnotation = normaliseDocument( JSON.parse( root.dataset.annotation || '{}' ) );
				updatePreview( root, ownAnnotation );
			} catch ( error ) {}
		}
		if ( root.querySelectorAll ) {
			root.querySelectorAll( '[data-tutorhelper-lms-quiz-annotation-display]' ).forEach( function( wrapper ) {
				var annotation;
				try {
					annotation = normaliseDocument( JSON.parse( wrapper.dataset.annotation || '{}' ) );
					updatePreview( wrapper, annotation );
				} catch ( error ) {}
			} );
		}
	}

	function initialise() {
		initialisePreviews( document );
		new MutationObserver( function( mutations ) {
			mutations.forEach( function( mutation ) {
				mutation.addedNodes.forEach( function( node ) {
					if ( node.nodeType === 1 ) {
						initialisePreviews( node );
					}
				} );
			} );
		} ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', initialise );
	} else {
		initialise();
	}
} )();
