( function() {
	'use strict';

	var config = window.tutorhelperLmsQuizAnnotations || window.tutorhelperLmsHomeworkPdfAnnotations || {};
	var pdfLibrary;
	var stampGroups = [
		[ 'General script', [ [ 'seen', 'SEEN' ], [ 'tick', '✓' ], [ 'cross', '✗' ], [ 'nr', 'NR' ], [ 'bod', 'BoD' ], [ 'tv', 'TV' ], [ 'i', 'I' ], [ 'rep', 'REP' ], [ 'con', 'CON' ] ] ],
		[ 'Extended response', [ [ 'ao1', 'AO1' ], [ 'ao2', 'AO2' ], [ 'ao3', 'AO3' ], [ 'ku', 'KU' ], [ 'dev', 'DEV' ], [ 'eval', 'EVAL' ], [ 'l1', 'L1' ], [ 'l2', 'L2' ], [ 'l3', 'L3' ], [ 'l4', 'L4' ], [ 'eg', 'EG' ], [ 'omission', '^' ] ] ],
		[ 'Maths & Science', [ [ 'm', 'M' ], [ 'a', 'A' ], [ 'b', 'B' ], [ 'ecf', 'ECF' ], [ 'ft', 'FT' ], [ 'ae', 'AE' ], [ 'sf', 'SF' ], [ 'unit', 'Unit' ], [ 'isw', 'ISW' ] ] ]
	];
	var labels = {};
	stampGroups.forEach( function( group ) { group[ 1 ].forEach( function( stamp ) { labels[ stamp[ 0 ] ] = stamp[ 1 ]; } ); } );

	function request( action, values ) {
		var body = new URLSearchParams();
		Object.keys( values || {} ).forEach( function( key ) {
			if ( Array.isArray( values[ key ] ) ) {
				values[ key ].forEach( function( value ) { body.append( key + '[]', value ); } );
			} else {
				body.append( key, values[ key ] );
			}
		} );
		body.append( 'action', action );
		return fetch( config.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString() } ).then( function( response ) { return response.json(); } );
	}

	function getPdfLibrary() {
		if ( pdfLibrary ) {
			return Promise.resolve( pdfLibrary );
		}
		return import( config.pdfJsUrl ).then( function( library ) {
			pdfLibrary = library;
			pdfLibrary.GlobalWorkerOptions.workerSrc = config.pdfWorkerUrl;
			return pdfLibrary;
		} );
	}

	function loadPdf( url ) {
		return Promise.all( [
			getPdfLibrary(),
			fetch( url, { credentials: 'same-origin' } ).then( function( response ) {
				if ( ! response.ok ) { throw new Error( 'The submitted PDF could not be loaded.' ); }
				return response.arrayBuffer();
			} )
		] ).then( function( results ) {
			return results[ 0 ].getDocument( { data: results[ 1 ] } ).promise;
		} );
	}

	function emptyPage() {
		return { version: 1, items: [] };
	}

	function documentAnnotations( annotation ) {
		if ( annotation && annotation.pages && typeof annotation.pages === 'object' ) {
			return annotation;
		}
		return { version: 2, pages: { '1': annotation && Array.isArray( annotation.items ) ? annotation : emptyPage() } };
	}

	function pageAnnotations( document, page ) {
		var key = String( page );
		if ( ! document.pages[ key ] || !Array.isArray( document.pages[ key ].items ) ) {
			document.pages[ key ] = emptyPage();
		}
		return document.pages[ key ];
	}

	function pointForEvent( event, canvas ) {
		var bounds = canvas.getBoundingClientRect();
		return { x: Math.max( 0, Math.min( 1, ( event.clientX - bounds.left ) / bounds.width ) ), y: Math.max( 0, Math.min( 1, ( event.clientY - bounds.top ) / bounds.height ) ) };
	}

	function drawItems( canvas, annotation ) {
		var context = canvas.getContext( '2d' );
		context.clearRect( 0, 0, canvas.width, canvas.height );
		( annotation.items || [] ).forEach( function( item ) {
			if ( item.type === 'stamp' ) {
				var stampScale = Math.max( 0.025, Math.min( 0.04, item.scale || 0.035 ) );
				var size = Math.max( 14, Math.round( canvas.width * stampScale ) );
				context.save();
				context.textAlign = 'center';
				context.textBaseline = 'middle';
				context.font = '800 ' + size + 'px Arial, sans-serif';
				context.lineJoin = 'round';
				context.strokeStyle = '#fff';
				context.lineWidth = Math.max( 3, Math.round( size * .16 ) );
				context.strokeText( labels[ item.stamp ] || item.stamp, item.x * canvas.width, item.y * canvas.height );
				context.fillStyle = item.stamp === 'cross' ? '#c83f39' : '#174957';
				context.fillText( labels[ item.stamp ] || item.stamp, item.x * canvas.width, item.y * canvas.height );
				context.restore();
			} else if ( item.type === 'stroke' && item.points && item.points.length > 1 ) {
				context.save();
				context.strokeStyle = item.colour || '#d3483f';
				context.lineWidth = Math.max( 2, canvas.width * ( item.width || .01 ) );
				context.lineCap = 'round';
				context.lineJoin = 'round';
				context.beginPath();
				item.points.forEach( function( point, index ) {
					if ( index ) { context.lineTo( point.x * canvas.width, point.y * canvas.height ); } else { context.moveTo( point.x * canvas.width, point.y * canvas.height ); }
				} );
				context.stroke();
				context.restore();
			}
		} );
	}

	function renderPdfPage( pdf, pageNumber, background, overlay ) {
		return pdf.getPage( pageNumber ).then( function( page ) {
			var viewport = page.getViewport( { scale: 1.55 } );
			background.width = Math.ceil( viewport.width );
			background.height = Math.ceil( viewport.height );
			overlay.width = background.width;
			overlay.height = background.height;
			return page.render( { canvasContext: background.getContext( '2d' ), viewport: viewport } ).promise;
		} );
	}

	function createButton( text, className ) {
		var button = document.createElement( 'button' );
		button.type = 'button';
		button.className = 'button ' + className;
		button.textContent = text;
		return button;
	}

	function renderPdfPreview( wrapper ) {
		if ( wrapper.dataset.pdfPreviewInitialised ) { return; }
		wrapper.dataset.pdfPreviewInitialised = '1';
		var loading = wrapper.querySelector( '.tutorhelper-lms-pdf-annotation-preview__loading' );
		var target = wrapper.querySelector( '.tutorhelper-lms-pdf-annotation-preview__page' );
		var annotation;
		try { annotation = documentAnnotations( JSON.parse( wrapper.dataset.annotation || '{}' ) ); } catch ( error ) { annotation = documentAnnotations(); }
		loadPdf( wrapper.dataset.pdfUrl ).then( function( pdf ) {
			var background = document.createElement( 'canvas' );
			var overlay = document.createElement( 'canvas' );
			var stage = document.createElement( 'div' );
			stage.className = 'tutorhelper-lms-pdf-annotation-stage';
			stage.appendChild( background );
			stage.appendChild( overlay );
			target.appendChild( stage );
			return renderPdfPage( pdf, 1, background, overlay ).then( function() {
				drawItems( overlay, pageAnnotations( annotation, 1 ) );
				if ( loading ) { loading.remove(); }
			} );
		} ).catch( function() {
			if ( loading ) { loading.textContent = 'The PDF preview could not be loaded.'; }
		} );
	}

	function openWorkspace( trigger ) {
		var workspaceConfig = trigger.hasAttribute( 'data-tutorhelper-lms-homework-annotation' ) ? ( window.tutorhelperLmsHomeworkPdfAnnotations || {} ) : config;
		var requestData = { nonce: workspaceConfig.nonce };
		if ( trigger.hasAttribute( 'data-tutorhelper-lms-homework-annotation' ) ) { requestData.submission_id = trigger.dataset.submissionId; } else { requestData.attempt_id = trigger.dataset.tutorhelperLmsQuizAnnotation; requestData.question_id = trigger.dataset.questionId; }
		trigger.disabled = true;
		request( workspaceConfig.loadAction, requestData ).then( function( response ) {
			if ( ! response || ! response.success ) { throw new Error( response && response.data && response.data.message ? response.data.message : workspaceConfig.loadFailed ); }
			return createWorkspace( response.data, trigger, workspaceConfig );
		} ).catch( function( error ) { window.alert( error.message || workspaceConfig.loadFailed ); } ).finally( function() { trigger.disabled = false; } );
	}

	function createWorkspace( payload, trigger, workspaceConfig ) {
		var annotations = documentAnnotations( payload.annotation );
		var favourites = Array.isArray( payload.favourites ) ? payload.favourites : [ 'tick', 'cross', 'nr', 'bod', 'ft' ];
		var drawing = payload.drawing || { colour: '#d3483f', width: 4 };
		var selected = { tool: 'draw', stamp: '' };
		var pageNumber = 1;
		var pdf;
		var activeStroke = null;
		var erasing = false;
		var dialog = document.createElement( 'dialog' );
		dialog.className = 'tutorhelper-lms-modal tutorhelper-lms-annotation-modal tutorhelper-lms-pdf-annotation-modal';
		dialog.innerHTML = '<div class="tutorhelper-lms-modal__header"><h2></h2><button type="button" class="button-link tutorhelper-lms-modal__close" aria-label="Close PDF marking">×</button></div><div class="tutorhelper-lms-modal__body"><p class="description">Mark each PDF page using the same stamps and ink tools. Tick stamps fill the question mark until you change it. Page annotations are saved independently.</p><div class="tutorhelper-lms-pdf-annotation-pages"><button type="button" class="button" data-page-previous>Previous</button><strong data-page-label>Loading PDF…</strong><button type="button" class="button" data-page-next>Next</button></div><section class="tutorhelper-lms-annotation-favourites-wrap"><h3>My stamps</h3><div class="tutorhelper-lms-annotation-favourites" data-pdf-favourites></div></section><div class="tutorhelper-lms-annotation-draw-tools"><button type="button" class="button tutorhelper-lms-annotation-tool is-active" data-tool="draw">Draw</button><button type="button" class="button tutorhelper-lms-annotation-tool" data-tool="eraser">Eraser</button><label>Colour <input type="color" value="' + drawing.colour + '" data-colour /></label><label>Pen width <input type="range" min="1" max="12" value="' + drawing.width + '" data-width /><output data-width-output>' + drawing.width + '</output></label></div><details class="tutorhelper-lms-annotation-group"><summary>More stamps</summary><div class="tutorhelper-lms-annotation-stamp-grid" data-pdf-all-stamps></div></details><div class="tutorhelper-lms-pdf-annotation-stage" data-pdf-stage><canvas data-pdf-page></canvas><canvas data-pdf-overlay aria-label="PDF annotation canvas"></canvas><p class="tutorhelper-lms-annotation-loading"><span class="tutorhelper-lms-annotation-spinner" aria-hidden="true"></span> Loading PDF…</p></div><p class="tutorhelper-lms-annotation-status" role="status"></p><div class="tutorhelper-lms-modal__actions"><button type="button" class="button" data-undo>Undo last</button><button type="button" class="button" data-clear>Clear this page</button><button type="button" class="button button-primary" data-save>Save annotations</button></div></div>';
		document.body.appendChild( dialog );

		var title = dialog.querySelector( 'h2' );
		var background = dialog.querySelector( '[data-pdf-page]' );
		var overlay = dialog.querySelector( '[data-pdf-overlay]' );
		var stage = dialog.querySelector( '[data-pdf-stage]' );
		var loading = dialog.querySelector( '.tutorhelper-lms-annotation-loading' );
		var pageLabel = dialog.querySelector( '[data-page-label]' );
		var previous = dialog.querySelector( '[data-page-previous]' );
		var next = dialog.querySelector( '[data-page-next]' );
		var favouritesElement = dialog.querySelector( '[data-pdf-favourites]' );
		var allStampsElement = dialog.querySelector( '[data-pdf-all-stamps]' );
		var colour = dialog.querySelector( '[data-colour]' );
		var width = dialog.querySelector( '[data-width]' );
		var widthOutput = dialog.querySelector( '[data-width-output]' );
		var status = dialog.querySelector( '.tutorhelper-lms-annotation-status' );
		var markInput = document.querySelector( '[data-tutorhelper-lms-question-mark-attempt="' + payload.attemptId + '"][data-tutorhelper-lms-question-mark-question="' + payload.questionId + '"]' );
		var markIsManual = !! ( markInput && markInput.value !== '' );
		var syncingTickMark = false;
		title.textContent = payload.filename || 'Mark PDF';

		function totalTickCount() {
			return Object.keys( annotations.pages ).reduce( function( total, page ) {
				return total + ( annotations.pages[ page ].items || [] ).filter( function( item ) { return item.type === 'stamp' && item.stamp === 'tick'; } ).length;
			}, 0 );
		}
		function syncTickMark() {
			if ( ! markInput || markIsManual ) {
				return;
			}
			syncingTickMark = true;
			var ticks = totalTickCount();
			markInput.value = String( ticks );
			markInput.dispatchEvent( new Event( 'input', { bubbles: true } ) );
			status.textContent = ticks > Number( markInput.max ) ? 'There are ' + ticks + ' tick stamps across this PDF, which is above the question maximum of ' + markInput.max + '.' : 'Question mark auto-filled from ' + ticks + ' tick stamp' + ( ticks === 1 ? '' : 's' ) + ' across this PDF.';
			syncingTickMark = false;
		}
		if ( markInput ) {
			markInput.addEventListener( 'input', function() {
				if ( ! syncingTickMark ) {
					markIsManual = true;
				}
			} );
		}
		syncTickMark();

		function currentAnnotation() { return pageAnnotations( annotations, pageNumber ); }
		function redraw() { drawItems( overlay, currentAnnotation() ); }
		function updateTool() {
			dialog.querySelectorAll( '[data-tool], [data-stamp]' ).forEach( function( button ) {
				button.classList.toggle( 'is-active', ( button.dataset.tool && button.dataset.tool === selected.tool ) || ( button.dataset.stamp && selected.tool === 'stamp' && button.dataset.stamp === selected.stamp ) );
			} );
			stage.classList.toggle( 'is-drawing', selected.tool === 'draw' );
			stage.classList.toggle( 'is-erasing', selected.tool === 'eraser' );
		}
		function stampButton( id, label ) {
			var button = createButton( label, 'tutorhelper-lms-annotation-stamp' );
			button.dataset.stamp = id;
			button.title = label;
			button.addEventListener( 'click', function() { selected = { tool: 'stamp', stamp: id }; updateTool(); } );
			return button;
		}
		favourites.forEach( function( id ) { if ( labels[ id ] ) { favouritesElement.appendChild( stampButton( id, labels[ id ] ) ); } } );
		stampGroups.forEach( function( group ) {
			var title = document.createElement( 'strong' );
			title.className = 'tutorhelper-lms-pdf-stamp-group__title';
			title.textContent = group[ 0 ];
			allStampsElement.appendChild( title );
			group[ 1 ].forEach( function( stamp ) { allStampsElement.appendChild( stampButton( stamp[ 0 ], stamp[ 1 ] ) ); } );
		} );
		dialog.querySelectorAll( '[data-tool]' ).forEach( function( button ) {
			button.addEventListener( 'click', function() { selected = { tool: button.dataset.tool, stamp: '' }; updateTool(); } );
		} );
		colour.addEventListener( 'input', function() { drawing.colour = colour.value; } );
		width.addEventListener( 'input', function() { drawing.width = Number( width.value ); widthOutput.textContent = width.value; } );

		function showPage( page ) {
			pageNumber = page;
			loading.hidden = false;
			loading.textContent = 'Rendering page ' + page + '…';
			return renderPdfPage( pdf, page, background, overlay ).then( function() {
				redraw();
				loading.hidden = true;
				pageLabel.textContent = 'Page ' + pageNumber + ' of ' + pdf.numPages;
				previous.disabled = pageNumber === 1;
				next.disabled = pageNumber === pdf.numPages;
			} );
		}
		previous.addEventListener( 'click', function() { if ( pageNumber > 1 ) { showPage( pageNumber - 1 ); } } );
		next.addEventListener( 'click', function() { if ( pdf && pageNumber < pdf.numPages ) { showPage( pageNumber + 1 ); } } );

		function eraseAt( point ) {
			var radius = .008 + ( Number( drawing.width ) * .002 );
			var page = currentAnnotation();
			page.items = page.items.filter( function( item ) {
				if ( item.type !== 'stroke' || ! item.points ) { return true; }
				return ! item.points.some( function( strokePoint ) {
					var x = strokePoint.x - point.x;
					var y = strokePoint.y - point.y;
					return Math.sqrt( ( x * x ) + ( y * y ) ) <= radius;
				} );
			} );
			redraw();
		}
		overlay.addEventListener( 'pointerdown', function( event ) {
			if ( event.button !== 0 || ! overlay.width ) { return; }
			var point = pointForEvent( event, overlay );
			var page = currentAnnotation();
			if ( selected.tool === 'stamp' ) {
				page.items.push( { type: 'stamp', stamp: selected.stamp, x: point.x, y: point.y, scale: .035 } );
				redraw();
				syncTickMark();
				return;
			}
			if ( selected.tool === 'eraser' ) {
				erasing = true;
				overlay.setPointerCapture( event.pointerId );
				eraseAt( point );
				return;
			}
			activeStroke = { type: 'stroke', colour: drawing.colour, width: Number( drawing.width ) * .0035, points: [ point ] };
			page.items.push( activeStroke );
			overlay.setPointerCapture( event.pointerId );
			redraw();
		} );
		overlay.addEventListener( 'pointermove', function( event ) {
			if ( erasing ) { eraseAt( pointForEvent( event, overlay ) ); return; }
			if ( activeStroke ) { activeStroke.points.push( pointForEvent( event, overlay ) ); redraw(); }
		} );
		function finish() {
			if ( activeStroke && activeStroke.points.length < 2 ) { currentAnnotation().items.pop(); redraw(); }
			activeStroke = null;
			erasing = false;
		}
		overlay.addEventListener( 'pointerup', finish );
		overlay.addEventListener( 'pointercancel', finish );
		overlay.addEventListener( 'contextmenu', function( event ) {
			event.preventDefault();
			var point = pointForEvent( event, overlay );
			var page = currentAnnotation();
			for ( var index = page.items.length - 1; index >= 0; index-- ) {
				var item = page.items[ index ];
				if ( item.type === 'stamp' && Math.abs( point.x - item.x ) <= Math.max( item.scale || .06, .04 ) && Math.abs( point.y - item.y ) <= Math.max( item.scale || .06, .04 ) ) {
					page.items.splice( index, 1 );
					redraw();
					syncTickMark();
					return;
				}
			}
		} );
		dialog.querySelector( '[data-undo]' ).addEventListener( 'click', function() { currentAnnotation().items.pop(); redraw(); syncTickMark(); } );
		dialog.querySelector( '[data-clear]' ).addEventListener( 'click', function() { if ( currentAnnotation().items.length && window.confirm( 'Clear all stamps and ink on this page?' ) ) { currentAnnotation().items = []; redraw(); syncTickMark(); } } );
		dialog.querySelector( '[data-save]' ).addEventListener( 'click', function( event ) {
			var button = event.currentTarget;
			button.disabled = true;
			status.textContent = 'Saving all PDF page annotations…';
			request( workspaceConfig.saveAction, { nonce: workspaceConfig.saveNonce, submission_id: payload.submissionId || 0, attempt_id: payload.attemptId || 0, question_id: payload.questionId || 0, annotation: JSON.stringify( annotations ) } ).then( function( response ) {
				if ( ! response || ! response.success ) { throw new Error( response && response.data && response.data.message ? response.data.message : workspaceConfig.saveFailed ); }
				annotations = documentAnnotations( response.data.annotation );
				document.querySelectorAll( '[data-tutorhelper-lms-pdf-annotation-preview], [data-tutorhelper-lms-homework-pdf-annotation-preview]' ).forEach( function( preview ) {
					if ( payload.submissionId ? String( preview.dataset.submissionId ) !== String( payload.submissionId ) : ( String( preview.dataset.attemptId ) !== String( payload.attemptId ) || String( preview.dataset.questionId ) !== String( payload.questionId ) ) ) {
						return;
					}
					preview.dataset.annotation = JSON.stringify( annotations );
					var previewCanvases = preview.querySelectorAll( 'canvas' );
					if ( previewCanvases.length > 1 ) {
						drawItems( previewCanvases[ 1 ], pageAnnotations( annotations, 1 ) );
					}
				} );
				status.textContent = 'PDF annotations saved.';
			} ).catch( function( error ) { status.textContent = error.message || workspaceConfig.saveFailed; } ).finally( function() { button.disabled = false; } );
		} );
		dialog.querySelector( '.tutorhelper-lms-modal__close' ).addEventListener( 'click', function() { dialog.close(); } );
		dialog.addEventListener( 'close', function() { dialog.remove(); trigger.focus(); } );
		updateTool();
		dialog.showModal();
		loadPdf( payload.fileUrl ).then( function( loadedPdf ) {
			pdf = loadedPdf;
			return showPage( 1 );
		} ).catch( function( error ) {
			loading.textContent = error.message || 'The PDF could not be rendered.';
		} );
	}

	function canvasBlob( canvas ) {
		return new Promise( function( resolve, reject ) {
			canvas.toBlob( function( blob ) { blob ? resolve( blob ) : reject( new Error( 'The marked PDF page could not be rendered.' ) ); }, 'image/jpeg', 0.92 );
		} );
	}

	async function flattenHomeworkPdf( submissionId ) {
		var workspaceConfig = window.tutorhelperLmsHomeworkPdfAnnotations || {};
		var storeConfig = window.tutorhelperLmsMarkedFiles || {};
		if ( ! workspaceConfig.ajaxUrl || ! workspaceConfig.loadAction || ! workspaceConfig.nonce || ! workspaceConfig.pdfLibUrl || ! storeConfig.storeAction || ! storeConfig.nonce ) {
			throw new Error( 'The marked PDF delivery service is not available. Refresh and try again.' );
		}
		var loaded = await request( workspaceConfig.loadAction, { nonce: workspaceConfig.nonce, submission_id: submissionId } );
		if ( ! loaded || ! loaded.success ) { throw new Error( loaded && loaded.data && loaded.data.message ? loaded.data.message : workspaceConfig.loadFailed ); }
		var payload = loaded.data;
		var annotations = documentAnnotations( payload.annotation );
		var library = await import( workspaceConfig.pdfLibUrl );
		var PDFDocument = library.PDFDocument;
		if ( ! PDFDocument ) { throw new Error( 'The PDF delivery library could not be loaded.' ); }
		var source = await loadPdf( payload.fileUrl );
		var flattened = await PDFDocument.create();
		for ( var pageNumber = 1; pageNumber <= source.numPages; pageNumber++ ) {
			var page = await source.getPage( pageNumber );
			var viewport = page.getViewport( { scale: 2 } );
			var background = document.createElement( 'canvas' );
			var overlay = document.createElement( 'canvas' );
			background.width = Math.ceil( viewport.width ); background.height = Math.ceil( viewport.height );
			overlay.width = background.width; overlay.height = background.height;
			await page.render( { canvasContext: background.getContext( '2d' ), viewport: viewport } ).promise;
			drawItems( overlay, pageAnnotations( annotations, pageNumber ) );
			var composite = document.createElement( 'canvas' );
			composite.width = background.width; composite.height = background.height;
			var compositeContext = composite.getContext( '2d' );
			compositeContext.drawImage( background, 0, 0 ); compositeContext.drawImage( overlay, 0, 0 );
			var image = await flattened.embedJpg( await canvasBlob( composite ).then( function( blob ) { return blob.arrayBuffer(); } ) );
			var outputPage = flattened.addPage( [ viewport.width / 2, viewport.height / 2 ] );
			outputPage.drawImage( image, { x: 0, y: 0, width: viewport.width / 2, height: viewport.height / 2 } );
		}
		var bytes = await flattened.save();
		var filename = ( payload.filename || 'homework.pdf' ).replace( /\.pdf$/i, '' ) + '-marked.pdf';
		var file = new File( [ bytes ], filename, { type: 'application/pdf' } );
		var form = new FormData();
		form.append( 'action', storeConfig.storeAction ); form.append( 'nonce', storeConfig.nonce );
		form.append( 'context_type', 'homework' ); form.append( 'context_id', String( submissionId ) ); form.append( 'item_id', '0' ); form.append( 'marked_file', file );
		var response = await fetch( storeConfig.ajaxUrl || workspaceConfig.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: form } );
		var stored = await response.json();
		if ( ! stored || ! stored.success ) { throw new Error( stored && stored.data && stored.data.message ? stored.data.message : 'The flattened marked PDF could not be stored.' ); }
		return stored.data || {};
	}

	window.TutorHelperLmsFlattenHomeworkPdf = flattenHomeworkPdf;

	document.addEventListener( 'click', function( event ) {
		var trigger = event.target.closest( '[data-tutorhelper-lms-quiz-annotation][data-file-type="pdf"], [data-tutorhelper-lms-homework-annotation][data-file-type="pdf"]' );
		if ( trigger ) { event.preventDefault(); openWorkspace( trigger ); }
	} );

	function initialisePreviews( root ) {
		if ( root.matches && root.matches( '[data-tutorhelper-lms-pdf-annotation-preview], [data-tutorhelper-lms-homework-pdf-annotation-preview]' ) ) { renderPdfPreview( root ); }
		if ( root.querySelectorAll ) { root.querySelectorAll( '[data-tutorhelper-lms-pdf-annotation-preview], [data-tutorhelper-lms-homework-pdf-annotation-preview]' ).forEach( renderPdfPreview ); }
	}
	function initialise() {
		initialisePreviews( document );
		new MutationObserver( function( mutations ) {
			mutations.forEach( function( mutation ) { mutation.addedNodes.forEach( function( node ) { if ( node.nodeType === 1 ) { initialisePreviews( node ); } } ); } );
		} ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) { document.addEventListener( 'DOMContentLoaded', initialise ); } else { initialise(); }
} )();
