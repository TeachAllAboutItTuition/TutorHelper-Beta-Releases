<?php
/**
 * Database schema and versioned migrations for TutorHelper LMS.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Database {

	/** Schema version for the Premium-owned LMS tables. */
	const SCHEMA_VERSION = '0.2.1';

	/**
	 * Create or upgrade LMS tables. This is called only on activation or when
	 * the stored schema version is older than the declared schema version.
	 *
	 * @return void
	 */
	public static function install_or_upgrade() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$assignments     = self::table( 'assignments' );
		$submissions     = self::table( 'submissions' );
		$files           = self::table( 'submission_files' );
		$marks           = self::table( 'marks' );
		$private_files   = self::table( 'private_files' );
		$resource_delivery = self::table( 'resource_delivery' );
		$learning_delivery = self::table( 'learning_delivery' );
		$homework_quiz_attempts = self::table( 'homework_quiz_attempts' );
		$quiz_file_annotations = self::table( 'quiz_file_annotations' );
		$homework_file_annotations = self::table( 'homework_file_annotations' );
		$marked_files = self::table( 'marked_files' );

		$sql = "CREATE TABLE {$assignments} (
			id bigint(20) unsigned NOT NULL auto_increment,
			source_type varchar(32) NOT NULL,
			source_id bigint(20) unsigned NOT NULL DEFAULT 0,
			booking_id bigint(20) unsigned NOT NULL DEFAULT 0,
			course_id bigint(20) unsigned NOT NULL DEFAULT 0,
			source_group_id bigint(20) unsigned NOT NULL DEFAULT 0,
			topic_ids longtext NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			tutor_user_id bigint(20) unsigned NOT NULL,
			assessment_type varchar(20) NOT NULL DEFAULT 'completion',
			title varchar(190) NOT NULL,
			instructions longtext NULL,
			max_mark decimal(10,2) NULL,
			grading_scheme_version varchar(64) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'not_started',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY student_status (student_user_id,status),
			KEY tutor_status (tutor_user_id,status),
			KEY booking_id (booking_id),
			KEY course_id (course_id),
			KEY source_group_id (source_group_id),
			KEY source_reference (source_type,source_id)
		) {$charset_collate};

		CREATE TABLE {$submissions} (
			id bigint(20) unsigned NOT NULL auto_increment,
			assignment_id bigint(20) unsigned NOT NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			attempt_number smallint(5) unsigned NOT NULL DEFAULT 1,
			status varchar(24) NOT NULL DEFAULT 'draft',
			submission_type varchar(20) NOT NULL DEFAULT 'link',
			storage_provider varchar(32) NOT NULL DEFAULT 'shared_link',
			provider_file_id varchar(255) NOT NULL DEFAULT '',
			link_url text NULL,
			submitted_at datetime NULL,
			reopened_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY assignment_attempt (assignment_id,attempt_number),
			KEY student_status (student_user_id,status),
			KEY assignment_id (assignment_id),
			KEY provider_file (storage_provider,provider_file_id)
		) {$charset_collate};

		CREATE TABLE {$files} (
			id bigint(20) unsigned NOT NULL auto_increment,
			submission_id bigint(20) unsigned NOT NULL,
			original_filename varchar(255) NOT NULL,
			storage_key varchar(191) NOT NULL,
			mime_type varchar(100) NOT NULL,
			file_size bigint(20) unsigned NOT NULL,
			file_hash char(64) NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY storage_key (storage_key),
			UNIQUE KEY submission_id (submission_id)
		) {$charset_collate};

		CREATE TABLE {$private_files} (
			id bigint(20) unsigned NOT NULL auto_increment,
			owner_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			entity_type varchar(32) NOT NULL,
			entity_id bigint(20) unsigned NOT NULL,
			version_number smallint(5) unsigned NOT NULL DEFAULT 1,
			storage_provider varchar(32) NOT NULL,
			provider_file_id varchar(255) NOT NULL DEFAULT '',
			storage_key varchar(191) NOT NULL DEFAULT '',
			original_filename varchar(255) NOT NULL,
			display_filename varchar(255) NOT NULL,
			mime_type varchar(100) NOT NULL,
			file_size bigint(20) unsigned NOT NULL DEFAULT 0,
			file_hash char(64) NOT NULL DEFAULT '',
			storage_state varchar(24) NOT NULL DEFAULT 'available',
			source_system varchar(64) NOT NULL DEFAULT '',
			source_identifier varchar(190) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY entity_version (entity_type,entity_id,version_number),
			KEY owner_lookup (owner_user_id,storage_state),
			KEY provider_lookup (storage_provider),
			KEY provider_file_lookup (provider_file_id(100)),
			KEY source_system_lookup (source_system),
			KEY source_identifier_lookup (source_identifier)
		) {$charset_collate};

		CREATE TABLE {$resource_delivery} (
			id bigint(20) unsigned NOT NULL auto_increment,
			source_type varchar(32) NOT NULL,
			source_id bigint(20) unsigned NOT NULL,
			resource_id bigint(20) unsigned NOT NULL,
			resource_version smallint(5) unsigned NOT NULL DEFAULT 1,
			resource_snapshot longtext NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY source_resource (source_type,source_id,resource_id,resource_version),
			KEY resource_lookup (resource_id),
			KEY source_lookup (source_type,source_id)
		) {$charset_collate};

		CREATE TABLE {$learning_delivery} (
			id bigint(20) unsigned NOT NULL auto_increment,
			source_type varchar(32) NOT NULL,
			source_id bigint(20) unsigned NOT NULL DEFAULT 0,
			item_type varchar(32) NOT NULL,
			item_id bigint(20) unsigned NOT NULL DEFAULT 0,
			course_id bigint(20) unsigned NOT NULL DEFAULT 0,
			topic_id bigint(20) unsigned NOT NULL DEFAULT 0,
			item_snapshot longtext NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY source_item (source_type,source_id,item_type,item_id),
			KEY source_lookup (source_type,source_id),
			KEY course_topic_lookup (course_id,topic_id),
			KEY item_lookup (item_type,item_id)
		) {$charset_collate};

		CREATE TABLE {$homework_quiz_attempts} (
			id bigint(20) unsigned NOT NULL auto_increment,
			homework_source_id bigint(20) unsigned NOT NULL,
			assignment_id bigint(20) unsigned NOT NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			placement_id bigint(20) unsigned NOT NULL,
			first_attempt_id bigint(20) unsigned NOT NULL,
			completion_attempt_id bigint(20) unsigned NOT NULL DEFAULT 0,
			awarded_mark decimal(10,2) NOT NULL DEFAULT 0,
			max_mark decimal(10,2) NOT NULL DEFAULT 0,
			completion_status varchar(20) NOT NULL DEFAULT 'submitted',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY homework_student (homework_source_id,student_user_id),
			KEY assignment_lookup (assignment_id),
			KEY placement_lookup (placement_id),
			KEY completion_lookup (completion_status)
		) {$charset_collate};

		CREATE TABLE {$quiz_file_annotations} (
			id bigint(20) unsigned NOT NULL auto_increment,
			attempt_id bigint(20) unsigned NOT NULL,
			question_id bigint(20) unsigned NOT NULL,
			annotation_json longtext NULL,
			marker_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY attempt_question (attempt_id,question_id),
			KEY marker_lookup (marker_user_id)
		) {$charset_collate};

		CREATE TABLE {$homework_file_annotations} (
			id bigint(20) unsigned NOT NULL auto_increment,
			submission_id bigint(20) unsigned NOT NULL,
			annotation_json longtext NULL,
			marker_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY submission_id (submission_id),
			KEY marker_lookup (marker_user_id)
		) {$charset_collate};

		CREATE TABLE {$marked_files} (
			id bigint(20) unsigned NOT NULL auto_increment,
			context_type varchar(20) NOT NULL,
			context_id bigint(20) unsigned NOT NULL,
			item_id bigint(20) unsigned NOT NULL DEFAULT 0,
			storage_provider varchar(32) NOT NULL,
			provider_file_id varchar(191) NOT NULL,
			storage_key varchar(255) NOT NULL DEFAULT '',
			original_filename varchar(255) NOT NULL,
			mime_type varchar(100) NOT NULL,
			file_size bigint(20) unsigned NOT NULL DEFAULT 0,
			file_hash char(64) NOT NULL DEFAULT '',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY context_item (context_type,context_id,item_id),
			KEY delivery_lookup (context_type,context_id)
		) {$charset_collate};

		CREATE TABLE {$marks} (
			id bigint(20) unsigned NOT NULL auto_increment,
			submission_id bigint(20) unsigned NOT NULL,
			marker_user_id bigint(20) unsigned NOT NULL,
			awarded_mark decimal(10,2) NULL,
			feedback longtext NULL,
			status varchar(20) NOT NULL DEFAULT 'draft',
			outcome varchar(24) NOT NULL DEFAULT 'pending',
			grading_scheme_snapshot longtext NULL,
			marked_at datetime NULL,
			released_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY submission_id (submission_id),
			KEY marker_status (marker_user_id,status),
			KEY released_at (released_at)
		) {$charset_collate};";

		dbDelta( $sql );
		self::backfill_submission_file_records();
		update_option( 'tutorhelper_lms_db_version', self::SCHEMA_VERSION, false );
	}

	/**
	 * Add generic file records for existing private submission files.
	 *
	 * This migration is deliberately additive: legacy submission and
	 * submission_files rows remain authoritative for existing workflows.
	 *
	 * @return void
	 */
	private static function backfill_submission_file_records() {
		global $wpdb;
		$private_files = self::table( 'private_files' );
		$submissions   = self::table( 'submissions' );
		$submission_files = self::table( 'submission_files' );
		$now = current_time( 'mysql', true );
		$sql = $wpdb->prepare(
			"INSERT INTO {$private_files} (owner_user_id, entity_type, entity_id, version_number, storage_provider, provider_file_id, storage_key, original_filename, display_filename, mime_type, file_size, file_hash, storage_state, source_system, source_identifier, created_at, updated_at)
			SELECT s.student_user_id, %s, s.id, 1, s.storage_provider, s.provider_file_id, f.storage_key, f.original_filename, f.original_filename, f.mime_type, f.file_size, f.file_hash, %s, %s, CAST(s.id AS CHAR), f.created_at, %s
			FROM {$submissions} s
			INNER JOIN {$submission_files} f ON f.submission_id = s.id
			LEFT JOIN {$private_files} existing ON existing.entity_type = %s AND existing.entity_id = s.id AND existing.version_number = 1
			WHERE s.submission_type = %s AND existing.id IS NULL",
			'submission',
			'available',
			'tutorhelper_lms_submission',
			$now,
			'submission',
			'file'
		);
		$wpdb->query( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- One-time additive migration from existing private submission metadata.
	}

	/**
	 * Run a migration only when a new plugin version declares one.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		$installed_version = (string) get_option( 'tutorhelper_lms_db_version', '' );

		if ( version_compare( $installed_version, self::SCHEMA_VERSION, '<' ) ) {
			self::install_or_upgrade();
		}
	}

	/**
	 * Return the fully prefixed table name for a known LMS table.
	 *
	 * @param string $name Table suffix.
	 * @return string
	 */
	public static function table( $name ) {
		global $wpdb;

		$allowed = array( 'assignments', 'submissions', 'submission_files', 'private_files', 'resource_delivery', 'learning_delivery', 'homework_quiz_attempts', 'quiz_file_annotations', 'homework_file_annotations', 'marked_files', 'marks' );

		if ( ! in_array( $name, $allowed, true ) ) {
			return '';
		}

		return $wpdb->prefix . 'tutorhelper_lms_' . $name;
	}
}
