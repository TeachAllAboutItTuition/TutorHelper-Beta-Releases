<?php
/**
 * Individual LMS Lesson delivery through TutorHelper Pro homework.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Attaches existing LMS Lessons to a specific Pro homework record.
 *
 * The durable delivery record keeps a homework-to-Lesson association without
 * converting an individual tuition association into formal Course enrolment.
 * Its deliberately generic item columns are reserved for later assignment and
 * quiz delivery types.
 */
final class TutorHelper_LMS_Learning_Delivery {

	const SOURCE_HOMEWORK = 'pro_homework';
	const ITEM_LESSON     = 'lesson';
	const LOAD_ACTION     = 'tutorhelper_lms_load_homework_lessons';
	const NONCE           = 'tutorhelper_lms_learning_delivery';

	/**
	 * Register the Pro homework integration.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'tutorhelper_pro_homework_resource_fields', array( __CLASS__, 'render_homework_fields' ), 20 );
		add_filter( 'tutorhelper_pro_homework_has_pending_content', array( __CLASS__, 'has_pending_lessons' ), 20, 2 );
		add_filter( 'tutorhelper_pro_homework_has_content', array( __CLASS__, 'homework_has_lessons' ), 20, 2 );
		add_action( 'tutorhelper_pro_homework_submission_updated', array( __CLASS__, 'save_homework_lessons' ), 30 );
		add_action( 'wp_ajax_' . self::LOAD_ACTION, array( __CLASS__, 'ajax_load_homework_lessons' ) );
		add_action( 'tutorhelper_pro_homework_student_actions', array( __CLASS__, 'render_student_lessons' ), 30 );
		add_filter( 'tutorhelper_lms_learner_can_view_lesson', array( __CLASS__, 'homework_allows_lesson' ), 30, 5 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_tutor_assets' ) );
	}


	/**
	 * Keep a new homework record when it has Lessons but no written task,
	 * upload or student submission. Pro has already verified the save request.
	 *
	 * @param bool  $has_content Existing decision.
	 * @param array $request     Submitted fields.
	 * @return bool
	 */
	public static function has_pending_lessons( $has_content, $request ) {
		if ( $has_content || ! is_array( $request ) || empty( $request['homework_lesson_ids'] ) || ! is_array( $request['homework_lesson_ids'] ) ) {
			return (bool) $has_content;
		}
		return ! empty( array_filter( array_map( 'absint', wp_unslash( $request['homework_lesson_ids'] ) ) ) );
	}

	/**
	 * Tell Pro that an existing Lesson delivery is homework content.
	 *
	 * @param bool   $has_content Existing decision.
	 * @param object $homework    Pro homework record.
	 * @return bool
	 */
	public static function homework_has_lessons( $has_content, $homework ) {
		if ( $has_content || ! $homework || empty( $homework->id ) ) {
			return (bool) $has_content;
		}
		return ! empty( self::lesson_ids( absint( $homework->id ) ) );
	}

	/**
	 * Render Lesson choices inside the established feedback and homework modal.
	 *
	 * @return void
	 */
	public static function render_homework_fields() {
		$lessons = self::tutor_lessons( get_current_user_id() );
		?>
		<fieldset class="tutorhelper-pro-homework-resources" data-tutorhelper-lms-homework-lessons>
			<legend><?php esc_html_e( 'LMS lessons', 'tutorhelper-lms' ); ?></legend>
			<p class="description"><?php esc_html_e( 'Attach one or more Lessons for this student to complete. Lessons are narrowed to the selected Course and Topics.', 'tutorhelper-lms' ); ?></p>
			<?php if ( empty( $lessons ) ) : ?>
				<p class="description"><?php esc_html_e( 'No Lessons are available yet. Add Lessons in Learning Hub → Courses.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<p><label class="screen-reader-text" for="tutorhelper-lms-homework-lesson-search"><?php esc_html_e( 'Search LMS lessons', 'tutorhelper-lms' ); ?></label><input id="tutorhelper-lms-homework-lesson-search" class="regular-text" type="search" placeholder="<?php esc_attr_e( 'Search selected lessons…', 'tutorhelper-lms' ); ?>" data-tutorhelper-lms-lesson-search /></p>
				<p class="description" data-tutorhelper-lms-lesson-context><?php esc_html_e( 'Select a Course and at least one Topic to view matching Lessons.', 'tutorhelper-lms' ); ?></p>
				<div class="tutorhelper-lms-resource-selector" data-tutorhelper-lms-lesson-selector>
					<?php foreach ( $lessons as $lesson ) : ?>
						<label data-tutorhelper-lms-lesson-row data-lesson-contexts="<?php echo esc_attr( implode( ',', $lesson['contexts'] ) ); ?>">
							<input type="checkbox" name="homework_lesson_ids[]" value="<?php echo esc_attr( $lesson['id'] ); ?>" />
							<?php echo esc_html( $lesson['title'] ); ?>
							<span class="description" hidden data-tutorhelper-lms-previous-lesson>↻ <?php esc_html_e( 'Previously assigned', 'tutorhelper-lms' ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>
				<p class="description" hidden data-tutorhelper-lms-lesson-empty><?php esc_html_e( 'No matching Lessons were found. Refine the Course, Topics or search.', 'tutorhelper-lms' ); ?></p>
			<?php endif; ?>
		</fieldset>
		<?php
	}

	/**
	 * Load prior Lesson choices and non-blocking repeat indicators.
	 *
	 * @return void
	 */
	public static function ajax_load_homework_lessons() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to view these lessons.', 'tutorhelper-lms' ) ), 403 );
		}
		check_ajax_referer( self::NONCE, 'nonce' );
		$source_id = isset( $_POST['source_id'] ) && ! is_array( $_POST['source_id'] ) ? absint( wp_unslash( $_POST['source_id'] ) ) : 0;
		$assignment = self::tutor_assignment( $source_id );
		if ( ! $assignment ) {
			wp_send_json_error( array( 'message' => __( 'The homework could not be found.', 'tutorhelper-lms' ) ), 404 );
		}
		$payload = array(
			'lessonIds'         => self::lesson_ids( $source_id ),
			'previousLessonIds' => self::previous_lesson_ids( absint( $assignment->student_user_id ), $source_id ),
		);
		wp_send_json_success( apply_filters( 'tutorhelper_lms_homework_learning_delivery_payload', $payload, $source_id, $assignment ) );
	}

	/**
	 * Store validated Lesson attachments after Pro has saved the homework.
	 *
	 * @param array $homework Sanitised Pro homework payload.
	 * @return void
	 */
	public static function save_homework_lessons( $homework ) {
		if ( ! is_array( $homework ) || empty( $homework['source_id'] ) || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$source_id = absint( $homework['source_id'] );
		$course_id = absint( $homework['course_id'] ?? 0 );
		$topic_ids = isset( $homework['topic_ids'] ) && is_array( $homework['topic_ids'] ) ? array_values( array_unique( array_filter( array_map( 'absint', $homework['topic_ids'] ) ) ) ) : array();
		$requested = isset( $_POST['homework_lesson_ids'] ) && is_array( $_POST['homework_lesson_ids'] ) ? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['homework_lesson_ids'] ) ) ) ) ) : array();
		$available = self::tutor_lessons( get_current_user_id() );
		$allowed = array();
		foreach ( $available as $lesson ) {
			$matching_topics = self::matching_topics( $lesson['contexts'], $course_id, $topic_ids );
			if ( ! in_array( absint( $lesson['id'] ), $requested, true ) || empty( $matching_topics ) ) {
				continue;
			}
			$lesson['selected_topic_id'] = absint( $matching_topics[0] );
			$allowed[] = $lesson;
		}
		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'learning_delivery' );
		$deleted = $wpdb->delete( $table, array( 'source_type' => self::SOURCE_HOMEWORK, 'source_id' => $source_id, 'item_type' => self::ITEM_LESSON ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Replaces this homework's explicit learning attachments.
		if ( false === $deleted ) {
			self::log_failure( 'learning_delivery_delete_failed', $source_id );
			return;
		}
		foreach ( $allowed as $lesson ) {
			$topic_id = absint( $lesson['selected_topic_id'] ?? 0 );
			if ( ! $topic_id ) {
				continue;
			}
			$inserted = $wpdb->insert(
				$table,
				array(
					'source_type'   => self::SOURCE_HOMEWORK,
					'source_id'     => $source_id,
					'item_type'     => self::ITEM_LESSON,
					'item_id'       => absint( $lesson['id'] ),
					'course_id'     => $course_id,
					'topic_id'      => $topic_id,
					'item_snapshot' => wp_json_encode( array( 'title' => sanitize_text_field( $lesson['title'] ) ) ),
					'created_at'    => current_time( 'mysql', true ),
				),
				array( '%s', '%d', '%s', '%d', '%d', '%d', '%s', '%s' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Stores one frozen Lesson-to-homework relationship.
			if ( false === $inserted ) {
				self::log_failure( 'learning_delivery_insert_failed', absint( $lesson['id'] ) );
			}
		}
	}

	/**
	 * Render open-Lesson links beneath the linked homework on the student dashboard.
	 *
	 * @param object $homework Pro homework record.
	 * @return void
	 */
	public static function render_student_lessons( $homework ) {
		if ( ! $homework || empty( $homework->id ) || ! is_user_logged_in() ) {
			return;
		}
		$student_id = get_current_user_id();
		$rows = self::student_lessons( absint( $homework->id ), $student_id );
		if ( empty( $rows ) || ! class_exists( 'TutorHelper_LMS_Learner_Access' ) ) {
			return;
		}
		$base_url = get_permalink();
		if ( class_exists( 'TutorHelper_Student_Account' ) ) {
			$base_url = add_query_arg( TutorHelper_Student_Account::TAB_QUERY, TutorHelper_LMS_Learner_Access::DASHBOARD_TAB, $base_url );
		}
		?>
		<div class="tutorhelper-lms-student-resources">
			<strong><?php esc_html_e( 'LMS lessons to complete', 'tutorhelper-lms' ); ?></strong>
			<?php foreach ( $rows as $row ) : ?>
				<p><span><?php echo esc_html( self::snapshot_title( $row ) ); ?></span> <a class="tutorhelper-button" href="<?php echo esc_url( TutorHelper_LMS_Learner_Access::lesson_url( $base_url, $row->course_id, $row->topic_id, $row->item_id ) ); ?>"><?php esc_html_e( 'Open lesson', 'tutorhelper-lms' ); ?></a></p>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Permit a specific Lesson only where it is still assigned through the
	 * student's own homework. Historical homework access remains available even
	 * if the student later leaves a Group or direct Course association.
	 *
	 * @param bool $allowed Existing decision.
	 * @param int  $student_user_id Student ID.
	 * @param int  $course_id Course ID.
	 * @param int  $topic_id Topic ID.
	 * @param int  $lesson_id Lesson ID.
	 * @return bool
	 */
	public static function homework_allows_lesson( $allowed, $student_user_id, $course_id, $topic_id, $lesson_id ) {
		if ( $allowed ) {
			return true;
		}
		global $wpdb;
		$delivery = TutorHelper_LMS_Database::table( 'learning_delivery' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT d.id FROM {$delivery} d INNER JOIN {$assignments} a ON a.source_type = d.source_type AND a.source_id = d.source_id WHERE d.source_type = %s AND d.item_type = %s AND d.item_id = %d AND d.course_id = %d AND d.topic_id = %d AND a.student_user_id = %d AND a.status != %s LIMIT 1",
				self::SOURCE_HOMEWORK,
				self::ITEM_LESSON,
				absint( $lesson_id ),
				absint( $course_id ),
				absint( $topic_id ),
				absint( $student_user_id ),
				'archived'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorises one explicit student homework Lesson.
		return (bool) $found;
	}

	/** Enqueue small modal-only filtering script. */
	public static function enqueue_tutor_assets() {
		if ( ! is_admin() ) {
			return;
		}
		$path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-learning-delivery.js';
		wp_enqueue_script( 'tutorhelper-lms-learning-delivery', TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-learning-delivery.js', array(), file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_LMS_PREMIUM_VERSION, true );
		wp_localize_script(
			'tutorhelper-lms-learning-delivery',
			'tutorhelperLmsLearningDelivery',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => self::LOAD_ACTION,
				'nonce'   => wp_create_nonce( self::NONCE ),
			)
		);
	}

	/** Return Lesson choices owned by the current tutor and their valid contexts. */
	private static function tutor_lessons( $tutor_id ) {
		$posts = get_posts(
			array(
				'post_type'      => 'tutorhelper_lesson',
				'post_status'    => 'publish',
				'author'         => absint( $tutor_id ),
				'numberposts'    => 500,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'suppress_filters' => false,
			)
		);
		$result = array();
		foreach ( $posts as $post ) {
			$contexts = self::lesson_contexts( $post->ID );
			if ( empty( $contexts ) ) {
				continue;
			}
			$result[] = array(
				'id'         => absint( $post->ID ),
				'title'      => sanitize_text_field( get_the_title( $post->ID ) ),
				'course_ids' => array_values( array_unique( array_map( 'absint', wp_list_pluck( $contexts, 'course_id' ) ) ) ),
				'topic_ids'  => array_values( array_unique( array_map( 'absint', wp_list_pluck( $contexts, 'topic_id' ) ) ) ),
				'contexts'   => array_values( array_unique( array_map( static function( $context ) { return absint( $context->course_id ) . ':' . absint( $context->topic_id ); }, $contexts ) ) ),
			);
		}
		return $result;
	}

	/** Return valid Course/Topic parents for a reusable Lesson. */
	private static function lesson_contexts( $lesson_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT course.parent_id AS course_id, topic.parent_id AS topic_id FROM {$table} topic INNER JOIN {$table} course ON course.parent_type = %s AND course.child_type = %s AND course.child_id = topic.parent_id WHERE topic.parent_type = %s AND topic.child_type = %s AND topic.child_id = %d",
				'tutorhelper_course',
				'tutorhelper_topic',
				'tutorhelper_topic',
				'tutorhelper_lesson',
				absint( $lesson_id )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads reusable course structure for owned Lesson choices.
		return is_array( $rows ) ? $rows : array();
	}

	/** Return all attached Lesson rows for one homework. */
	private static function lessons( $source_id ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM " . TutorHelper_LMS_Database::table( 'learning_delivery' ) . " WHERE source_type = %s AND source_id = %d AND item_type = %s ORDER BY id ASC",
				self::SOURCE_HOMEWORK,
				absint( $source_id ),
				self::ITEM_LESSON
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads explicit Lesson attachments for one homework.
	}

	/** Return attached Lesson identifiers. */
	private static function lesson_ids( $source_id ) {
		return array_map( 'absint', wp_list_pluck( self::lessons( $source_id ), 'item_id' ) );
	}

	/** Return Lesson rows owned by the current student. */
	private static function student_lessons( $source_id, $student_id ) {
		global $wpdb;
		$delivery = TutorHelper_LMS_Database::table( 'learning_delivery' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT d.* FROM {$delivery} d INNER JOIN {$assignments} a ON a.source_type = d.source_type AND a.source_id = d.source_id WHERE d.source_type = %s AND d.source_id = %d AND d.item_type = %s AND a.student_user_id = %d AND a.status != %s ORDER BY d.id ASC",
				self::SOURCE_HOMEWORK,
				absint( $source_id ),
				self::ITEM_LESSON,
				absint( $student_id ),
				'archived'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Limits each student to Lessons on their own homework.
	}

	/** Return tutor-owned assignment context for an AJAX request. */
	private static function tutor_assignment( $source_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM " . TutorHelper_LMS_Database::table( 'assignments' ) . " WHERE source_type = %s AND source_id = %d AND tutor_user_id = %d LIMIT 1",
				self::SOURCE_HOMEWORK,
				absint( $source_id ),
				get_current_user_id()
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorises tutor loading one existing homework choice.
	}

	/** Return previously assigned Lessons for a duplicate-assignment hint. */
	private static function previous_lesson_ids( $student_id, $exclude_source_id ) {
		global $wpdb;
		$delivery = TutorHelper_LMS_Database::table( 'learning_delivery' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT d.item_id FROM {$delivery} d INNER JOIN {$assignments} a ON a.source_type = d.source_type AND a.source_id = d.source_id WHERE d.source_type = %s AND d.item_type = %s AND a.student_user_id = %d AND d.source_id != %d",
				self::SOURCE_HOMEWORK,
				self::ITEM_LESSON,
				absint( $student_id ),
				absint( $exclude_source_id )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Optional duplicate-assignment hint.
		return array_map( 'absint', is_array( $ids ) ? $ids : array() );
	}

	/** Return selected Topics which form an exact Course/Topic context for a Lesson. */
	private static function matching_topics( $contexts, $course_id, $selected_topic_ids ) {
		$valid = array_map( 'strval', is_array( $contexts ) ? $contexts : array() );
		$matches = array();
		foreach ( array_map( 'absint', $selected_topic_ids ) as $topic_id ) {
			if ( in_array( absint( $course_id ) . ':' . $topic_id, $valid, true ) ) {
				$matches[] = $topic_id;
			}
		}
		return $matches;
	}

	/** Return snapshot title, safely falling back to the current Lesson title. */
	private static function snapshot_title( $row ) {
		$snapshot = ! empty( $row->item_snapshot ) ? json_decode( $row->item_snapshot, true ) : array();
		return ! empty( $snapshot['title'] ) ? sanitize_text_field( $snapshot['title'] ) : sanitize_text_field( get_the_title( absint( $row->item_id ) ) );
	}

	/** Log a privacy-safe operational failure. */
	private static function log_failure( $reason, $entity_id ) {
		do_action( 'tutorhelper_diagnostics_log', 'warning', 'LMS homework Lesson delivery failed.', array( 'component' => 'lms', 'operation' => 'homework_lesson_delivery', 'entity_id' => absint( $entity_id ), 'failure_reason' => sanitize_key( $reason ) ) );
	}
}
