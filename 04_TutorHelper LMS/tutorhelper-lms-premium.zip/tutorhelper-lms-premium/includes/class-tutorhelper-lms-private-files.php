<?php
/**
 * Provider-independent records for private TutorHelper LMS files.
 *
 * These records do not deliver files or grant access. They retain safe metadata
 * while the storage provider remains responsible for the physical file.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Private_Files {

	const ENTITY_SUBMISSION = 'submission';
	const ENTITY_RESOURCE   = 'resource';

	/**
	 * Create or update the generic record for one existing submission file.
	 *
	 * @param int   $submission_id Submission ID.
	 * @param int   $owner_user_id Student owner ID.
	 * @param array $stored        Verified storage metadata.
	 * @return int|WP_Error Generic file-record ID or an error.
	 */
	public static function sync_submission_file( $submission_id, $owner_user_id, $stored ) {
		return self::sync_file( self::ENTITY_SUBMISSION, $submission_id, $owner_user_id, $stored, 'tutorhelper_lms_submission', (string) absint( $submission_id ) );
	}

	/**
	 * Create the generic record for a master Resource file.
	 *
	 * Resource R2 deliberately creates version 1 only. File replacement and
	 * historical versions are reserved for R5.
	 *
	 * @param int   $resource_id Resource post ID.
	 * @param int   $owner_user_id Tutor owner ID.
	 * @param array $stored Verified storage metadata.
	 * @return int|WP_Error Generic file-record ID or an error.
	 */
	public static function sync_resource_file( $resource_id, $owner_user_id, $stored ) {
		return self::sync_file( self::ENTITY_RESOURCE, $resource_id, $owner_user_id, $stored, 'tutorhelper_lms_resource', (string) absint( $resource_id ) );
	}

	/**
	 * Upsert a private-file metadata record without granting file access.
	 *
	 * @param string $entity_type Logical entity type.
	 * @param int    $entity_id Logical entity ID.
	 * @param int    $owner_user_id File owner.
	 * @param array  $stored Verified storage metadata.
	 * @param string $source_system Stable origin.
	 * @param string $source_identifier Stable origin identifier.
	 * @return int|WP_Error Generic file-record ID or an error.
	 */
	private static function sync_file( $entity_type, $entity_id, $owner_user_id, $stored, $source_system, $source_identifier ) {
		$entity_id = absint( $entity_id );
		if ( ! $entity_id || ! is_array( $stored ) ) {
			return new WP_Error( 'tutorhelper_lms_private_file_invalid', __( 'The private file record could not be prepared.', 'tutorhelper-lms' ) );
		}

		$record = array(
			'owner_user_id'     => absint( $owner_user_id ),
			'entity_type'       => sanitize_key( $entity_type ),
			'entity_id'         => $entity_id,
			'version_number'    => 1,
			'storage_provider'  => sanitize_key( isset( $stored['provider'] ) ? $stored['provider'] : '' ),
			'provider_file_id'  => sanitize_text_field( isset( $stored['provider_file_id'] ) ? $stored['provider_file_id'] : '' ),
			'storage_key'       => sanitize_text_field( isset( $stored['storage_key'] ) ? $stored['storage_key'] : '' ),
			'original_filename' => sanitize_file_name( isset( $stored['original_filename'] ) ? $stored['original_filename'] : '' ),
			'display_filename'  => sanitize_file_name( isset( $stored['display_filename'] ) ? $stored['display_filename'] : ( isset( $stored['original_filename'] ) ? $stored['original_filename'] : '' ) ),
			'mime_type'         => sanitize_mime_type( isset( $stored['mime_type'] ) ? $stored['mime_type'] : '' ),
			'file_size'         => absint( isset( $stored['file_size'] ) ? $stored['file_size'] : 0 ),
			'file_hash'         => preg_replace( '/[^a-f0-9]/i', '', (string) ( isset( $stored['file_hash'] ) ? $stored['file_hash'] : '' ) ),
			'storage_state'     => 'available',
			'source_system'     => sanitize_key( $source_system ),
			'source_identifier' => sanitize_text_field( $source_identifier ),
			'updated_at'        => current_time( 'mysql', true ),
		);

		if ( '' === $record['storage_provider'] || '' === $record['provider_file_id'] || '' === $record['original_filename'] || '' === $record['mime_type'] ) {
			return new WP_Error( 'tutorhelper_lms_private_file_metadata_missing', __( 'The private file record is missing required storage metadata.', 'tutorhelper-lms' ) );
		}

		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'private_files' );
		$existing_id = absint( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE entity_type = %s AND entity_id = %d AND version_number = %d", $record['entity_type'], $entity_id, 1 ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Looks up one generic private-file record.

		if ( $existing_id ) {
			$updated = $wpdb->update( $table, $record, array( 'id' => $existing_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Synchronises metadata for one authorised private file.
			return false === $updated ? new WP_Error( 'tutorhelper_lms_private_file_update_failed', __( 'The private file record could not be updated.', 'tutorhelper-lms' ) ) : $existing_id;
		}

		$record['created_at'] = current_time( 'mysql', true );
		$inserted = $wpdb->insert( $table, $record ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Creates one generic private-file record.
		return false === $inserted ? new WP_Error( 'tutorhelper_lms_private_file_insert_failed', __( 'The private file record could not be created.', 'tutorhelper-lms' ) ) : absint( $wpdb->insert_id );
	}

	/**
	 * Find a generic record by its logical entity and version.
	 *
	 * This is intentionally metadata-only. A future access controller will
	 * authorise resource delivery separately from file lookup.
	 *
	 * @param string $entity_type Logical entity type.
	 * @param int    $entity_id   Logical entity ID.
	 * @param int    $version     Version number.
	 * @return object|null
	 */
	public static function find( $entity_type, $entity_id, $version = 1 ) {
		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'private_files' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE entity_type = %s AND entity_id = %d AND version_number = %d", sanitize_key( $entity_type ), absint( $entity_id ), max( 1, absint( $version ) ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads one private-file metadata record.
	}
}
