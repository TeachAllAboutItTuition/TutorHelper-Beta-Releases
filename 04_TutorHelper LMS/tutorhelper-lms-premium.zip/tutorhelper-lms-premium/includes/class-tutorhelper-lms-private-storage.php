<?php
/**
 * Private-file storage checks for TutorHelper LMS.
 *
 * Uploaded coursework is intentionally not stored in the public Media Library.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Private_Storage {

	const OPTION_STATUS = 'tutorhelper_lms_private_storage_status';
	const OPTION_MODE   = 'tutorhelper_lms_submission_mode';
	const OPTION_PATH   = 'tutorhelper_lms_private_storage_path';
	const STATUS_TRANSIENT = 'tutorhelper_lms_private_storage_checked';
	const MODE_LINKS_ONLY  = 'links_only';
	const MODE_LOCAL       = 'private_local';
	const MODE_GOOGLE      = 'google_drive';

	/**
	 * Return the effective submission mode.
	 *
	 * A path declared in wp-config.php deliberately takes precedence and enables
	 * private local storage without requiring an administrator to enter it again.
	 *
	 * @return string
	 */
	public static function mode() {
		if ( defined( 'TUTORHELPER_LMS_PRIVATE_STORAGE_PATH' ) && '' !== trim( (string) TUTORHELPER_LMS_PRIVATE_STORAGE_PATH ) ) {
			return self::MODE_LOCAL;
		}

		$mode = (string) get_option( self::OPTION_MODE, self::MODE_LINKS_ONLY );

		return in_array( $mode, array( self::MODE_LOCAL, self::MODE_GOOGLE ), true ) ? $mode : self::MODE_LINKS_ONLY;
	}

	/**
	 * Return the configured private storage directory. It must be explicitly
	 * provided by a developer constant or a tutor administrator; LMS never
	 * assumes it may create a directory above the website's public root.
	 *
	 * @return string
	 */
	public static function directory() {
		$directory = defined( 'TUTORHELPER_LMS_PRIVATE_STORAGE_PATH' )
			? TUTORHELPER_LMS_PRIVATE_STORAGE_PATH
			: get_option( self::OPTION_PATH, '' );

		return untrailingslashit( wp_normalize_path( (string) $directory ) );
	}

	/**
	 * Verify an existing private directory can be used safely.
	 *
	 * No public uploads-directory fallback is permitted. The host or site owner
	 * must create this directory outside the public WordPress root.
	 *
	 * @return true|WP_Error
	 */
	public static function verify() {
		if ( self::MODE_LOCAL !== self::mode() ) {
			return new WP_Error(
				'tutorhelper_lms_private_storage_not_enabled',
				__( 'File uploads are not enabled. Students can still submit shared-file links.', 'tutorhelper-lms' )
			);
		}

		$directory = self::directory();

		if ( '' === $directory || ! is_dir( $directory ) ) {
			return new WP_Error(
				'tutorhelper_lms_private_storage_missing',
				__( 'The private LMS storage folder does not exist. Create a private folder through your hosting account, then save its path in LMS settings.', 'tutorhelper-lms' )
			);
		}

		$real_directory = realpath( $directory );
		$web_root       = realpath( ABSPATH );

		if ( false === $real_directory || false === $web_root ) {
			return new WP_Error(
				'tutorhelper_lms_private_storage_unresolved',
				__( 'TutorHelper LMS could not verify the private storage folder. File uploads have been disabled.', 'tutorhelper-lms' )
			);
		}

		$real_directory = untrailingslashit( wp_normalize_path( $real_directory ) );
		$web_root       = untrailingslashit( wp_normalize_path( $web_root ) );

		if ( $real_directory === $web_root || 0 === strpos( $real_directory, $web_root . '/' ) ) {
			return new WP_Error(
				'tutorhelper_lms_private_storage_not_private',
				__( 'Private LMS storage must be outside the public WordPress directory. File uploads have been disabled.', 'tutorhelper-lms' )
			);
		}

		if ( ! is_writable( $real_directory ) ) {
			return new WP_Error(
				'tutorhelper_lms_private_storage_not_writable',
				__( 'TutorHelper LMS private storage is not writable. File uploads have been disabled.', 'tutorhelper-lms' )
			);
		}

		return true;
	}

	/**
	 * Refresh storage status when requested.
	 *
	 * @return void
	 */
	public static function refresh_status() {
		if ( self::MODE_GOOGLE === self::mode() ) {
			$connected = class_exists( 'TutorHelper_LMS_Google_Drive_Auth' ) && TutorHelper_LMS_Google_Drive_Auth::is_connected();
			update_option( self::OPTION_STATUS, array( 'state' => self::MODE_GOOGLE, 'ready' => $connected, 'message' => $connected ? __( 'Google Drive is connected and ready for private student uploads.', 'tutorhelper-lms' ) : __( 'Google Drive storage is selected but not connected. Students can still submit HTTPS links.', 'tutorhelper-lms' ) ), false );
			set_transient( self::STATUS_TRANSIENT, '1', 12 * HOUR_IN_SECONDS );
			return;
		}

		if ( self::MODE_LOCAL !== self::mode() ) {
			update_option(
				self::OPTION_STATUS,
				array(
					'state'   => self::MODE_LINKS_ONLY,
					'ready'   => false,
					'message' => __( 'Students can submit shared-file links. Private file uploads are not enabled.', 'tutorhelper-lms' ),
				),
				false
			);
			set_transient( self::STATUS_TRANSIENT, '1', 12 * HOUR_IN_SECONDS );
			return;
		}

		$result = self::verify();
		$status = is_wp_error( $result )
			? array(
				'state'   => self::MODE_LOCAL,
				'ready'   => false,
				'message' => $result->get_error_message(),
			)
			: array(
				'state'   => self::MODE_LOCAL,
				'ready'   => true,
				'message' => __( 'Private coursework storage is ready.', 'tutorhelper-lms' ),
			);

		update_option( self::OPTION_STATUS, $status, false );
		set_transient( self::STATUS_TRANSIENT, '1', 12 * HOUR_IN_SECONDS );
	}

	/**
	 * Refresh only when no recent check exists. This avoids a filesystem write
	 * and option update on ordinary page requests.
	 *
	 * @return void
	 */
	public static function maybe_refresh_status() {
		if ( false === get_transient( self::STATUS_TRANSIENT ) || false === get_option( self::OPTION_STATUS, false ) ) {
			self::refresh_status();
		}
	}

	/**
	 * Return whether private uploads are permitted.
	 *
	 * @return bool
	 */
	public static function is_ready() {
		$status = get_option( self::OPTION_STATUS, array() );

		return in_array( self::mode(), array( self::MODE_LOCAL, self::MODE_GOOGLE ), true ) && ! empty( $status['ready'] );
	}

	/**
	 * Return the maximum accepted file size in bytes, bounded by WordPress and
	 * server constraints.
	 *
	 * @return int
	 */
	public static function effective_upload_limit() {
		$configured_megabytes = absint( get_option( 'tutorhelper_lms_upload_limit_mb', 5 ) );
		$configured_bytes     = max( 1, $configured_megabytes ) * MB_IN_BYTES;

		return min( $configured_bytes, wp_max_upload_size() );
	}
}
