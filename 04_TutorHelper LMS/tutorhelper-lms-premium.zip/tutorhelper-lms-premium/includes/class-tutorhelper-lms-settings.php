<?php
/**
 * LMS settings integrated into the existing TutorHelper settings area.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Settings {

	const TAB    = 'lms';
	const ACTION = 'tutorhelper_lms_save_settings';

	/**
	 * Register settings hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'tutorhelper_settings_tabs', array( __CLASS__, 'add_tab' ) );
		add_action( 'tutorhelper_settings_render_tab', array( __CLASS__, 'render_tab' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'save' ) );
	}

	/**
	 * Add the LMS settings tab.
	 *
	 * @param array $tabs Existing settings tabs.
	 * @return array
	 */
	public static function add_tab( $tabs ) {
		$tabs[ self::TAB ] = array(
			'label' => __( 'LMS', 'tutorhelper-lms' ),
			'icon'  => 'dashicons-welcome-learn-more',
		);

		return $tabs;
	}

	/**
	 * Render storage and submission settings.
	 *
	 * @param string $selected_tab Current settings tab.
	 * @return void
	 */
	public static function render_tab( $selected_tab ) {
		if ( self::TAB !== $selected_tab || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}

		$status       = get_option( TutorHelper_LMS_Private_Storage::OPTION_STATUS, array() );
		$mode         = TutorHelper_LMS_Private_Storage::mode();
		$path         = defined( 'TUTORHELPER_LMS_PRIVATE_STORAGE_PATH' ) ? '' : (string) get_option( TutorHelper_LMS_Private_Storage::OPTION_PATH, '' );
		$limit_mb     = absint( get_option( 'tutorhelper_lms_upload_limit_mb', 5 ) );
		$server_mb    = round( wp_max_upload_size() / MB_IN_BYTES, 2 );
		$uses_constant    = defined( 'TUTORHELPER_LMS_PRIVATE_STORAGE_PATH' );
		$google_connected = class_exists( 'TutorHelper_LMS_Google_Drive_Auth' ) && TutorHelper_LMS_Google_Drive_Auth::is_connected();
		?>
		<section class="tutorhelper-main-section">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'TutorHelper LMS', 'tutorhelper-lms' ); ?></h2>
					<p><?php esc_html_e( 'Choose how files are stored. Shared-file links work without additional storage setup.', 'tutorhelper-lms' ); ?></p>
				</div>
			</header>
			<div class="tutorhelper-main-section__body">
				<?php if ( TutorHelper_LMS_Private_Storage::MODE_LINKS_ONLY === $mode ) : ?>
					<p class="notice notice-info inline"><span><?php echo esc_html( ! empty( $status['message'] ) ? $status['message'] : __( 'Students can submit shared-file links. Private file uploads are not enabled.', 'tutorhelper-lms' ) ); ?></span></p>
				<?php elseif ( ! empty( $status['ready'] ) ) : ?>
					<p class="notice notice-success inline"><span><?php echo esc_html( $status['message'] ); ?></span></p>
				<?php else : ?>
					<p class="notice notice-error inline"><span><?php echo esc_html( ! empty( $status['message'] ) ? $status['message'] : __( 'Private coursework storage has not been checked yet.', 'tutorhelper-lms' ) ); ?></span></p>
				<?php endif; ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
					<?php wp_nonce_field( self::ACTION ); ?>

					<fieldset class="tutorhelper-input-fields">
						<legend><strong><?php esc_html_e( 'Assignment submission method', 'tutorhelper-lms' ); ?></strong></legend>
						<label>
							<input type="radio" name="submission_mode" value="<?php echo esc_attr( TutorHelper_LMS_Private_Storage::MODE_LINKS_ONLY ); ?>" <?php checked( TutorHelper_LMS_Private_Storage::MODE_LINKS_ONLY, $mode ); ?> <?php disabled( $uses_constant ); ?> />
							<strong><?php esc_html_e( 'Shared-file links only', 'tutorhelper-lms' ); ?></strong>
							<span class="description"><?php esc_html_e( 'Students submit a Google Drive, OneDrive or similar sharing link. No coursework file is stored by this website.', 'tutorhelper-lms' ); ?></span>
						</label><br />
						<label>
							<input type="radio" name="submission_mode" value="<?php echo esc_attr( TutorHelper_LMS_Private_Storage::MODE_GOOGLE ); ?>" <?php checked( TutorHelper_LMS_Private_Storage::MODE_GOOGLE, $mode ); ?> <?php disabled( ! $google_connected || $uses_constant ); ?> />
							<strong><?php esc_html_e( 'Private Google Drive storage', 'tutorhelper-lms' ); ?></strong>
							<span class="description"><?php echo esc_html( $google_connected ? __( 'Student files are uploaded to the connected tutor Google Drive account, not the website Media Library.', 'tutorhelper-lms' ) : __( 'Connect Google Drive below before this storage option can be used.', 'tutorhelper-lms' ) ); ?></span>
						</label><br />
						<label>
							<input type="radio" name="submission_mode" value="<?php echo esc_attr( TutorHelper_LMS_Private_Storage::MODE_LOCAL ); ?>" <?php checked( TutorHelper_LMS_Private_Storage::MODE_LOCAL, $mode ); ?> <?php disabled( $uses_constant ); ?> />
							<strong><?php esc_html_e( 'Private local file storage', 'tutorhelper-lms' ); ?></strong>
							<span class="description"><?php esc_html_e( 'Enable file uploads only after your host has created a writable folder outside the public website directory.', 'tutorhelper-lms' ); ?></span>
						</label>
					</fieldset>

					<p class="tutorhelper-input-field is-full-width">
						<label for="tutorhelper-lms-private-path"><strong><?php esc_html_e( 'Private storage folder path', 'tutorhelper-lms' ); ?></strong></label><br />
						<input id="tutorhelper-lms-private-path" name="private_storage_path" type="text" class="regular-text code tutorhelper-input-field__control" value="<?php echo esc_attr( $path ); ?>" <?php disabled( $uses_constant ); ?> />
						<span class="description"><?php esc_html_e( 'Ask your host to create this folder outside public_html (or your site’s web root). TutorHelper LMS will not create or use a public uploads folder.', 'tutorhelper-lms' ); ?></span>
						<?php if ( $uses_constant ) : ?>
							<span class="description"><?php esc_html_e( 'A developer-configured storage path is currently in use, so this field is locked.', 'tutorhelper-lms' ); ?></span>
						<?php endif; ?>
					</p>

					<p class="tutorhelper-input-field is-full-width">
						<label for="tutorhelper-lms-upload-limit"><strong><?php esc_html_e( 'Maximum file size (MB)', 'tutorhelper-lms' ); ?></strong></label><br />
						<input id="tutorhelper-lms-upload-limit" name="upload_limit_mb" type="number" class="tutorhelper-input-field__control" min="1" max="100" value="<?php echo esc_attr( $limit_mb ); ?>" />
						<span class="description">
							<?php
							printf(
								/* translators: %s: Maximum upload size permitted by WordPress and the server, in megabytes. */
								esc_html__( 'The effective limit cannot exceed the server limit of %s MB.', 'tutorhelper-lms' ),
								esc_html( (string) $server_mb )
							);
							?>
						</span>
					</p>
					<p><?php esc_html_e( 'Supported assignment uploads in the first release are PDF, DOCX, JPG and PNG. Students may submit one file or one shared-file link for each assignment.', 'tutorhelper-lms' ); ?></p>
					<p><button type="submit" class="button button-primary tutorhelper-action-button"><?php esc_html_e( 'Save LMS settings', 'tutorhelper-lms' ); ?></button></p>
				</form>
			</div>
		</section>
		<?php
	}

	/**
	 * Save LMS settings.
	 *
	 * @return void
	 */
	public static function save() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to change LMS settings.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( self::ACTION );

		$limit = isset( $_POST['upload_limit_mb'] ) && ! is_array( $_POST['upload_limit_mb'] )
			? absint( wp_unslash( $_POST['upload_limit_mb'] ) )
			: 5;

		if ( ! defined( 'TUTORHELPER_LMS_PRIVATE_STORAGE_PATH' ) ) {
			$mode = isset( $_POST['submission_mode'] ) && ! is_array( $_POST['submission_mode'] )
				? sanitize_key( wp_unslash( $_POST['submission_mode'] ) )
				: TutorHelper_LMS_Private_Storage::MODE_LINKS_ONLY;

			$path = isset( $_POST['private_storage_path'] ) && ! is_array( $_POST['private_storage_path'] )
				? sanitize_text_field( wp_unslash( $_POST['private_storage_path'] ) )
				: '';

			update_option(
				TutorHelper_LMS_Private_Storage::OPTION_MODE,
				in_array( $mode, array( TutorHelper_LMS_Private_Storage::MODE_LOCAL, TutorHelper_LMS_Private_Storage::MODE_GOOGLE ), true ) ? $mode : TutorHelper_LMS_Private_Storage::MODE_LINKS_ONLY,
				false
			);
			update_option( TutorHelper_LMS_Private_Storage::OPTION_PATH, $path, false );
		}

		update_option( 'tutorhelper_lms_upload_limit_mb', min( 100, max( 1, $limit ) ), false );
		TutorHelper_LMS_Private_Storage::refresh_status();

		$url = add_query_arg(
			array(
				'page'                     => TutorHelper_Admin::MENU_SLUG,
				'tab'                      => self::TAB,
				'tutorhelper_lms_settings' => 'saved',
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
