<?php
/**
 * Registry for LMS submission-storage providers.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Storage_Registry {

	/**
	 * Return registered provider implementations keyed by stable provider ID.
	 *
	 * Protected WordPress storage, Google Drive and OneDrive can register
	 * implementations through this filter without changing submission, marking
	 * or gradebook records.
	 *
	 * @return TutorHelper_LMS_Storage_Provider_Interface[]
	 */
	public static function providers() {
		$providers = apply_filters( 'tutorhelper_lms_storage_providers', array() );

		if ( ! is_array( $providers ) ) {
			return array();
		}

		$valid = array();

		foreach ( $providers as $provider ) {
			if ( $provider instanceof TutorHelper_LMS_Storage_Provider_Interface ) {
				$valid[ sanitize_key( $provider->get_id() ) ] = $provider;
			}
		}

		return $valid;
	}

	/**
	 * Return a provider by ID when registered.
	 *
	 * @param string $provider_id Provider identifier.
	 * @return TutorHelper_LMS_Storage_Provider_Interface|null
	 */
	public static function get( $provider_id ) {
		$providers   = self::providers();
		$provider_id = sanitize_key( $provider_id );

		return isset( $providers[ $provider_id ] ) ? $providers[ $provider_id ] : null;
	}
}
