<?php
/**
 * Protected WordPress filesystem storage for TutorHelper LMS submissions.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Local_Storage_Provider implements TutorHelper_LMS_Storage_Provider_Interface {

	/** Register this provider. */
	public static function init() {
		add_filter(
			'tutorhelper_lms_storage_providers',
			static function( $providers ) {
				$providers[] = new self();
				return $providers;
			}
		);
	}

	public function get_id() {
		return 'protected_wordpress';
	}

	public function get_label() {
		return __( 'Protected WordPress storage', 'tutorhelper-lms' );
	}

	public function is_available() {
		return TutorHelper_LMS_Private_Storage::is_ready();
	}

	public function store( $upload, $context ) {
		$verified = TutorHelper_LMS_Private_Storage::verify();
		if ( is_wp_error( $verified ) ) {
			return $verified;
		}

		$extension = strtolower( pathinfo( (string) $upload['name'], PATHINFO_EXTENSION ) );
		$filename = wp_generate_password( 32, false, false ) . ( $extension ? '.' . $extension : '' );
		$target = trailingslashit( TutorHelper_LMS_Private_Storage::directory() ) . $filename;

		if ( ! @move_uploaded_file( $upload['tmp_name'], $target ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Do not expose the server path in a student-facing error.
			return new WP_Error( 'tutorhelper_lms_private_store_failed', __( 'The private file could not be stored.', 'tutorhelper-lms' ) );
		}

		return array( 'provider_file_id' => $filename, 'storage_key' => $filename );
	}

	public function stream( $provider_file_id, $context ) {
		$filename = basename( (string) $provider_file_id );
		$path = trailingslashit( TutorHelper_LMS_Private_Storage::directory() ) . $filename;

		if ( '' === $filename || ! is_readable( $path ) ) {
			return new WP_Error( 'tutorhelper_lms_file_missing', __( 'This submission file is no longer available.', 'tutorhelper-lms' ) );
		}

		nocache_headers();
		header( 'Content-Type: ' . ( ! empty( $context['mime_type'] ) ? $context['mime_type'] : 'application/octet-stream' ) );
		header( 'Content-Length: ' . (string) filesize( $path ) );
		$disposition = ! empty( $context['disposition'] ) && 'inline' === $context['disposition'] ? 'inline' : 'attachment';
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: ' . $disposition . '; filename="' . sanitize_file_name( (string) $context['filename'] ) . '"' );
		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Streams one authenticated, private submission.
		return true;
	}
}
