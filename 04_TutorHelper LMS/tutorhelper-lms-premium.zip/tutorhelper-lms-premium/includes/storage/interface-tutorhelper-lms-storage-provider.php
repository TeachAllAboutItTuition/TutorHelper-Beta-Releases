<?php
/**
 * Contract for private TutorHelper LMS storage providers and private files.
 *
 * Providers must not return public sharing URLs. The LMS application controls
 * authorisation before a submitted file is opened or downloaded.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface TutorHelper_LMS_Storage_Provider_Interface {

	/**
	 * Return a stable machine-readable provider identifier.
	 *
	 * @return string
	 */
	public function get_id();

	/**
	 * Return a translated provider label for tutor-facing settings.
	 *
	 * @return string
	 */
	public function get_label();

	/**
	 * Whether this provider is configured and ready for new submissions.
	 *
	 * @return bool
	 */
	public function is_available();

	/**
	 * Store one validated temporary upload for a private LMS file.
	 *
	 * The returned array must contain the provider-specific file identifier and
	 * must not contain a public URL.
	 *
	 * @param array $upload  Validated upload data.
	 * @param array $context File purpose, ownership and storage-routing context.
	 * @return array|WP_Error
	 */
	public function store( $upload, $context );

	/**
	 * Stream an authorised file to the current request. The caller performs all
	 * access checks before this method is called.
	 *
	 * @param string $provider_file_id Provider-specific file identifier.
	 * @param array  $context          Authorised delivery context.
	 * @return true|WP_Error
	 */
	public function stream( $provider_file_id, $context );
}
