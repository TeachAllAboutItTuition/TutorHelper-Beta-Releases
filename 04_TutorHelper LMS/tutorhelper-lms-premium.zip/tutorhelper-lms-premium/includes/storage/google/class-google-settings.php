<?php
/**
 * Google Drive connection controls for TutorHelper LMS.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Google_Drive_Settings {

	const ACTION = 'tutorhelper_lms_save_google_drive_settings';

	/**
	 * Register Google Drive settings hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'tutorhelper_settings_render_tab', array( __CLASS__, 'render' ), 20 );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'save' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Load the small reusable LMS modal assets only on TutorHelper Settings.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'tutorhelper_page_tutorhelper-settings' !== $hook_suffix ) {
			return;
		}

		$style_path  = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/css/tutorhelper-lms-shared.css';
		$script_path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-modal.js';

		wp_enqueue_style(
			'tutorhelper-lms-shared',
			TUTORHELPER_LMS_PREMIUM_URL . 'assets/css/tutorhelper-lms-shared.css',
			array(),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_LMS_PREMIUM_VERSION
		);
		wp_enqueue_script(
			'tutorhelper-lms-modal',
			TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-modal.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_LMS_PREMIUM_VERSION,
			true
		);
	}

	/**
	 * Render the Google Drive connection section.
	 *
	 * @param string $selected_tab Current settings tab.
	 * @return void
	 */
	public static function render( $selected_tab ) {
		if ( TutorHelper_LMS_Settings::TAB !== $selected_tab || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}

		$client_id    = TutorHelper_LMS_Google_Drive_Auth::client_id();
		$redirect_uri = TutorHelper_LMS_Google_Drive_Auth::redirect_uri();
		$notice       = isset( $_GET['tutorhelper_lms_google'] ) && ! is_array( $_GET['tutorhelper_lms_google'] )
			? sanitize_key( wp_unslash( $_GET['tutorhelper_lms_google'] ) )
			: '';
		?>
		<section class="tutorhelper-main-section">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'Google Drive', 'tutorhelper-lms' ); ?></h2>
					<p><?php esc_html_e( 'Connect the tutor’s Google account to store future submitted files privately in Google Drive. Students do not need Google accounts.', 'tutorhelper-lms' ); ?></p>
				</div>
				<p><button type="button" class="button button-secondary" data-tutorhelper-lms-modal-open="tutorhelper-lms-google-setup"><?php esc_html_e( 'Set up Google Drive', 'tutorhelper-lms' ); ?></button></p>
			</header>
			<div class="tutorhelper-main-section__body">
				<?php self::render_notice( $notice ); ?>
				<?php if ( TutorHelper_LMS_Google_Drive_Auth::is_connected() ) : ?>
					<p class="notice notice-success inline"><span><?php esc_html_e( 'Connection status: Google Drive is connected. Select Private Google Drive storage in the LMS tab to store new uploaded files there.', 'tutorhelper-lms' ); ?></span></p>
				<?php else : ?>
					<p class="notice notice-warning inline"><span><?php esc_html_e( 'Connection status: Google Drive is not connected. Saving OAuth credentials alone does not connect the account.', 'tutorhelper-lms' ); ?></span></p>
				<?php endif; ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
					<?php wp_nonce_field( self::ACTION ); ?>
					<p>
						<label for="tutorhelper-lms-google-client-id"><strong><?php esc_html_e( 'OAuth client ID', 'tutorhelper-lms' ); ?></strong></label><br />
						<input id="tutorhelper-lms-google-client-id" class="regular-text code tutorhelper-input-field__control" name="client_id" type="text" value="<?php echo esc_attr( $client_id ); ?>" autocomplete="off" />
					</p>
					<p>
						<label for="tutorhelper-lms-google-client-secret"><strong><?php esc_html_e( 'OAuth client secret', 'tutorhelper-lms' ); ?></strong></label><br />
						<input id="tutorhelper-lms-google-client-secret" class="regular-text code tutorhelper-input-field__control" name="client_secret" type="password" value="" autocomplete="new-password" />
						<span class="description"><?php esc_html_e( 'Leave this blank to keep the saved secret unchanged.', 'tutorhelper-lms' ); ?></span>
					</p>
					<p><button type="submit" class="button button-secondary tutorhelper-action-button"><?php esc_html_e( 'Save Google settings', 'tutorhelper-lms' ); ?></button></p>
				</form>

				<p><strong><?php esc_html_e( 'Google Cloud redirect URI', 'tutorhelper-lms' ); ?></strong><br />
					<code><?php echo esc_html( $redirect_uri ); ?></code><br />
					<span class="description"><?php esc_html_e( 'Add this exact URI to the authorised redirect URIs for your Google Cloud OAuth web application.', 'tutorhelper-lms' ); ?></span>
				</p>

				<?php if ( TutorHelper_LMS_Google_Drive_Auth::is_connected() ) : ?>
					<p class="notice notice-success inline"><span><?php esc_html_e( 'Google Drive is connected for future LMS submissions.', 'tutorhelper-lms' ); ?></span></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="tutorhelper_lms_google_drive_disconnect" />
						<?php wp_nonce_field( 'tutorhelper_lms_google_drive_disconnect' ); ?>
						<p><button type="submit" class="button button-secondary tutorhelper-action-button"><?php esc_html_e( 'Disconnect Google Drive', 'tutorhelper-lms' ); ?></button></p>
					</form>
				<?php elseif ( TutorHelper_LMS_Google_Drive_Auth::credentials_ready() && TutorHelper_LMS_Secrets::is_available() ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="tutorhelper_lms_google_drive_connect" />
						<?php wp_nonce_field( 'tutorhelper_lms_google_drive_connect' ); ?>
						<p><button type="submit" class="button button-primary tutorhelper-action-button"><?php esc_html_e( 'Connect Google Drive', 'tutorhelper-lms' ); ?></button></p>
					</form>
				<?php else : ?>
					<p class="notice notice-warning inline"><span><?php esc_html_e( 'Save valid Google OAuth client credentials before connecting Google Drive. Secure token encryption must also be available on this server.', 'tutorhelper-lms' ); ?></span></p>
				<?php endif; ?>
			</div>
		</section>

		<dialog id="tutorhelper-lms-google-setup" class="tutorhelper-lms-modal" aria-labelledby="tutorhelper-lms-google-setup-title">
			<div class="tutorhelper-lms-modal__header">
				<h2 id="tutorhelper-lms-google-setup-title"><?php esc_html_e( 'Set up Google Drive for TutorHelper LMS', 'tutorhelper-lms' ); ?></h2>
				<button type="button" class="button-link tutorhelper-lms-modal__close" data-tutorhelper-lms-modal-close aria-label="<?php esc_attr_e( 'Close setup instructions', 'tutorhelper-lms' ); ?>">×</button>
			</div>
			<div class="tutorhelper-lms-modal__body">
				<p><?php esc_html_e( 'You only need to complete this once for this website. Students will upload through TutorHelper and do not need Google accounts.', 'tutorhelper-lms' ); ?></p>
				<ol>
					<li><a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open Google Cloud Console', 'tutorhelper-lms' ); ?></a><?php esc_html_e( ' and create or select a project.', 'tutorhelper-lms' ); ?></li>
					<li><?php esc_html_e( 'Open APIs & Services → Library, find Google Drive API and enable it.', 'tutorhelper-lms' ); ?></li>
					<li><?php esc_html_e( 'Open APIs & Services → OAuth consent screen and complete the required app details. During testing, add the Google account you will use as a test user.', 'tutorhelper-lms' ); ?></li>
					<li><?php esc_html_e( 'Open APIs & Services → Credentials → Create credentials → OAuth client ID. Choose Web application.', 'tutorhelper-lms' ); ?></li>
					<li><?php esc_html_e( 'Under Authorised redirect URIs, add this exact address:', 'tutorhelper-lms' ); ?><br /><code><?php echo esc_html( $redirect_uri ); ?></code></li>
					<li><?php esc_html_e( 'Copy the client ID and client secret into the fields above, save them, then select Connect Google Drive.', 'tutorhelper-lms' ); ?></li>
				</ol>
				<p class="description"><?php esc_html_e( 'TutorHelper LMS requests permission only to manage files it creates or opens through this connection. Keep your client secret private and never add it to a Git repository.', 'tutorhelper-lms' ); ?></p>
			</div>
			<div class="tutorhelper-lms-modal__footer">
				<button type="button" class="button button-primary" data-tutorhelper-lms-modal-close><?php esc_html_e( 'Done', 'tutorhelper-lms' ); ?></button>
			</div>
		</dialog>
		<?php
	}

	/**
	 * Save encrypted Google OAuth client credentials.
	 *
	 * @return void
	 */
	public static function save() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Google Drive settings.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( self::ACTION );

		$client_id = isset( $_POST['client_id'] ) && ! is_array( $_POST['client_id'] )
			? sanitize_text_field( wp_unslash( $_POST['client_id'] ) )
			: '';
		$secret = isset( $_POST['client_secret'] ) && ! is_array( $_POST['client_secret'] )
			? trim( wp_unslash( $_POST['client_secret'] ) )
			: '';

		update_option( TutorHelper_LMS_Google_Drive_Auth::CLIENT_ID_OPTION, $client_id, false );

		if ( '' !== $secret ) {
			$encrypted = TutorHelper_LMS_Secrets::encrypt( $secret );

			if ( is_wp_error( $encrypted ) ) {
				self::redirect( 'encryption_unavailable' );
			}

			update_option( TutorHelper_LMS_Google_Drive_Auth::CLIENT_SECRET_OPTION, $encrypted, false );
		}

		self::redirect( 'settings_saved' );
	}

	/**
	 * Render concise connection notices.
	 *
	 * @param string $notice Notice identifier.
	 * @return void
	 */
	private static function render_notice( $notice ) {
		$messages = array(
			'settings_saved'         => array( 'success', __( 'Google Drive settings saved.', 'tutorhelper-lms' ) ),
			'connected'              => array( 'success', __( 'Google Drive has been connected.', 'tutorhelper-lms' ) ),
			'disconnected'           => array( 'success', __( 'Google Drive has been disconnected. Existing submission records have not been changed.', 'tutorhelper-lms' ) ),
			'credentials_missing'    => array( 'error', __( 'Save the Google OAuth client ID and client secret before connecting.', 'tutorhelper-lms' ) ),
			'encryption_unavailable' => array( 'error', __( 'This server cannot securely encrypt Google Drive connection details.', 'tutorhelper-lms' ) ),
			'state_invalid'          => array( 'error', __( 'The Google connection request expired or could not be verified. Please try again.', 'tutorhelper-lms' ) ),
			'google_denied'          => array( 'error', __( 'Google Drive permission was not granted.', 'tutorhelper-lms' ) ),
			'code_missing'           => array( 'error', __( 'Google did not return an authorisation code.', 'tutorhelper-lms' ) ),
			'token_exchange_failed'  => array( 'error', __( 'TutorHelper LMS could not complete the Google Drive connection.', 'tutorhelper-lms' ) ),
			'refresh_token_missing'  => array( 'error', __( 'Google did not provide an offline refresh token. Disconnect this app in Google and try again.', 'tutorhelper-lms' ) ),
			'token_encrypt_failed'   => array( 'error', __( 'TutorHelper LMS could not securely save the Google Drive connection.', 'tutorhelper-lms' ) ),
			'state_failed'           => array( 'error', __( 'TutorHelper LMS could not create a secure Google connection request.', 'tutorhelper-lms' ) ),
		);

		if ( ! isset( $messages[ $notice ] ) ) {
			return;
		}

		$message = $messages[ $notice ];
		?>
		<p class="notice notice-<?php echo esc_attr( $message[0] ); ?> inline"><span><?php echo esc_html( $message[1] ); ?></span></p>
		<?php
	}

	/**
	 * Return to LMS settings with a notice.
	 *
	 * @param string $notice Notice identifier.
	 * @return void
	 */
	private static function redirect( $notice ) {
		$url = add_query_arg(
			array(
				'page'                    => TutorHelper_Admin::MENU_SLUG,
				'tab'                     => TutorHelper_LMS_Settings::TAB,
				'tutorhelper_lms_google' => sanitize_key( $notice ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
