<?php
/**
 * Private Google Drive storage provider for TutorHelper LMS.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Google_Drive_Provider implements TutorHelper_LMS_Storage_Provider_Interface {

	/** Register this provider. */
	public static function init() {
		add_filter(
			'tutorhelper_lms_storage_providers',
			static function( $providers ) {
				$providers[] = new self();
				return $providers;
			}
		);
	}

	public function get_id() {
		return 'google_drive';
	}

	public function get_label() {
		return __( 'Google Drive', 'tutorhelper-lms' );
	}

	public function is_available() {
		return TutorHelper_LMS_Google_Drive_Auth::is_connected();
	}

	public function store( $upload, $context ) {
		$token = TutorHelper_LMS_Google_Drive_Auth::access_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$folder_id = ! empty( $context['purpose'] ) && 'resource' === $context['purpose']
			? self::resource_library_folder_id( $token )
			: self::student_folder_id( ! empty( $context['student_user_id'] ) ? absint( $context['student_user_id'] ) : 0, $token );
		if ( is_wp_error( $folder_id ) ) {
			return $folder_id;
		}

		$resource_upload = ! empty( $context['purpose'] ) && 'resource' === $context['purpose'];
		$metadata = wp_json_encode(
			array(
				'name' => sanitize_file_name( (string) $upload['name'] ),
				'description' => $resource_upload ? 'Private TutorHelper LMS master learning resource.' : 'Private TutorHelper LMS coursework submission.',
				'parents' => array( $folder_id ),
			)
		);
		if ( $resource_upload ) {
			return self::store_resumable_resource( $upload, $metadata, $token );
		}

		$boundary = 'tutorhelperlms' . wp_generate_password( 24, false, false );
		$contents = @file_get_contents( $upload['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reads only the validated temporary upload for the provider request.
		if ( false === $contents ) {
			return new WP_Error( 'tutorhelper_lms_upload_unreadable', __( 'The uploaded file could not be read securely.', 'tutorhelper-lms' ) );
		}

		$body = "--{$boundary}\r\n"
			. "Content-Type: application/json; charset=UTF-8\r\n\r\n"
			. $metadata . "\r\n"
			. "--{$boundary}\r\n"
			. 'Content-Type: ' . (string) $upload['type'] . "\r\n\r\n"
			. $contents . "\r\n"
			. "--{$boundary}--";

		$response = wp_remote_post(
			'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size',
			array(
				'timeout' => 60,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type' => 'multipart/related; boundary=' . $boundary,
				),
				'body' => $body,
			)
		);

		if ( is_wp_error( $response ) || ! in_array( wp_remote_retrieve_response_code( $response ), array( 200, 201 ), true ) ) {
			return new WP_Error( 'tutorhelper_lms_google_store_failed', __( 'Google Drive could not securely store this file. Please try again.', 'tutorhelper-lms' ) );
		}

		$result = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $result ) || empty( $result['id'] ) ) {
			return new WP_Error( 'tutorhelper_lms_google_store_invalid', __( 'Google Drive did not return a file reference.', 'tutorhelper-lms' ) );
		}

		return array( 'provider_file_id' => sanitize_text_field( $result['id'] ), 'storage_key' => sanitize_text_field( $result['id'] ) );
	}

	/**
	 * Upload a Resource in bounded chunks rather than reading the full file into PHP memory.
	 *
	 * @param array  $upload Validated temporary upload.
	 * @param string $metadata JSON Drive metadata.
	 * @param string $token Valid Google access token.
	 * @return array|WP_Error
	 */
	private static function store_resumable_resource( $upload, $metadata, $token ) {
		$size = absint( $upload['size'] );
		$start = wp_remote_post(
			'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name,mimeType,size',
			array(
				'timeout' => 60,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type' => 'application/json; charset=UTF-8',
					'X-Upload-Content-Type' => (string) $upload['type'],
					'X-Upload-Content-Length' => (string) $size,
				),
				'body' => $metadata,
			)
		);
		$session = is_wp_error( $start ) ? '' : (string) wp_remote_retrieve_header( $start, 'location' );
		if ( is_wp_error( $start ) || ! in_array( wp_remote_retrieve_response_code( $start ), array( 200, 201 ), true ) || '' === $session ) {
			return new WP_Error( 'tutorhelper_lms_google_resumable_start_failed', __( 'Google Drive could not prepare this Resource upload. Please try again.', 'tutorhelper-lms' ) );
		}

		$handle = @fopen( $upload['tmp_name'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Reads the validated temporary upload in bounded chunks.
		if ( ! $handle ) {
			return new WP_Error( 'tutorhelper_lms_upload_unreadable', __( 'The uploaded file could not be read securely.', 'tutorhelper-lms' ) );
		}

		$offset = 0;
		$chunk_size = 8 * MB_IN_BYTES;
		$result = null;
		while ( $offset < $size ) {
			$length = min( $chunk_size, $size - $offset );
			$chunk = fread( $handle, $length ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- Reads a bounded authenticated upload chunk.
			if ( false === $chunk || strlen( $chunk ) !== $length ) {
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes a temporary upload handle.
				return new WP_Error( 'tutorhelper_lms_upload_unreadable', __( 'The uploaded file could not be read securely.', 'tutorhelper-lms' ) );
			}
			$response = wp_remote_request(
				$session,
				array(
					'method'  => 'PUT',
					'timeout' => 90,
					'headers' => array(
						'Authorization' => 'Bearer ' . $token,
						'Content-Type' => (string) $upload['type'],
						'Content-Length' => (string) $length,
						'Content-Range' => sprintf( 'bytes %d-%d/%d', $offset, $offset + $length - 1, $size ),
					),
					'body' => $chunk,
				)
			);
			$offset += $length;
			if ( is_wp_error( $response ) ) {
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes a temporary upload handle.
				return new WP_Error( 'tutorhelper_lms_google_resumable_upload_failed', __( 'Google Drive could not securely store this Resource file. Please try again.', 'tutorhelper-lms' ) );
			}
			$status = wp_remote_retrieve_response_code( $response );
			if ( in_array( $status, array( 200, 201 ), true ) ) {
				$result = json_decode( wp_remote_retrieve_body( $response ), true );
				break;
			}
			if ( 308 !== $status ) {
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes a temporary upload handle.
				return new WP_Error( 'tutorhelper_lms_google_resumable_upload_failed', __( 'Google Drive could not securely store this Resource file. Please try again.', 'tutorhelper-lms' ) );
			}
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes a temporary upload handle.

		if ( ! is_array( $result ) || empty( $result['id'] ) ) {
			return new WP_Error( 'tutorhelper_lms_google_store_invalid', __( 'Google Drive did not return a file reference.', 'tutorhelper-lms' ) );
		}
		return array( 'provider_file_id' => sanitize_text_field( $result['id'] ), 'storage_key' => sanitize_text_field( $result['id'] ) );
	}

	/**
	 * Return the app-created private folder for a student's uploads.
	 *
	 * The hierarchy deliberately stops at TutorHelper LMS / username in this
	 * release. Subject and topic folders will be added only once course/group
	 * relationships supply an unambiguous primary topic.
	 *
	 * @param int    $student_user_id Student ID.
	 * @param string $token Valid Google access token.
	 * @return string|WP_Error
	 */
	private static function student_folder_id( $student_user_id, $token ) {
		$root = self::find_or_create_folder( 'TutorHelper LMS', 'root', $token );
		if ( is_wp_error( $root ) ) {
			return $root;
		}

		$user = get_userdata( $student_user_id );
		$name = $user ? sanitize_file_name( $user->user_login ) : 'student-' . absint( $student_user_id );
		return self::find_or_create_folder( $name ? $name : 'student-' . absint( $student_user_id ), $root, $token );
	}

	/**
	 * Return the app-created private Resource Library folder.
	 *
	 * Course and Topic associations remain database relationships because one
	 * master file can serve several contexts. Folder placement is therefore
	 * deliberately stable and does not duplicate or move a file.
	 *
	 * @param string $token Valid Google access token.
	 * @return string|WP_Error
	 */
	private static function resource_library_folder_id( $token ) {
		$root = self::find_or_create_folder( 'TutorHelper LMS', 'root', $token );
		return is_wp_error( $root ) ? $root : self::find_or_create_folder( 'Resource Library', $root, $token );
	}

	/** Find an app-visible folder by parent and create it if absent. */
	private static function find_or_create_folder( $name, $parent_id, $token ) {
		$query = sprintf( "mimeType = 'application/vnd.google-apps.folder' and name = '%s' and '%s' in parents and trashed = false", str_replace( "'", "\\\\'", (string) $name ), str_replace( "'", "\\\\'", (string) $parent_id ) );
		$response = wp_remote_get( 'https://www.googleapis.com/drive/v3/files?' . http_build_query( array( 'q' => $query, 'fields' => 'files(id)', 'pageSize' => 1 ) ), array( 'timeout' => 30, 'headers' => array( 'Authorization' => 'Bearer ' . $token ) ) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'tutorhelper_lms_google_folder_lookup_failed', __( 'Google Drive could not prepare private coursework storage. Please try again.', 'tutorhelper-lms' ) );
		}
		$result = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! empty( $result['files'][0]['id'] ) ) {
			return sanitize_text_field( $result['files'][0]['id'] );
		}

		$response = wp_remote_post( 'https://www.googleapis.com/drive/v3/files?fields=id', array( 'timeout' => 30, 'headers' => array( 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'name' => $name, 'mimeType' => 'application/vnd.google-apps.folder', 'parents' => array( $parent_id ) ) ) ) );
		if ( is_wp_error( $response ) || ! in_array( wp_remote_retrieve_response_code( $response ), array( 200, 201 ), true ) ) {
			return new WP_Error( 'tutorhelper_lms_google_folder_create_failed', __( 'Google Drive could not prepare private coursework storage. Please try again.', 'tutorhelper-lms' ) );
		}
		$result = json_decode( wp_remote_retrieve_body( $response ), true );
		return ! empty( $result['id'] ) ? sanitize_text_field( $result['id'] ) : new WP_Error( 'tutorhelper_lms_google_folder_invalid', __( 'Google Drive did not return a private folder reference.', 'tutorhelper-lms' ) );
	}

	public function stream( $provider_file_id, $context ) {
		$token = TutorHelper_LMS_Google_Drive_Auth::access_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$temporary_file = wp_tempnam( 'tutorhelper-lms-download' );
		if ( ! $temporary_file ) {
			return new WP_Error( 'tutorhelper_lms_download_temp_failed', __( 'The private download could not be prepared.', 'tutorhelper-lms' ) );
		}

		$response = wp_remote_get(
			'https://www.googleapis.com/drive/v3/files/' . rawurlencode( (string) $provider_file_id ) . '?alt=media',
			array(
				'timeout' => 60,
				'stream' => true,
				'filename' => $temporary_file,
				'headers' => array( 'Authorization' => 'Bearer ' . $token ),
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) || ! is_readable( $temporary_file ) ) {
			@unlink( $temporary_file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Removes temporary private download.
			return new WP_Error( 'tutorhelper_lms_google_download_failed', __( 'Google Drive could not retrieve this private file. It has not been removed from the submission record.', 'tutorhelper-lms' ) );
		}

		nocache_headers();
		header( 'Content-Type: ' . ( ! empty( $context['mime_type'] ) ? $context['mime_type'] : 'application/octet-stream' ) );
		header( 'Content-Length: ' . (string) filesize( $temporary_file ) );
		$disposition = ! empty( $context['disposition'] ) && 'inline' === $context['disposition'] ? 'inline' : 'attachment';
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: ' . $disposition . '; filename="' . sanitize_file_name( (string) $context['filename'] ) . '"' );
		readfile( $temporary_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Streams one authenticated private download.
		@unlink( $temporary_file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Removes temporary private download.
		return true;
	}
}
