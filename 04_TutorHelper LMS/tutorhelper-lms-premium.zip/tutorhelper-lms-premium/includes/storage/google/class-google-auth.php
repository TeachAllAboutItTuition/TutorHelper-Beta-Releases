<?php
/**
 * Google Drive OAuth 2.0 connection service.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Google_Drive_Auth {

	const CLIENT_ID_OPTION     = 'tutorhelper_lms_google_drive_client_id';
	const CLIENT_SECRET_OPTION = 'tutorhelper_lms_google_drive_client_secret';
	const TOKENS_OPTION        = 'tutorhelper_lms_google_drive_tokens';
	const STATE_PREFIX         = 'tutorhelper_lms_google_state_';
	const SCOPE                = 'https://www.googleapis.com/auth/drive.file';

	/**
	 * Register Google Drive routes.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_tutorhelper_lms_google_drive_connect', array( __CLASS__, 'begin_connection' ) );
		add_action( 'admin_post_tutorhelper_lms_google_drive_callback', array( __CLASS__, 'handle_callback' ) );
		add_action( 'admin_post_tutorhelper_lms_google_drive_disconnect', array( __CLASS__, 'disconnect' ) );
	}

	/**
	 * Return the exact redirect URI that must be added to Google Cloud.
	 *
	 * @return string
	 */
	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=tutorhelper_lms_google_drive_callback' );
	}

	/**
	 * Whether client credentials have been configured and can be decrypted.
	 *
	 * @return bool
	 */
	public static function credentials_ready() {
		return '' !== self::client_id() && ! is_wp_error( self::client_secret() );
	}

	/**
	 * Whether a refresh token has been saved.
	 *
	 * @return bool
	 */
	public static function is_connected() {
		$tokens = self::tokens();

		return ! is_wp_error( $tokens ) && ! empty( $tokens['refresh_token'] );
	}

	/**
	 * Get the encrypted client ID.
	 *
	 * @return string
	 */
	public static function client_id() {
		return trim( (string) get_option( self::CLIENT_ID_OPTION, '' ) );
	}

	/**
	 * Get the decrypted client secret.
	 *
	 * @return string|WP_Error
	 */
	public static function client_secret() {
		$stored = (string) get_option( self::CLIENT_SECRET_OPTION, '' );

		if ( '' === $stored ) {
			return new WP_Error( 'tutorhelper_lms_google_credentials_missing', __( 'Google Drive client credentials have not been saved.', 'tutorhelper-lms' ) );
		}

		return TutorHelper_LMS_Secrets::decrypt( $stored );
	}

	/**
	 * Return current OAuth tokens.
	 *
	 * @return array|WP_Error
	 */
	public static function tokens() {
		$stored = (string) get_option( self::TOKENS_OPTION, '' );

		if ( '' === $stored ) {
			return new WP_Error( 'tutorhelper_lms_google_not_connected', __( 'Google Drive is not connected.', 'tutorhelper-lms' ) );
		}

		$json = TutorHelper_LMS_Secrets::decrypt( $stored );

		if ( is_wp_error( $json ) ) {
			return $json;
		}

		$tokens = json_decode( $json, true );

		return is_array( $tokens )
			? $tokens
			: new WP_Error( 'tutorhelper_lms_google_tokens_invalid', __( 'Saved Google Drive connection details are invalid.', 'tutorhelper-lms' ) );
	}

	/**
	 * Start an OAuth connection after verifying the current tutor administrator.
	 *
	 * @return void
	 */
	public static function begin_connection() {
		self::require_admin();
		check_admin_referer( 'tutorhelper_lms_google_drive_connect' );

		if ( ! TutorHelper_LMS_Secrets::is_available() ) {
			self::redirect_with_notice( 'encryption_unavailable' );
		}

		if ( ! self::credentials_ready() ) {
			self::redirect_with_notice( 'credentials_missing' );
		}

		try {
			$state = bin2hex( random_bytes( 32 ) );
		} catch ( Exception $exception ) {
			self::redirect_with_notice( 'state_failed' );
		}

		set_transient(
			self::STATE_PREFIX . $state,
			array(
				'user_id' => get_current_user_id(),
				'created' => time(),
			),
			10 * MINUTE_IN_SECONDS
		);

		$url = add_query_arg(
			array(
				'client_id'             => self::client_id(),
				'redirect_uri'          => self::redirect_uri(),
				'response_type'         => 'code',
				'scope'                 => self::SCOPE,
				'access_type'           => 'offline',
				'include_granted_scopes'=> 'true',
				'prompt'                => 'consent',
				'state'                 => $state,
			),
			'https://accounts.google.com/o/oauth2/v2/auth'
		);

		wp_redirect( esc_url_raw( $url ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- OAuth endpoint is a fixed Google URL.
		exit;
	}

	/**
	 * Validate the OAuth callback and securely store returned tokens.
	 *
	 * @return void
	 */
	public static function handle_callback() {
		$state = isset( $_GET['state'] ) && ! is_array( $_GET['state'] )
			? sanitize_text_field( wp_unslash( $_GET['state'] ) )
			: '';
		$context = '' !== $state ? get_transient( self::STATE_PREFIX . $state ) : false;

		if ( ! is_array( $context ) || empty( $context['user_id'] ) || absint( $context['user_id'] ) !== get_current_user_id() ) {
			self::redirect_with_notice( 'state_invalid' );
		}

		delete_transient( self::STATE_PREFIX . $state );
		self::require_admin();

		$error = isset( $_GET['error'] ) && ! is_array( $_GET['error'] )
			? sanitize_key( wp_unslash( $_GET['error'] ) )
			: '';

		if ( '' !== $error ) {
			self::redirect_with_notice( 'google_denied' );
		}

		$code = isset( $_GET['code'] ) && ! is_array( $_GET['code'] )
			? sanitize_text_field( wp_unslash( $_GET['code'] ) )
			: '';

		if ( '' === $code ) {
			self::redirect_with_notice( 'code_missing' );
		}

		$secret = self::client_secret();

		if ( is_wp_error( $secret ) ) {
			self::redirect_with_notice( 'credentials_missing' );
		}

		$response = wp_remote_post(
			'https://oauth2.googleapis.com/token',
			array(
				'timeout' => 20,
				'body'    => array(
					'code'          => $code,
					'client_id'     => self::client_id(),
					'client_secret' => $secret,
					'redirect_uri'  => self::redirect_uri(),
					'grant_type'    => 'authorization_code',
				),
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			self::redirect_with_notice( 'token_exchange_failed' );
		}

		$tokens = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( is_array( $tokens ) ) {
			$tokens['created'] = time();
		}

		if ( ! is_array( $tokens ) || empty( $tokens['refresh_token'] ) ) {
			self::redirect_with_notice( 'refresh_token_missing' );
		}

		$encrypted = TutorHelper_LMS_Secrets::encrypt( wp_json_encode( $tokens ) );

		if ( is_wp_error( $encrypted ) ) {
			self::redirect_with_notice( 'token_encrypt_failed' );
		}

		update_option( self::TOKENS_OPTION, $encrypted, false );
		self::redirect_with_notice( 'connected' );
	}

	/**
	 * Return a current OAuth access token, refreshing it when necessary.
	 *
	 * @return string|WP_Error
	 */
	public static function access_token() {
		$tokens = self::tokens();

		if ( is_wp_error( $tokens ) || empty( $tokens['refresh_token'] ) ) {
			return is_wp_error( $tokens ) ? $tokens : new WP_Error( 'tutorhelper_lms_google_not_connected', __( 'Google Drive is not connected.', 'tutorhelper-lms' ) );
		}

		if ( ! empty( $tokens['access_token'] ) && ! empty( $tokens['expires_in'] ) && ! empty( $tokens['created'] ) && (int) $tokens['created'] + (int) $tokens['expires_in'] - 60 > time() ) {
			return (string) $tokens['access_token'];
		}

		$secret = self::client_secret();
		if ( is_wp_error( $secret ) ) {
			return $secret;
		}

		$response = wp_remote_post(
			'https://oauth2.googleapis.com/token',
			array(
				'timeout' => 20,
				'body' => array(
					'client_id' => self::client_id(),
					'client_secret' => $secret,
					'refresh_token' => $tokens['refresh_token'],
					'grant_type' => 'refresh_token',
				),
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'tutorhelper_lms_google_refresh_failed', __( 'Google Drive could not refresh its secure connection.', 'tutorhelper-lms' ) );
		}

		$refreshed = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $refreshed ) || empty( $refreshed['access_token'] ) ) {
			return new WP_Error( 'tutorhelper_lms_google_refresh_invalid', __( 'Google Drive returned an invalid connection response.', 'tutorhelper-lms' ) );
		}

		$tokens = array_merge( $tokens, $refreshed );
		$tokens['created'] = time();
		$encrypted = TutorHelper_LMS_Secrets::encrypt( wp_json_encode( $tokens ) );
		if ( is_wp_error( $encrypted ) ) {
			return new WP_Error( 'tutorhelper_lms_google_refresh_store_failed', __( 'Google Drive connection details could not be securely updated.', 'tutorhelper-lms' ) );
		}
		update_option( self::TOKENS_OPTION, $encrypted, false );

		return (string) $tokens['access_token'];
	}

	/**
	 * Disconnect Google Drive without deleting existing submission records.
	 *
	 * @return void
	 */
	public static function disconnect() {
		self::require_admin();
		check_admin_referer( 'tutorhelper_lms_google_drive_disconnect' );
		delete_option( self::TOKENS_OPTION );
		self::redirect_with_notice( 'disconnected' );
	}

	/**
	 * Require TutorHelper administrator access.
	 *
	 * @return void
	 */
	private static function require_admin() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage the Google Drive connection.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
	}

	/**
	 * Return to the LMS settings tab with a safe status code.
	 *
	 * @param string $notice Notice identifier.
	 * @return void
	 */
	private static function redirect_with_notice( $notice ) {
		$url = add_query_arg(
			array(
				'page'                     => TutorHelper_Admin::MENU_SLUG,
				'tab'                      => TutorHelper_LMS_Settings::TAB,
				'tutorhelper_lms_google'  => sanitize_key( $notice ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
