<?php
/**
 * Premium adaptive practice Quiz pools.
 *
 * @package TutorHelper_LMS_Premium
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Adaptive_Practice {

	/**
	 * Automatically-marked Question types that can form an adaptive pool.
	 *
	 * @var string[]
	 */
	private static $objective_types = array(
		'single_choice',
		'multiple_choice',
		'free_answer',
		'sort_answer',
		'matrix_sort',
		'cloze',
	);

	/**
	 * Register Premium extensions to the Core Quiz lifecycle.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'tutorhelper_lms_quiz_builder_premium_options', array( __CLASS__, 'render_builder_options' ), 10, 2 );
		add_filter( 'tutorhelper_lms_quiz_definition_from_request', array( __CLASS__, 'save_definition' ), 10, 3 );
		add_filter( 'tutorhelper_lms_quiz_canonical_definition', array( __CLASS__, 'canonical_definition' ), 10, 2 );
		add_filter( 'tutorhelper_lms_quiz_attempt_snapshot_questions', array( __CLASS__, 'select_attempt_questions' ), 10, 4 );
		add_filter( 'tutorhelper_lms_quiz_attempt_passed', array( __CLASS__, 'calculate_pass_outcome' ), 10, 5 );
		add_filter( 'tutorhelper_lms_quiz_attempt_requirement_label', array( __CLASS__, 'requirement_label' ), 10, 4 );
		add_filter( 'tutorhelper_lms_quiz_attempt_review_pass_label', array( __CLASS__, 'review_pass_label' ), 10, 4 );
		add_filter( 'tutorhelper_lms_quiz_errors', array( __CLASS__, 'builder_errors' ) );
	}

	/**
	 * Render the adaptive-practice controls in the reusable Quiz Builder.
	 *
	 * @param array $definition Current immutable Quiz definition.
	 * @param array $selected   Selected Question placements.
	 * @return void
	 */
	public static function render_builder_options( $definition, $selected ) {
		$practice = self::normalise_practice( $definition['practice'] ?? array() );
		$count    = count( $selected );
		$adaptive = 'adaptive' === $practice['mode'];
		?>
		<div class="tutorhelper-lms-quiz-builder__option tutorhelper-lms-quiz-builder__option--premium tutorhelper-lms-adaptive-practice">
			<label for="tutorhelper-lms-practice-mode"><strong><?php esc_html_e( 'Premium practice mode', 'tutorhelper-lms-premium' ); ?></strong></label>
			<div class="tutorhelper-lms-quiz-builder__option-control">
				<select id="tutorhelper-lms-practice-mode" name="practice_mode" data-tutorhelper-lms-practice-mode>
					<option value="standard" <?php selected( $practice['mode'], 'standard' ); ?>><?php esc_html_e( 'Standard Quiz', 'tutorhelper-lms-premium' ); ?></option>
					<option value="adaptive" <?php selected( $practice['mode'], 'adaptive' ); ?>><?php esc_html_e( 'Adaptive Practice Quiz', 'tutorhelper-lms-premium' ); ?></option>
				</select>
				<span class="tutorhelper-lms-quiz-builder__help" tabindex="0" role="img" aria-label="<?php esc_attr_e( 'Adaptive practice takes a fresh selection from this Question pool for each new attempt. Questions not yet seen or answered incorrectly are prioritised; Questions mastered five or more times are least likely to appear.', 'tutorhelper-lms-premium' ); ?>">
					<span class="dashicons dashicons-editor-help" aria-hidden="true"></span>
					<span class="tutorhelper-lms-quiz-builder__help-text"><?php esc_html_e( 'Adaptive practice takes a fresh selection from this Question pool for each new attempt. Questions not yet seen or answered incorrectly are prioritised; Questions mastered five or more times are least likely to appear.', 'tutorhelper-lms-premium' ); ?></span>
				</span>
			</div>
			<p class="description"><?php esc_html_e( 'Adaptive Practice uses only automatically marked Questions. It also favours a mix of Question types when Questions have similar learning priority.', 'tutorhelper-lms-premium' ); ?></p>
		</div>
		<div class="tutorhelper-lms-quiz-builder__option tutorhelper-lms-quiz-builder__option--premium" data-tutorhelper-lms-adaptive-settings<?php echo $adaptive ? '' : ' hidden'; ?>>
			<label for="tutorhelper-lms-practice-question-count"><strong><?php esc_html_e( 'Questions per practice attempt', 'tutorhelper-lms-premium' ); ?></strong></label>
			<div class="tutorhelper-lms-quiz-builder__option-control">
				<input id="tutorhelper-lms-practice-question-count" type="number" min="1" max="<?php echo esc_attr( max( 1, $count ) ); ?>" step="1" name="practice_question_count" data-tutorhelper-lms-practice-question-count<?php disabled( ! $adaptive ); ?> value="<?php echo esc_attr( absint( $practice['questions_per_attempt'] ? $practice['questions_per_attempt'] : min( 10, max( 1, $count ) ) ) ); ?>" />
			</div>
			<p class="description"><?php esc_html_e( 'The pool can hold many more Questions than each student sees in one practice attempt.', 'tutorhelper-lms-premium' ); ?></p>
		</div>
		<div class="tutorhelper-lms-quiz-builder__option tutorhelper-lms-quiz-builder__option--premium" data-tutorhelper-lms-adaptive-settings<?php echo $adaptive ? '' : ' hidden'; ?>>
			<label for="tutorhelper-lms-practice-pass-percentage"><strong><?php esc_html_e( 'Adaptive practice pass percentage', 'tutorhelper-lms-premium' ); ?></strong></label>
			<div class="tutorhelper-lms-quiz-builder__option-control">
				<input id="tutorhelper-lms-practice-pass-percentage" type="number" min="1" max="100" step="1" name="practice_pass_percentage" data-tutorhelper-lms-practice-pass-percentage<?php disabled( ! $adaptive ); ?> value="<?php echo esc_attr( absint( $practice['pass_percentage'] ) ); ?>" />%
			</div>
			<p class="description"><?php esc_html_e( 'This percentage replaces the normal fixed pass mark for adaptive practice attempts.', 'tutorhelper-lms-premium' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Validate and attach submitted Premium practice settings to a Quiz definition.
	 *
	 * @param array $definition Core definition.
	 * @param array $placements Selected Question placements.
	 * @param int   $quiz_id Quiz post ID.
	 * @return array|WP_Error
	 */
	public static function save_definition( $definition, $placements, $quiz_id ) {
		$mode = isset( $_POST['practice_mode'] ) && ! is_array( $_POST['practice_mode'] ) ? sanitize_key( wp_unslash( $_POST['practice_mode'] ) ) : 'standard'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core Quiz save action verifies its nonce.

		if ( 'adaptive' !== $mode ) {
			$definition['practice'] = array( 'mode' => 'standard' );
			return $definition;
		}

		if ( ! TutorHelper_LMS_Premium::is_available() ) {
			return new WP_Error( 'adaptive_practice_requires_premium' );
		}

		$questions_per_attempt = isset( $_POST['practice_question_count'] ) && ! is_array( $_POST['practice_question_count'] ) ? absint( wp_unslash( $_POST['practice_question_count'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core Quiz save action verifies its nonce.
		$pass_percentage       = isset( $_POST['practice_pass_percentage'] ) && ! is_array( $_POST['practice_pass_percentage'] ) ? absint( wp_unslash( $_POST['practice_pass_percentage'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core Quiz save action verifies its nonce.
		$pool_count            = count( $placements );

		if ( $questions_per_attempt < 1 || $questions_per_attempt > $pool_count ) {
			return new WP_Error( 'adaptive_practice_question_count' );
		}
		if ( $pass_percentage < 1 || $pass_percentage > 100 ) {
			return new WP_Error( 'adaptive_practice_pass_percentage' );
		}
		if ( ! self::placements_are_objective( $placements ) ) {
			return new WP_Error( 'adaptive_practice_manual_question' );
		}

		$definition['practice'] = array(
			'mode'                  => 'adaptive',
			'questions_per_attempt' => $questions_per_attempt,
			'pass_percentage'       => $pass_percentage,
		);

		// Adaptive attempts calculate their result from their own available marks.
		$definition['pass_mark'] = 0;

		return $definition;
	}

	/**
	 * Include practice settings when calculating a version fingerprint.
	 *
	 * @param array $canonical  Core canonical definition.
	 * @param array $definition Source definition.
	 * @return array
	 */
	public static function canonical_definition( $canonical, $definition ) {
		$canonical['practice'] = self::normalise_practice( $definition['practice'] ?? array() );
		return $canonical;
	}

	/**
	 * Select one immutable adaptive practice snapshot.
	 *
	 * Mastery always remains the main decision. Type diversity only boosts an
	 * otherwise similarly useful type; it cannot make mastered Questions outrank
	 * unseen or recently incorrect Questions.
	 *
	 * @param array  $questions       Pool rows from Core.
	 * @param array  $definition      Immutable Quiz definition.
	 * @param object $placement       Course Quiz placement.
	 * @param int    $student_user_id Student ID.
	 * @return array|WP_Error
	 */
	public static function select_attempt_questions( $questions, $definition, $placement, $student_user_id ) {
		$practice = self::normalise_practice( $definition['practice'] ?? array() );
		if ( 'adaptive' !== $practice['mode'] ) {
			return $questions;
		}

		$question_ids = array_values( array_unique( array_filter( array_map( 'absint', wp_list_pluck( $questions, 'question_id' ) ) ) ) );
		if ( $practice['questions_per_attempt'] > count( $question_ids ) ) {
			return new WP_Error( 'quiz_attempt_unavailable', __( 'This adaptive Quiz needs more eligible Questions in its pool before it can start.', 'tutorhelper-lms-premium' ) );
		}

		$history    = self::question_history( absint( $student_user_id ), $question_ids );
		$candidates = array();

		foreach ( $questions as $question ) {
			$question_id = absint( self::question_value( $question, 'question_id' ) );
			$definition_json = json_decode( (string) self::question_value( $question, 'definition_json' ), true );
			$type = sanitize_key( is_array( $definition_json ) ? ( $definition_json['question_type'] ?? '' ) : '' );
			if ( ! $question_id || ! in_array( $type, self::$objective_types, true ) ) {
				return new WP_Error( 'quiz_attempt_unavailable', __( 'This adaptive Quiz has a Question that needs tutor marking. Please ask your tutor to update its pool.', 'tutorhelper-lms-premium' ) );
			}

			$candidates[] = array(
				'question' => $question,
				'type'     => $type,
				'priority' => self::learning_priority( $history[ $question_id ] ?? array() ),
			);
		}

		$selected    = array();
		$type_counts = array();

		while ( count( $selected ) < $practice['questions_per_attempt'] && ! empty( $candidates ) ) {
			$choice = self::weighted_pick( $candidates, $type_counts );
			if ( null === $choice ) {
				break;
			}
			$selected[] = $choice['question'];
			$type       = $choice['type'];
			$type_counts[ $type ] = absint( $type_counts[ $type ] ?? 0 ) + 1;

			foreach ( $candidates as $index => $candidate ) {
				if ( absint( self::question_value( $candidate['question'], 'question_id' ) ) === absint( self::question_value( $choice['question'], 'question_id' ) ) ) {
					unset( $candidates[ $index ] );
					break;
				}
			}
			$candidates = array_values( $candidates );
		}

		return $selected;
	}

	/**
	 * Apply percentage-based pass/fail to adaptive snapshots.
	 *
	 * @param bool  $passed    Core result.
	 * @param int   $marks     Awarded marks.
	 * @param int   $available Available marks.
	 * @param array $snapshot  Attempt snapshot.
	 * @return bool
	 */
	public static function calculate_pass_outcome( $passed, $marks, $available, $snapshot ) {
		$quiz     = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
		$practice = self::normalise_practice( $quiz['practice'] ?? array() );
		if ( 'adaptive' !== $practice['mode'] || absint( $available ) < 1 ) {
			return (bool) $passed;
		}

		return ( ( absint( $marks ) * 100 ) / absint( $available ) ) >= absint( $practice['pass_percentage'] );
	}

	/**
	 * Replace a fixed-mark threshold with an adaptive percentage threshold.
	 *
	 * @param string $label Default Core label.
	 * @param array  $snapshot Attempt snapshot.
	 * @param int    $pass_mark Core fixed pass mark.
	 * @param int    $available Available marks.
	 * @return string
	 */
	public static function requirement_label( $label, $snapshot, $pass_mark, $available ) {
		$quiz = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
		$practice = self::normalise_practice( $quiz['practice'] ?? array() );
		return 'adaptive' === $practice['mode']
			? sprintf( __( 'You must score %d%% to pass', 'tutorhelper-lms-premium' ), absint( $practice['pass_percentage'] ) )
			: $label;
	}

	/**
	 * Replace the review threshold label for adaptive percentage outcomes.
	 *
	 * @param string $label Default Core label.
	 * @param array  $snapshot Attempt snapshot.
	 * @param int    $percentage Achieved percentage.
	 * @param int    $pass_mark Core fixed pass mark.
	 * @return string
	 */
	public static function review_pass_label( $label, $snapshot, $percentage, $pass_mark ) {
		$quiz = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
		$practice = self::normalise_practice( $quiz['practice'] ?? array() );
		return 'adaptive' === $practice['mode']
			? sprintf( __( '%1$d%% · Pass mark: %2$d%%', 'tutorhelper-lms-premium' ), absint( $percentage ), absint( $practice['pass_percentage'] ) )
			: $label;
	}

	/**
	 * Add learner-friendly builder validation messages.
	 *
	 * @param array $errors Existing messages.
	 * @return array
	 */
	public static function builder_errors( $errors ) {
		$errors['adaptive_practice_requires_premium'] = __( 'Adaptive Practice Quizzes require TutorHelper LMS Premium.', 'tutorhelper-lms-premium' );
		$errors['adaptive_practice_question_count']   = __( 'Choose at least one Question and no more Questions than are in the practice pool.', 'tutorhelper-lms-premium' );
		$errors['adaptive_practice_pass_percentage']  = __( 'Enter an adaptive practice pass percentage between 1 and 100.', 'tutorhelper-lms-premium' );
		$errors['adaptive_practice_manual_question']  = __( 'Adaptive Practice Quizzes can contain only automatically marked Question types. Remove written-response or file-upload Questions from this pool.', 'tutorhelper-lms-premium' );
		return $errors;
	}

	/**
	 * Return safe, immutable practice configuration.
	 *
	 * @param mixed $practice Candidate configuration.
	 * @return array
	 */
	private static function normalise_practice( $practice ) {
		$practice = is_array( $practice ) ? $practice : array();
		$mode = 'adaptive' === sanitize_key( $practice['mode'] ?? '' ) ? 'adaptive' : 'standard';

		return array(
			'mode'                  => $mode,
			'questions_per_attempt' => absint( $practice['questions_per_attempt'] ?? 0 ),
			'pass_percentage'       => min( 100, max( 1, absint( $practice['pass_percentage'] ?? 70 ) ) ),
		);
	}

	/**
	 * Ensure a configured pool contains only automatic Question types.
	 *
	 * @param array $placements Question placements.
	 * @return bool
	 */
	private static function placements_are_objective( $placements ) {
		global $wpdb;

		$version_ids = array_values( array_unique( array_filter( array_map( 'absint', wp_list_pluck( $placements, 'question_version_id' ) ) ) ) );
		if ( empty( $version_ids ) || count( $version_ids ) !== count( $placements ) ) {
			return false;
		}

		$table = TutorHelper_LMS_Free_Database::table( 'question_versions' );
		if ( ! $table ) {
			return false;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $version_ids ), '%d' ) );
		$query = call_user_func_array(
			array( $wpdb, 'prepare' ),
			array_merge( array( "SELECT id, definition_json FROM {$table} WHERE id IN ({$placeholders})" ), $version_ids )
		);
		$rows = $wpdb->get_results( $query, ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Validates the tutor's adaptive practice pool before it is saved.
		if ( count( $rows ) !== count( $version_ids ) ) {
			return false;
		}

		foreach ( $rows as $row ) {
			$definition = json_decode( (string) ( $row['definition_json'] ?? '' ), true );
			$type = sanitize_key( is_array( $definition ) ? ( $definition['question_type'] ?? '' ) : '' );
			if ( ! in_array( $type, self::$objective_types, true ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Read a snapshotted Question row regardless of WordPress database return mode.
	 *
	 * @param array|object $question Question row.
	 * @param string       $key Field name.
	 * @return mixed
	 */
	private static function question_value( $question, $key ) {
		if ( is_object( $question ) ) {
			return $question->{$key} ?? null;
		}
		return is_array( $question ) ? ( $question[ $key ] ?? null ) : null;
	}

	/**
	 * Retrieve one student's historic automatic marking for pool Questions.
	 *
	 * @param int   $student_user_id Student ID.
	 * @param array $question_ids Question IDs.
	 * @return array
	 */
	private static function question_history( $student_user_id, $question_ids ) {
		global $wpdb;

		$history = array();
		foreach ( $question_ids as $question_id ) {
			$history[ absint( $question_id ) ] = array( 'attempts' => 0, 'correct' => 0, 'last_status' => '' );
		}
		if ( empty( $history ) ) {
			return $history;
		}

		$attempts  = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$responses = TutorHelper_LMS_Free_Database::table( 'quiz_attempt_responses' );
		if ( ! $attempts || ! $responses ) {
			return $history;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $history ), '%d' ) );
		$sql = "SELECT response.question_id, response.auto_mark_json
			FROM {$responses} response
			INNER JOIN {$attempts} attempt ON attempt.id = response.attempt_id
			WHERE attempt.student_user_id = %d
				AND attempt.status = 'completed'
				AND response.question_id IN ({$placeholders})
			ORDER BY attempt.completed_at ASC, response.id ASC";
		$args = array_merge( array( absint( $student_user_id ) ), array_keys( $history ) );
		$query = call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $sql ), $args ) );
		$rows = $wpdb->get_results( $query, ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Adaptive selection needs the student's own historic marks.

		foreach ( (array) $rows as $row ) {
			$question_id = absint( $row['question_id'] ?? 0 );
			if ( ! isset( $history[ $question_id ] ) ) {
				continue;
			}
			$mark = json_decode( (string) ( $row['auto_mark_json'] ?? '' ), true );
			$status = sanitize_key( is_array( $mark ) ? ( $mark['status'] ?? '' ) : '' );
			$history[ $question_id ]['attempts']++;
			$history[ $question_id ]['last_status'] = $status;
			if ( 'correct' === $status ) {
				$history[ $question_id ]['correct']++;
			}
		}

		return $history;
	}

	/**
	 * Convert historic marks into an intentionally broad learning priority.
	 *
	 * @param array $history Question history.
	 * @return int
	 */
	private static function learning_priority( $history ) {
		$attempts = absint( $history['attempts'] ?? 0 );
		$correct  = absint( $history['correct'] ?? 0 );
		$last     = sanitize_key( $history['last_status'] ?? '' );

		if ( 0 === $attempts ) {
			return 1000;
		}
		if ( in_array( $last, array( 'incorrect', 'partial' ), true ) ) {
			return 800;
		}
		if ( $correct >= 5 ) {
			return 100;
		}
		return 450;
	}

	/**
	 * Pick one candidate with mastery-first weighted randomness.
	 *
	 * A Question type not represented in the current selection gets a modest
	 * 35% boost. This means meaningful variety without overpowering learning
	 * priority: an unseen Question remains more useful than a mastered one.
	 *
	 * @param array $candidates Candidate rows.
	 * @param array $type_counts Selected count by Question type.
	 * @return array|null
	 */
	private static function weighted_pick( $candidates, $type_counts ) {
		$total = 0;
		$weights = array();

		foreach ( $candidates as $index => $candidate ) {
			$weight = max( 1, absint( $candidate['priority'] ?? 1 ) );
			if ( ! empty( $type_counts ) && empty( $type_counts[ $candidate['type'] ] ) ) {
				$weight = (int) round( $weight * 1.35 );
			}
			$weights[ $index ] = $weight;
			$total += $weight;
		}
		if ( $total < 1 ) {
			return null;
		}

		try {
			$roll = random_int( 1, $total );
		} catch ( Exception $exception ) {
			$roll = mt_rand( 1, $total );
		}

		foreach ( $weights as $index => $weight ) {
			$roll -= $weight;
			if ( $roll <= 0 ) {
				return $candidates[ $index ];
			}
		}

		return null;
	}
}
