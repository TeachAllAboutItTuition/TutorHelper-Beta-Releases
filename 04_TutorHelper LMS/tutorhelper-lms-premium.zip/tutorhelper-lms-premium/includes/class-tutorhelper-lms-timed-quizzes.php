<?php
/**
 * Premium timed Quiz delivery and exam-access arrangements.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Timed_Quizzes {

	const EXTRA_TIME_META = '_tutorhelper_lms_exam_extra_time';
	const SAVE_ACTION     = 'tutorhelper_lms_save_exam_extra_time';

	/**
	 * Register Premium-only timing controls.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'tutorhelper_lms_quiz_builder_premium_options', array( __CLASS__, 'render_builder_options' ), 20, 2 );
		add_filter( 'tutorhelper_lms_quiz_definition_from_request', array( __CLASS__, 'save_definition' ), 20, 3 );
		add_filter( 'tutorhelper_lms_quiz_canonical_definition', array( __CLASS__, 'canonical_definition' ), 20, 2 );
		add_filter( 'tutorhelper_lms_quiz_attempt_snapshot', array( __CLASS__, 'snapshot_timing' ), 20, 3 );
		add_filter( 'tutorhelper_lms_quiz_attempt_expired', array( __CLASS__, 'attempt_expired' ), 20, 2 );
		add_action( 'tutorhelper_lms_quiz_player_summary', array( __CLASS__, 'render_timer' ), 10, 2 );
		add_action( 'tutorhelper_lms_quiz_attempt_review_meta', array( __CLASS__, 'render_review_meta' ), 10, 2 );
		add_action( 'tutorhelper_students_detail_academic_courses', array( __CLASS__, 'render_exam_arrangement' ), 30 );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save_exam_arrangement' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Load the small learner timer asset bundle.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {
		$css_path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/css/tutorhelper-lms-timed-quiz.css';
		$js_path  = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-timed-quiz.js';
		wp_enqueue_style( 'tutorhelper-lms-timed-quiz', TUTORHELPER_LMS_PREMIUM_URL . 'assets/css/tutorhelper-lms-timed-quiz.css', array(), file_exists( $css_path ) ? (string) filemtime( $css_path ) : TUTORHELPER_LMS_PREMIUM_VERSION );
		wp_enqueue_script( 'tutorhelper-lms-timed-quiz', TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-timed-quiz.js', array(), file_exists( $js_path ) ? (string) filemtime( $js_path ) : TUTORHELPER_LMS_PREMIUM_VERSION, true );
	}

	/**
	 * Render Premium timer configuration in the reusable Quiz Builder.
	 *
	 * @param array $definition Current Quiz definition.
	 * @param array $selected Selected Question rows.
	 * @return void
	 */
	public static function render_builder_options( $definition, $selected ) {
		$timing = self::normalise_timing( $definition['timing'] ?? array() );
		$minutes = max( 1, (int) ceil( $timing['duration_seconds'] / 60 ) );
		?>
		<div class="tutorhelper-lms-quiz-builder__option tutorhelper-lms-quiz-builder__option--premium">
			<label><strong><?php esc_html_e( 'Timed Quiz', 'tutorhelper-lms' ); ?></strong></label>
			<p><label><input type="checkbox" name="timed_quiz" value="1" data-tutorhelper-lms-timed-quiz-toggle <?php checked( 'timed' === $timing['mode'] ); ?> /> <?php esc_html_e( 'Automatically submit answers when time runs out.', 'tutorhelper-lms' ); ?></label></p>
			<div data-tutorhelper-lms-timed-quiz-settings<?php echo 'timed' === $timing['mode'] ? '' : ' hidden'; ?>>
				<p>
					<label for="tutorhelper-lms-quiz-time-limit"><strong><?php esc_html_e( 'Time allowed', 'tutorhelper-lms' ); ?></strong></label>
					<input id="tutorhelper-lms-quiz-time-limit" type="number" min="1" step="1" name="timed_quiz_minutes" value="<?php echo esc_attr( $minutes ); ?>"<?php echo 'timed' === $timing['mode'] ? ' required' : ''; ?> /> <?php esc_html_e( 'minutes', 'tutorhelper-lms' ); ?>
				</p>
				<p class="description"><?php esc_html_e( 'Students see a countdown, may hide it without pausing it, and their individual exam extra-time arrangement is applied automatically.', 'tutorhelper-lms' ); ?></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Save a safe immutable timed-Quiz definition.
	 *
	 * @param array $definition Core Quiz definition.
	 * @param array $placements Question placements.
	 * @param int   $quiz_id Quiz ID.
	 * @return array|WP_Error
	 */
	public static function save_definition( $definition, $placements, $quiz_id ) {
		$enabled = ! empty( $_POST['timed_quiz'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core Quiz save verifies the enclosing nonce.
		$minutes = isset( $_POST['timed_quiz_minutes'] ) && ! is_array( $_POST['timed_quiz_minutes'] ) ? absint( wp_unslash( $_POST['timed_quiz_minutes'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core Quiz save verifies the enclosing nonce.
		if ( $enabled && $minutes < 1 ) {
			return new WP_Error( 'invalid_timed_quiz_duration' );
		}
		$definition['timing'] = array(
			'mode'             => $enabled ? 'timed' : 'untimed',
			'duration_seconds' => $enabled ? $minutes * MINUTE_IN_SECONDS : 0,
		);
		return $definition;
	}

	/**
	 * Preserve timing in the Quiz-version fingerprint.
	 *
	 * @param array $canonical Core canonical definition.
	 * @param array $definition Full definition.
	 * @return array
	 */
	public static function canonical_definition( $canonical, $definition ) {
		$canonical['timing'] = self::normalise_timing( $definition['timing'] ?? array() );
		return $canonical;
	}

	/**
	 * Freeze duration, access arrangement and deadline when an attempt starts.
	 *
	 * @param array  $snapshot Attempt snapshot.
	 * @param object $placement Course placement.
	 * @param int    $student_user_id Student ID.
	 * @return array
	 */
	public static function snapshot_timing( $snapshot, $placement, $student_user_id ) {
		$timing = self::normalise_timing( $snapshot['quiz']['timing'] ?? array() );
		$extra_percentage = self::exam_extra_time_percentage( $student_user_id );
		$base_seconds = absint( $timing['duration_seconds'] );
		$extra_seconds = 'timed' === $timing['mode'] ? (int) round( $base_seconds * $extra_percentage / 100 ) : 0;
		$allowed_seconds = $base_seconds + $extra_seconds;
		$now = current_time( 'timestamp', true );

		$snapshot['timing'] = array(
			'mode'               => $timing['mode'],
			'base_seconds'       => $base_seconds,
			'extra_percentage'   => $extra_percentage,
			'extra_seconds'      => $extra_seconds,
			'allowed_seconds'    => $allowed_seconds,
			'deadline_timestamp' => 'timed' === $timing['mode'] ? $now + $allowed_seconds : 0,
		);
		return $snapshot;
	}

	/**
	 * Prevent any post-deadline draft from remaining resumable.
	 *
	 * @param bool   $expired Current state.
	 * @param object $attempt Attempt row.
	 * @return bool
	 */
	public static function attempt_expired( $expired, $attempt ) {
		if ( $expired || ! is_object( $attempt ) || 'in_progress' !== (string) ( $attempt->status ?? '' ) ) {
			return (bool) $expired;
		}
		$snapshot = json_decode( (string) ( $attempt->snapshot_json ?? '' ), true );
		$timing = is_array( $snapshot['timing'] ?? null ) ? $snapshot['timing'] : array();
		return 'timed' === sanitize_key( $timing['mode'] ?? '' ) && absint( $timing['deadline_timestamp'] ?? 0 ) <= current_time( 'timestamp', true );
	}

	/**
	 * Render the sticky learner countdown.
	 *
	 * @param object $attempt Attempt row.
	 * @param array  $snapshot Snapshot.
	 * @return void
	 */
	public static function render_timer( $attempt, $snapshot ) {
		$timing = is_array( $snapshot['timing'] ?? null ) ? $snapshot['timing'] : array();
		if ( 'timed' !== sanitize_key( $timing['mode'] ?? '' ) ) {
			return;
		}
		$deadline = absint( $timing['deadline_timestamp'] ?? 0 );
		if ( ! $deadline ) {
			return;
		}
		?>
		<aside class="tutorhelper-lms-quiz-timer" data-tutorhelper-lms-quiz-timer data-deadline="<?php echo esc_attr( $deadline ); ?>" aria-live="polite">
			<div class="tutorhelper-lms-quiz-timer__heading"><span class="dashicons dashicons-clock" aria-hidden="true"></span><strong><?php esc_html_e( 'Time remaining', 'tutorhelper-lms' ); ?></strong></div>
			<strong class="tutorhelper-lms-quiz-timer__countdown" data-tutorhelper-lms-quiz-countdown><?php echo esc_html( self::duration_label( max( 0, $deadline - current_time( 'timestamp', true ) ) ) ); ?></strong>
			<?php if ( absint( $timing['extra_seconds'] ?? 0 ) > 0 ) : ?><p><?php echo esc_html( sprintf( __( '%1$d%% exam extra time: +%2$s', 'tutorhelper-lms' ), absint( $timing['extra_percentage'] ), self::duration_label( absint( $timing['extra_seconds'] ) ) ) ); ?></p><?php endif; ?>
			<button type="button" class="tutorhelper-lms-quiz__button tutorhelper-lms-quiz__button--secondary" data-tutorhelper-lms-hide-timer><?php esc_html_e( 'Hide timer', 'tutorhelper-lms' ); ?></button>
		</aside>
		<?php
	}

	/**
	 * Show the timed-attempt allowance in released feedback.
	 *
	 * @param object $attempt Attempt row.
	 * @param array  $snapshot Snapshot.
	 * @return void
	 */
	public static function render_review_meta( $attempt, $snapshot ) {
		$timing = is_array( $snapshot['timing'] ?? null ) ? $snapshot['timing'] : array();
		if ( 'timed' !== sanitize_key( $timing['mode'] ?? '' ) ) {
			return;
		}
		$label = sprintf( __( 'Timed Quiz: %s allowed.', 'tutorhelper-lms' ), self::duration_label( absint( $timing['allowed_seconds'] ?? 0 ) ) );
		if ( absint( $timing['extra_seconds'] ?? 0 ) > 0 ) {
			$label .= ' ' . sprintf( __( 'This includes %1$d%% exam extra time (%2$s).', 'tutorhelper-lms' ), absint( $timing['extra_percentage'] ?? 0 ), self::duration_label( absint( $timing['extra_seconds'] ) ) );
		}
		echo '<p class="tutorhelper-lms-quiz__timing-meta">' . esc_html( $label ) . '</p>';
	}

	/**
	 * Add Premium exam-extra-time controls to the Bookings student Academic Courses area.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render_exam_arrangement( $student ) {
		if ( ! $student instanceof WP_User || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$current = self::exam_extra_time_percentage( $student->ID );
		?>
		<hr />
		<h4><?php esc_html_e( 'Exam access arrangements', 'tutorhelper-lms' ); ?></h4>
		<p class="description"><?php esc_html_e( 'This applies to every timed LMS Quiz for this student. It does not alter the reusable Quiz or other students’ attempts.', 'tutorhelper-lms' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
			<input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student->ID ); ?>" />
			<?php wp_nonce_field( self::SAVE_ACTION . '_' . $student->ID ); ?>
			<p><label for="tutorhelper-lms-exam-extra-time"><strong><?php esc_html_e( 'Exam Extra Time', 'tutorhelper-lms' ); ?></strong></label><br />
				<select id="tutorhelper-lms-exam-extra-time" name="exam_extra_time">
					<option value="0" <?php selected( $current, 0 ); ?>><?php esc_html_e( 'None', 'tutorhelper-lms' ); ?></option>
					<option value="25" <?php selected( $current, 25 ); ?>><?php esc_html_e( '25%', 'tutorhelper-lms' ); ?></option>
					<option value="50" <?php selected( $current, 50 ); ?>><?php esc_html_e( '50%', 'tutorhelper-lms' ); ?></option>
				</select>
			</p>
			<p><button type="submit" class="button tutorhelper-action-button"><?php esc_html_e( 'Save exam arrangement', 'tutorhelper-lms' ); ?></button></p>
		</form>
		<?php
	}

	/**
	 * Persist one safe tutor-selected access arrangement.
	 *
	 * @return void
	 */
	public static function save_exam_arrangement() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update this student.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$student_id = isset( $_POST['student_user_id'] ) && ! is_array( $_POST['student_user_id'] ) ? absint( wp_unslash( $_POST['student_user_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified below.
		check_admin_referer( self::SAVE_ACTION . '_' . $student_id );
		$value = isset( $_POST['exam_extra_time'] ) && ! is_array( $_POST['exam_extra_time'] ) ? absint( wp_unslash( $_POST['exam_extra_time'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above.
		$value = in_array( $value, array( 0, 25, 50 ), true ) ? $value : 0;
		if ( ! $student_id || ! TutorHelper_Students::get_student( $student_id ) ) {
			wp_die( esc_html__( 'This student is not available.', 'tutorhelper-lms' ), '', array( 'response' => 404 ) );
		}
		update_user_meta( $student_id, self::EXTRA_TIME_META, $value );
		wp_safe_redirect( add_query_arg( 'tutorhelper_lms_exam_extra_time_saved', '1', wp_get_referer() ? wp_get_referer() : admin_url() ) );
		exit;
	}

	/**
	 * Return an individual student's validated extra-time percentage.
	 *
	 * @param int $student_user_id Student ID.
	 * @return int
	 */
	private static function exam_extra_time_percentage( $student_user_id ) {
		$value = absint( get_user_meta( absint( $student_user_id ), self::EXTRA_TIME_META, true ) );
		return in_array( $value, array( 25, 50 ), true ) ? $value : 0;
	}

	/**
	 * Normalise mutable builder timing data.
	 *
	 * @param mixed $timing Timing data.
	 * @return array
	 */
	private static function normalise_timing( $timing ) {
		$timing = is_array( $timing ) ? $timing : array();
		$mode = 'timed' === sanitize_key( $timing['mode'] ?? '' ) ? 'timed' : 'untimed';
		$seconds = absint( $timing['duration_seconds'] ?? 0 );
		return array( 'mode' => $mode, 'duration_seconds' => 'timed' === $mode ? max( MINUTE_IN_SECONDS, $seconds ) : 0 );
	}

	/**
	 * Format seconds as a compact learner-friendly duration.
	 *
	 * @param int $seconds Seconds.
	 * @return string
	 */
	private static function duration_label( $seconds ) {
		$seconds = max( 0, absint( $seconds ) );
		$minutes = (int) floor( $seconds / 60 );
		$remainder = $seconds % 60;
		if ( $minutes > 0 && $remainder > 0 ) {
			return sprintf( __( '%1$dm %2$ds', 'tutorhelper-lms' ), $minutes, $remainder );
		}
		if ( $minutes > 0 ) {
			return sprintf( _n( '%d minute', '%d minutes', $minutes, 'tutorhelper-lms' ), $minutes );
		}
		return sprintf( _n( '%d second', '%d seconds', $seconds, 'tutorhelper-lms' ), $seconds );
	}
}
