<?php
/**
 * Premium individual Quiz homework delivery and completion tracking.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Connects one Course Quiz placement to one TutorHelper Pro homework record.
 *
 * A Quiz attempt remains a normal immutable LMS attempt. This class stores only
 * the first linked result for the Homework mark and records whether a later
 * attempt passed or a tutor explicitly accepted the work.
 */
final class TutorHelper_LMS_Quiz_Homework {

	const SOURCE_TYPE   = 'pro_homework';
	const ITEM_TYPE     = 'quiz';
	const QUERY_KEY     = 'tutorhelper_lms_homework_quiz';
	const ACCEPT_ACTION = 'tutorhelper_lms_accept_quiz_homework';

	/**
	 * Register Premium-only Homework Quiz integration.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'tutorhelper_pro_homework_resource_fields', array( __CLASS__, 'render_homework_field' ), 30 );
		add_filter( 'tutorhelper_pro_homework_has_pending_content', array( __CLASS__, 'has_pending_quiz' ), 30, 2 );
		add_filter( 'tutorhelper_pro_homework_has_content', array( __CLASS__, 'homework_has_quiz' ), 30, 2 );
		add_action( 'tutorhelper_pro_homework_submission_updated', array( __CLASS__, 'save_homework_quiz' ), 40 );
		add_action( 'tutorhelper_pro_homework_student_actions', array( __CLASS__, 'render_student_quiz' ), 40 );
		add_filter( 'tutorhelper_lms_homework_learning_delivery_payload', array( __CLASS__, 'add_selected_quiz_to_payload' ), 10, 3 );

		add_filter( 'tutorhelper_lms_quiz_player_context', array( __CLASS__, 'player_context' ), 10, 5 );
		add_filter( 'tutorhelper_lms_quiz_attempt_snapshot', array( __CLASS__, 'snapshot_context' ), 30, 3 );
		add_filter( 'tutorhelper_lms_quiz_url', array( __CLASS__, 'preserve_homework_url' ), 10, 5 );
		add_action( 'tutorhelper_lms_quiz_attempt_submitted', array( __CLASS__, 'record_submitted_attempt' ), 10, 2 );

		add_filter( 'tutorhelper_pro_homework_completed', array( __CLASS__, 'complete_passed_quiz_homework' ), 20, 3 );
		add_filter( 'tutorhelper_pro_homework_completion_managed', array( __CLASS__, 'manage_passed_quiz_homework' ), 20, 3 );
		add_action( 'tutorhelper_lms_submissions_table_rows', array( __CLASS__, 'render_tutor_submission_rows' ) );
		add_filter( 'tutorhelper_lms_tutor_quiz_submission_rows', array( __CLASS__, 'hide_first_homework_attempt_from_quiz_rows' ) );
		add_filter( 'tutorhelper_lms_has_custom_submission_rows', array( __CLASS__, 'has_tutor_submission_rows' ) );
		add_action( 'admin_post_' . self::ACCEPT_ACTION, array( __CLASS__, 'accept_homework' ) );
	}

	/**
	 * Render the one-Quiz choice in the existing TutorHelper Pro homework modal.
	 *
	 * @return void
	 */
	public static function render_homework_field() {
		$placements = self::tutor_quiz_placements( get_current_user_id() );
		?>
		<fieldset class="tutorhelper-pro-homework-resources" data-tutorhelper-lms-homework-quiz>
			<legend><?php esc_html_e( 'LMS Quiz', 'tutorhelper-lms' ); ?></legend>
			<p class="description"><?php esc_html_e( 'Optionally attach one Course Quiz. A linked Quiz replaces a file or link submission, is marked automatically, and completes this Homework when the student passes.', 'tutorhelper-lms' ); ?></p>
			<?php if ( empty( $placements ) ) : ?>
				<p class="description"><?php esc_html_e( 'No placed Course Quizzes are available yet. Add a Quiz to a Course in Learning Hub first.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<label for="tutorhelper-lms-homework-quiz"><strong><?php esc_html_e( 'Quiz to complete', 'tutorhelper-lms' ); ?></strong></label>
				<select id="tutorhelper-lms-homework-quiz" name="homework_quiz_placement_id" data-tutorhelper-lms-homework-quiz-select>
					<option value="0"><?php esc_html_e( 'No LMS Quiz attached', 'tutorhelper-lms' ); ?></option>
					<?php foreach ( $placements as $placement ) : ?>
						<option value="<?php echo esc_attr( $placement['id'] ); ?>" data-tutorhelper-lms-quiz-course="<?php echo esc_attr( $placement['course_id'] ); ?>"><?php echo esc_html( $placement['label'] ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description" data-tutorhelper-lms-homework-quiz-context><?php esc_html_e( 'Select a Course above to see its placed Quizzes.', 'tutorhelper-lms' ); ?></p>
				<p class="description" data-tutorhelper-lms-homework-quiz-notice hidden><?php esc_html_e( 'The Quiz is the student submission. Assessment is marked automatically; the maximum mark is recorded from the first Quiz attempt so Adaptive Practice remains accurate.', 'tutorhelper-lms' ); ?></p>
			<?php endif; ?>
		</fieldset>
		<?php
	}

	/**
	 * Keep a new Homework with a valid Quiz attachment.
	 *
	 * @param bool  $has_content Existing content decision.
	 * @param array $request Submitted homework request.
	 * @return bool
	 */
	public static function has_pending_quiz( $has_content, $request ) {
		if ( $has_content || ! is_array( $request ) ) {
			return (bool) $has_content;
		}
		return ! empty( $request['homework_quiz_placement_id'] ) && absint( $request['homework_quiz_placement_id'] ) > 0;
	}

	/**
	 * Treat an existing Quiz attachment as Homework content.
	 *
	 * @param bool   $has_content Existing content decision.
	 * @param object $homework Pro homework object.
	 * @return bool
	 */
	public static function homework_has_quiz( $has_content, $homework ) {
		return $has_content || ( $homework && ! empty( $homework->id ) && (bool) self::delivery_for_homework( absint( $homework->id ) ) );
	}

	/**
	 * Save one validated Quiz placement against the Homework source record.
	 *
	 * @param array $homework Sanitised Pro Homework payload.
	 * @return void
	 */
	public static function save_homework_quiz( $homework ) {
		if ( ! is_array( $homework ) || empty( $homework['source_id'] ) || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$source_id = absint( $homework['source_id'] );
		$requested = isset( $_POST['homework_quiz_placement_id'] ) && ! is_array( $_POST['homework_quiz_placement_id'] ) ? absint( wp_unslash( $_POST['homework_quiz_placement_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- TutorHelper Pro verifies its enclosing Homework request.
		$allowed   = array();
		foreach ( self::tutor_quiz_placements( get_current_user_id() ) as $placement ) {
			$allowed[ absint( $placement['id'] ) ] = $placement;
		}
		$selected = $allowed[ $requested ] ?? null;

		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'learning_delivery' );
		$wpdb->delete( $table, array( 'source_type' => self::SOURCE_TYPE, 'source_id' => $source_id, 'item_type' => self::ITEM_TYPE ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Replaces this Homework's single explicit Quiz attachment.
		if ( ! $selected ) {
			return;
		}
		$wpdb->insert(
			$table,
			array(
				'source_type'   => self::SOURCE_TYPE,
				'source_id'     => $source_id,
				'item_type'     => self::ITEM_TYPE,
				'item_id'       => absint( $selected['quiz_id'] ),
				'course_id'     => absint( $selected['course_id'] ),
				'topic_id'      => absint( $selected['topic_id'] ),
				'item_snapshot' => wp_json_encode( array( 'title' => $selected['title'], 'placement_id' => absint( $selected['id'] ) ) ),
				'created_at'    => current_time( 'mysql', true ),
			),
			array( '%s', '%d', '%s', '%d', '%d', '%d', '%s', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Stores one tutor-selected Quiz Homework association.
	}

	/**
	 * Render the student's Homework-specific Quiz link.
	 *
	 * @param object $homework Pro Homework object.
	 * @return void
	 */
	public static function render_student_quiz( $homework ) {
		if ( ! $homework || empty( $homework->id ) || ! is_user_logged_in() || ! class_exists( 'TutorHelper_LMS_Learner_Access' ) ) {
			return;
		}
		$delivery = self::student_delivery( absint( $homework->id ), get_current_user_id() );
		if ( ! $delivery ) {
			return;
		}
		$snapshot = self::delivery_snapshot( $delivery );
		$placement_id = absint( $snapshot['placement_id'] ?? 0 );
		if ( ! $placement_id ) {
			return;
		}
		$base_url = get_permalink();
		if ( class_exists( 'TutorHelper_Student_Account' ) ) {
			$base_url = add_query_arg( TutorHelper_Student_Account::TAB_QUERY, TutorHelper_LMS_Learner_Access::DASHBOARD_TAB, $base_url );
		}
		$url = add_query_arg( self::QUERY_KEY, absint( $homework->id ), TutorHelper_LMS_Learner_Access::quiz_url( $base_url, absint( $delivery->course_id ), $placement_id, get_current_user_id() ) );
		?>
		<div class="tutorhelper-lms-student-resources">
			<strong><?php esc_html_e( 'LMS Quiz to complete', 'tutorhelper-lms' ); ?></strong>
			<p><span><?php echo esc_html( $snapshot['title'] ?? __( 'Quiz', 'tutorhelper-lms' ) ); ?></span> <a class="tutorhelper-button" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Open Quiz', 'tutorhelper-lms' ); ?></a></p>
		</div>
		<?php
	}

	/**
	 * Add the saved Quiz placement to the established Homework-modal AJAX payload.
	 *
	 * @param array  $payload Existing Lesson payload.
	 * @param int    $source_id Homework source ID.
	 * @return array
	 */
	public static function add_selected_quiz_to_payload( $payload, $source_id ) {
		$delivery = self::delivery_for_homework( $source_id );
		$snapshot = self::delivery_snapshot( $delivery );
		$payload['quizPlacementId'] = absint( $snapshot['placement_id'] ?? 0 );
		return $payload;
	}

	/**
	 * Validate a Quiz Homework URL for its enrolled/assigned student.
	 *
	 * @param array  $context Existing player context.
	 * @param int    $student_id Student ID.
	 * @param int    $course_id Course ID.
	 * @param object $placement Course Quiz placement.
	 * @return array|WP_Error
	 */
	public static function player_context( $context, $student_id, $course_id, $placement, $base_url = '' ) {
		$source_id = self::requested_source_id();
		if ( ! $source_id ) {
			return $context;
		}
		$delivery = self::student_delivery( $source_id, $student_id );
		$snapshot = $delivery ? self::delivery_snapshot( $delivery ) : array();
		if ( ! $delivery || absint( $delivery->course_id ) !== absint( $course_id ) || absint( $snapshot['placement_id'] ?? 0 ) !== absint( $placement->id ) ) {
			return new WP_Error( 'quiz_homework_unavailable', __( 'This Homework Quiz is not available for your account.', 'tutorhelper-lms' ) );
		}
		return array( 'homework_source_id' => $source_id, 'delivery_id' => absint( $delivery->id ) );
	}

	/**
	 * Freeze trusted Homework context into a newly created attempt.
	 *
	 * @param array  $snapshot Attempt snapshot.
	 * @param object $placement Course Quiz placement.
	 * @param int    $student_id Student ID.
	 * @return array
	 */
	public static function snapshot_context( $snapshot, $placement, $student_id ) {
		$context = self::player_context( array(), $student_id, absint( $placement->course_id ), $placement );
		if ( is_wp_error( $context ) || empty( $context['homework_source_id'] ) ) {
			return $snapshot;
		}
		$snapshot['homework_quiz'] = array(
			'source_id'   => absint( $context['homework_source_id'] ),
			'delivery_id' => absint( $context['delivery_id'] ),
		);
		return $snapshot;
	}

	/**
	 * Retain the verified Homework source across Quiz internal links.
	 *
	 * @param string $url Quiz URL.
	 * @return string
	 */
	public static function preserve_homework_url( $url, $base_url = '', $course_id = 0, $placement_id = 0, $student_id = 0 ) {
		$source_id = self::requested_source_id();
		return $source_id ? add_query_arg( self::QUERY_KEY, $source_id, $url ) : $url;
	}

	/**
	 * Save the first completed linked attempt and update pass completion state.
	 *
	 * @param object $attempt Completed attempt as locked at submission.
	 * @param array  $summary Automatic marking summary.
	 * @return void
	 */
	public static function record_submitted_attempt( $attempt, $summary ) {
		if ( ! is_object( $attempt ) || ! is_array( $summary ) ) {
			return;
		}
		$snapshot = json_decode( (string) $attempt->snapshot_json, true );
		$context  = is_array( $snapshot['homework_quiz'] ?? null ) ? $snapshot['homework_quiz'] : array();
		$source_id = absint( $context['source_id'] ?? 0 );
		if ( ! $source_id ) {
			return;
		}
		$assignment = self::assignment_for_source( $source_id, absint( $attempt->student_user_id ) );
		if ( ! $assignment ) {
			return;
		}
		$passed = ! empty( $summary['passed'] );
		$now = current_time( 'mysql', true );
		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'homework_quiz_attempts' );
		$record = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE homework_source_id = %d AND student_user_id = %d LIMIT 1", $source_id, absint( $attempt->student_user_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finds the one durable Homework Quiz result.
		if ( ! $record ) {
			$wpdb->insert(
				$table,
				array(
					'homework_source_id' => $source_id,
					'assignment_id'      => absint( $assignment->id ),
					'student_user_id'    => absint( $attempt->student_user_id ),
					'placement_id'       => absint( $attempt->course_quiz_placement_id ),
					'first_attempt_id'   => absint( $attempt->id ),
					'completion_attempt_id' => $passed ? absint( $attempt->id ) : 0,
					'awarded_mark'       => absint( $summary['marks'] ?? 0 ),
					'max_mark'           => absint( $summary['available'] ?? 0 ),
					'completion_status'  => $passed ? 'passed' : 'submitted',
					'created_at'         => $now,
					'updated_at'         => $now,
				),
				array( '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%s', '%s', '%s' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Records only the Homework's first Quiz attempt.
			$wpdb->update( TutorHelper_LMS_Database::table( 'assignments' ), array( 'max_mark' => absint( $summary['available'] ?? 0 ), 'updated_at' => $now ), array( 'id' => absint( $assignment->id ) ), array( '%d', '%s' ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Pins the Homework maximum to the adaptive or fixed attempt snapshot.
			return;
		}
		if ( $passed && 'passed' !== (string) $record->completion_status && 'accepted' !== (string) $record->completion_status ) {
			$wpdb->update( $table, array( 'completion_status' => 'passed', 'completion_attempt_id' => absint( $attempt->id ), 'updated_at' => $now ), array( 'id' => absint( $record->id ) ), array( '%s', '%d', '%s' ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- A later pass completes but never overwrites the first Homework mark.
		}
	}

	/**
	 * Mark passed/accepted Quiz Homework as complete in TutorHelper Pro.
	 *
	 * @param bool   $completed Existing completion decision.
	 * @param int    $booking_id Booking ID.
	 * @param object $booking Booking object.
	 * @return bool
	 */
	public static function complete_passed_quiz_homework( $completed, $booking_id, $booking ) {
		return $completed || self::has_completed_result( $booking_id, $booking );
	}

	/**
	 * Stop a Pro completion checkbox undoing a completed Quiz Homework.
	 *
	 * @param bool   $managed Existing management decision.
	 * @param int    $booking_id Booking ID.
	 * @param object $booking Booking object.
	 * @return bool
	 */
	public static function manage_passed_quiz_homework( $managed, $booking_id, $booking ) {
		return $managed || self::has_completed_result( $booking_id, $booking );
	}

	/**
	 * Render first-attempt Homework results inside the shared tutor table.
	 *
	 * @return void
	 */
	public static function render_tutor_submission_rows() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		global $wpdb;
		$results = TutorHelper_LMS_Database::table( 'homework_quiz_attempts' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$attempts = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT r.*, a.title, a.booking_id, q.quiz_id, q.submitted_at, q.completed_at, q.time_taken_seconds FROM {$results} r INNER JOIN {$assignments} a ON a.id = r.assignment_id LEFT JOIN {$attempts} q ON q.id = r.first_attempt_id WHERE a.tutor_user_id = %d AND a.status != %s ORDER BY r.updated_at DESC", get_current_user_id(), 'archived' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Lists this tutor's Quiz Homework first-attempt records.
		foreach ( (array) $rows as $row ) :
			$status = sanitize_key( $row->completion_status );
			?>
			<tr data-tutorhelper-lms-submission-kind="homework" data-tutorhelper-lms-submission-status-key="<?php echo esc_attr( in_array( $status, array( 'passed', 'accepted' ), true ) ? 'marked' : 'submitted' ); ?>">
				<td><?php esc_html_e( 'Homework · Quiz', 'tutorhelper-lms' ); ?></td>
				<td><strong><?php echo esc_html( $row->title ); ?></strong><br /><small><?php echo esc_html( get_the_title( absint( $row->quiz_id ) ) ); ?></small></td>
				<td><?php echo esc_html( self::user_name( $row->student_user_id ) ); ?></td>
				<td><strong><?php echo esc_html( 'passed' === $status ? __( 'Completed — Quiz passed', 'tutorhelper-lms' ) : ( 'accepted' === $status ? __( 'Completed — tutor accepted', 'tutorhelper-lms' ) : __( 'Submitted — Quiz not yet passed', 'tutorhelper-lms' ) ) ); ?></strong></td>
				<td><?php echo esc_html( self::booking_date_label( $row->booking_id ) ); ?></td>
				<td><?php echo esc_html( self::submitted_date_label( $row->submitted_at ?: $row->completed_at ) ); ?></td>
				<td><?php echo esc_html( class_exists( 'TutorHelper_LMS_Quiz_Attempts' ) ? TutorHelper_LMS_Quiz_Attempts::time_taken_label( $row ) : '—' ); ?></td>
				<td><?php echo esc_html( $row->awarded_mark . ' / ' . $row->max_mark ); ?></td>
				<td><button type="button" class="button tutorhelper-action-button" data-tutorhelper-lms-review-quiz="<?php echo esc_attr( $row->first_attempt_id ); ?>"><?php esc_html_e( 'Open first attempt', 'tutorhelper-lms' ); ?></button><?php if ( ! in_array( $status, array( 'passed', 'accepted' ), true ) ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"><input type="hidden" name="action" value="<?php echo esc_attr( self::ACCEPT_ACTION ); ?>" /><input type="hidden" name="result_id" value="<?php echo esc_attr( $row->id ); ?>" /><?php wp_nonce_field( self::ACCEPT_ACTION . '_' . absint( $row->id ) ); ?><button type="submit" class="button"><?php esc_html_e( 'Accept as complete', 'tutorhelper-lms' ); ?></button></form><?php endif; ?></td>
			</tr>
		<?php endforeach;
	}

	/**
	 * Determine whether this tutor has dedicated Quiz Homework rows to render.
	 *
	 * @param bool $has_rows Existing decision.
	 * @return bool
	 */
	public static function has_tutor_submission_rows( $has_rows ) {
		if ( $has_rows || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return (bool) $has_rows;
		}
		global $wpdb;
		$found = $wpdb->get_var( $wpdb->prepare( "SELECT r.id FROM " . TutorHelper_LMS_Database::table( 'homework_quiz_attempts' ) . " r INNER JOIN " . TutorHelper_LMS_Database::table( 'assignments' ) . " a ON a.id = r.assignment_id WHERE a.tutor_user_id = %d AND a.status != %s LIMIT 1", get_current_user_id(), 'archived' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checks whether this tutor has one Quiz Homework result.
		return (bool) $found;
	}

	/**
	 * Keep the first linked attempt in its Homework row; later attempts remain
	 * visible as ordinary Quiz submissions beneath it.
	 *
	 * @param array $attempts Tutor-owned completed Quiz attempts.
	 * @return array
	 */
	public static function hide_first_homework_attempt_from_quiz_rows( $attempts ) {
		if ( empty( $attempts ) ) {
			return array();
		}
		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'homework_quiz_attempts' );
		$ids = array_map( 'absint', $wpdb->get_col( $wpdb->prepare( "SELECT r.first_attempt_id FROM {$table} r INNER JOIN " . TutorHelper_LMS_Database::table( 'assignments' ) . " a ON a.id = r.assignment_id WHERE a.tutor_user_id = %d", get_current_user_id() ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Keeps the first Homework attempt in its dedicated Homework row.
		return array_values( array_filter( (array) $attempts, static function( $attempt ) use ( $ids ) {
			return ! in_array( absint( $attempt->id ?? 0 ), $ids, true );
		} ) );
	}

	/**
	 * Tutor accepts a submitted failed Quiz attempt as complete.
	 *
	 * @return void
	 */
	public static function accept_homework() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update this Homework.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$result_id = isset( $_POST['result_id'] ) && ! is_array( $_POST['result_id'] ) ? absint( wp_unslash( $_POST['result_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified immediately below.
		check_admin_referer( self::ACCEPT_ACTION . '_' . $result_id );
		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'homework_quiz_attempts' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$updated = $wpdb->query( $wpdb->prepare( "UPDATE {$table} r INNER JOIN {$assignments} a ON a.id = r.assignment_id SET r.completion_status = %s, r.updated_at = %s WHERE r.id = %d AND a.tutor_user_id = %d", 'accepted', current_time( 'mysql', true ), $result_id, get_current_user_id() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Accepts one verified tutor-owned Quiz Homework result.
		$redirect = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=' . TutorHelper_LMS_Submissions::PAGE_SLUG );
		wp_safe_redirect( add_query_arg( 'tutorhelper_lms_quiz_homework_accepted', false === $updated ? '0' : '1', $redirect ) );
		exit;
	}

	/**
	 * Return a tutor-owned published Course Quiz placement option.
	 *
	 * @param int $tutor_id Tutor user ID.
	 * @return array
	 */
	private static function tutor_quiz_placements( $tutor_id ) {
		global $wpdb;
		$placements = TutorHelper_LMS_Free_Database::table( 'course_quiz_placements' );
		$posts = $wpdb->posts;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.id, p.course_id, p.topic_id, p.quiz_id, q.post_title AS quiz_title, c.post_title AS course_title, t.post_title AS topic_title FROM {$placements} p INNER JOIN {$posts} q ON q.ID = p.quiz_id INNER JOIN {$posts} c ON c.ID = p.course_id INNER JOIN {$posts} t ON t.ID = p.topic_id WHERE q.post_author = %d AND q.post_status = %s AND c.post_status = %s AND t.post_status = %s ORDER BY c.post_title ASC, t.post_title ASC, q.post_title ASC", absint( $tutor_id ), 'publish', 'publish', 'publish' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Lists only the current tutor's placed Quizzes.
		$result = array();
		foreach ( (array) $rows as $row ) {
			$result[] = array( 'id' => absint( $row->id ), 'course_id' => absint( $row->course_id ), 'topic_id' => absint( $row->topic_id ), 'quiz_id' => absint( $row->quiz_id ), 'title' => sanitize_text_field( $row->quiz_title ), 'label' => sprintf( '%1$s › %2$s › %3$s', $row->course_title, $row->topic_title, $row->quiz_title ) );
		}
		return $result;
	}

	/**
	 * Read one student-authorised delivery association.
	 *
	 * @param int $source_id Homework source ID.
	 * @param int $student_id Student ID.
	 * @return object|null
	 */
	private static function student_delivery( $source_id, $student_id ) {
		global $wpdb;
		$delivery = TutorHelper_LMS_Database::table( 'learning_delivery' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT d.* FROM {$delivery} d INNER JOIN {$assignments} a ON a.source_type = d.source_type AND a.source_id = d.source_id WHERE d.source_type = %s AND d.source_id = %d AND d.item_type = %s AND a.student_user_id = %d AND a.status != %s LIMIT 1", self::SOURCE_TYPE, absint( $source_id ), self::ITEM_TYPE, absint( $student_id ), 'archived' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorises a student's explicit Quiz Homework.
	}

	/**
	 * Read the durable assignment behind a Pro Homework source.
	 *
	 * @param int $source_id Homework source ID.
	 * @param int $student_id Student ID.
	 * @return object|null
	 */
	private static function assignment_for_source( $source_id, $student_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'assignments' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE source_type = %s AND source_id = %d AND student_user_id = %d AND status != %s LIMIT 1", self::SOURCE_TYPE, absint( $source_id ), absint( $student_id ), 'archived' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Owns the durable Homework context.
	}

	/** Return the selected Quiz delivery row for a Homework source. */
	private static function delivery_for_homework( $source_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'learning_delivery' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE source_type = %s AND source_id = %d AND item_type = %s LIMIT 1", self::SOURCE_TYPE, absint( $source_id ), self::ITEM_TYPE ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads one Homework Quiz association.
	}

	/** Decode one durable delivery title/placement snapshot. */
	private static function delivery_snapshot( $delivery ) {
		$snapshot = $delivery && ! empty( $delivery->item_snapshot ) ? json_decode( $delivery->item_snapshot, true ) : array();
		return is_array( $snapshot ) ? $snapshot : array();
	}

	/** Read the requested Homework source identifier. */
	private static function requested_source_id() {
		return isset( $_REQUEST[ self::QUERY_KEY ] ) && ! is_array( $_REQUEST[ self::QUERY_KEY ] ) ? absint( wp_unslash( $_REQUEST[ self::QUERY_KEY ] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Validated against the current student before use.
	}

	/** Check whether a booking's student has a passed or accepted Quiz Homework. */
	private static function has_completed_result( $booking_id, $booking ) {
		if ( ! $booking || empty( $booking->student_user_id ) ) {
			return false;
		}
		global $wpdb;
		$results = TutorHelper_LMS_Database::table( 'homework_quiz_attempts' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$found = $wpdb->get_var( $wpdb->prepare( "SELECT r.id FROM {$results} r INNER JOIN {$assignments} a ON a.id = r.assignment_id WHERE a.booking_id = %d AND a.student_user_id = %d AND r.completion_status IN (%s, %s) LIMIT 1", absint( $booking_id ), absint( $booking->student_user_id ), 'passed', 'accepted' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checks one student's completed Quiz Homework state.
		return (bool) $found;
	}

	/** Small compatibility helpers shared with the existing submissions table. */
	private static function user_name( $user_id ) {
		$user = get_userdata( absint( $user_id ) );
		return $user ? ( $user->display_name ? $user->display_name : $user->user_login ) : __( 'Student', 'tutorhelper-lms' );
	}

	private static function booking_date_label( $booking_id ) {
		return class_exists( 'TutorHelper_Pro_Lesson_Follow_Up' ) && method_exists( 'TutorHelper_Pro_Lesson_Follow_Up', 'booking_date_label' ) ? TutorHelper_Pro_Lesson_Follow_Up::booking_date_label( $booking_id ) : '—';
	}

	private static function submitted_date_label( $date ) {
		return $date ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $date ) ) : '—';
	}
}
