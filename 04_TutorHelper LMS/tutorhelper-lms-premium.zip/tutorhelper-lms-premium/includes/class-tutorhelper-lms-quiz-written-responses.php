<?php
/**
 * Premium manually marked Quiz response types.
 *
 * Core provides neutral extension hooks; this class owns Premium written/file
 * models and their private attachment storage.
 *
 * @package TutorHelper_LMS
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_LMS_Quiz_Written_Responses {

	const LONG_ANSWER = 'long_answer';
	const FILE_UPLOAD = 'file_upload';
	const STUDENT_FILE_ACTION = 'tutorhelper_lms_download_own_quiz_response_file';

	public static function init() {
		add_filter( 'tutorhelper_lms_question_types', array( __CLASS__, 'question_types' ) );
		add_filter( 'tutorhelper_lms_manual_question_types', array( __CLASS__, 'manual_question_types' ) );
		add_action( 'tutorhelper_lms_question_answer_editor', array( __CLASS__, 'render_answer_editor' ), 10, 2 );
		add_filter( 'tutorhelper_lms_question_posted_configuration', array( __CLASS__, 'posted_configuration' ), 10, 2 );
		add_filter( 'tutorhelper_lms_quiz_question_response_html', array( __CLASS__, 'render_student_response' ), 10, 6 );
		add_filter( 'tutorhelper_lms_quiz_read_only_response_html', array( __CLASS__, 'render_read_only_response' ), 10, 8 );
		add_filter( 'tutorhelper_lms_quiz_player_posted_responses', array( __CLASS__, 'attach_uploaded_responses' ), 10, 3 );
		add_filter( 'tutorhelper_lms_sanitise_quiz_response', array( __CLASS__, 'sanitise_response' ), 10, 4 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_editor_assets' ) );
		add_action( 'admin_post_' . self::STUDENT_FILE_ACTION, array( __CLASS__, 'download_student_file' ) );
	}

	/**
	 * Make the restricted long-answer editor available when learner content is
	 * rendered after the page head.
	 *
	 * @return void
	 */
	public static function enqueue_editor_assets() {
		if ( is_user_logged_in() && function_exists( 'wp_enqueue_editor' ) ) {
			wp_enqueue_editor();
		}
	}

	public static function question_types( $types ) {
		$types = is_array( $types ) ? $types : array();
		$types[ self::LONG_ANSWER ] = __( 'Essay / Long Answer', 'tutorhelper-lms' );
		$types[ self::FILE_UPLOAD ] = __( 'File Upload', 'tutorhelper-lms' );
		return $types;
	}

	public static function manual_question_types( $types ) {
		$types   = is_array( $types ) ? $types : array();
		$types[] = self::LONG_ANSWER;
		$types[] = self::FILE_UPLOAD;
		return array_values( array_unique( array_map( 'sanitize_key', $types ) ) );
	}

	/**
	 * Always render both panels so the Core type selector can reveal the
	 * applicable configuration when a new Question changes from its default.
	 *
	 * @param string $type Current Question type.
	 * @param array  $definition Current definition.
	 * @return void
	 */
	public static function render_answer_editor( $type, $definition ) {
		$settings = is_array( $definition['settings'] ?? null ) ? $definition['settings'] : array();
		?>
		<div class="tutorhelper-lms-answer-panel" data-question-type="<?php echo esc_attr( self::LONG_ANSWER ); ?>">
			<p><strong><?php esc_html_e( 'Tutor marking required', 'tutorhelper-lms' ); ?></strong></p>
			<p class="description"><?php esc_html_e( 'Students enter a written response. Set the maximum marks available above.', 'tutorhelper-lms' ); ?></p>
			<label><input type="checkbox" name="allow_file_upload" value="1" <?php checked( ! empty( $settings['allow_file_upload'] ) ); ?> /> <?php esc_html_e( 'Also allow one private file upload with this essay response', 'tutorhelper-lms' ); ?></label>
			<p class="description"><?php esc_html_e( 'The student may submit text, a file, or both. Files are private and marked by the tutor.', 'tutorhelper-lms' ); ?></p>
		</div>
		<div class="tutorhelper-lms-answer-panel" data-question-type="<?php echo esc_attr( self::FILE_UPLOAD ); ?>">
			<p><strong><?php esc_html_e( 'Tutor marking required', 'tutorhelper-lms' ); ?></strong></p>
			<p class="description"><?php esc_html_e( 'Students upload one private PDF, DOCX, JPG or PNG file. This Question does not include a written response field.', 'tutorhelper-lms' ); ?></p>
		</div>
		<div class="tutorhelper-lms-answer-panel" data-question-type="<?php echo esc_attr( self::LONG_ANSWER . ' ' . self::FILE_UPLOAD ); ?>">
			<label for="tutorhelper-lms-question-marking-guidance"><strong><?php esc_html_e( 'Marking guidance (tutor only)', 'tutorhelper-lms' ); ?></strong></label>
			<?php
			wp_editor(
				(string) ( $settings['marking_guidance'] ?? '' ),
				'tutorhelper-lms-question-marking-guidance',
				array(
					'textarea_name' => 'marking_guidance',
					'textarea_rows' => 7,
					'media_buttons' => false,
					'teeny'         => false,
				)
			);
			?>
			<p class="description"><?php esc_html_e( 'This is never shown to students. Tutors can open it beneath the submitted response while marking.', 'tutorhelper-lms' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Persist only the attachment permission for Premium long-answer Questions.
	 *
	 * @param array|null $configuration Existing extension configuration.
	 * @param string     $type          Selected Question type.
	 * @return array|null
	 */
	public static function posted_configuration( $configuration, $type ) {
		$guidance = isset( $_POST['marking_guidance'] ) && ! is_array( $_POST['marking_guidance'] ) ? wp_kses_post( wp_unslash( $_POST['marking_guidance'] ) ) : '';
		if ( self::LONG_ANSWER === $type ) {
			return array( 'answers' => array(), 'settings' => array( 'allow_file_upload' => ! empty( $_POST['allow_file_upload'] ), 'marking_guidance' => $guidance ) );
		}
		if ( self::FILE_UPLOAD === $type ) {
			return array( 'answers' => array(), 'settings' => array( 'marking_guidance' => $guidance ) );
		}
		return $configuration;
	}

	/**
	 * Render student controls. Long-answer Questions may have an additional
	 * optional file field; file-only Questions retain no text control.
	 *
	 * @param string $html Existing extension markup.
	 * @param int    $attempt_id Attempt ID.
	 * @param int    $question_id Question ID.
	 * @param array  $definition Pinned definition.
	 * @param string $type Question type.
	 * @param mixed  $answer Draft answer.
	 * @return string
	 */
	public static function render_student_response( $html, $attempt_id, $question_id, $definition, $type, $answer ) {
		if ( self::LONG_ANSWER === $type ) {
			$output = self::written_editor( $question_id, self::written_text( $answer ) );
			$output .= '<p class="description">' . esc_html__( 'Use the formatting controls for bold, italic, underline and bullet lists. Your response will be marked by your tutor.', 'tutorhelper-lms' ) . '</p>';
			if ( self::allows_attachment( $definition ) ) {
				$output .= self::file_field( $question_id, self::attachment_from_response( $answer ) );
			}
			return $output;
		}
		if ( self::FILE_UPLOAD === $type ) {
			return self::file_field( $question_id, self::attachment_from_response( $answer ) );
		}
		return $html;
	}

	/**
	 * Render a safe submitted representation. Q5b will add tutor-authorised
	 * download/preview and manual marking controls.
	 *
	 * @param string $html Existing extension markup.
	 * @param array  $definition Pinned definition.
	 * @param string $type Question type.
	 * @param mixed  $answer Stored answer.
	 * @param string $status Mark status.
	 * @param array  $mark Mark data.
	 * @param int    $question_id Question ID.
	 * @return string
	 */
	public static function render_read_only_response( $html, $definition, $type, $answer, $status, $mark, $question_id, $attempt = null ) {
		if ( self::LONG_ANSWER === $type ) {
			$output = '<div class="tutorhelper-lms-quiz__review-answer tutorhelper-lms-quiz__review-answer--formatted is-ungraded">' . wpautop( self::sanitise_formatted_text( self::written_text( $answer ) ) ) . '</div>';
			$attachment = self::attachment_from_response( $answer );
			return $attachment ? $output . self::attachment_summary( $attachment, $attempt, $question_id ) : $output;
		}
		if ( self::FILE_UPLOAD !== $type ) {
			return $html;
		}
		$attachment = self::attachment_from_response( $answer );
		return $attachment ? self::attachment_summary( $attachment, $attempt, $question_id ) : '<div class="tutorhelper-lms-quiz__review-answer is-ungraded">' . esc_html__( 'No file was attached.', 'tutorhelper-lms' ) . '</div>';
	}

	/**
	 * Store posted attachments using the configured private provider and
	 * preserve one previously saved attachment through delivery-page changes.
	 *
	 * @param array  $responses Posted responses.
	 * @param object $attempt Student-owned attempt.
	 * @param array  $visible_question_ids Current page Questions.
	 * @return array|WP_Error
	 */
	public static function attach_uploaded_responses( $responses, $attempt, $visible_question_ids ) {
		if ( ! is_array( $responses ) || ! is_object( $attempt ) ) {
			return $responses;
		}
		$snapshot = json_decode( (string) ( $attempt->snapshot_json ?? '' ), true );
		$questions = is_array( $snapshot['questions'] ?? null ) ? $snapshot['questions'] : array();
		$visible = array_values( array_unique( array_filter( array_map( 'absint', (array) $visible_question_ids ) ) ) );
		$existing = TutorHelper_LMS_Quiz_Attempts::draft_responses( absint( $attempt->id ) );

		foreach ( $questions as $question ) {
			$question_id = absint( $question['question_id'] ?? 0 );
			if ( ! $question_id || ( ! empty( $visible ) && ! in_array( $question_id, $visible, true ) ) ) {
				continue;
			}
			$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
			$definition = is_array( $definition ) ? $definition : array();
			$type = sanitize_key( $definition['question_type'] ?? '' );
			if ( ! in_array( $type, array( self::LONG_ANSWER, self::FILE_UPLOAD ), true ) ) {
				continue;
			}

			$existing_response = $existing[ $question_id ] ?? '';
			if ( self::LONG_ANSWER === $type ) {
				$response = array( 'kind' => 'written_response', 'text' => self::written_text( $responses[ $question_id ] ?? '' ) );
				if ( self::allows_attachment( $definition ) ) {
					$attachment = self::posted_or_existing_attachment( $question_id, $existing_response, $attempt->student_user_id );
					if ( is_wp_error( $attachment ) ) {
						return $attachment;
					}
					if ( $attachment ) {
						$response['attachment'] = $attachment;
					}
				}
				$responses[ $question_id ] = $response;
				continue;
			}

			$attachment = self::posted_or_existing_attachment( $question_id, $existing_response, $attempt->student_user_id );
			if ( is_wp_error( $attachment ) ) {
				return $attachment;
			}
			if ( $attachment ) {
				$responses[ $question_id ] = $attachment;
			} elseif ( ! array_key_exists( $question_id, $responses ) ) {
				$responses[ $question_id ] = '';
			}
		}
		return $responses;
	}

	/**
	 * Preserve the deliberately small rich-text subset for long answers only.
	 *
	 * @param mixed  $sanitised_response Existing extension response.
	 * @param mixed  $response           Posted response.
	 * @param array  $question           Pinned Question snapshot.
	 * @param object $attempt            Owned attempt.
	 * @return mixed
	 */
	public static function sanitise_response( $sanitised_response, $response, $question, $attempt ) {
		$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
		$type = sanitize_key( is_array( $definition ) ? ( $definition['question_type'] ?? '' ) : '' );
		if ( self::LONG_ANSWER !== $type ) {
			return $sanitised_response;
		}
		$text = self::sanitise_formatted_text( self::written_text( $response ) );
		$attachment = self::attachment_from_response( $response );
		if ( '' === trim( wp_strip_all_tags( $text ) ) && ! $attachment ) {
			return '';
		}
		$clean = array( 'kind' => 'written_response', 'text' => $text );
		if ( $attachment ) {
			$clean['attachment'] = $attachment;
		}
		return $clean;
	}

	private static function posted_or_existing_attachment( $question_id, $existing_response, $student_user_id ) {
		$upload = self::posted_file( $question_id );
		if ( is_wp_error( $upload ) || null === $upload ) {
			return is_wp_error( $upload ) ? $upload : self::attachment_from_response( $existing_response );
		}
		return self::store_uploaded_file( $upload, absint( $student_user_id ) );
	}

	private static function posted_file( $question_id ) {
		$files = isset( $_FILES['quiz_file'] ) && is_array( $_FILES['quiz_file'] ) ? $_FILES['quiz_file'] : array();
		$error = isset( $files['error'][ $question_id ] ) ? absint( $files['error'][ $question_id ] ) : UPLOAD_ERR_NO_FILE;
		if ( UPLOAD_ERR_NO_FILE === $error ) {
			return null;
		}
		if ( UPLOAD_ERR_OK !== $error ) {
			return new WP_Error( 'quiz_file_upload_failed', __( 'Your file could not be uploaded. Please choose it again and retry.', 'tutorhelper-lms' ) );
		}
		$upload = array(
			'name'     => isset( $files['name'][ $question_id ] ) ? (string) $files['name'][ $question_id ] : '',
			'type'     => isset( $files['type'][ $question_id ] ) ? (string) $files['type'][ $question_id ] : '',
			'tmp_name' => isset( $files['tmp_name'][ $question_id ] ) ? (string) $files['tmp_name'][ $question_id ] : '',
			'error'    => $error,
			'size'     => isset( $files['size'][ $question_id ] ) ? absint( $files['size'][ $question_id ] ) : 0,
		);
		return is_uploaded_file( $upload['tmp_name'] ) ? $upload : new WP_Error( 'quiz_file_upload_invalid', __( 'Your file could not be accepted. Please choose it again and retry.', 'tutorhelper-lms' ) );
	}

	private static function store_uploaded_file( $upload, $student_user_id ) {
		if ( (int) $upload['size'] < 1 || (int) $upload['size'] > TutorHelper_LMS_Private_Storage::effective_upload_limit() ) {
			return new WP_Error( 'quiz_file_upload_size', __( 'This file exceeds the configured upload limit.', 'tutorhelper-lms' ) );
		}
		$allowed = array( 'pdf' => 'application/pdf', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png' );
		$check = wp_check_filetype_and_ext( $upload['tmp_name'], sanitize_file_name( $upload['name'] ), $allowed );
		if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
			return new WP_Error( 'quiz_file_upload_type', __( 'Use a PDF, DOCX, JPG or PNG file.', 'tutorhelper-lms' ) );
		}
		$provider = self::preferred_provider();
		if ( ! $provider ) {
			return new WP_Error( 'quiz_file_upload_storage', __( 'Private file uploads are not currently available. Please ask your tutor for guidance.', 'tutorhelper-lms' ) );
		}
		$file_hash = (string) hash_file( 'sha256', $upload['tmp_name'] );
		$stored = $provider->store( $upload, array( 'student_user_id' => $student_user_id, 'purpose' => 'quiz_response' ) );
		if ( is_wp_error( $stored ) ) {
			return new WP_Error( 'quiz_file_upload_store', __( 'Your file could not be stored privately. Please try again.', 'tutorhelper-lms' ) );
		}
		return array(
			'kind'             => 'private_file',
			'provider'         => sanitize_key( $provider->get_id() ),
			'provider_file_id' => sanitize_text_field( $stored['provider_file_id'] ?? '' ),
			'storage_key'      => sanitize_text_field( $stored['storage_key'] ?? '' ),
			'filename'         => sanitize_file_name( $upload['name'] ),
			'mime_type'        => sanitize_mime_type( $check['type'] ),
			'file_size'        => absint( $upload['size'] ),
			'file_hash'        => $file_hash,
		);
	}

	/**
	 * Render a tightly scoped visual editor for a student long answer.
	 *
	 * @param int    $question_id Question ID.
	 * @param string $content     Saved editor HTML.
	 * @return string
	 */
	private static function written_editor( $question_id, $content ) {
		$editor_id = 'tutorhelper-lms-quiz-response-' . absint( $question_id );
		if ( function_exists( 'wp_enqueue_editor' ) ) {
			wp_enqueue_editor();
		}
		if ( ! function_exists( 'wp_editor' ) ) {
			return '<textarea id="' . esc_attr( $editor_id ) . '" name="response[' . esc_attr( $question_id ) . '][text]" rows="8">' . esc_textarea( $content ) . '</textarea>';
		}
		ob_start();
		wp_editor(
			$content,
			$editor_id,
			array(
				'textarea_name' => 'response[' . absint( $question_id ) . '][text]',
				'textarea_rows' => 8,
				'media_buttons' => false,
				'teeny'         => true,
				'quicktags'     => false,
				'tinymce'       => array(
					'toolbar1' => 'bold,italic,underline,bullist',
					'toolbar2' => '',
					'menubar'  => false,
					'statusbar' => false,
				),
			)
		);
		return (string) ob_get_clean();
	}

	private static function sanitise_formatted_text( $text ) {
		$allowed = array(
			'p'      => array(),
			'br'     => array(),
			'strong' => array(),
			'b'      => array(),
			'em'     => array(),
			'i'      => array(),
			'u'      => array(),
			'ul'     => array(),
			'ol'     => array(),
			'li'     => array(),
			'span'   => array( 'style' => true ),
		);
		return wp_kses( wp_unslash( (string) $text ), $allowed );
	}

	private static function file_field( $question_id, $attachment ) {
		if ( ! self::preferred_provider() ) {
			return '<p class="tutorhelper-lms-quiz__marking-notice">' . esc_html__( 'Private file submission is not currently available. Please contact your tutor.', 'tutorhelper-lms' ) . '</p>';
		}
		$output = '<label for="' . esc_attr( 'tutorhelper-lms-quiz-file-' . $question_id ) . '"><strong>' . esc_html__( 'Upload a file', 'tutorhelper-lms' ) . '</strong></label><br />';
		$output .= '<input id="' . esc_attr( 'tutorhelper-lms-quiz-file-' . $question_id ) . '" name="quiz_file[' . esc_attr( $question_id ) . ']" type="file" accept=".pdf,.docx,.jpg,.jpeg,.png,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/jpeg,image/png" />';
		$output .= '<p class="description">' . esc_html( self::file_guidance() ) . '</p>';
		return $attachment ? $output . '<p class="tutorhelper-lms-quiz__uploaded-file"><span class="dashicons dashicons-paperclip" aria-hidden="true"></span> ' . esc_html( sprintf( __( 'Saved attachment: %s', 'tutorhelper-lms' ), $attachment['filename'] ) ) . '</p>' : $output;
	}

	/**
	 * Render a private attachment in the learner's released Quiz feedback.
	 *
	 * Tutors retain their existing review view; only the attempt owner sees the
	 * completed-review wording and a time-limited, authenticated file endpoint.
	 *
	 * @param array       $attachment Normalised private attachment details.
	 * @param object|null $attempt    Current immutable Quiz attempt.
	 * @param int         $question_id Question ID.
	 * @return string
	 */
	private static function attachment_summary( $attachment, $attempt = null, $question_id = 0 ) {
		$is_student_review = is_object( $attempt )
			&& absint( $attempt->student_user_id ?? 0 ) === get_current_user_id()
			&& TutorHelper_LMS_Quiz_Attempts::results_released( $attempt );
		$output = '<div class="tutorhelper-lms-quiz__review-answer tutorhelper-lms-quiz__submitted-attachment is-ungraded"><span class="dashicons dashicons-paperclip" aria-hidden="true"></span> ' . esc_html( $attachment['filename'] );
		if ( ! $is_student_review ) {
			return $output . '<p>' . esc_html__( 'Your tutor will review this private attachment.', 'tutorhelper-lms' ) . '</p></div>';
		}
		$output .= '<p>' . esc_html__( 'Your tutor has reviewed this private attachment.', 'tutorhelper-lms' ) . '</p>';
		if ( self::is_displayable_image( $attachment ) ) {
			$image = '<img class="tutorhelper-lms-quiz__submitted-image" src="' . esc_url( self::student_file_url( $attempt, $question_id, true ) ) . '" alt="' . esc_attr( sprintf( __( 'Your uploaded file: %s', 'tutorhelper-lms' ), $attachment['filename'] ) ) . '" />';
			$output .= apply_filters( 'tutorhelper_lms_quiz_response_attachment_display', $image, $attempt, $question_id, $attachment );
		} else {
			$output .= '<p><a class="tutorhelper-lms-quiz__download-file" href="' . esc_url( self::student_file_url( $attempt, $question_id, false ) ) . '">' . esc_html__( 'Download your uploaded file', 'tutorhelper-lms' ) . '</a></p>';
		}
		return $output . '</div>';
	}

	private static function is_displayable_image( $attachment ) {
		return in_array( sanitize_mime_type( $attachment['mime_type'] ?? '' ), array( 'image/jpeg', 'image/png' ), true );
	}

	private static function student_file_url( $attempt, $question_id, $inline ) {
		$args = array(
			'action'       => self::STUDENT_FILE_ACTION,
			'attempt_id'   => absint( $attempt->id ?? 0 ),
			'placement_id' => absint( $attempt->course_quiz_placement_id ?? 0 ),
			'question_id'  => absint( $question_id ),
			'inline'       => $inline ? '1' : '0',
		);
		$url = add_query_arg( $args, admin_url( 'admin-post.php' ) );
		return wp_nonce_url( $url, self::STUDENT_FILE_ACTION . '_' . absint( $attempt->id ?? 0 ) . '_' . absint( $question_id ) );
	}

	/**
	 * Stream one private response file to its student owner after result release.
	 *
	 * @return void
	 */
	public static function download_student_file() {
		if ( ! is_user_logged_in() ) {
			wp_die( esc_html__( 'You must be logged in to access this file.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$attempt_id = isset( $_GET['attempt_id'] ) ? absint( $_GET['attempt_id'] ) : 0;
		$placement_id = isset( $_GET['placement_id'] ) ? absint( $_GET['placement_id'] ) : 0;
		$question_id = isset( $_GET['question_id'] ) ? absint( $_GET['question_id'] ) : 0;
		check_admin_referer( self::STUDENT_FILE_ACTION . '_' . $attempt_id . '_' . $question_id );
		$attempt = TutorHelper_LMS_Quiz_Attempts::attempt_for_student( $attempt_id, get_current_user_id(), $placement_id );
		if ( ! $attempt || ! TutorHelper_LMS_Quiz_Attempts::results_released( $attempt ) ) {
			wp_die( esc_html__( 'This file is not available.', 'tutorhelper-lms' ), '', array( 'response' => 404 ) );
		}
		$review = TutorHelper_LMS_Quiz_Attempts::reviewed_responses( $attempt_id );
		$attachment = self::attachment_from_response( $review[ $question_id ]['answer'] ?? '' );
		if ( ! $attachment ) {
			wp_die( esc_html__( 'This file is not available.', 'tutorhelper-lms' ), '', array( 'response' => 404 ) );
		}
		$provider = TutorHelper_LMS_Storage_Registry::get( $attachment['provider'] );
		if ( ! $provider ) {
			wp_die( esc_html__( 'The storage provider for this file is unavailable.', 'tutorhelper-lms' ), '', array( 'response' => 503 ) );
		}
		$inline = ! empty( $_GET['inline'] ) && self::is_displayable_image( $attachment );
		$result = $provider->stream( $attachment['provider_file_id'], array(
			'filename' => $attachment['filename'],
			'mime_type' => $attachment['mime_type'],
			'disposition' => $inline ? 'inline' : 'attachment',
		) );
		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 503 ) );
		}
		exit;
	}

	private static function allows_attachment( $definition ) {
		return ! empty( $definition['settings']['allow_file_upload'] );
	}

	private static function written_text( $answer ) {
		if ( is_array( $answer ) && array_key_exists( 'text', $answer ) ) {
			return (string) $answer['text'];
		}
		return is_scalar( $answer ) ? (string) $answer : '';
	}

	private static function attachment_from_response( $response ) {
		$attachment = is_array( $response ) && isset( $response['attachment'] ) ? $response['attachment'] : $response;
		if ( ! is_array( $attachment ) || 'private_file' !== (string) ( $attachment['kind'] ?? '' ) || '' === trim( (string) ( $attachment['filename'] ?? '' ) ) ) {
			return array();
		}
		return array(
			'kind'             => 'private_file',
			'provider'         => sanitize_key( $attachment['provider'] ?? '' ),
			'provider_file_id' => sanitize_text_field( $attachment['provider_file_id'] ?? '' ),
			'storage_key'      => sanitize_text_field( $attachment['storage_key'] ?? '' ),
			'filename'         => sanitize_file_name( $attachment['filename'] ),
			'mime_type'        => sanitize_mime_type( $attachment['mime_type'] ?? '' ),
			'file_size'        => absint( $attachment['file_size'] ?? 0 ),
			'file_hash'        => sanitize_text_field( $attachment['file_hash'] ?? '' ),
		);
	}

	private static function preferred_provider() {
		$providers = TutorHelper_LMS_Storage_Registry::providers();
		$mode = TutorHelper_LMS_Private_Storage::mode();
		$id = TutorHelper_LMS_Private_Storage::MODE_GOOGLE === $mode ? 'google_drive' : ( TutorHelper_LMS_Private_Storage::MODE_LOCAL === $mode ? 'protected_wordpress' : '' );
		return $id && isset( $providers[ $id ] ) && $providers[ $id ]->is_available() ? $providers[ $id ] : null;
	}

	private static function file_guidance() {
		$limit_mb = number_format_i18n( TutorHelper_LMS_Private_Storage::effective_upload_limit() / MB_IN_BYTES, 0 );
		return sprintf( __( 'Choose a PDF, DOCX, JPG or PNG file up to %s MB. Your tutor will mark it privately.', 'tutorhelper-lms' ), $limit_mb );
	}
}
