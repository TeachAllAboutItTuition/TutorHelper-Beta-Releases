<?php
/**
 * Pro-homework assignment synchronisation and secure student submissions.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Submissions {

	const SOURCE_TYPE     = 'pro_homework';
	const SAVE_ACTION     = 'tutorhelper_lms_save_assignment';
	const DOWNLOAD_ACTION = 'tutorhelper_lms_download_submission';
	const PREVIEW_ACTION  = 'tutorhelper_lms_preview_submission';
	const REOPEN_ACTION   = 'tutorhelper_lms_reopen_submission';
	const MARK_LOAD_ACTION = 'tutorhelper_lms_load_marking';
	const MARK_SAVE_ACTION = 'tutorhelper_lms_save_marking';
	const QUIZ_REVIEW_LOAD_ACTION = 'tutorhelper_lms_load_quiz_review';
	const QUIZ_REVIEW_ACTION = 'tutorhelper_lms_review_quiz_attempt';
	const QUIZ_FILE_DOWNLOAD_ACTION = 'tutorhelper_lms_download_quiz_response_file';
	const QUIZ_FILE_PREVIEW_ACTION  = 'tutorhelper_lms_preview_quiz_response_file';
	const PAGE_SLUG       = 'tutorhelper-lms-submissions';

	/** @var int Per-request counter preventing duplicate modal IDs across dashboard views. */
	private static $student_submission_modal_instance = 0;

	/**
	 * Register Premium submission functionality.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'tutorhelper_pro_homework_submission_updated', array( __CLASS__, 'sync_assignment' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_student_assets' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_tutor_assets' ) );
		add_action( 'tutorhelper_pro_homework_student_actions', array( __CLASS__, 'render_student_submission_trigger' ) );
		add_action( 'tutorhelper_pro_student_lesson_follow_up_after_homework', array( __CLASS__, 'render_released_student_lesson_feedback' ), 10, 3 );
		add_filter( 'tutorhelper_pro_due_homework_item', array( __CLASS__, 'add_due_submission_details' ), 10, 2 );
		add_filter( 'tutorhelper_pro_student_lesson_follow_up_display', array( __CLASS__, 'filter_marked_student_follow_up_display' ), 10, 3 );
		add_filter( 'tutorhelper_pro_homework_completed', array( __CLASS__, 'complete_marked_pro_homework' ), 10, 3 );
		add_filter( 'tutorhelper_pro_homework_completion_managed', array( __CLASS__, 'manage_marked_pro_homework_completion' ), 10, 3 );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save' ) );
		add_action( 'admin_post_' . self::DOWNLOAD_ACTION, array( __CLASS__, 'download' ) );
		add_action( 'admin_post_' . self::PREVIEW_ACTION, array( __CLASS__, 'preview' ) );
		add_action( 'admin_post_' . self::REOPEN_ACTION, array( __CLASS__, 'reopen' ) );
		add_action( 'wp_ajax_' . self::MARK_LOAD_ACTION, array( __CLASS__, 'ajax_load_marking' ) );
		add_action( 'wp_ajax_' . self::MARK_SAVE_ACTION, array( __CLASS__, 'ajax_save_marking' ) );
		add_action( 'wp_ajax_' . self::QUIZ_REVIEW_LOAD_ACTION, array( __CLASS__, 'ajax_load_quiz_review' ) );
		add_action( 'admin_post_' . self::QUIZ_REVIEW_ACTION, array( __CLASS__, 'save_quiz_review' ) );
		add_action( 'admin_post_' . self::QUIZ_FILE_DOWNLOAD_ACTION, array( __CLASS__, 'download_quiz_file' ) );
		add_action( 'admin_post_' . self::QUIZ_FILE_PREVIEW_ACTION, array( __CLASS__, 'preview_quiz_file' ) );
	}

	/**
	 * Preserve student access to submitted records without enabling new work.
	 *
	 * @return void
	 */
	public static function init_read_only() {
		add_action( 'tutorhelper_student_dashboard_booking_details', array( __CLASS__, 'render_read_only_assignments' ), 30, 2 );
		add_action( 'admin_post_' . self::DOWNLOAD_ACTION, array( __CLASS__, 'download' ) );
		add_action( 'admin_post_' . self::PREVIEW_ACTION, array( __CLASS__, 'preview' ) );
	}

	/**
	 * Hide duplicate Pro feedback/homework blocks when LMS presents marked work.
	 *
	 * @param array  $display Pro student-dashboard display state.
	 * @param object $booking Booking record.
	 * @param object $follow_up Source follow-up record.
	 * @return array
	 */
	public static function filter_marked_student_follow_up_display( $display, $booking, $follow_up ) {
		if ( ! is_array( $display ) || ! $booking || empty( $booking->student_user_id ) ) {
			return $display;
		}

		$student_id = absint( $booking->student_user_id );
		if ( $follow_up && self::follow_up_has_released_submission( $follow_up, $student_id ) ) {
			$display['show_feedback'] = false;
			$display['show_source_homework'] = false;
		}

		if ( isset( $display['due_homework'] ) && is_array( $display['due_homework'] ) ) {
			$display['due_homework'] = array_values(
				array_filter(
					$display['due_homework'],
					function ( $homework ) use ( $student_id ) {
						return ! self::follow_up_has_released_submission( $homework, $student_id );
					}
				)
			);
		}

		return $display;
	}

	/**
	 * Whether one Pro homework record has a tutor-marked LMS submission.
	 *
	 * @param object $homework Pro homework record.
	 * @param int    $student_id Student user ID.
	 * @return bool
	 */
	private static function follow_up_has_released_submission( $homework, $student_id ) {
		if ( ! $homework || empty( $homework->id ) ) {
			return false;
		}

		$assignment = self::assignment_for_source( absint( $homework->id ), absint( $student_id ) );
		$submission = $assignment ? self::latest_submission_for_assignment( $assignment->id ) : null;
		return $submission && 'marked' === $submission->status;
	}

	/**
	 * Render released LMS feedback after Pro has rendered (or intentionally
	 * hidden) the source homework panels. This keeps the student view intact
	 * when Pro's duplicate panel is suppressed.
	 *
	 * @param object $booking Current student booking.
	 * @param object $follow_up Homework set on this booking.
	 * @param array  $due_homework Original homework due for this booking.
	 * @return void
	 */
	public static function render_released_student_lesson_feedback( $booking, $follow_up, $due_homework ) {
		if ( ! $booking || absint( $booking->student_user_id ) !== get_current_user_id() ) {
			return;
		}

		$records = array();
		if ( $follow_up && ! empty( $follow_up->id ) ) {
			$records[] = $follow_up;
		}
		foreach ( is_array( $due_homework ) ? $due_homework : array() as $homework ) {
			if ( $homework && ! empty( $homework->id ) ) {
				$records[] = $homework;
			}
		}

		$rendered = array();
		foreach ( $records as $homework ) {
			$source_id = absint( $homework->id );
			if ( ! $source_id || isset( $rendered[ $source_id ] ) || empty( $homework->homework_submission_enabled ) ) {
				continue;
			}
			$rendered[ $source_id ] = true;
			$assignment = self::assignment_for_source( $source_id, absint( $booking->student_user_id ) );
			$submission = $assignment ? self::latest_submission( $assignment->id ) : null;
			if ( $submission && self::has_released_mark( $submission ) ) {
				self::render_student_released_feedback( $assignment, $submission, true );
			}
		}
	}

	/**
	 * Treat a tutor-marked LMS submission as complete in the linked Pro lesson.
	 *
	 * This filter only runs while LMS Premium is active; Pro retains its own
	 * manual completion checkbox when LMS is not installed or no work is marked.
	 *
	 * @param bool   $completed Existing Pro completion state.
	 * @param int    $booking_id Due booking ID.
	 * @param object $booking Booking record.
	 * @return bool
	 */
	public static function complete_marked_pro_homework( $completed, $booking_id, $booking ) {
		return $completed || self::has_marked_submission_for_booking( $booking_id, $booking );
	}

	/**
	 * Prevent the Pro checkbox overriding a marked LMS submission.
	 *
	 * @param bool   $managed Existing managed state.
	 * @param int    $booking_id Due booking ID.
	 * @param object $booking Booking record.
	 * @return bool
	 */
	public static function manage_marked_pro_homework_completion( $managed, $booking_id, $booking ) {
		return $managed || self::has_marked_submission_for_booking( $booking_id, $booking );
	}

	/**
	 * Check whether this student's homework due for a booking has been marked.
	 *
	 * @param int    $booking_id Due booking ID.
	 * @param object $booking Booking record.
	 * @return bool
	 */
	private static function has_marked_submission_for_booking( $booking_id, $booking ) {
		if ( ! $booking || empty( $booking->student_user_id ) ) {
			return false;
		}

		global $wpdb;
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$submissions = TutorHelper_LMS_Database::table( 'submissions' );
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT s.id FROM {$submissions} s INNER JOIN {$assignments} a ON a.id = s.assignment_id WHERE a.booking_id = %d AND a.student_user_id = %d AND a.status != %s AND s.status = %s LIMIT 1",
				absint( $booking_id ),
				absint( $booking->student_user_id ),
				'archived',
				'marked'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads the linked LMS submission state for one tutor-owned booking.

		return ! empty( $found );
	}

	/**
	 * Synchronise the narrow, opt-in payload supplied by TutorHelper Pro.
	 *
	 * @param array $homework Homework payload.
	 * @return void
	 */
	public static function sync_assignment( $homework ) {
		if ( ! is_array( $homework ) || empty( $homework['source_id'] ) ) {
			return;
		}

		global $wpdb;

		$table     = TutorHelper_LMS_Database::table( 'assignments' );
		$source_id = absint( $homework['source_id'] );
		$existing  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE source_type = %s AND source_id = %d LIMIT 1", self::SOURCE_TYPE, $source_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Synchronises one Pro homework record.
		// A linked LMS Lesson also needs a durable assignment owner, even when
		// this homework does not request a file or link submission.
		$has_linked_lessons = isset( $_POST['homework_lesson_ids'] ) && is_array( $_POST['homework_lesson_ids'] ) && ! empty( $_POST['homework_lesson_ids'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Pro verifies the save AJAX nonce before firing this integration hook.
		$has_linked_quiz = isset( $_POST['homework_quiz_placement_id'] ) && ! is_array( $_POST['homework_quiz_placement_id'] ) && absint( wp_unslash( $_POST['homework_quiz_placement_id'] ) ) > 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified against the tutor's Course placement by the Premium delivery handler.
		$enabled   = ! empty( $homework['enabled'] ) || $has_linked_lessons || $has_linked_quiz;
		$course_id = absint( $homework['course_id'] ?? 0 );
		$grading_context = self::course_grading_context( $course_id );
		$data      = array(
			'booking_id'      => absint( ! empty( $homework['due_booking_id'] ) ? $homework['due_booking_id'] : $homework['booking_id'] ),
			'course_id'       => $course_id,
			'source_group_id' => absint( $homework['source_group_id'] ?? 0 ),
			'topic_ids'       => wp_json_encode( array_values( array_unique( array_filter( array_map( 'absint', is_array( $homework['topic_ids'] ?? null ) ? $homework['topic_ids'] : array() ) ) ) ) ),
			'student_user_id' => absint( $homework['student_user_id'] ),
			'tutor_user_id'   => absint( $homework['tutor_user_id'] ),
			'assessment_type' => 'marked' === ( $homework['assessment_type'] ?? '' ) ? 'marked' : 'completion',
			'title'           => sanitize_text_field( $homework['title'] ?? '' ),
			'instructions'    => sanitize_textarea_field( $homework['instructions'] ?? '' ),
			'max_mark'        => ! empty( $homework['max_mark'] ) ? (float) $homework['max_mark'] : null,
			'grading_scheme_version' => sanitize_text_field( $grading_context['version'] ?? '' ),
			'updated_at'      => current_time( 'mysql', true ),
		);

		if ( $has_linked_quiz ) {
			// Quiz Homework owns its submission and grade. Its actual maximum comes
			// from the first immutable attempt, including Adaptive Practice attempts.
			$data['assessment_type'] = 'marked';
			unset( $data['max_mark'] );
		}

		if ( $existing ) {
			// Do not undo a tutor-authorised reopen when editing homework wording.
			$data['status'] = $enabled ? $existing->status : 'archived';
			$wpdb->update( $table, $data, array( 'id' => absint( $existing->id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Updates one source-linked assignment.
			return;
		}

		if ( ! $enabled ) {
			return;
		}

		$data['source_type'] = self::SOURCE_TYPE;
		$data['source_id']   = $source_id;
		$data['status']      = 'not_started';
		$data['created_at']  = current_time( 'mysql', true );
		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds one tutor-enabled assignment.
	}

	/**
	 * Add a tutor-only submissions page beneath the shared TutorHelper menu.
	 *
	 * @return void
	 */
	public static function register_tutor_page() {
		if ( ! class_exists( 'TutorHelper_Admin' ) || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}

		add_submenu_page(
			TutorHelper_Admin::MENU_SLUG,
			__( 'LMS submissions', 'tutorhelper-lms' ),
			__( 'LMS submissions', 'tutorhelper-lms' ),
			TutorHelper_Admin::CAPABILITY,
			self::PAGE_SLUG,
			array( __CLASS__, 'render_tutor_page' )
		);
	}

	/**
	 * Render tutor controls for opening, downloading and reopening work.
	 *
	 * @return void
	 */
	public static function render_tutor_page() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view LMS submissions.', 'tutorhelper-lms' ) );
		}

		$homework_rows = self::tutor_homework_submission_rows();
		$quiz_rows     = self::tutor_quiz_submission_rows();
		$has_custom_rows = (bool) apply_filters( 'tutorhelper_lms_has_custom_submission_rows', false );
		$quiz_notice   = isset( $_GET['tutorhelper_lms_quiz_review'] ) && ! is_array( $_GET['tutorhelper_lms_quiz_review'] ) ? sanitize_key( wp_unslash( $_GET['tutorhelper_lms_quiz_review'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only redirect notice.
		$quiz_messages = array(
			'quiz_feedback_saved'    => __( 'Quiz feedback saved privately.', 'tutorhelper-lms' ),
			'quiz_results_released' => __( 'Quiz results and feedback released to the student.', 'tutorhelper-lms' ),
			'quiz_feedback_error'          => __( 'Quiz feedback could not be saved. Please try again.', 'tutorhelper-lms' ),
			'quiz_release_error'           => __( 'Quiz results could not be released. Please try again.', 'tutorhelper-lms' ),
			'quiz_invalid_mark'            => __( 'Each awarded mark must be a whole number between zero and the Question maximum.', 'tutorhelper-lms' ),
			'quiz_manual_marking_pending'  => __( 'Mark every written or file response before releasing this Quiz.', 'tutorhelper-lms' ),
		);
		?>
		<div class="tutorhelper-settings-page tutorhelper-lms-submissions-workspace">
			<section class="tutorhelper-main-section">
				<header class="tutorhelper-main-section__header">
					<div class="tutorhelper-main-section__header-content">
						<h1><?php esc_html_e( 'LMS submissions', 'tutorhelper-lms' ); ?></h1>
						<p><?php esc_html_e( 'Review student homework and completed Quiz attempts.', 'tutorhelper-lms' ); ?></p>
					</div>
				</header>
				<div class="tutorhelper-main-section__body">
					<?php if ( isset( $quiz_messages[ $quiz_notice ] ) ) : ?><div class="notice <?php echo false !== strpos( $quiz_notice, 'error' ) ? 'notice-error' : 'notice-success'; ?> inline"><p><?php echo esc_html( $quiz_messages[ $quiz_notice ] ); ?></p></div><?php endif; ?>
					<?php if ( empty( $homework_rows ) && empty( $quiz_rows ) && ! $has_custom_rows ) : ?>
						<p><?php esc_html_e( 'No homework or Quiz submissions are available yet.', 'tutorhelper-lms' ); ?></p>
					<?php else : ?>
						<p><label for="tutorhelper-lms-submission-kind"><strong><?php esc_html_e( 'Show', 'tutorhelper-lms' ); ?></strong></label> <select id="tutorhelper-lms-submission-kind" data-tutorhelper-lms-submission-kind-filter><option value=""><?php esc_html_e( 'Homework and Quiz submissions', 'tutorhelper-lms' ); ?></option><option value="homework"><?php esc_html_e( 'Homework submissions', 'tutorhelper-lms' ); ?></option><option value="quiz"><?php esc_html_e( 'Quiz submissions', 'tutorhelper-lms' ); ?></option></select></p>
						<table class="widefat striped" data-tutorhelper-lms-submission-kind-table>
							<thead><tr>
								<th><?php esc_html_e( 'Type', 'tutorhelper-lms' ); ?></th>
								<th><?php esc_html_e( 'Submission', 'tutorhelper-lms' ); ?></th>
								<th><?php esc_html_e( 'Student', 'tutorhelper-lms' ); ?></th>
								<th><?php esc_html_e( 'Status', 'tutorhelper-lms' ); ?></th>
								<th><?php esc_html_e( 'Due date', 'tutorhelper-lms' ); ?></th>
								<th><?php esc_html_e( 'Date submitted', 'tutorhelper-lms' ); ?></th>
								<th><?php esc_html_e( 'Time taken', 'tutorhelper-lms' ); ?></th>
								<th><?php esc_html_e( 'Result', 'tutorhelper-lms' ); ?></th>
								<th><?php esc_html_e( 'Actions', 'tutorhelper-lms' ); ?></th>
							</tr></thead>
							<tbody>
								<?php foreach ( $homework_rows as $row ) : ?>
									<tr data-tutorhelper-lms-submission-row="<?php echo esc_attr( $row->submission_id ); ?>" data-tutorhelper-lms-submission-kind="homework" data-tutorhelper-lms-submission-status-key="<?php echo esc_attr( self::submission_filter_status( $row ) ); ?>">
										<td><?php esc_html_e( 'Homework', 'tutorhelper-lms' ); ?></td>
										<td><?php echo esc_html( $row->title ); ?></td>
										<td><?php echo esc_html( self::user_name( $row->student_user_id ) ); ?></td>
										<td data-tutorhelper-lms-submission-status><?php self::render_tutor_submission_status( $row ); ?></td>
										<td><?php echo esc_html( self::booking_date_label( $row->booking_id ) ); ?></td>
										<td><?php echo esc_html( self::submitted_date_label( $row->submitted_at ) ); ?></td>
										<td>—</td>
										<td><?php echo null !== $row->awarded_mark ? esc_html( self::mark_format( $row->awarded_mark ) . ( null !== $row->max_mark ? ' / ' . self::mark_format( $row->max_mark ) : '' ) ) : '—'; ?></td>
										<td>
											<?php if ( 'file' === $row->submission_type && $row->submission_id ) : ?>
												<?php self::render_tutor_submission_actions( $row ); ?>
											<?php elseif ( 'link' === $row->submission_type && $row->link_url ) : ?>
												<button type="button" class="button tutorhelper-action-button tutorhelper-lms-mark-submission" data-tutorhelper-lms-mark-submission="<?php echo esc_attr( $row->submission_id ); ?>"><?php esc_html_e( 'View / Mark homework', 'tutorhelper-lms' ); ?></button>
												<a class="button tutorhelper-action-button" href="<?php echo esc_url( $row->link_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open shared link', 'tutorhelper-lms' ); ?></a>
											<?php else : ?>
												<?php esc_html_e( 'No work saved', 'tutorhelper-lms' ); ?>
											<?php endif; ?>
											<?php self::render_tutor_submission_actions_cell( $row ); ?>
										</td>
									</tr>
								<?php endforeach; ?>
								<?php foreach ( $quiz_rows as $attempt ) : ?>
									<?php
									$released = TutorHelper_LMS_Quiz_Attempts::results_released( $attempt );
									$score = TutorHelper_LMS_Quiz_Attempts::attempt_score( $attempt->id );
									$quiz_status = $released ? 'results_released' : 'awaiting_release';
									?>
									<tr data-tutorhelper-lms-submission-kind="quiz" data-tutorhelper-lms-submission-status-key="<?php echo esc_attr( $quiz_status ); ?>">
										<td><?php esc_html_e( 'Quiz', 'tutorhelper-lms' ); ?></td>
										<td><strong><?php echo esc_html( $attempt->quiz_title ? $attempt->quiz_title : __( 'Quiz', 'tutorhelper-lms' ) ); ?></strong><?php if ( $attempt->course_title ) : ?><br /><small><?php echo esc_html( $attempt->course_title ); ?></small><?php endif; ?></td>
										<td><?php echo esc_html( self::user_name( $attempt->student_user_id ) ); ?></td>
										<td><strong><?php echo esc_html( self::tutor_submission_status_label( $quiz_status ) ); ?></strong></td>
										<td>—</td>
										<td><?php echo esc_html( self::submitted_date_label( $attempt->submitted_at ?: $attempt->completed_at ) ); ?></td>
										<td><?php echo esc_html( TutorHelper_LMS_Quiz_Attempts::time_taken_label( $attempt ) ); ?></td>
										<td><?php echo esc_html( self::quiz_result_label( $attempt, $score ) ); ?></td>
										<td><button type="button" class="button tutorhelper-action-button" data-tutorhelper-lms-review-quiz="<?php echo esc_attr( $attempt->id ); ?>"><?php esc_html_e( 'Open Quiz', 'tutorhelper-lms' ); ?></button></td>
									</tr>
								<?php endforeach; ?>
								<?php do_action( 'tutorhelper_lms_submissions_table_rows' ); ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>
			</section>
		</div>
		<?php
	}

	/**
	 * Return homework rows submitted to the current tutor.
	 *
	 * @return array
	 */
	private static function tutor_homework_submission_rows() {
		global $wpdb;

		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$submissions = TutorHelper_LMS_Database::table( 'submissions' );
		$files       = TutorHelper_LMS_Database::table( 'submission_files' );
		$marks       = TutorHelper_LMS_Database::table( 'marks' );

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.*, s.id AS submission_id, s.status AS submission_status, s.submission_type, s.storage_provider, s.provider_file_id, s.link_url, s.submitted_at, f.original_filename, f.mime_type, m.awarded_mark, m.grading_scheme_snapshot, m.status AS mark_status
				FROM {$assignments} a
				LEFT JOIN {$submissions} s ON s.id = (
					SELECT recent.id FROM {$submissions} recent WHERE recent.assignment_id = a.id ORDER BY recent.id DESC LIMIT 1
				)
				LEFT JOIN {$files} f ON f.submission_id = s.id
				LEFT JOIN {$marks} m ON m.submission_id = s.id
				WHERE a.tutor_user_id = %d AND a.status != %s
				ORDER BY a.updated_at DESC",
				get_current_user_id(),
				'archived'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Lists only the current tutor's homework assignments.
	}

	/**
	 * Return completed Quiz attempts from Courses authored by the current tutor.
	 *
	 * @return array
	 */
	private static function tutor_quiz_submission_rows() {
		global $wpdb;

		$attempts = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		if ( '' === $attempts ) {
			return array();
		}

		$posts = $wpdb->posts;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT attempts.*, course.post_title AS course_title, quiz.post_title AS quiz_title
				FROM {$attempts} attempts
				INNER JOIN {$posts} course ON course.ID = attempts.course_id
				LEFT JOIN {$posts} quiz ON quiz.ID = attempts.quiz_id
				WHERE course.post_author = %d AND course.post_type = %s AND attempts.status = %s
				ORDER BY COALESCE( attempts.submitted_at, attempts.completed_at ) DESC, attempts.id DESC",
				get_current_user_id(),
				'tutorhelper_course',
				'completed'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Lists completed Quiz attempts for Courses owned by the current tutor.
		return apply_filters( 'tutorhelper_lms_tutor_quiz_submission_rows', is_array( $rows ) ? $rows : array() );
	}

	/**
	 * Return the Quiz Builder edit URL for a submitted attempt.
	 *
	 * @param int $quiz_id Quiz post ID.
	 * @return string
	 */
	private static function quiz_builder_url( $quiz_id ) {
		return add_query_arg(
			array(
				'page'      => TutorHelper_LMS_Learning_Hub::PAGE_SLUG,
				'tab'       => 'quizzes',
				'edit_quiz' => absint( $quiz_id ),
			),
			admin_url( 'admin.php' )
		);
	}

	/** Render the result state shown in a tutor submissions table row. */
	private static function render_tutor_submission_status( $row ) {
		$key = self::submission_filter_status( $row );
		echo '<strong>' . esc_html( self::tutor_submission_status_label( $key ) ) . '</strong>';
		if ( null !== $row->awarded_mark && 'marked' === $row->assessment_type ) {
			$table_result = self::grade_snapshot( $row, $row->awarded_mark, $row->grading_scheme_snapshot );
			echo '<small class="tutorhelper-lms-submission-result">' . esc_html( self::mark_format( $row->awarded_mark ) . ( null !== $row->max_mark ? ' / ' . self::mark_format( $row->max_mark ) : '' ) . ( $table_result ? ' · ' . self::grade_result_label( $table_result ) : '' ) ) . '</small>';
		}
	}

	/**
	 * Return the restricted shared status used by the tutor submissions filter.
	 *
	 * @param object $row Homework submission row.
	 * @return string
	 */
	private static function submission_filter_status( $row ) {
		if ( null !== ( $row->awarded_mark ?? null ) && 'marked' === ( $row->assessment_type ?? '' ) ) {
			return 'marked';
		}
		$status = sanitize_key( $row->submission_status ?? 'not_started' );
		if ( 'marked' === $status ) {
			return 'marked';
		}
		if ( in_array( $status, array( 'submitted', 'reopened' ), true ) ) {
			return 'submitted';
		}
		return 'not_started';
	}

	/**
	 * Return tutor-facing labels shared by homework and Quiz submission rows.
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	private static function tutor_submission_status_label( $status ) {
		$labels = array(
			'marked'           => __( 'Marked', 'tutorhelper-lms' ),
			'not_started'      => __( 'Not Started', 'tutorhelper-lms' ),
			'awaiting_release' => __( 'Awaiting Release', 'tutorhelper-lms' ),
			'results_released' => __( 'Results Released', 'tutorhelper-lms' ),
			'submitted'        => __( 'Submitted', 'tutorhelper-lms' ),
		);
		return $labels[ $status ] ?? $labels['not_started'];
	}

	/**
	 * Format one Quiz's score with its Course percentage and grade.
	 *
	 * @param object $attempt Completed Quiz attempt.
	 * @param array  $score Calculated Quiz score.
	 * @return string
	 */
	private static function quiz_result_label( $attempt, $score ) {
		$marks = absint( $score['marks'] ?? 0 );
		$available = absint( $score['available'] ?? 0 );
		$label = sprintf( _n( '%1$d / %2$d mark', '%1$d / %2$d marks', $available, 'tutorhelper-lms' ), $marks, $available );
		if ( class_exists( 'TutorHelper_LMS_Grade_Systems' ) ) {
			$snapshot = json_decode( (string) ( $attempt->snapshot_json ?? '' ), true );
			$context = is_array( $snapshot['course_grading_context'] ?? null ) ? $snapshot['course_grading_context'] : array();
			$result = TutorHelper_LMS_Grade_Systems::grade_result_for_course( absint( $attempt->course_id ?? 0 ), $marks, $available, $context );
			$grade_label = TutorHelper_LMS_Grade_Systems::grade_result_label( $result );
			if ( '' !== $grade_label ) {
				$label .= ' · ' . $grade_label;
			}
		}
		return $label;
	}

	/** Render actions shown in a tutor submissions table row. */
	private static function render_tutor_submission_actions_cell( $row ) {
		if ( 'submitted' !== $row->submission_status ) {
			echo '<span aria-hidden="true">—</span>';
			return;
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::REOPEN_ACTION ); ?>" />
			<input type="hidden" name="submission_id" value="<?php echo esc_attr( $row->submission_id ); ?>" />
			<?php wp_nonce_field( self::REOPEN_ACTION . '_' . $row->submission_id ); ?>
			<button type="submit" class="button tutorhelper-action-button"><?php esc_html_e( 'Request resubmission', 'tutorhelper-lms' ); ?></button>
		</form>
		<?php
	}


	/**
	 * Load the established LMS modal treatment for student dashboard controls.
	 *
	 * @return void
	 */
	public static function enqueue_student_assets() {
		if ( ! is_user_logged_in() ) {
			return;
		}

		$style_path  = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/css/tutorhelper-lms-shared.css';
		$script_path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-modal.js';
		wp_enqueue_style( 'tutorhelper-lms-shared', TUTORHELPER_LMS_PREMIUM_URL . 'assets/css/tutorhelper-lms-shared.css', array(), file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_LMS_PREMIUM_VERSION );
		wp_enqueue_script( 'tutorhelper-lms-modal', TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-modal.js', array(), file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_LMS_PREMIUM_VERSION, true );
	}

	/**
	 * Load the shared LMS modal assets for TutorHelper tutor workspaces.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public static function enqueue_tutor_assets( $hook_suffix ) {
		if ( false === strpos( (string) $hook_suffix, 'tutorhelper' ) ) {
			return;
		}

		$style_path  = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/css/tutorhelper-lms-shared.css';
		$script_path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-modal.js';
		wp_enqueue_style( 'tutorhelper-lms-shared', TUTORHELPER_LMS_PREMIUM_URL . 'assets/css/tutorhelper-lms-shared.css', array(), file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_LMS_PREMIUM_VERSION );
		wp_enqueue_script( 'tutorhelper-lms-modal', TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-modal.js', array( 'jquery', 'wp-editor' ), file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_LMS_PREMIUM_VERSION, true );
		wp_enqueue_editor();
		wp_localize_script( 'tutorhelper-lms-modal', 'tutorhelperLmsMarking', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( self::MARK_LOAD_ACTION ), 'saveNonce' => wp_create_nonce( self::MARK_SAVE_ACTION ), 'loadAction' => self::MARK_LOAD_ACTION, 'saveAction' => self::MARK_SAVE_ACTION, 'failed' => __( 'The marking workspace could not be loaded.', 'tutorhelper-lms' ) ) );
		wp_localize_script( 'tutorhelper-lms-modal', 'tutorhelperLmsQuizReview', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( self::QUIZ_REVIEW_LOAD_ACTION ), 'loadAction' => self::QUIZ_REVIEW_LOAD_ACTION, 'failed' => __( 'The Quiz review workspace could not be loaded.', 'tutorhelper-lms' ) ) );
	}

	/**
	 * Add a single LMS action below the existing Pro homework links.
	 *
	 * @param object $homework Pro homework record.
	 * @return void
	 */
	public static function render_student_submission_trigger( $homework ) {
		if ( ! $homework || empty( $homework->id ) || empty( $homework->homework_submission_enabled ) ) {
			return;
		}

		$assignment = self::assignment_for_source( absint( $homework->id ), get_current_user_id() );
		if ( ! $assignment || 'archived' === $assignment->status ) {
			return;
		}

		$submission = self::latest_submission( $assignment->id );
		self::$student_submission_modal_instance++;
		$modal_id   = 'tutorhelper-lms-submit-' . absint( $assignment->id ) . '-' . self::$student_submission_modal_instance;
		$due_label  = self::assignment_due_label( $assignment );
		?>
		<div class="tutorhelper-lms-homework-action">
			<?php if ( $submission && self::has_released_mark( $submission ) ) : ?>
				<?php self::render_student_released_feedback( $assignment, $submission, true ); ?>
			<?php elseif ( $submission && in_array( $submission->status, array( 'submitted', 'marked' ), true ) ) : ?>
				<span class="tutorhelper-lms-homework-status"><?php esc_html_e( 'Homework submitted', 'tutorhelper-lms' ); ?></span>
				<?php self::render_submission_access( $submission ); ?>
			<?php else : ?>
				<button type="button" class="tutorhelper-button tutorhelper-lms-submit-button" data-tutorhelper-lms-modal-open="<?php echo esc_attr( $modal_id ); ?>"><?php echo esc_html( $submission && 'reopened' === $submission->status ? __( 'Resubmit homework', 'tutorhelper-lms' ) : ( $submission && 'draft' === $submission->status ? __( 'Submit homework (draft saved)', 'tutorhelper-lms' ) : __( 'Submit homework', 'tutorhelper-lms' ) ) ); ?></button>
			<?php endif; ?>
		</div>
		<?php if ( ! $submission || ! in_array( $submission->status, array( 'submitted', 'marked' ), true ) ) : ?>
			<dialog id="<?php echo esc_attr( $modal_id ); ?>" class="tutorhelper-lms-modal" aria-labelledby="<?php echo esc_attr( $modal_id . '-title' ); ?>">
				<div class="tutorhelper-lms-modal__header"><h2 id="<?php echo esc_attr( $modal_id . '-title' ); ?>"><?php echo esc_html( $assignment->title . $due_label ); ?></h2><button type="button" class="button-link tutorhelper-lms-modal__close" data-tutorhelper-lms-modal-close aria-label="<?php esc_attr_e( 'Close submission form', 'tutorhelper-lms' ); ?>">×</button></div>
				<div class="tutorhelper-lms-modal__body">
					<?php if ( $submission && 'reopened' === $submission->status ) : ?><p class="tutorhelper-lms-resubmission-message"><?php esc_html_e( 'Your tutor has returned your homework to resubmit.', 'tutorhelper-lms' ); ?></p><?php self::render_student_released_feedback( $assignment, $submission ); ?><?php endif; ?>
					<?php if ( $assignment->instructions ) : ?><p class="tutorhelper-lms-assignment-instructions"><?php echo esc_html( $assignment->instructions ); ?></p><?php endif; ?>
					<?php if ( $submission && 'draft' === $submission->status ) : ?><p class="tutorhelper-lms-draft-message"><?php esc_html_e( 'You have currently saved your homework as a draft.', 'tutorhelper-lms' ); ?> <?php self::render_submission_access( $submission, __( 'Download your saved file', 'tutorhelper-lms' ) ); ?></p><?php endif; ?>
					<?php self::render_submission_form( $assignment, $submission ); ?>
				</div>
			</dialog>
		<?php endif;
	}

	/**
	 * Add tutor-visible LMS status to the existing Pro due-homework modal.
	 *
	 * @param array  $item Prepared Pro homework item.
	 * @param object $homework Pro homework record.
	 * @return array
	 */
	public static function add_due_submission_details( $item, $homework ) {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) || ! $homework || empty( $homework->id ) || empty( $homework->homework_submission_enabled ) ) {
			return $item;
		}

		$assignment = self::assignment_for_source( absint( $homework->id ) );
		if ( ! $assignment ) {
			return $item;
		}

		$submission = self::latest_submission_for_assignment( $assignment->id );
		$method     = $submission ? self::provider_label( $submission->storage_provider ) : __( 'No submission yet', 'tutorhelper-lms' );
		$item['lmsSubmission'] = array(
			'status'   => self::status_label( $submission ? $submission->status : 'not_started' ),
			'method'   => $method,
			'url'      => $submission && 'file' === $submission->submission_type ? self::download_url( $submission->id ) : ( $submission && ! empty( $submission->link_url ) ? esc_url_raw( $submission->link_url ) : '' ),
			'urlLabel' => $submission && 'file' === $submission->submission_type ? __( 'Download submission', 'tutorhelper-lms' ) : __( 'Open submitted link', 'tutorhelper-lms' ),
			'markSubmissionId' => $submission && in_array( $submission->status, array( 'submitted', 'reopened' ), true ) ? absint( $submission->id ) : 0,
		);
		return $item;
	}


	/**
	 * Render active submission controls in the student's own booking dashboard.
	 *
	 * @param mixed  $booking_data Booking object or ID.
	 * @param string $section Current dashboard section.
	 * @return void
	 */
	public static function render_student_assignments( $booking_data, $section = '' ) {
		$booking = self::student_booking( $booking_data );
		if ( ! $booking ) {
			return;
		}

		foreach ( self::assignments_for_booking( $booking->id ) as $assignment ) {
			self::render_student_assignment( $assignment, false );
		}
	}

	/**
	 * Render submitted coursework only after Premium becomes unavailable.
	 *
	 * @param mixed  $booking_data Booking object or ID.
	 * @param string $section Current dashboard section.
	 * @return void
	 */
	public static function render_read_only_assignments( $booking_data, $section = '' ) {
		$booking = self::student_booking( $booking_data );
		if ( ! $booking ) {
			return;
		}

		foreach ( self::assignments_for_booking( $booking->id, true ) as $assignment ) {
			$submission = self::latest_submission( $assignment->id );
			if ( ! $submission || ! in_array( $submission->status, array( 'submitted', 'reopened' ), true ) ) {
				continue;
			}
			?>
			<section class="tutorhelper-main-section tutorhelper-lms-assignment">
				<header class="tutorhelper-main-section__header is-compact"><div class="tutorhelper-main-section__header-content">
					<h3><?php echo esc_html( $assignment->title ); ?></h3>
					<p><?php esc_html_e( 'Your existing coursework remains available to view. New submission activity is currently unavailable.', 'tutorhelper-lms' ); ?></p>
				</div></header>
				<div class="tutorhelper-main-section__body"><?php self::render_submission_access( $submission ); ?></div>
			</section>
			<?php
		}
	}

	/**
	 * Render one student assignment card.
	 *
	 * @param object $assignment Assignment.
	 * @param bool   $readonly Whether mutating controls are unavailable.
	 * @return void
	 */
	private static function render_student_assignment( $assignment, $readonly ) {
		$submission = self::latest_submission( $assignment->id );
		?>
		<section class="tutorhelper-main-section tutorhelper-lms-assignment">
			<header class="tutorhelper-main-section__header is-compact"><div class="tutorhelper-main-section__header-content">
				<h3><?php echo esc_html( $assignment->title ); ?></h3>
				<?php if ( $assignment->instructions ) : ?><p><?php echo esc_html( $assignment->instructions ); ?></p><?php endif; ?>
				<?php if ( 'marked' === $assignment->assessment_type && null !== $assignment->max_mark ) : ?>
					<p><?php
					/* translators: %s is the maximum available mark. */
					printf( esc_html__( 'Maximum mark: %s', 'tutorhelper-lms' ), esc_html( self::mark_format( $assignment->max_mark ) ) );
					?></p>
				<?php endif; ?>
			</div></header>
			<div class="tutorhelper-main-section__body">
				<?php if ( $submission && self::has_released_mark( $submission ) ) : ?>
					<?php self::render_student_released_feedback( $assignment, $submission ); ?>
				<?php elseif ( $submission && in_array( $submission->status, array( 'submitted', 'marked' ), true ) ) : ?>
					<p class="notice notice-success inline"><span><?php esc_html_e( 'Submitted. Your work is now locked unless your tutor returns it for resubmission.', 'tutorhelper-lms' ); ?></span></p>
					<?php self::render_submission_access( $submission ); ?>
				<?php else : ?>
					<?php if ( $submission && 'reopened' === $submission->status ) : ?>
						<p class="notice notice-warning inline"><span><?php esc_html_e( 'Your tutor has returned this work for resubmission. Save a draft or submit your updated work when ready.', 'tutorhelper-lms' ); ?></span></p>
					<?php elseif ( $submission && 'draft' === $submission->status ) : ?>
						<p class="notice notice-info inline"><span><?php esc_html_e( 'Draft saved. You can return and continue before submitting.', 'tutorhelper-lms' ); ?></span></p>
					<?php endif; ?>
					<?php self::render_submission_form( $assignment, $submission ); ?>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	/**
	 * Render a stateful draft/submit form.
	 *
	 * @param object      $assignment Assignment.
	 * @param object|null $submission Current editable submission.
	 * @return void
	 */
	private static function render_submission_form( $assignment, $submission ) {
		$limit_mb = self::upload_limit_mb();
		$provider = self::preferred_provider();
		$provider_label = TutorHelper_LMS_Private_Storage::MODE_GOOGLE === TutorHelper_LMS_Private_Storage::mode() ? __( 'Upload to private Google Drive', 'tutorhelper-lms' ) : __( 'Private file upload', 'tutorhelper-lms' );
		?>
		<form class="tutorhelper-settings-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
			<input type="hidden" name="assignment_id" value="<?php echo esc_attr( $assignment->id ); ?>" />
			<input type="hidden" name="submission_id" value="<?php echo esc_attr( $submission ? $submission->id : 0 ); ?>" />
			<?php wp_nonce_field( self::SAVE_ACTION . '_' . $assignment->id ); ?>

			<?php if ( $submission ) : ?><p><?php self::render_submission_access( $submission ); ?></p><?php endif; ?>

			<?php if ( $provider ) : ?>
			<p class="tutorhelper-input-field is-full-width">
				<label for="tutorhelper-lms-file-<?php echo esc_attr( $assignment->id ); ?>"><strong><?php echo esc_html( $provider_label ); ?></strong></label><br />
				<input id="tutorhelper-lms-file-<?php echo esc_attr( $assignment->id ); ?>" name="submission_file" type="file" accept=".pdf,.docx,.jpg,.jpeg,.png,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/jpeg,image/png" />
				<span class="description"><?php
				/* translators: %s is the configured upload limit in MB. */
				printf( esc_html__( 'Once you have completed your homework, please upload it here as a PDF, Word Document, Image (.jpg or .png). Your file must be smaller than %s MB to upload.', 'tutorhelper-lms' ), esc_html( $limit_mb ) );
				?></span>
				<span class="description tutorhelper-lms-submission-help"><?php esc_html_e( 'Homework files are stored on a private cloud drive.', 'tutorhelper-lms' ); ?></span>
			</p>
			<?php endif; ?>
			<?php if ( ! $provider ) : ?><p class="tutorhelper-lms-submission-guidance"><?php esc_html_e( 'To send your homework file to your tutor, create a shared document link using Google Drive, OneDrive, Dropbox, or another similar sharing service. Copy and paste your link into the box below so your tutor can view the file.', 'tutorhelper-lms' ); ?></p><?php else : ?><p><?php esc_html_e( 'or', 'tutorhelper-lms' ); ?></p><?php endif; ?>
			<p class="tutorhelper-input-field is-full-width">
				<label for="tutorhelper-lms-link-<?php echo esc_attr( $assignment->id ); ?>"><strong><?php esc_html_e( 'Paste your share link here:', 'tutorhelper-lms' ); ?></strong></label><br />
				<input id="tutorhelper-lms-link-<?php echo esc_attr( $assignment->id ); ?>" class="regular-text tutorhelper-input-field__control" name="submission_link" type="url" inputmode="url" placeholder="https://" value="" />
				<span class="description tutorhelper-lms-submission-help"><?php esc_html_e( 'Make sure that you have created a share link that your tutor can access! Your link will only be sent to your tutor, and will not be shared.', 'tutorhelper-lms' ); ?></span>
			</p>
			<p>
				<button class="button button-secondary tutorhelper-action-button" type="submit" name="submission_intent" value="draft"><?php esc_html_e( 'Save draft', 'tutorhelper-lms' ); ?></button>
				<button class="button button-primary tutorhelper-action-button" type="submit" name="submission_intent" value="submitted"><?php echo esc_html( $submission && 'reopened' === $submission->status ? __( 'Resubmit homework', 'tutorhelper-lms' ) : __( 'Submit homework', 'tutorhelper-lms' ) ); ?></button>
			</p>
		</form>
		<?php
	}

	/**
	 * Save a student-owned draft or final submission.
	 *
	 * @return void
	 */
	public static function save() {
		$assignment_id = isset( $_POST['assignment_id'] ) ? absint( $_POST['assignment_id'] ) : 0;
		check_admin_referer( self::SAVE_ACTION . '_' . $assignment_id );

		$assignment = self::owned_assignment( $assignment_id );
		if ( ! $assignment ) {
			wp_die( esc_html__( 'This assignment is not available.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		$intent = isset( $_POST['submission_intent'] ) && ! is_array( $_POST['submission_intent'] )
			? sanitize_key( wp_unslash( $_POST['submission_intent'] ) )
			: 'draft';
		$intent = in_array( $intent, array( 'draft', 'submitted' ), true ) ? $intent : 'draft';

		$submission_id = isset( $_POST['submission_id'] ) ? absint( $_POST['submission_id'] ) : 0;
		$submission    = self::owned_editable_submission( $assignment->id, $submission_id );
		$link          = self::posted_https_link();
		$upload        = isset( $_FILES['submission_file'] ) && is_array( $_FILES['submission_file'] ) ? $_FILES['submission_file'] : null;
		$has_upload    = $upload && UPLOAD_ERR_NO_FILE !== (int) $upload['error'];

		if ( $has_upload && '' !== $link ) {
			self::fail( __( 'Choose either one file or one HTTPS shared-document link.', 'tutorhelper-lms' ) );
		}

		if ( $has_upload ) {
			$stored = self::store_file( $assignment, $upload );
			self::save_file_submission( $assignment, $submission, $stored, $intent );
		} elseif ( '' !== $link ) {
			self::save_link_submission( $assignment, $submission, $link, $intent );
		} elseif ( $submission ) {
			self::set_submission_status( $submission, $intent );
		} else {
			self::fail( __( 'Choose one file or enter one HTTPS shared-document link.', 'tutorhelper-lms' ) );
		}

		wp_safe_redirect( wp_validate_redirect( wp_get_referer(), home_url( '/' ) ) );
		exit;
	}

	/**
	 * Reopen submitted work for the assigned tutor only.
	 *
	 * @return void
	 */
	public static function reopen() {
		$submission_id = isset( $_POST['submission_id'] ) ? absint( $_POST['submission_id'] ) : 0;
		check_admin_referer( self::REOPEN_ACTION . '_' . $submission_id );

		$submission = self::tutor_submission( $submission_id );
		if ( ! $submission || 'submitted' !== $submission->status ) {
			wp_die( esc_html__( 'This submission cannot be reopened.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->update( TutorHelper_LMS_Database::table( 'submissions' ), array( 'status' => 'reopened', 'reopened_at' => $now, 'updated_at' => $now ), array( 'id' => $submission_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Tutor-authorised revision of one assigned submission.
		$wpdb->update( TutorHelper_LMS_Database::table( 'assignments' ), array( 'status' => 'reopened', 'updated_at' => $now ), array( 'id' => absint( $submission->assignment_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Mirrors the revision state on the assignment.

		wp_safe_redirect( admin_url( 'admin.php?page=tutorhelper-lms-learning-hub&tab=submissions' ) );
		exit;
	}

	/**
	 * Load the tutor Quiz-review modal for a completed attempt they own.
	 *
	 * @return void
	 */
	public static function ajax_load_quiz_review() {
		check_ajax_referer( self::QUIZ_REVIEW_LOAD_ACTION, 'nonce' );
		$attempt = self::tutor_quiz_attempt( isset( $_POST['attempt_id'] ) ? absint( $_POST['attempt_id'] ) : 0 );
		if ( ! $attempt ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to review this Quiz attempt.', 'tutorhelper-lms' ) ), 403 );
		}

		ob_start();
		self::render_quiz_review_workspace( $attempt );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/**
	 * Save optional tutor feedback and, when requested, release one Quiz result.
	 *
	 * @return void
	 */
	public static function save_quiz_review() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to review Quiz attempts.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		$attempt_id = isset( $_POST['attempt_id'] ) && ! is_array( $_POST['attempt_id'] ) ? absint( wp_unslash( $_POST['attempt_id'] ) ) : 0;
		check_admin_referer( self::QUIZ_REVIEW_ACTION . '_' . $attempt_id );
		$attempt = self::tutor_quiz_attempt( $attempt_id );
		if ( ! $attempt ) {
			wp_die( esc_html__( 'This Quiz attempt is not available.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		$feedback = isset( $_POST['tutor_feedback'] ) && ! is_array( $_POST['tutor_feedback'] ) ? wp_kses_post( wp_unslash( $_POST['tutor_feedback'] ) ) : '';
		$enabled_question_feedback = isset( $_POST['question_feedback_enabled'] ) && is_array( $_POST['question_feedback_enabled'] ) ? wp_unslash( $_POST['question_feedback_enabled'] ) : array();
		$question_feedback = isset( $_POST['question_feedback'] ) && is_array( $_POST['question_feedback'] ) ? wp_unslash( $_POST['question_feedback'] ) : array();
		$question_marks = isset( $_POST['question_marks'] ) && is_array( $_POST['question_marks'] ) ? wp_unslash( $_POST['question_marks'] ) : array();
		$snapshot = json_decode( (string) $attempt->snapshot_json, true );
		$questions = is_array( $snapshot['questions'] ?? null ) ? $snapshot['questions'] : array();
		$allowed_question_ids = array();
		$manual_questions = array();
		foreach ( $questions as $question ) {
			$question_id = absint( $question['question_id'] ?? 0 );
			$allowed_question_ids[] = $question_id;
			$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
			if ( self::is_manual_quiz_question_type( sanitize_key( is_array( $definition ) ? ( $definition['question_type'] ?? '' ) : '' ) ) ) {
				$manual_questions[ $question_id ] = absint( null === ( $question['mark_override'] ?? null ) ? ( $question['max_marks'] ?? 0 ) : $question['mark_override'] );
			}
		}
		$allowed_question_ids = array_filter( array_unique( $allowed_question_ids ) );

		global $wpdb;
		$attempts_table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$responses_table = TutorHelper_LMS_Free_Database::table( 'quiz_attempt_responses' );
		$updated = $wpdb->update(
			$attempts_table,
			array( 'tutor_feedback' => $feedback, 'feedback_updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => $attempt_id ),
			array( '%s', '%s' ),
			array( '%d' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Stores overall feedback against one tutor-owned immutable attempt.
		if ( false === $updated || ! $responses_table ) {
			wp_safe_redirect( self::submissions_url( 'quiz_feedback_error' ) );
			exit;
		}

		$existing_review = TutorHelper_LMS_Quiz_Attempts::reviewed_responses( $attempt_id );
		$manual_pending = false;
		foreach ( $manual_questions as $question_id => $available_marks ) {
			$posted_mark = isset( $question_marks[ $question_id ] ) && ! is_array( $question_marks[ $question_id ] ) ? trim( (string) $question_marks[ $question_id ] ) : '';
			if ( '' === $posted_mark ) {
				if ( 'manual_marked' !== sanitize_key( $existing_review[ $question_id ]['mark']['status'] ?? '' ) ) {
					$manual_pending = true;
				}
				continue;
			}
			if ( ! is_numeric( $posted_mark ) ) {
				wp_safe_redirect( self::submissions_url( 'quiz_invalid_mark' ) );
				exit;
			}
			$awarded = min( $available_marks, max( 0, (int) $posted_mark ) );
			$mark = array(
				'marks'          => $awarded,
				'available'      => $available_marks,
				'correct'        => null,
				'status'         => 'manual_marked',
				'feedback'       => '',
				'details'        => array(),
				'marking_source' => 'manual',
			);
			$saved = $wpdb->update(
				$responses_table,
				array( 'auto_mark_json' => wp_json_encode( $mark ), 'status' => 'manual_marked', 'updated_at' => current_time( 'mysql', true ) ),
				array( 'attempt_id' => $attempt_id, 'question_id' => $question_id ),
				array( '%s', '%s', '%s' ),
				array( '%d', '%d' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Stores one tutor-awarded mark for a submitted manual response.
			if ( false === $saved ) {
				wp_safe_redirect( self::submissions_url( 'quiz_feedback_error' ) );
				exit;
			}
		}

		foreach ( $enabled_question_feedback as $raw_question_id => $enabled ) {
			$question_id = absint( $raw_question_id );
			if ( empty( $enabled ) || ! in_array( $question_id, $allowed_question_ids, true ) ) {
				continue;
			}
			$value = isset( $question_feedback[ $raw_question_id ] ) && ! is_array( $question_feedback[ $raw_question_id ] ) ? wp_kses_post( $question_feedback[ $raw_question_id ] ) : '';
			$saved = $wpdb->update(
				$responses_table,
				array( 'tutor_feedback' => $value ),
				array( 'attempt_id' => $attempt_id, 'question_id' => $question_id ),
				array( '%s' ),
				array( '%d', '%d' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Stores tutor-only Question feedback override.
			if ( false === $saved ) {
				wp_safe_redirect( self::submissions_url( 'quiz_feedback_error' ) );
				exit;
			}
		}

		if ( ! empty( $_POST['release_results'] ) ) {
			if ( $manual_pending ) {
				wp_safe_redirect( self::submissions_url( 'quiz_manual_marking_pending' ) );
				exit;
			}
			$released = TutorHelper_LMS_Quiz_Attempts::release_results( $attempt_id );
			wp_safe_redirect( self::submissions_url( is_wp_error( $released ) ? 'quiz_release_error' : 'quiz_results_released' ) );
			exit;
		}

		wp_safe_redirect( self::submissions_url( 'quiz_feedback_saved' ) );
		exit;
	}

	/**
	 * Retrieve a completed Quiz attempt from a Course owned by the current tutor.
	 *
	 * @param int $attempt_id Quiz attempt ID.
	 * @return object|null
	 */
	private static function tutor_quiz_attempt( $attempt_id ) {
		global $wpdb;

		$attempts = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		if ( '' === $attempts || ! $attempt_id ) {
			return null;
		}

		$posts = $wpdb->posts;
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT attempts.*, course.post_title AS course_title, quiz.post_title AS quiz_title
				FROM {$attempts} attempts
				INNER JOIN {$posts} course ON course.ID = attempts.course_id
				LEFT JOIN {$posts} quiz ON quiz.ID = attempts.quiz_id
				WHERE attempts.id = %d AND course.post_author = %d AND course.post_type = %s AND attempts.status = %s",
				absint( $attempt_id ),
				get_current_user_id(),
				'tutorhelper_course',
				'completed'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- verifies Tutor ownership of one Quiz attempt.
	}

	/**
	 * Return whether a snapshot type is owned by the Premium manual workflow.
	 *
	 * @param string $type Question type.
	 * @return bool
	 */
	private static function is_manual_quiz_question_type( $type ) {
		return in_array( sanitize_key( $type ), array_values( array_unique( array_map( 'sanitize_key', (array) apply_filters( 'tutorhelper_lms_manual_question_types', array() ) ) ) ), true );
	}

	/**
	 * Extract safe private-file metadata from either a file-only response or a
	 * long-answer response with an optional attachment.
	 *
	 * @param mixed $answer Stored response.
	 * @return array
	 */
	private static function quiz_response_attachment( $answer ) {
		$file = is_array( $answer ) && isset( $answer['attachment'] ) ? $answer['attachment'] : $answer;
		if ( ! is_array( $file ) || 'private_file' !== (string) ( $file['kind'] ?? '' ) ) {
			return array();
		}
		$provider_file_id = sanitize_text_field( $file['provider_file_id'] ?? '' );
		$filename = sanitize_file_name( $file['filename'] ?? '' );
		if ( '' === $provider_file_id || '' === $filename ) {
			return array();
		}
		return array(
			'provider'         => sanitize_key( $file['provider'] ?? '' ),
			'provider_file_id' => $provider_file_id,
			'filename'         => $filename,
			'mime_type'        => sanitize_mime_type( $file['mime_type'] ?? '' ),
		);
	}

	/**
	 * Stream one private Quiz response file after tutor ownership and nonce checks.
	 *
	 * @param bool $preview Whether to request inline browser rendering.
	 * @return void
	 */
	private static function stream_quiz_file( $preview ) {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this file.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$attempt_id = isset( $_GET['attempt_id'] ) ? absint( $_GET['attempt_id'] ) : 0;
		$question_id = isset( $_GET['question_id'] ) ? absint( $_GET['question_id'] ) : 0;
		$action = $preview ? self::QUIZ_FILE_PREVIEW_ACTION : self::QUIZ_FILE_DOWNLOAD_ACTION;
		check_admin_referer( $action . '_' . $attempt_id . '_' . $question_id );
		$attempt = self::tutor_quiz_attempt( $attempt_id );
		$review = $attempt ? TutorHelper_LMS_Quiz_Attempts::reviewed_responses( $attempt_id ) : array();
		$file = self::quiz_response_attachment( $review[ $question_id ]['answer'] ?? '' );
		if ( ! $file || ( $preview && ! self::is_previewable_mime_type( $file['mime_type'] ) ) ) {
			wp_die( esc_html__( 'This file is not available.', 'tutorhelper-lms' ), '', array( 'response' => 404 ) );
		}
		$provider = TutorHelper_LMS_Storage_Registry::get( $file['provider'] );
		if ( ! $provider ) {
			wp_die( esc_html__( 'The storage provider for this file is unavailable.', 'tutorhelper-lms' ), '', array( 'response' => 503 ) );
		}
		$result = $provider->stream( $file['provider_file_id'], array( 'filename' => $file['filename'], 'mime_type' => $file['mime_type'], 'disposition' => $preview ? 'inline' : 'attachment' ) );
		if ( is_wp_error( $result ) ) {
			self::log_storage_failure( $file['provider'], $result->get_error_code() );
			wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 503 ) );
		}
		exit;
	}

	/** Download one tutor-authorised private Quiz response file. */
	public static function download_quiz_file() {
		self::stream_quiz_file( false );
	}

	/** Preview one tutor-authorised browser-previewable Quiz response file. */
	public static function preview_quiz_file() {
		self::stream_quiz_file( true );
	}

	private static function quiz_file_url( $action, $attempt_id, $question_id ) {
		$url = add_query_arg( array( 'action' => $action, 'attempt_id' => absint( $attempt_id ), 'question_id' => absint( $question_id ) ), admin_url( 'admin-post.php' ) );
		return wp_nonce_url( $url, $action . '_' . absint( $attempt_id ) . '_' . absint( $question_id ) );
	}

	private static function render_quiz_file_actions( $attempt, $question_id, $answer ) {
		$file = self::quiz_response_attachment( $answer );
		if ( ! $file ) {
			return;
		}
		$drive_url = self::google_drive_url( $file['provider'], $file['provider_file_id'] );
		$previewable = self::is_previewable_mime_type( $file['mime_type'] );
		$annotation_workspace = class_exists( 'TutorHelper_LMS_Quiz_Annotations' ) && TutorHelper_LMS_Quiz_Annotations::supports_file( $file );
		$preview_id = 'tutorhelper-lms-quiz-file-preview-' . absint( $attempt->id ) . '-' . absint( $question_id );
		$preview_url = self::quiz_file_url( self::QUIZ_FILE_PREVIEW_ACTION, $attempt->id, $question_id );
		echo '<div class="tutorhelper-lms-quiz__file-actions"><strong>' . esc_html( $file['filename'] ) . '</strong><div class="tutorhelper-lms-quiz__file-actions-buttons">';
		if ( $previewable && ! $annotation_workspace ) {
			echo '<button type="button" class="button tutorhelper-lms-quiz-review__file-action tutorhelper-lms-quiz-review__file-preview-toggle" data-tutorhelper-lms-quiz-file-preview="' . esc_attr( $preview_id ) . '" data-preview-url="' . esc_url( $preview_url ) . '" data-preview-title="' . esc_attr( sprintf( __( 'Preview: %s', 'tutorhelper-lms' ), $file['filename'] ) ) . '" aria-expanded="false">' . esc_html__( 'Preview file', 'tutorhelper-lms' ) . '</button>';
		}
		if ( $annotation_workspace ) {
			TutorHelper_LMS_Quiz_Annotations::render_tutor_trigger( $attempt, $question_id, $file );
		}
		if ( $drive_url ) {
			echo '<a class="button tutorhelper-lms-quiz-review__file-action" href="' . esc_url( $drive_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Open in Google Drive', 'tutorhelper-lms' ) . '</a>';
		}
		echo '<a class="button tutorhelper-lms-quiz-review__file-action" href="' . esc_url( self::quiz_file_url( self::QUIZ_FILE_DOWNLOAD_ACTION, $attempt->id, $question_id ) ) . '">' . esc_html__( 'Download file', 'tutorhelper-lms' ) . '</a></div>';
		if ( $annotation_workspace ) {
			TutorHelper_LMS_Quiz_Annotations::render_tutor_preview( $attempt, $question_id, $file );
		}
		if ( $previewable && ! $annotation_workspace ) {
			echo '<div id="' . esc_attr( $preview_id ) . '" class="tutorhelper-lms-quiz-review__file-preview" hidden></div>';
		}
		echo '</div>';
	}

	/**
	 * Render tutor-visible objective answers, automatic marking and feedback controls.
	 *
	 * @param object $attempt Completed tutor-owned attempt.
	 * @return void
	 */
	private static function render_quiz_review_workspace( $attempt ) {
		$snapshot  = json_decode( (string) $attempt->snapshot_json, true );
		$quiz      = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
		$questions = is_array( $snapshot['questions'] ?? null ) ? $snapshot['questions'] : array();
		$review    = TutorHelper_LMS_Quiz_Attempts::reviewed_responses( $attempt->id );
		$score     = TutorHelper_LMS_Quiz_Attempts::attempt_score( $attempt->id );
		$released  = TutorHelper_LMS_Quiz_Attempts::results_released( $attempt );
		$modal_id  = 'tutorhelper-lms-quiz-review-' . absint( $attempt->id );
		$feedback_id = 'tutorhelper-lms-quiz-feedback-' . absint( $attempt->id );
		$student   = get_userdata( absint( $attempt->student_user_id ) );
		$result_label = __( 'Awaiting marking', 'tutorhelper-lms' );
		if ( 'pass' === $score['outcome'] ) {
			$result_label = __( 'Pass', 'tutorhelper-lms' );
		} elseif ( 'fail' === $score['outcome'] ) {
			$result_label = __( 'Fail', 'tutorhelper-lms' );
		}
		?>
		<dialog id="<?php echo esc_attr( $modal_id ); ?>" class="tutorhelper-lms-modal tutorhelper-lms-preview-modal tutorhelper-lms-quiz-review-modal" aria-labelledby="<?php echo esc_attr( $modal_id . '-title' ); ?>">
			<div class="tutorhelper-lms-modal__header"><h2 id="<?php echo esc_attr( $modal_id . '-title' ); ?>"><?php echo esc_html( $quiz['title'] ?? $attempt->quiz_title ?? __( 'Quiz review', 'tutorhelper-lms' ) ); ?></h2><button type="button" class="button-link tutorhelper-lms-modal__close" data-tutorhelper-lms-modal-close aria-label="<?php esc_attr_e( 'Close Quiz review', 'tutorhelper-lms' ); ?>">×</button></div>
			<div class="tutorhelper-lms-modal__body">
				<p><strong><?php esc_html_e( 'Student:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( $student ? $student->display_name : __( 'Unknown student', 'tutorhelper-lms' ) ); ?> · <strong><?php esc_html_e( 'Attempt:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( absint( $attempt->attempt_number ) ); ?> · <strong><?php esc_html_e( 'Time taken:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( TutorHelper_LMS_Quiz_Attempts::time_taken_label( $attempt ) ); ?> · <strong><?php esc_html_e( 'Result:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( sprintf( _n( '%1$d / %2$d mark', '%1$d / %2$d marks', absint( $score['available'] ), 'tutorhelper-lms' ), absint( $score['marks'] ), absint( $score['available'] ) ) ); ?> · <?php echo esc_html( $result_label ); ?></p>
				<?php do_action( 'tutorhelper_lms_quiz_attempt_review_meta', $attempt, $snapshot ); ?>
				<p class="description"><?php echo esc_html( $released ? __( 'Results have been released to the student.', 'tutorhelper-lms' ) : __( 'Results are currently private to the tutor.', 'tutorhelper-lms' ) ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-quiz-review-form">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::QUIZ_REVIEW_ACTION ); ?>" />
					<input type="hidden" name="attempt_id" value="<?php echo esc_attr( $attempt->id ); ?>" />
					<?php wp_nonce_field( self::QUIZ_REVIEW_ACTION . '_' . absint( $attempt->id ) ); ?>
					<ol class="tutorhelper-lms-quiz__questions tutorhelper-lms-quiz__questions--review">
						<?php foreach ( $questions as $index => $question ) : ?>
							<?php
							$question_id = absint( $question['question_id'] ?? 0 );
							$definition = json_decode( (string) ( $question['definition_json'] ?? '' ), true );
							$definition = is_array( $definition ) ? $definition : array();
							$type = sanitize_key( $definition['question_type'] ?? '' );
							$is_manual = self::is_manual_quiz_question_type( $type );
							$response = $review[ $question_id ] ?? array( 'answer' => '', 'mark' => array( 'status' => 'ungraded' ) );
							$mark = is_array( $response['mark'] ?? null ) ? $response['mark'] : array();
							$status = sanitize_key( $mark['status'] ?? ( $response['status'] ?? 'ungraded' ) );
							$label = __( 'Incorrect', 'tutorhelper-lms' );
							if ( 'correct' === $status ) {
								$label = __( 'Correct', 'tutorhelper-lms' );
							} elseif ( 'partial' === $status ) {
								$label = __( 'Partially correct', 'tutorhelper-lms' );
							} elseif ( 'awaiting_marking' === $status ) {
								$label = __( 'Tutor marking needed', 'tutorhelper-lms' );
							} elseif ( 'manual_marked' === $status ) {
								$label = __( 'Tutor marked', 'tutorhelper-lms' );
							} elseif ( 'ungraded' === $status ) {
								$label = __( 'Recorded (ungraded)', 'tutorhelper-lms' );
							}
							$available_marks = absint( $mark['available'] ?? 0 );
							$earned_marks = absint( $mark['marks'] ?? 0 );
							$mark_label = sprintf( _n( '%1$d / %2$d mark', '%1$d / %2$d marks', $available_marks, 'tutorhelper-lms' ), $earned_marks, $available_marks );
							$display_feedback = (string) ( $mark['feedback'] ?? '' );
							$stored_feedback = (string) ( $response['tutor_feedback'] ?? '' );
							$feedback_field_id = 'tutorhelper-lms-quiz-question-feedback-' . absint( $attempt->id ) . '-' . $question_id;
							?>
							<li class="tutorhelper-lms-quiz__question tutorhelper-lms-quiz__question--review is-<?php echo esc_attr( $status ); ?>">
								<h4><span class="tutorhelper-lms-quiz__feedback-label"><?php echo esc_html( sprintf( __( 'Question %1$d · %2$s', 'tutorhelper-lms' ), $index + 1, $label ) ); ?>&nbsp;:</span><span class="tutorhelper-lms-quiz__marks">&nbsp;<?php echo esc_html( $mark_label ); ?></span></h4>
								<?php if ( 'cloze' !== $type ) : ?><div class="tutorhelper-lms-quiz__prompt"><?php echo wp_kses_post( apply_filters( 'the_content', $definition['prompt'] ?? '' ) ); ?></div><?php endif; ?>
								<?php TutorHelper_LMS_Learner_Access::render_quiz_read_only_answer( $definition, $type, $response['answer'] ?? '', $status, $mark, $question_id ); ?>
								<?php if ( $is_manual && '' !== trim( (string) ( $definition['settings']['marking_guidance'] ?? '' ) ) ) : ?>
									<details class="tutorhelper-lms-quiz__marking-guidance">
										<summary><?php esc_html_e( 'Show marking guidance', 'tutorhelper-lms' ); ?></summary>
										<div><?php echo wp_kses_post( wpautop( (string) $definition['settings']['marking_guidance'] ) ); ?></div>
									</details>
								<?php endif; ?>
								<?php if ( $is_manual ) : ?>
									<?php self::render_quiz_file_actions( $attempt, $question_id, $response['answer'] ?? '' ); ?>
									<p><label for="<?php echo esc_attr( 'tutorhelper-lms-quiz-question-mark-' . $attempt->id . '-' . $question_id ); ?>"><strong><?php esc_html_e( 'Award mark', 'tutorhelper-lms' ); ?></strong></label> <input id="<?php echo esc_attr( 'tutorhelper-lms-quiz-question-mark-' . $attempt->id . '-' . $question_id ); ?>" type="number" min="0" max="<?php echo esc_attr( $available_marks ); ?>" step="1" name="question_marks[<?php echo esc_attr( $question_id ); ?>]" value="<?php echo esc_attr( 'manual_marked' === $status ? $earned_marks : '' ); ?>" data-tutorhelper-lms-question-mark-attempt="<?php echo esc_attr( $attempt->id ); ?>" data-tutorhelper-lms-question-mark-question="<?php echo esc_attr( $question_id ); ?>" /> / <?php echo esc_html( sprintf( _n( '%d mark', '%d marks', $available_marks, 'tutorhelper-lms' ), $available_marks ) ); ?></p>
									<input type="hidden" name="question_feedback_enabled[<?php echo esc_attr( $question_id ); ?>]" value="1" />
									<div class="tutorhelper-lms-quiz-review__question-feedback-editor">
										<label for="<?php echo esc_attr( $feedback_field_id ); ?>"><?php esc_html_e( 'Feedback for this response', 'tutorhelper-lms' ); ?></label>
										<textarea id="<?php echo esc_attr( $feedback_field_id ); ?>" class="large-text" rows="6" name="question_feedback[<?php echo esc_attr( $question_id ); ?>]" data-tutorhelper-lms-question-feedback-editor><?php echo esc_textarea( $stored_feedback ); ?></textarea>
									</div>
								<?php elseif ( in_array( $status, array( 'correct', 'partial', 'incorrect' ), true ) ) : ?>
									<div class="tutorhelper-lms-quiz__feedback tutorhelper-lms-quiz-review__question-feedback" data-tutorhelper-lms-question-feedback-display="<?php echo esc_attr( $feedback_field_id ); ?>"><?php if ( '' !== trim( $display_feedback ) ) : ?><?php echo wp_kses_post( wpautop( $display_feedback ) ); ?><?php else : ?><p><?php esc_html_e( 'No automatic feedback has been set for this response.', 'tutorhelper-lms' ); ?></p><?php endif; ?></div>
									<p><button type="button" class="button tutorhelper-lms-quiz-review__edit-feedback" data-tutorhelper-lms-edit-question-feedback="<?php echo esc_attr( $feedback_field_id ); ?>"><?php esc_html_e( 'Edit feedback', 'tutorhelper-lms' ); ?></button></p>
									<input type="hidden" name="question_feedback_enabled[<?php echo esc_attr( $question_id ); ?>]" value="<?php echo '' !== trim( $stored_feedback ) ? '1' : ''; ?>" data-tutorhelper-lms-question-feedback-enabled="<?php echo esc_attr( $feedback_field_id ); ?>" />
									<div class="tutorhelper-lms-quiz-review__question-feedback-editor" id="<?php echo esc_attr( $feedback_field_id . '-editor' ); ?>" hidden>
										<label for="<?php echo esc_attr( $feedback_field_id ); ?>"><?php esc_html_e( 'Personalised feedback for this student', 'tutorhelper-lms' ); ?></label>
										<textarea id="<?php echo esc_attr( $feedback_field_id ); ?>" class="large-text" rows="6" name="question_feedback[<?php echo esc_attr( $question_id ); ?>]" data-tutorhelper-lms-question-feedback-editor><?php echo esc_textarea( $display_feedback ); ?></textarea>
									</div>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ol>
					<p><label for="<?php echo esc_attr( $feedback_id ); ?>"><?php esc_html_e( 'Overall tutor feedback', 'tutorhelper-lms' ); ?></label><textarea id="<?php echo esc_attr( $feedback_id ); ?>" class="large-text" rows="8" name="tutor_feedback" data-tutorhelper-lms-editor><?php echo esc_textarea( $attempt->tutor_feedback ?? '' ); ?></textarea></p>
					<p class="description"><?php esc_html_e( 'Save feedback without release to keep it private. Releasing makes the automatic marks, question feedback and this feedback visible to the student.', 'tutorhelper-lms' ); ?></p>
					<p class="tutorhelper-lms-quiz-review__actions"><button type="submit" class="button tutorhelper-lms-submit-button"><?php esc_html_e( 'Save feedback', 'tutorhelper-lms' ); ?></button><?php if ( ! $released ) : ?> <button type="submit" name="release_results" value="1" class="button tutorhelper-lms-submit-button"><?php esc_html_e( 'Save & release Quiz', 'tutorhelper-lms' ); ?></button><?php endif; ?></p>
				</form>
			</div>
		</dialog>
		<?php
	}

	/**
	 * Return Learning Hub submissions URL with a compact notice key.
	 *
	 * @param string $notice Notice key.
	 * @return string
	 */
	private static function submissions_url( $notice = '' ) {
		$args = array( 'page' => TutorHelper_LMS_Learning_Hub::PAGE_SLUG, 'tab' => 'submissions' );
		if ( '' !== $notice ) {
			$args['tutorhelper_lms_quiz_review'] = sanitize_key( $notice );
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/** Load the tutor marking workspace only for an assigned submission. */
	public static function ajax_load_marking() {
		check_ajax_referer( self::MARK_LOAD_ACTION, 'nonce' );
		$submission = self::tutor_submission( isset( $_POST['submission_id'] ) ? absint( $_POST['submission_id'] ) : 0 );
		if ( ! $submission ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to mark this submission.', 'tutorhelper-lms' ) ), 403 );
		}
		ob_start();
		self::render_marking_workspace( $submission );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/** Save tutor feedback, outcome and an optional released mark. */
	public static function ajax_save_marking() {
		check_ajax_referer( self::MARK_SAVE_ACTION, 'nonce' );
		$submission = self::tutor_submission( isset( $_POST['submission_id'] ) ? absint( $_POST['submission_id'] ) : 0 );
		if ( ! $submission ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to mark this submission.', 'tutorhelper-lms' ) ), 403 );
		}
		$assignment = self::assignment_by_id( $submission->assignment_id );
		$outcome = isset( $_POST['outcome'] ) ? sanitize_key( wp_unslash( $_POST['outcome'] ) ) : 'pending';
		if ( ! in_array( $outcome, array( 'pending', 'complete', 'resubmission' ), true ) ) {
			$outcome = 'pending';
		}
		$release = ! empty( $_POST['release_feedback'] );
		$feedback = isset( $_POST['feedback'] ) ? wp_kses_post( wp_unslash( $_POST['feedback'] ) ) : '';
		$awarded = null;
		if ( $assignment && 'marked' === $assignment->assessment_type && isset( $_POST['awarded_mark'] ) && '' !== $_POST['awarded_mark'] ) {
			$awarded = (float) wp_unslash( $_POST['awarded_mark'] );
			if ( $awarded < 0 || ( null !== $assignment->max_mark && $awarded > (float) $assignment->max_mark ) ) {
				wp_send_json_error( array( 'message' => __( 'The mark must be between zero and the assignment maximum.', 'tutorhelper-lms' ) ), 400 );
			}
		}
		global $wpdb;
		$marks = TutorHelper_LMS_Database::table( 'marks' );
		$now = current_time( 'mysql', true );
		$existing = self::mark_for_submission( $submission->id );
		$data = array( 'marker_user_id' => get_current_user_id(), 'awarded_mark' => $awarded, 'feedback' => $feedback, 'status' => $release ? 'released' : 'draft', 'outcome' => $outcome, 'marked_at' => $now, 'released_at' => $release ? ( $existing && $existing->released_at ? $existing->released_at : $now ) : null, 'updated_at' => $now );
		if ( $release && $assignment && 'marked' === $assignment->assessment_type && null !== $awarded ) {
			// Once released, a grading snapshot is a historic record rather than a live Course setting.
			$data['grading_scheme_snapshot'] = $existing && ! empty( $existing->grading_scheme_snapshot )
				? $existing->grading_scheme_snapshot
				: wp_json_encode( self::grade_snapshot( $assignment, $awarded ) );
		}
		if ( $existing ) {
			$wpdb->update( $marks, $data, array( 'submission_id' => $submission->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Updates one tutor-owned mark.
		} else {
			$data['submission_id'] = $submission->id;
			$data['created_at'] = $now;
			$wpdb->insert( $marks, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds one tutor-owned mark.
		}
		if ( 'resubmission' === $outcome ) {
			$wpdb->update( TutorHelper_LMS_Database::table( 'submissions' ), array( 'status' => 'reopened', 'reopened_at' => $now, 'updated_at' => $now ), array( 'id' => $submission->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update( TutorHelper_LMS_Database::table( 'assignments' ), array( 'status' => 'reopened', 'updated_at' => $now ), array( 'id' => $submission->assignment_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		} else {
			$wpdb->update( TutorHelper_LMS_Database::table( 'submissions' ), array( 'status' => 'marked', 'updated_at' => $now ), array( 'id' => $submission->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Marks the tutor-reviewed attempt without requiring feedback release.
		}
		$updated_submission = self::tutor_submission( $submission->id );
		$updated_mark       = self::mark_for_submission( $submission->id );
		$table_row          = (object) array(
			'submission_status'       => $updated_submission ? $updated_submission->status : $submission->status,
			'awarded_mark'            => $updated_mark ? $updated_mark->awarded_mark : null,
			'assessment_type'          => $assignment ? $assignment->assessment_type : '',
			'max_mark'                 => $assignment ? $assignment->max_mark : null,
			'grading_scheme_snapshot'  => $updated_mark ? $updated_mark->grading_scheme_snapshot : '',
		);
		ob_start();
		self::render_tutor_submission_status( $table_row );
		$status_html = (string) ob_get_clean();
		wp_send_json_success(
			array(
				'message'       => $release ? __( 'Feedback released to the student.', 'tutorhelper-lms' ) : __( 'Marking draft saved.', 'tutorhelper-lms' ),
				'submissionId'  => absint( $submission->id ),
				'statusHtml'    => $status_html,
				'actionsHtml'   => '<span aria-hidden="true">—</span>',
			)
		);
	}

	/** Render the common modal body used from Learning Hub and Bookings Hub. */
	private static function render_marking_workspace( $submission ) {
		$assignment = self::assignment_by_id( $submission->assignment_id );
		$mark = self::mark_for_submission( $submission->id );
		$modal_id = 'tutorhelper-lms-marking-' . absint( $submission->id );
		$feedback_id = 'tutorhelper-lms-feedback-' . absint( $submission->id );
		$file = self::file_for_submission( $submission->id );
		?>
		<dialog id="<?php echo esc_attr( $modal_id ); ?>" class="tutorhelper-lms-modal tutorhelper-lms-preview-modal" aria-labelledby="<?php echo esc_attr( $modal_id . '-title' ); ?>">
		<div class="tutorhelper-lms-modal__header"><h2 id="<?php echo esc_attr( $modal_id . '-title' ); ?>"><?php echo esc_html( $assignment ? $assignment->title : __( 'Homework marking', 'tutorhelper-lms' ) ); ?></h2><button type="button" class="button-link tutorhelper-lms-modal__close" data-tutorhelper-lms-modal-close aria-label="<?php esc_attr_e( 'Close marking workspace', 'tutorhelper-lms' ); ?>">×</button></div>
		<div class="tutorhelper-lms-modal__body tutorhelper-lms-marking-grid">
			<div class="tutorhelper-lms-marking-preview">
				<?php if ( $assignment ) : ?><section class="tutorhelper-lms-homework-details"><h3><?php esc_html_e( 'Homework details', 'tutorhelper-lms' ); ?></h3><?php if ( $assignment->instructions ) : ?><p><?php echo esc_html( $assignment->instructions ); ?></p><?php endif; ?><?php if ( $assignment->course_id ) : ?><p><strong><?php esc_html_e( 'Academic course:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( get_the_title( $assignment->course_id ) ); ?></p><?php endif; ?><?php if ( 'marked' === $assignment->assessment_type && null !== $assignment->max_mark ) : ?><p><strong><?php esc_html_e( 'Maximum mark:', 'tutorhelper-lms' ); ?></strong> <?php echo esc_html( self::mark_format( $assignment->max_mark ) ); ?></p><?php endif; ?></section><?php endif; ?>
				<?php self::render_submission_preview( $submission, $file, true ); ?>
				<?php if ( class_exists( 'TutorHelper_LMS_Homework_Annotations' ) && TutorHelper_LMS_Homework_Annotations::supports_file( $file ) ) : ?>
					<p class="tutorhelper-lms-homework-annotation-actions"><?php TutorHelper_LMS_Homework_Annotations::render_trigger( $submission, $file ); ?></p>
				<?php endif; ?>
			</div>
			<form class="tutorhelper-lms-marking-form" data-tutorhelper-lms-marking-form<?php echo ( $file && 'application/pdf' === sanitize_mime_type( $file->mime_type ) && class_exists( 'TutorHelper_LMS_Homework_Annotations' ) && TutorHelper_LMS_Homework_Annotations::supports_file( $file ) ) ? ' data-tutorhelper-lms-homework-pdf' : ''; ?>>
				<input type="hidden" name="submission_id" value="<?php echo esc_attr( $submission->id ); ?>" />
				<p><label for="<?php echo esc_attr( $feedback_id ); ?>"><?php esc_html_e( 'Feedback', 'tutorhelper-lms' ); ?></label><textarea id="<?php echo esc_attr( $feedback_id ); ?>" class="large-text" rows="10" data-tutorhelper-lms-editor><?php echo esc_textarea( $mark ? $mark->feedback : '' ); ?></textarea></p>
				<?php if ( $assignment && 'marked' === $assignment->assessment_type ) : ?><p><label><?php esc_html_e( 'Mark', 'tutorhelper-lms' ); ?> <input type="number" name="awarded_mark" min="0" max="<?php echo esc_attr( $assignment->max_mark ); ?>" step="0.01" value="<?php echo esc_attr( $mark && null !== $mark->awarded_mark ? $mark->awarded_mark : '' ); ?>" /> / <?php echo esc_html( self::mark_format( $assignment->max_mark ) ); ?></label></p><?php $grade_preview = $mark && null !== $mark->awarded_mark ? self::grade_snapshot( $assignment, $mark->awarded_mark, $mark->grading_scheme_snapshot ) : array(); ?><p class="description tutorhelper-lms-live-grade" data-tutorhelper-lms-live-grade data-max-mark="<?php echo esc_attr( $assignment->max_mark ); ?>" data-grading-context="<?php echo esc_attr( wp_json_encode( self::course_grading_context( $assignment->course_id ) ) ); ?>"><strong><?php esc_html_e( 'Academic result:', 'tutorhelper-lms' ); ?></strong> <span data-tutorhelper-lms-live-grade-value><?php echo esc_html( $grade_preview ? self::grade_result_label( $grade_preview ) : __( 'Enter a mark to calculate the percentage and grade.', 'tutorhelper-lms' ) ); ?></span></p><?php endif; ?>
				<p><label for="<?php echo esc_attr( $feedback_id . '-outcome' ); ?>"><?php esc_html_e( 'Submission status', 'tutorhelper-lms' ); ?></label><select id="<?php echo esc_attr( $feedback_id . '-outcome' ); ?>" name="outcome"><option value="pending" <?php selected( $mark ? $mark->outcome : 'pending', 'pending' ); ?>><?php esc_html_e( 'Awaiting marking', 'tutorhelper-lms' ); ?></option><option value="complete" <?php selected( $mark ? $mark->outcome : '', 'complete' ); ?>><?php esc_html_e( 'Complete', 'tutorhelper-lms' ); ?></option><option value="resubmission" <?php selected( $mark ? $mark->outcome : '', 'resubmission' ); ?>><?php esc_html_e( 'Request resubmission', 'tutorhelper-lms' ); ?></option></select></p>
				<p><label><input type="checkbox" name="release_feedback" value="1" <?php checked( $mark && 'released' === $mark->status ); ?> /> <?php esc_html_e( 'Release feedback to the student now', 'tutorhelper-lms' ); ?></label></p>
				<p class="description"><?php esc_html_e( 'Save without release to keep feedback private while you continue marking.', 'tutorhelper-lms' ); ?></p>
				<p class="tutorhelper-lms-marking-status" data-tutorhelper-lms-marking-status aria-live="polite"></p>
				<p><button type="submit" class="button button-primary tutorhelper-action-button"><?php esc_html_e( 'Save marking', 'tutorhelper-lms' ); ?></button></p>
			</form>
		</div></dialog>
		<?php
	}

	/** Render an authenticated preview without exposing provider URLs. */
	private static function render_submission_preview( $submission, $file, $tutor_view = false ) {
		if ( 'link' === $submission->submission_type && $submission->link_url ) {
			echo '<p><a class="button button-secondary tutorhelper-action-button" href="' . esc_url( $submission->link_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Open submitted link', 'tutorhelper-lms' ) . '</a></p>';
			return;
		}
		if ( ! $file ) { echo '<p>' . esc_html__( 'No file is available for preview.', 'tutorhelper-lms' ) . '</p>'; return; }
		$name = $file->original_filename;
		$is_markable_pdf = 'application/pdf' === sanitize_mime_type( $file->mime_type ) && class_exists( 'TutorHelper_LMS_Homework_Annotations' ) && TutorHelper_LMS_Homework_Annotations::supports_file( $file );
		$marked_file = class_exists( 'TutorHelper_LMS_Marked_Files' ) ? TutorHelper_LMS_Marked_Files::record_for( 'homework', $submission->id, 0 ) : null;
		if ( $is_markable_pdf && $marked_file ) {
			echo '<p><strong>' . esc_html__( 'Released marked PDF', 'tutorhelper-lms' ) . '</strong></p><iframe class="tutorhelper-lms-preview-frame" src="' . esc_url( TutorHelper_LMS_Marked_Files::preview_url( 'homework', $submission->id, 0 ) ) . '" title="' . esc_attr( $marked_file->original_filename ) . '"></iframe>';
		} elseif ( $is_markable_pdf ) {
			TutorHelper_LMS_Homework_Annotations::render_preview( $submission, $file );
		} elseif ( self::is_previewable_mime_type( $file->mime_type ) ) {
			if ( in_array( $file->mime_type, array( 'image/jpeg', 'image/png' ), true ) ) {
				$image_id = 'tutorhelper-lms-preview-image-' . absint( $submission->id );
				echo '<img id="' . esc_attr( $image_id ) . '" class="tutorhelper-lms-preview-image is-zoomable" src="' . esc_url( self::preview_url( $submission->id ) ) . '" alt="' . esc_attr( $name ) . '" />';
				echo '<p class="tutorhelper-lms-preview-zoom"><label for="' . esc_attr( $image_id . '-zoom' ) . '">' . esc_html__( 'Zoom preview', 'tutorhelper-lms' ) . '</label> <input id="' . esc_attr( $image_id . '-zoom' ) . '" type="range" min="100" max="300" step="25" value="100" data-tutorhelper-lms-image-zoom="' . esc_attr( $image_id ) . '" /></p>';
			} else { echo '<iframe class="tutorhelper-lms-preview-frame" src="' . esc_url( self::preview_url( $submission->id ) ) . '" title="' . esc_attr( $name ) . '"></iframe>'; }
		} else { echo '<p>' . esc_html__( 'Word documents need to be downloaded to view securely.', 'tutorhelper-lms' ) . '</p>'; }
		echo '<p><a class="button button-secondary tutorhelper-action-button" href="' . esc_url( self::download_url( $submission->id ) ) . '">' . esc_html__( 'Download homework', 'tutorhelper-lms' ) . '</a>';
		if ( $tutor_view ) {
			$drive_url = self::google_drive_url( $submission->storage_provider, $submission->provider_file_id );
			if ( $drive_url ) { echo ' <a class="button button-secondary tutorhelper-action-button" href="' . esc_url( $drive_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View in Google Drive', 'tutorhelper-lms' ) . '</a>'; }
		}
		echo '</p>';
	}

	/** Return related LMS data for a single submission. */
	private static function assignment_by_id( $assignment_id ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . TutorHelper_LMS_Database::table( 'assignments' ) . ' WHERE id = %d LIMIT 1', absint( $assignment_id ) ) ); }
	private static function mark_for_submission( $submission_id ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . TutorHelper_LMS_Database::table( 'marks' ) . ' WHERE submission_id = %d LIMIT 1', absint( $submission_id ) ) ); }
	private static function file_for_submission( $submission_id ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . TutorHelper_LMS_Database::table( 'submission_files' ) . ' WHERE submission_id = %d LIMIT 1', absint( $submission_id ) ) ); }

	/**
	 * Securely stream a private file to its owner or assigned tutor.
	 *
	 * @return void
	 */
	public static function download() {
		$submission_id = isset( $_GET['submission_id'] ) ? absint( $_GET['submission_id'] ) : 0;
		check_admin_referer( self::DOWNLOAD_ACTION . '_' . $submission_id );

		global $wpdb;
		$submissions = TutorHelper_LMS_Database::table( 'submissions' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$files       = TutorHelper_LMS_Database::table( 'submission_files' );
		$row         = $wpdb->get_row( $wpdb->prepare( "SELECT s.*, a.student_user_id, a.tutor_user_id, f.original_filename, f.mime_type FROM {$submissions} s INNER JOIN {$assignments} a ON a.id = s.assignment_id INNER JOIN {$files} f ON f.submission_id = s.id WHERE s.id = %d LIMIT 1", $submission_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorises and retrieves one private file.

		if ( ! $row || 'file' !== $row->submission_type || ! self::can_access_submission( $row ) ) {
			wp_die( esc_html__( 'You do not have permission to download this file.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		$provider = TutorHelper_LMS_Storage_Registry::get( $row->storage_provider );
		if ( ! $provider ) {
			wp_die( esc_html__( 'The storage provider for this file is unavailable.', 'tutorhelper-lms' ), '', array( 'response' => 503 ) );
		}

		$result = $provider->stream( $row->provider_file_id, array( 'filename' => $row->original_filename, 'mime_type' => $row->mime_type ) );
		if ( is_wp_error( $result ) ) {
			self::log_storage_failure( $row->storage_provider, $result->get_error_code() );
			wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 503 ) );
		}

		exit;
	}

	/**
	 * Securely stream a browser-previewable private file to its owner or assigned tutor.
	 *
	 * @return void
	 */
	public static function preview() {
		$submission_id = isset( $_GET['submission_id'] ) ? absint( $_GET['submission_id'] ) : 0;
		check_admin_referer( self::PREVIEW_ACTION . '_' . $submission_id );

		global $wpdb;
		$submissions = TutorHelper_LMS_Database::table( 'submissions' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$files       = TutorHelper_LMS_Database::table( 'submission_files' );
		$row         = $wpdb->get_row( $wpdb->prepare( "SELECT s.*, a.student_user_id, a.tutor_user_id, f.original_filename, f.mime_type FROM {$submissions} s INNER JOIN {$assignments} a ON a.id = s.assignment_id INNER JOIN {$files} f ON f.submission_id = s.id WHERE s.id = %d LIMIT 1", $submission_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorises and retrieves one previewable private file.

		if ( ! $row || 'file' !== $row->submission_type || ! self::can_access_submission( $row ) || ! self::is_previewable_mime_type( $row->mime_type ) ) {
			wp_die( esc_html__( 'This file cannot be previewed.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		$provider = TutorHelper_LMS_Storage_Registry::get( $row->storage_provider );
		if ( ! $provider ) {
			wp_die( esc_html__( 'The storage provider for this file is unavailable.', 'tutorhelper-lms' ), '', array( 'response' => 503 ) );
		}

		$result = $provider->stream( $row->provider_file_id, array( 'filename' => $row->original_filename, 'mime_type' => $row->mime_type, 'disposition' => 'inline' ) );
		if ( is_wp_error( $result ) ) {
			self::log_storage_failure( $row->storage_provider, $result->get_error_code() );
			wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 503 ) );
		}

		exit;
	}

	/**
	 * Validate and store one uploaded file through the selected private provider.
	 *
	 * @param object $assignment Assignment.
	 * @param array  $upload Uploaded file array.
	 * @return array
	 */
	private static function store_file( $assignment, $upload ) {
		if ( UPLOAD_ERR_OK !== (int) $upload['error'] || ! is_uploaded_file( $upload['tmp_name'] ) ) {
			self::fail( __( 'The uploaded file could not be accepted. Please try again.', 'tutorhelper-lms' ) );
		}

		if ( (int) $upload['size'] < 1 || (int) $upload['size'] > TutorHelper_LMS_Private_Storage::effective_upload_limit() ) {
			self::fail( __( 'This file exceeds the configured upload limit.', 'tutorhelper-lms' ) );
		}

		$allowed = array(
			'pdf'  => 'application/pdf',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'jpg|jpeg' => 'image/jpeg',
			'png'  => 'image/png',
		);
		$check = wp_check_filetype_and_ext( $upload['tmp_name'], sanitize_file_name( $upload['name'] ), $allowed );
		if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
			self::fail( __( 'Use a PDF, DOCX, JPG or PNG file.', 'tutorhelper-lms' ) );
		}

		$provider = self::preferred_provider();
		if ( ! $provider ) {
			self::fail( __( 'Private file uploads are not currently available. You can submit an HTTPS shared-document link instead.', 'tutorhelper-lms' ), 503 );
		}

		$stored = $provider->store( $upload, array( 'assignment_id' => $assignment->id, 'student_user_id' => $assignment->student_user_id ) );
		if ( is_wp_error( $stored ) ) {
			self::log_storage_failure( $provider->get_id(), $stored->get_error_code() );
			self::fail( $stored->get_error_message(), 503 );
		}

		return array(
			'provider'         => $provider->get_id(),
			'provider_file_id' => sanitize_text_field( $stored['provider_file_id'] ),
			'storage_key'      => sanitize_text_field( $stored['storage_key'] ),
			'original_filename'=> sanitize_file_name( $upload['name'] ),
			'mime_type'        => sanitize_mime_type( $check['type'] ),
			'file_size'        => absint( $upload['size'] ),
			'file_hash'        => (string) hash_file( 'sha256', $upload['tmp_name'] ),
		);
	}

	/**
	 * Save file metadata after provider storage succeeds.
	 *
	 * @param object      $assignment Assignment.
	 * @param object|null $submission Editable submission.
	 * @param array       $stored Stored file metadata.
	 * @param string      $intent draft or submitted.
	 * @return void
	 */
	private static function save_file_submission( $assignment, $submission, $stored, $intent ) {
		$submission_id = self::upsert_submission( $assignment, $submission, array(
			'submission_type'   => 'file',
			'storage_provider'  => $stored['provider'],
			'provider_file_id'  => $stored['provider_file_id'],
			'link_url'          => '',
		), $intent );

		global $wpdb;
		$files = TutorHelper_LMS_Database::table( 'submission_files' );
		$wpdb->delete( $files, array( 'submission_id' => $submission_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Replaces metadata for the editable draft/revision file.
		$wpdb->insert( $files, array(
			'submission_id'     => $submission_id,
			'original_filename' => $stored['original_filename'],
			'storage_key'       => $stored['storage_key'],
			'mime_type'         => $stored['mime_type'],
			'file_size'         => $stored['file_size'],
			'file_hash'         => $stored['file_hash'],
			'created_at'        => current_time( 'mysql', true ),
		) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Stores only private-file metadata.

		$record = TutorHelper_LMS_Private_Files::sync_submission_file( $submission_id, $assignment->student_user_id, $stored );
		if ( is_wp_error( $record ) ) {
			self::log_storage_failure( $stored['provider'], $record->get_error_code() );
		}
	}

	/**
	 * Save an HTTPS shared-document link.
	 *
	 * @param object      $assignment Assignment.
	 * @param object|null $submission Editable submission.
	 * @param string      $link Validated link.
	 * @param string      $intent draft or submitted.
	 * @return void
	 */
	private static function save_link_submission( $assignment, $submission, $link, $intent ) {
		$submission_id = self::upsert_submission( $assignment, $submission, array(
			'submission_type'  => 'link',
			'storage_provider' => 'shared_link',
			'provider_file_id' => '',
			'link_url'         => $link,
		), $intent );

		global $wpdb;
		$wpdb->delete( TutorHelper_LMS_Database::table( 'submission_files' ), array( 'submission_id' => $submission_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Link submissions do not retain file metadata.
	}

	/**
	 * Insert or update the one editable draft/revision attempt.
	 *
	 * @param object      $assignment Assignment.
	 * @param object|null $submission Editable submission.
	 * @param array       $data Submission data.
	 * @param string      $intent draft or submitted.
	 * @return int
	 */
	private static function upsert_submission( $assignment, $submission, $data, $intent ) {
		global $wpdb;

		$now    = current_time( 'mysql', true );
		$status = 'submitted' === $intent ? 'submitted' : 'draft';
		$data   = array_merge( $data, array(
			'status'       => $status,
			'submitted_at' => 'submitted' === $status ? $now : null,
			'updated_at'   => $now,
		) );

		if ( $submission ) {
			$wpdb->update( TutorHelper_LMS_Database::table( 'submissions' ), $data, array( 'id' => absint( $submission->id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Updates the student's current editable submission.
			$submission_id = absint( $submission->id );
		} else {
			$data = array_merge( $data, array(
				'assignment_id'   => absint( $assignment->id ),
				'student_user_id' => get_current_user_id(),
				'attempt_number' => self::next_attempt_number( $assignment->id ),
				'created_at'      => $now,
			) );
			$wpdb->insert( TutorHelper_LMS_Database::table( 'submissions' ), $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Inserts the student's own attempt.
			$submission_id = absint( $wpdb->insert_id );
		}

		$wpdb->update( TutorHelper_LMS_Database::table( 'assignments' ), array( 'status' => $status, 'updated_at' => $now ), array( 'id' => absint( $assignment->id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Keeps assignment status aligned with current student action.

		return $submission_id;
	}

	/**
	 * Change the state of an existing draft/reopened item without replacing it.
	 *
	 * @param object $submission Editable submission.
	 * @param string $intent Desired state.
	 * @return void
	 */
	private static function set_submission_status( $submission, $intent ) {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->update(
			TutorHelper_LMS_Database::table( 'submissions' ),
			array( 'status' => $intent, 'submitted_at' => 'submitted' === $intent ? $now : null, 'updated_at' => $now ),
			array( 'id' => absint( $submission->id ) )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finalises the student's existing draft.
		$wpdb->update(
			TutorHelper_LMS_Database::table( 'assignments' ),
			array( 'status' => $intent, 'updated_at' => $now ),
			array( 'id' => absint( $submission->assignment_id ) )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Keeps assignment status aligned with the existing draft.
	}

	/**
	 * Return a current student's assignment for the submitted ID.
	 *
	 * @param int $assignment_id Assignment ID.
	 * @return object|null
	 */
	private static function owned_assignment( $assignment_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . TutorHelper_LMS_Database::table( 'assignments' ) . " WHERE id = %d AND student_user_id = %d AND status != %s LIMIT 1", $assignment_id, get_current_user_id(), 'archived' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorises current student's assignment.
	}

	/**
	 * Return one current user's editable submission, never a locked one.
	 *
	 * @param int $assignment_id Assignment ID.
	 * @param int $submission_id Submitted ID.
	 * @return object|null
	 */
	private static function owned_editable_submission( $assignment_id, $submission_id ) {
		if ( ! $submission_id ) {
			return null;
		}

		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . TutorHelper_LMS_Database::table( 'submissions' ) . " WHERE id = %d AND assignment_id = %d AND student_user_id = %d AND status IN ('draft','reopened') LIMIT 1", $submission_id, $assignment_id, get_current_user_id() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorises only the student's editable attempt.
	}

	/**
	 * Return a submission owned by the current tutor.
	 *
	 * @param int $submission_id Submission ID.
	 * @return object|null
	 */
	private static function tutor_submission( $submission_id ) {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return null;
		}

		global $wpdb;
		$submissions = TutorHelper_LMS_Database::table( 'submissions' );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT s.*, a.tutor_user_id FROM {$submissions} s INNER JOIN {$assignments} a ON a.id = s.assignment_id WHERE s.id = %d AND a.tutor_user_id = %d LIMIT 1", $submission_id, get_current_user_id() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorises one tutor-owned submission.
	}


	/**
	 * Find one LMS assignment by its stable Pro homework source ID.
	 *
	 * @param int $source_id Pro follow-up record ID.
	 * @param int $student_id Optional student ID.
	 * @return object|null
	 */
	private static function assignment_for_source( $source_id, $student_id = 0 ) {
		global $wpdb;
		$sql = "SELECT * FROM " . TutorHelper_LMS_Database::table( 'assignments' ) . " WHERE source_type = %s AND source_id = %d";
		$args = array( self::SOURCE_TYPE, absint( $source_id ) );
		if ( $student_id ) {
			$sql .= ' AND student_user_id = %d';
			$args[] = absint( $student_id );
		}
		$sql .= ' LIMIT 1';
		return $wpdb->get_row( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Resolves one linked Pro homework record.
	}

	/**
	 * Return the latest submission for tutor-side status display.
	 *
	 * @param int $assignment_id Assignment ID.
	 * @return object|null
	 */
	private static function latest_submission_for_assignment( $assignment_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . TutorHelper_LMS_Database::table( 'submissions' ) . ' WHERE assignment_id = %d ORDER BY id DESC LIMIT 1', absint( $assignment_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Displays the latest tutor-authorised assignment status.
	}


	/** Return the current course grading settings without requiring Premium to own them. */
	private static function course_grading_context( $course_id ) {
		return class_exists( 'TutorHelper_LMS_Grade_Systems' ) ? TutorHelper_LMS_Grade_Systems::grading_context_for_course( absint( $course_id ) ) : array();
	}

	/** Build or read the immutable grading result attached to a released mark. */
	private static function grade_snapshot( $assignment, $awarded_mark, $stored_snapshot = '' ) {
		if ( $stored_snapshot ) {
			$stored = json_decode( $stored_snapshot, true );
			if ( is_array( $stored ) ) { return $stored; }
		}
		$max = null !== $assignment->max_mark ? (float) $assignment->max_mark : 0;
		if ( $max <= 0 ) { return array(); }
		$percentage = round( ( (float) $awarded_mark / $max ) * 100, 2 );
		$context = self::course_grading_context( $assignment->course_id );
		$snapshot = array( 'course_id' => absint( $assignment->course_id ), 'course_title' => $assignment->course_id ? get_the_title( $assignment->course_id ) : '', 'awarded_mark' => (float) $awarded_mark, 'maximum_mark' => $max, 'percentage' => $percentage, 'grade_label' => '', 'grading_context' => $context );
		if ( ! empty( $context['labels'] ) && ! empty( $context['boundaries'] ) && 'grades' === ( $context['type'] ?? '' ) ) {
			foreach ( $context['labels'] as $index => $label ) {
				if ( isset( $context['boundaries'][ $index ] ) && $percentage >= (float) $context['boundaries'][ $index ] ) { $snapshot['grade_label'] = $label; break; }
			}
		}
		return $snapshot;
	}

	/** Format a snapshot consistently for tutor and student views. */
	private static function grade_result_label( $snapshot ) {
		$parts = array();
		if ( isset( $snapshot['percentage'] ) ) { $parts[] = self::mark_format( $snapshot['percentage'] ) . '%'; }
		if ( ! empty( $snapshot['grade_label'] ) ) { $parts[] = __( 'Grade', 'tutorhelper-lms-premium' ) . ' ' . $snapshot['grade_label']; }
		return implode( ' · ', $parts );
	}

	/** Return the relevant due/source lesson date without exposing booking data. */
	private static function booking_date_label( $booking_id ) {
		$booking = class_exists( 'TutorHelper_Booking_Records' ) ? TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) ) : null;
		if ( ! $booking || empty( $booking->booking_start ) ) {
			return '—';
		}
		$timestamp = strtotime( $booking->booking_start . ' UTC' );
		return $timestamp ? wp_date( get_option( 'date_format' ), $timestamp, wp_timezone() ) : '—';
	}

	/** Format a submission timestamp for the tutor list. */
	private static function submitted_date_label( $submitted_at ) {
		if ( empty( $submitted_at ) ) {
			return '—';
		}
		$timestamp = strtotime( $submitted_at . ' UTC' );
		return $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp, wp_timezone() ) : '—';
	}

	/**
	 * Build the due date suffix for the student submission modal title.
	 *
	 * @param object $assignment LMS assignment.
	 * @return string
	 */
	private static function assignment_due_label( $assignment ) {
		$booking = class_exists( 'TutorHelper_Booking_Records' ) ? TutorHelper_Booking_Records::get_by_id( absint( $assignment->booking_id ) ) : null;
		if ( ! $booking || empty( $booking->booking_start ) ) {
			return '';
		}
		$timestamp = strtotime( $booking->booking_start . ' UTC' );
		return $timestamp ? ' (' . wp_date( get_option( 'date_format' ), $timestamp, wp_timezone() ) . ')' : '';
	}

	/**
	 * Return a safe storage label without exposing a provider identifier.
	 *
	 * @param string $provider Provider key.
	 * @return string
	 */
	private static function provider_label( $provider ) {
		$labels = array( 'google_drive' => __( "Stored to Tutor's Google Drive", 'tutorhelper-lms' ), 'protected_wordpress' => __( 'Private website file', 'tutorhelper-lms' ), 'shared_link' => __( 'HTTPS shared link', 'tutorhelper-lms' ) );
		return isset( $labels[ $provider ] ) ? $labels[ $provider ] : __( 'Private submission', 'tutorhelper-lms' );
	}


	/**
	 * Return the most recent student attempt for one assignment.
	 *
	 * @param int $assignment_id Assignment ID.
	 * @return object|null
	 */
	private static function latest_submission( $assignment_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . TutorHelper_LMS_Database::table( 'submissions' ) . " WHERE assignment_id = %d AND student_user_id = %d ORDER BY id DESC LIMIT 1", $assignment_id, get_current_user_id() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Retrieves the current student's latest submission.
	}

	/**
	 * Return current student's assignments for a booking.
	 *
	 * @param int  $booking_id Booking ID.
	 * @param bool $include_archived Whether historic records are required.
	 * @return array
	 */
	private static function assignments_for_booking( $booking_id, $include_archived = false ) {
		global $wpdb;
		$sql = "SELECT * FROM " . TutorHelper_LMS_Database::table( 'assignments' ) . " WHERE booking_id = %d AND student_user_id = %d";
		if ( ! $include_archived ) {
			$sql .= " AND status != 'archived'";
		}
		$sql .= ' ORDER BY id ASC';

		return $wpdb->get_results( $wpdb->prepare( $sql, absint( $booking_id ), get_current_user_id() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Displays the current student's assignments for their booking.
	}

	/**
	 * Check booking ownership for student-facing rendering.
	 *
	 * @param mixed $booking_data Booking object or ID.
	 * @return object|null
	 */
	private static function student_booking( $booking_data ) {
		$booking = is_object( $booking_data ) ? $booking_data : ( is_numeric( $booking_data ) ? TutorHelper_Booking_Records::get_by_id( absint( $booking_data ) ) : null );

		return $booking && is_user_logged_in() && absint( $booking->student_user_id ) === get_current_user_id() ? $booking : null;
	}

	/** Show only feedback that the tutor has explicitly released. */
	private static function has_released_mark( $submission ) {
		$mark = $submission ? self::mark_for_submission( $submission->id ) : null;
		return $mark && 'released' === $mark->status;
	}

	/**
	 * Render the completed student-facing marked homework record.
	 *
	 * @param object $assignment Assignment.
	 * @param object $submission Submission.
	 * @param bool   $include_task Whether the parent view does not already show task details.
	 * @return void
	 */
	private static function render_student_released_feedback( $assignment, $submission, $include_task = false ) {
		$mark = self::mark_for_submission( $submission->id );
		if ( ! $mark || 'released' !== $mark->status ) {
			return;
		}

		$released_result = null;
		if ( 'marked' === $assignment->assessment_type && null !== $mark->awarded_mark ) {
			$released_result = self::grade_snapshot( $assignment, $mark->awarded_mark, $mark->grading_scheme_snapshot );
		}
		?>
		<section class="tutorhelper-lms-marked-homework">
			<header class="tutorhelper-lms-marked-homework__header">
				<p class="tutorhelper-lms-homework-status"><?php esc_html_e( 'Homework marked', 'tutorhelper-lms' ); ?></p>
				<?php if ( $include_task ) : ?>
					<h4><?php echo esc_html( $assignment->title ); ?></h4>
					<?php if ( $assignment->instructions ) : ?><p><?php echo esc_html( $assignment->instructions ); ?></p><?php endif; ?>
				<?php endif; ?>
			</header>
			<?php if ( 'marked' === $assignment->assessment_type && null !== $mark->awarded_mark ) : ?>
				<div class="tutorhelper-lms-marked-homework__result">
					<strong><?php esc_html_e( 'Mark awarded:', 'tutorhelper-lms' ); ?></strong>
					<?php echo esc_html( self::mark_format( $mark->awarded_mark ) . ( null !== $assignment->max_mark ? ' / ' . self::mark_format( $assignment->max_mark ) : '' ) ); ?>
					<?php if ( $released_result ) : ?><span> · <?php echo esc_html( self::grade_result_label( $released_result ) ); ?></span><?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="tutorhelper-lms-marked-homework__feedback">
				<h4><?php esc_html_e( 'Tutor feedback', 'tutorhelper-lms' ); ?></h4>
				<?php if ( '' !== trim( (string) $mark->feedback ) ) : ?>
					<div class="tutorhelper-lms-rich-feedback"><?php echo wp_kses_post( wpautop( $mark->feedback ) ); ?></div>
				<?php else : ?>
					<p><?php esc_html_e( 'Your tutor has marked this homework.', 'tutorhelper-lms' ); ?></p>
				<?php endif; ?>
			</div>
			<div class="tutorhelper-lms-marked-homework__submission">
				<?php $marked_file = class_exists( 'TutorHelper_LMS_Marked_Files' ) ? TutorHelper_LMS_Marked_Files::record_for( 'homework', $submission->id, 0 ) : null; ?>
				<?php if ( $marked_file ) : ?>
					<strong><?php esc_html_e( 'Marked homework:', 'tutorhelper-lms' ); ?></strong>
					<a class="button tutorhelper-action-button" href="<?php echo esc_url( TutorHelper_LMS_Marked_Files::preview_url( 'homework', $submission->id, 0 ) ); ?>"><?php esc_html_e( 'View marked work', 'tutorhelper-lms' ); ?></a>
				<?php endif; ?>
				<strong><?php esc_html_e( 'Your original submission:', 'tutorhelper-lms' ); ?></strong>
				<?php self::render_submission_access( $submission, __( 'Download original submission', 'tutorhelper-lms' ) ); ?>
			</div>
		</section>
		<?php
	}
	/** Translate a stored marking outcome for tutors and students. */
	private static function outcome_label( $outcome ) { $labels = array( 'pending' => __( 'Awaiting marking', 'tutorhelper-lms' ), 'complete' => __( 'Complete', 'tutorhelper-lms' ), 'resubmission' => __( 'Resubmission requested', 'tutorhelper-lms' ) ); return isset( $labels[ $outcome ] ) ? $labels[ $outcome ] : $labels['pending']; }

	/**
	 * Output file/link access for an authenticated record.
	 *
	 * @param object $submission Submission.
	 * @return void
	 */
	private static function render_submission_access( $submission, $file_label = '' ) {
		if ( 'file' === $submission->submission_type ) {
			?><a class="button tutorhelper-action-button" href="<?php echo esc_url( self::download_url( $submission->id ) ); ?>"><?php echo esc_html( $file_label ? $file_label : __( 'Download submitted file', 'tutorhelper-lms' ) ); ?></a><?php
		} elseif ( 'link' === $submission->submission_type && ! empty( $submission->link_url ) ) {
			?><a class="button tutorhelper-action-button" href="<?php echo esc_url( $submission->link_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open submitted link', 'tutorhelper-lms' ); ?></a><?php
		}
	}

	/**
	 * Build a nonce-protected private-download URL.
	 *
	 * @param int $submission_id Submission ID.
	 * @return string
	 */
	private static function download_url( $submission_id ) {
		return wp_nonce_url( add_query_arg( array( 'action' => self::DOWNLOAD_ACTION, 'submission_id' => absint( $submission_id ) ), admin_url( 'admin-post.php' ) ), self::DOWNLOAD_ACTION . '_' . absint( $submission_id ) );
	}

	/** Build a nonce-protected private-preview URL. */
	private static function preview_url( $submission_id ) {
		return wp_nonce_url( add_query_arg( array( 'action' => self::PREVIEW_ACTION, 'submission_id' => absint( $submission_id ) ), admin_url( 'admin-post.php' ) ), self::PREVIEW_ACTION . '_' . absint( $submission_id ) );
	}

	/** Return whether the browser can safely preview the stored file. */
	private static function is_previewable_mime_type( $mime_type ) {
		return in_array( sanitize_mime_type( $mime_type ), array( 'application/pdf', 'image/jpeg', 'image/png' ), true );
	}

	/** Build the private Google Drive destination for a tutor-owned file. */
	private static function google_drive_url( $provider, $file_id ) {
		return 'google_drive' === $provider && '' !== $file_id ? 'https://drive.google.com/file/d/' . rawurlencode( $file_id ) . '/view' : '';
	}

	/** Render tutor-side view/mark, download and optional Drive controls. */
	private static function render_tutor_submission_actions( $row ) {
		$drive_url = self::google_drive_url( $row->storage_provider, $row->provider_file_id );
		?>
		<button type="button" class="button tutorhelper-action-button tutorhelper-lms-mark-submission" data-tutorhelper-lms-mark-submission="<?php echo esc_attr( $row->submission_id ); ?>"><?php esc_html_e( 'View / Mark homework', 'tutorhelper-lms' ); ?></button>
		<?php if ( $drive_url ) : ?><a class="button tutorhelper-action-button" href="<?php echo esc_url( $drive_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View in Google Drive', 'tutorhelper-lms' ); ?></a><?php endif; ?>
		<?php
	}

	/**
	 * Return the configured limit in MB for student-facing wording.
	 *
	 * @return string
	 */
	private static function upload_limit_mb() {
		return number_format_i18n( TutorHelper_LMS_Private_Storage::effective_upload_limit() / MB_IN_BYTES, 0 );
	}

	/**
	 * Return a sanitised HTTPS link or fail for non-HTTPS input.
	 *
	 * @return string
	 */
	private static function posted_https_link() {
		if ( ! isset( $_POST['submission_link'] ) || is_array( $_POST['submission_link'] ) ) {
			return '';
		}

		$link = esc_url_raw( trim( wp_unslash( $_POST['submission_link'] ) ), array( 'https' ) );
		if ( '' === $link ) {
			return '';
		}

		$parts = wp_parse_url( $link );
		if ( empty( $parts['host'] ) || empty( $parts['scheme'] ) || 'https' !== strtolower( $parts['scheme'] ) ) {
			self::fail( __( 'Shared-document links must use HTTPS.', 'tutorhelper-lms' ) );
		}

		return $link;
	}

	/**
	 * Return the preferred provider without ever creating a public file URL.
	 *
	 * @return TutorHelper_LMS_Storage_Provider_Interface|null
	 */
	private static function preferred_provider() {
		$providers = TutorHelper_LMS_Storage_Registry::providers();
		$mode      = TutorHelper_LMS_Private_Storage::mode();
		$id        = TutorHelper_LMS_Private_Storage::MODE_GOOGLE === $mode ? 'google_drive' : ( TutorHelper_LMS_Private_Storage::MODE_LOCAL === $mode ? 'protected_wordpress' : '' );

		return $id && isset( $providers[ $id ] ) && $providers[ $id ]->is_available() ? $providers[ $id ] : null;
	}

	/**
	 * Calculate next attempt number.
	 *
	 * @param int $assignment_id Assignment ID.
	 * @return int
	 */
	private static function next_attempt_number( $assignment_id ) {
		global $wpdb;
		$number = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(attempt_number) FROM " . TutorHelper_LMS_Database::table( 'submissions' ) . " WHERE assignment_id = %d", $assignment_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Determines next attempt number for one assignment.

		return $number + 1;
	}

	/**
	 * Verify that the current user is the student or assigned tutor.
	 *
	 * @param object $submission Submission row with ownership fields.
	 * @return bool
	 */
	private static function can_access_submission( $submission ) {
		$user_id = get_current_user_id();

		return $user_id && ( $user_id === absint( $submission->student_user_id ) || ( $user_id === absint( $submission->tutor_user_id ) && current_user_can( TutorHelper_Admin::CAPABILITY ) ) );
	}

	/**
	 * Return a safe display name.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	private static function user_name( $user_id ) {
		$user = get_userdata( absint( $user_id ) );

		return $user ? $user->display_name : __( 'Unknown student', 'tutorhelper-lms' );
	}

	/**
	 * Format mark values without unnecessary decimal places.
	 *
	 * @param mixed $mark Mark.
	 * @return string
	 */
	private static function mark_format( $mark ) {
		return (string) (float) $mark;
	}

	/**
	 * Return human-readable status.
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	private static function status_label( $status ) {
		$labels = array(
			'not_started' => __( 'Not started', 'tutorhelper-lms' ),
			'draft'       => __( 'Draft', 'tutorhelper-lms' ),
			'submitted'   => __( 'Submitted', 'tutorhelper-lms' ),
			'marked'      => __( 'Marked', 'tutorhelper-lms' ),
			'reopened'    => __( 'Reopened for resubmission', 'tutorhelper-lms' ),
		);

		return $labels[ $status ] ?? __( 'Unknown', 'tutorhelper-lms' );
	}

	/**
	 * Log only provider/error-code diagnostics; never a file name, link or token.
	 *
	 * @param string $provider Provider key.
	 * @param string $code Error key.
	 * @return void
	 */
	private static function log_storage_failure( $provider, $code ) {
		if ( class_exists( 'TutorHelper_Logger' ) ) {
			TutorHelper_Logger::error( 'TutorHelper LMS storage failure.', array( 'provider' => sanitize_key( $provider ), 'error_code' => sanitize_key( $code ) ) );
		}
	}

	/**
	 * Stop an invalid student request without disclosing storage details.
	 *
	 * @param string $message Safe message.
	 * @param int    $status HTTP status.
	 * @return void
	 */
	private static function fail( $message, $status = 400 ) {
		wp_die( esc_html( $message ), '', array( 'response' => absint( $status ) ) );
	}
}
