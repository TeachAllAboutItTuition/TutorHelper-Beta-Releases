<?php
/**
 * Encrypts connection credentials and OAuth tokens before they are stored.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Secrets {

	/**
	 * Return whether a supported authenticated-encryption implementation exists.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return function_exists( 'sodium_crypto_secretbox' )
			|| ( function_exists( 'openssl_encrypt' ) && function_exists( 'openssl_decrypt' ) );
	}

	/**
	 * Encrypt a value for WordPress option storage.
	 *
	 * @param string $value Plaintext value.
	 * @return string|WP_Error
	 */
	public static function encrypt( $value ) {
		if ( ! self::is_available() ) {
			return new WP_Error(
				'tutorhelper_lms_encryption_unavailable',
				__( 'Secure token encryption is not available on this server.', 'tutorhelper-lms' )
			);
		}

		$key = hash( 'sha256', wp_salt( 'auth' ), true );

		if ( function_exists( 'sodium_crypto_secretbox' ) ) {
			$nonce  = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$cipher = sodium_crypto_secretbox( $value, $nonce, $key );

			return 'sodium:' . base64_encode( $nonce . $cipher );
		}

		$iv     = random_bytes( 12 );
		$tag    = '';
		$cipher = openssl_encrypt( $value, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );

		if ( false === $cipher ) {
			return new WP_Error(
				'tutorhelper_lms_encryption_failed',
				__( 'TutorHelper LMS could not encrypt the connection details.', 'tutorhelper-lms' )
			);
		}

		return 'openssl:' . base64_encode( $iv . $tag . $cipher );
	}

	/**
	 * Decrypt a value stored by this class.
	 *
	 * @param string $value Encrypted value.
	 * @return string|WP_Error
	 */
	public static function decrypt( $value ) {
		$parts = explode( ':', (string) $value, 2 );

		if ( 2 !== count( $parts ) ) {
			return new WP_Error( 'tutorhelper_lms_encryption_invalid', __( 'Stored connection details are invalid.', 'tutorhelper-lms' ) );
		}

		$payload = base64_decode( $parts[1], true );
		$key     = hash( 'sha256', wp_salt( 'auth' ), true );

		if ( false === $payload ) {
			return new WP_Error( 'tutorhelper_lms_encryption_invalid', __( 'Stored connection details are invalid.', 'tutorhelper-lms' ) );
		}

		if ( 'sodium' === $parts[0] && function_exists( 'sodium_crypto_secretbox_open' ) ) {
			$nonce  = substr( $payload, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$cipher = substr( $payload, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$plain  = sodium_crypto_secretbox_open( $cipher, $nonce, $key );

			return false === $plain
				? new WP_Error( 'tutorhelper_lms_encryption_invalid', __( 'Stored connection details could not be decrypted.', 'tutorhelper-lms' ) )
				: $plain;
		}

		if ( 'openssl' === $parts[0] && function_exists( 'openssl_decrypt' ) ) {
			$iv     = substr( $payload, 0, 12 );
			$tag    = substr( $payload, 12, 16 );
			$cipher = substr( $payload, 28 );
			$plain  = openssl_decrypt( $cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );

			return false === $plain
				? new WP_Error( 'tutorhelper_lms_encryption_invalid', __( 'Stored connection details could not be decrypted.', 'tutorhelper-lms' ) )
				: $plain;
		}

		return new WP_Error( 'tutorhelper_lms_encryption_unavailable', __( 'Secure token encryption is not available on this server.', 'tutorhelper-lms' ) );
	}
}
