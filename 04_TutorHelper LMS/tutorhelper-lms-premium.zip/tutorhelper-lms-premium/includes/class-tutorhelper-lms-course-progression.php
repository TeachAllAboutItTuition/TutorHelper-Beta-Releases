<?php
/**
 * Premium Course progression styles and scheduled access controls.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Extends Core Course navigation with topic gates, Quiz pass gates and dates.
 */
final class TutorHelper_LMS_Course_Progression {

	const DATE_ACTION = 'tutorhelper_lms_save_progression_date';
	const META_TOPIC_PREFIX = '_tutorhelper_lms_topic_unlock_';
	const META_ACTIVITY_PREFIX = '_tutorhelper_lms_activity_unlock_';

	/** Register Premium navigation extensions. */
	public static function init() {
		add_filter( 'tutorhelper_lms_course_access_style_labels', array( __CLASS__, 'access_style_labels' ) );
		add_filter( 'tutorhelper_lms_course_activity_access', array( __CLASS__, 'activity_access' ), 10, 8 );
		add_filter( 'tutorhelper_lms_activity_available_from_label', array( __CLASS__, 'activity_available_from_label' ), 10, 5 );
		add_action( 'tutorhelper_lms_course_builder_topic_options', array( __CLASS__, 'render_topic_date_control' ), 10, 2 );
		add_action( 'tutorhelper_lms_course_builder_activity_options', array( __CLASS__, 'render_activity_date_control' ), 20, 3 );
		add_action( 'admin_post_' . self::DATE_ACTION, array( __CLASS__, 'save_date' ) );
	}

	/** Add Premium-only styles to the Core Course Details selector. */
	public static function access_style_labels( $styles ) {
		$styles = is_array( $styles ) ? $styles : array();
		$styles['in_order_by_topic'] = __( 'In order by topic', 'tutorhelper-lms' );
		$styles['pass_topic_quiz']   = __( 'Pass topic quiz', 'tutorhelper-lms' );
		$styles['by_date']           = __( 'By date', 'tutorhelper-lms' );
		return $styles;
	}

	/**
	 * Resolve one Premium activity-access decision.
	 *
	 * @param bool|null $decision Existing decision.
	 * @return bool|null
	 */
	public static function activity_access( $decision, $student_user_id, $course_id, $topic_id, $type, $activity_id, $placement_id, $style ) {
		if ( null !== $decision || ! class_exists( 'TutorHelper_LMS_Course_Settings' ) ) {
			return $decision;
		}

		$style = sanitize_key( $style );
		if ( 'in_order_by_topic' === $style ) {
			return self::prior_topics_complete( $student_user_id, $course_id, $topic_id );
		}
		if ( 'pass_topic_quiz' === $style ) {
			return self::prior_topic_quizzes_passed( $student_user_id, $course_id, $topic_id );
		}
		if ( 'by_date' === $style ) {
			return self::activity_is_released( $course_id, $topic_id, $type, $activity_id );
		}

		return $decision;
	}

	/** Render one Topic release date control in the Course Builder. */
	public static function render_topic_date_control( $course_id, $topic_id ) {
		if ( ! self::uses_dates( $course_id ) || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$value = self::date_input_value( self::topic_unlock_at( $course_id, $topic_id ) );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__activity-requirement">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::DATE_ACTION ); ?>" />
			<input type="hidden" name="course_id" value="<?php echo esc_attr( absint( $course_id ) ); ?>" />
			<input type="hidden" name="topic_id" value="<?php echo esc_attr( absint( $topic_id ) ); ?>" />
			<input type="hidden" name="progression_scope" value="topic" />
			<?php wp_nonce_field( self::DATE_ACTION . '_topic_' . absint( $course_id ) . '_' . absint( $topic_id ) ); ?>
			<label><span class="screen-reader-text"><?php esc_html_e( 'Topic unlock date', 'tutorhelper-lms' ); ?></span><input type="datetime-local" name="unlock_at" value="<?php echo esc_attr( $value ); ?>" /></label>
			<button type="submit" class="button tutorhelper-lms-button--grey"><?php esc_html_e( 'Save topic unlock date', 'tutorhelper-lms' ); ?></button>
			<span class="description"><?php esc_html_e( 'Blank means available immediately. Activities inherit this date unless they have an override.', 'tutorhelper-lms' ); ?></span>
		</form>
		<?php
	}

	/** Render an optional activity-level date override in the Course Builder. */
	public static function render_activity_date_control( $activity, $course_id, $topic_id ) {
		if ( ! self::uses_dates( $course_id ) || ! is_object( $activity ) || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$type = sanitize_key( $activity->activity_type ?? '' );
		$activity_id = absint( $activity->activity_id ?? 0 );
		if ( ! in_array( $type, array( 'lesson', 'quiz' ), true ) || ! $activity_id ) {
			return;
		}
		$value = self::date_input_value( self::activity_unlock_at( $course_id, $topic_id, $type, $activity_id ) );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__activity-requirement">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::DATE_ACTION ); ?>" />
			<input type="hidden" name="course_id" value="<?php echo esc_attr( absint( $course_id ) ); ?>" />
			<input type="hidden" name="topic_id" value="<?php echo esc_attr( absint( $topic_id ) ); ?>" />
			<input type="hidden" name="activity_type" value="<?php echo esc_attr( $type ); ?>" />
			<input type="hidden" name="activity_id" value="<?php echo esc_attr( $activity_id ); ?>" />
			<input type="hidden" name="progression_scope" value="activity" />
			<?php wp_nonce_field( self::DATE_ACTION . '_activity_' . absint( $course_id ) . '_' . absint( $topic_id ) . '_' . $type . '_' . $activity_id ); ?>
			<label><span class="screen-reader-text"><?php esc_html_e( 'Activity unlock date override', 'tutorhelper-lms' ); ?></span><input type="datetime-local" name="unlock_at" value="<?php echo esc_attr( $value ); ?>" /></label>
			<button type="submit" class="button tutorhelper-lms-button--grey"><?php esc_html_e( 'Save date override', 'tutorhelper-lms' ); ?></button>
			<span class="description"><?php esc_html_e( 'Blank inherits the Topic date.', 'tutorhelper-lms' ); ?></span>
		</form>
		<?php
	}

	/** Save one validated Topic date or activity override. */
	public static function save_date() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update Course progression.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}

		$course_id = self::posted_id( 'course_id' );
		$topic_id  = self::posted_id( 'topic_id' );
		$scope     = self::posted_key( 'progression_scope' );
		if ( ! $course_id || ! $topic_id || ! class_exists( 'TutorHelper_LMS_Learner_Access' ) || ! TutorHelper_LMS_Learner_Access::course_has_topic( $course_id, $topic_id ) ) {
			self::redirect( false );
		}

		$type = self::posted_key( 'activity_type' );
		$activity_id = self::posted_id( 'activity_id' );
		$nonce = 'topic' === $scope ? self::DATE_ACTION . '_topic_' . $course_id . '_' . $topic_id : self::DATE_ACTION . '_activity_' . $course_id . '_' . $topic_id . '_' . $type . '_' . $activity_id;
		check_admin_referer( $nonce );

		if ( 'activity' === $scope && ! self::valid_activity( $course_id, $topic_id, $type, $activity_id ) ) {
			self::redirect( false );
		}
		if ( ! in_array( $scope, array( 'topic', 'activity' ), true ) ) {
			self::redirect( false );
		}

		$unlock_at = self::normalise_date( self::posted_value( 'unlock_at' ) );
		if ( is_wp_error( $unlock_at ) ) {
			self::redirect( false );
		}
		$key = 'topic' === $scope ? self::topic_meta_key( $topic_id ) : self::activity_meta_key( $topic_id, $type, $activity_id );
		if ( '' === $unlock_at ) {
			delete_post_meta( $course_id, $key );
		} else {
			update_post_meta( $course_id, $key, $unlock_at );
		}
		self::redirect( true );
	}

	/** Determine whether all prior Topics are complete. */
	private static function prior_topics_complete( $student_user_id, $course_id, $topic_id ) {
		foreach ( self::course_topics( $course_id ) as $topic ) {
			$current_id = absint( $topic['id'] ?? 0 );
			if ( $current_id === absint( $topic_id ) ) {
				return true;
			}
			if ( ! self::topic_complete( $student_user_id, $course_id, $current_id ) ) {
				return false;
			}
		}
		return false;
	}

	/** Determine whether every Quiz in each prior Topic has been passed. */
	private static function prior_topic_quizzes_passed( $student_user_id, $course_id, $topic_id ) {
		foreach ( self::course_topics( $course_id ) as $topic ) {
			$current_id = absint( $topic['id'] ?? 0 );
			if ( $current_id === absint( $topic_id ) ) {
				return true;
			}
			if ( ! self::topic_quizzes_passed( $student_user_id, $course_id, $current_id ) ) {
				return false;
			}
		}
		return false;
	}

	/** Check all required activities inside one Topic. */
	private static function topic_complete( $student_user_id, $course_id, $topic_id ) {
		foreach ( self::topic_activities( $course_id, $topic_id ) as $activity ) {
			if ( empty( $activity['required'] ) ) {
				continue;
			}
			if ( ! self::activity_complete( $student_user_id, $course_id, $topic_id, $activity ) ) {
				return false;
			}
		}
		return true;
	}

	/** Check all required Topic Quizzes. A Topic without a Quiz does not block progression. */
	private static function topic_quizzes_passed( $student_user_id, $course_id, $topic_id ) {
		foreach ( self::topic_activities( $course_id, $topic_id ) as $activity ) {
			if ( 'quiz' === ( $activity['type'] ?? '' ) && ! empty( $activity['required'] ) && ! self::quiz_passed( $student_user_id, absint( $activity['placement_id'] ?? 0 ) ) ) {
				return false;
			}
		}
		return true;
	}

	/** Check one required lesson or Quiz for topic completion. */
	private static function activity_complete( $student_user_id, $course_id, $topic_id, $activity ) {
		if ( 'lesson' === ( $activity['type'] ?? '' ) ) {
			return class_exists( 'TutorHelper_LMS_Learner_Progress' ) && TutorHelper_LMS_Learner_Progress::is_lesson_complete( $student_user_id, $course_id, $topic_id, absint( $activity['id'] ?? 0 ) );
		}
		if ( 'quiz' !== ( $activity['type'] ?? '' ) || ! class_exists( 'TutorHelper_LMS_Quiz_Attempts' ) ) {
			return false;
		}
		foreach ( TutorHelper_LMS_Quiz_Attempts::attempts_for_placement( $student_user_id, absint( $activity['placement_id'] ?? 0 ) ) as $attempt ) {
			if ( 'completed' === (string) $attempt->status ) {
				return true;
			}
		}
		return false;
	}

	/** Check whether any completed attempt passed, without waiting for result release. */
	private static function quiz_passed( $student_user_id, $placement_id ) {
		if ( ! class_exists( 'TutorHelper_LMS_Quiz_Attempts' ) ) {
			return false;
		}
		foreach ( TutorHelper_LMS_Quiz_Attempts::attempts_for_placement( $student_user_id, $placement_id ) as $attempt ) {
			if ( 'completed' !== (string) $attempt->status ) {
				continue;
			}
			$score = TutorHelper_LMS_Quiz_Attempts::attempt_score( $attempt->id );
			if ( ! empty( $score['passed'] ) ) {
				return true;
			}
		}
		return false;
	}

	/** Return a learner-facing date label when an activity is scheduled. */
	public static function activity_available_from_label( $label, $course_id, $topic_id, $type, $activity_id ) {
		if ( '' !== (string) $label || ! self::uses_dates( $course_id ) ) {
			return $label;
		}
		$unlock_at = self::effective_unlock_at( $course_id, $topic_id, $type, $activity_id );
		if ( '' === $unlock_at ) {
			return '';
		}
		$timestamp = strtotime( $unlock_at . ' UTC' );
		return $timestamp ? sprintf( __( 'Available from %1$s at %2$s', 'tutorhelper-lms' ), wp_date( get_option( 'date_format' ), $timestamp, wp_timezone() ), wp_date( get_option( 'time_format' ), $timestamp, wp_timezone() ) ) : '';
	}

	/** Check one dated activity, allowing a per-activity override. */
	private static function activity_is_released( $course_id, $topic_id, $type, $activity_id ) {
		$unlock_at = self::effective_unlock_at( $course_id, $topic_id, $type, $activity_id );
		return '' === $unlock_at || current_time( 'timestamp', true ) >= strtotime( $unlock_at . ' UTC' );
	}

	/** Resolve an activity override or inherited Topic date. */
	private static function effective_unlock_at( $course_id, $topic_id, $type, $activity_id ) {
		$unlock_at = self::activity_unlock_at( $course_id, $topic_id, $type, $activity_id );
		return '' !== $unlock_at ? $unlock_at : self::topic_unlock_at( $course_id, $topic_id );
	}

	/** Return the Course's ordered Topics. */
	private static function course_topics( $course_id ) {
		return apply_filters( 'tutorhelper_lms_course_topics', array(), absint( $course_id ) );
	}

	/** Return the existing mixed activity sequence for one Topic. */
	private static function topic_activities( $course_id, $topic_id ) {
		return class_exists( 'TutorHelper_LMS_Learner_Access' ) ? TutorHelper_LMS_Learner_Access::course_topic_activities( $course_id, $topic_id ) : array();
	}

	/** Ensure an override belongs to the current Course and Topic. */
	private static function valid_activity( $course_id, $topic_id, $type, $activity_id ) {
		foreach ( self::topic_activities( $course_id, $topic_id ) as $activity ) {
			if ( sanitize_key( $activity['type'] ?? '' ) === $type && absint( $activity['id'] ?? 0 ) === absint( $activity_id ) ) {
				return true;
			}
		}
		return false;
	}

	/** Whether the Course currently uses the dated-access style. */
	private static function uses_dates( $course_id ) {
		return class_exists( 'TutorHelper_LMS_Course_Settings' ) && 'by_date' === TutorHelper_LMS_Course_Settings::access_style( $course_id );
	}

	/** Read one Topic's UTC unlock date. */
	private static function topic_unlock_at( $course_id, $topic_id ) {
		return self::valid_utc_date( get_post_meta( $course_id, self::topic_meta_key( $topic_id ), true ) );
	}

	/** Read one activity override UTC unlock date. */
	private static function activity_unlock_at( $course_id, $topic_id, $type, $activity_id ) {
		return self::valid_utc_date( get_post_meta( $course_id, self::activity_meta_key( $topic_id, $type, $activity_id ), true ) );
	}

	/** Build stable, Course-scoped meta keys. */
	private static function topic_meta_key( $topic_id ) {
		return self::META_TOPIC_PREFIX . absint( $topic_id );
	}

	private static function activity_meta_key( $topic_id, $type, $activity_id ) {
		return self::META_ACTIVITY_PREFIX . absint( $topic_id ) . '_' . sanitize_key( $type ) . '_' . absint( $activity_id );
	}

	/** Format a stored UTC date for a site-local datetime field. */
	private static function date_input_value( $date ) {
		if ( '' === $date ) {
			return '';
		}
		try {
			return ( new DateTimeImmutable( $date, new DateTimeZone( 'UTC' ) ) )->setTimezone( wp_timezone() )->format( 'Y-m-d\\TH:i' );
		} catch ( Exception $exception ) {
			return '';
		}
	}

	/** Validate a site-local datetime and store it in UTC. */
	private static function normalise_date( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d\\TH:i', $value, wp_timezone() );
		$errors = DateTimeImmutable::getLastErrors();
		if ( ! $date || ( is_array( $errors ) && ( ! empty( $errors['warning_count'] ) || ! empty( $errors['error_count'] ) ) ) || $date->format( 'Y-m-d\\TH:i' ) !== $value ) {
			return new WP_Error( 'invalid_unlock_date', __( 'Enter a valid unlock date and time.', 'tutorhelper-lms' ) );
		}
		return $date->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	}

	/** Keep only a correctly shaped UTC timestamp. */
	private static function valid_utc_date( $value ) {
		$value = trim( (string) $value );
		return preg_match( '/^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$/', $value ) ? $value : '';
	}

	private static function posted_id( $name ) {
		return isset( $_POST[ $name ] ) && ! is_array( $_POST[ $name ] ) ? absint( wp_unslash( $_POST[ $name ] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in save_date().
	}

	private static function posted_key( $name ) {
		return isset( $_POST[ $name ] ) && ! is_array( $_POST[ $name ] ) ? sanitize_key( wp_unslash( $_POST[ $name ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in save_date().
	}

	private static function posted_value( $name ) {
		return isset( $_POST[ $name ] ) && ! is_array( $_POST[ $name ] ) ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in save_date().
	}

	private static function redirect( $saved ) {
		$redirect = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=tutorhelper-learning-hub&tab=courses' );
		wp_safe_redirect( add_query_arg( 'tutorhelper_lms_progression_date', $saved ? 'saved' : 'invalid', $redirect ) );
		exit;
	}
}
