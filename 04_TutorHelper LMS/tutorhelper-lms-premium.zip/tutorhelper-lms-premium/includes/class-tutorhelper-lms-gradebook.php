<?php
/**
 * Course gradebook foundation.
 *
 * @package TutorHelper_LMS_Premium
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Displays a privacy-safe, read-only course assessment record in Learning Hub.
 *
 * This first gradebook deliberately reports recorded assessment results rather
 * than calculating an overall Course grade. Weighting, exam overrides and
 * assessment types will be introduced with their own explicit rules.
 */
final class TutorHelper_LMS_Gradebook {

	const TAB = 'gradebook';

	/** @var array<string,bool> */
	private static $rendered_progress_dialogs = array();

	/**
	 * Register the premium Gradebook Learning Hub tab.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'tutorhelper_lms_learning_hub_sections', array( __CLASS__, 'add_tab' ), 30 );
		add_filter( 'tutorhelper_lms_learning_hub_render_tab', array( __CLASS__, 'render_tab' ), 10, 3 );
		add_shortcode( 'tutorhelper_lms_gradebook', array( __CLASS__, 'render_student_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_student_assets' ) );
		add_action( 'wp_ajax_tutorhelper_lms_gradebook_progress', array( __CLASS__, 'ajax_student_progress' ) );
	}

	/**
	 * Load the small, front-end-only Course-switcher enhancement.
	 *
	 * @return void
	 */
	public static function enqueue_student_assets() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$script_path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-gradebook.js';
		wp_enqueue_script(
			'tutorhelper-lms-gradebook',
			TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-gradebook.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_LMS_PREMIUM_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-lms-gradebook',
			'tutorhelperLmsGradebook',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => 'tutorhelper_lms_gradebook_progress',
				'nonce'   => wp_create_nonce( 'tutorhelper_lms_gradebook_progress' ),
				'failed'  => __( 'The Gradebook could not be updated. Please try again.', 'tutorhelper-lms' ),
			)
		);
	}

	/**
	 * Return one logged-in student's authorised Course progress markup.
	 *
	 * @return void
	 */
	public static function ajax_student_progress() {
		check_ajax_referer( 'tutorhelper_lms_gradebook_progress', 'nonce' );
		$student_id = get_current_user_id();
		$course_id  = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
		if ( ! $student_id || ! in_array( $course_id, self::student_course_ids( $student_id ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to view that Course Gradebook.', 'tutorhelper-lms' ) ), 403 );
		}
		ob_start();
		self::render_student_progress( $student_id, $course_id );
		wp_send_json_success( array( 'html' => (string) ob_get_clean() ) );
	}

	/**
	 * Add Gradebook after the free academic-library tabs.
	 *
	 * @param array $sections Existing tab definitions.
	 * @return array
	 */
	public static function add_tab( $sections ) {
		$sections[ self::TAB ] = array(
			'label'       => __( 'Gradebook', 'tutorhelper-lms' ),
			'icon'        => 'dashicons-analytics',
			'description' => __( 'Review recorded coursework marks and released grades by course.', 'tutorhelper-lms' ),
		);

		return $sections;
	}

	/**
	 * Render the Gradebook workspace in Learning Hub.
	 *
	 * @param bool  $handled Whether another extension handled the tab.
	 * @param string $selected_tab Selected tab.
	 * @param array  $sections Hub sections.
	 * @return bool
	 */
	public static function render_tab( $handled, $selected_tab, $sections ) {
		if ( self::TAB !== $selected_tab ) {
			return $handled;
		}

		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return true;
		}

		self::render_workspace();
		return true;
	}

	/**
	 * Render course selection and the assessment-result table.
	 *
	 * @return void
	 */
	private static function render_workspace() {
		$courses = get_posts(
			array(
				'post_type'      => 'tutorhelper_course',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		$course_id = isset( $_GET['lms_gradebook_course'] ) ? absint( $_GET['lms_gradebook_course'] ) : 0;
		$status    = isset( $_GET['lms_gradebook_status'] ) ? sanitize_key( wp_unslash( $_GET['lms_gradebook_status'] ) ) : 'all';
		$status    = in_array( $status, array( 'all', 'released', 'marked', 'submitted' ), true ) ? $status : 'all';
		?>
		<section class="tutorhelper-main-section tutorhelper-lms-gradebook">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'Course gradebook', 'tutorhelper-lms' ); ?></h2>
					<p><?php esc_html_e( 'Review each student’s coursework record. Released results retain the grade boundary snapshot that applied when feedback was released.', 'tutorhelper-lms' ); ?></p>
				</div>
			</header>
			<div class="tutorhelper-main-section__body">
				<form method="get" class="tutorhelper-settings-form tutorhelper-lms-gradebook__filters">
					<input type="hidden" name="page" value="tutorhelper-lms-learning-hub" />
					<input type="hidden" name="tab" value="gradebook" />
					<p class="tutorhelper-input-field">
						<label for="tutorhelper-lms-gradebook-course"><strong><?php esc_html_e( 'Course', 'tutorhelper-lms' ); ?></strong></label>
						<select id="tutorhelper-lms-gradebook-course" name="lms_gradebook_course">
							<option value="0"><?php esc_html_e( 'Select a course', 'tutorhelper-lms' ); ?></option>
							<?php foreach ( $courses as $course ) : ?>
								<option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( $course_id, $course->ID ); ?>><?php echo esc_html( $course->post_title ); ?></option>
							<?php endforeach; ?>
						</select>
					</p>
					<p class="tutorhelper-input-field">
						<label for="tutorhelper-lms-gradebook-status"><strong><?php esc_html_e( 'Assessment status', 'tutorhelper-lms' ); ?></strong></label>
						<select id="tutorhelper-lms-gradebook-status" name="lms_gradebook_status">
							<option value="all" <?php selected( 'all', $status ); ?>><?php esc_html_e( 'All submitted work', 'tutorhelper-lms' ); ?></option>
							<option value="released" <?php selected( 'released', $status ); ?>><?php esc_html_e( 'Feedback released', 'tutorhelper-lms' ); ?></option>
							<option value="marked" <?php selected( 'marked', $status ); ?>><?php esc_html_e( 'Saved marking', 'tutorhelper-lms' ); ?></option>
							<option value="submitted" <?php selected( 'submitted', $status ); ?>><?php esc_html_e( 'Awaiting marking', 'tutorhelper-lms' ); ?></option>
						</select>
					</p>
					<p><button type="submit" class="button button-primary tutorhelper-action-button"><?php esc_html_e( 'View gradebook', 'tutorhelper-lms' ); ?></button></p>
				</form>
				<?php if ( ! $course_id || 'tutorhelper_course' !== get_post_type( $course_id ) ) : ?>
					<p class="tutorhelper-lms-empty-state"><?php esc_html_e( 'Choose a course to view its recorded coursework results.', 'tutorhelper-lms' ); ?></p>
				<?php else : ?>
					<?php self::render_results( $course_id, $status ); ?>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	/**
	 * Render records for one course.
	 *
	 * @param int    $course_id Course ID.
	 * @param string $status Requested status filter.
	 * @return void
	 */
	private static function render_results( $course_id, $status ) {
		$records = self::records_for_course( $course_id, $status );
		?>
		<h3 class="tutorhelper-lms-gradebook__course-title"><?php echo esc_html( get_the_title( $course_id ) ); ?></h3>
		<?php if ( empty( $records ) ) : ?>
			<p class="tutorhelper-lms-empty-state"><?php esc_html_e( 'No submitted coursework matches this view yet.', 'tutorhelper-lms' ); ?></p>
			<?php return; ?>
		<?php endif; ?>
		<div class="tutorhelper-lms-table-wrap">
			<table class="widefat striped tutorhelper-lms-gradebook__table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Student', 'tutorhelper-lms' ); ?></th>
						<th><?php esc_html_e( 'Homework', 'tutorhelper-lms' ); ?></th>
						<th><?php esc_html_e( 'Topics', 'tutorhelper-lms' ); ?></th>
						<th><?php esc_html_e( 'Submitted', 'tutorhelper-lms' ); ?></th>
						<th><?php esc_html_e( 'Mark', 'tutorhelper-lms' ); ?></th>
						<th><?php esc_html_e( 'Result', 'tutorhelper-lms' ); ?></th>
						<th><?php esc_html_e( 'Feedback status', 'tutorhelper-lms' ); ?></th>
						<th><?php esc_html_e( 'Student progress', 'tutorhelper-lms' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $records as $record ) : ?>
						<?php $student = get_userdata( absint( $record->student_user_id ) ); ?>
						<tr>
							<td><?php echo esc_html( $student ? $student->display_name : __( 'Former student', 'tutorhelper-lms' ) ); ?></td>
							<td><?php echo esc_html( $record->title ); ?></td>
							<td><?php echo esc_html( self::topic_label( $record->topic_ids ) ); ?></td>
							<td><?php echo esc_html( self::date_label( $record->submitted_at ) ); ?></td>
							<td><?php echo esc_html( self::mark_label( $record ) ); ?></td>
							<td><?php echo esc_html( self::result_label( $record ) ); ?></td>
							<td><?php echo esc_html( self::feedback_status_label( $record ) ); ?></td>
							<td><?php self::render_tutor_progress_button( absint( $record->student_user_id ), $course_id ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<p class="description tutorhelper-lms-gradebook__note"><?php esc_html_e( 'Overall course grades are not calculated in this foundation release. They will be introduced once weighting and assessment-level boundary rules are defined.', 'tutorhelper-lms' ); ?></p>
		<?php
	}

	/**
	 * Return submitted LMS records for one course.
	 *
	 * @param int    $course_id Course ID.
	 * @param string $status Requested status.
	 * @return array
	 */
	private static function records_for_course( $course_id, $status ) {
		global $wpdb;

		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$submissions = TutorHelper_LMS_Database::table( 'submissions' );
		$marks       = TutorHelper_LMS_Database::table( 'marks' );
		$sql = "SELECT a.student_user_id, a.title, a.topic_ids, a.max_mark, s.submitted_at, s.status AS submission_status, m.awarded_mark, m.status AS mark_status, m.grading_scheme_snapshot FROM {$assignments} a INNER JOIN {$submissions} s ON s.assignment_id = a.id LEFT JOIN {$marks} m ON m.submission_id = s.id WHERE a.course_id = %d AND a.status != %s AND s.status IN ('submitted', 'marked')";

		$args = array( absint( $course_id ), 'archived' );
		if ( 'released' === $status ) {
			$sql .= ' AND m.status = %s';
			$args[] = 'released';
		} elseif ( 'marked' === $status ) {
			$sql .= ' AND s.status = %s';
			$args[] = 'marked';
		} elseif ( 'submitted' === $status ) {
			$sql .= ' AND s.status = %s';
			$args[] = 'submitted';
		}

		$sql .= ' ORDER BY a.student_user_id ASC, s.submitted_at DESC';
		return $wpdb->get_results( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Tutor-owned Gradebook needs current LMS results.
	}

	/** Format one recorded mark. */
	private static function mark_label( $record ) {
		if ( null === $record->awarded_mark || '' === $record->awarded_mark ) {
			return '—';
		}
		$mark = self::number_label( $record->awarded_mark );
		return null !== $record->max_mark ? $mark . ' / ' . self::number_label( $record->max_mark ) : $mark;
	}

	/** Format the immutable released percentage/Grade snapshot. */
	private static function result_label( $record ) {
		if ( 'released' !== $record->mark_status || empty( $record->grading_scheme_snapshot ) ) {
			return '—';
		}
		$snapshot = json_decode( $record->grading_scheme_snapshot, true );
		if ( ! is_array( $snapshot ) || ! isset( $snapshot['percentage'] ) ) {
			return '—';
		}
		$result = self::number_label( $snapshot['percentage'] ) . '%';
		if ( ! empty( $snapshot['grade_label'] ) ) {
			$result .= ' · ' . __( 'Grade', 'tutorhelper-lms' ) . ' ' . $snapshot['grade_label'];
		}
		return $result;
	}

	/** Format the private marking state for tutors. */
	private static function feedback_status_label( $record ) {
		if ( 'released' === $record->mark_status ) {
			return __( 'Released', 'tutorhelper-lms' );
		}
		if ( 'marked' === $record->submission_status ) {
			return __( 'Saved marking', 'tutorhelper-lms' );
		}
		return __( 'Awaiting marking', 'tutorhelper-lms' );
	}

	/** Format topic associations without exposing unrelated learner data. */
	private static function topic_label( $topic_ids ) {
		$ids = json_decode( (string) $topic_ids, true );
		if ( ! is_array( $ids ) || empty( $ids ) ) {
			return '—';
		}
		$names = array();
		foreach ( array_slice( array_map( 'absint', $ids ), 0, 3 ) as $topic_id ) {
			$title = get_the_title( $topic_id );
			if ( $title ) {
				$names[] = $title;
			}
		}
		return $names ? implode( ', ', $names ) : '—';
	}

	/** Format an LMS UTC timestamp in the site timezone. */
	private static function date_label( $value ) {
		$timestamp = strtotime( (string) $value . ' UTC' );
		return $timestamp ? wp_date( get_option( 'date_format' ), $timestamp, wp_timezone() ) : '—';
	}

	/** Format a decimal without unnecessary zeroes. */
	private static function number_label( $value ) {
		return rtrim( rtrim( number_format_i18n( (float) $value, 2 ), '0' ), '.' );
	}
	/**
	 * Render a student’s own visual topic Gradebook.
	 *
	 * @return string
	 */
	public static function render_student_shortcode() {
		if ( ! is_user_logged_in() ) {
			return '<p class="tutorhelper-lms-gradebook-notice">' . esc_html__( 'Please log in to view your academic progress.', 'tutorhelper-lms' ) . '</p>';
		}

		$student_id = get_current_user_id();
		$course_ids = self::student_course_ids( $student_id );
		if ( empty( $course_ids ) ) {
			return '<p class="tutorhelper-lms-gradebook-notice">' . esc_html__( 'Your Gradebook will appear here after your tutor has released marked coursework.', 'tutorhelper-lms' ) . '</p>';
		}

		$course_id = isset( $_GET['tutorhelper_lms_gradebook_course'] ) ? absint( $_GET['tutorhelper_lms_gradebook_course'] ) : absint( $course_ids[0] );
		if ( ! in_array( $course_id, $course_ids, true ) ) {
			$course_id = absint( $course_ids[0] );
		}

		ob_start();
		?>
		<section class="tutorhelper-lms-student-gradebook">
			<header class="tutorhelper-lms-student-gradebook__header">
				<h2><?php esc_html_e( 'My academic progress', 'tutorhelper-lms' ); ?></h2>
				<p><?php esc_html_e( 'These topic results are based on the marked coursework your tutor has released.', 'tutorhelper-lms' ); ?></p>
			</header>
			<?php if ( count( $course_ids ) > 1 ) : ?>
				<nav class="tutorhelper-lms-student-gradebook__course-picker" aria-label="<?php esc_attr_e( 'Choose a Course Gradebook', 'tutorhelper-lms' ); ?>" data-tutorhelper-lms-gradebook-picker>
					<span class="tutorhelper-lms-student-gradebook__course-label"><?php esc_html_e( 'Your course', 'tutorhelper-lms' ); ?></span>
					<div class="tutorhelper-lms-student-gradebook__course-options" role="tablist">
						<?php foreach ( $course_ids as $id ) : ?>
							<button type="button" role="tab" aria-selected="<?php echo $course_id === $id ? 'true' : 'false'; ?>" class="tutorhelper-button tutorhelper-lms-student-gradebook__course-option<?php echo $course_id === $id ? ' is-active' : ''; ?>" data-tutorhelper-lms-gradebook-course="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( get_the_title( $id ) ); ?></button>
						<?php endforeach; ?>
					</div>
				</nav>
				<noscript><p><?php esc_html_e( 'Choose a Course by adding tutorhelper_lms_gradebook_course to this page URL.', 'tutorhelper-lms' ); ?></p></noscript>
			<?php endif; ?>
			<div class="tutorhelper-lms-student-gradebook__progress" data-tutorhelper-lms-gradebook-progress aria-live="polite"><?php self::render_student_progress( $student_id, $course_id ); ?></div>
		</section>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Output the tutor's authorised visual view of one student's Course progress.
	 *
	 * @param int $student_id Student ID.
	 * @param int $course_id Course ID.
	 * @return void
	 */
	private static function render_tutor_progress_button( $student_id, $course_id ) {
		$modal_id = 'tutorhelper-lms-gradebook-progress-' . absint( $course_id ) . '-' . absint( $student_id );
		?>
		<button type="button" class="button tutorhelper-action-button" data-tutorhelper-lms-modal-open="<?php echo esc_attr( $modal_id ); ?>"><?php esc_html_e( 'View progress', 'tutorhelper-lms' ); ?></button>
		<?php if ( empty( self::$rendered_progress_dialogs[ $modal_id ] ) ) : ?>
			<?php self::$rendered_progress_dialogs[ $modal_id ] = true; $student = get_userdata( $student_id ); ?>
			<dialog id="<?php echo esc_attr( $modal_id ); ?>" class="tutorhelper-lms-modal tutorhelper-lms-gradebook-modal">
				<div class="tutorhelper-lms-modal__header"><h2><?php echo esc_html( ( $student ? $student->display_name : __( 'Student', 'tutorhelper-lms' ) ) . ' — ' . get_the_title( $course_id ) ); ?></h2><button type="button" class="button-link tutorhelper-lms-modal__close" data-tutorhelper-lms-modal-close aria-label="<?php esc_attr_e( 'Close Gradebook', 'tutorhelper-lms' ); ?>">×</button></div>
				<div class="tutorhelper-lms-modal__body"><?php self::render_student_progress( $student_id, $course_id ); ?></div>
			</dialog>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render the embedded, authorised Gradebook for one Course view.
	 *
	 * @param int $student_id Student ID.
	 * @param int $course_id Course ID.
	 * @return void
	 */
	public static function render_student_course_gradebook( $student_id, $course_id ) {
		?>
		<section class="tutorhelper-lms-course-gradebook" data-tutorhelper-lms-course-gradebook aria-labelledby="tutorhelper-lms-course-gradebook-title">
			<header class="tutorhelper-lms-course-gradebook__header">
				<p class="tutorhelper-lms-textbook__eyebrow"><?php esc_html_e( 'My Gradebook', 'tutorhelper-lms' ); ?></p>
				<h4 id="tutorhelper-lms-course-gradebook-title"><?php echo esc_html( get_the_title( $course_id ) ); ?></h4>
				<p><?php esc_html_e( 'Review released coursework and Quiz results for this Course.', 'tutorhelper-lms' ); ?></p>
			</header>
			<?php self::render_student_progress( $student_id, $course_id, true ); ?>
		</section>
		<?php
	}

	/**
	 * Render one student's authorised Course progress.
	 *
	 * @param int  $student_id Student user ID.
	 * @param int  $course_id Course post ID.
	 * @param bool $embedded Whether the Course heading is supplied by a parent view.
	 * @return void
	 */
	public static function render_student_progress( $student_id, $course_id, $embedded = false ) {
		$topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
		$scores = self::topic_scores( $student_id, $course_id, $topics );
		?>
		<div class="tutorhelper-lms-topic-progress" data-tutorhelper-lms-gradebook-topic-progress>
			<?php if ( ! $embedded ) : ?><h3><?php echo esc_html( get_the_title( $course_id ) ); ?></h3><?php endif; ?>
			<p class="description"><?php esc_html_e( 'Topic percentages weight each released assessment by its available marks. Select a Topic to see the Quiz attempts and homework that contribute to it.', 'tutorhelper-lms' ); ?></p>
			<?php if ( empty( $topics ) ) : ?><p><?php esc_html_e( 'This course does not yet have Topics linked to it.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?><div class="tutorhelper-lms-topic-progress__grid">
				<?php foreach ( $topics as $topic ) : $topic_id = absint( $topic['id'] ?? 0 ); $score = $scores[ $topic_id ] ?? array( 'awarded' => 0, 'available' => 0, 'count' => 0 ); $percentage = $score['available'] ? round( ( $score['awarded'] / $score['available'] ) * 100, 1 ) : null; ?>
					<button type="button" class="tutorhelper-lms-topic-progress__card" data-tutorhelper-lms-gradebook-topic="<?php echo esc_attr( $topic_id ); ?>" aria-pressed="false">
						<h4><?php echo esc_html( $topic['title'] ?? __( 'Topic', 'tutorhelper-lms' ) ); ?></h4>
						<?php if ( null === $percentage ) : ?><p class="tutorhelper-lms-topic-progress__empty"><?php esc_html_e( 'No released marked work yet', 'tutorhelper-lms' ); ?></p>
						<?php else : ?><p class="tutorhelper-lms-topic-progress__percentage"><?php echo esc_html( self::number_label( $percentage ) ); ?>%</p><p><strong><?php echo esc_html( self::current_grade_label( $course_id, $percentage ) ); ?></strong></p><p class="description"><?php echo esc_html( sprintf( _n( '%d released assessment', '%d released assessments', $score['count'], 'tutorhelper-lms' ), $score['count'] ) ); ?></p><?php endif; ?>
					</button>
				<?php endforeach; ?>
			</div><?php endif; ?>
			<?php self::render_student_quiz_results( $student_id, $course_id ); ?>
		</div>
		<?php
	}

	/**
	 * Render the released Quiz and homework results that contribute to Topic grades.
	 *
	 * @param int $student_id Student user ID.
	 * @param int $course_id Course post ID.
	 * @return void
	 */
	private static function render_student_quiz_results( $student_id, $course_id ) {
		$records = self::student_assessment_records( $student_id, $course_id );
		if ( empty( $records ) ) {
			return;
		}
		?>
		<section class="tutorhelper-lms-gradebook-assessment-records" data-tutorhelper-lms-gradebook-assessment-records>
			<div class="tutorhelper-lms-gradebook-assessment-records__header">
				<div><h4><?php esc_html_e( 'Released assessments', 'tutorhelper-lms' ); ?></h4><p class="description" data-tutorhelper-lms-gradebook-filter-label><?php esc_html_e( 'Showing all released assessments.', 'tutorhelper-lms' ); ?></p></div>
				<button type="button" class="tutorhelper-button tutorhelper-lms-gradebook-assessment-records__clear" data-tutorhelper-lms-gradebook-clear-filter hidden><?php esc_html_e( 'Show all results', 'tutorhelper-lms' ); ?></button>
			</div>
			<div class="tutorhelper-lms-gradebook-assessment-records__table-wrap">
				<table>
					<thead><tr><th scope="col"><?php esc_html_e( 'Assessment', 'tutorhelper-lms' ); ?></th><th scope="col"><?php esc_html_e( 'Type', 'tutorhelper-lms' ); ?></th><th scope="col"><?php esc_html_e( 'Topic', 'tutorhelper-lms' ); ?></th><th scope="col"><?php esc_html_e( 'Score', 'tutorhelper-lms' ); ?></th><th scope="col"><?php esc_html_e( 'Released', 'tutorhelper-lms' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $records as $record ) : ?>
							<tr data-tutorhelper-lms-gradebook-record data-tutorhelper-lms-gradebook-topics="<?php echo esc_attr( implode( ',', $record['topic_ids'] ) ); ?>">
								<th scope="row"><?php echo esc_html( $record['title'] ); ?></th>
								<td><?php echo esc_html( 'quiz' === $record['type'] ? __( 'Quiz', 'tutorhelper-lms' ) : __( 'Homework', 'tutorhelper-lms' ) ); ?></td>
								<td><?php echo esc_html( $record['topic_title'] ); ?></td>
								<td><?php echo esc_html( self::student_mark_label( $record['awarded'], $record['available'] ) ); ?></td>
								<td><?php echo esc_html( self::date_label( $record['date'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<nav class="tutorhelper-lms-gradebook-assessment-records__pagination" data-tutorhelper-lms-gradebook-pagination aria-label="<?php esc_attr_e( 'Assessment table pages', 'tutorhelper-lms' ); ?>" hidden>
				<button type="button" class="tutorhelper-button" data-tutorhelper-lms-gradebook-page="previous"><?php esc_html_e( 'Previous', 'tutorhelper-lms' ); ?></button>
				<span data-tutorhelper-lms-gradebook-page-status aria-live="polite"></span>
				<button type="button" class="tutorhelper-button" data-tutorhelper-lms-gradebook-page="next"><?php esc_html_e( 'Next', 'tutorhelper-lms' ); ?></button>
			</nav>
			<p class="tutorhelper-lms-topic-progress__empty" data-tutorhelper-lms-gradebook-no-results hidden><?php esc_html_e( 'There are no released assessments for this Topic yet.', 'tutorhelper-lms' ); ?></p>
		</section>
		<?php
	}

	/**
	 * Return released, single-Topic homework and Quiz records for the student.
	 *
	 * A Question without a Course-specific Topic mapping inherits the Topic of
	 * its Quiz placement. The immutable attempt snapshot preserves that decision.
	 *
	 * @param int $student_id Student user ID.
	 * @param int $course_id Course post ID.
	 * @return array<int,array<string,mixed>>
	 */
	private static function student_assessment_records( $student_id, $course_id ) {
		global $wpdb;
		$records = array();
		$course_topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
		$course_topic_ids = array_flip( array_filter( array_map( 'absint', wp_list_pluck( $course_topics, 'id' ) ) ) );
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$submissions = TutorHelper_LMS_Database::table( 'submissions' );
		$marks = TutorHelper_LMS_Database::table( 'marks' );
		$homework = $wpdb->get_results( $wpdb->prepare( "SELECT a.title, a.topic_ids, a.max_mark, m.awarded_mark, s.submitted_at FROM {$assignments} a INNER JOIN {$submissions} s ON s.assignment_id = a.id INNER JOIN {$marks} m ON m.submission_id = s.id WHERE a.student_user_id = %d AND a.course_id = %d AND a.status != %s AND s.status = %s AND m.status = %s AND m.awarded_mark IS NOT NULL", absint( $student_id ), absint( $course_id ), 'archived', 'marked', 'released' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads this student's released coursework.
		foreach ( is_array( $homework ) ? $homework : array() as $row ) {
			$topic_ids = json_decode( (string) $row->topic_ids, true );
			$topic_ids = is_array( $topic_ids ) ? array_values( array_filter( array_map( 'absint', $topic_ids ) ) ) : array();
			if ( 1 !== count( $topic_ids ) || (float) $row->max_mark <= 0 ) { continue; }
			$records[] = array( 'type' => 'homework', 'title' => (string) $row->title, 'topic_ids' => $topic_ids, 'topic_title' => (string) get_the_title( $topic_ids[0] ), 'awarded' => (float) $row->awarded_mark, 'available' => (float) $row->max_mark, 'date' => (string) $row->submitted_at );
		}
		if ( ! class_exists( 'TutorHelper_LMS_Free_Database' ) || ! class_exists( 'TutorHelper_LMS_Quiz_Attempts' ) ) { return self::sort_student_assessment_records( $records ); }
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		$attempts = $table ? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE student_user_id = %d AND course_id = %d AND status = %s", absint( $student_id ), absint( $course_id ), 'completed' ) ) : array(); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads the student's released Course Quiz attempts.
		foreach ( is_array( $attempts ) ? $attempts : array() as $attempt ) {
			if ( ! TutorHelper_LMS_Quiz_Attempts::results_released( $attempt ) ) { continue; }
			$snapshot = json_decode( (string) $attempt->snapshot_json, true );
			if ( ! is_array( $snapshot ) ) { continue; }
			$quiz = is_array( $snapshot['quiz'] ?? null ) ? $snapshot['quiz'] : array();
			$totals = array();
			foreach ( TutorHelper_LMS_Quiz_Attempts::reviewed_responses( $attempt->id ) as $question_id => $response ) {
				$mark = is_array( $response['mark'] ?? null ) ? $response['mark'] : array();
				if ( in_array( $mark['status'] ?? '', array( 'awaiting_marking', 'manual_pending' ), true ) ) { continue; }
				$topic_id = self::quiz_question_effective_topic( $snapshot, $attempt, $question_id );
				$topic_id = self::normalise_quiz_course_topic( $topic_id, absint( $attempt->topic_id ), $course_topics, $course_topic_ids );
				$available = (float) ( $mark['available'] ?? 0 );
				if ( ! $topic_id || $available <= 0 ) { continue; }
				if ( ! isset( $totals[ $topic_id ] ) ) { $totals[ $topic_id ] = array( 'awarded' => 0, 'available' => 0 ); }
				$totals[ $topic_id ]['awarded'] += (float) ( $mark['marks'] ?? 0 );
				$totals[ $topic_id ]['available'] += $available;
			}
			foreach ( $totals as $topic_id => $total ) {
				$records[] = array( 'type' => 'quiz', 'title' => sprintf( __( '%1$s — Attempt %2$d', 'tutorhelper-lms' ), (string) ( $quiz['title'] ?? get_the_title( absint( $attempt->quiz_id ) ) ), absint( $attempt->attempt_number ) ), 'topic_ids' => array( absint( $topic_id ) ), 'topic_title' => (string) get_the_title( absint( $topic_id ) ), 'awarded' => (float) $total['awarded'], 'available' => (float) $total['available'], 'date' => (string) ( $attempt->results_released_at ?: $attempt->completed_at ) );
			}
		}
		return self::sort_student_assessment_records( $records );
	}

	/**
	 * Read a Question's frozen Topic override, otherwise inherit the Quiz placement Topic.
	 *
	 * @param array  $snapshot Attempt snapshot.
	 * @param object $attempt Attempt record.
	 * @param int    $question_id Question ID.
	 * @return int
	 */
	private static function quiz_question_effective_topic( $snapshot, $attempt, $question_id ) {
		foreach ( (array) ( $snapshot['course_question_topics'] ?? array() ) as $mapping ) {
			if ( absint( $mapping['question_id'] ?? 0 ) === absint( $question_id ) ) {
				$topic_id = absint( $mapping['topic_id'] ?? 0 );
				return $topic_id ? $topic_id : absint( $attempt->topic_id ?? 0 );
			}
		}
		return absint( $attempt->topic_id ?? 0 );
	}

	/**
	 * Resolve an historic Question mapping to a Topic in the current Course.
	 *
	 * Historic attempts normally retain a Course Topic ID. Older data can contain
	 * an equivalent, no-longer-linked Topic record instead. In that situation a
	 * unique matching title is used only as a final compatibility bridge.
	 *
	 * @param int   $question_topic_id Stored Question Topic ID.
	 * @param int   $placement_topic_id Stored Quiz placement Topic ID.
	 * @param array $course_topics Current Course Topic records.
	 * @param array $course_topic_ids Current Course Topic lookup.
	 * @return int
	 */
	private static function normalise_quiz_course_topic( $question_topic_id, $placement_topic_id, $course_topics, $course_topic_ids ) {
		if ( $question_topic_id && isset( $course_topic_ids[ $question_topic_id ] ) ) {
			return $question_topic_id;
		}
		if ( $placement_topic_id && isset( $course_topic_ids[ $placement_topic_id ] ) ) {
			return $placement_topic_id;
		}
		$candidates = array();
		foreach ( array_filter( array_unique( array( absint( $question_topic_id ), absint( $placement_topic_id ) ) ) ) as $stored_topic_id ) {
			$stored_title = sanitize_title( get_the_title( $stored_topic_id ) );
			if ( '' === $stored_title ) {
				continue;
			}
			$matches = array();
			foreach ( (array) $course_topics as $course_topic ) {
				if ( $stored_title === sanitize_title( (string) ( $course_topic['title'] ?? '' ) ) ) {
					$matches[] = absint( $course_topic['id'] ?? 0 );
				}
			}
			$matches = array_values( array_filter( array_unique( $matches ) ) );
			if ( 1 === count( $matches ) ) {
				$candidates[] = $matches[0];
			}
		}
		$candidates = array_values( array_filter( array_unique( $candidates ) ) );
		return 1 === count( $candidates ) ? $candidates[0] : 0;
	}

	/** Sort the student record table most-recent first. */
	private static function sort_student_assessment_records( $records ) {
		usort( $records, function( $first, $second ) { return strcmp( (string) ( $second['date'] ?? '' ), (string) ( $first['date'] ?? '' ) ); } );
		return $records;
	}

	/** Format a student-facing mark with correct singular/plural wording. */
	private static function student_mark_label( $awarded, $available ) {
		return sprintf( _n( '%1$s / %2$s mark', '%1$s / %2$s marks', (int) $available, 'tutorhelper-lms' ), self::number_label( $awarded ), self::number_label( $available ) );
	}

	/**
	 * Return a translated label for a stored Quiz outcome.
	 *
	 * @param string $outcome Stored outcome key.
	 * @return string
	 */
	private static function quiz_result_label( $outcome ) {
		$outcome = sanitize_key( $outcome );
		if ( 'pass' === $outcome ) {
			return __( 'Pass', 'tutorhelper-lms' );
		}
		if ( 'fail' === $outcome ) {
			return __( 'Fail', 'tutorhelper-lms' );
		}
		return __( 'Awaiting marking', 'tutorhelper-lms' );
	}

	/** Return Course IDs for which a student has released LMS results. */
	private static function student_course_ids( $student_id ) {
		global $wpdb;
		$assignments = TutorHelper_LMS_Database::table( 'assignments' );
		$submissions = TutorHelper_LMS_Database::table( 'submissions' );
		$marks = TutorHelper_LMS_Database::table( 'marks' );
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT a.course_id FROM {$assignments} a INNER JOIN {$submissions} s ON s.assignment_id = a.id INNER JOIN {$marks} m ON m.submission_id = s.id WHERE a.student_user_id = %d AND a.course_id > 0 AND a.status != %s AND s.status = %s AND m.status = %s", absint( $student_id ), 'archived', 'marked', 'released' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Student reads only their released coursework.
		if ( class_exists( 'TutorHelper_LMS_Free_Database' ) && class_exists( 'TutorHelper_LMS_Quiz_Attempts' ) ) {
			$attempts = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
			$quiz_attempts = $attempts ? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$attempts} WHERE student_user_id = %d AND course_id > 0 AND status = %s", absint( $student_id ), 'completed' ) ) : array(); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finds this student's released Course Quiz results.
			foreach ( is_array( $quiz_attempts ) ? $quiz_attempts : array() as $attempt ) {
				if ( TutorHelper_LMS_Quiz_Attempts::results_released( $attempt ) ) {
					$ids[] = absint( $attempt->course_id );
				}
			}
		}
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	/** Calculate weighted top-level Topic scores from the released records displayed below. */
	private static function topic_scores( $student_id, $course_id, $topics ) {
		$allowed = array_flip( array_map( 'absint', wp_list_pluck( $topics, 'id' ) ) );
		$scores = array();
		foreach ( self::student_assessment_records( $student_id, $course_id ) as $record ) {
			$topic_ids = array_values( array_filter( array_map( 'absint', (array) ( $record['topic_ids'] ?? array() ) ) ) );
			if ( 1 !== count( $topic_ids ) || ! isset( $allowed[ $topic_ids[0] ] ) || (float) ( $record['available'] ?? 0 ) <= 0 ) { continue; }
			$topic_id = $topic_ids[0];
			if ( ! isset( $scores[ $topic_id ] ) ) { $scores[ $topic_id ] = array( 'awarded' => 0, 'available' => 0, 'count' => 0 ); }
			$scores[ $topic_id ]['awarded'] += (float) $record['awarded'];
			$scores[ $topic_id ]['available'] += (float) $record['available'];
			++$scores[ $topic_id ]['count'];
		}
		return $scores;
	}
	/** Use current Course boundaries for an indicative Topic Grade. */
	private static function current_grade_label( $course_id, $percentage ) {
		$context = class_exists( 'TutorHelper_LMS_Grade_Systems' ) ? TutorHelper_LMS_Grade_Systems::grading_context_for_course( $course_id ) : array();
		if ( 'grades' !== ( $context['type'] ?? '' ) ) { return __( 'Percentage result', 'tutorhelper-lms' ); }
		foreach ( $context['labels'] ?? array() as $index => $label ) {
			if ( isset( $context['boundaries'][ $index ] ) && $percentage >= (float) $context['boundaries'][ $index ] ) { return __( 'Grade', 'tutorhelper-lms' ) . ' ' . $label; }
		}
		return __( 'Below the current Grade boundary', 'tutorhelper-lms' );
	}

}
