<?php
/**
 * TutorHelper LMS Premium licence state and secure bridge client.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Premium {

	const PRODUCT_SLUG = 'tutorhelper-lms';
	const SETTINGS_TAB = 'lms-licence';
	const ACTIVATE_ACTION = 'tutorhelper_lms_activate_licence';
	const DEACTIVATE_ACTION = 'tutorhelper_lms_deactivate_licence';
	const KEY_OPTION = 'tutorhelper_lms_licence_key';
	const TOKEN_OPTION = 'tutorhelper_lms_licence_token';
	const STATUS_OPTION = 'tutorhelper_lms_licence_status';
	const INSTANCE_OPTION = 'tutorhelper_lms_licence_instance';
	const EXPIRES_OPTION = 'tutorhelper_lms_licence_expires';
	const LIFETIME_OPTION = 'tutorhelper_lms_licence_lifetime';
	const API_URL = 'https://tutorhelper.co.uk/wp-json/tutorhelper-license/v1/';

	public static function init() {
		add_filter( 'tutorhelper_settings_tabs', array( __CLASS__, 'add_tab' ) );
		add_action( 'tutorhelper_settings_render_tab', array( __CLASS__, 'render_tab' ) );
		add_action( 'admin_post_' . self::ACTIVATE_ACTION, array( __CLASS__, 'activate' ) );
		add_action( 'admin_post_' . self::DEACTIVATE_ACTION, array( __CLASS__, 'deactivate' ) );
		add_filter( 'tutorhelper_lms_learning_hub_sections', array( __CLASS__, 'add_learning_hub_section' ) );
		add_filter( 'tutorhelper_lms_learning_hub_render_tab', array( __CLASS__, 'render_learning_hub_section' ), 10, 3 );
	}

	/**
	 * Add Premium submissions to the existing Learning Hub only when available.
	 *
	 * @param array $sections Free LMS Hub sections.
	 * @return array
	 */
	public static function add_learning_hub_section( $sections ) {
		if ( self::is_available() ) {
			$sections['submissions'] = array(
				'label'       => __( 'Submissions', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-upload',
				'description' => __( 'Review student homework submissions and revisions.', 'tutorhelper-lms' ),
			);
		}
		return $sections;
	}

	/**
	 * Render the Premium submissions workspace inside Learning Hub.
	 *
	 * @param bool   $handled Whether another extension rendered the tab.
	 * @param string $tab Current tab.
	 * @param array  $sections Available tabs.
	 * @return bool
	 */
	public static function render_learning_hub_section( $handled, $tab, $sections ) {
		if ( $handled || 'submissions' !== $tab || ! self::is_available() ) {
			return $handled;
		}
		TutorHelper_LMS_Submissions::render_tutor_page();
		return true;
	}

	public static function is_available() {
		return defined( 'TUTORHELPER_PRO_VERSION' )
			&& version_compare( TUTORHELPER_PRO_VERSION, TutorHelper_LMS_Dependency::MINIMUM_PRO_VERSION, '>=' )
			&& self::is_licensed();
	}

	public static function is_licensed() {
		if ( 'active' !== sanitize_key( get_option( self::STATUS_OPTION, 'inactive' ) ) ) {
			return false;
		}
		if ( (bool) get_option( self::LIFETIME_OPTION, false ) ) {
			return true;
		}
		$expires = (string) get_option( self::EXPIRES_OPTION, '' );
		if ( '' !== $expires && strtotime( $expires ) < time() ) {
			update_option( self::STATUS_OPTION, 'expired', false );
			return false;
		}
		return true;
	}

	public static function add_tab( $tabs ) {
		$tabs[ self::SETTINGS_TAB ] = array(
			'label' => __( 'LMS Licence', 'tutorhelper-lms' ),
			'icon' => 'dashicons-admin-network',
		);
		return $tabs;
	}

	public static function render_tab( $selected_tab ) {
		if ( self::SETTINGS_TAB !== $selected_tab || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$status = sanitize_key( get_option( self::STATUS_OPTION, 'inactive' ) );
		$key = (string) get_option( self::KEY_OPTION, '' );
		$lifetime = (bool) get_option( self::LIFETIME_OPTION, false );
		$expires = (string) get_option( self::EXPIRES_OPTION, '' );
		?>
		<section class="tutorhelper-main-section">
			<header class="tutorhelper-main-section__header is-compact"><div class="tutorhelper-main-section__header-content"><h2><?php esc_html_e( 'TutorHelper LMS Premium', 'tutorhelper-lms' ); ?></h2><p><?php esc_html_e( 'Premium submissions, marking and storage require TutorHelper Pro and a separate LMS licence.', 'tutorhelper-lms' ); ?></p></div></header>
			<div class="tutorhelper-main-section__body">
				<?php if ( self::is_available() ) : ?>
					<p class="notice notice-success inline"><span><?php echo esc_html( $lifetime ? __( 'LMS Premium is active with a lifetime licence.', 'tutorhelper-lms' ) : sprintf( __( 'LMS Premium is active until %s.', 'tutorhelper-lms' ), $expires ) ); ?></span></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form"><input type="hidden" name="action" value="<?php echo esc_attr( self::DEACTIVATE_ACTION ); ?>" /><?php wp_nonce_field( self::DEACTIVATE_ACTION ); ?><p><button type="submit" class="button button-secondary tutorhelper-action-button"><?php esc_html_e( 'Deactivate LMS licence', 'tutorhelper-lms' ); ?></button></p></form>
				<?php else : ?>
					<p class="notice notice-warning inline"><span><?php echo esc_html( defined( 'TUTORHELPER_PRO_VERSION' ) ? __( 'LMS Premium is unavailable until an active LMS licence is connected.', 'tutorhelper-lms' ) : __( 'LMS Premium also requires TutorHelper Pro to be active. Free learning features remain available.', 'tutorhelper-lms' ) ); ?></span></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form"><input type="hidden" name="action" value="<?php echo esc_attr( self::ACTIVATE_ACTION ); ?>" /><?php wp_nonce_field( self::ACTIVATE_ACTION ); ?><p class="tutorhelper-input-field is-full-width"><label for="tutorhelper-lms-licence-key"><strong><?php esc_html_e( 'LMS licence key', 'tutorhelper-lms' ); ?></strong></label><br /><input id="tutorhelper-lms-licence-key" class="regular-text code tutorhelper-input-field__control" name="licence_key" type="text" value="<?php echo esc_attr( $key ); ?>" autocomplete="off" /></p><p><button type="submit" class="button button-primary tutorhelper-action-button"><?php esc_html_e( 'Activate LMS licence', 'tutorhelper-lms' ); ?></button></p></form>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	public static function activate() {
		self::require_admin();
		check_admin_referer( self::ACTIVATE_ACTION );
		$key = isset( $_POST['licence_key'] ) && ! is_array( $_POST['licence_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['licence_key'] ) ) ) : '';
		if ( '' === $key ) {
			self::redirect( 'missing_key' );
		}
		$response = self::request( 'activate', $key, '' );
		if ( is_wp_error( $response ) || empty( $response['success'] ) || empty( $response['activation_token'] ) ) {
			self::redirect( 'activation_failed' );
		}
		update_option( self::KEY_OPTION, $key, false );
		update_option( self::TOKEN_OPTION, sanitize_text_field( $response['activation_token'] ), false );
		self::store_metadata( $response );
		update_option( self::STATUS_OPTION, 'active', false );
		self::redirect( 'activated' );
	}

	public static function deactivate() {
		self::require_admin();
		check_admin_referer( self::DEACTIVATE_ACTION );
		$key = (string) get_option( self::KEY_OPTION, '' );
		$token = (string) get_option( self::TOKEN_OPTION, '' );
		if ( '' !== $key && '' !== $token ) {
			self::request( 'deactivate', $key, $token );
		}
		delete_option( self::TOKEN_OPTION );
		update_option( self::STATUS_OPTION, 'inactive', false );
		self::redirect( 'deactivated' );
	}

	private static function request( $endpoint, $key, $token ) {
		$response = wp_remote_post(
			trailingslashit( self::API_URL ) . ltrim( $endpoint, '/' ),
			array(
				'timeout' => 15,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body' => wp_json_encode( array( 'license_key' => $key, 'activation_token' => $token, 'instance_id' => self::instance_id(), 'site_url' => home_url( '/' ), 'product_slug' => self::PRODUCT_SLUG ) ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) ? $data : new WP_Error( 'tutorhelper_lms_licence_response', __( 'The licence service returned an invalid response.', 'tutorhelper-lms' ) );
	}

	private static function store_metadata( $response ) {
		$lifetime = ! empty( $response['lifetime'] );
		$expires = isset( $response['expires_at'] ) && is_scalar( $response['expires_at'] ) ? sanitize_text_field( (string) $response['expires_at'] ) : '';
		update_option( self::LIFETIME_OPTION, $lifetime ? 1 : 0, false );
		update_option( self::EXPIRES_OPTION, $lifetime ? '' : $expires, false );
	}

	private static function instance_id() {
		$id = (string) get_option( self::INSTANCE_OPTION, '' );
		if ( '' === $id ) {
			$id = wp_generate_uuid4();
			update_option( self::INSTANCE_OPTION, $id, false );
		}
		return $id;
	}

	private static function require_admin() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage the LMS licence.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
	}

	private static function redirect( $notice ) {
		wp_safe_redirect( add_query_arg( array( 'page' => TutorHelper_Admin::MENU_SLUG, 'tab' => self::SETTINGS_TAB, 'tutorhelper_lms_licence' => sanitize_key( $notice ) ), admin_url( 'admin.php' ) ) );
		exit;
	}
}
