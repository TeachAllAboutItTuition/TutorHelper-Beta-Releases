<?php
/**
 * Explicit reusable-resource selection and protected student delivery.
 *
 * @package TutorHelper_LMS
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_LMS_Resource_Delivery {
	const SOURCE_HOMEWORK = 'pro_homework';
	const LOAD_ACTION = 'tutorhelper_lms_load_homework_resources';
	const DOWNLOAD_ACTION = 'tutorhelper_lms_download_resource';
	const PREVIEW_ACTION = 'tutorhelper_lms_preview_resource';
	const NONCE = 'tutorhelper_lms_resource_delivery';

	public static function init() {
		add_action( 'tutorhelper_pro_homework_resource_fields', array( __CLASS__, 'render_homework_fields' ) );
		add_action( 'tutorhelper_pro_homework_submission_updated', array( __CLASS__, 'save_homework_resources' ), 20 );
		add_action( 'wp_ajax_' . self::LOAD_ACTION, array( __CLASS__, 'ajax_load_homework_resources' ) );
		add_action( 'admin_post_' . self::DOWNLOAD_ACTION, array( __CLASS__, 'stream_download' ) );
		add_action( 'admin_post_' . self::PREVIEW_ACTION, array( __CLASS__, 'stream_preview' ) );
		add_filter( 'tutorhelper_pro_due_homework_item', array( __CLASS__, 'add_student_resources' ), 20, 2 );
		add_action( 'tutorhelper_pro_homework_student_actions', array( __CLASS__, 'render_student_resources' ), 20 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_tutor_assets' ) );
	}

	public static function render_homework_fields() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) { return; }
		$resources = self::tutor_resources( get_current_user_id() );
		?>
		<fieldset class="tutorhelper-pro-homework-resources" data-tutorhelper-lms-homework-resources>
			<legend><?php esc_html_e( 'Learning resources', 'tutorhelper-lms' ); ?></legend>
			<p class="description"><?php esc_html_e( 'Resources are narrowed to the selected Course and Topics. Search can refine the list further. A repeat indicator means this Resource has already been assigned to this student on other homework; you can still choose it deliberately.', 'tutorhelper-lms' ); ?></p>
			<?php if ( empty( $resources ) ) : ?><p class="description"><?php esc_html_e( 'No resources are available yet. Add them in Learning Hub → Resources.', 'tutorhelper-lms' ); ?></p>
			<?php else : ?>
				<p><label class="screen-reader-text" for="tutorhelper-lms-homework-resource-search"><?php esc_html_e( 'Search learning resources', 'tutorhelper-lms' ); ?></label><input id="tutorhelper-lms-homework-resource-search" class="regular-text" type="search" placeholder="<?php esc_attr_e( 'Search selected resources…', 'tutorhelper-lms' ); ?>" data-tutorhelper-lms-resource-search /></p>
				<p class="description" data-tutorhelper-lms-resource-context><?php esc_html_e( 'Select a Course or Topic to filter the Resource Library.', 'tutorhelper-lms' ); ?></p>
				<div class="tutorhelper-lms-resource-selector" data-tutorhelper-lms-resource-selector><?php foreach ( $resources as $resource ) : ?>
					<label data-tutorhelper-lms-resource-row data-resource-course-ids="<?php echo esc_attr( implode( ',', $resource['course_ids'] ) ); ?>" data-resource-topic-ids="<?php echo esc_attr( implode( ',', $resource['topic_ids'] ) ); ?>"><input type="checkbox" name="homework_resource_ids[]" value="<?php echo esc_attr( $resource['id'] ); ?>" /> <?php echo esc_html( $resource['title'] ); ?> <small>(<?php echo esc_html( $resource['type'] ); ?>)</small> <span class="description" hidden data-tutorhelper-lms-previous-resource>↻ <?php esc_html_e( 'Previously assigned', 'tutorhelper-lms' ); ?></span></label>
				<?php endforeach; ?></div><p class="description" hidden data-tutorhelper-lms-resource-empty><?php esc_html_e( 'No matching Resources were found. Refine the Course, Topics or search.', 'tutorhelper-lms' ); ?></p>
			<?php endif; ?>
		</fieldset><?php
	}

	public static function enqueue_tutor_assets( $hook ) {
		// Homework can be edited from the top-level TutorHelper screen and its Student Bookings submenu.
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) || false === strpos( (string) $hook, 'tutorhelper' ) ) { return; }
		$path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-resource-delivery.js';
		wp_enqueue_script( 'tutorhelper-lms-resource-delivery', TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-resource-delivery.js', array(), file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_LMS_PREMIUM_VERSION, true );
		wp_localize_script( 'tutorhelper-lms-resource-delivery', 'tutorhelperLmsResourceDelivery', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'action' => self::LOAD_ACTION,
			'nonce' => wp_create_nonce( self::NONCE ),
		) );
	}

	public static function ajax_load_homework_resources() {
		check_ajax_referer( self::NONCE, 'nonce' );
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) { wp_send_json_error( array( 'message' => __( 'You do not have permission to view these resources.', 'tutorhelper-lms' ) ), 403 ); }
		$source_id = isset( $_POST['source_id'] ) ? absint( $_POST['source_id'] ) : 0;
		$booking_id = isset( $_POST['booking_id'] ) ? absint( $_POST['booking_id'] ) : 0;
		$student_id = self::student_for_source_or_booking( $source_id, $booking_id );
		wp_send_json_success( array( 'resourceIds' => self::resource_ids( self::SOURCE_HOMEWORK, $source_id ), 'previousResourceIds' => $student_id ? self::previous_resource_ids( $student_id, $source_id ) : array() ) );
	}

	public static function save_homework_resources( $homework ) {
		if ( ! is_array( $homework ) || empty( $homework['source_id'] ) || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) { return; }
		$source_id = absint( $homework['source_id'] );
		$ids = isset( $_POST['homework_resource_ids'] ) && is_array( $_POST['homework_resource_ids'] ) ? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['homework_resource_ids'] ) ) ) ) ) : array();
		$allowed = wp_list_pluck( self::tutor_resources( get_current_user_id() ), 'id' );
		$ids = array_values( array_intersect( $ids, array_map( 'absint', $allowed ) ) );
		global $wpdb; $table = TutorHelper_LMS_Database::table( 'resource_delivery' );
		if ( false === $wpdb->delete( $table, array( 'source_type' => self::SOURCE_HOMEWORK, 'source_id' => $source_id ) ) ) { self::log_failure( '', 'resource_delivery_delete_failed' ); return; } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- replaces explicit Resource attachment set.
		foreach ( $ids as $id ) { $snapshot = self::resource_snapshot( $id ); if ( empty( $snapshot['title'] ) || false === $wpdb->insert( $table, array( 'source_type' => self::SOURCE_HOMEWORK, 'source_id' => $source_id, 'resource_id' => $id, 'resource_version' => absint( $snapshot['version'] ), 'resource_snapshot' => wp_json_encode( $snapshot ), 'created_at' => current_time( 'mysql', true ) ) ) ) { self::log_failure( '', 'resource_delivery_insert_failed' ); } } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- saves frozen authorised Resource handouts.
	}

	public static function add_student_resources( $item, $record ) {
		if ( ! is_array( $item ) || ! $record || ! is_user_logged_in() || empty( $record->id ) ) { return $item; }
		$booking = ! empty( $record->booking_id ) ? TutorHelper_Booking_Records::get_by_id( absint( $record->booking_id ) ) : null;
		if ( ! $booking || absint( $booking->student_user_id ) !== get_current_user_id() ) { return $item; }
		$resources = self::student_resource_rows( absint( $record->id ) ); if ( $resources ) { $item['lmsResources'] = $resources; } return $item;
	}

	public static function render_student_resources( $record ) {
		if ( ! $record || empty( $record->id ) || ! is_user_logged_in() ) { return; }
		$booking = ! empty( $record->booking_id ) ? TutorHelper_Booking_Records::get_by_id( absint( $record->booking_id ) ) : null;
		if ( ! $booking || absint( $booking->student_user_id ) !== get_current_user_id() ) { return; }
		$resources = self::student_resource_rows( absint( $record->id ) ); if ( ! $resources ) { return; }
		?><div class="tutorhelper-lms-student-resources"><strong><?php esc_html_e( 'Learning resources', 'tutorhelper-lms' ); ?></strong><?php foreach ( $resources as $resource ) : ?><p><span><?php echo esc_html( $resource['title'] ); ?></span><?php if ( $resource['previewable'] ) : ?><a class="tutorhelper-button" href="<?php echo esc_url( $resource['previewUrl'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Preview', 'tutorhelper-lms' ); ?></a><?php endif; ?><a class="tutorhelper-button" href="<?php echo esc_url( $resource['downloadUrl'] ); ?>"><?php esc_html_e( 'Download', 'tutorhelper-lms' ); ?></a></p><?php endforeach; ?></div><?php
	}

	public static function stream_download() { self::stream( false ); }

	public static function stream_preview() { self::stream( true ); }

	private static function stream( $preview ) {
		$resource_id = isset( $_GET['resource_id'] ) ? absint( $_GET['resource_id'] ) : 0; $source_id = isset( $_GET['source_id'] ) ? absint( $_GET['source_id'] ) : 0;
		check_admin_referer( ( $preview ? self::PREVIEW_ACTION : self::DOWNLOAD_ACTION ) . '_' . $resource_id . '_' . $source_id );
		$attachment = self::attachment( self::SOURCE_HOMEWORK, $source_id, $resource_id );
		if ( ! is_user_logged_in() || ! $attachment || ! self::student_can_access( $resource_id, $source_id ) ) { wp_die( esc_html__( 'You do not have permission to access this resource.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) ); }
		$key = 'tutorhelper_lms_resource_rate_' . get_current_user_id(); $count = (int) get_transient( $key ); if ( $count >= 30 ) { wp_die( esc_html__( 'Please wait a moment before requesting another resource.', 'tutorhelper-lms' ), '', array( 'response' => 429 ) ); } set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
		$file = TutorHelper_LMS_Private_Files::find( TutorHelper_LMS_Private_Files::ENTITY_RESOURCE, $resource_id, absint( $attachment->resource_version ) ); $provider = $file ? TutorHelper_LMS_Storage_Registry::get( $file->storage_provider ) : null; $snapshot = self::snapshot_for_attachment( $attachment );
		if ( ! $file || ! $provider || ( $preview && ! self::is_previewable( $file->mime_type ) ) ) { wp_die( esc_html__( 'This resource is temporarily unavailable. Please contact your tutor.', 'tutorhelper-lms' ), '', array( 'response' => 503 ) ); }
		$result = $provider->stream( $file->provider_file_id, array( 'filename' => ! empty( $snapshot['filename'] ) ? $snapshot['filename'] : $file->display_filename, 'mime_type' => $file->mime_type, 'disposition' => $preview ? 'inline' : 'attachment' ) );
		if ( is_wp_error( $result ) ) { self::log_failure( $file->storage_provider, $result->get_error_code() ); wp_die( esc_html__( 'This resource is temporarily unavailable. Please try again later.', 'tutorhelper-lms' ), '', array( 'response' => 503 ) ); } exit;
	}

	private static function student_can_access( $resource_id, $source_id ) {
		if ( ! self::has_attachment( self::SOURCE_HOMEWORK, $source_id, $resource_id ) ) { return false; }
		if ( current_user_can( TutorHelper_Admin::CAPABILITY ) ) { return true; }
		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'lesson_follow_up' );
		$booking_id = absint( $wpdb->get_var( $wpdb->prepare( "SELECT booking_id FROM {$table} WHERE id = %d LIMIT 1", $source_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- checks the exact attached homework.
		$booking = $booking_id ? TutorHelper_Booking_Records::get_by_id( $booking_id ) : null;
		return $booking && absint( $booking->student_user_id ) === get_current_user_id();
	}

	private static function student_resource_rows( $source_id ) {
		$items = array(); foreach ( self::attachments( self::SOURCE_HOMEWORK, $source_id ) as $attachment ) { $snapshot = self::snapshot_for_attachment( $attachment ); if ( 'private_file' !== $snapshot['type'] ) { continue; } $file = TutorHelper_LMS_Private_Files::find( TutorHelper_LMS_Private_Files::ENTITY_RESOURCE, absint( $attachment->resource_id ), absint( $attachment->resource_version ) ); if ( ! $file ) { continue; } $items[] = array( 'title' => $snapshot['title'], 'previewUrl' => self::url( self::PREVIEW_ACTION, $attachment->resource_id, $source_id ), 'downloadUrl' => self::url( self::DOWNLOAD_ACTION, $attachment->resource_id, $source_id ), 'previewable' => self::is_previewable( $file->mime_type ) ); } return $items;
	}
	private static function attachments( $type, $source_id ) { global $wpdb; $table = TutorHelper_LMS_Database::table( 'resource_delivery' ); return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE source_type = %s AND source_id = %d ORDER BY id ASC", $type, $source_id ) ); } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- reads explicit Resource handouts.
	private static function attachment( $type, $source_id, $resource_id ) { foreach ( self::attachments( $type, $source_id ) as $row ) { if ( absint( $row->resource_id ) === absint( $resource_id ) ) { return $row; } } return null; }
	private static function resource_ids( $type, $source_id ) { return array_map( 'absint', wp_list_pluck( self::attachments( $type, $source_id ), 'resource_id' ) ); }
	private static function has_attachment( $type, $source_id, $resource_id ) { return (bool) self::attachment( $type, $source_id, $resource_id ); }
	private static function tutor_resources( $tutor_id ) { $posts = get_posts( array( 'post_type' => TutorHelper_LMS_Resource_Library::POST_TYPE, 'post_status' => 'publish', 'author' => absint( $tutor_id ), 'numberposts' => 500, 'orderby' => 'title', 'order' => 'ASC' ) ); return array_map( static function( $post ) { $contexts = self::resource_contexts( $post->ID ); return array( 'id' => absint( $post->ID ), 'title' => get_the_title( $post ), 'type' => self::resource_type( $post->ID ), 'course_ids' => $contexts['course_ids'], 'topic_ids' => $contexts['topic_ids'] ); }, $posts ); }
	private static function resource_contexts( $resource_id ) { global $wpdb; $table = TutorHelper_LMS_Free_Database::table( 'content_relationships' ); $rows = $wpdb->get_results( $wpdb->prepare( "SELECT parent_type, parent_id FROM {$table} WHERE child_type = %s AND child_id = %d", TutorHelper_LMS_Resource_Library::POST_TYPE, absint( $resource_id ) ) ); $result = array( 'course_ids' => array(), 'topic_ids' => array() ); foreach ( (array) $rows as $row ) { if ( 'tutorhelper_course' === $row->parent_type ) { $result['course_ids'][] = absint( $row->parent_id ); } if ( 'tutorhelper_topic' === $row->parent_type ) { $result['topic_ids'][] = absint( $row->parent_id ); } } return $result; } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- filters the tutor's own Resource Library by explicit curriculum links.
	private static function resource_snapshot( $resource_id ) { $post = get_post( $resource_id ); if ( ! $post || TutorHelper_LMS_Resource_Library::POST_TYPE !== $post->post_type ) { return array(); } $type = self::resource_type( $resource_id ); $file = 'private_file' === $type ? TutorHelper_LMS_Private_Files::find( TutorHelper_LMS_Private_Files::ENTITY_RESOURCE, $resource_id ) : null; return array( 'title' => sanitize_text_field( get_the_title( $resource_id ) ), 'type' => $type, 'description' => wp_kses_post( $post->post_content ), 'external_url' => esc_url_raw( get_post_meta( $resource_id, TutorHelper_LMS_Resource_Library::META_EXTERNAL_URL, true ) ), 'external_kind' => sanitize_key( get_post_meta( $resource_id, TutorHelper_LMS_Resource_Library::META_EXTERNAL_KIND, true ) ), 'version' => $file ? absint( $file->version_number ) : 1, 'filename' => $file ? sanitize_file_name( $file->display_filename ) : '' ); }
	private static function snapshot_for_attachment( $attachment ) { $snapshot = ! empty( $attachment->resource_snapshot ) ? json_decode( $attachment->resource_snapshot, true ) : array(); if ( ! is_array( $snapshot ) || empty( $snapshot['title'] ) ) { $snapshot = self::resource_snapshot( absint( $attachment->resource_id ) ); } return wp_parse_args( $snapshot, array( 'title' => __( 'Learning resource', 'tutorhelper-lms' ), 'type' => '', 'version' => absint( $attachment->resource_version ), 'filename' => '' ) ); }
	private static function student_for_source_or_booking( $source_id, $booking_id ) { if ( $booking_id ) { $booking = TutorHelper_Booking_Records::get_by_id( $booking_id ); if ( $booking ) { return absint( $booking->student_user_id ); } } if ( ! $source_id ) { return 0; } global $wpdb; $assignments = TutorHelper_LMS_Database::table( 'assignments' ); return absint( $wpdb->get_var( $wpdb->prepare( "SELECT student_user_id FROM {$assignments} WHERE source_type = %s AND source_id = %d LIMIT 1", self::SOURCE_HOMEWORK, $source_id ) ) ); } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- reads assignment owner for authorised tutor request.
	private static function previous_resource_ids( $student_id, $exclude_source_id ) { global $wpdb; $assignments = TutorHelper_LMS_Database::table( 'assignments' ); $delivery = TutorHelper_LMS_Database::table( 'resource_delivery' ); $sql = $wpdb->prepare( "SELECT DISTINCT d.resource_id FROM {$delivery} d INNER JOIN {$assignments} a ON a.source_type = d.source_type AND a.source_id = d.source_id WHERE d.source_type = %s AND a.student_user_id = %d AND d.source_id != %d", self::SOURCE_HOMEWORK, absint( $student_id ), absint( $exclude_source_id ) ); return array_map( 'absint', $wpdb->get_col( $sql ) ); } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- contextual duplicate-assignment hint only.
	private static function resource_type( $id ) { return sanitize_key( get_post_meta( $id, TutorHelper_LMS_Resource_Library::META_TYPE, true ) ); }
	private static function is_previewable( $mime ) { return in_array( strtolower( (string) $mime ), array( 'application/pdf', 'image/jpeg', 'image/png' ), true ); }
	private static function url( $action, $resource_id, $source_id ) { return wp_nonce_url( add_query_arg( array( 'action' => $action, 'resource_id' => absint( $resource_id ), 'source_id' => absint( $source_id ) ), admin_url( 'admin-post.php' ) ), $action . '_' . absint( $resource_id ) . '_' . absint( $source_id ) ); }
	private static function log_failure( $provider, $code ) { do_action( 'tutorhelper_diagnostics_log', 'warning', 'LMS resource delivery failed.', array( 'component' => 'lms', 'provider' => sanitize_key( $provider ), 'error_code' => sanitize_key( $code ) ) ); }
}
