<?php
/**
 * Premium Learning Journey theme registration and asset verification.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps visual-theme assets separate from Course progress and learner access.
 */
final class TutorHelper_LMS_Journey_Themes {

	const TAB = 'journey-themes';
	const CLASSIC_STEPS = 'classic-steps';
	const ACTIVITY_ACTION = 'tutorhelper_lms_save_course_activity_requirement';

	/**
	 * Register the tutor-only preview after all Premium dependencies are available.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'tutorhelper_lms_learning_hub_sections', array( __CLASS__, 'add_hub_section' ) );
		add_filter( 'tutorhelper_lms_learning_hub_render_tab', array( __CLASS__, 'render_hub_section' ), 10, 3 );
		add_action( 'tutorhelper_lms_learner_course_view_before_list', array( __CLASS__, 'render_student_journey' ), 10, 4 );
		add_action( 'tutorhelper_lms_course_builder_activity_options', array( __CLASS__, 'render_activity_requirement_control' ), 10, 3 );
		add_action( 'admin_post_' . self::ACTIVITY_ACTION, array( __CLASS__, 'save_activity_requirement' ) );
	}

	/**
	 * Return the registered visual theme manifest.
	 *
	 * URLs are always derived from the installed Premium plugin, never from a
	 * site, media-library or repository URL.
	 *
	 * @param string $theme_id Theme identifier.
	 * @return array
	 */
	public static function manifest( $theme_id = self::CLASSIC_STEPS ) {
		$theme_id = sanitize_key( $theme_id );
		if ( self::CLASSIC_STEPS !== $theme_id ) {
			return array();
		}

		$files = array(
			'lesson_not_started'    => 'lesson-not-started.png',
			'lesson_complete'       => 'lesson-completed.png',
			'lesson_current'        => 'lesson-current.png',
			'quiz_not_started'      => 'quiz-not-started.png',
			'quiz_passed'           => 'quiz-passed.png',
			'quiz_retry'            => 'quiz-retry.png',
			'sidequest_not_started' => 'side-quest-not-started.png',
			'sidequest_in_progress' => 'side-quest-in-progress.png',
			'sidequest_complete'    => 'side-quest-completed.png',
			'learner_character'     => 'learner-character.png',
			'learner_character_stone' => 'learner-character-stone.png',
			'path_upcoming'         => 'path-upcoming.png',
			'path_complete'         => 'path-completed.png',
			'path_side_branch'      => 'path-side-quest-branch.png',
			'locked_overlay'        => 'locked-step-overlay.png',
			'milestone_start'       => 'milestone-start.png',
			'milestone_finish'      => 'milestone-finish.png',
			'milestone_achievement' => 'milestone-achievement.png',
		);

		$assets = array();
		foreach ( $files as $state => $file ) {
			$assets[ $state ] = self::asset( $file );
		}

		return array(
			'id'          => self::CLASSIC_STEPS,
			'label'       => __( 'Classic Stepping Stones', 'tutorhelper-lms' ),
			'assets'      => $assets,
			'is_complete' => self::assets_available( $assets ),
		);
	}

	/**
	 * Add a Premium-only preview workspace. It does not expose a student Journey.
	 *
	 * @param array $sections Existing Learning Hub sections.
	 * @return array
	 */
	public static function add_hub_section( $sections ) {
		if ( class_exists( 'TutorHelper_LMS_Premium' ) && TutorHelper_LMS_Premium::is_available() ) {
			$sections[ self::TAB ] = array(
				'label'       => __( 'Journey themes', 'tutorhelper-lms' ),
				'icon'        => 'dashicons-admin-appearance',
				'description' => __( 'Preview Learning Journey artwork available to Premium courses.', 'tutorhelper-lms' ),
			);
		}
		return $sections;
	}

	/**
	 * Render the requested preview tab.
	 *
	 * @param bool   $handled Whether another component rendered the tab.
	 * @param string $tab Current tab.
	 * @param array  $sections Hub sections.
	 * @return bool
	 */
	public static function render_hub_section( $handled, $tab, $sections ) {
		if ( $handled || self::TAB !== $tab || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return $handled;
		}

		$theme = self::manifest();
		?>
		<section class="tutorhelper-main-section">
			<header class="tutorhelper-main-section__header is-compact"><div class="tutorhelper-main-section__header-content">
				<h2><?php esc_html_e( 'Learning Journey themes', 'tutorhelper-lms' ); ?></h2>
				<p><?php esc_html_e( 'Classic Stepping Stones is ready for the Premium Learning Journey. This preview does not change Course progress or student access.', 'tutorhelper-lms' ); ?></p>
			</div></header>
			<div class="tutorhelper-main-section__body">
				<?php if ( $theme['is_complete'] ) : ?>
					<p class="notice notice-success inline"><span><?php esc_html_e( 'All Classic Steps artwork is present in this installed Premium package.', 'tutorhelper-lms' ); ?></span></p>
					<div class="tutorhelper-lms-journey-theme-preview" aria-label="<?php esc_attr_e( 'Classic Stepping Stones preview', 'tutorhelper-lms' ); ?>">
						<?php foreach ( array( 'lesson_not_started', 'lesson_current', 'lesson_complete' ) as $state ) : ?>
							<figure><img src="<?php echo esc_url( $theme['assets'][ $state ]['url'] ); ?>" alt="" width="96" height="96" /><figcaption><?php echo esc_html( ucwords( str_replace( '_', ' ', substr( $state, 7 ) ) ) ); ?></figcaption></figure>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<p class="notice notice-error inline"><span><?php esc_html_e( 'Some Classic Steps artwork is missing from this Premium package. Reinstall the complete Premium ZIP before enabling a Learning Journey.', 'tutorhelper-lms' ); ?></span></p>
				<?php endif; ?>
			</div>
		</section>
		<style>.tutorhelper-lms-journey-theme-preview{display:flex;gap:1rem;flex-wrap:wrap}.tutorhelper-lms-journey-theme-preview figure{margin:0;text-align:center}.tutorhelper-lms-journey-theme-preview img{display:block;width:96px;height:96px;object-fit:contain}.tutorhelper-lms-journey-theme-preview figcaption{margin-top:.4rem;font-weight:700}</style>
		<?php
		return true;
	}

	/**
	 * Render the Premium visual representation before the always-available Core list.
	 *
	 * Core supplies the authorised Course context and remains responsible for access.
	 *
	 * @param int    $student_user_id Student user ID.
	 * @param int    $course_id Course ID.
	 * @param string $base_url My Learning page URL.
	 * @param array  $topics Ordered Course Topics.
	 * @return void
	 */
	public static function render_student_journey( $student_user_id, $course_id, $base_url, $topics ) {
		if ( ! class_exists( 'TutorHelper_LMS_Premium' ) || ! TutorHelper_LMS_Premium::is_available() ) {
			return;
		}
		$theme = self::manifest();
		if ( empty( $theme['is_complete'] ) || ! class_exists( 'TutorHelper_LMS_Learner_Progress' ) || ! class_exists( 'TutorHelper_LMS_Learner_Access' ) || ! class_exists( 'TutorHelper_LMS_Gradebook' ) ) {
			return;
		}

		$progress = TutorHelper_LMS_Learner_Progress::course_progress( $student_user_id, $course_id );
		$current  = TutorHelper_LMS_Learner_Progress::resume_context( $student_user_id, $course_id );
		$resume   = TutorHelper_LMS_Learner_Progress::resume_activity( $student_user_id, $course_id );
		$colour   = class_exists( 'TutorHelper_LMS_Course_Settings' ) ? TutorHelper_LMS_Course_Settings::colour( $course_id ) : '';
		$colour   = sanitize_hex_color( $colour ) ?: '#174957';
		$user     = get_userdata( $student_user_id );
		$name     = $user ? trim( (string) $user->first_name ) : '';
		$name     = '' !== $name ? $name : __( 'My', 'tutorhelper-lms' );

		$nodes        = array();
		$side_quests  = array();
		$topic_counter = 0;
		foreach ( (array) $topics as $topic ) {
			$topic_id = absint( $topic['id'] ?? 0 );
			if ( ! $topic_id ) {
				continue;
			}
			++$topic_counter;
			$topic_colour = sanitize_hex_color( get_post_meta( $topic_id, '_tutorhelper_lms_topic_colour', true ) ) ?: $colour;
			$topic_side_quest_anchor = -1;
			foreach ( TutorHelper_LMS_Learner_Access::course_topic_activities( $course_id, $topic_id ) as $activity ) {
				$node = array(
					'topic_id'     => $topic_id,
					'topic'        => (string) ( $topic['title'] ?? '' ),
					'topic_number' => $topic_counter,
					'topic_colour' => $topic_colour,
					'type'         => sanitize_key( $activity['type'] ?? 'lesson' ),
					'id'           => absint( $activity['id'] ?? 0 ),
					'placement_id' => absint( $activity['placement_id'] ?? 0 ),
					'title'        => (string) ( $activity['title'] ?? '' ),
				);
				if ( ! empty( $activity['required'] ) ) {
					$nodes[]                   = $node;
					$topic_side_quest_anchor   = count( $nodes ) - 1;
				} else {
					// A side quest branches from the preceding required activity in its own Topic.
					// -1 deliberately means the Topic begins with an optional activity, so it
					// branches from the Start milestone rather than appearing as a main step.
					$node['side_quest_anchor'] = $topic_side_quest_anchor;
					$side_quests[]             = $node;
				}
			}
		}

		if ( empty( $nodes ) && empty( $side_quests ) ) {
			return;
		}
		?>
		<div class="tutorhelper-lms-journey-switcher" data-tutorhelper-lms-journey-switcher role="group" aria-label="<?php esc_attr_e( 'Course view', 'tutorhelper-lms' ); ?>">
			<button type="button" data-tutorhelper-lms-journey-view aria-pressed="true"><?php esc_html_e( 'Learning Journey', 'tutorhelper-lms' ); ?></button>
			<button type="button" data-tutorhelper-lms-list-view aria-pressed="false"><?php esc_html_e( 'List View', 'tutorhelper-lms' ); ?></button>
			<button type="button" data-tutorhelper-lms-gradebook-view aria-pressed="false"><?php esc_html_e( 'My Gradebook', 'tutorhelper-lms' ); ?></button>
		</div>
		<section class="tutorhelper-lms-journey" data-tutorhelper-lms-journey style="--tutorhelper-journey-colour:<?php echo esc_attr( $colour ); ?>" aria-labelledby="tutorhelper-lms-journey-title">
			<header class="tutorhelper-lms-journey__header">
				<p class="tutorhelper-lms-textbook__eyebrow"><?php echo esc_html( sprintf( __( "%s's Learning Journey", 'tutorhelper-lms' ), $name ) ); ?></p>
				<h4 id="tutorhelper-lms-journey-title"><?php esc_html_e( 'Your learning path', 'tutorhelper-lms' ); ?></h4>
				<p><?php echo esc_html( sprintf( _n( '%1$d of %2$d Lesson complete', '%1$d of %2$d Lessons complete', $progress['total'], 'tutorhelper-lms' ), $progress['complete'], $progress['total'] ) ); ?></p>
				<progress value="<?php echo esc_attr( $progress['complete'] ); ?>" max="<?php echo esc_attr( max( 1, $progress['total'] ) ); ?>"><?php echo esc_html( $progress['complete'] . '/' . max( 1, $progress['total'] ) ); ?></progress>
			</header>
			<div class="tutorhelper-lms-journey__map" data-tutorhelper-lms-journey-map>
				<svg class="tutorhelper-lms-journey__routes" data-tutorhelper-lms-journey-routes aria-hidden="true" focusable="false"></svg>
				<ol class="tutorhelper-lms-journey__nodes" data-tutorhelper-lms-journey-nodes>
					<li class="tutorhelper-lms-journey__milestone is-start" data-tutorhelper-lms-journey-node data-route-colour="<?php echo esc_attr( $colour ); ?>" data-route-state="<?php echo $progress['complete'] ? 'complete' : 'upcoming'; ?>">
						<img src="<?php echo esc_url( $theme['assets']['milestone_start']['url'] ); ?>" alt="" /><span><?php esc_html_e( 'Start', 'tutorhelper-lms' ); ?></span>
					</li>
					<?php
					$previous_topic_id = 0;
					foreach ( $nodes as $number => $node ) :
						$is_quiz    = 'quiz' === ( $node['type'] ?? 'lesson' );
						$state      = $is_quiz ? self::quiz_state( $student_user_id, $course_id, $node['placement_id'] ) : self::lesson_state( $student_user_id, $course_id, $node['topic_id'], $node['id'] );
						$is_complete = $is_quiz ? 'passed' === ( $state['status'] ?? '' ) : 'complete' === ( $state['status'] ?? '' );
						$is_current  = ! $is_quiz && $current && absint( $current['lesson_id'] ?? 0 ) === $node['id'] && absint( $current['topic_id'] ?? 0 ) === $node['topic_id'];
						$is_locked   = $is_quiz ? ! TutorHelper_LMS_Learner_Access::can_view_quiz( $student_user_id, $course_id, $node['placement_id'] ) : ! TutorHelper_LMS_Learner_Access::can_view_lesson( $student_user_id, $course_id, $node['topic_id'], $node['id'] );
						$key         = $is_quiz ? ( 'passed' === ( $state['status'] ?? '' ) ? 'quiz_passed' : ( 'retry' === ( $state['status'] ?? '' ) ? 'quiz_retry' : 'quiz_not_started' ) ) : ( $is_current ? 'lesson_current' : ( $is_complete ? 'lesson_complete' : 'lesson_not_started' ) );
						$status      = $is_locked ? __( 'Locked', 'tutorhelper-lms' ) : ( $is_quiz ? self::quiz_state_label( $state['status'] ?? 'not_started' ) : ( $is_current ? __( 'Current lesson', 'tutorhelper-lms' ) : ( $is_complete ? __( 'Complete', 'tutorhelper-lms' ) : __( 'Not started', 'tutorhelper-lms' ) ) ) );
						$available_from = apply_filters( 'tutorhelper_lms_activity_available_from_label', '', $course_id, $node['topic_id'], $node['type'], $node['id'] );
						$topic_start = $previous_topic_id !== $node['topic_id'];
						$previous_topic_id = $node['topic_id'];
						$tooltip = sprintf( __( '%1$d. %2$s — %3$s', 'tutorhelper-lms' ), $number + 1, $node['title'], $status ) . ( $available_from ? "\n" . $available_from : '' );
						?>
						<li class="tutorhelper-lms-journey__node<?php echo $is_current ? ' is-current' : ''; ?><?php echo $is_complete ? ' is-complete' : ''; ?><?php echo $is_locked ? ' is-locked' : ''; ?>" data-tutorhelper-lms-journey-node data-route-colour="<?php echo esc_attr( $node['topic_colour'] ); ?>" data-route-state="<?php echo esc_attr( ( $is_current || $is_complete ) ? 'complete' : 'upcoming' ); ?>">
							<?php if ( $topic_start ) : ?><span class="tutorhelper-lms-journey__topic-label"><?php echo esc_html( sprintf( __( 'Topic %1$d: %2$s', 'tutorhelper-lms' ), $node['topic_number'], $node['topic'] ) ); ?></span><?php endif; ?>
							<?php if ( ! $is_locked ) : ?><a class="tutorhelper-lms-journey__lesson-link" data-tooltip="<?php echo esc_attr( $tooltip ); ?>" aria-label="<?php echo esc_attr( $tooltip ); ?>" href="<?php echo esc_url( $is_quiz ? TutorHelper_LMS_Learner_Access::quiz_url( $base_url, $course_id, $node['placement_id'], $student_user_id ) : TutorHelper_LMS_Learner_Access::lesson_url( $base_url, $course_id, $node['topic_id'], $node['id'], 0, $student_user_id ) ); ?>"><?php else : ?><span class="tutorhelper-lms-journey__lesson-link is-locked" data-tooltip="<?php echo esc_attr( $tooltip ); ?>" aria-label="<?php echo esc_attr( $tooltip ); ?>" aria-disabled="true"><?php endif; ?>
								<img src="<?php echo esc_url( $theme['assets'][ $key ]['url'] ); ?>" alt="" />
								<?php if ( $is_locked ) : ?><img class="tutorhelper-lms-journey__locked-overlay" src="<?php echo esc_url( $theme['assets']['locked_overlay']['url'] ); ?>" alt="" /><?php endif; ?>
								<span class="screen-reader-text"><?php echo esc_html( $tooltip ); ?></span>
								<?php echo $is_locked ? '</span>' : '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup selected above. ?>
							<?php if ( $is_current ) : ?><img class="tutorhelper-lms-journey__learner" src="<?php echo esc_url( $theme['assets']['learner_character']['url'] ); ?>" alt="" /><?php endif; ?>
						</li>
					<?php endforeach; ?>
					<li class="tutorhelper-lms-journey__milestone is-finish" data-tutorhelper-lms-journey-node data-route-colour="<?php echo esc_attr( $colour ); ?>" data-route-state="<?php echo ( $progress['total'] && $progress['complete'] >= $progress['total'] ) ? 'complete' : 'upcoming'; ?>">
						<img src="<?php echo esc_url( $theme['assets']['milestone_finish']['url'] ); ?>" alt="" /><span><?php esc_html_e( 'Finish', 'tutorhelper-lms' ); ?></span>
					</li>
				</ol>
				<?php if ( $side_quests ) : ?>
					<ol class="tutorhelper-lms-journey__sidequest-nodes" aria-label="<?php esc_attr_e( 'Optional side quests', 'tutorhelper-lms' ); ?>">
						<?php foreach ( $side_quests as $side_quest ) : ?>
							<?php
							$type         = sanitize_key( $side_quest['type'] ?? 'lesson' );
							$state        = 'quiz' === $type ? self::quiz_state( $student_user_id, $course_id, $side_quest['placement_id'] ) : self::lesson_state( $student_user_id, $course_id, $side_quest['topic_id'], $side_quest['id'] );
							$status_key   = sanitize_key( $state['status'] ?? 'not_started' );
							$is_complete  = 'quiz' === $type ? 'passed' === $status_key : 'complete' === $status_key;
							$in_progress  = 'in_progress' === $status_key || 'submitted' === $status_key;
							// Keep one stable side-quest icon until the Journey artwork states have been independently tested.
							$asset_key    = 'sidequest_not_started';
							$quiz_labels  = array(
								'passed'      => __( 'Complete', 'tutorhelper-lms' ),
								'retry'       => __( 'Try again', 'tutorhelper-lms' ),
								'in_progress' => __( 'In progress', 'tutorhelper-lms' ),
								'submitted'   => __( 'Awaiting results', 'tutorhelper-lms' ),
								'not_started' => __( 'Not started', 'tutorhelper-lms' ),
							);
							$status       = 'quiz' === $type ? ( $quiz_labels[ $status_key ] ?? $quiz_labels['not_started'] ) : ( $is_complete ? __( 'Complete', 'tutorhelper-lms' ) : ( $in_progress ? __( 'In progress', 'tutorhelper-lms' ) : __( 'Not started', 'tutorhelper-lms' ) ) );
							$tooltip      = sprintf( __( "💫 Side Quest! 💫\n%1\$s\n%2\$s", 'tutorhelper-lms' ), $side_quest['title'], $status );
							$href         = 'quiz' === $type ? TutorHelper_LMS_Learner_Access::quiz_url( $base_url, $course_id, $side_quest['placement_id'], $student_user_id ) : TutorHelper_LMS_Learner_Access::lesson_url( $base_url, $course_id, $side_quest['topic_id'], $side_quest['id'], 0, $student_user_id );
							?>
							<li class="tutorhelper-lms-journey__sidequest-node is-<?php echo esc_attr( $status_key ); ?>" data-tutorhelper-lms-sidequest-node data-sidequest-anchor="<?php echo esc_attr( (int) $side_quest['side_quest_anchor'] ); ?>" data-route-colour="<?php echo esc_attr( $side_quest['topic_colour'] ); ?>" data-route-state="<?php echo esc_attr( $is_complete ? 'complete' : 'upcoming' ); ?>">
								<a class="tutorhelper-lms-journey__sidequest-link" href="<?php echo esc_url( $href ); ?>" data-tooltip="<?php echo esc_attr( $tooltip ); ?>" aria-label="<?php echo esc_attr( $tooltip ); ?>">
									<img src="<?php echo esc_url( $theme['assets'][ $asset_key ]['url'] ); ?>" alt="" />
									<span class="screen-reader-text"><?php echo esc_html( $tooltip ); ?></span>
								</a>
							</li>
						<?php endforeach; ?>
					</ol>
				<?php endif; ?>
			</div>
			<?php if ( $resume ) : ?><p class="tutorhelper-lms-journey__resume"><a class="tutorhelper-student-booking-notice__action" href="<?php echo esc_url( 'quiz' === ( $resume['type'] ?? '' ) ? TutorHelper_LMS_Learner_Access::quiz_url( $base_url, $course_id, absint( $resume['placement_id'] ?? 0 ), $student_user_id ) : TutorHelper_LMS_Learner_Access::lesson_url( $base_url, $course_id, absint( $resume['topic_id'] ?? 0 ), absint( $resume['id'] ?? 0 ), 0, $student_user_id ) ); ?>"><?php esc_html_e( 'Resume Learning', 'tutorhelper-lms' ); ?></a></p><?php endif; ?>
		</section>
		<div data-tutorhelper-lms-course-gradebook-panel hidden>
			<?php TutorHelper_LMS_Gradebook::render_student_course_gradebook( $student_user_id, $course_id ); ?>
		</div>
		<style>
			.tutorhelper-lms-journey-switcher{display:flex;gap:.5rem;margin:1rem 0 .5rem}.tutorhelper-lms-journey-switcher button{padding:.5rem .8rem;border:1px solid #174957;border-radius:999px;background:#fff;color:#174957;font-weight:700}.tutorhelper-lms-journey-switcher button[aria-pressed=true]{background:#174957;color:#fff}.tutorhelper-lms-journey{margin:0 0 1rem;padding:1rem;border:2px solid var(--tutorhelper-journey-colour);border-radius:14px;background:#fff8ef}.tutorhelper-lms-journey__header progress{width:100%;accent-color:var(--tutorhelper-journey-colour)}.tutorhelper-lms-journey__map{position:relative;min-height:360px;margin:1rem 0}.tutorhelper-lms-journey__routes{position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none}.tutorhelper-lms-journey__route{fill:none;stroke-width:14;stroke-linecap:round}.tutorhelper-lms-journey__route.is-complete{opacity:1}.tutorhelper-lms-journey__route.is-upcoming{opacity:.34}.tutorhelper-lms-journey__nodes{position:absolute;inset:0;margin:0;padding:0;list-style:none}.tutorhelper-lms-journey__node,.tutorhelper-lms-journey__milestone{position:absolute;z-index:1;transform:translate(-50%,-50%);text-align:center}.tutorhelper-lms-journey__node{width:110px}.tutorhelper-lms-journey__lesson-link{position:relative;display:block;color:#174957;text-decoration:none}.tutorhelper-lms-journey__lesson-link>img{display:block;width:94px;height:94px;object-fit:contain;margin:auto}.tutorhelper-lms-journey__lesson-link>.tutorhelper-lms-journey__locked-overlay{position:absolute;z-index:2;top:50%;left:50%;transform:translate(-50%,-50%);pointer-events:none}.tutorhelper-lms-journey__lesson-link.is-locked{cursor:not-allowed}.tutorhelper-lms-journey__lesson-link:focus-visible{outline:3px solid #e86b2d;outline-offset:4px;border-radius:50%}.tutorhelper-lms-journey__lesson-link:after{content:attr(data-tooltip);position:absolute;z-index:5;left:50%;bottom:100%;width:max-content;max-width:190px;padding:.45rem .6rem;border-radius:6px;background:#123f4d;color:#fff;font-size:.8rem;line-height:1.25;white-space:pre-line;opacity:0;pointer-events:none;transform:translate(-50%,-.5rem);transition:opacity .15s ease}.tutorhelper-lms-journey__lesson-link:hover:after,.tutorhelper-lms-journey__lesson-link:focus:after{opacity:1}.tutorhelper-lms-journey__topic-label{display:block;position:absolute;z-index:3;left:50%;bottom:calc(100% + .4rem);width:max-content;max-width:190px;padding:.25rem .45rem;border-radius:999px;background:#fff8ef;box-shadow:0 0 0 3px #fff8ef;color:#174957;font-size:.75rem;font-weight:700;line-height:1.2;transform:translateX(-50%)}.tutorhelper-lms-journey__learner{position:absolute;z-index:2;left:50%;bottom:48%;width:80px;height:80px;object-fit:contain;transform:translateX(-50%);pointer-events:none}.tutorhelper-lms-journey__milestone{font-weight:700;color:#174957}.tutorhelper-lms-journey__milestone img{display:block;width:76px;height:76px;object-fit:contain;margin:auto}.tutorhelper-lms-journey__milestone span{display:inline-block;margin-top:.2rem;padding:.1rem .35rem;border-radius:4px;background:#fff8ef;box-shadow:0 0 0 3px #fff8ef}.tutorhelper-lms-journey__sidequest-nodes{position:absolute;inset:0;margin:0;padding:0;list-style:none;pointer-events:none}.tutorhelper-lms-journey__sidequest-node{position:absolute;z-index:2;width:78px;transform:translate(-50%,-50%);pointer-events:auto}.tutorhelper-lms-journey__sidequest-link{position:relative;display:block}.tutorhelper-lms-journey__sidequest-link>img{display:block;width:68px;height:68px;object-fit:contain;margin:auto}.tutorhelper-lms-journey__sidequest-link:focus-visible{outline:3px solid #e86b2d;outline-offset:4px;border-radius:50%}.tutorhelper-lms-journey__sidequest-link:after{content:attr(data-tooltip);position:absolute;z-index:5;left:50%;bottom:100%;width:max-content;max-width:220px;padding:.5rem .7rem;border-radius:6px;background:#123f4d;color:#fff;font-size:.82rem;font-weight:600;line-height:1.35;text-align:center;white-space:pre-line;opacity:0;pointer-events:none;transform:translate(-50%,-.5rem);transition:opacity .15s ease}.tutorhelper-lms-journey__sidequest-link:hover:after,.tutorhelper-lms-journey__sidequest-link:focus:after{opacity:1}.tutorhelper-lms-journey__resume{margin:0}.tutorhelper-lms-journey__sidequests{margin:1.25rem 0;padding:1rem;border:1px solid #e6cdb4;border-radius:12px;background:#fff}.tutorhelper-lms-journey__sidequests header p{margin:.25rem 0}.tutorhelper-lms-journey__sidequests>ol{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:.75rem;margin:1rem 0 0;padding:0;list-style:none}.tutorhelper-lms-journey__sidequest{border:1px solid #ead9c7;border-radius:10px;background:#fff8ef}.tutorhelper-lms-journey__sidequest a,.tutorhelper-lms-journey__sidequest summary{display:flex;gap:.6rem;align-items:center;padding:.65rem;color:#174957;text-decoration:none;cursor:pointer}.tutorhelper-lms-journey__sidequest a:focus-visible,.tutorhelper-lms-journey__sidequest summary:focus-visible{outline:3px solid #e86b2d;outline-offset:3px}.tutorhelper-lms-journey__sidequest img{width:50px;height:50px;object-fit:contain}.tutorhelper-lms-journey__sidequest strong,.tutorhelper-lms-journey__sidequest small{display:block}.tutorhelper-lms-journey__sidequest small{margin-top:.15rem}.tutorhelper-lms-journey__sidequest-content{padding:0 .75rem .75rem}.tutorhelper-lms-course-overview__side-quest-label{display:inline-block;margin-left:.5rem;padding:.1rem .4rem;border-radius:999px;background:#fff1df;color:#8b421e;font-size:.75rem;font-weight:700}.tutorhelper-lms-journey[hidden]{display:none}@media (prefers-reduced-motion:reduce){.tutorhelper-lms-journey__lesson-link:after{transition:none}}@media (max-width:640px){.tutorhelper-lms-journey{padding:.75rem}.tutorhelper-lms-journey__lesson-link>img{width:78px;height:78px}.tutorhelper-lms-journey__node{width:92px}.tutorhelper-lms-journey__milestone img{width:62px;height:62px}.tutorhelper-lms-journey__topic-label{max-width:130px;font-size:.68rem}.tutorhelper-lms-journey__learner{width:44px;height:44px}}
		</style>
		<script>
			(function(){function boot(){var root=document.querySelector('[data-tutorhelper-lms-journey]'),switcher=document.querySelector('[data-tutorhelper-lms-journey-switcher]');if(!root||!switcher){return;}var list=root.parentElement.querySelector('[data-tutorhelper-lms-core-course-list]'),journeyButton=switcher.querySelector('[data-tutorhelper-lms-journey-view]'),listButton=switcher.querySelector('[data-tutorhelper-lms-list-view]'),map=root.querySelector('[data-tutorhelper-lms-journey-map]'),svg=root.querySelector('[data-tutorhelper-lms-journey-routes]'),nodes=[].slice.call(root.querySelectorAll('[data-tutorhelper-lms-journey-node]')),sidequests=[].slice.call(root.querySelectorAll('[data-tutorhelper-lms-sidequest-node]'));function mode(showJourney){root.hidden=!showJourney;if(list){list.hidden=showJourney;}journeyButton.setAttribute('aria-pressed',showJourney?'true':'false');listButton.setAttribute('aria-pressed',showJourney?'false':'true');}function route(from,to,colour,complete,dashed){var path=document.createElementNS('http://www.w3.org/2000/svg','path'),horizontal=Math.max(14,Math.min(30,Math.abs(to.x-from.x)*.12)),wave=to.y>=from.y?horizontal:-horizontal,d='M '+from.x+' '+from.y+' C '+(from.x+(to.x-from.x)*.28)+' '+(from.y+wave)+' '+(to.x-(to.x-from.x)*.28)+' '+(to.y-wave)+' '+to.x+' '+to.y;path.setAttribute('d',d);path.setAttribute('class','tutorhelper-lms-journey__route '+(complete?'is-complete':'is-upcoming'));path.style.stroke=colour||'#174957';if(dashed){path.style.strokeWidth='6';path.style.strokeDasharray='10 10';}svg.appendChild(path);}function draw(){var width=map.clientWidth;if(!width){return;}var capacity=width>=1100?5:(width>=760?4:3),mobile=width<640,side=mobile?48:78,rowHeight=mobile?166:190,rows=Math.ceil(nodes.length/capacity),height=Math.max(mobile?400:440,rows*rowHeight+150),positions=[];map.style.height=height+'px';nodes.forEach(function(node,index){var row=Math.floor(index/capacity),column=index%capacity,itemsInRow=Math.min(capacity,nodes.length-row*capacity),position=row%2===0?column:(itemsInRow-1-column),fraction=itemsInRow===1?.5:position/(itemsInRow-1),point={x:Math.round(side+(width-side*2)*fraction),y:Math.round(92+row*rowHeight)};positions.push(point);node.style.left=point.x+'px';node.style.top=point.y+'px';});svg.setAttribute('viewBox','0 0 '+width+' '+height);svg.setAttribute('width',width);svg.setAttribute('height',height);svg.innerHTML='';for(var i=1;i<positions.length;i++){route(positions[i-1],positions[i],(i===nodes.length-1?nodes[i]:nodes[i-1]).getAttribute('data-route-colour'),nodes[i].getAttribute('data-route-state')==='complete',false);}var branches={};sidequests.forEach(function(node){var anchorNumber=parseInt(node.getAttribute('data-sidequest-anchor'),10),anchor=positions[isNaN(anchorNumber)?0:Math.max(0,anchorNumber+1)]||positions[0],count=branches[anchorNumber]||0,sign=count%2===0?1:-1,point={x:Math.max(side,Math.min(width-side,anchor.x+(mobile?52:76)*sign)),y:Math.min(height-44,anchor.y+(mobile?72:94)+(Math.floor(count/2)*(mobile?54:70)))};branches[anchorNumber]=count+1;node.style.left=point.x+'px';node.style.top=point.y+'px';route(anchor,point,node.getAttribute('data-route-colour'),node.getAttribute('data-route-state')==='complete',true);});}journeyButton.addEventListener('click',function(){mode(true);draw();});listButton.addEventListener('click',function(){mode(false);});mode(true);draw();window.addEventListener('resize',draw);if(window.ResizeObserver){new ResizeObserver(draw).observe(map);}}if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',boot);}else{boot();}})();
		</script>
		<script>
			(function() {
				function boot() {
					var root = document.querySelector( '[data-tutorhelper-lms-journey]' );
					var switcher = document.querySelector( '[data-tutorhelper-lms-journey-switcher]' );
					if ( ! root || ! switcher ) {
						return;
					}
					var list = root.parentElement.querySelector( '[data-tutorhelper-lms-core-course-list]' );
					var panel = root.parentElement.querySelector( '[data-tutorhelper-lms-course-gradebook-panel]' );
					var journeyButton = switcher.querySelector( '[data-tutorhelper-lms-journey-view]' );
					var listButton = switcher.querySelector( '[data-tutorhelper-lms-list-view]' );
					var gradebookButton = switcher.querySelector( '[data-tutorhelper-lms-gradebook-view]' );
					if ( ! panel || ! journeyButton || ! listButton || ! gradebookButton ) {
						return;
					}
					function setPressed( active ) {
						journeyButton.setAttribute( 'aria-pressed', active === journeyButton ? 'true' : 'false' );
						listButton.setAttribute( 'aria-pressed', active === listButton ? 'true' : 'false' );
						gradebookButton.setAttribute( 'aria-pressed', active === gradebookButton ? 'true' : 'false' );
					}
					gradebookButton.addEventListener( 'click', function() {
						root.hidden = true;
						if ( list ) {
							list.hidden = true;
						}
						panel.hidden = false;
						setPressed( gradebookButton );
					} );
					journeyButton.addEventListener( 'click', function() {
						panel.hidden = true;
						setPressed( journeyButton );
					} );
					listButton.addEventListener( 'click', function() {
						panel.hidden = true;
						setPressed( listButton );
					} );
				}
				if ( document.readyState === 'loading' ) {
					document.addEventListener( 'DOMContentLoaded', boot );
				} else {
					boot();
				}
			}());
		</script>
		<?php
	}

	/**
	 * Show a Premium-only requirement switch beside one Course activity.
	 *
	 * @param object $activity Course activity row.
	 * @param int    $course_id Course ID.
	 * @param int    $topic_id Topic ID.
	 * @return void
	 */
	public static function render_activity_requirement_control( $activity, $course_id, $topic_id ) {
		if ( ! is_object( $activity ) || ! in_array( sanitize_key( $activity->activity_type ?? '' ), array( 'lesson', 'quiz' ), true ) || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$required = ! isset( $activity->is_required ) || (bool) absint( $activity->is_required );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-lms-course-builder__activity-requirement">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTIVITY_ACTION ); ?>" />
			<input type="hidden" name="course_id" value="<?php echo esc_attr( absint( $course_id ) ); ?>" />
			<input type="hidden" name="topic_id" value="<?php echo esc_attr( absint( $topic_id ) ); ?>" />
			<input type="hidden" name="activity_id" value="<?php echo esc_attr( absint( $activity->activity_id ) ); ?>" />
			<input type="hidden" name="activity_type" value="<?php echo esc_attr( sanitize_key( $activity->activity_type ) ); ?>" />
			<input type="hidden" name="is_required" value="<?php echo esc_attr( $required ? 0 : 1 ); ?>" />
			<?php wp_nonce_field( self::ACTIVITY_ACTION . '_' . absint( $course_id ) . '_' . absint( $topic_id ) . '_' . absint( $activity->activity_id ) ); ?>
			<span class="description"><?php echo esc_html( $required ? __( 'Required for Course completion', 'tutorhelper-lms' ) : __( 'Optional side quest', 'tutorhelper-lms' ) ); ?></span>
			<button type="submit" class="button tutorhelper-lms-button--grey"><?php echo esc_html( $required ? __( 'Make side quest', 'tutorhelper-lms' ) : __( 'Make required', 'tutorhelper-lms' ) ); ?></button>
		</form>
		<?php
	}

	/**
	 * Save one verified Course activity requirement flag.
	 *
	 * @return void
	 */
	public static function save_activity_requirement() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update Course activities.', 'tutorhelper-lms' ), '', array( 'response' => 403 ) );
		}
		$course_id = isset( $_POST['course_id'] ) && ! is_array( $_POST['course_id'] ) ? absint( wp_unslash( $_POST['course_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified below.
		$topic_id = isset( $_POST['topic_id'] ) && ! is_array( $_POST['topic_id'] ) ? absint( wp_unslash( $_POST['topic_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified below.
		$activity_id = isset( $_POST['activity_id'] ) && ! is_array( $_POST['activity_id'] ) ? absint( wp_unslash( $_POST['activity_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified below.
		$type = isset( $_POST['activity_type'] ) && ! is_array( $_POST['activity_type'] ) ? sanitize_key( wp_unslash( $_POST['activity_type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified below.
		check_admin_referer( self::ACTIVITY_ACTION . '_' . $course_id . '_' . $topic_id . '_' . $activity_id );
		$required = isset( $_POST['is_required'] ) && ! is_array( $_POST['is_required'] ) && '1' === (string) wp_unslash( $_POST['is_required'] );
		$topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
		$topic_valid = false;
		foreach ( (array) $topics as $topic ) {
			if ( $topic_id === absint( $topic['id'] ?? 0 ) ) {
				$topic_valid = true;
				break;
			}
		}
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'course_topic_activities' );
		$updated = $course_id && $topic_valid && in_array( $type, array( 'lesson', 'quiz' ), true ) && $table
			? $wpdb->update( $table, array( 'is_required' => $required ? 1 : 0, 'updated_at' => current_time( 'mysql', true ) ), array( 'course_id' => $course_id, 'topic_id' => $topic_id, 'activity_type' => $type, 'activity_id' => $activity_id ), array( '%d', '%s' ), array( '%d', '%d', '%s', '%d' ) )
			: false; // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Updates one verified Course-specific Premium setting.
		$redirect = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=' . TutorHelper_LMS_Learning_Hub::PAGE_SLUG . '&tab=courses' );
		wp_safe_redirect( add_query_arg( 'tutorhelper_lms_side_quest_saved', false === $updated ? '0' : '1', $redirect ) );
		exit;
	}

	/**
	 * Return safe learner state for one Course Quiz placement.
	 *
	 * @return array{status:string}
	 */
	private static function quiz_state( $student_user_id, $course_id, $placement_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		if ( ! $table || ! $placement_id ) {
			return array( 'status' => 'not_started' );
		}
		$attempts = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE student_user_id = %d AND course_id = %d AND course_quiz_placement_id = %d ORDER BY id DESC", absint( $student_user_id ), absint( $course_id ), absint( $placement_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads only the current learner's own Course Quiz history.
		if ( empty( $attempts ) ) {
			return array( 'status' => 'not_started' );
		}

		// Passing a Quiz is an achievement, not a property of its most recent attempt.
		// A later practice attempt must never erase a visible earlier pass in the Journey.
		foreach ( $attempts as $attempt ) {
			if ( 'completed' === (string) $attempt->status && TutorHelper_LMS_Quiz_Attempts::results_released( $attempt ) ) {
				$score = TutorHelper_LMS_Quiz_Attempts::attempt_score( $attempt->id );
				if ( ! empty( $score['passed'] ) ) {
					return array( 'status' => 'passed' );
				}
			}
		}

		$latest = $attempts[0];
		if ( 'in_progress' === (string) $latest->status ) {
			return array( 'status' => 'in_progress' );
		}
		if ( 'completed' !== (string) $latest->status || ! TutorHelper_LMS_Quiz_Attempts::results_released( $latest ) ) {
			return array( 'status' => 'submitted' );
		}
		return array( 'status' => 'retry' );
	}

	/**
	 * Translate a safe learner Quiz state without exposing unreleased results.
	 *
	 * @param string $status Quiz state.
	 * @return string
	 */
	private static function quiz_state_label( $status ) {
		$labels = array(
			'passed'      => __( 'Quiz passed', 'tutorhelper-lms' ),
			'retry'       => __( 'Try again', 'tutorhelper-lms' ),
			'in_progress' => __( 'Quiz in progress', 'tutorhelper-lms' ),
			'submitted'   => __( 'Submitted — awaiting results', 'tutorhelper-lms' ),
			'not_started' => __( 'Quiz not started', 'tutorhelper-lms' ),
		);
		$status = sanitize_key( $status );
		return $labels[ $status ] ?? $labels['not_started'];
	}

	/**
	 * Return learner-safe Topic Resources as optional Journey helpers.
	 *
	 * Private files are intentionally excluded until Course-specific protected
	 * delivery is implemented; rich text and external HTTPS links are safe.
	 *
	 * @param int $topic_id Topic ID.
	 * @return array
	 */
	private static function topic_sidequest_resources( $topic_id ) {
		if ( ! class_exists( 'TutorHelper_LMS_Resource_Library' ) ) {
			return array();
		}
		global $wpdb;
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$ids = $table ? $wpdb->get_col( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", 'tutorhelper_topic', absint( $topic_id ), TutorHelper_LMS_Resource_Library::POST_TYPE ) ) : array(); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads explicit Topic-owned Resource links for the authorised Course Journey.
		$resources = array();
		foreach ( array_map( 'absint', (array) $ids ) as $resource_id ) {
			$resource = get_post( $resource_id );
			$type = sanitize_key( get_post_meta( $resource_id, TutorHelper_LMS_Resource_Library::META_TYPE, true ) );
			if ( ! $resource || 'publish' !== $resource->post_status || ! in_array( $type, array( 'rich_text', 'external_link' ), true ) ) {
				continue;
			}
			$url = esc_url_raw( get_post_meta( $resource_id, TutorHelper_LMS_Resource_Library::META_EXTERNAL_URL, true ), array( 'https' ) );
			if ( 'external_link' === $type && '' === $url ) {
				continue;
			}
			$resources[] = array(
				'type'          => 'resource',
				'id'            => $resource_id,
				'title'         => $resource->post_title,
				'resource_type' => $type,
				'content'       => $resource->post_content,
				'external_url'  => $url,
			);
		}
		return $resources;
	}

	/**
	 * Read ordered Lesson relationships for an authorised Course Topic.
	 *
	 * @param int $topic_id Topic ID.
	 * @return array
	 */
	private static function topic_lessons( $topic_id ) {
		global $wpdb;
		if ( ! class_exists( 'TutorHelper_LMS_Free_Database' ) ) {
			return array();
		}
		$table = TutorHelper_LMS_Free_Database::table( 'content_relationships' );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT child_id FROM {$table} WHERE parent_type = %s AND parent_id = %d AND child_type = %s ORDER BY sort_order ASC, id ASC", 'tutorhelper_topic', absint( $topic_id ), 'tutorhelper_lesson' ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$lessons = array();
		foreach ( (array) $rows as $row ) {
			$lesson = get_post( absint( $row['child_id'] ?? 0 ) );
			if ( $lesson && 'tutorhelper_lesson' === $lesson->post_type && 'publish' === $lesson->post_status ) {
				$lessons[] = array( 'id' => $lesson->ID, 'title' => $lesson->post_title );
			}
		}
		return $lessons;
	}

	/**
	 * Read only the current student's durable state from the existing Core table.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $course_id Course ID.
	 * @param int $topic_id Topic ID.
	 * @param int $lesson_id Lesson ID.
	 * @return array
	 */
	private static function lesson_state( $student_user_id, $course_id, $topic_id, $lesson_id ) {
		global $wpdb;
		if ( ! class_exists( 'TutorHelper_LMS_Free_Database' ) ) {
			return array();
		}
		$table = TutorHelper_LMS_Free_Database::table( 'learner_lesson_state' );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT status FROM {$table} WHERE student_user_id = %d AND course_id = %d AND topic_id = %d AND lesson_id = %d LIMIT 1", $student_user_id, $course_id, $topic_id, $lesson_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return is_array( $row ) ? $row : array();
	}

	/**
	 * Build one asset descriptor from a fixed manifest filename.
	 *
	 * @param string $file Approved PNG filename.
	 * @return array
	 */
	private static function asset( $file ) {
		$file = basename( $file );
		$relative = 'assets/images/journey/' . self::CLASSIC_STEPS . '/' . $file;
		return array(
			'file'   => $file,
			'path'   => TUTORHELPER_LMS_PREMIUM_PATH . $relative,
			'url'    => TUTORHELPER_LMS_PREMIUM_URL . $relative,
			'exists' => is_readable( TUTORHELPER_LMS_PREMIUM_PATH . $relative ),
		);
	}

	/**
	 * Confirm that every required manifest asset is bundled.
	 *
	 * @param array $assets Theme asset descriptors.
	 * @return bool
	 */
	private static function assets_available( $assets ) {
		foreach ( $assets as $asset ) {
			if ( empty( $asset['exists'] ) ) {
				return false;
			}
		}
		return true;
	}
}
