<?php
/**
 * Primary TutorHelper LMS controller.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS {

	/** @var TutorHelper_LMS|null */
	private static $instance = null;

	/**
	 * Return the single LMS controller.
	 *
	 * @return TutorHelper_LMS
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Activation handler.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( ! TutorHelper_LMS_Dependency::is_available() ) {
			return;
		}

		TutorHelper_LMS_Database::install_or_upgrade();
		TutorHelper_LMS_Learning::register_content_types();
	}

	/**
	 * Start LMS only when its two required plugins are available.
	 *
	 * @return void
	 */
	public function run() {
		add_action( 'admin_notices', array( 'TutorHelper_LMS_Dependency', 'render_notice' ) );

		if ( ! TutorHelper_LMS_Dependency::is_available() ) {
			return;
		}

		TutorHelper_LMS_Database::maybe_upgrade();
		TutorHelper_LMS_Learning::init();
		TutorHelper_LMS_Premium::init();

		// Providers remain registered for authenticated, read-only access to historic premium submissions.
		TutorHelper_LMS_Local_Storage_Provider::init();
		TutorHelper_LMS_Google_Drive_Provider::init();

		if ( TutorHelper_LMS_Premium::is_available() ) {
			TutorHelper_LMS_Private_Storage::maybe_refresh_status();
			TutorHelper_LMS_Settings::init();
			TutorHelper_LMS_Google_Drive_Auth::init();
			TutorHelper_LMS_Google_Drive_Settings::init();
			TutorHelper_LMS_Resource_Files::init();
			TutorHelper_LMS_Resource_Delivery::init();
			TutorHelper_LMS_Learning_Delivery::init();
			TutorHelper_LMS_Quiz_Homework::init();
			TutorHelper_LMS_Submissions::init();
			TutorHelper_LMS_Quiz_Written_Responses::init();
			TutorHelper_LMS_Quiz_Annotations::init();
			TutorHelper_LMS_Homework_Annotations::init();
			TutorHelper_LMS_Marked_Files::init();
			TutorHelper_LMS_Adaptive_Practice::init();
			TutorHelper_LMS_Timed_Quizzes::init();
			TutorHelper_LMS_Gradebook::init();
			TutorHelper_LMS_Course_Progression::init();
			TutorHelper_LMS_Journey_Themes::init();
		} else {
			TutorHelper_LMS_Submissions::init_read_only();
		}
	}
}
