<?php
/**
 * Homework image/PDF annotation workspace.
 *
 * @package TutorHelper_LMS
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TutorHelper_LMS_Homework_Annotations {
	const LOAD_ACTION = 'tutorhelper_lms_load_homework_annotation';
	const SAVE_ACTION = 'tutorhelper_lms_save_homework_annotation';

	public static function init() {
		add_action( 'wp_ajax_' . self::LOAD_ACTION, array( __CLASS__, 'ajax_load' ) );
		add_action( 'wp_ajax_' . self::SAVE_ACTION, array( __CLASS__, 'ajax_save' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	public static function enqueue_assets( $hook ) {
		if ( false === strpos( (string) $hook, 'tutorhelper' ) ) { return; }
		wp_localize_script( 'tutorhelper-lms-quiz-annotations', 'tutorhelperLmsHomeworkAnnotations', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( self::LOAD_ACTION ),
			'saveNonce' => wp_create_nonce( self::SAVE_ACTION ),
			'loadAction' => self::LOAD_ACTION,
			'saveAction' => self::SAVE_ACTION,
			'loadFailed' => __( 'The homework annotation workspace could not be loaded.', 'tutorhelper-lms' ),
			'saveFailed' => __( 'Homework annotations could not be saved.', 'tutorhelper-lms' ),
		) );
		wp_localize_script( 'tutorhelper-lms-pdf-annotations', 'tutorhelperLmsHomeworkPdfAnnotations', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( self::LOAD_ACTION ),
			'saveNonce' => wp_create_nonce( self::SAVE_ACTION ),
			'loadAction' => self::LOAD_ACTION,
			'saveAction' => self::SAVE_ACTION,
			'pdfJsUrl' => apply_filters( 'tutorhelper_lms_pdfjs_url', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs' ),
			'pdfWorkerUrl' => apply_filters( 'tutorhelper_lms_pdfjs_worker_url', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs' ),
			'pdfLibUrl' => apply_filters( 'tutorhelper_lms_pdflib_url', 'https://cdn.jsdelivr.net/npm/pdf-lib@1.17.1/+esm' ),
			'loadFailed' => __( 'The homework PDF annotation workspace could not be loaded.', 'tutorhelper-lms' ),
			'saveFailed' => __( 'Homework PDF annotations could not be saved.', 'tutorhelper-lms' ),
		) );
	}

	public static function supports_file( $file ) {
		return $file && in_array( sanitize_mime_type( $file->mime_type ?? '' ), array( 'application/pdf', 'image/jpeg', 'image/png' ), true );
	}

	public static function render_trigger( $submission, $file ) {
		if ( ! self::supports_file( $file ) ) { return; }
		$type = 'application/pdf' === sanitize_mime_type( $file->mime_type ) ? 'pdf' : 'image';
		echo '<button type="button" class="button tutorhelper-action-button" data-tutorhelper-lms-homework-annotation="' . esc_attr( $submission->id ) . '" data-submission-id="' . esc_attr( $submission->id ) . '" data-file-type="' . esc_attr( $type ) . '" data-file-title="' . esc_attr( $file->original_filename ) . '">' . esc_html( 'pdf' === $type ? __( 'Mark PDF', 'tutorhelper-lms' ) : __( 'Mark image', 'tutorhelper-lms' ) ) . '</button>';
	}

	public static function render_preview( $submission, $file ) {
		if ( ! self::supports_file( $file ) ) { return; }
		$annotation = self::annotation_for( $submission->id );
		$url = self::preview_url( $submission->id );
		if ( 'application/pdf' === sanitize_mime_type( $file->mime_type ) ) {
			echo '<div class="tutorhelper-lms-quiz__annotation-preview tutorhelper-lms-pdf-annotation-preview" data-tutorhelper-lms-homework-pdf-annotation-preview data-submission-id="' . esc_attr( $submission->id ) . '" data-pdf-url="' . esc_url( $url ) . '" data-annotation="' . esc_attr( wp_json_encode( $annotation ) ) . '"><strong>' . esc_html__( 'Current marked PDF preview', 'tutorhelper-lms' ) . '</strong><div class="tutorhelper-lms-pdf-annotation-preview__page"><p class="tutorhelper-lms-pdf-annotation-preview__loading">' . esc_html__( 'Loading marked PDF preview…', 'tutorhelper-lms' ) . '</p></div></div>';
			return;
		}
		echo '<div class="tutorhelper-lms-quiz__annotation-preview"><strong>' . esc_html__( 'Current marking preview', 'tutorhelper-lms' ) . '</strong><div class="tutorhelper-lms-quiz__annotated-image" data-tutorhelper-lms-homework-annotation-display data-submission-id="' . esc_attr( $submission->id ) . '" data-annotation="' . esc_attr( wp_json_encode( $annotation ) ) . '"><img class="tutorhelper-lms-quiz__submitted-image" src="' . esc_url( $url ) . '" alt="' . esc_attr( $file->original_filename ) . '" /><canvas aria-hidden="true"></canvas></div></div>';
	}

	public static function ajax_load() {
		check_ajax_referer( self::LOAD_ACTION, 'nonce' );
		$submission = self::tutor_submission( isset( $_POST['submission_id'] ) ? absint( $_POST['submission_id'] ) : 0 );
		$file = $submission ? self::file_for_submission( $submission->id ) : null;
		if ( ! $submission || ! self::supports_file( $file ) ) { wp_send_json_error( array( 'message' => __( 'You do not have permission to annotate this submission.', 'tutorhelper-lms' ) ), 403 ); }
		wp_send_json_success( array( 'submissionId' => absint( $submission->id ), 'filename' => $file->original_filename, 'imageUrl' => self::preview_url( $submission->id ), 'fileUrl' => self::preview_url( $submission->id ), 'annotation' => self::annotation_for( $submission->id ) ) );
	}

	public static function ajax_save() {
		check_ajax_referer( self::SAVE_ACTION, 'nonce' );
		$submission = self::tutor_submission( isset( $_POST['submission_id'] ) ? absint( $_POST['submission_id'] ) : 0 );
		if ( ! $submission ) { wp_send_json_error( array( 'message' => __( 'You do not have permission to save annotations for this submission.', 'tutorhelper-lms' ) ), 403 ); }
		$raw = isset( $_POST['annotation'] ) ? json_decode( wp_unslash( $_POST['annotation'] ), true ) : array();
		$annotation = self::sanitise( $raw );
		global $wpdb; $table = TutorHelper_LMS_Database::table( 'homework_file_annotations' ); $now = current_time( 'mysql', true );
		$data = array( 'annotation_json' => wp_json_encode( $annotation ), 'marker_user_id' => get_current_user_id(), 'updated_at' => $now );
		if ( self::annotation_row( $submission->id ) ) { $wpdb->update( $table, $data, array( 'submission_id' => $submission->id ) ); } else { $data['submission_id'] = $submission->id; $data['created_at'] = $now; $wpdb->insert( $table, $data ); }
		wp_send_json_success( array( 'annotation' => $annotation ) );
	}

	public static function annotation_for( $submission_id ) { $row = self::annotation_row( $submission_id ); $data = $row ? json_decode( (string) $row->annotation_json, true ) : array(); return self::sanitise( $data ); }

	private static function annotation_row( $id ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . TutorHelper_LMS_Database::table( 'homework_file_annotations' ) . ' WHERE submission_id = %d LIMIT 1', absint( $id ) ) ); }
	private static function file_for_submission( $id ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . TutorHelper_LMS_Database::table( 'submission_files' ) . ' WHERE submission_id = %d LIMIT 1', absint( $id ) ) ); }
	private static function preview_url( $id ) {
		$action = TutorHelper_LMS_Submissions::PREVIEW_ACTION;
		return add_query_arg(
			array(
				'action'        => $action,
				'submission_id' => absint( $id ),
				'_wpnonce'      => wp_create_nonce( $action . '_' . absint( $id ) ),
			),
			admin_url( 'admin-post.php' )
		);
	}
	private static function tutor_submission( $id ) { global $wpdb; $s=TutorHelper_LMS_Database::table('submissions'); $a=TutorHelper_LMS_Database::table('assignments'); return $wpdb->get_row( $wpdb->prepare( "SELECT s.* FROM {$s} s INNER JOIN {$a} a ON a.id=s.assignment_id WHERE s.id=%d AND a.tutor_user_id=%d LIMIT 1", absint($id), get_current_user_id() ) ); }

	private static function sanitise( $document ) {
		if ( isset( $document['pages'] ) && is_array( $document['pages'] ) ) { $pages=array(); foreach($document['pages'] as $number=>$page){ if(absint($number)){ $pages[(string)absint($number)]=self::page($page); } } return array('version'=>2,'pages'=>$pages); }
		return self::page( $document );
	}
	private static function page( $page ) {
		$items=array(); foreach ( (array) ( is_array($page) ? ($page['items']??array()) : array() ) as $item ) { if(!is_array($item))continue; if('stamp'===($item['type']??'')){ $items[]=array('type'=>'stamp','stamp'=>sanitize_key($item['stamp']??''),'x'=>self::number($item['x']??0),'y'=>self::number($item['y']??0),'scale'=>max(.025,min(.12,(float)($item['scale']??.06)))); } elseif('stroke'===($item['type']??'')&&isset($item['points'])&&is_array($item['points'])) { $points=array();foreach($item['points'] as $p){if(is_array($p))$points[]=array('x'=>self::number($p['x']??0),'y'=>self::number($p['y']??0));}if(count($points)>1)$items[]=array('type'=>'stroke','colour'=>preg_match('/^#[0-9a-f]{6}$/i',(string)($item['colour']??''))?(string)$item['colour']:'#d3483f','width'=>max(.001,min(.05,(float)($item['width']??.01))),'points'=>$points); } } return array('version'=>1,'items'=>$items);
	}
	private static function number($number) { return max(0,min(1,is_numeric($number)?(float)$number:0)); }
}