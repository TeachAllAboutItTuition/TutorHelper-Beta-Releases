<?php
/**
 * Private master-file uploads for TutorHelper LMS Resources.
 *
 * R2 stores file metadata independently from the free Resource record. It does
 * not grant student access or create public URLs; R4 adds delivery rules.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Resource_Files {

	const FILE_INPUT = 'tutorhelper_lms_resource_file';
	const NOTICE_TRANSIENT_PREFIX = 'tutorhelper_lms_resource_file_notice_';

	/** Register Premium Resource file hooks. */
	public static function init() {
		add_filter( 'tutorhelper_lms_resource_types', array( __CLASS__, 'add_resource_type' ) );
		add_action( 'tutorhelper_lms_resource_library_after_type_fields', array( __CLASS__, 'render_upload_field' ) );
		add_action( 'tutorhelper_lms_resource_library_saved', array( __CLASS__, 'save_upload' ), 10, 3 );
		add_action( 'tutorhelper_lms_resource_library_notices', array( __CLASS__, 'render_notice' ) );
	}

	/** Add private master files only while the Premium service is available. */
	public static function add_resource_type( $types ) {
		if ( TutorHelper_LMS_Premium::is_available() && is_array( $types ) ) {
			$types['private_file'] = __( 'Private uploaded file', 'tutorhelper-lms' );
		}
		return $types;
	}

	/**
	 * Render an upload control inside the Core Resource form.
	 *
	 * @param WP_Post|null $resource Resource currently being edited.
	 * @return void
	 */
	public static function render_upload_field( $resource ) {
		if ( ! TutorHelper_LMS_Premium::is_available() ) {
			return;
		}

		$resource_id = $resource instanceof WP_Post ? absint( $resource->ID ) : 0;
		$file = $resource_id ? TutorHelper_LMS_Private_Files::find( TutorHelper_LMS_Private_Files::ENTITY_RESOURCE, $resource_id ) : null;
		$provider = self::active_provider();
		?>
		<div data-tutorhelper-lms-resource-fields="private_file">
			<?php if ( $file ) : ?>
				<p><strong><?php esc_html_e( 'Current private master file', 'tutorhelper-lms' ); ?></strong><br /><?php echo esc_html( $file->display_filename ); ?><span class="description"><?php esc_html_e( 'This Resource already has its initial master file. Replacement and version history will be added in a later Resource versioning batch.', 'tutorhelper-lms' ); ?></span></p>
			<?php elseif ( ! $provider ) : ?>
				<p class="notice notice-warning inline"><span><?php esc_html_e( 'Choose and verify protected WordPress storage or connected Google Drive in TutorHelper Settings before uploading a private Resource file.', 'tutorhelper-lms' ); ?></span></p>
			<?php else : ?>
				<p><label for="tutorhelper-lms-resource-file"><strong><?php esc_html_e( 'Upload private master file', 'tutorhelper-lms' ); ?></strong></label><input id="tutorhelper-lms-resource-file" type="file" name="<?php echo esc_attr( self::FILE_INPUT ); ?>" accept=".pdf,.docx,.pptx,.xlsx,.jpg,.jpeg,.png" /><span class="description"><?php echo esc_html( sprintf( __( 'PDF, DOCX, PPTX, XLSX, JPG and PNG up to %s MB. The file is stored privately using %s and never added to the WordPress Media Library.', 'tutorhelper-lms' ), self::upload_limit_megabytes(), $provider->get_label() ) ); ?></span></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Store one submitted master file after Core has safely created the Resource.
	 *
	 * @param int    $resource_id Resource ID.
	 * @param bool   $is_new_resource Whether Core created this Resource now.
	 * @param string $type Resource type.
	 * @return void
	 */
	public static function save_upload( $resource_id, $is_new_resource, $type ) {
		if ( 'private_file' !== sanitize_key( $type ) || ! TutorHelper_LMS_Premium::is_available() ) {
			return;
		}

		if ( TutorHelper_LMS_Private_Files::find( TutorHelper_LMS_Private_Files::ENTITY_RESOURCE, $resource_id ) ) {
			return;
		}

		$upload = self::validated_upload();
		if ( is_wp_error( $upload ) ) {
			self::fail( $resource_id, $upload->get_error_code() );
			return;
		}

		$provider = self::active_provider();
		if ( ! $provider ) {
			self::fail( $resource_id, 'storage_unavailable' );
			return;
		}

		$stored = $provider->store(
			$upload,
			array(
				'purpose'           => 'resource',
				'resource_id'       => absint( $resource_id ),
				'resource_owner_id' => get_current_user_id(),
			)
		);
		if ( is_wp_error( $stored ) || ! is_array( $stored ) ) {
			self::fail( $resource_id, is_wp_error( $stored ) ? $stored->get_error_code() : 'store_failed', $provider->get_id() );
			return;
		}

		$stored['provider'] = $provider->get_id();
		$stored['original_filename'] = $upload['name'];
		$stored['display_filename'] = $upload['name'];
		$stored['mime_type'] = $upload['type'];
		$stored['file_size'] = $upload['size'];
		$stored['file_hash'] = hash_file( 'sha256', $upload['tmp_name'] );

		$result = TutorHelper_LMS_Private_Files::sync_resource_file( $resource_id, get_current_user_id(), $stored );
		if ( is_wp_error( $result ) ) {
			self::fail( $resource_id, $result->get_error_code(), $provider->get_id() );
			return;
		}

		self::set_notice( 'success', __( 'Private master file uploaded securely. Student access has not been enabled yet.', 'tutorhelper-lms' ) );
	}

	/** Render the one-time safe notice after a Resource save redirect. */
	public static function render_notice() {
		$notice = get_transient( self::notice_key() );
		if ( ! is_array( $notice ) || empty( $notice['message'] ) ) {
			return;
		}
		delete_transient( self::notice_key() );
		$type = isset( $notice['type'] ) && 'success' === $notice['type'] ? 'success' : 'error';
		echo '<div class="notice notice-' . esc_attr( $type ) . ' inline"><p>' . esc_html( $notice['message'] ) . '</p></div>';
	}

	/** Return the currently selected and usable private-storage provider. */
	private static function active_provider() {
		$provider_id = TutorHelper_LMS_Private_Storage::mode();
		if ( TutorHelper_LMS_Private_Storage::MODE_LINKS_ONLY === $provider_id ) {
			return null;
		}
		$provider = TutorHelper_LMS_Storage_Registry::get( $provider_id );
		return $provider && $provider->is_available() ? $provider : null;
	}

	/** Validate a temporary upload without using WordPress public upload handling. */
	private static function validated_upload() {
		if ( empty( $_FILES[ self::FILE_INPUT ] ) || ! is_array( $_FILES[ self::FILE_INPUT ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core save action has already verified its nonce.
			return new WP_Error( 'resource_file_missing', __( 'Choose a Resource file to upload.', 'tutorhelper-lms' ) );
		}
		$file = wp_unslash( $_FILES[ self::FILE_INPUT ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core save action has already verified its nonce.
		if ( ! isset( $file['error'], $file['tmp_name'], $file['name'], $file['size'] ) || UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'resource_file_upload_invalid', __( 'The Resource file upload could not be verified.', 'tutorhelper-lms' ) );
		}

		$allowed = self::allowed_mimes();
		$checked = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $allowed );
		if ( empty( $checked['ext'] ) || empty( $checked['type'] ) || ! in_array( $checked['type'], $allowed, true ) ) {
			return new WP_Error( 'resource_file_type_invalid', __( 'This Resource file type is not supported.', 'tutorhelper-lms' ) );
		}

		$size = absint( $file['size'] );
		if ( ! $size || $size > TutorHelper_LMS_Private_Storage::effective_upload_limit() ) {
			return new WP_Error( 'resource_file_size_invalid', __( 'This Resource file is larger than the configured upload limit.', 'tutorhelper-lms' ) );
		}

		return array(
			'name'     => sanitize_file_name( $file['name'] ),
			'tmp_name' => $file['tmp_name'],
			'type'     => sanitize_mime_type( $checked['type'] ),
			'size'     => $size,
		);
	}

	/** Return initial supported master-file MIME types. */
	private static function allowed_mimes() {
		return array(
			'pdf'  => 'application/pdf',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
			'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'jpg|jpeg' => 'image/jpeg',
			'png'  => 'image/png',
		);
	}

	/** Return the effective private upload limit in MB for tutor-facing copy. */
	private static function upload_limit_megabytes() {
		return number_format_i18n( TutorHelper_LMS_Private_Storage::effective_upload_limit() / MB_IN_BYTES, 2 );
	}

	/** Store a generic safe notice and diagnostics metadata for this tutor. */
	private static function fail( $resource_id, $reason, $provider = '' ) {
		self::set_notice( 'error', __( 'The Resource was saved, but its private file could not be uploaded. Check your storage connection and try again from Edit Resource.', 'tutorhelper-lms' ) );
		if ( class_exists( 'TutorHelper_LMS_Diagnostics' ) ) {
			TutorHelper_LMS_Diagnostics::error( 'Private Resource file upload failed.', array( 'component' => 'lms', 'operation' => 'resource_file_upload', 'entity_id' => absint( $resource_id ), 'provider' => sanitize_key( $provider ), 'failure_reason' => sanitize_key( $reason ) ) );
		}
	}

	/** Set a one-time Resource Library notice for the current authenticated tutor. */
	private static function set_notice( $type, $message ) {
		set_transient( self::notice_key(), array( 'type' => sanitize_key( $type ), 'message' => sanitize_text_field( $message ) ), MINUTE_IN_SECONDS );
	}

	/** Build the user-specific notice transient key. */
	private static function notice_key() {
		return self::NOTICE_TRANSIENT_PREFIX . get_current_user_id();
	}
}
