<?php
/**
 * Premium tutor annotations for private image responses in Quiz marking.
 *
 * Annotations deliberately live apart from the immutable student response,
 * question marks and written feedback. They remain editable by the tutor and
 * are rendered only after the Quiz result is released to the student.
 *
 * @package TutorHelper_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TutorHelper_LMS_Quiz_Annotations {

	const LOAD_ACTION = 'tutorhelper_lms_load_quiz_file_annotation';
	const SAVE_ACTION = 'tutorhelper_lms_save_quiz_file_annotation';
	const SAVE_FAVOURITES_ACTION = 'tutorhelper_lms_save_quiz_annotation_favourites';
	const SAVE_DRAWING_ACTION = 'tutorhelper_lms_save_quiz_annotation_drawing';
	const FAVOURITES_META = 'tutorhelper_lms_quiz_annotation_favourites';
	const DRAWING_META = 'tutorhelper_lms_quiz_annotation_drawing';

	/**
	 * Register annotation persistence, authorisation and display hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_ajax_' . self::LOAD_ACTION, array( __CLASS__, 'ajax_load' ) );
		add_action( 'wp_ajax_' . self::SAVE_ACTION, array( __CLASS__, 'ajax_save' ) );
		add_action( 'wp_ajax_' . self::SAVE_FAVOURITES_ACTION, array( __CLASS__, 'ajax_save_favourites' ) );
		add_action( 'wp_ajax_' . self::SAVE_DRAWING_ACTION, array( __CLASS__, 'ajax_save_drawing' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend_assets' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_filter( 'tutorhelper_lms_quiz_response_attachment_display', array( __CLASS__, 'render_released_annotation' ), 10, 4 );
	}

	/**
	 * Load the small, display-only renderer for released student feedback.
	 *
	 * @return void
	 */
	public static function enqueue_frontend_assets() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		self::enqueue_assets();
	}

	/**
	 * Load the tutor drawing workspace on TutorHelper screens only.
	 *
	 * @param string $hook_suffix Current admin screen hook.
	 * @return void
	 */
	public static function enqueue_admin_assets( $hook_suffix ) {
		if ( false === strpos( (string) $hook_suffix, 'tutorhelper' ) ) {
			return;
		}
		self::enqueue_assets();
	}

	/**
	 * Enqueue editable canvas tools and their read-only renderer.
	 *
	 * @return void
	 */
	private static function enqueue_assets() {
		$style_path  = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/css/tutorhelper-lms-quiz-annotations.css';
		$script_path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-quiz-annotations.js';
		$pdf_script_path = TUTORHELPER_LMS_PREMIUM_PATH . 'assets/js/tutorhelper-lms-pdf-annotations.js';

		wp_enqueue_style(
			'tutorhelper-lms-quiz-annotations',
			TUTORHELPER_LMS_PREMIUM_URL . 'assets/css/tutorhelper-lms-quiz-annotations.css',
			array(),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_LMS_PREMIUM_VERSION
		);
		wp_enqueue_script(
			'tutorhelper-lms-quiz-annotations',
			TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-quiz-annotations.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_LMS_PREMIUM_VERSION,
			true
		);
		wp_enqueue_script(
			'tutorhelper-lms-pdf-annotations',
			TUTORHELPER_LMS_PREMIUM_URL . 'assets/js/tutorhelper-lms-pdf-annotations.js',
			array( 'tutorhelper-lms-quiz-annotations' ),
			file_exists( $pdf_script_path ) ? (string) filemtime( $pdf_script_path ) : TUTORHELPER_LMS_PREMIUM_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-lms-quiz-annotations',
			'tutorhelperLmsQuizAnnotations',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'loadAction' => self::LOAD_ACTION,
				'saveAction'       => self::SAVE_ACTION,
				'saveFavouritesAction' => self::SAVE_FAVOURITES_ACTION,
				'saveDrawingAction' => self::SAVE_DRAWING_ACTION,
				'nonce'            => wp_create_nonce( self::LOAD_ACTION ),
				'saveNonce'        => wp_create_nonce( self::SAVE_ACTION ),
				'favouritesNonce'  => wp_create_nonce( self::SAVE_FAVOURITES_ACTION ),
				'drawingNonce'     => wp_create_nonce( self::SAVE_DRAWING_ACTION ),
				'pdfJsUrl'         => apply_filters( 'tutorhelper_lms_pdfjs_url', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs' ),
				'pdfWorkerUrl'     => apply_filters( 'tutorhelper_lms_pdfjs_worker_url', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs' ),
				'loadFailed' => __( 'The annotation workspace could not be loaded.', 'tutorhelper-lms' ),
				'saveFailed' => __( 'Your annotations could not be saved. Please try again.', 'tutorhelper-lms' ),
			)
		);
	}

	/**
	 * Whether a private response file can be marked in the in-browser canvas.
	 *
	 * PDF annotation will use the same normalised document format when its
	 * page renderer is introduced; it is intentionally not presented as an
	 * image workspace until a real per-page PDF surface is available.
	 *
	 * @param array $file Normalised private-file metadata.
	 * @return bool
	 */
	public static function supports_file( $file ) {
		$mime_type = sanitize_mime_type( is_array( $file ) ? ( $file['mime_type'] ?? '' ) : '' );
		return self::is_image_file( $mime_type ) || 'application/pdf' === $mime_type;
	}

	/**
	 * Whether a file is an image response.
	 *
	 * @param string $mime_type Response MIME type.
	 * @return bool
	 */
	private static function is_image_file( $mime_type ) {
		return in_array( sanitize_mime_type( $mime_type ), array( 'image/jpeg', 'image/png' ), true );
	}

	/**
	 * Render the tutor trigger alongside the existing Preview/Drive/Download
	 * actions. The original protected image is never duplicated or replaced.
	 *
	 * @param object $attempt Quiz attempt.
	 * @param int    $question_id Question ID.
	 * @param array  $file Normalised file metadata.
	 * @return void
	 */
	public static function render_tutor_trigger( $attempt, $question_id, $file ) {
		if ( ! $attempt || ! self::supports_file( $file ) ) {
			return;
		}

		printf(
			'<button type="button" class="button tutorhelper-lms-quiz-review__file-action tutorhelper-lms-quiz-annotation-trigger" data-tutorhelper-lms-quiz-annotation="%1$d" data-question-id="%2$d" data-file-title="%3$s" data-file-type="%4$s">%5$s</button>',
			absint( $attempt->id ),
			absint( $question_id ),
			esc_attr( sprintf( __( 'Mark: %s', 'tutorhelper-lms' ), $file['filename'] ?? __( 'uploaded file', 'tutorhelper-lms' ) ) ),
			self::is_image_file( $file['mime_type'] ?? '' ) ? 'image' : 'pdf',
			self::is_image_file( $file['mime_type'] ?? '' ) ? esc_html__( 'Mark image', 'tutorhelper-lms' ) : esc_html__( 'Mark PDF', 'tutorhelper-lms' )
		);
	}

	/**
	 * Send one tutor-owned response image plus saved normalised annotations.
	 *
	 * @return void
	 */
	public static function ajax_load() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to annotate this response.', 'tutorhelper-lms' ) ), 403 );
		}
		check_ajax_referer( self::LOAD_ACTION, 'nonce' );

		$attempt_id  = isset( $_POST['attempt_id'] ) && ! is_array( $_POST['attempt_id'] ) ? absint( wp_unslash( $_POST['attempt_id'] ) ) : 0;
		$question_id = isset( $_POST['question_id'] ) && ! is_array( $_POST['question_id'] ) ? absint( wp_unslash( $_POST['question_id'] ) ) : 0;
		$attempt     = self::tutor_attempt( $attempt_id );
		$file        = $attempt ? self::response_file( $attempt_id, $question_id ) : array();

		if ( ! $attempt || ! self::supports_file( $file ) ) {
			wp_send_json_error( array( 'message' => __( 'This image response is not available for annotation.', 'tutorhelper-lms' ) ), 404 );
		}

		wp_send_json_success(
			array(
				'attemptId'  => absint( $attempt_id ),
				'questionId' => absint( $question_id ),
				'filename'   => $file['filename'],
				'fileType'   => self::is_image_file( $file['mime_type'] ?? '' ) ? 'image' : 'pdf',
				'fileUrl'    => self::preview_url( $attempt_id, $question_id ),
				'imageUrl'   => self::preview_url( $attempt_id, $question_id ),
				'annotation' => self::annotation_for( $attempt_id, $question_id ),
				'favourites' => self::favourites_for_user( get_current_user_id() ),
				'drawing'    => self::drawing_for_user( get_current_user_id() ),
			)
		);
	}

	/**
	 * Save the current tutor's ordered favourite stamp list.
	 *
	 * @return void
	 */
	public static function ajax_save_favourites() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to change marking favourites.', 'tutorhelper-lms' ) ), 403 );
		}
		check_ajax_referer( self::SAVE_FAVOURITES_ACTION, 'nonce' );

		$posted = isset( $_POST['favourites'] ) && is_array( $_POST['favourites'] ) ? wp_unslash( $_POST['favourites'] ) : array();
		$favourites = self::sanitise_favourites( $posted );
		update_user_meta( get_current_user_id(), self::FAVOURITES_META, $favourites );
		wp_send_json_success( array( 'favourites' => $favourites ) );
	}

	/**
	 * Save the tutor's chosen pen colour and width for subsequent marking.
	 *
	 * @return void
	 */
	public static function ajax_save_drawing() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to change drawing preferences.', 'tutorhelper-lms' ) ), 403 );
		}
		check_ajax_referer( self::SAVE_DRAWING_ACTION, 'nonce' );

		$colour = isset( $_POST['colour'] ) && ! is_array( $_POST['colour'] ) ? sanitize_hex_color( wp_unslash( $_POST['colour'] ) ) : '';
		$width = isset( $_POST['width'] ) && ! is_array( $_POST['width'] ) ? absint( wp_unslash( $_POST['width'] ) ) : 4;
		$drawing = array(
			'colour' => $colour ? $colour : '#d3483f',
			'width'  => max( 1, min( 12, $width ) ),
		);
		update_user_meta( get_current_user_id(), self::DRAWING_META, $drawing );
		wp_send_json_success( array( 'drawing' => $drawing ) );
	}

	/**
	 * Store a tutor's editable canvas document. Coordinates are normalised
	 * (0–1), keeping placement accurate at every responsive display size.
	 *
	 * @return void
	 */
	public static function ajax_save() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to save annotations.', 'tutorhelper-lms' ) ), 403 );
		}
		check_ajax_referer( self::SAVE_ACTION, 'nonce' );

		$attempt_id  = isset( $_POST['attempt_id'] ) && ! is_array( $_POST['attempt_id'] ) ? absint( wp_unslash( $_POST['attempt_id'] ) ) : 0;
		$question_id = isset( $_POST['question_id'] ) && ! is_array( $_POST['question_id'] ) ? absint( wp_unslash( $_POST['question_id'] ) ) : 0;
		$raw         = isset( $_POST['annotation'] ) && ! is_array( $_POST['annotation'] ) ? (string) wp_unslash( $_POST['annotation'] ) : '';
		$attempt     = self::tutor_attempt( $attempt_id );
		$file        = $attempt ? self::response_file( $attempt_id, $question_id ) : array();

		if ( ! $attempt || ! self::supports_file( $file ) ) {
			wp_send_json_error( array( 'message' => __( 'This image response is not available for annotation.', 'tutorhelper-lms' ) ), 404 );
		}

		$annotation = self::sanitise_annotation( $raw );
		if ( is_wp_error( $annotation ) ) {
			wp_send_json_error( array( 'message' => $annotation->get_error_message() ), 400 );
		}

		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'quiz_file_annotations' );
		if ( '' === $table ) {
			wp_send_json_error( array( 'message' => __( 'Annotations are not available until the LMS database update has completed.', 'tutorhelper-lms' ) ), 503 );
		}

		$now = current_time( 'mysql', true );
		$stored = $wpdb->replace(
			$table,
			array(
				'attempt_id'      => absint( $attempt_id ),
				'question_id'     => absint( $question_id ),
				'annotation_json' => wp_json_encode( $annotation ),
				'marker_user_id'  => get_current_user_id(),
				'updated_at'      => $now,
				'created_at'      => $now,
			),
			array( '%d', '%d', '%s', '%d', '%s', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Writes one tutor-owned, editable marking layer.

		if ( false === $stored ) {
			wp_send_json_error( array( 'message' => __( 'Your annotations could not be saved. Please try again.', 'tutorhelper-lms' ) ), 500 );
		}

		wp_send_json_success( array( 'annotation' => $annotation ) );
	}

	/**
	 * Wrap a released student image in a pointer-free canvas display layer.
	 *
	 * @param string $html Existing image markup.
	 * @param object $attempt Immutable Quiz attempt.
	 * @param int    $question_id Question ID.
	 * @param array  $attachment Private attachment metadata.
	 * @return string
	 */
	public static function render_released_annotation( $html, $attempt, $question_id, $attachment ) {
		if ( ! self::is_image_file( $attachment['mime_type'] ?? '' ) || ! is_object( $attempt ) || ! TutorHelper_LMS_Quiz_Attempts::results_released( $attempt ) ) {
			return $html;
		}

		$annotation = self::annotation_for( absint( $attempt->id ), absint( $question_id ) );
		if ( empty( $annotation['items'] ) ) {
			return $html;
		}

		return '<div class="tutorhelper-lms-quiz__annotated-image" data-tutorhelper-lms-quiz-annotation-display data-annotation="' . esc_attr( wp_json_encode( $annotation ) ) . '">' . $html . '<canvas aria-hidden="true"></canvas></div>';
	}

	/**
	 * Retrieve one stored annotation document, always returning a valid shape.
	 *
	 * @param int $attempt_id Attempt ID.
	 * @param int $question_id Question ID.
	 * @return array
	 */
	public static function annotation_for( $attempt_id, $question_id ) {
		global $wpdb;
		$table = TutorHelper_LMS_Database::table( 'quiz_file_annotations' );
		if ( '' === $table || ! $attempt_id || ! $question_id ) {
			return self::empty_annotation();
		}

		$json = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT annotation_json FROM {$table} WHERE attempt_id = %d AND question_id = %d",
				absint( $attempt_id ),
				absint( $question_id )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads one released response's marking layer.

		$annotation = json_decode( (string) $json, true );
		return is_array( $annotation ) ? self::sanitise_annotation_array( $annotation ) : self::empty_annotation();
	}

	/**
	 * Verify the current tutor owns the Course containing the completed attempt.
	 *
	 * @param int $attempt_id Quiz attempt ID.
	 * @return object|null
	 */
	private static function tutor_attempt( $attempt_id ) {
		global $wpdb;
		$attempts = TutorHelper_LMS_Free_Database::table( 'quiz_attempts' );
		if ( '' === $attempts || ! $attempt_id ) {
			return null;
		}

		$posts = $wpdb->posts;
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT attempts.* FROM {$attempts} attempts INNER JOIN {$posts} course ON course.ID = attempts.course_id WHERE attempts.id = %d AND course.post_author = %d AND course.post_type = %s AND attempts.status = %s",
				absint( $attempt_id ),
				get_current_user_id(),
				'tutorhelper_course',
				'completed'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Verifies tutor ownership before exposing a protected response.
	}

	/**
	 * Extract only the private image metadata for one immutable response.
	 *
	 * @param int $attempt_id Attempt ID.
	 * @param int $question_id Question ID.
	 * @return array
	 */
	private static function response_file( $attempt_id, $question_id ) {
		$review = TutorHelper_LMS_Quiz_Attempts::reviewed_responses( $attempt_id );
		$answer = $review[ absint( $question_id ) ]['answer'] ?? array();
		$file = is_array( $answer ) && isset( $answer['attachment'] ) ? $answer['attachment'] : $answer;
		if ( ! is_array( $file ) || 'private_file' !== (string) ( $file['kind'] ?? '' ) ) {
			return array();
		}

		return array(
			'provider'         => sanitize_key( $file['provider'] ?? '' ),
			'provider_file_id' => sanitize_text_field( $file['provider_file_id'] ?? '' ),
			'filename'         => sanitize_file_name( $file['filename'] ?? '' ),
			'mime_type'        => sanitize_mime_type( $file['mime_type'] ?? '' ),
		);
	}

	/**
	 * Return the authenticated, nonce-protected inline image route.
	 *
	 * @param int $attempt_id Attempt ID.
	 * @param int $question_id Question ID.
	 * @return string
	 */
	private static function preview_url( $attempt_id, $question_id ) {
		$action = TutorHelper_LMS_Submissions::QUIZ_FILE_PREVIEW_ACTION;
		return add_query_arg(
			array(
				'action'      => $action,
				'attempt_id'  => absint( $attempt_id ),
				'question_id' => absint( $question_id ),
				'_wpnonce'    => wp_create_nonce( $action . '_' . absint( $attempt_id ) . '_' . absint( $question_id ) ),
			),
			admin_url( 'admin-post.php' )
		);
	}

	/**
	 * Decode and validate a client annotation document.
	 *
	 * @param string $raw JSON payload.
	 * @return array|WP_Error
	 */
	private static function sanitise_annotation( $raw ) {
		if ( strlen( $raw ) > 500000 ) {
			return new WP_Error( 'annotation_too_large', __( 'This annotation is too large to save.', 'tutorhelper-lms' ) );
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'annotation_invalid', __( 'This annotation could not be read.', 'tutorhelper-lms' ) );
		}
		return self::sanitise_annotation_array( $decoded );
	}

	/**
	 * Keep only bounded, normalised drawing data.
	 *
	 * @param array $annotation Annotation document.
	 * @return array
	 */
	private static function sanitise_annotation_array( $annotation ) {
		if ( isset( $annotation['pages'] ) && is_array( $annotation['pages'] ) ) {
			$pages = array();
			foreach ( array_slice( $annotation['pages'], 0, 100, true ) as $page_number => $page_annotation ) {
				$page_number = absint( $page_number );
				if ( $page_number < 1 || ! is_array( $page_annotation ) ) {
					continue;
				}
				$pages[ $page_number ] = self::sanitise_page_annotation( $page_annotation );
			}
			return array(
				'version' => 2,
				'pages'   => $pages,
			);
		}
		return self::sanitise_page_annotation( $annotation );
	}

	/**
	 * Keep one canvas page's stamps and ink within safe limits.
	 *
	 * @param array $annotation Page annotation data.
	 * @return array
	 */
	private static function sanitise_page_annotation( $annotation ) {
		$items = array();
		$allowed_stamps = self::allowed_stamp_ids();
		foreach ( array_slice( (array) ( $annotation['items'] ?? array() ), 0, 500 ) as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$type = sanitize_key( $item['type'] ?? '' );
			if ( 'stamp' === $type && in_array( sanitize_key( $item['stamp'] ?? '' ), $allowed_stamps, true ) ) {
				$items[] = array(
					'type'  => 'stamp',
					'stamp' => sanitize_key( $item['stamp'] ),
					'x'     => self::normalised_number( $item['x'] ?? 0 ),
					'y'     => self::normalised_number( $item['y'] ?? 0 ),
					'scale' => max( 0.025, min( 0.15, (float) ( $item['scale'] ?? 0.06 ) ) ),
				);
				continue;
			}
			if ( 'stroke' !== $type ) {
				continue;
			}
			$points = array();
			foreach ( array_slice( (array) ( $item['points'] ?? array() ), 0, 1000 ) as $point ) {
				if ( is_array( $point ) ) {
					$points[] = array( 'x' => self::normalised_number( $point['x'] ?? 0 ), 'y' => self::normalised_number( $point['y'] ?? 0 ) );
				}
			}
			if ( count( $points ) > 1 ) {
				$colour = sanitize_hex_color( $item['colour'] ?? '' );
				$items[] = array(
					'type'   => 'stroke',
					'colour' => $colour ? $colour : '#d3483f',
					'width'  => max( 0.0015, min( 0.05, (float) ( $item['width'] ?? 0.004 ) ) ),
					'points' => $points,
				);
			}
		}
		return array( 'version' => 1, 'items' => $items );
	}

	/**
	 * Return the supported examiner stamp identifiers.
	 *
	 * @return array
	 */
	public static function allowed_stamp_ids() {
		return array(
			'seen', 'tick', 'cross', 'nr', 'bod', 'tv', 'i', 'rep', 'con',
			'ao1', 'ao2', 'ao3', 'ku', 'dev', 'eval', 'l1', 'l2', 'l3', 'l4', 'eg', 'omission',
			'm', 'a', 'b', 'ecf', 'ft', 'ae', 'sf', 'unit', 'isw',
		);
	}

	/**
	 * Return a safe ordered favourite set for one tutor.
	 *
	 * @param int $user_id Tutor user ID.
	 * @return array
	 */
	private static function favourites_for_user( $user_id ) {
		$stored = get_user_meta( absint( $user_id ), self::FAVOURITES_META, true );
		if ( ! is_array( $stored ) ) {
			return array( 'tick', 'cross', 'nr', 'bod', 'ft' );
		}
		return self::sanitise_favourites( $stored );
	}

	/**
	 * Keep a compact, ordered set of supported favourite stamps.
	 *
	 * @param array $favourites Raw stamp identifiers.
	 * @return array
	 */
	private static function sanitise_favourites( $favourites ) {
		$allowed = self::allowed_stamp_ids();
		$output = array();
		foreach ( array_slice( (array) $favourites, 0, 16 ) as $stamp ) {
			$stamp = sanitize_key( $stamp );
			if ( in_array( $stamp, $allowed, true ) && ! in_array( $stamp, $output, true ) ) {
				$output[] = $stamp;
			}
		}
		return $output;
	}

	/**
	 * Return one tutor's saved pen settings.
	 *
	 * @param int $user_id Tutor user ID.
	 * @return array
	 */
	private static function drawing_for_user( $user_id ) {
		$stored = get_user_meta( absint( $user_id ), self::DRAWING_META, true );
		$colour = is_array( $stored ) ? sanitize_hex_color( $stored['colour'] ?? '' ) : '';
		$width = is_array( $stored ) && isset( $stored['width'] ) ? absint( $stored['width'] ) : 4;
		return array(
			'colour' => $colour ? $colour : '#d3483f',
			'width'  => max( 1, min( 12, $width ) ),
		);
	}

	/**
	 * Render a tutor-visible, automatically updated preview beside a response's
	 * normal marking controls.
	 *
	 * @param object $attempt Quiz attempt.
	 * @param int    $question_id Question ID.
	 * @param array  $file Normalised file metadata.
	 * @return void
	 */
	public static function render_tutor_preview( $attempt, $question_id, $file ) {
		if ( ! $attempt || ! self::supports_file( $file ) ) {
			return;
		}
		$annotation = self::annotation_for( absint( $attempt->id ), absint( $question_id ) );
		$url = self::preview_url( $attempt->id, $question_id );
		if ( self::is_image_file( $file['mime_type'] ?? '' ) ) {
			echo '<div class="tutorhelper-lms-quiz__annotation-preview"><strong>' . esc_html__( 'Current marking preview', 'tutorhelper-lms' ) . '</strong><div class="tutorhelper-lms-quiz__annotated-image" data-tutorhelper-lms-quiz-annotation-display data-attempt-id="' . esc_attr( absint( $attempt->id ) ) . '" data-question-id="' . esc_attr( absint( $question_id ) ) . '" data-annotation="' . esc_attr( wp_json_encode( $annotation ) ) . '"><img class="tutorhelper-lms-quiz__submitted-image" src="' . esc_url( $url ) . '" alt="' . esc_attr( sprintf( __( 'Submitted image: %s', 'tutorhelper-lms' ), $file['filename'] ) ) . '" /><canvas aria-hidden="true"></canvas></div></div>';
			return;
		}
		echo '<div class="tutorhelper-lms-quiz__annotation-preview tutorhelper-lms-quiz__pdf-annotation-preview" data-tutorhelper-lms-pdf-annotation-preview data-attempt-id="' . esc_attr( absint( $attempt->id ) ) . '" data-question-id="' . esc_attr( absint( $question_id ) ) . '" data-pdf-url="' . esc_url( $url ) . '" data-annotation="' . esc_attr( wp_json_encode( $annotation ) ) . '"><strong>' . esc_html__( 'Current PDF marking preview', 'tutorhelper-lms' ) . '</strong><p class="tutorhelper-lms-pdf-annotation-preview__loading"><span class="tutorhelper-lms-annotation-spinner" aria-hidden="true"></span> ' . esc_html__( 'Loading page 1…', 'tutorhelper-lms' ) . '</p><div class="tutorhelper-lms-pdf-annotation-preview__page"></div></div>';
	}
	/**
	 * Clamp a coordinate to the document's unit square.
	 *
	 * @param mixed $value Coordinate.
	 * @return float
	 */
	private static function normalised_number( $value ) {
		return max( 0, min( 1, is_numeric( $value ) ? (float) $value : 0 ) );
	}

	/**
	 * Return the canonical empty drawing document.
	 *
	 * @return array
	 */
	private static function empty_annotation() {
		return array(
			'version' => 1,
			'items'   => array(),
		);
	}
}
