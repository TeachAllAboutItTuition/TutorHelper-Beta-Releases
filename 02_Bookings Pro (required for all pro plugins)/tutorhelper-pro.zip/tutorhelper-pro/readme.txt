=== TutorHelper Pro ===
Contributors: tutorhelper
Tags: tutor, bookings, education
Requires at least: 6.4
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.3.20
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

TutorHelper extension component.

== Description ==

This plugin is part of the TutorHelper booking platform.

== Changelog ==

= 1.3.22 =

* 🆕 New Feature: 💳 Lets tutors apply available account credit to existing unpaid or partly paid lessons, either individually or across selected lessons.
* 🔒 Security: 💳 Validates account-credit allocations against the current immutable ledger and prevents duplicate or concurrent use of the same credit.


= 1.3.20 =

* 🐛 Fix: Provides a dedicated extension point for released LMS feedback so student homework details do not disappear after marking.

= 1.3.19 =

* 🐛 Fix: Avoids duplicated student homework cards when the homework is set and due for the same lesson, or LMS presents marked work.

= 1.3.18 =

* 🐛 Fix: Treats marked LMS homework as completed in Student Bookings while keeping the manual completion checkbox for ordinary homework.

= 1.3.17 =

* 🐛 Fix: Stops the Pro database schema migration from running on every request, preventing frontend database-error output.

= 1.3.16 =

* 🐛 Fix: 🎛️ Calculates student-specific Booking Type prices proportionally when a tutor changes lesson duration.

= 1.3.12 =

* 🐛 Fix: 🎛️ Refreshes only the recurring-lesson review when future-series details change, preserving all unsaved Edit Booking values.

= 1.3.11 =

* 🐛 Fix: 🎛️ Moves each future recurring lesson by the same calendar-date shift as the selected lesson, as well as applying its new time.

= 1.3.10 =

* 🐛 Fix: 🎛️ Identifies each recurring-lesson clash and limits calendar-warning overrides to public holidays and out-of-term-time dates.

= 1.3.9 =

* ✨ Improvement: Lets tutors review and resolve individual clashes when moving recurring future lessons, rather than rejecting the whole series update.

= 1.3.8 =

* 🎨 Improvement: Labels LMS homework submission status clearly and presents the Bookings Hub View / Mark homework action as the standard TutorHelper orange button beneath the private download link.


= 1.3.2 =

* 🐛 Fix: Keeps the student and parent dashboards available when an older saved tuition report has recipient metadata in an unexpected format.
* 🚀 Improvement: 💳 Records Stripe Checkout webhook outcomes separately for clearer payment troubleshooting, including pending, duplicate and rejected events.
* 🐛 Fix: 💳 Safely handles delayed Stripe Checkout success or failure without treating an unpaid completed session as paid.
* 🔒 Security: 💳 Prevents a tutor-recorded manual payment from silently replacing a verified TutorHelper Stripe Checkout payment.

* 🐛 Fix: Restores Feedback & homework as its own visible action column in Student Bookings, separate from Attendance controls.

* 🐛 Fix: 💳 Prevents repeated payment-method sections when a parent returns to the cached Book a Lesson tab.

* 🐛 Fix: 💳 Applies the selected linked child’s payment options when a parent opens the Book a Lesson tab.

* 🐛 Fix: 👩‍🎓 Restores shared Group Lesson feedback and homework on the standard student lesson dashboard.

* 🚀 Improvement: 💳 Shows payment-aware booking actions and guidance for card, bank-transfer and invoice arrangements, including parent bookings for a linked child.

* 🐛 Fix: 🖥️ Keeps student and parent dashboards usable when a legacy or unavailable tuition report cannot be downloaded.

* 🎨 Improvement: 📊 Aligns Tutor Dashboard section-refresh actions with the standard TutorHelper orange button treatment while preserving section-only refreshes.
* 🎨 Improvement: 🧩 Adds reusable compact option-row and standard button style hooks for Dashboard add-ons.


* 🐛 Fix: 💳 Creates cancellation credit from the settled payment ledger even after a cancelled lesson’s visible payment state has changed.
* 🐛 Fix: 💷 Reconciles account credit and refunds as separate immutable audit entries, so a refunded cancellation credit is no longer counted twice.
* 🚀 Improvement: 📋 Shows the full refund and credit audit beneath the Finance lesson, including action, date, tutor, payment route and notes.
* 🐛 Fix: 💰 Shows fully refunded lessons as Refunded rather than Void while retaining their Cancelled lesson status.


* 🐛 Fix: 💳 Confirms unconfirmed lessons when a Parent Dashboard Stripe payment settles, matching Tutor Finance payment handling.

* 🐛 Fix: 💷 Keeps an agreed student-specific Booking Type price fixed when a tutor changes a lesson duration, preventing accidental price uplifts before Stripe checkout.

* 🆕 New Feature: 🎛️ Adds multi-select Finance payment-status and manual payment-type filters, payment-type grouping, and recorded cash, bank transfer, external-card or other payment types.
* 🐛 Fix: 🎛️ Retains Finance filters when tutors move between report pages.
* 🆕 New Feature: 🎛️ Exports the complete filtered Finance report as CSV or PDF, keeping selected payment-status and payment-type filters.
* ♻️ Update: 🕒 Uses the configured WordPress timezone for Finance export lesson dates and times, including daylight-saving transitions.

* ♻️ Update: 🧠 Gives OpenAI the report date range and explicitly asks for a whole-period summary rather than single-lesson commentary.
* ♻️ Update: 🧠 Writes AI overviews in the tutor’s voice using feedback tone and the disclosed attendance, feedback and homework context.
* 🚀 Improvement: 🖼 Shows future incomplete homework as Not due and adds an accessible generating state while report previews are built.

* 🐛 Fix: 🧠 Prevents attendance percentages in OpenAI summary context from triggering a PHP format-string error.

* 🐛 Fix: 🧠 Catches unexpected tuition-report preview failures, records safe diagnostic details and returns tutors to a friendly error notice.
* ♻️ Update: 🖼 Limits the on-screen tuition-report preview to the first selected student while retaining every selected student in the combined PDF.

* 🐛 Fix: 🧠 Reliably extracts OpenAI feedback summaries from REST responses and shows a preview warning with Diagnostics logging when generation fails.
* ♻️ Update: 🧠 Adds the student’s first name and attendance percentage to the explicitly disclosed AI summary context.

* 🚀 Improvement: Adds an editable, branded payment-request email preview with one-off subject, body and personal-message controls before sending.
* 🐛 Fix: 📧 Associates parent-only payment request and receipt emails with the relevant student's communication history.

* 🐛 Fix: Restores Tuition Reports on student dashboards when Core does not yet provide the post-lessons hook, records linked-parent downloads, and applies self-contained tutor table styling.
* 🚀 Improvement: Shows recipient names instead of email addresses or recipient counts on student and parent dashboards.
* 🆕 New Feature: Adds an explicit OpenAI API connection and per-report opt-in for feedback summaries; the summary section remains hidden unless configured, selected and successfully generated.

* 🐛 Fix: Keeps each student’s report recipient list private, displays report creation times in the configured WordPress timezone, and embeds Media Library images in report notes.
* 🚀 Improvement: Sends a secure dashboard link instead of a temporary PDF attachment, places student reports after My Lessons, matches report tables to their host dashboard, and records student or parent PDF downloads for the tutor audit trail.

* 🚀 Improvement: Refines Tuition Reports with per-student branded headers, feedback summaries, rich introductions and notes, creation and recipient details, and secure saved-report history across tutor, student and parent views.

* 🆕 New Feature: Adds preview-first, branded student progress PDF reports with bulk student selection, lesson-type summaries, rich-text notes and private per-student delivery to authorised recipients.
* 🚀 Improvement: Sends temporary report attachments through TutorHelper email templates and delivery history, with safe Diagnostics logging for PDF and delivery failures.

* ♻️ Update: 🎛️ Groups registration, notes, lesson history, lesson options, pricing, payments, credit and student groups into the revised Student Detail layout.
* 🚀 Improvement: Displays communication history using the Students table styling, with searchable filters and 10 records shown by default.
* 🚀 Improvement: Matches Lesson History to the Students table and pagination, with selectable 10, 20 or 50 record page sizes and Past, Upcoming or combined lesson filtering.
* 🆕 New Feature: 🎛️ Adds a filterable student educational-history workspace covering lessons, attendance, feedback and homework.
* 🚀 Improvement: 🗓 Adds a compact choice to update one recurring lesson or that lesson and all future lessons in its recurring set.
* 📊 Adds expandable attendance breakdowns for students, lesson types, and popular lesson days and times, with in-panel refresh controls.
* 🧭 Links new-registration totals directly to the registration workspace.
* 👪 Adds an actionable missing-parent card for active under-18 students, excluding adults, blocked accounts and registrations still awaiting review.
* 🆕 New Feature: Adds independent branding controls for the registration form and Parent Dashboard.
* ♻️ Update: Uses the configured Privacy Policy and Terms pages throughout registration and annual agreement prompts.
* 🐛 Fix: Prevents the annual agreement modal from covering either configured legal page.
* 🐛 Fix: Uses the configured student login page in registration emails.

* Shows the Pro annual renewal date or Lifetime licence status alongside the active licence.
* Shows the current Pro Finance payment status on calendar lessons while Pro is active.
* Keeps upcoming table lessons chronological while showing past lessons with the most recent first.
* Renames student-facing How to join details to Lesson Notes.

* 🔒 Security: Validates the Pro licence against its specific TutorHelper installation and supports one-site activation enforcement.
* 🐛 Fix: Keeps Pro active when a scheduled check fails because of a temporary connection or licence-server error.
* ♻️ Update: Adds daily Pro licence validation and stores annual expiry or lifetime metadata returned by the licence server.
* Saves the submitted Pro licence key before remote activation and verifies that WordPress stored it successfully.
* Retains the saved key across logins, validation failures and licence deactivation until it is deliberately changed or removed.
* Adds an explicit Remove saved key action for inactive licences.

= 1.3.1 =

* Links dashboard email and finance cards to their relevant anchored or filtered reports.
* Removes the standalone credit-adjustment form while retaining refund and credit history.
* Registers the bulk due-date and PDF export handlers, loads Core Dompdf, and exports colour-coded tutor note sheets with homework due and writing space.
* Refreshes payment-request preparation in place and applies consistent button styling.
* Adds `{homework_set}` and `{homework_due}` to the reminder editor and delivery placeholders, including Group lesson fallback.

= 1.3.0 =

* Adds unpaid-request decline controls to Student Bookings.
* Improves dashboard report placement and booking heatmap presentation.
* Adds bulk finance due dates, name filtering, payment-request styling and printable Student Bookings PDF export.

== Upgrade Notice ==

= 1.3.8 =

Improves the Bookings Hub LMS homework submission display.


= 1.3.2 =

Ensures the Pro licence key remains stored on the site between administrator sessions.

= 1.3.0 =

Adds dashboard and finance workflow improvements; TutorHelper Bookings 2.1.0 is recommended.
