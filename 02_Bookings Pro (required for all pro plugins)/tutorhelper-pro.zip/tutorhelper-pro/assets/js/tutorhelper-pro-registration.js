(function () {
	'use strict';

	/**
	 * Initialise one TutorHelper registration form.
	 *
	 * @param {HTMLFormElement} form Registration form.
	 */
	function initialiseRegistrationForm(form) {

		const registration =
			form.closest(
				'.tutorhelper-pro-registration'
			);

		const steps =
			Array.from(
				form.querySelectorAll(
					'[data-registration-step]'
				)
			);

		if (
			!registration
			|| steps.length === 0
		) {
			return;
		}

		const indicators =
			Array.from(
				registration.querySelectorAll(
					'[data-step-indicator]'
				)
			);

		let currentStep = 0;


		/**
		 * Check the visible step using the browser's
		 * native form validation.
		 *
		 * @return {boolean}
		 */
		function validateCurrentStep() {

			const fields =
				steps[currentStep]
					.querySelectorAll(
						'input, select, textarea'
					);

			for (const field of fields) {

				if (!field.checkValidity()) {

					field.reportValidity();

					return false;
				}
			}

			return true;
		}


		/**
		 * Display one registration step.
		 *
		 * @param {number} index Step index.
		 */
		function showStep(index) {

			if (
				index < 0
				|| index >= steps.length
			) {
				return;
			}

			steps.forEach(
				function (step, stepIndex) {

					const isActive =
						stepIndex === index;

					step.hidden =
						!isActive;

					step.classList.toggle(
						'is-active',
						isActive
					);
				}
			);

			indicators.forEach(
				function (
					indicator,
					stepIndex
				) {

					indicator.classList.toggle(
						'is-active',
						stepIndex === index
					);

					indicator.classList.toggle(
						'is-complete',
						stepIndex < index
					);

					if (stepIndex === index) {
						indicator.setAttribute(
							'aria-current',
							'step'
						);
					} else {
						indicator.removeAttribute(
							'aria-current'
						);
					}
				}
			);

			currentStep = index;

			const heading =
				steps[currentStep]
					.querySelector(
						'h3'
					);

			if (heading) {

				heading.setAttribute(
					'tabindex',
					'-1'
				);

				heading.focus();
			}
		}


		form.addEventListener(
			'click',
			function (event) {

				const next =
					event.target.closest(
						'[data-registration-next]'
					);

				if (next) {

					if (
						validateCurrentStep()
					) {
						showStep(
							currentStep + 1
						);
					}

					return;
				}


				const back =
					event.target.closest(
						'[data-registration-back]'
					);

				if (back) {

					showStep(
						currentStep - 1
					);
				}
			}
		);


		showStep(0);
	}


	document.addEventListener(
		'DOMContentLoaded',
		function () {

			document
				.querySelectorAll(
					'[data-registration-form]'
				)
				.forEach(
					initialiseRegistrationForm
				);
		}
	);

})();
