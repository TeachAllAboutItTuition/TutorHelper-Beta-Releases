(function () {
	'use strict';

	const config =
		window.tutorhelperProStudentBookings;

	if (!config) {
		return;
	}

	const lateReminderModal =
		document.querySelector(
			'[data-late-reminder-modal]'
		);

	let lateReminderBookingId = 0;
	let lateReminderTrigger = null;


	const form =
		document.querySelector(
			'.tutorhelper-student-bookings-filter'
		);

	if (!form) {
		return;
	}

	/**
	 * Refresh the table for the requested page.
	 *
	 * @param {number} page Page number.
	 * @param {string} url  Canonical pagination URL.
	 */
	async function refreshResults(
		page,
		url
	) {
		const results =
			document.querySelector(
				'[data-student-bookings-results]'
			);

		if (!results) {
			return;
		}

		const data =
			new FormData(form);

		data.append(
			'action',
			config.action
		);

		data.append(
			'nonce',
			config.nonce
		);

		

        if (
            page > 1
        ) {
            data.set(
                'student_bookings_page',
                String(page)
            );
        } else {
            data.delete(
                'student_bookings_page'
            );
        }

		results.classList.add(
			'is-loading'
		);

		try {
			const response =
				await fetch(
					config.ajaxUrl,
					{
						method: 'POST',
						credentials: 'same-origin',
						body: data,
					}
				);

			const payload =
				await response.json();

			if (
				! payload.success
				|| ! payload.data
				|| ! payload.data.html
			) {
				throw new Error(
					'Student Bookings refresh failed.'
				);
			}

			const wrapper =
				document.createElement(
					'div'
				);

			wrapper.innerHTML =
				payload.data.html;

			const replacement =
				wrapper.querySelector(
					'[data-student-bookings-results]'
				);

			if (!replacement) {
				throw new Error(
					'Student Bookings response was invalid.'
				);
			}

			results.replaceWith(
				replacement
			);

			if (url) {
				window.history.replaceState(
					{},
					'',
					url
				);
			}
		} catch (error) {
			/*
			 * Fall back to normal browser navigation if
			 * AJAX fails for any reason.
			 */
			if (url) {
				window.location.href =
					url;
			}
		}
	}


	/*
	 * Event delegation means newly returned pagination
	 * links automatically continue to work.
	 */
	document.addEventListener(
		'click',
		function (event) {
			const link =
				event.target.closest(
					'.tutorhelper-student-bookings-pagination a.page-numbers'
				);

			if (!link) {
				return;
			}

			event.preventDefault();

			const url =
				link.href;

			const parsed =
				new URL(
					url,
					window.location.href
				);

			const page =
				parseInt(
					parsed.searchParams.get(
						'student_bookings_page'
					),
					10
				) || 1;

			refreshResults(
				page,
				url
			);
		}
	);
    

    document.addEventListener(
        'click',
        function (event) {
            const shortcut =
                event.target.closest(
                    '[data-student-bookings-date-shortcut]'
                );

            if (!shortcut) {
                return;
            }

            event.preventDefault();

            const dateFrom =
                form.querySelector(
                    '[name="student_bookings_date_from"]'
                );
            const dateTo =
                form.querySelector(
                    '[name="student_bookings_date_to"]'
                );

            if (dateFrom) {
                dateFrom.value =
                    shortcut.dataset.dateFrom || '';
            }

            if (dateTo) {
                dateTo.value =
                    shortcut.dataset.dateTo || '';
            }

            if ('function' === typeof form.requestSubmit) {
                form.requestSubmit();
            } else {
                form.dispatchEvent(
                    new Event(
                        'submit',
                        {
                            bubbles: true,
                            cancelable: true
                        }
                    )
                );
            }
        }
    );


    form.addEventListener(
        'submit',
        function (event) {
			if (
				event.submitter
				&& event.submitter.value === 'tutorhelper_pro_student_bookings_pdf'
			) {
				return;
			}
            event.preventDefault();

            const data =
                new FormData(form);

            const url =
                new URL(
                    window.location.href
                );

            /*
            * Remove the current filter state from the URL first,
            * then rebuild it from the submitted form values.
            */

            url.searchParams.delete(
                'student_bookings_student_search'
            );

            url.searchParams.delete(
                'student_bookings_date_from'
            );

            url.searchParams.delete(
                'student_bookings_date_to'
            );

            url.searchParams.delete(
                'student_bookings_booking_type_id'
            );

            url.searchParams.delete(
                'student_bookings_status'
            );

            url.searchParams.delete(
                'student_bookings_status_exclude'
            );

            url.searchParams.delete(
                'student_bookings_time_scope'
            );

            url.searchParams.delete(
                'student_bookings_sort_order'
            );

            url.searchParams.delete(
                'student_bookings_per_page'
            );

            url.searchParams.delete(
                'student_bookings_page'
            );

            /*
            * Copy the submitted filter values into the URL.
            *
            * Empty filters are left out so copied URLs stay tidy.
            */
            data.forEach(
                function (value, key) {
                    if (
                        key === 'page'
                        || key === 'tab'
                    ) {
                        return;
                    }

                    if (
                        String(value).trim()
                        === ''
                    ) {
                        return;
                    }

                    url.searchParams.set(
                        key,
                        String(value)
                    );
                }
            );

            /*
            * A new filter submission always returns to page 1.
            */
            refreshResults(
                1,
                url.toString()
            );
        }
    );

    document.addEventListener(
        'click',
        function (event) {
            const clear =
                event.target.closest(
                    '[data-student-bookings-clear]'
                );

            if (!clear) {
                return;
            }

            event.preventDefault();

            form.reset();

            const url =
                new URL(
                    clear.href,
                    window.location.href
                );

            refreshResults(
                1,
                url.toString()
            );
        }
    );

	document.addEventListener(
		'change',
		async function (event) {
			const checkbox =
				event.target.closest(
					'[data-booking-confirm]'
				);

			if (!checkbox) {
				return;
			}

			if (!checkbox.checked) {
				return;
			}

			const bookingId =
				parseInt(
					checkbox.dataset.bookingId,
					10
				);

			const wrapper =
				checkbox.closest(
					'[data-booking-confirm-wrapper]'
				);

			const label =
				wrapper
					? wrapper.querySelector(
						'[data-booking-confirm-label]'
					)
					: null;

			if (!bookingId) {
				checkbox.checked = false;
				return;
			}

			checkbox.disabled = true;

			if (label) {
				label.textContent =
					config.confirmingLabel
					|| 'Confirming…';
			}

			const data =
				new FormData();

			data.append(
				'action',
				config.confirmAction
			);

			data.append(
				'nonce',
				config.confirmNonce
			);

			data.append(
				'booking_id',
				String(bookingId)
			);

			try {
				const response =
					await fetch(
						config.ajaxUrl,
						{
							method: 'POST',
							credentials:
								'same-origin',
							body: data,
						}
					);

				const payload =
					await response.json();

				if (
					! payload.success
					|| ! payload.data
				) {
					throw new Error(
						payload.data
						&& payload.data.message
							? payload.data.message
							: config.confirmFailedLabel
					);
				}

				if (wrapper) {
					const status =
						document.createElement(
							'span'
						);

					status.className =
						'tutorhelper-student-bookings-status-text';

					status.textContent =
						payload.data.label
						|| config.confirmedLabel
						|| 'Confirmed';

					wrapper.replaceWith(
						status
					);
				}

			} catch (error) {
				checkbox.checked = false;
				checkbox.disabled = false;

				if (label) {
					label.textContent =
						'Confirm';
				}

				window.alert(
					error.message
					|| config.confirmFailedLabel
					|| 'The booking could not be confirmed.'
				);
			}
		}
	);


	document.addEventListener(
		'click',
		async function (event) {
			const button =
				event.target.closest(
					'[data-booking-decline]'
				);

			if (!button) {
				return;
			}

			const bookingId =
				parseInt(
					button.dataset.bookingId,
					10
				);

			if (
				!bookingId
				|| !window.confirm(
					config.declineConfirmLabel
					|| 'Decline this unpaid lesson request?'
				)
			) {
				return;
			}

			button.disabled = true;

			const data =
				new FormData();

			data.append(
				'action',
				config.declineAction
			);
			data.append(
				'nonce',
				config.declineNonce
			);
			data.append(
				'booking_id',
				String(bookingId)
			);

			try {
				const response =
					await fetch(
						config.ajaxUrl,
						{
							method: 'POST',
							credentials: 'same-origin',
							body: data,
						}
					);
				const payload =
					await response.json();

				if (!payload.success) {
					throw new Error(
						payload.data
						&& payload.data.message
							? payload.data.message
							: config.declineFailedLabel
					);
				}

				await refreshResults(
					1,
					window.location.href
				);
			} catch (error) {
				button.disabled = false;
				window.alert(
					error.message
					|| config.declineFailedLabel
					|| 'The request could not be declined.'
				);
			}
		}
	);


	document.addEventListener(
		'change',
		async function (event) {
			const attendanceSelect =
				event.target.closest(
					'[data-booking-attendance]'
				);

			if (!attendanceSelect) {
				return;
			}

			const bookingId =
				parseInt(
					attendanceSelect.dataset.bookingId,
					10
				);

			const attendanceStatus =
				attendanceSelect.value;

			const previousStatus =
				attendanceSelect.dataset.previousStatus
				|| 'not_recorded';

			const cell =
				attendanceSelect.closest(
					'.tutorhelper-student-bookings-table__attendance'
				);

			const saveStatus =
				cell
					? cell.querySelector(
						'[data-attendance-save-status]'
					)
					: null;

			if (!bookingId) {
				return;
			}

			const data =
				new FormData();

			data.append(
				'action',
				config.attendanceAction
			);

			data.append(
				'nonce',
				config.attendanceNonce
			);

			data.append(
				'booking_id',
				String(bookingId)
			);

			data.append(
				'attendance_status',
				attendanceStatus
			);

			attendanceSelect.disabled = true;

			if (saveStatus) {
				saveStatus.textContent =
					config.attendanceSavingLabel;
			}

			try {
				const response =
					await fetch(
						config.ajaxUrl,
						{
							method: 'POST',
							credentials: 'same-origin',
							body: data,
						}
					);

				const payload =
					await response.json();

				if (
					! payload.success
					|| ! payload.data
				) {
					const message =
						payload.data
						&& payload.data.message
							? payload.data.message
							: config.attendanceFailedLabel;

					throw new Error(
						message
					);
				}

				attendanceSelect.dataset.previousStatus =
					attendanceStatus;

				if (saveStatus) {
					saveStatus.textContent =
						config.attendanceSavedLabel;

					window.setTimeout(
						function () {
							saveStatus.textContent = '';
						},
						1500
					);
				}

			} catch (error) {

				/*
				* Return the control to the last value that
				* was successfully stored.
				*/
				attendanceSelect.value =
					previousStatus;

				if (saveStatus) {
					saveStatus.textContent =
						error
						&& error.message
							? error.message
							: config.attendanceFailedLabel;
				}

			} finally {
				attendanceSelect.disabled = false;
			}
		}
	);


	document.addEventListener(
		'click',
		async function (event) {

			const button =
				event.target.closest(
					'[data-late-reminder]'
				);

			if (!button) {
				return;
			}

			const bookingId =
				parseInt(
					button.dataset.bookingId,
					10
				);

			if (
				!bookingId
				|| !lateReminderModal
			) {
				return;
			}

			lateReminderTrigger = button;

			button.disabled = true;

			try {

				const data =
					new FormData();

				data.append(
					'action',
					config.lateReminderPrepareAction
				);

				data.append(
					'nonce',
					config.lateReminderNonce
				);

				data.append(
					'booking_id',
					String(bookingId)
				);

				const response =
					await fetch(
						config.ajaxUrl,
						{
							method: 'POST',
							credentials: 'same-origin',
							body: data,
						}
					);

				const payload =
					await response.json();

				if (
					!payload.success
					|| !payload.data
				) {
					throw new Error(
						payload.data
						&& payload.data.message
							? payload.data.message
							: config.lateReminderFailedLabel
					);
				}

				lateReminderBookingId =
					bookingId;

				lateReminderModal
					.querySelector(
						'[data-late-reminder-recipients]'
					)
					.textContent =
						payload.data.recipients;

				lateReminderModal
					.querySelector(
						'[data-late-reminder-subject]'
					)
					.textContent =
						payload.data.subject;

				lateReminderModal
					.querySelector(
						'[data-late-reminder-message]'
					)
					.value =
						payload.data.message;

				lateReminderModal.hidden =
					false;

			} catch (error) {

				window.alert(
					error
					&& error.message
						? error.message
						: config.lateReminderFailedLabel
				);

			} finally {

				button.disabled = false;
			}
		}
	);

	document.addEventListener(
		'click',
		function (event) {

			const close =
				event.target.closest(
					'[data-late-reminder-close]'
				);

			if (
				!close
				|| !lateReminderModal
			) {
				return;
			}

			lateReminderModal.hidden = true;
			lateReminderBookingId = 0;

			if (lateReminderTrigger) {
				lateReminderTrigger.focus();
			}
		}
	);

	document.addEventListener(
		'click',
		async function (event) {

			const sendButton =
				event.target.closest(
					'[data-late-reminder-send]'
				);

			if (
				!sendButton
				|| !lateReminderModal
				|| !lateReminderBookingId
			) {
				return;
			}

			const messageField =
				lateReminderModal.querySelector(
					'[data-late-reminder-message]'
				);

			const message =
				messageField
					? messageField.value.trim()
					: '';

			if (!message) {
				return;
			}

			sendButton.disabled = true;

			const originalLabel =
				sendButton.textContent;

			sendButton.textContent =
				config.lateReminderSendingLabel;

			try {

				const data =
					new FormData();

				data.append(
					'action',
					config.lateReminderSendAction
				);

				data.append(
					'nonce',
					config.lateReminderNonce
				);

				data.append(
					'booking_id',
					String(
						lateReminderBookingId
					)
				);

				data.append(
					'message',
					message
				);

				const response =
					await fetch(
						config.ajaxUrl,
						{
							method: 'POST',
							credentials: 'same-origin',
							body: data,
						}
					);

				const payload =
					await response.json();

				if (!payload.success) {
					throw new Error(
						payload.data
						&& payload.data.message
							? payload.data.message
							: config.lateReminderFailedLabel
					);
				}

				if (lateReminderTrigger) {

					const cell =
						lateReminderTrigger.closest(
							'.tutorhelper-student-bookings-table__actions'
						);

					const status =
						cell
							? cell.querySelector(
								'[data-late-reminder-status]'
							)
							: null;

					if (status) {
						status.textContent =
							config.lateReminderSentLabel;
					}
				}

				lateReminderModal.hidden = true;
				lateReminderBookingId = 0;

			} catch (error) {

				window.alert(
					error
					&& error.message
						? error.message
						: config.lateReminderFailedLabel
				);

			} finally {

				sendButton.disabled = false;
				sendButton.textContent =
					originalLabel;
			}
		}
	);


})();
