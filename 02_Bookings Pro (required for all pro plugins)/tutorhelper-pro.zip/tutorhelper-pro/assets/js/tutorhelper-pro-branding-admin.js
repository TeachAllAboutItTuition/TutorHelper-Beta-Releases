(function () {
	'use strict';


	document.addEventListener(
		'click',
		function (event) {

			const selectButton =
				event.target.closest(
					'[data-branding-image-select]'
				);

			if (selectButton) {

				const field =
					selectButton.closest(
						'[data-tutorhelper-branding-image]'
					);

				if (
					!field
					|| !window.wp
					|| !window.wp.media
				) {
					return;
				}

				const idField =
					field.querySelector(
						'[data-branding-image-id]'
					);

				const preview =
					field.querySelector(
						'[data-branding-image-preview]'
					);

				const removeButton =
					field.querySelector(
						'[data-branding-image-remove]'
					);

				const frame =
					window.wp.media({
						title:
							'Choose branding image',

						button: {
							text:
								'Use this image',
						},

						multiple:
							false,

						library: {
							type:
								'image',
						},
					});

				frame.on(
					'select',
					function () {

						const attachment =
							frame
								.state()
								.get(
									'selection'
								)
								.first()
								.toJSON();

						if (idField) {
							idField.value =
								attachment.id;
						}

						if (preview) {

							const imageUrl =
								attachment.sizes
								&& attachment.sizes.medium
									? attachment.sizes.medium.url
									: attachment.url;

							preview.innerHTML =
								'<img src="'
								+ imageUrl
								+ '" width="200" alt="">';
						}

                        const imageType =
                            field.dataset.brandingImageType;


                        if (
                            imageType
                                === 'logo_attachment_id'
                        ) {

                            const logoPreview =
                                document.querySelector(
                                    '[data-branding-preview-logo]'
                                );

                            if (logoPreview) {

                                logoPreview.innerHTML =
                                    '<img src="'
                                    + imageUrl
                                    + '" alt="">';
                            }
                        }


                        if (
                            imageType
                                === 'email_banner_attachment_id'
                        ) {

                            const bannerPreview =
                                document.querySelector(
                                    '[data-branding-preview-banner]'
                                );

                            if (bannerPreview) {

                                bannerPreview.innerHTML =
                                    '<img src="'
                                    + (
                                        attachment.url
                                        || imageUrl
                                    )
                                    + '" alt="">';

                                bannerPreview.classList.remove(
                                    'is-empty'
                                );
                            }
                        }

						if (removeButton) {
							removeButton.disabled =
								false;
						}
					}
				);

				frame.open();

				return;
			}


			const removeButton =
				event.target.closest(
					'[data-branding-image-remove]'
				);

			if (!removeButton) {
				return;
			}

			const field =
				removeButton.closest(
					'[data-tutorhelper-branding-image]'
				);

			if (!field) {
				return;
			}

			const idField =
				field.querySelector(
					'[data-branding-image-id]'
				);

			const preview =
				field.querySelector(
					'[data-branding-image-preview]'
				);

			if (idField) {
				idField.value = '';
			}

			if (preview) {
				preview.innerHTML = '';
			}

            const imageType =
                field.dataset.brandingImageType;


            if (
                imageType
                    === 'logo_attachment_id'
            ) {

                const logoPreview =
                    document.querySelector(
                        '[data-branding-preview-logo]'
                    );

                if (logoPreview) {
                    logoPreview.innerHTML = '';
                }
            }


            if (
                imageType
                    === 'email_banner_attachment_id'
            ) {

                const bannerPreview =
                    document.querySelector(
                        '[data-branding-preview-banner]'
                    );

                if (bannerPreview) {

                    bannerPreview.innerHTML =
                        '<span>Email banner</span>';

                    bannerPreview.classList.add(
                        'is-empty'
                    );
                }
            }

			removeButton.disabled =
				true;
		}
	);


    const brandingPreview =
        document.querySelector(
            '[data-branding-preview]'
        );


    function updateBrandingPreview() {

        if (!brandingPreview) {
            return;
        }

        const colorFields =
            document.querySelectorAll(
                '[data-branding-color]'
            );

        colorFields.forEach(
            function (field) {

                const key =
                    field.dataset.brandingColor;

                const value =
                    field.value;

                const variableMap = {
                    primary_color:
                        '--branding-primary',

                    accent_color:
                        '--branding-accent',

                    text_color:
                        '--branding-text',

                    heading_color:
                        '--branding-heading',

                    background_color:
                        '--branding-background',
                };

                if (
                    variableMap[key]
                ) {
                    brandingPreview.style.setProperty(
                        variableMap[key],
                        value
                    );
                }

                const valueDisplay =
                    document.querySelector(
                        '[data-branding-color-value="'
                        + key
                        + '"]'
                    );

                if (valueDisplay) {
                    valueDisplay.textContent =
                        value;
                }
            }
        );


        const textFont =
            document.querySelector(
                '[data-branding-preview-text-font]'
            );

        if (textFont) {
            brandingPreview.style.setProperty(
                '--branding-text-font',
                textFont.value
            );
        }


        const headingFont =
            document.querySelector(
                '[data-branding-preview-heading-font]'
            );

        if (headingFont) {
            brandingPreview.style.setProperty(
                '--branding-heading-font',
                headingFont.value
            );
        }


        const businessName =
            document.querySelector(
                '[data-branding-business-name]'
            );

        const businessPreview =
            document.querySelector(
                '[data-branding-preview-business-name]'
            );

        if (
            businessName
            && businessPreview
        ) {
            businessPreview.textContent =
                businessName.value;
        }


        const tagline =
            document.querySelector(
                '[data-branding-tagline]'
            );

        const taglinePreview =
            document.querySelector(
                '[data-branding-preview-tagline]'
            );

        if (
            tagline
            && taglinePreview
        ) {
            taglinePreview.textContent =
                tagline.value;
        }
    }


    document
        .querySelectorAll(
            [
                '[data-branding-color]',
                '[data-branding-preview-text-font]',
                '[data-branding-preview-heading-font]',
                '[data-branding-business-name]',
                '[data-branding-tagline]',
            ].join(',')
        )
        .forEach(
            function (field) {

                field.addEventListener(
                    'input',
                    updateBrandingPreview
                );

                field.addEventListener(
                    'change',
                    updateBrandingPreview
                );
            }
        );


    updateBrandingPreview();


})();
