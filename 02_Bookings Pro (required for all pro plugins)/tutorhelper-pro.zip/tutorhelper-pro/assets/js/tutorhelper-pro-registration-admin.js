(function ($) {
	'use strict';

	function initialiseQuestionType() {
		const type = document.getElementById(
			'tutorhelper-pro-question-type'
		);

		const options = document.querySelector(
			'[data-onboarding-options]'
		);

		if (!type || !options) {
			return;
		}

		function update() {
			const requiresOptions =
				type.value === 'checkbox'
				|| type.value === 'dropdown';

			options.hidden = !requiresOptions;

			const field = options.querySelector(
				'textarea'
			);

			if (field) {
				field.required = requiresOptions;
			}
		}

		type.addEventListener(
			'change',
			update
		);

		update();
	}


	function initialiseDataGuidance() {
		const category = document.getElementById(
			'tutorhelper-pro-data-category'
		);

		if (!category) {
			return;
		}

		const notices = document.querySelectorAll(
			'[data-category]'
		);

		function update() {
			notices.forEach(function (notice) {
				notice.hidden =
					notice.dataset.category
					!== category.value;
			});
		}

		category.addEventListener(
			'change',
			update
		);

		update();
	}


	function initialiseSorting() {
		const list = document.getElementById(
			'tutorhelper-pro-onboarding-question-list'
		);

		const status = document.getElementById(
			'tutorhelper-pro-onboarding-order-status'
		);

		if (
			!list
			|| typeof $.fn.sortable !== 'function'
			|| typeof tutorhelperProRegistrations
				=== 'undefined'
		) {
			return;
		}

        list.classList.add(
            'is-sortable-ready'
        );

		$(list).sortable({
            items:
                '> .tutorhelper-pro-onboarding-question.is-sortable',

            handle:
                '.tutorhelper-pro-onboarding-question__drag',

            axis: 'y',
            tolerance: 'pointer',
            cursor: 'grabbing',

            placeholder:
                'tutorhelper-pro-onboarding-question__placeholder',

            forcePlaceholderSize: true,
			update: function () {
				const ids = [];

				list.querySelectorAll(
					'.tutorhelper-pro-onboarding-question'
				).forEach(function (item) {
					const id = parseInt(
						item.dataset.questionId,
						10
					);

					if (id > 0) {
						ids.push(id);
					}
				});

				if (status) {
					status.textContent =
						tutorhelperProRegistrations.saving;
				}

				$.ajax({
					url:
						tutorhelperProRegistrations.ajaxUrl,

					method: 'POST',

					data: {
						action:
							tutorhelperProRegistrations
								.reorderAction,

						nonce:
							tutorhelperProRegistrations
								.reorderNonce,

						question_ids:
							ids
					}
				})
					.done(function (response) {
						if (
							response
							&& response.success
						) {
							status.textContent =
								response.data.message;
							return;
						}

						status.textContent =
							tutorhelperProRegistrations.failed;
					})
					.fail(function () {
						status.textContent =
							tutorhelperProRegistrations.failed;
					});
			}
		});
	}


	$(function () {
		initialiseQuestionType();
		initialiseDataGuidance();
		initialiseSorting();
	});

})(jQuery);
