( function () {
	'use strict';

	function initialise( controls ) {
		var dashboard = controls.closest( '[data-tutorhelper-student-dashboard]' );
		var cards = dashboard && dashboard.querySelector( '.tutorhelper-student-dashboard__sections' );
		var table = controls.querySelector( '[data-dashboard-table-view]' );
		var tableElement = table && table.querySelector( 'table' );
		var rows = tableElement ? Array.prototype.slice.call( tableElement.querySelectorAll( '[data-dashboard-table-row]' ) ) : [];
		var tableGroups = tableElement ? tableElement.querySelectorAll( '[data-dashboard-table-group]' ) : [];
		var empty = controls.querySelector( '[data-dashboard-no-results]' );
		var count = controls.querySelector( '[data-dashboard-result-count]' );
		var viewButtons = controls.querySelectorAll( '[data-dashboard-view-button]' );
		var filters = controls.querySelectorAll( '[data-dashboard-filter]' );
		var sortButtons = controls.querySelectorAll( '[data-dashboard-sort]' );
		var reset = controls.querySelector( '[data-dashboard-filter-reset]' );
		var storageKey = controls.getAttribute( 'data-storage-key' );
		var sortKey = 'date';
		var direction = 'grouped';

		if ( ! cards || ! table || ! tableElement ) {
			return;
		}

		function savedView() {
			try {
				return window.localStorage.getItem( storageKey );
			} catch ( error ) {
				return null;
			}
		}

		function setView( view, remember ) {
			var tableActive = 'table' === view;

			cards.hidden = tableActive;
			table.hidden = ! tableActive;

			Array.prototype.forEach.call( viewButtons, function ( button ) {
				var active = button.getAttribute( 'data-dashboard-view-button' ) === view;
				button.classList.toggle( 'is-active', active );
				button.setAttribute( 'aria-pressed', active ? 'true' : 'false' );
			} );

			if ( remember ) {
				try {
					window.localStorage.setItem( storageKey, view );
				} catch ( error ) {
					// The switch still works when browser storage is unavailable.
				}
			}
		}

		function filterValue( key ) {
			var field = controls.querySelector( '[data-dashboard-filter="' + key + '"]' );
			return field ? field.value : '';
		}

		function applyFilters() {
			var values = {
				timeframe: filterValue( 'timeframe' ),
				status: filterValue( 'status' ),
				type: filterValue( 'type' ),
				location: filterValue( 'location' )
			};
			var visible = 0;

			rows.forEach( function ( row ) {
				var show = Object.keys( values ).every( function ( key ) {
					if ( 'status' === key && 'confirmed' === values[ key ] ) {
						return 'confirmed' === row.getAttribute( 'data-booking-status' );
					}
					return ! values[ key ] || values[ key ] === row.getAttribute( 'data-' + key );
				} );

				row.hidden = ! show;
				if ( show ) {
					visible++;
				}
			} );

			Array.prototype.forEach.call( tableGroups, function ( group ) {
				var groupRows = Array.prototype.slice.call( group.querySelectorAll( '[data-dashboard-table-row]' ) );
				group.hidden = ! groupRows.some( function ( row ) {
					return ! row.hidden;
				} );
			} );

			if ( empty ) {
				empty.hidden = 0 !== visible;
			}
			if ( count ) {
				var strings = window.TutorHelperProDashboardTable || {};
				var singular = strings.oneLesson || '1 lesson shown';
				var plural = strings.manyLessons || '%d lessons shown';
				count.textContent = 1 === visible
					? singular
					: plural.replace( '%d', visible );
			}
		}

		function sortValue( row, key ) {
			if ( 'date' === key || 'time' === key ) {
				return parseInt( row.getAttribute( 'data-' + key ), 10 ) || 0;
			}
			if ( 'location' === key || 'status' === key ) {
				return row.getAttribute( 'data-' + key + '-label' ) || '';
			}
			return row.getAttribute( 'data-' + key ) || '';
		}

		function applySort() {
			rows.sort( function ( first, second ) {
				var firstValue = sortValue( first, sortKey );
				var secondValue = sortValue( second, sortKey );
				var result = 'number' === typeof firstValue
					? firstValue - secondValue
					: firstValue.localeCompare( secondValue, undefined, {
						numeric: true,
						sensitivity: 'base'
					} );

				if ( 'grouped' === direction && 'date' === sortKey ) {
					var firstTimeframe = first.getAttribute( 'data-timeframe' );
					var secondTimeframe = second.getAttribute( 'data-timeframe' );

					if ( firstTimeframe !== secondTimeframe ) {
						return 0;
					}

					return 'past' === firstTimeframe ? -result : result;
				}

				return 'asc' === direction ? result : -result;
			} );

			rows.forEach( function ( row ) {
				var groupName = 'past' === row.getAttribute( 'data-timeframe' ) ? 'past' : 'upcoming';
				var group = tableElement.querySelector( '[data-dashboard-table-group="' + groupName + '"]' );
				if ( group ) {
					group.appendChild( row );
				}
			} );

			Array.prototype.forEach.call( sortButtons, function ( button ) {
				var active = sortKey === button.getAttribute( 'data-dashboard-sort' );
				var heading = button.closest( 'th' );
				var indicator = button.querySelector( '[data-dashboard-sort-indicator]' );

				if ( heading ) {
					heading.setAttribute(
						'aria-sort',
						active && 'grouped' !== direction
							? ( 'asc' === direction ? 'ascending' : 'descending' )
							: 'none'
					);
				}
				if ( indicator ) {
					indicator.textContent = active && 'grouped' !== direction
						? ( 'asc' === direction ? '↑' : '↓' )
						: '↕';
				}
			} );
		}

		Array.prototype.forEach.call( viewButtons, function ( button ) {
			button.addEventListener( 'click', function () {
				setView( button.getAttribute( 'data-dashboard-view-button' ), true );
			} );
		} );

		Array.prototype.forEach.call( filters, function ( field ) {
			field.addEventListener( 'change', applyFilters );
		} );

		Array.prototype.forEach.call( sortButtons, function ( button ) {
			button.addEventListener( 'click', function () {
				var key = button.getAttribute( 'data-dashboard-sort' );
				if ( sortKey === key ) {
					direction = 'asc' === direction ? 'desc' : 'asc';
				} else {
					sortKey = key;
					direction = 'asc';
				}
				applySort();
			} );
		} );

		if ( reset ) {
			reset.addEventListener( 'click', function () {
				Array.prototype.forEach.call( filters, function ( field ) {
					field.value = '';
				} );
				applyFilters();
			} );
		}

		applySort();
		applyFilters();
		setView( 'table' === savedView() ? 'table' : 'cards', false );
	}

	function initialiseCardPagination( section ) {
		var cardGrid = section.querySelector( '.tutorhelper-student-dashboard__cards' );
		var cards = cardGrid ? Array.prototype.slice.call( cardGrid.querySelectorAll( '.tutorhelper-student-dashboard__card' ) ) : [];
		var pageSize = 6;
		var pageCount = Math.ceil( cards.length / pageSize );
		var currentPage = 1;

		if ( ! cardGrid || pageCount <= 1 ) {
			return;
		}

		var strings = window.TutorHelperProDashboardTable || {};
		var pagination = document.createElement( 'nav' );
		var previous = document.createElement( 'button' );
		var status = document.createElement( 'span' );
		var next = document.createElement( 'button' );

		pagination.className = 'tutorhelper-pro-card-pagination';
		pagination.setAttribute( 'aria-label', strings.cardPagesLabel || 'Lesson card pages' );
		previous.type = 'button';
		previous.textContent = strings.previousPage || 'Previous';
		next.type = 'button';
		next.textContent = strings.nextPage || 'Next';
		status.setAttribute( 'aria-live', 'polite' );
		pagination.appendChild( previous );
		pagination.appendChild( status );
		pagination.appendChild( next );
		cardGrid.insertAdjacentElement( 'afterend', pagination );

		function showPage( page ) {
			var template = strings.cardPageStatus || 'Page %1$d of %2$d';
			currentPage = Math.min( Math.max( page, 1 ), pageCount );
			cards.forEach( function ( card, index ) {
				card.hidden = index < ( currentPage - 1 ) * pageSize || index >= currentPage * pageSize;
			} );
			previous.disabled = 1 === currentPage;
			next.disabled = pageCount === currentPage;
			status.textContent = template.replace( '%1$d', currentPage ).replace( '%2$d', pageCount );
		}

		previous.addEventListener( 'click', function () {
			showPage( currentPage - 1 );
		} );
		next.addEventListener( 'click', function () {
			showPage( currentPage + 1 );
		} );

		showPage( 1 );
	}

	function initialiseAttendanceHistory( history ) {
		var rows = Array.prototype.slice.call( history.querySelectorAll( '[data-attendance-row]' ) );
		var pagination = history.querySelector( '[data-attendance-pagination]' );
		var previous = history.querySelector( '[data-attendance-previous]' );
		var next = history.querySelector( '[data-attendance-next]' );
		var status = history.querySelector( '[data-attendance-page-status]' );
		var pageSize = parseInt( history.getAttribute( 'data-page-size' ), 10 ) || 10;
		var pageCount = Math.max( 1, Math.ceil( rows.length / pageSize ) );
		var currentPage = 1;

		if ( ! pagination || ! previous || ! next || ! status || rows.length <= pageSize ) {
			return;
		}

		function showPage( page ) {
			currentPage = Math.min( Math.max( page, 1 ), pageCount );
			rows.forEach( function ( row, index ) {
				row.hidden = index < ( currentPage - 1 ) * pageSize || index >= currentPage * pageSize;
			} );
			previous.disabled = 1 === currentPage;
			next.disabled = pageCount === currentPage;
			status.textContent = currentPage + ' / ' + pageCount;
		}

		previous.addEventListener( 'click', function () {
			showPage( currentPage - 1 );
		} );
		next.addEventListener( 'click', function () {
			showPage( currentPage + 1 );
		} );

		pagination.hidden = false;
		showPage( 1 );
	}

	function start() {
		Array.prototype.forEach.call(
			document.querySelectorAll( '[data-tutorhelper-pro-dashboard-view]' ),
			initialise
		);
		Array.prototype.forEach.call(
			document.querySelectorAll( '[data-attendance-history]' ),
			initialiseAttendanceHistory
		);
		Array.prototype.forEach.call(
			document.querySelectorAll( '.tutorhelper-student-dashboard__section' ),
			initialiseCardPagination
		);
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
}() );
