(function () {
	'use strict';

	const config =
		window.tutorhelperProRecurrence || null;

	const root =
		document.querySelector(
			'[data-pro-recurrence]'
		);

	if (!config || !root) {
		return;
	}

	const toggle =
		root.querySelector(
			'[data-pro-recurrence-toggle]'
		);

	const options =
		root.querySelector(
			'[data-pro-recurrence-options]'
		);

	const summary =
		document.querySelector(
			'[data-pro-recurrence-summary]'
		);

	const summaryText =
		summary
			? summary.querySelector(
				'[data-pro-recurrence-summary-text]'
			)
			: null;

	const counts =
		summary
			? summary.querySelector(
				'[data-pro-recurrence-counts]'
			)
			: null;

	const occurrences =
		summary
			? summary.querySelector(
				'[data-pro-recurrence-occurrences]'
			)
			: null;

	const status =
		summary
			? summary.querySelector(
				'[data-pro-recurrence-status]'
			)
			: null;

	const spinner =
		summary
			? summary.querySelector(
				'[data-pro-recurrence-spinner]'
			)
			: null;

	const form =
		root.closest('form');

	if (!toggle || !options || !summary || !form) {
		return;
	}

	const bookingDate =
		form.querySelector(
			'[name="booking_date"]'
		);
    
    const bookingType =
        form.querySelector(
            '[name="booking_type_id"]'
        );

    const startTime =
        form.querySelector(
            '[name="start_time"]'
        );

    const endTime =
        form.querySelector(
            '[name="end_time"]'
        );

    const timezone =
        form.querySelector(
            '[name="timezone"]'
        );

    const locationType =
        form.querySelector(
            '[name="location_type"]'
        );

	const endDate =
		root.querySelector(
			'[name="tutorhelper_pro_recurrence_end_date"]'
		);

	const frequency =
		root.querySelector(
			'[name="tutorhelper_pro_recurrence_frequency"]'
		);

	const termTime =
		root.querySelector(
			'[name="tutorhelper_pro_exclude_outside_term_time"]'
		);

	const holidays =
		root.querySelector(
			'[name="tutorhelper_pro_exclude_public_holidays"]'
		);

	let requestTimer = null;
	let controller = null;

	function setEnabled(enabled) {
		options.hidden = !enabled;
        summary.hidden = !enabled;

        summary.style.display =
            enabled
                ? ''
                : 'none';

        [
            bookingType,
            startTime,
            endTime,
            locationType
        ].forEach(function (field) {
            if (field) {
                field.addEventListener(
                    'change',
                    schedulePreview
                );
            }
        });


		[
			endDate,
			frequency,
			termTime,
			holidays
		].forEach(function (field) {
			if (field) {
				field.disabled = !enabled;
			}
		});

		if (endDate) {
			endDate.required = enabled;
		}
	}

	function formatDate(value) {
		const parts = value.split('-');

		if (parts.length !== 3) {
			return value;
		}

		const date = new Date(
			Number(parts[0]),
			Number(parts[1]) - 1,
			Number(parts[2])
		);

		return new Intl.DateTimeFormat(
			document.documentElement.lang || undefined,
			{
				weekday: 'short',
				day: 'numeric',
				month: 'short',
				year: 'numeric'
			}
		).format(date);
	}

	function skipReason(item) {
		if (item.skipLabel) {
			return item.skipLabel;
		}

		switch (item.skipReason) {
            case 'tutor_unavailable':
                return config.labels.unavailable;

            case 'outside_term_time':
                return config.labels.termTime;

            case 'public_holiday':
                return config.labels.holiday;

            case 'booking_conflict':
                return config.labels.clash;

            default:
                return '';
        }
	}

	function renderPlan(data) {
		if (!data.complete) {
			if (status) {
				status.textContent =
					'Choose an end date to preview the series.';
			}
			return;
		}

		if (summaryText) {
			summaryText.textContent =
				formatDate(bookingDate.value)
				+ ' – '
				+ formatDate(endDate.value);
		}

		if (counts) {
            counts.textContent =
                data.includedCount
                    + ' '
                    + config.labels.lessons
                    + ' · '
                    + data.skippedCount
                    + ' '
                    + config.labels.skipped;

            
        }

		if (occurrences) {
			occurrences.innerHTML = '';

			data.occurrences.forEach(
                function (item) {
                    const row =
                        document.createElement('li');

                    /*
                    * Decide how this occurrence should be styled.
                    *
                    * A blocking clash takes priority over the normal
                    * included/skipped appearance.
                    */
                    if (item.blocked) {
                        row.className =
                            'is-blocked';
                    } else {
                        row.className =
                            item.shouldCreate
                                ? 'is-included'
                                : 'is-skipped';
                    }

                    const marker =
                        document.createElement('span');

                    marker.setAttribute(
                        'aria-hidden',
                        'true'
                    );

                    /*
                    * Use:
                    *
                    * !  = booking clash / blocking condition
                    * ✓  = occurrence will be created
                    * –  = occurrence skipped by recurrence rules
                    */
                    if (item.blocked) {
                        marker.textContent = '!';
                    } else {
                        marker.textContent =
                            item.shouldCreate
                                ? '✓'
                                : '–';
                    }

                    const text =
                        document.createElement('span');

                    text.textContent =
                        formatDate(item.date);

                    row.appendChild(marker);
                    row.appendChild(text);

                    /*
                    * Blocking conditions and ordinary skipped dates
                    * have different explanations.
                    */
                    if (item.blocked) {
                        const reason =
                            document.createElement(
                                'small'
                            );

                        if (
                            item.blockReason
                            === 'booking_conflict'
                        ) {
                            reason.textContent =
                                config.labels.clash;
                        } else {
                            reason.textContent =
                                config.labels.blocked;
                        }

                        row.appendChild(reason);

                    } else if (!item.shouldCreate) {
                        const reason =
                            document.createElement(
                                'small'
                            );

                        reason.textContent =
                            skipReason(item);

                        row.appendChild(reason);
                    }

                    occurrences.appendChild(row);
                }
            );
		}

		if (status) {
			status.textContent = '';
		}
	}

	function preview() {
		if (
            !toggle.checked
            || !bookingDate
            || !bookingDate.value
            || !endDate
            || !endDate.value
            || !frequency
            || !frequency.value
            || !bookingType
            || !bookingType.value
            || !startTime
            || !startTime.value
            || !endTime
            || !endTime.value
            || !locationType
            || !locationType.value
        ) {
            return;
        }

		if (controller) {
			controller.abort();
		}

		controller = new AbortController();

		if (spinner) {
			spinner.classList.add('is-active');
		}

		const body = new FormData();

		body.append(
			'action',
			config.action
		);

		body.append(
			'nonce',
			config.nonce
		);

        body.append(
            'booking_type_id',
            bookingType.value
        );

        body.append(
            'start_time',
            startTime.value
        );

        body.append(
            'end_time',
            endTime.value
        );

        body.append(
            'timezone',
            timezone && timezone.value
                ? timezone.value
                : ''
        );

        body.append(
            'location_type',
            locationType.value
        );

		body.append(
			'start_date',
			bookingDate.value
		);

		body.append(
			'end_date',
			endDate.value
		);

		body.append(
			'frequency',
			frequency.value
		);

		body.append(
			'exclude_outside_term_time',
			termTime && termTime.checked
				? '1'
				: '0'
		);

		body.append(
			'exclude_public_holidays',
			holidays && holidays.checked
				? '1'
				: '0'
		);

		fetch(
			config.ajaxUrl,
			{
				method: 'POST',
				credentials: 'same-origin',
				body: body,
				signal: controller.signal
			}
		)
			.then(function (response) {
				return response.json();
			})
			.then(function (response) {
				if (
					!response.success
					|| !response.data
				) {
					throw new Error(
						response.data
						&& response.data.message
							? response.data.message
							: config.labels.failed
					);
				}

				renderPlan(response.data);
			})
			.catch(function (error) {
				if (error.name === 'AbortError') {
					return;
				}

				if (status) {
					status.textContent =
						error.message
						|| config.labels.failed;
				}
			})
			.finally(function () {
				if (spinner) {
					spinner.classList.remove(
						'is-active'
					);
				}
			});
	}

	function schedulePreview() {
		window.clearTimeout(
			requestTimer
		);

		requestTimer =
			window.setTimeout(
				preview,
				250
			);
	}

	toggle.addEventListener(
		'change',
		function () {
			setEnabled(toggle.checked);

			if (
				toggle.checked
				&& bookingDate
				&& bookingDate.value
				&& endDate
				&& !endDate.value
			) {
				endDate.value =
					bookingDate.value;
			}

			if (toggle.checked) {
				schedulePreview();
			}
		}
	);

	root
		.querySelectorAll(
			'[data-pro-recurrence-field]'
		)
		.forEach(function (field) {
			field.addEventListener(
				'change',
				schedulePreview
			);
		});

	if (bookingDate) {
		bookingDate.addEventListener(
			'change',
			function () {
				if (
					endDate
					&& (
						!endDate.value
						|| endDate.value
							< bookingDate.value
					)
				) {
					endDate.value =
						bookingDate.value;
				}

				schedulePreview();
			}
		);
	}

	setEnabled(false);
})();
