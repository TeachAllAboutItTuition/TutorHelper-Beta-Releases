(function () {
	'use strict';

	const config = window.tutorhelperProStudentEmail;
	const composer = document.querySelector('[data-student-email-composer]');

	if (!config || !composer) {
		return;
	}

	const modal = composer.querySelector('[data-student-email-modal]');
	const openButton = composer.querySelector('[data-student-email-open]');
	const subjectField = composer.querySelector('[data-student-email-subject]');
	const previewFrame = composer.querySelector('[data-student-email-preview-frame]');
	const previewButton = composer.querySelector('[data-student-email-preview]');
	const sendButton = composer.querySelector('[data-student-email-send]');
	const status = composer.querySelector('[data-student-email-status]');
	const copyTutorField = composer.querySelector('[data-student-email-copy-tutor]');
	const studentId = parseInt(composer.dataset.studentId, 10);
	let previousFocus = null;

	if (!modal || !openButton || !studentId) {
		return;
	}

	/**
	 * Return the WordPress visual editor when it is available.
	 *
	 * @return {Object|null} TinyMCE editor.
	 */
	function getEditor() {
		if (!window.tinymce || typeof window.tinymce.get !== 'function') {
			return null;
		}

		return window.tinymce.get(config.editorId);
	}

	/**
	 * Read the current message from the active editor mode.
	 *
	 * @return {string} Message HTML.
	 */
	function getMessage() {
		const editor = getEditor();

		if (editor && !editor.isHidden()) {
			return editor.getContent();
		}

		const textarea = document.getElementById(config.editorId);
		return textarea ? textarea.value : '';
	}

	/**
	 * Replace the editor contents.
	 *
	 * @param {string} content Message HTML.
	 */
	function setMessage(content) {
		const textarea = document.getElementById(config.editorId);
		const editor = getEditor();

		if (textarea) {
			textarea.value = content;
		}

		if (editor) {
			editor.setContent(content);
		}
	}

	/**
	 * Return selected recipient types.
	 *
	 * @return {Array<string>} Recipient types.
	 */
	function getRecipients() {
		return Array.from(
			composer.querySelectorAll('[data-student-email-recipient]:checked:not(:disabled)')
		).map(function (field) {
			return field.value;
		});
	}

	/**
	 * Show an accessible status message.
	 *
	 * @param {string} message Message.
	 * @param {string} type    Status type.
	 */
	function setStatus(message, type) {
		status.textContent = message || '';
		status.classList.remove('is-success', 'is-error', 'is-loading');

		if (type) {
			status.classList.add('is-' + type);
		}
	}

	/**
	 * Return validated composer values or display an error.
	 *
	 * @return {Object|null} Values.
	 */
	function getValues() {
		const subject = subjectField ? subjectField.value.trim() : '';
		const message = getMessage().trim();
		const recipients = getRecipients();

		if (!recipients.length) {
			setStatus(config.chooseRecipient, 'error');
			return null;
		}

		if (!subject || !message) {
			setStatus(config.completeFields, 'error');
			return null;
		}

		return {
			subject: subject,
			message: message,
			recipients: recipients,
			copyTutor: Boolean(copyTutorField && copyTutorField.checked)
		};
	}

	/**
	 * Post one composer request.
	 *
	 * @param {string} action AJAX action.
	 * @param {Object} values Composer values.
	 * @return {Promise<Object>} Parsed response.
	 */
	async function postRequest(action, values) {
		const data = new FormData();
		data.append('action', action);
		data.append('nonce', config.nonce);
		data.append('student_id', String(studentId));
		data.append('subject', values.subject);
		data.append('message', values.message);
		data.append('copy_tutor', values.copyTutor ? '1' : '0');

		values.recipients.forEach(function (recipient) {
			data.append('recipients[]', recipient);
		});

		data.append('recipient_type', values.recipients[0]);

		const response = await fetch(
			config.ajaxUrl,
			{
				method: 'POST',
				credentials: 'same-origin',
				body: data
			}
		);

		return response.json();
	}

	/**
	 * Refresh the exact branded preview.
	 */
	async function refreshPreview() {
		const values = getValues();

		if (!values) {
			return;
		}

		previewButton.disabled = true;
		setStatus(config.previewingLabel, 'loading');

		try {
			const payload = await postRequest(config.previewAction, values);

			if (!payload.success || !payload.data || !payload.data.html) {
				throw new Error(
					payload.data && payload.data.message
						? payload.data.message
						: config.previewError
				);
			}

			previewFrame.srcdoc = payload.data.html;
			setStatus('', '');
		} catch (error) {
			setStatus(
				error && error.message ? error.message : config.previewError,
				'error'
			);
		} finally {
			previewButton.disabled = false;
		}
	}

	/**
	 * Reset and open the modal.
	 */
	function openModal() {
		previousFocus = document.activeElement;
		subjectField.value = config.defaultSubject;
		setMessage(config.defaultMessage);
		setStatus('', '');
		previewFrame.removeAttribute('srcdoc');

		composer.querySelectorAll('[data-student-email-recipient]').forEach(function (field) {
			const unavailable = field.closest('label').classList.contains('is-unavailable');
			field.disabled = unavailable;
			field.checked = !unavailable && 'student' === field.value;
		});

		const availableChecked = getRecipients();
		if (!availableChecked.length) {
			const firstAvailable = composer.querySelector('[data-student-email-recipient]:not(:disabled)');
			if (firstAvailable) {
				firstAvailable.checked = true;
			}
		}

		modal.hidden = false;
		document.body.classList.add('tutorhelper-modal-open');
		subjectField.focus();
		window.setTimeout(refreshPreview, 120);
	}

	/**
	 * Close the modal and restore focus.
	 */
	function closeModal() {
		modal.hidden = true;
		document.body.classList.remove('tutorhelper-modal-open');

		if (previousFocus && typeof previousFocus.focus === 'function') {
			previousFocus.focus();
		}
	}

	openButton.addEventListener('click', openModal);
	previewButton.addEventListener('click', refreshPreview);

	composer.addEventListener('click', function (event) {
		if (event.target.closest('[data-student-email-close]')) {
			closeModal();
		}
	});

	sendButton.addEventListener('click', async function () {
		const values = getValues();

		if (!values) {
			return;
		}

		sendButton.disabled = true;
		previewButton.disabled = true;
		const originalLabel = sendButton.textContent;
		sendButton.textContent = config.sendingLabel;
		setStatus(config.sendingLabel, 'loading');

		try {
			const payload = await postRequest(config.sendAction, values);
			const data = payload.data || {};

			if (!payload.success) {
				(data.sentRecipientTypes || []).forEach(function (recipientType) {
					const field = composer.querySelector(
						'[data-student-email-recipient][value="' + recipientType + '"]'
					);
					if (field) {
						field.checked = false;
						field.disabled = true;
					}
				});

				throw new Error(data.message || config.sendError);
			}

			setStatus(data.message, 'success');
			window.location.hash = 'tutorhelper-notes-communication';
			window.setTimeout(function () {
				window.location.reload();
			}, 700);
		} catch (error) {
			setStatus(
				error && error.message ? error.message : config.sendError,
				'error'
			);
		} finally {
			sendButton.disabled = false;
			previewButton.disabled = false;
			sendButton.textContent = originalLabel;
		}
	});

	document.addEventListener('keydown', function (event) {
		if (modal.hidden) {
			return;
		}

		if ('Escape' === event.key) {
			event.preventDefault();
			closeModal();
			return;
		}

		if ('Tab' !== event.key) {
			return;
		}

		const focusable = Array.from(
			modal.querySelectorAll(
				'button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])'
			)
		).filter(function (element) {
			return null !== element.offsetParent;
		});

		if (!focusable.length) {
			return;
		}

		const first = focusable[0];
		const last = focusable[focusable.length - 1];

		if (event.shiftKey && document.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	});
})();
