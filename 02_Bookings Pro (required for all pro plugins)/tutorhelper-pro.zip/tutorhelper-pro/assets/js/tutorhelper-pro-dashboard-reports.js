( function () {
	'use strict';

	var config = window.tutorhelperProDashboardReports || {};

	function requestBreakdown( panel, refreshing ) {
		var filters;
		if ( panel.dataset.loading === '1' ) {
			return;
		}
		try {
			filters = JSON.parse( panel.dataset.filters || '{}' );
		} catch ( error ) {
			filters = {};
		}

		panel.dataset.loading = '1';
		panel.setAttribute( 'aria-busy', 'true' );
		panel.innerHTML = '<p class="tutorhelper-pro-attendance-breakdown__status" role="status">' + ( refreshing ? config.refreshingText : config.loadingText ) + '</p>';

		var body = new window.URLSearchParams();
		body.append( 'action', config.action );
		body.append( 'nonce', config.nonce );
		body.append( 'breakdown', panel.dataset.breakdown || '' );
		Object.keys( filters ).forEach( function ( key ) {
			body.append( 'filters[' + key + ']', filters[ key ] );
		} );

		window.fetch( config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} ).then( function ( response ) {
			return response.json();
		} ).then( function ( response ) {
			if ( ! response.success || ! response.data || ! response.data.html ) {
				throw new Error( 'Invalid report response' );
			}
			panel.innerHTML = response.data.html;
			panel.dataset.loaded = '1';
		} ).catch( function () {
			panel.innerHTML = '<p class="notice notice-error tutorhelper-pro-attendance-breakdown__status" role="alert">' + config.errorText + '</p><button type="button" class="button tutorhelper-pro-attendance-breakdown__refresh">' + config.retryText + '</button>';
		} ).finally( function () {
			delete panel.dataset.loading;
			panel.removeAttribute( 'aria-busy' );
		} );
	}

	document.addEventListener( 'toggle', function ( event ) {
		var details = event.target;
		if ( ! details.matches || ! details.matches( 'details[open]' ) ) {
			return;
		}
		var panel = details.querySelector( '.tutorhelper-pro-attendance-breakdown' );
		if ( panel && panel.dataset.loaded !== '1' ) {
			requestBreakdown( panel, false );
		}
	}, true );

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '.tutorhelper-pro-attendance-breakdown__refresh' );
		if ( button ) {
			requestBreakdown( button.closest( '.tutorhelper-pro-attendance-breakdown' ), true );
		}
	} );
	function setupOutstandingHomework( panel ) {
		var body = panel.querySelector( 'tbody' );
		var search = panel.querySelector( '[data-outstanding-homework-search]' );
		var student = panel.querySelector( '[data-outstanding-homework-student]' );
		var bookingType = panel.querySelector( '[data-outstanding-homework-booking-type]' );
		var order = panel.querySelector( '[data-outstanding-homework-order]' );
		var empty = panel.querySelector( '[data-outstanding-homework-empty]' );
		if ( ! body || ! search || ! student || ! bookingType || ! order || panel.dataset.enhanced === '1' ) {
			return;
		}

		function rows() {
			return Array.prototype.slice.call( body.querySelectorAll( '[data-outstanding-homework-row]' ) );
		}

		function apply() {
			var term = ( search.value || '' ).trim().toLowerCase();
			var selectedStudent = student.value || '';
			var selectedType = ( bookingType.value || '' ).toLowerCase();
			var visible = 0;
			rows().forEach( function ( row ) {
				var matches = ( ! term || ( row.dataset.studentName + ' ' + row.dataset.homework ).indexOf( term ) !== -1 )
					&& ( ! selectedStudent || row.dataset.studentId === selectedStudent )
					&& ( ! selectedType || row.dataset.bookingType === selectedType );
				row.hidden = ! matches;
				if ( matches ) {
					visible += 1;
				}
			} );

			rows().sort( function ( left, right ) {
				var mode = order.value;
				var leftValue = mode.indexOf( 'student' ) === 0 ? left.dataset.studentName : left.dataset.dueAt;
				var rightValue = mode.indexOf( 'student' ) === 0 ? right.dataset.studentName : right.dataset.dueAt;
				var result = leftValue.localeCompare( rightValue );
				return mode.indexOf( '-desc' ) !== -1 ? -result : result;
			} ).forEach( function ( row ) {
				body.appendChild( row );
			} );
			empty.hidden = visible !== 0;
		}

		[ search, student, bookingType, order ].forEach( function ( control ) {
			control.addEventListener( control === search ? 'input' : 'change', apply );
		} );
		panel.dataset.enhanced = '1';
		apply();
	}

	function setupOutstandingHomeworkPanels() {
		document.querySelectorAll( '[data-outstanding-homework]' ).forEach( setupOutstandingHomework );
	}

	setupOutstandingHomeworkPanels();

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '[data-homework-not-due]' );
		var row;
		var body;
		var form;
		if ( ! button || ! config.homeworkNotDueAction || button.disabled ) {
			return;
		}
		if ( ! window.confirm( config.homeworkNotDueConfirm ) ) {
			return;
		}

		row = button.closest( '[data-outstanding-homework-row]' );
		body = row && row.parentNode;
		form = new window.URLSearchParams();
		form.append( 'action', config.homeworkNotDueAction );
		form.append( 'nonce', config.homeworkNotDueNonce || '' );
		form.append( 'booking_id', button.dataset.bookingId || '' );
		button.disabled = true;

		window.fetch( config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: form.toString()
		} ).then( function ( response ) {
			return response.json();
		} ).then( function ( response ) {
			if ( ! response.success ) {
				throw new Error( response.data && response.data.message ? response.data.message : config.homeworkNotDueError );
			}
			if ( row ) {
				row.remove();
			}
			var panel = button.closest( '[data-outstanding-homework]' );
			if ( body && ! body.querySelector( '[data-outstanding-homework-row]' ) && panel ) {
				var tableWrap = panel.querySelector( '.tutorhelper-pro-outstanding-homework__table-wrap' );
				var emptyMessage = panel.querySelector( '[data-outstanding-homework-empty]' );
				if ( tableWrap ) {
					tableWrap.hidden = true;
				}
				if ( emptyMessage ) {
					emptyMessage.textContent = 'No outstanding homework remains.';
					emptyMessage.hidden = false;
				}
				return;
			}
			setupOutstandingHomeworkPanels();
			if ( panel ) {
				var eventToDispatch = new window.Event( 'change' );
				panel.querySelector( '[data-outstanding-homework-order]' ).dispatchEvent( eventToDispatch );
			}
		} ).catch( function ( error ) {
			window.alert( error.message || config.homeworkNotDueError );
			button.disabled = false;
		} );
	} );

}() );
