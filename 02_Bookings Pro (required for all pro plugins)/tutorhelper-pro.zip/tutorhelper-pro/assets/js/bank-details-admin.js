(function () {
	'use strict';

	document.addEventListener(
		'DOMContentLoaded',
		function () {
			var panel = document.getElementById(
				'tutorhelper-pro-bank-details-panel'
			);

			if (!panel) {
				return;
			}

			var workspace = document.querySelector(
				'.tutorhelper-hub-workspace'
			);

			if (!workspace) {
				return;
			}

			panel.hidden = false;
			workspace.appendChild(panel);
		}
	);
})();
