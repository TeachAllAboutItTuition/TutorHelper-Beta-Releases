(function () {
	'use strict';

	function priceIsFree(priceLabel) {
		var label = String(priceLabel || '').trim().toLowerCase();

		if (!label || label.indexOf('free') !== -1) {
			return true;
		}

		var numericText = label
			.replace(/[^0-9.,-]/g, '')
			.replace(/,/g, '');

		var numericValue = Number.parseFloat(numericText);

		return !Number.isNaN(numericValue)
			&& numericValue <= 0;
	}

	document.addEventListener(
		'DOMContentLoaded',
		function () {
			document
				.querySelectorAll(
					'[data-tutorhelper-student-booking]'
				)
				.forEach(function (container) {
					var form = container.querySelector(
						'[data-booking-form]'
					);

					var summary = container.querySelector(
						'.tutorhelper-student-booking__summary'
					);

					if (!form || !summary) {
						return;
					}

					var paymentChoice = document.createElement('div');
					paymentChoice.className =
						'tutorhelper-pro-payment-choice';
					paymentChoice.setAttribute(
						'data-tutorhelper-payment-choice',
						''
					);
					paymentChoice.hidden = true;

					paymentChoice.innerHTML =
						'<h4>Payment method</h4>'
						+ '<div class="tutorhelper-pro-payment-choice__options">'
						+ '<label>'
						+ '<input type="radio" name="tutorhelper_payment_method" value="stripe" checked data-tutorhelper-booking-extension-field>'
						+ '<span><strong>Pay by card</strong><small>Pay securely online after confirming your lesson.</small></span>'
						+ '</label>'
						+ '<label>'
						+ '<input type="radio" name="tutorhelper_payment_method" value="manual" data-tutorhelper-booking-extension-field>'
						+ '<span><strong>Invoice / bank transfer</strong><small>Reserve the lesson now and arrange payment separately with your tutor.</small></span>'
						+ '</label>'
						+ '</div>';

					var policy = summary.querySelector(
						'.tutorhelper-student-booking__policy'
					);

					if (policy) {
						summary.insertBefore(
							paymentChoice,
							policy
						);
					} else {
						summary.appendChild(
							paymentChoice
						);
					}

					var cardInput = paymentChoice.querySelector(
						'input[value="stripe"]'
					);

					function resetChoice() {
						if (cardInput) {
							cardInput.checked = true;
						}
					}

					container.addEventListener(
						'tutorhelper:booking-service-selected',
						function (event) {
							var price =
								event.detail
								&& event.detail.price
									? event.detail.price
									: '';

							var isPaid =
								!priceIsFree(price);

							paymentChoice.hidden =
								!isPaid;

							if (!isPaid) {
								resetChoice();
							}
						}
					);
				});
		}
	);
})();
