( function () {
	'use strict';

	const config = window.tutorhelperProLessonRating || {};
	if ( ! config.ajaxUrl ) {
		return;
	}

	function summaryFor( bookingId ) {
		return document.querySelector( '[data-rating-summary][data-rating-booking="' + bookingId + '"]' );
	}

	function editorFor( bookingId ) {
		return document.querySelector( '[data-rating-editor][data-rating-booking="' + bookingId + '"]' );
	}

	function starLabel( rating ) {
		return ( config.stars || '%1$d out of %2$d stars' )
			.replace( '%1$d', rating )
			.replace( '%2$d', 5 );
	}

	function openEditor( bookingId ) {
		const editor = editorFor( bookingId );
		if ( ! editor ) {
			return;
		}
		editor.hidden = false;
		const selected = editor.querySelector( 'input[name="rating"]:checked' );
		const focusTarget = selected || editor.querySelector( 'input[name="rating"], textarea, button' );
		if ( focusTarget ) {
			focusTarget.focus();
		}
	}

	function closeEditor( editor ) {
		if ( editor && editor.classList.contains( 'is-modal' ) ) {
			editor.hidden = true;
			const summary = summaryFor( editor.getAttribute( 'data-rating-booking' ) );
			const edit = summary && summary.querySelector( '[data-rating-edit]' );
			if ( edit ) {
				edit.focus();
			}
		}
	}

	function moveModalToBody( editor ) {
		if ( editor && editor.classList.contains( 'is-modal' ) && editor.parentNode !== document.body ) {
			document.body.appendChild( editor );
		}
	}

	document.addEventListener( 'click', function ( event ) {
		const edit = event.target.closest( '[data-rating-edit]' );
		if ( edit ) {
			const summary = edit.closest( '[data-rating-summary]' );
			openEditor( summary ? summary.getAttribute( 'data-rating-booking' ) : '' );
			return;
		}

		const close = event.target.closest( '[data-rating-close]' );
		if ( close ) {
			closeEditor( close.closest( '[data-rating-editor]' ) );
			return;
		}

		if ( event.target.matches( '[data-rating-editor].is-modal' ) ) {
			closeEditor( event.target );
		}
	} );

	document.addEventListener( 'keydown', function ( event ) {
		if ( 'Escape' !== event.key ) {
			return;
		}
		const editor = document.querySelector( '[data-rating-editor].is-modal:not([hidden])' );
		closeEditor( editor );
	} );

	document.addEventListener( 'submit', async function ( event ) {
		const form = event.target.closest( '[data-lesson-rating]' );
		if ( ! form ) {
			return;
		}
		event.preventDefault();
		const status = form.querySelector( '[data-rating-status]' );
		const body = new FormData( form );
		body.append( 'action', config.action );
		body.append( 'nonce', config.nonce );
		status.textContent = config.saving;
		status.classList.remove( 'is-error' );
		try {
			const response = await fetch( config.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				body: body
			} );
			const result = await response.json();
			if ( ! response.ok || ! result.success ) {
				throw new Error( result.data && result.data.message ? result.data.message : config.failed );
			}
			status.textContent = result.data.message || config.saved;
			const recordId = form.querySelector( '[name="booking_id"]' ).value;
			const summaries = document.querySelectorAll( '[data-rating-summary][data-rating-record="' + recordId + '"]' );
			const editors = document.querySelectorAll( '[data-rating-editor][data-rating-record="' + recordId + '"]' );
			const rating = parseInt( result.data.rating, 10 ) || 0;
			const comment = result.data.comment || '';

			Array.prototype.forEach.call( summaries, function ( summary ) {
				const stars = summary.querySelector( '[data-rating-summary-stars]' );
				const commentElement = summary.querySelector( '[data-rating-summary-comment]' );
				const summaryStatus = summary.querySelector( '[data-rating-summary-status]' );
				if ( stars ) {
					stars.textContent = '★'.repeat( rating ) + '☆'.repeat( Math.max( 0, 5 - rating ) );
					stars.setAttribute( 'aria-label', starLabel( rating ) );
				}
				if ( commentElement ) {
					commentElement.textContent = comment;
					commentElement.hidden = ! comment;
				}
				if ( summaryStatus ) {
					summaryStatus.textContent = result.data.message || config.saved;
				}
				summary.hidden = false;
			} );
			Array.prototype.forEach.call( editors, function ( ratingEditor ) {
				const selectedRating = ratingEditor.querySelector( 'input[name="rating"][value="' + rating + '"]' );
				const commentField = ratingEditor.querySelector( 'textarea[name="comment"]' );
				ratingEditor.classList.add( 'is-modal' );
				if ( selectedRating ) {
					selectedRating.checked = true;
				}
				if ( commentField ) {
					commentField.value = comment;
				}
				const shell = ratingEditor.querySelector( '.tutorhelper-pro-lesson-rating-editor__shell' );
				if ( shell ) {
					shell.setAttribute( 'role', 'dialog' );
					shell.setAttribute( 'aria-modal', 'true' );
				}
				ratingEditor.hidden = true;
				moveModalToBody( ratingEditor );
			} );
			const button = form.querySelector( 'button[type="submit"]' );
			if ( button ) {
				button.textContent = config.update || 'Update rating';
			}
		} catch ( error ) {
			status.textContent = error.message || config.failed;
			status.classList.add( 'is-error' );
		}
	} );

	Array.prototype.forEach.call(
		document.querySelectorAll( '[data-rating-editor].is-modal' ),
		moveModalToBody
	);
}() );
