(function () {
	'use strict';

	if (typeof tutorhelperProFinancePayments === 'undefined') {
		return;
	}

	var config = tutorhelperProFinancePayments;
	var modal = null;
	var activeBookingIds = [];
	var selectedBookingIds = [];

	function initialise() {
		document
			.querySelectorAll('.tutorhelper-pro-finance-row')
			.forEach(enhanceRow);

		addBulkPaymentBar();
		document.addEventListener('click', handleClick);
		document.addEventListener('change', handleChange);
	}

	function enhanceRow(row) {
		var dueCell = row.querySelector('[data-finance-due-date]');
		if (!dueCell) {
			return;
		}

		var bookingId = String(dueCell.dataset.bookingId || '');
		var summary = config.bookings[bookingId];
		if (!summary) {
			return;
		}

		row.setAttribute('data-finance-payment-booking-id', bookingId);
		row.setAttribute('data-finance-payment-student-id', String(summary.studentUserId || ''));

		addSelectionControl(row, summary);

		var paymentMethodCell = dueCell.nextElementSibling;
		var paymentStatusCell = paymentMethodCell
			? paymentMethodCell.nextElementSibling
			: null;

		if (!paymentStatusCell) {
			return;
		}

		var existing = paymentStatusCell.querySelector(
			'[data-finance-payment-summary]'
		);
		if (existing) {
			existing.remove();
		}

		var panel = document.createElement('div');
		panel.className = 'tutorhelper-pro-finance-payment-summary';
		panel.setAttribute('data-finance-payment-summary', '');

		var balance = document.createElement('small');
		balance.className = 'tutorhelper-pro-finance-payment-summary__balance';
		balance.textContent = buildBalanceText(summary);
		panel.appendChild(balance);

		if (summary.canRecordPayment) {
			var button = document.createElement('button');
			button.type = 'button';
			button.className = 'button button-small tutorhelper-admin-button';
			button.setAttribute('data-finance-record-payment', bookingId);
			button.textContent = config.labels.recordPayment;
			panel.appendChild(button);
		}

		paymentStatusCell.appendChild(panel);
		renderTransactionRows(row, summary);
	}

	function addSelectionControl(row, summary) {
		var firstStudentCell = row.querySelector('td:nth-child(2)');
		if (!firstStudentCell) {
			return;
		}

		var existing = firstStudentCell.querySelector('[data-finance-payment-select]');
		if (existing) {
			existing.disabled = !summary.canRecordPayment;
			existing.checked = selectedBookingIds.indexOf(String(summary.bookingId)) >= 0;
			return;
		}

		var label = document.createElement('label');
		label.className = 'tutorhelper-pro-finance-payment-select';

		var checkbox = document.createElement('input');
		checkbox.type = 'checkbox';
		checkbox.setAttribute('data-finance-payment-select', String(summary.bookingId));
		checkbox.disabled = !summary.canRecordPayment;
		checkbox.setAttribute('aria-label', 'Select lesson for combined payment');

		label.appendChild(checkbox);
		firstStudentCell.insertBefore(label, firstStudentCell.firstChild);
	}

	function addBulkPaymentBar() {
		var wrap = document.querySelector('.tutorhelper-pro-finance-table-wrap');
		if (!wrap || document.querySelector('[data-finance-payment-bulk-bar]')) {
			return;
		}

		var bar = document.createElement('div');
		bar.className = 'tutorhelper-pro-finance-payment-bulk-bar';
		bar.setAttribute('data-finance-payment-bulk-bar', '');
		bar.hidden = true;
		bar.innerHTML =
			'<span data-finance-payment-bulk-summary></span>'
			+ '<button type="button" class="button tutorhelper-admin-button tutorhelper-admin-button--primary" data-finance-record-selected>'
			+ escapeHtml(config.labels.recordSelected)
			+ '</button>'
			+ '<button type="button" class="button tutorhelper-admin-button" data-finance-clear-selection>'
			+ escapeHtml(config.labels.cancel)
			+ '</button>';

		wrap.parentNode.insertBefore(bar, wrap);
	}

	function handleChange(event) {
		var checkbox = event.target.closest('[data-finance-payment-select]');
		if (!checkbox) {
			return;
		}

		var bookingId = String(checkbox.getAttribute('data-finance-payment-select') || '');
		var summary = config.bookings[bookingId];
		if (!summary) {
			checkbox.checked = false;
			return;
		}

		if (checkbox.checked) {
			var selectedStudentId = getSelectedStudentId();
			if (selectedStudentId && String(summary.studentUserId) !== selectedStudentId) {
				checkbox.checked = false;
				window.alert(config.labels.sameStudent);
				return;
			}
			if (selectedBookingIds.indexOf(bookingId) < 0) {
				selectedBookingIds.push(bookingId);
			}
		} else {
			selectedBookingIds = selectedBookingIds.filter(function (id) {
				return id !== bookingId;
			});
		}

		updateBulkPaymentBar();
	}

	function getSelectedStudentId() {
		if (!selectedBookingIds.length) {
			return '';
		}
		var summary = config.bookings[selectedBookingIds[0]];
		return summary ? String(summary.studentUserId || '') : '';
	}

	function updateBulkPaymentBar() {
		var bar = document.querySelector('[data-finance-payment-bulk-bar]');
		if (!bar) {
			return;
		}

		var validIds = selectedBookingIds.filter(function (bookingId) {
			return config.bookings[bookingId] && config.bookings[bookingId].canRecordPayment;
		});
		selectedBookingIds = validIds;

		bar.hidden = !selectedBookingIds.length;
		var summary = bar.querySelector('[data-finance-payment-bulk-summary]');
		if (summary) {
			summary.textContent = selectedBookingIds.length
			+ ' '
			+ config.labels.selectedCount;
		}
	}

	function buildBalanceText(summary) {
		if (Number(summary.outstandingMinorUnits || 0) <= 0) {
			return config.labels.paidInFull;
		}

		if (Number(summary.settledMinorUnits || 0) <= 0) {
			return summary.outstandingLabel + ' ' + config.labels.remaining;
		}

		return summary.settledLabel
			+ ' / '
			+ summary.priceLabel
			+ ' · '
			+ summary.outstandingLabel
			+ ' '
			+ config.labels.remaining;
	}

	function renderTransactionRows(bookingRow, summary) {
		var bookingId = String(summary.bookingId || '');
		document
			.querySelectorAll(
				'.tutorhelper-pro-finance-payment-entry[data-payment-booking-id="'
				+ bookingId
				+ '"]'
			)
			.forEach(function (entry) {
				entry.remove();
			});

		var insertionPoint = bookingRow;
		(summary.transactions || []).forEach(function (transaction) {
			var entry = document.createElement('tr');
			entry.className = 'tutorhelper-pro-finance-payment-entry';
			entry.setAttribute('data-payment-booking-id', bookingId);

			var indicator = document.createElement('td');
			indicator.className = 'tutorhelper-pro-finance-table__indicator';
			entry.appendChild(indicator);

			var details = document.createElement('td');
			details.colSpan = 3;
			details.innerHTML = '<strong>'
				+ escapeHtml(transaction.label || '')
				+ '</strong><br><small>'
				+ escapeHtml(transaction.date || '')
				+ (transaction.description
					? ' · ' + escapeHtml(transaction.description)
					: '')
				+ '</small>';
			entry.appendChild(details);

			var amount = document.createElement('td');
			amount.innerHTML = '<strong>'
				+ escapeHtml(transaction.amount || '')
				+ '</strong>';
			entry.appendChild(amount);

			var remainder = document.createElement('td');
			remainder.colSpan = 4;
			entry.appendChild(remainder);

			insertionPoint.insertAdjacentElement('afterend', entry);
			insertionPoint = entry;
		});
	}

	function handleClick(event) {
		var recordButton = event.target.closest('[data-finance-record-payment]');
		if (recordButton) {
			var clickedBookingId = String(
				recordButton.getAttribute('data-finance-record-payment') || ''
			);

			if (
				selectedBookingIds.length > 1
				&& selectedBookingIds.indexOf(clickedBookingId) >= 0
			) {
				openModal(selectedBookingIds.slice());
			} else {
				openModal([clickedBookingId]);
			}
			return;
		}

		if (event.target.closest('[data-finance-record-selected]')) {
			openModal(selectedBookingIds.slice());
			return;
		}

		if (event.target.closest('[data-finance-clear-selection]')) {
			clearSelection();
			return;
		}

		if (event.target.closest('[data-finance-payment-cancel]')) {
			closeModal();
			return;
		}

		if (event.target.closest('[data-finance-payment-save]')) {
			savePayment();
		}
	}

	function clearSelection() {
		selectedBookingIds = [];
		document.querySelectorAll('[data-finance-payment-select]').forEach(function (checkbox) {
			checkbox.checked = false;
		});
		updateBulkPaymentBar();
	}

	function ensureModal() {
		if (modal) {
			return modal;
		}

		modal = document.createElement('div');
		modal.className = 'tutorhelper-pro-finance-payment-modal';
		modal.hidden = true;
		modal.innerHTML =
			'<div class="tutorhelper-pro-finance-payment-modal__backdrop" data-finance-payment-cancel></div>'
			+ '<div class="tutorhelper-pro-finance-payment-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="tutorhelper-finance-payment-heading">'
			+ '<h2 id="tutorhelper-finance-payment-heading" data-finance-payment-heading></h2>'
			+ '<p class="tutorhelper-pro-finance-payment-modal__summary" data-finance-payment-modal-summary></p>'
			+ '<div class="tutorhelper-pro-finance-payment-allocations" data-finance-payment-allocations></div>'
			+ '<label><span>' + escapeHtml(config.labels.date) + '</span><input type="date" max="' + escapeHtml(config.today) + '" data-finance-payment-date class="tutorhelper-admin-control"></label>'
			+ '<label><span>' + escapeHtml(config.labels.entryType) + '</span><select data-finance-payment-type class="tutorhelper-admin-control"><option value="payment">' + escapeHtml(config.labels.payment) + '</option><option value="deposit">' + escapeHtml(config.labels.deposit) + '</option></select></label>'
			+ '<label><span>' + escapeHtml(config.labels.manualPaymentType) + '</span><select data-finance-manual-payment-type class="tutorhelper-admin-control"><option value="cash">' + escapeHtml(config.labels.cash) + '</option><option value="bank_transfer">' + escapeHtml(config.labels.bankTransfer) + '</option><option value="external_card">' + escapeHtml(config.labels.externalCard) + '</option><option value="other">' + escapeHtml(config.labels.other) + '</option></select></label>'
			+ '<label><span>' + escapeHtml(config.labels.notes) + '</span><textarea rows="3" data-finance-payment-notes class="tutorhelper-admin-control"></textarea></label>'
			+ '<p class="tutorhelper-pro-finance-payment-modal__message" data-finance-payment-message hidden></p>'
			+ '<div class="tutorhelper-pro-finance-payment-modal__actions"><button type="button" class="button tutorhelper-admin-button tutorhelper-admin-button--primary" data-finance-payment-save>' + escapeHtml(config.labels.save) + '</button><button type="button" class="button tutorhelper-admin-button" data-finance-payment-cancel>' + escapeHtml(config.labels.cancel) + '</button></div>'
			+ '</div>';

		document.body.appendChild(modal);
		return modal;
	}

	function openModal(bookingIds) {
		var summaries = bookingIds
			.map(function (bookingId) {
				return config.bookings[String(bookingId)];
			})
			.filter(function (summary) {
				return summary && summary.canRecordPayment;
			});

		if (!summaries.length) {
			return;
		}

		var studentId = String(summaries[0].studentUserId || '');
		if (summaries.some(function (summary) {
			return String(summary.studentUserId || '') !== studentId;
		})) {
			window.alert(config.labels.sameStudent);
			return;
		}

		activeBookingIds = summaries.map(function (summary) {
			return String(summary.bookingId);
		});

		var dialog = ensureModal();
		dialog.hidden = false;
		dialog.querySelector('[data-finance-payment-heading]').textContent =
			activeBookingIds.length > 1 ? config.labels.groupHeading : config.labels.heading;

		var totalMinor = summaries.reduce(function (total, summary) {
			return total + Number(summary.outstandingMinorUnits || 0);
		}, 0);
		var currency = summaries[0].currency;

		dialog.querySelector('[data-finance-payment-modal-summary]').textContent =
			summaries[0].studentName
			+ ' · '
			+ activeBookingIds.length
			+ ' '
			+ config.labels.selectedCount
			+ ' · '
			+ config.labels.total
			+ ': '
			+ formatMinorUnits(totalMinor, currency);

		var allocations = dialog.querySelector('[data-finance-payment-allocations]');
		allocations.innerHTML = '';
		summaries.forEach(function (summary) {
			var item = document.createElement('label');
			item.className = 'tutorhelper-pro-finance-payment-allocation';
			item.innerHTML =
				'<span><strong>' + escapeHtml(summary.lessonLabel || '') + '</strong><small>'
				+ escapeHtml(summary.outstandingLabel || '') + ' ' + escapeHtml(config.labels.remaining)
				+ '</small></span>'
				+ '<input type="number" min="0.01" step="0.01" class="tutorhelper-admin-control" data-finance-payment-allocation="'
				+ escapeHtml(String(summary.bookingId))
				+ '" value="'
				+ escapeHtml(minorUnitsToMajor(summary.outstandingMinorUnits, summary.currency))
				+ '">';
			allocations.appendChild(item);
		});

		dialog.querySelector('[data-finance-payment-date]').value = config.today;
		dialog.querySelector('[data-finance-payment-type]').value = 'payment';
		dialog.querySelector('[data-finance-manual-payment-type]').value = 'bank_transfer';
		dialog.querySelector('[data-finance-payment-notes]').value = '';
		var message = dialog.querySelector('[data-finance-payment-message]');
		message.hidden = true;
		message.textContent = '';
		var firstInput = allocations.querySelector('[data-finance-payment-allocation]');
		if (firstInput) {
			firstInput.focus();
		}
	}

	function closeModal() {
		if (modal) {
			modal.hidden = true;
		}
		activeBookingIds = [];
	}

	function savePayment() {
		if (!modal || !activeBookingIds.length) {
			return;
		}

		var allocations = activeBookingIds.map(function (bookingId) {
			var input = modal.querySelector('[data-finance-payment-allocation="' + bookingId + '"]');
			return {
				bookingId: bookingId,
				amount: input ? input.value : ''
			};
		}).filter(function (allocation) {
			return Number(allocation.amount || 0) > 0;
		});

		if (!allocations.length) {
			return;
		}

		var saveButton = modal.querySelector('[data-finance-payment-save]');
		var message = modal.querySelector('[data-finance-payment-message]');
		var paymentDate = modal.querySelector('[data-finance-payment-date]').value;
		var paymentType = modal.querySelector('[data-finance-payment-type]').value;
		var manualPaymentType = modal.querySelector('[data-finance-manual-payment-type]').value;
		var notes = modal.querySelector('[data-finance-payment-notes]').value;
		var batchReference = activeBookingIds.length > 1
			? 'TH-' + Date.now().toString(36).toUpperCase()
			: '';

		saveButton.disabled = true;
		saveButton.textContent = config.labels.saving;
		message.hidden = false;
		message.textContent = config.labels.saving;

		var chain = Promise.resolve();
		allocations.forEach(function (allocation) {
			chain = chain.then(function () {
				return recordAllocation(
					allocation,
					paymentDate,
					paymentType,
					manualPaymentType,
					notes,
					batchReference
				);
			});
		});

		chain
			.then(function () {
				message.textContent = config.labels.refreshing;
				clearSelection();
				return refreshFinanceSection();
			})
			.then(function () {
				closeModal();
			})
			.catch(function (error) {
				message.textContent = error.message;
				message.hidden = false;
			})
			.finally(function () {
				saveButton.disabled = false;
				saveButton.textContent = config.labels.save;
			});
	}

	function recordAllocation(allocation, paymentDate, paymentType, manualPaymentType, notes, batchReference) {
		var formData = new FormData();
		formData.append('action', config.action);
		formData.append('nonce', config.nonce);
		formData.append('booking_id', allocation.bookingId);
		formData.append('amount', allocation.amount);
		formData.append('payment_date', paymentDate);
		formData.append('payment_type', paymentType);
		formData.append('manual_payment_type', manualPaymentType);
		formData.append('notes', notes);
		formData.append('batch_reference', batchReference);

		return fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: formData
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (payload) {
				if (!payload || !payload.success) {
					throw new Error(
						payload && payload.data && payload.data.message
							? payload.data.message
							: config.labels.failed
					);
				}
				config.bookings[String(allocation.bookingId)] = payload.data;
				return payload.data;
			});
	}

	function refreshFinanceSection() {
		return fetch(window.location.href, {
			method: 'GET',
			credentials: 'same-origin',
			headers: {
				'X-Requested-With': 'XMLHttpRequest'
			}
		})
			.then(function (response) {
				if (!response.ok) {
					throw new Error(config.labels.failed);
				}
				return response.text();
			})
			.then(function (html) {
				var parser = new DOMParser();
				var documentCopy = parser.parseFromString(html, 'text/html');
				var currentSection = document.querySelector('.tutorhelper-pro-finance .tutorhelper-main-section');
				var freshSection = documentCopy.querySelector('.tutorhelper-pro-finance .tutorhelper-main-section');
				if (!currentSection || !freshSection) {
					throw new Error(config.labels.failed);
				}

				currentSection.replaceWith(freshSection);
				config.bookings = extractFreshBookingSummaries(freshSection);
				freshSection.querySelectorAll('.tutorhelper-pro-finance-row').forEach(enhanceRow);
				addBulkPaymentBar();
			});
	}

	function extractFreshBookingSummaries(section) {
		var summaries = config.bookings || {};
		section.querySelectorAll('[data-finance-due-date]').forEach(function (dueCell) {
			var bookingId = String(dueCell.dataset.bookingId || '');
			if (!bookingId || !summaries[bookingId]) {
				return;
			}
			var row = dueCell.closest('.tutorhelper-pro-finance-row');
			if (!row) {
				return;
			}
			var cells = row.querySelectorAll('td');
			if (cells.length >= 9) {
				summaries[bookingId].paymentStatus = cells[7].textContent.trim().toLowerCase().replace(/\s+/g, '_');
				summaries[bookingId].bookingStatus = cells[8].textContent.trim().toLowerCase().replace(/\s+/g, '_');
			}
		});
		return summaries;
	}

	function minorUnitsToMajor(amount, currency) {
		var zeroDecimal = [
			'BIF', 'CLP', 'DJF', 'GNF', 'ISK', 'JPY', 'KMF',
			'KRW', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF',
			'XOF', 'XPF'
		];
		var divisor = zeroDecimal.indexOf(String(currency || '').toUpperCase()) >= 0
			? 1
			: 100;
		return (Number(amount || 0) / divisor).toFixed(divisor === 1 ? 0 : 2);
	}

	function formatMinorUnits(amount, currency) {
		var summary = Object.keys(config.bookings).map(function (key) {
			return config.bookings[key];
		}).find(function (item) {
			return item.currency === currency && Number(item.outstandingMinorUnits) === Number(amount);
		});
		if (summary) {
			return summary.outstandingLabel;
		}
		var symbol = currency === 'GBP' ? '£' : currency + ' ';
		return symbol + minorUnitsToMajor(amount, currency);
	}

	function escapeHtml(value) {
		var element = document.createElement('div');
		element.textContent = String(value || '');
		return element.innerHTML;
	}

	window.addEventListener('load', initialise);
})();
