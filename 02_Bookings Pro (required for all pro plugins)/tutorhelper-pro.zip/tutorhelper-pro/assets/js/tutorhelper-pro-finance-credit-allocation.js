(function () {
	'use strict';

	if (typeof tutorhelperProFinanceCreditAllocation === 'undefined') {
		return;
	}

	var config = tutorhelperProFinanceCreditAllocation;
	var modal;
	var preview;
	var operationId = '';

	function init() {
		document.addEventListener('click', handleClick);
		enhanceRows();
		addBulkAction();
	}

	function enhanceRows() {
		document.querySelectorAll('.tutorhelper-pro-finance-row').forEach(function (row) {
			var dueCell = row.querySelector('[data-finance-due-date][data-booking-id]');
			if (!dueCell || row.querySelector('[data-finance-apply-credit]')) {
				return;
			}

			var statusCell = dueCell.nextElementSibling;
			statusCell = statusCell ? statusCell.nextElementSibling : null;
			if (!statusCell) {
				return;
			}

			var button = document.createElement('button');
			button.type = 'button';
			button.className = 'button button-small tutorhelper-admin-button';
			button.setAttribute('data-finance-apply-credit', dueCell.dataset.bookingId);
			button.textContent = config.labels.applyCredit;
			statusCell.appendChild(button);
		});
	}

	function addBulkAction() {
		var paymentBar = document.querySelector('[data-finance-payment-bulk-bar]');
		if (!paymentBar || paymentBar.querySelector('[data-finance-apply-selected-credit]')) {
			return;
		}

		var button = document.createElement('button');
		button.type = 'button';
		button.className = 'button tutorhelper-admin-button';
		button.setAttribute('data-finance-apply-selected-credit', '');
		button.textContent = config.labels.applyCredit;
		paymentBar.insertBefore(button, paymentBar.lastElementChild);
	}

	function handleClick(event) {
		var single = event.target.closest('[data-finance-apply-credit]');
		if (single) {
			var singleId = String(single.getAttribute('data-finance-apply-credit') || '');
			var selected = selectedBookingIds();
			openAllocation(
				selected.length > 1 && selected.indexOf(singleId) >= 0
					? selected
					: [singleId]
			);
			return;
		}

		if (event.target.closest('[data-finance-apply-selected-credit]')) {
			openAllocation(selectedBookingIds());
			return;
		}

		if (event.target.closest('[data-credit-allocation-close]')) {
			closeModal();
			return;
		}

		if (event.target.closest('[data-credit-allocation-confirm]')) {
			applyAllocation();
		}
	}

	function selectedBookingIds() {
		return Array.prototype.map.call(
			document.querySelectorAll('[data-finance-payment-select]:checked'),
			function (input) {
				return String(input.getAttribute('data-finance-payment-select') || '');
			}
		).filter(Boolean);
	}

	function openAllocation(ids) {
		ids = ids.filter(Boolean);
		if (!ids.length) {
			return;
		}

		var dialog = ensureModal();
		dialog.hidden = false;
		setMessage(config.labels.loading, false);
		dialog.querySelector('[data-credit-allocation-list]').innerHTML = '';
		dialog.querySelector('[data-credit-allocation-confirm]').disabled = true;
		operationId = createOperationId();

		request(config.previewAction, ids)
			.then(function (data) {
				preview = data;
				renderPreview();
				dialog.querySelector('[data-credit-allocation-confirm]').disabled = false;
				var first = dialog.querySelector('[data-credit-allocation-amount]');
				if (first) {
					first.focus();
				}
			})
			.catch(function (error) {
				setMessage(error.message || config.labels.failed, true);
			});
	}

	function ensureModal() {
		if (modal) {
			return modal;
		}

		modal = document.createElement('div');
		modal.className = 'tutorhelper-pro-credit-allocation-modal';
		modal.hidden = true;
		modal.innerHTML =
			'<div class="tutorhelper-pro-credit-allocation-modal__backdrop" data-credit-allocation-close></div>'
			+ '<div class="tutorhelper-pro-credit-allocation-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="tutorhelper-credit-allocation-title">'
			+ '<h2 id="tutorhelper-credit-allocation-title">' + escapeHtml(config.labels.heading) + '</h2>'
			+ '<p data-credit-allocation-student></p>'
			+ '<div class="tutorhelper-pro-credit-allocation-modal__totals" data-credit-allocation-totals></div>'
			+ '<div class="tutorhelper-pro-credit-allocation-modal__list" data-credit-allocation-list></div>'
			+ '<p class="tutorhelper-pro-credit-allocation-modal__message" data-credit-allocation-message role="status"></p>'
			+ '<div class="tutorhelper-pro-credit-allocation-modal__actions">'
			+ '<button type="button" class="button tutorhelper-admin-button tutorhelper-admin-button--primary" data-credit-allocation-confirm>' + escapeHtml(config.labels.confirm) + '</button>'
			+ '<button type="button" class="button tutorhelper-admin-button" data-credit-allocation-close>' + escapeHtml(config.labels.cancel) + '</button>'
			+ '</div></div>';

		modal.addEventListener('input', function (event) {
			if (event.target.matches('[data-credit-allocation-amount]')) {
				updatePreviewFromInputs();
			}
		});
		document.body.appendChild(modal);
		return modal;
	}

	function renderPreview() {
		if (!preview || !modal) {
			return;
		}

		modal.querySelector('[data-credit-allocation-student]').textContent = preview.studentName || '';
		var list = modal.querySelector('[data-credit-allocation-list]');
		list.innerHTML = '';

		Object.keys(preview.allocations || {}).forEach(function (bookingId) {
			var allocation = preview.allocations[bookingId];
			var row = document.createElement('div');
			row.className = 'tutorhelper-pro-credit-allocation-row';
			row.innerHTML =
				'<div><strong>' + escapeHtml(allocation.lessonLabel || '') + '</strong>'
				+ '<span>' + escapeHtml(config.labels.originalPrice) + ': ' + escapeHtml(format(allocation.originalPriceMinorUnits, preview.currency)) + '</span>'
				+ '<span>' + escapeHtml(config.labels.alreadyPaid) + ': ' + escapeHtml(format(allocation.settledMinorUnits, preview.currency)) + '</span>'
				+ '<span>' + escapeHtml(config.labels.outstanding) + ': ' + escapeHtml(format(allocation.outstandingMinorUnits, preview.currency)) + '</span>'
				+ '<span data-credit-allocation-row-remaining="' + escapeHtml(bookingId) + '"></span></div>'
				+ '<label><span>' + escapeHtml(config.labels.creditToApply) + '</span>'
				+ '<input type="number" min="0" step="' + escapeHtml(stepFor(preview.currency)) + '" class="tutorhelper-admin-control" data-credit-allocation-amount="' + escapeHtml(bookingId) + '" value="' + escapeHtml(toMajor(allocation.amountMinorUnits, preview.currency)) + '"></label>';
			list.appendChild(row);
		});

		updatePreviewFromInputs();
	}

	function updatePreviewFromInputs() {
		if (!preview || !modal) {
			return;
		}

		var total = 0;
		Object.keys(preview.allocations || {}).forEach(function (bookingId) {
			var allocation = preview.allocations[bookingId];
			var input = modal.querySelector('[data-credit-allocation-amount="' + cssEscape(bookingId) + '"]');
			var amount = input ? toMinor(input.value, preview.currency) : 0;
			amount = Math.max(0, amount);
			total += amount;
			var remaining = Math.max(0, Number(allocation.outstandingMinorUnits || 0) - amount);
			var remainingNode = modal.querySelector('[data-credit-allocation-row-remaining="' + cssEscape(bookingId) + '"]');
			if (remainingNode) {
				remainingNode.textContent = config.labels.remaining + ': ' + format(remaining, preview.currency);
			}
			if (input) {
				input.setAttribute('aria-invalid', amount > Number(allocation.outstandingMinorUnits || 0) ? 'true' : 'false');
			}
		});

		var remainingCredit = Number(preview.availableCreditMinorUnits || 0) - total;
		modal.querySelector('[data-credit-allocation-totals]').innerHTML =
			'<span><strong>' + escapeHtml(config.labels.studentCredit) + '</strong>' + escapeHtml(format(preview.availableCreditMinorUnits, preview.currency)) + '</span>'
			+ '<span><strong>' + escapeHtml(config.labels.remainingCredit) + '</strong>' + escapeHtml(format(Math.max(0, remainingCredit), preview.currency)) + '</span>';

		var invalid = total <= 0 || remainingCredit < 0
			|| Array.prototype.some.call(
				modal.querySelectorAll('[data-credit-allocation-amount]'),
				function (input) {
					var allocation = preview.allocations[input.getAttribute('data-credit-allocation-amount')];
					return toMinor(input.value, preview.currency) > Number(allocation.outstandingMinorUnits || 0);
				}
			);

		modal.querySelector('[data-credit-allocation-confirm]').disabled = invalid;
		if (invalid) {
			setMessage(config.labels.noCredit, true);
		} else {
			setMessage('', false);
		}
	}

	function applyAllocation() {
		if (!preview || !modal) {
			return;
		}

		var ids = Object.keys(preview.allocations || {});
		var allocations = {};
		ids.forEach(function (bookingId) {
			var input = modal.querySelector('[data-credit-allocation-amount="' + cssEscape(bookingId) + '"]');
			allocations[bookingId] = Math.max(0, toMinor(input ? input.value : '0', preview.currency));
		});

		var button = modal.querySelector('[data-credit-allocation-confirm]');
		button.disabled = true;
		setMessage(config.labels.applying, false);

		request(config.applyAction, ids, allocations, operationId)
			.then(function (data) {
				setMessage(data.message || config.labels.refreshing, false);
				window.location.reload();
			})
			.catch(function (error) {
				setMessage(error.message || config.labels.failed, true);
				button.disabled = false;
			});
	}

	function request(action, ids, allocations, id) {
		var form = new FormData();
		form.append('action', action);
		form.append('nonce', config.nonce);
		ids.forEach(function (bookingId) {
			form.append('booking_ids[]', bookingId);
		});
		Object.keys(allocations || {}).forEach(function (bookingId) {
			form.append('allocations[' + bookingId + ']', String(allocations[bookingId]));
		});
		if (id) {
			form.append('operation_id', id);
		}

		return fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: form
		}).then(function (response) {
			return response.json();
		}).then(function (payload) {
			if (!payload || !payload.success) {
				throw new Error(
					payload && payload.data && payload.data.message
						? payload.data.message
						: config.labels.failed
				);
			}
			return payload.data;
		});
	}

	function closeModal() {
		if (modal) {
			modal.hidden = true;
		}
		preview = null;
	}

	function setMessage(message, isError) {
		if (!modal) {
			return;
		}
		var node = modal.querySelector('[data-credit-allocation-message]');
		node.textContent = message || '';
		node.classList.toggle('is-error', Boolean(isError));
	}

	function createOperationId() {
		if (window.crypto && typeof window.crypto.randomUUID === 'function') {
			return window.crypto.randomUUID().toLowerCase();
		}
		return 'credit-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 14);
	}

	function zeroDecimal(currency) {
		return ['BIF', 'CLP', 'DJF', 'GNF', 'ISK', 'JPY', 'KMF', 'KRW', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'].indexOf(String(currency || '').toUpperCase()) >= 0;
	}

	function toMinor(value, currency) {
		var number = Number(String(value || '').replace(',', '.'));
		if (!Number.isFinite(number)) {
			return 0;
		}
		return Math.round(number * (zeroDecimal(currency) ? 1 : 100));
	}

	function toMajor(amount, currency) {
		var divisor = zeroDecimal(currency) ? 1 : 100;
		return (Number(amount || 0) / divisor).toFixed(divisor === 1 ? 0 : 2);
	}

	function stepFor(currency) {
		return zeroDecimal(currency) ? '1' : '0.01';
	}

	function format(amount, currency) {
		try {
			return new Intl.NumberFormat(undefined, {
				style: 'currency',
				currency: currency
			}).format(Number(amount || 0) / (zeroDecimal(currency) ? 1 : 100));
		} catch (error) {
			return String(currency || '') + ' ' + toMajor(amount, currency);
		}
	}

	function cssEscape(value) {
		return window.CSS && window.CSS.escape
			? window.CSS.escape(String(value))
			: String(value).replace(/"/g, '\\"');
	}

	function escapeHtml(value) {
		var node = document.createElement('div');
		node.textContent = String(value || '');
		return node.innerHTML;
	}

	window.addEventListener('load', init);
})();
