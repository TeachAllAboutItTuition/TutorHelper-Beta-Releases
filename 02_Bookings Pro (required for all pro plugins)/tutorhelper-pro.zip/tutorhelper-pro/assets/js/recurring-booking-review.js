(function () {
	'use strict';

	function initialiseRecurringReview() {
		const form = document.querySelector('.tutorhelper-tutor-booking__form');
		const panel = document.querySelector('[data-tutorhelper-pro-recurring-review]');

		if (!form || !panel) {
			return;
		}

		const scopeInputs = form.querySelectorAll(
			'[name="tutorhelper_pro_recurring_edit_scope"]'
		);
		const date = form.querySelector('[name="booking_date"]');
		const start = form.querySelector('[name="start_time"]');
		const end = form.querySelector('[name="end_time"]');
		const bookingType = form.querySelector('[name="booking_type_id"]');
		const location = form.querySelector('[name="location_type"]');
		const timezone = form.querySelector('[name="timezone"]');
		let request = null;
		let timer = null;

		function futureScopeSelected() {
			const selected = form.querySelector(
				'[name="tutorhelper_pro_recurring_edit_scope"]:checked'
			);

			return selected && selected.value === 'future';
		}

		function setPanelVisible() {
			panel.hidden = !futureScopeSelected();
		}

		function refreshReview() {
			if (!futureScopeSelected() || !date || !start || !end || !date.value || !start.value || !end.value) {
				return;
			}

			if (request) {
				request.abort();
			}

			const data = new URLSearchParams({
				action: 'tutorhelper_pro_recurring_booking_review',
				nonce: panel.dataset.nonce || '',
				booking_id: panel.dataset.bookingId || '',
				booking_date: date.value,
				start_time: start.value,
				end_time: end.value,
				booking_type_id: bookingType ? bookingType.value : '',
				location_type: location ? location.value : '',
				timezone: timezone ? timezone.value : ''
			});

			panel.setAttribute('aria-busy', 'true');
			request = new AbortController();

			fetch(panel.dataset.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
				},
				body: data.toString(),
				signal: request.signal
			})
				.then(function (response) {
					return response.json();
				})
				.then(function (response) {
					if (!response || !response.success || !response.data) {
						return;
					}

					panel.innerHTML = response.data.html || '';
				})
				.catch(function (error) {
					if (error.name !== 'AbortError') {
						window.console.warn('TutorHelper: recurring lesson review could not be refreshed.', error);
					}
				})
				.finally(function () {
					panel.removeAttribute('aria-busy');
					request = null;
				});
		}

		function scheduleRefresh() {
			window.clearTimeout(timer);
			timer = window.setTimeout(refreshReview, 300);
		}

		scopeInputs.forEach(function (input) {
			input.addEventListener('change', function () {
				setPanelVisible();

				if (futureScopeSelected()) {
					scheduleRefresh();
				}
			});
		});

		[date, start, end, bookingType, location].forEach(function (input) {
			if (!input) {
				return;
			}

			input.addEventListener('change', scheduleRefresh);
			input.addEventListener('input', scheduleRefresh);
		});

		setPanelVisible();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initialiseRecurringReview);
	} else {
		initialiseRecurringReview();
	}
}());
