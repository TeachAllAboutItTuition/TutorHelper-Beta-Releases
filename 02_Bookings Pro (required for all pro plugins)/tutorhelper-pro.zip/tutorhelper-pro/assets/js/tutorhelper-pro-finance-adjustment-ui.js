(function () {
	'use strict';

	if (typeof tutorhelperProFinanceAdjustmentUI === 'undefined') {
		return;
	}

	var config = tutorhelperProFinanceAdjustmentUI;
	var modal = null;

	function initialise() {
		document
			.querySelectorAll('.tutorhelper-pro-finance-row')
			.forEach(enhanceRow);

		document.addEventListener('click', handleClick);
	}

	function enhanceRow(row) {
		var dueCell = row.querySelector('[data-finance-due-date]');
		if (!dueCell) {
			return;
		}

		var bookingId = String(dueCell.dataset.bookingId || '');
		var summary = config.bookings[bookingId];
		if (!summary) {
			return;
		}

		var paymentMethodCell = dueCell.nextElementSibling;
		var paymentStatusCell = paymentMethodCell
			? paymentMethodCell.nextElementSibling
			: null;

		if (!paymentStatusCell || paymentStatusCell.querySelector('[data-finance-adjustment-button]')) {
			return;
		}

		var button = document.createElement('button');
		button.type = 'button';
		button.className = 'button button-small tutorhelper-admin-button tutorhelper-pro-finance-adjustment-row-button';
		button.setAttribute('data-finance-adjustment-button', bookingId);
		button.textContent = config.labels.button;
		paymentStatusCell.appendChild(button);
	}

	function ensureModal() {
		if (modal) {
			return modal;
		}

		modal = document.createElement('div');
		modal.className = 'tutorhelper-pro-finance-adjustment-modal';
		modal.hidden = true;
		modal.innerHTML =
			'<div class="tutorhelper-pro-finance-adjustment-modal__backdrop" data-finance-adjustment-close></div>'
			+ '<div class="tutorhelper-pro-finance-adjustment-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="tutorhelper-finance-adjustment-heading">'
			+ '<h2 id="tutorhelper-finance-adjustment-heading">' + escapeHtml(config.labels.heading) + '</h2>'
			+ '<p class="tutorhelper-pro-finance-adjustment-modal__summary" data-finance-adjustment-summary></p>'
			+ '<p><strong>' + escapeHtml(config.labels.refundable) + ':</strong> <span data-finance-adjustment-refundable></span></p>'
			+ '<form method="post" action="' + escapeHtml(config.actionUrl || '') + '" data-finance-adjustment-form>'
			+ '<input type="hidden" name="action" value="' + escapeHtml(config.action || '') + '">'
			+ '<input type="hidden" name="booking_id" data-finance-adjustment-booking-id>'
			+ '<input type="hidden" name="_wpnonce" value="' + escapeHtml(config.nonce || '') + '">'
			+ '<label><span>' + escapeHtml(config.labels.action) + '</span><select name="adjustment_type" data-finance-adjustment-type class="tutorhelper-admin-control">'
			+ '<option value="credit">' + escapeHtml(config.labels.credit) + '</option>'
			+ '<option value="refund_external">' + escapeHtml(config.labels.externalRefund) + '</option>'
			+ '<option value="refund_stripe">' + escapeHtml(config.labels.stripeRefund) + '</option>'
			+ '</select></label>'
			+ '<p class="description" data-finance-adjustment-description></p>'
			+ '<label><span>' + escapeHtml(config.labels.amount) + '</span><input name="amount" type="number" min="0.01" step="0.01" required class="tutorhelper-admin-control" data-finance-adjustment-amount></label>'
			+ '<label><span>' + escapeHtml(config.labels.notes) + '</span><textarea name="notes" rows="3" class="tutorhelper-admin-control"></textarea></label>'
			+ '<div class="tutorhelper-pro-finance-adjustment-modal__actions">'
			+ '<button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary">' + escapeHtml(config.labels.save) + '</button>'
			+ '<button type="button" class="button tutorhelper-admin-button" data-finance-adjustment-close>' + escapeHtml(config.labels.close) + '</button>'
			+ '</div>'
			+ '</form>'
			+ '</div>';

		document.body.appendChild(modal);
		modal.querySelector('[data-finance-adjustment-type]').addEventListener('change', updateTypeHelp);
		return modal;
	}

	function handleClick(event) {
		var button = event.target.closest('[data-finance-adjustment-button]');
		if (button) {
			openModal(String(button.getAttribute('data-finance-adjustment-button') || ''));
			return;
		}

		if (event.target.closest('[data-finance-adjustment-close]')) {
			closeModal();
		}
	}

	function openModal(bookingId) {
		var summary = config.bookings[bookingId];
		if (!summary) {
			return;
		}

		var dialog = ensureModal();
		dialog.querySelector('[data-finance-adjustment-booking-id]').value = bookingId;
		dialog.querySelector('[data-finance-adjustment-summary]').textContent = summary.studentName + ' · ' + summary.lessonLabel;
		dialog.querySelector('[data-finance-adjustment-refundable]').textContent = summary.refundableLabel;

		var amount = dialog.querySelector('[data-finance-adjustment-amount]');
		amount.max = toMajorUnits(summary.refundableMinorUnits);
		amount.value = '';

		var type = dialog.querySelector('[data-finance-adjustment-type]');
		var stripeOption = type.querySelector('option[value="refund_stripe"]');
		stripeOption.disabled = !summary.canStripeRefund;
		if (stripeOption.disabled && type.value === 'refund_stripe') {
			type.value = 'credit';
		}

		dialog.dataset.activeBookingId = bookingId;
		updateTypeHelp();
		dialog.hidden = false;
		amount.focus();
	}

	function updateTypeHelp() {
		if (!modal || modal.hidden) {
			return;
		}

		var bookingId = String(modal.dataset.activeBookingId || '');
		var summary = config.bookings[bookingId];
		if (!summary) {
			return;
		}

		var type = modal.querySelector('[data-finance-adjustment-type]').value;
		var help = modal.querySelector('[data-finance-adjustment-description]');
		var amount = modal.querySelector('[data-finance-adjustment-amount]');

		if (type === 'refund_stripe') {
			amount.max = toMajorUnits(summary.stripeRefundableMinorUnits);
			help.textContent = summary.canStripeRefund
				? config.labels.stripeRefundHelp
				: config.labels.stripeUnavailable;
			return;
		}

		amount.max = toMajorUnits(summary.refundableMinorUnits);
		help.textContent = type === 'refund_external'
			? config.labels.externalRefundHelp
			: config.labels.creditHelp;
	}

	function closeModal() {
		if (modal) {
			modal.hidden = true;
		}
	}

	function toMajorUnits(value) {
		return (Number(value || 0) / 100).toFixed(2);
	}

	function escapeHtml(value) {
		return String(value || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initialise);
	} else {
		initialise();
	}
}());
