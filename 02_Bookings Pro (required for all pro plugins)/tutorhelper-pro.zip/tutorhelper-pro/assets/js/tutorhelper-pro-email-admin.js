(function () {
	'use strict';

	const config =
		window.tutorhelperProEmailAdmin || {};

	const placeholderValues =
		config.placeholders || {};


	function replacePlaceholders(value) {

		let result =
			String(value || '');

		Object.keys(
			placeholderValues
		).forEach(
			function (placeholder) {

				result =
					result
						.split(placeholder)
						.join(
							placeholderValues[
								placeholder
							]
						);
			}
		);

		return result;
	}


	function getEditorContent(editorId) {

		if (
			window.tinymce
			&& window.tinymce.get(
				editorId
			)
		) {
			return window.tinymce
				.get(editorId)
				.getContent();
		}

		const textarea =
			document.querySelector(
				'#' + editorId
			);

		return textarea
			? textarea.value
			: '';
	}


	function updatePreview(preview) {

		if (!preview) {
			return;
		}

		const subjectId =
			preview.dataset
				.emailSubjectId;

		const editorId =
			preview.dataset
				.emailEditorId;

		const subjectField =
			subjectId
				? document.getElementById(
					subjectId
				)
				: null;

		const previewSubject =
			preview.querySelector(
				'[data-email-preview-subject]'
			);

		const previewBody =
			preview.querySelector(
				'[data-email-preview-body]'
			);

		if (
			subjectField
			&& previewSubject
		) {
			previewSubject.textContent =
				replacePlaceholders(
					subjectField.value
				);
		}

		if (
			editorId
			&& previewBody
		) {
			previewBody.innerHTML =
				replacePlaceholders(
					getEditorContent(
						editorId
					)
				);
		}
	}


	function connectPreview(preview) {

		const subjectId =
			preview.dataset
				.emailSubjectId;

		const editorId =
			preview.dataset
				.emailEditorId;

		const subjectField =
			subjectId
				? document.getElementById(
					subjectId
				)
				: null;

		if (subjectField) {
			subjectField.addEventListener(
				'input',
				function () {
					updatePreview(
						preview
					);
				}
			);
		}


		function connectEditor() {

			if (
				!editorId
				|| !window.tinymce
				|| !window.tinymce.get(
					editorId
				)
			) {
				window.setTimeout(
					connectEditor,
					100
				);

				return;
			}

			const editor =
				window.tinymce.get(
					editorId
				);

			editor.on(
				'input change keyup SetContent',
				function () {
					updatePreview(
						preview
					);
				}
			);

			updatePreview(
				preview
			);
		}


		connectEditor();

		updatePreview(
			preview
		);
	}


	document
		.querySelectorAll(
			'[data-email-preview]'
		)
		.forEach(
			connectPreview
		);


	document.addEventListener(
		'click',
		function (event) {

			const placeholderButton =
				event.target.closest(
					'[data-email-placeholder]'
				);

			if (!placeholderButton) {
				return;
			}

			const placeholder =
				placeholderButton.dataset
					.emailPlaceholder;

			const editorId =
				placeholderButton.dataset
					.emailEditor
				|| 'tutorhelper_pro_email_body';

			if (!placeholder) {
				return;
			}

			const editor =
				window.tinymce
					? window.tinymce.get(
						editorId
					)
					: null;

			if (editor) {

				editor.focus();

				editor.insertContent(
					placeholder
				);

				const preview =
					document.querySelector(
						'[data-email-preview]'
						+ '[data-email-editor-id="'
						+ editorId
						+ '"]'
					);

				updatePreview(
					preview
				);

				return;
			}

			const textarea =
				document.getElementById(
					editorId
				);

			if (textarea) {
				textarea.value +=
					placeholder;
			}
		}
	);


    const timingAmount =
        document.getElementById(
            'tutorhelper-pro-reminder-timing-amount'
        );

    const timingUnit =
        document.getElementById(
            'tutorhelper-pro-reminder-timing-unit'
        );

    const timingDirection =
        document.getElementById(
            'tutorhelper-pro-reminder-timing-direction'
        );

    const timingError =
        document.querySelector(
            '[data-reminder-timing-error]'
        );


    function timingInMinutes() {

        if (
            !timingAmount
            || !timingUnit
        ) {
            return 0;
        }

        const amount =
            parseInt(
                timingAmount.value,
                10
            ) || 0;

        switch (timingUnit.value) {

            case 'days':
                return amount * 1440;

            case 'hours':
                return amount * 60;

            case 'minutes':
            default:
                return amount;
        }
    }


    function validateReminderTiming() {

        if (
            !timingAmount
            || !timingUnit
            || !timingDirection
        ) {
            return true;
        }

        const isBefore =
            timingDirection.value === 'before';

        const usesMinutes =
            timingUnit.value === 'minutes';

        /*
        * When using minutes before a lesson, the HTML control
        * itself should reflect the actual minimum.
        */
        timingAmount.min =
            isBefore && usesMinutes
                ? '15'
                : '1';

        const invalid =
            isBefore
            && timingInMinutes() < 15;

        if (invalid) {

            timingAmount.setCustomValidity(
                'Before-lesson reminders must be scheduled at least 15 minutes before the lesson.'
            );

            timingAmount.setAttribute(
                'aria-invalid',
                'true'
            );

            if (timingError) {
                timingError.hidden = false;
            }

        } else {

            timingAmount.setCustomValidity(
                ''
            );

            timingAmount.removeAttribute(
                'aria-invalid'
            );

            if (timingError) {
                timingError.hidden = true;
            }
        }

        return !invalid;
    }


    [
        timingAmount,
        timingUnit,
        timingDirection,
    ].forEach(
        function (field) {

            if (!field) {
                return;
            }

            field.addEventListener(
                'change',
                validateReminderTiming
            );

            field.addEventListener(
                'input',
                validateReminderTiming
            );
        }
    );


    validateReminderTiming();

    const reminderForm =
        timingAmount
            ? timingAmount.closest(
                'form'
            )
            : null;


    if (reminderForm) {

        reminderForm.addEventListener(
            'submit',
            function (event) {

                if (
                    !validateReminderTiming()
                ) {
                    event.preventDefault();

                    timingAmount.reportValidity();

                    timingAmount.focus();
                }
            }
        );
    }


})();
