(function () {
	'use strict';

	var initialisedPaymentChoices = new WeakSet();

	function priceIsFree(priceLabel) {
		var label = String(priceLabel || '').trim().toLowerCase();
		if (!label || label.indexOf('free') !== -1) {
			return true;
		}

		var numericText = label.replace(/[^0-9.,-]/g, '').replace(/,/g, '');
		var numericValue = Number.parseFloat(numericText);
		return !Number.isNaN(numericValue) && numericValue <= 0;
	}

	function methodDetails(method, labels) {
		if ('stripe' === method) {
			return {
				title: labels.card || 'Pay by card',
				button: labels.bookAndPay || 'Book & Pay',
				note: ''
			};
		}
		if ('invoice' === method) {
			return {
				title: labels.invoice || 'Invoice',
				button: labels.bookAndInvoice || 'Book & Add To Invoice',
				note: labels.invoiceNote || ''
			};
		}
		return {
			title: labels.bank || 'Bank transfer',
			button: labels.requestLesson || 'Request lesson',
			note: labels.bankNote || ''
		};
	}

	function initialisePaymentChoices(container) {
		if (!container || initialisedPaymentChoices.has(container)) {
			return;
		}

		var configNode = container.querySelector('[data-tutorhelper-payment-methods]');
		var config = window.tutorhelperProPaymentMethods || {};
		if (configNode && configNode.dataset.paymentMethods) {
			try {
				config = JSON.parse(configNode.dataset.paymentMethods);
			} catch (error) {
				config = {};
			}
		}
		var methods = Array.isArray(config.methods) ? config.methods : [];
		var labels = config.labels || {};
		var form = container.querySelector('[data-booking-form]');
		var summary = container.querySelector('.tutorhelper-student-booking__summary');
		var submitButton = container.querySelector('[data-booking-submit]');
		var policy = summary && summary.querySelector('.tutorhelper-student-booking__policy');

		if (!form || !summary || !submitButton || !policy || !methods.length) {
			return;
		}

		/*
		 * The Parent Dashboard caches tab HTML but not JavaScript listeners.
		 * Remove any payment UI copied into that cached markup before creating
		 * the new interactive instance.
		 */
		container.querySelectorAll(
			'[data-tutorhelper-payment-choice], .tutorhelper-pro-payment-choice__note'
		).forEach(function (element) {
			element.remove();
		});

		initialisedPaymentChoices.add(container);
		var paymentChoice = document.createElement('div');
		paymentChoice.className = 'tutorhelper-pro-payment-choice';
		paymentChoice.setAttribute('data-tutorhelper-payment-choice', '');
		paymentChoice.hidden = true;

		var paymentNote = document.createElement('p');
		paymentNote.className = 'tutorhelper-pro-payment-choice__note';
		paymentNote.hidden = true;

		if (1 === methods.length) {
			paymentChoice.classList.add('tutorhelper-pro-payment-choice--single');
			paymentChoice.innerHTML =
				'<input type="hidden" name="tutorhelper_payment_method" value="'
				+ methods[0] + '" data-tutorhelper-booking-extension-field>';
		} else {
			var options = methods.map(function (method) {
				var detail = methodDetails(method, labels);
				return '<label><input type="radio" name="tutorhelper_payment_method" value="'
					+ method + '" data-tutorhelper-booking-extension-field><span><strong>'
					+ detail.title + '</strong></span></label>';
			}).join('');
			paymentChoice.innerHTML =
				'<h4>' + (labels.paymentMethod || 'Payment method') + '</h4>'
				+ '<p>' + (labels.choosePaymentMethod || '') + '</p>'
				+ '<div class="tutorhelper-pro-payment-choice__options">' + options + '</div>';
		}

		policy.insertAdjacentElement('afterend', paymentChoice);
		paymentChoice.insertAdjacentElement('afterend', paymentNote);

		function selectedMethod() {
			var selected = paymentChoice.querySelector('[name="tutorhelper_payment_method"]:checked');
			if (selected) {
				return selected.value;
			}
			var single = paymentChoice.querySelector('input[type="hidden"][name="tutorhelper_payment_method"]');
			return single && !single.disabled ? single.value : '';
		}

		function setPresentation() {
			var method = paymentChoice.hidden ? '' : selectedMethod();
			var detail = method ? methodDetails(method, labels) : null;
			submitButton.textContent = detail ? detail.button : (labels.requestLesson || 'Request lesson');
			paymentNote.textContent = detail ? detail.note : '';
			paymentNote.hidden = !detail || !detail.note;
			container.dispatchEvent(new CustomEvent('tutorhelper:booking-payment-method-changed'));
		}

		function setPaidState(isPaid) {
			paymentChoice.hidden = !isPaid;
			paymentNote.hidden = !isPaid;
			if (isPaid && methods.length > 1) {
				paymentChoice.setAttribute('data-tutorhelper-payment-required', '1');
			} else {
				paymentChoice.removeAttribute('data-tutorhelper-payment-required');
			}
			if (!isPaid) {
				paymentChoice.querySelectorAll('input[type="radio"]').forEach(function (input) {
					input.checked = false;
				});
				paymentChoice.querySelectorAll('input[type="hidden"]').forEach(function (input) {
					input.disabled = true;
				});
			} else {
				paymentChoice.querySelectorAll('input[type="hidden"]').forEach(function (input) {
					input.disabled = false;
				});
			}
			setPresentation();
		}

		paymentChoice.addEventListener('change', setPresentation);
		container.addEventListener('tutorhelper:booking-service-selected', function (event) {
			setPaidState(!priceIsFree(event.detail && event.detail.price));
		});
		setPresentation();
	}

	window.TutorHelperStudentPaymentMethodsInitialise = initialisePaymentChoices;
	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('[data-tutorhelper-student-booking]').forEach(initialisePaymentChoices);
	});
})();
