( function () {
	'use strict';

	var config = window.tutorhelperProProgressReports || {};

	function setLoading( form, isLoading ) {
		var button = form.querySelector( '[data-progress-report-build]' );
		var status = form.querySelector( '[data-progress-report-status]' );

		form.dataset.generatingReport = isLoading ? '1' : '';
		if ( isLoading ) {
			form.setAttribute( 'aria-busy', 'true' );
		} else {
			delete form.dataset.generatingReport;
			form.removeAttribute( 'aria-busy' );
		}

		if ( button ) {
			if ( ! button.dataset.defaultLabel ) {
				button.dataset.defaultLabel = button.textContent;
			}
			button.disabled = isLoading;
			button.classList.toggle( 'is-loading', isLoading );
			button.textContent = isLoading
				? ( button.dataset.loadingLabel || button.textContent )
				: ( button.dataset.defaultLabel || button.textContent );
		}

		if ( status ) {
			status.hidden = ! isLoading;
		}
	}

	document.addEventListener( 'submit', function ( event ) {
		var form = event.target.closest( '.tutorhelper-progress-reports__form' );
		var region;
		var body;

		if ( ! form || '1' === form.dataset.generatingReport ) {
			return;
		}

		if ( ! config.ajaxUrl || ! config.action || ! window.fetch || ! window.FormData ) {
			return;
		}

		event.preventDefault();

		if ( window.tinyMCE && window.tinyMCE.triggerSave ) {
			window.tinyMCE.triggerSave();
		}

		region = form.closest( '.tutorhelper-progress-reports' )
			.querySelector( '[data-progress-report-preview]' );
		body = new window.FormData( form );
		body.set( 'action', config.action );

		setLoading( form, true );

		window.fetch( config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		} ).then( function ( response ) {
			return response.json();
		} ).then( function ( response ) {
			if ( ! response.success || ! response.data || ! response.data.html ) {
				throw new Error(
					response && response.data && response.data.message
						? response.data.message
						: config.errorText
				);
			}

			if ( region ) {
				region.innerHTML = response.data.html;
				region.focus();
			}
		} ).catch( function ( error ) {
			if ( region ) {
				region.innerHTML = '<div class="notice notice-error" role="alert"><p>'
					+ ( error && error.message ? error.message : config.errorText )
					+ '</p></div>';
			}
		} ).finally( function () {
			setLoading( form, false );
		} );
	} );

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '[data-progress-report-build]' ).forEach( function ( button ) {
			button.dataset.defaultLabel = button.textContent;
		} );
	} );
}() );
