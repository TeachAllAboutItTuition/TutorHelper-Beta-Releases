(function () {
	'use strict';

	function showDashboardRescheduleNotice() {
		var dashboard = document.querySelector(
			'[data-tutorhelper-student-dashboard]'
		);

		if (!dashboard) {
			return;
		}

		var params = new URLSearchParams(window.location.search);
		if ('rescheduled' !== params.get('tutorhelper_dashboard_status')) {
			return;
		}

		var notice = document.createElement('div');
		notice.className =
			'tutorhelper-student-dashboard__notice '
			+ 'tutorhelper-student-dashboard__notice--success';
		notice.setAttribute('role', 'status');
		notice.textContent =
			'Your lesson has been rescheduled successfully.';

		dashboard.insertBefore(notice, dashboard.firstChild);
	}

	function addCancellationTermsToCoreControl() {
		document
			.querySelectorAll('[data-tutorhelper-pro-booking-change-meta]')
			.forEach(function (meta) {
				if ('1' !== meta.dataset.cancelAvailable) {
					return;
				}

				var actions = meta.closest(
					'.tutorhelper-student-dashboard__card-actions'
				);

				if (!actions) {
					return;
				}

				var cancelForm = actions.querySelector(
					'.tutorhelper-student-dashboard__cancellation-form'
				);

				if (
					!cancelForm
					|| cancelForm.querySelector(
						'.tutorhelper-pro-booking-change-action-message'
					)
				) {
					return;
				}

				var termsText = meta.dataset.cancelTerms || '';
				if (!termsText) {
					return;
				}

				var terms = document.createElement('p');
				terms.className =
					'tutorhelper-pro-booking-change-action-message';
				terms.textContent = termsText;

				var label = cancelForm.querySelector(
					'label[for^="tutorhelper-cancellation-reason-"]'
				);

				if (label) {
					cancelForm.insertBefore(terms, label);
				} else {
					cancelForm.insertBefore(terms, cancelForm.firstChild);
				}
			});
	}

	function hidePaymentChoice(container) {
		container
			.querySelectorAll(
				'[data-tutorhelper-payment-choice], .tutorhelper-pro-payment-choice'
			)
			.forEach(function (choice) {
				choice.hidden = true;
				choice.setAttribute('aria-hidden', 'true');
			});
	}

	function renderRescheduleTerms(policyText) {
		if (!policyText) {
			return;
		}

		var combined = String(
			tutorhelperProReschedule.policyText || ''
		).trim();

		policyText.textContent = '';
		policyText.classList.add(
			'tutorhelper-pro-reschedule-terms'
		);

		if (!combined) {
			return;
		}

		var marker = ' You can reschedule';
		var markerIndex = combined.indexOf(marker);
		var cancellationText = combined;
		var rescheduleText = '';

		if (-1 !== markerIndex) {
			cancellationText = combined
				.substring(0, markerIndex)
				.trim();
			rescheduleText = combined
				.substring(markerIndex + 1)
				.trim();
		}

		function addTerm(label, text) {
			if (!text) {
				return;
			}

			var item = document.createElement('span');
			item.className =
				'tutorhelper-pro-reschedule-terms__item';

			var heading = document.createElement('strong');
			heading.className =
				'tutorhelper-pro-reschedule-terms__label';
			heading.textContent = label;

			var copy = document.createElement('span');
			copy.className =
				'tutorhelper-pro-reschedule-terms__text';
			copy.textContent = text;

			item.appendChild(heading);
			item.appendChild(copy);
			policyText.appendChild(item);
		}

		addTerm('Cancellation', cancellationText);
		addTerm('Rescheduling', rescheduleText);
	}

	function initialiseRescheduleMode() {
		if (
			typeof tutorhelperProReschedule === 'undefined'
			|| !tutorhelperProReschedule.active
		) {
			return;
		}

		var container = document.querySelector(
			'[data-tutorhelper-student-booking]'
		);

		if (!container) {
			return;
		}

		var form = container.querySelector('[data-booking-form]');
		if (!form) {
			return;
		}

		container.setAttribute('data-tutorhelper-pro-reschedule', '1');

		var extensionField = document.createElement('input');
		extensionField.type = 'hidden';
		extensionField.name = 'tutorhelper_reschedule_booking_id';
		extensionField.value = String(
			tutorhelperProReschedule.bookingId || ''
	);
		extensionField.setAttribute(
			'data-tutorhelper-booking-extension-field',
			''
		);
		form.appendChild(extensionField);

		var heading = container.querySelector(
			'.tutorhelper-student-booking__heading'
		);
		var intro = container.querySelector(
			'.tutorhelper-student-booking__introduction'
		);
		var serviceHeading = container.querySelector(
			'#tutorhelper-booking-service-heading'
		);
		var policyHeading = container.querySelector(
			'.tutorhelper-student-booking__policy h4'
		);
		var policyText = container.querySelector(
			'[data-booking-cancellation-policy]'
		);
		var agreementText = container.querySelector(
			'.tutorhelper-student-booking__policy-agreement span'
		);
		var submit = container.querySelector('[data-booking-submit]');

		if (heading) {
			heading.textContent = tutorhelperProReschedule.strings.heading;
		}

		if (intro) {
			intro.textContent = tutorhelperProReschedule.strings.intro;
		}

		if (serviceHeading) {
			serviceHeading.childNodes.forEach(function (node) {
				if (3 === node.nodeType && node.textContent.trim()) {
					node.textContent =
						tutorhelperProReschedule.strings.serviceHeading
						+ ' ';
				}
			});
		}

		if (policyHeading) {
			policyHeading.textContent =
				tutorhelperProReschedule.strings.policyHeading;
		}

		if (agreementText) {
			agreementText.textContent =
				tutorhelperProReschedule.strings.agreement;
		}

		if (submit) {
			submit.textContent = tutorhelperProReschedule.strings.submit;
		}

		var services = Array.from(
			container.querySelectorAll('[data-booking-service]')
		);
		var matchingService = null;

		services.forEach(function (service) {
			var matches =
				String(service.dataset.bookingTypeId || '')
				=== String(tutorhelperProReschedule.bookingTypeId || '');

			service.hidden = !matches;

			if (matches) {
				matchingService = service;
			}
		});

		container.addEventListener(
			'tutorhelper:booking-service-selected',
			function () {
				hidePaymentChoice(container);

				window.setTimeout(function () {
					renderRescheduleTerms(policyText);
				}, 0);
			}
		);

		if (matchingService && !matchingService.disabled) {
			matchingService.click();
			matchingService.disabled = true;
			matchingService.setAttribute('aria-disabled', 'true');
		}

		renderRescheduleTerms(policyText);
		hidePaymentChoice(container);
	}

	window.addEventListener('load', function () {
		showDashboardRescheduleNotice();
		addCancellationTermsToCoreControl();
		initialiseRescheduleMode();
	});
})();
