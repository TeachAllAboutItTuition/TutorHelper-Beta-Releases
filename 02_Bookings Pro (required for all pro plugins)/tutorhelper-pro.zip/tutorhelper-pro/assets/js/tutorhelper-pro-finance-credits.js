(function () {
	'use strict';

	function buildCreditRow(transaction, columnCount) {
		var row = document.createElement('tr');
		row.className =
			'tutorhelper-pro-finance-credit-row '
			+ 'tutorhelper-pro-finance-credit-row--'
			+ String(transaction.type || 'credit');

		var indicator = document.createElement('td');
		indicator.className =
			'tutorhelper-pro-finance-table__indicator';
		indicator.setAttribute('aria-hidden', 'true');
		row.appendChild(indicator);

		var content = document.createElement('td');
		content.colSpan = Math.max(1, columnCount - 1);
		content.className =
			'tutorhelper-pro-finance-credit-row__content';

		var heading = document.createElement('strong');
		heading.className =
			'tutorhelper-pro-finance-credit-row__label';
		heading.textContent = String(transaction.label || 'Account credit');

		var amount = document.createElement('span');
		amount.className =
			'tutorhelper-pro-finance-credit-row__amount';
		amount.textContent =
			(
				'credit_issued' === transaction.type
				|| 'refund' === transaction.type
					? '−'
					: ''
			)
			+ String(transaction.amount || '');

		var meta = document.createElement('span');
		meta.className =
			'tutorhelper-pro-finance-credit-row__meta';
		meta.textContent = [
			transaction.date || '',
			transaction.actor ? 'Recorded by ' + transaction.actor : '',
			transaction.paymentProvider ? 'Method: ' + transaction.paymentProvider : '',
			transaction.description || ''
		].filter(Boolean).join(' · ');

		content.appendChild(heading);
		content.appendChild(amount);

		if (meta.textContent) {
			content.appendChild(meta);
		}

		row.appendChild(content);
		return row;
	}

	function initialiseFinanceCredits() {
		if (
			typeof tutorhelperProFinanceCredits === 'undefined'
			|| !Array.isArray(tutorhelperProFinanceCredits.transactions)
			|| !tutorhelperProFinanceCredits.transactions.length
		) {
			return;
		}

		var table = document.querySelector(
			'.tutorhelper-pro-finance-table'
		);

		if (!table) {
			return;
		}

		var columnCount = table.querySelectorAll('thead th').length || 9;
		var byBooking = {};

		tutorhelperProFinanceCredits.transactions.forEach(function (transaction) {
			var bookingId = String(transaction.bookingId || '');
			if (!bookingId) {
				return;
			}

			if (!byBooking[bookingId]) {
				byBooking[bookingId] = [];
			}

			byBooking[bookingId].push(transaction);
		});

		table
			.querySelectorAll('[data-finance-due-date][data-booking-id]')
			.forEach(function (cell) {
				var bookingId = String(cell.dataset.bookingId || '');
				var transactions = byBooking[bookingId] || [];

				if (!transactions.length) {
					return;
				}

				var bookingRow = cell.closest('tr');
				if (!bookingRow) {
					return;
				}

				var anchor = bookingRow;
				transactions.forEach(function (transaction) {
					var creditRow = buildCreditRow(
						transaction,
						columnCount
					);

					anchor.parentNode.insertBefore(
						creditRow,
						anchor.nextSibling
					);
					anchor = creditRow;
				});
			});
	}

	window.addEventListener('load', initialiseFinanceCredits);
})();
