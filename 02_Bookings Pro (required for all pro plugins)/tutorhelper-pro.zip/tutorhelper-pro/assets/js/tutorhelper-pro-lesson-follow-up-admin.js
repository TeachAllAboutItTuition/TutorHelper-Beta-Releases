( function () {
	'use strict';

	const config = window.tutorhelperProLessonFollowUp || {};
	const modal = document.querySelector( '[data-follow-up-modal]' );
	const form = document.querySelector( '[data-follow-up-form]' );

	if ( ! modal || ! form || ! config.ajaxUrl ) {
		return;
	}

	const status = form.querySelector( '[data-follow-up-status]' );
	const lessonLabel = modal.querySelector( '[data-follow-up-lesson-label]' );
	const dueSelect = form.elements.homework_due_booking_id;
	const attachmentId = form.elements.homework_attachment_id;
	const fileName = form.querySelector( '[data-follow-up-file-name]' );
	const removeFile = form.querySelector( '[data-follow-up-remove-file]' );
	const ratingSummary = form.querySelector( '[data-follow-up-rating-summary]' );
	const completedField = form.elements.homework_completed;
	const completedWrap = form.querySelector( '[data-homework-completed-wrap]' );
	const tabButtons = Array.from( form.querySelectorAll( '[data-follow-up-tab]' ) );
	const tabPanels = Array.from( form.querySelectorAll( '[data-follow-up-panel]' ) );
	const dueTab = form.querySelector( '[data-follow-up-tab="due"]' );
	const dueCount = form.querySelector( '[data-follow-up-due-count]' );
	const dueList = form.querySelector( '[data-homework-due-list]' );
	const useSharedWrap = form.querySelector( '[data-follow-up-use-shared-wrap]' );
	const useShared = form.querySelector( '[data-follow-up-use-shared]' );
	const editableFields = form.querySelector( '[data-follow-up-editable-fields]' );
	const feedbackLabel = form.querySelector( '[data-follow-up-feedback-label]' );
	const submissionEnabled = form.elements.homework_submission_enabled;
	const assessmentType = form.elements.homework_assessment_type;
	const maxMark = form.elements.homework_max_mark;
	const academicContext = form.querySelector( '[data-follow-up-academic-context]' );
	const courseSelect = form.querySelector( '[data-follow-up-course]' );
	const topicsWrap = form.querySelector( '[data-follow-up-topics-wrap]' );
	const topicsContainer = form.querySelector( '[data-follow-up-topics]' );
	let availableCourses = [];
	let mediaFrame = null;
	let restoreDialogAfterMedia = false;

	function setStatus( message, isError ) {
		status.textContent = message || '';
		status.classList.toggle( 'is-error', Boolean( isError ) );
	}

	function setUseShared( enabled ) {
		useShared.checked = Boolean( enabled );
		editableFields.querySelectorAll( 'input, textarea, select, button' ).forEach( function ( field ) {
			field.disabled = Boolean( enabled );
		} );
		editableFields.classList.toggle( 'is-disabled', Boolean( enabled ) );
	}

	function selectTab( tabName ) {
		tabButtons.forEach( function ( button ) {
			const selected = button.dataset.followUpTab === tabName;
			button.setAttribute( 'aria-selected', selected ? 'true' : 'false' );
		} );
		tabPanels.forEach( function ( panel ) {
			panel.hidden = panel.dataset.followUpPanel !== tabName;
		} );
	}

	function appendHomeworkLink( container, url, label ) {
		if ( ! url ) {
			return;
		}
		const link = document.createElement( 'a' );
		link.href = url;
		link.target = '_blank';
		link.rel = 'noopener noreferrer';
		link.textContent = label;
		container.appendChild( link );
	}

	function renderDueHomework( items ) {
		const homework = Array.isArray( items ) ? items : [];
		dueList.replaceChildren();
		dueTab.hidden = homework.length === 0;
		completedWrap.hidden = homework.length === 0;
		dueCount.textContent = homework.length ? ' (' + homework.length + ')' : '';

		homework.forEach( function ( item ) {
			const article = document.createElement( 'article' );
			article.className = 'tutorhelper-pro-homework-due-item';

			const heading = document.createElement( 'h3' );
			heading.textContent = item.title || config.homeworkFallback || 'Homework';
			article.appendChild( heading );

			if ( item.sourceLabel ) {
				const source = document.createElement( 'p' );
				source.className = 'tutorhelper-pro-homework-due-item__source';
				source.textContent = ( config.homeworkSetAfter || 'Set after' ) + ': ' + item.sourceLabel;
				article.appendChild( source );
			}

			if ( item.instructions ) {
				const instructions = document.createElement( 'p' );
				instructions.textContent = item.instructions;
				article.appendChild( instructions );
			}

			const links = document.createElement( 'div' );
			links.className = 'tutorhelper-pro-homework-due-item__links';
			appendHomeworkLink( links, item.url, config.openHomeworkLink || 'Open homework link' );
			appendHomeworkLink( links, item.attachmentUrl, item.attachmentName || config.downloadHomeworkFile || 'Download homework file' );
			if ( links.children.length ) {
				article.appendChild( links );
			}
			if ( Array.isArray( item.lmsResources ) && item.lmsResources.length ) {
				const resources = document.createElement( 'div' );
				resources.className = 'tutorhelper-pro-homework-due-item__resources';
				const heading = document.createElement( 'strong' );
				heading.textContent = 'Learning resources';
				resources.appendChild( heading );
				item.lmsResources.forEach( function ( resource ) {
					const itemWrap = document.createElement( 'p' );
					const name = document.createElement( 'span' );
					name.textContent = resource.title || 'Resource';
					itemWrap.appendChild( name );
					if ( resource.previewable && resource.previewUrl ) {
						appendHomeworkLink( itemWrap, resource.previewUrl, 'Preview' );
					}
					appendHomeworkLink( itemWrap, resource.downloadUrl, 'Download' );
					resources.appendChild( itemWrap );
				} );
				article.appendChild( resources );
			}
			if ( item.lmsSubmission ) {
				const lms = document.createElement( 'p' );
				lms.className = 'tutorhelper-pro-homework-due-item__submission';
				lms.textContent = 'Status: ' + ( item.lmsSubmission.status || 'Not started' ) + ( item.lmsSubmission.method ? ' · ' + item.lmsSubmission.method : '' );
				article.appendChild( lms );
				appendHomeworkLink( article, item.lmsSubmission.url, item.lmsSubmission.urlLabel || 'View submission' );
				if ( item.lmsSubmission.markSubmissionId ) {
					const markButton = document.createElement( 'button' );
					markButton.type = 'button';
					markButton.className = 'button tutorhelper-action-button tutorhelper-lms-mark-submission tutorhelper-pro-homework-due-item__mark-button';
					markButton.dataset.tutorhelperLmsMarkSubmission = String( item.lmsSubmission.markSubmissionId );
					markButton.textContent = 'View / Mark homework';
					article.appendChild( markButton );
				}
			}
			dueList.appendChild( article );
		} );
	}


	function selectedCourse() {
		const selected = Number( courseSelect.value || 0 );
		return availableCourses.find( function ( course ) { return Number( course.id ) === selected; } ) || null;
	}

	function renderTopics( selectedIds ) {
		const course = selectedCourse();
		const selected = Array.isArray( selectedIds ) ? selectedIds.map( Number ) : [];
		topicsContainer.replaceChildren();
		const topics = course && Array.isArray( course.topics ) ? course.topics : [];
		topicsWrap.hidden = topics.length === 0;
		topics.forEach( function ( topic ) {
			const label = document.createElement( 'label' );
			const checkbox = document.createElement( 'input' );
			checkbox.type = 'checkbox';
			checkbox.name = 'homework_topic_ids[]';
			checkbox.value = String( topic.id );
			checkbox.checked = selected.includes( Number( topic.id ) );
			label.appendChild( checkbox );
			label.appendChild( document.createTextNode( ' ' + ( topic.title || '' ) ) );
			topicsContainer.appendChild( label );
		} );
		document.dispatchEvent( new CustomEvent( 'tutorhelper:follow-up-academic-context-changed', { detail: { form: form } } ) );
	}

	function renderAcademicContext( context, followUp ) {
		availableCourses = Array.isArray( context ) ? context : [];
		academicContext.hidden = availableCourses.length === 0;
		courseSelect.replaceChildren( new Option( 'No course selected', '0' ) );
		availableCourses.forEach( function ( course ) {
			courseSelect.appendChild( new Option( course.title || 'Course', String( course.id ) ) );
		} );
		let selected = Number( followUp.homework_course_id || 0 );
		if ( ! selected && availableCourses.length === 1 ) {
			selected = Number( availableCourses[ 0 ].id );
		}
		courseSelect.value = String( selected || 0 );
		renderTopics( followUp.homework_topic_ids || [] );
	}

	function resetForm() {
		form.reset();
		form.elements.booking_id.value = '';
		form.elements.group_session_id.value = '';
		form.elements.follow_up_scope.value = 'booking';
		attachmentId.value = '';
		fileName.textContent = 'No file selected';
		removeFile.hidden = true;
		ratingSummary.hidden = true;
		ratingSummary.textContent = '';
		useSharedWrap.hidden = true;
		setUseShared( false );
		renderDueHomework( [] );
		selectTab( 'set' );
		dueSelect.innerHTML = '';
		dueSelect.appendChild( new Option( 'No particular lesson', '0' ) );
		availableCourses = [];
		academicContext.hidden = true;
		courseSelect.replaceChildren( new Option( 'No course selected', '0' ) );
		topicsContainer.replaceChildren();
		topicsWrap.hidden = true;
		setStatus( '' );
	}

	async function request( body ) {
		const response = await fetch( config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		} );
		const result = await response.json();
		if ( ! response.ok || ! result.success ) {
			throw new Error( result.data && result.data.message ? result.data.message : config.failed );
		}
		return result.data;
	}

	async function openModal( bookingId, groupSessionId, scope ) {
		resetForm();
		const resolvedScope = scope || 'booking';
		const resolvedBookingId = 'group' === resolvedScope ? '0' : ( bookingId || '0' );
		form.elements.booking_id.value = resolvedBookingId;
		form.elements.group_session_id.value = groupSessionId || '';
		form.elements.follow_up_scope.value = resolvedScope;
		feedbackLabel.textContent = 'group' === resolvedScope ? config.groupFeedbackLabel : config.studentFeedbackLabel;
		lessonLabel.textContent = config.loading;
		modal.showModal();
		const body = new FormData();
		body.append( 'action', config.loadAction );
		body.append( 'nonce', config.nonce );
		body.append( 'booking_id', resolvedBookingId );
		body.append( 'group_session_id', groupSessionId || '0' );
		body.append( 'follow_up_scope', resolvedScope );
		try {
			const data = await request( body );
			const followUp = data.followUp || {};
			lessonLabel.textContent = data.lessonLabel || '';
			form.elements.tutor_feedback.value = followUp.tutor_feedback || '';
			form.elements.homework_title.value = followUp.homework_title || '';
			form.elements.homework_instructions.value = followUp.homework_instructions || '';
			form.elements.homework_url.value = followUp.homework_url || '';
			submissionEnabled.checked = Boolean( followUp.homework_submission_enabled );
			assessmentType.value = followUp.homework_assessment_type || 'completion';
			maxMark.value = followUp.homework_max_mark || '';
			attachmentId.value = followUp.homework_attachment_id || '';
			fileName.textContent = followUp.homework_attachment_name || 'No file selected';
			removeFile.hidden = ! followUp.homework_attachment_id;
			if ( completedField ) {
				completedField.checked = Boolean( data.homeworkCompleted );
				completedField.disabled = Boolean( data.homeworkCompletionManaged );
			}
			if ( completedWrap ) {
				completedWrap.hidden = Boolean( data.homeworkCompletionManaged );
			}
			renderDueHomework( data.dueHomework || [] );
			( data.dueBookings || [] ).forEach( function ( booking ) {
				dueSelect.appendChild( new Option( booking.label, String( booking.id ) ) );
			} );
			dueSelect.value = String( followUp.homework_due_booking_id || 0 );
			renderAcademicContext( data.academicContext || [], followUp );
			// Optional integrations can populate additional homework controls without
			// creating a dependency from Pro back to those plugins.
			document.dispatchEvent( new CustomEvent( 'tutorhelper:follow-up-loaded', {
				detail: { data: data, followUp: followUp, form: form }
			} ) );
			useSharedWrap.hidden = ! data.isGroupOverride;
			setUseShared( data.useGroupDefault );
			if ( data.rating ) {
				ratingSummary.hidden = false;
				ratingSummary.textContent = 'Student rating: ' + data.rating.value + '/5' + ( data.rating.comment ? ' — ' + data.rating.comment : '' );
			}
		} catch ( error ) {
			setStatus( error.message || config.failed, true );
		}
	}

	document.addEventListener( 'click', function ( event ) {
		const tabButton = event.target.closest( '[data-follow-up-tab]' );
		if ( tabButton && ! tabButton.hidden ) {
			event.preventDefault();
			selectTab( tabButton.dataset.followUpTab );
			return;
		}
		const trigger = event.target.closest( '[data-follow-up-booking-id]' );
		if ( trigger ) {
			event.preventDefault();
			openModal( trigger.dataset.followUpBookingId, trigger.dataset.followUpGroupSessionId, trigger.dataset.followUpScope );
			return;
		}
		if ( event.target.closest( '[data-follow-up-cancel]' ) ) {
			modal.close();
		}
	} );

	useShared.addEventListener( 'change', function () {
		setUseShared( useShared.checked );
	} );

	courseSelect.addEventListener( 'change', function () {
		renderTopics( [] );
	} );

	form.querySelector( '[data-follow-up-choose-file]' ).addEventListener( 'click', function () {
		if ( ! window.wp || ! wp.media ) {
			return;
		}
		if ( ! mediaFrame ) {
			mediaFrame = wp.media( {
				title: config.chooseFile,
				button: { text: config.useFile },
				multiple: false
			} );
			mediaFrame.on( 'select', function () {
				const file = mediaFrame.state().get( 'selection' ).first().toJSON();
				attachmentId.value = file.id;
				fileName.textContent = file.filename || file.title;
				removeFile.hidden = false;
			} );
			mediaFrame.on( 'close', function () {
				if ( restoreDialogAfterMedia && ! modal.open ) {
					modal.showModal();
				}
				restoreDialogAfterMedia = false;
			} );
		}
		restoreDialogAfterMedia = modal.open;
		if ( modal.open ) {
			modal.close();
		}
		mediaFrame.open();
	} );

	removeFile.addEventListener( 'click', function () {
		attachmentId.value = '';
		fileName.textContent = 'No file selected';
		removeFile.hidden = true;
	} );

	form.addEventListener( 'submit', async function ( event ) {
		event.preventDefault();
		setStatus( config.saving );
		const body = new FormData( form );
		body.append( 'action', config.saveAction );
		body.append( 'nonce', config.nonce );
		if ( useSharedWrap.hidden === false && useShared.checked ) {
			body.append( 'use_group_default', '1' );
		}
		try {
			const data = await request( body );
			setStatus( data.message || '' );
			window.setTimeout( function () { modal.close(); }, 500 );
		} catch ( error ) {
			setStatus( error.message || config.failed, true );
		}
	} );
}() );
