(function () {
	'use strict';

	if (
		typeof tutorhelperProFinance
		=== 'undefined'
	) {
		return;
	}

	document.addEventListener(
		'submit',
		function (event) {
			var form = event.target.closest('#tutorhelper-pro-payment-request-selection');
			if (!form) {
				return;
			}
			event.preventDefault();
			var region = form.closest('[data-payment-request-region]');
			var data = new FormData();
			data.append('action', tutorhelperProFinance.preparePaymentRequestAction);
			data.append('nonce', tutorhelperProFinance.preparePaymentRequestNonce);
			document.querySelectorAll('[data-finance-payment-select]:checked').forEach(function (checkbox) {
				data.append('booking_ids[]', checkbox.value);
			});
			fetch(tutorhelperProFinance.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
				.then(function (response) { return response.json(); })
				.then(function (payload) {
					if (!payload.success || !payload.data || !payload.data.html) {
						throw new Error(payload.data && payload.data.message ? payload.data.message : tutorhelperProFinance.saveFailedLabel);
					}
					var wrapper = document.createElement('div');
					wrapper.innerHTML = payload.data.html;
					var replacement = wrapper.querySelector('[data-payment-request-region]');
					if (region && replacement) {
						region.replaceWith(replacement);
					}
				})
				.catch(function (error) {
					window.alert(error.message);
				});
		}
	);

	document.addEventListener(
		'submit',
		function (event) {
			var form = event.target.closest('.tutorhelper-pro-payment-request__form');
			if (!form) {
				return;
			}
			if ('1' === form.dataset.paymentRequestConfirmed) {
				delete form.dataset.paymentRequestConfirmed;
				return;
			}
			event.preventDefault();
			openPaymentRequestEmail(form);
		}
	);

	function paymentRequestEmailElements(form) {
		return {
			modal: form.querySelector('[data-payment-request-email-modal]'),
			subject: form.querySelector('[data-payment-request-email-subject]'),
			body: form.querySelector('[data-payment-request-email-body]'),
			frame: form.querySelector('[data-payment-request-email-preview-frame]'),
			status: form.querySelector('[data-payment-request-email-status]'),
			refresh: form.querySelector('[data-payment-request-email-refresh]'),
			send: form.querySelector('[data-payment-request-email-send]')
		};
	}

	function setPaymentRequestEmailStatus(elements, message, type) {
		if (!elements.status) {
			return;
		}
		elements.status.textContent = message || '';
		elements.status.classList.remove('is-loading', 'is-error');
		if (type) {
			elements.status.classList.add('is-' + type);
		}
	}

	function validatePaymentRequestEmail(elements) {
		var form = elements.modal ? elements.modal.closest('.tutorhelper-pro-payment-request__form') : null;
		var hasMethod = form && form.querySelector('input[name="payment_methods[]"]:checked');
		var hasRecipient = form && form.querySelector('input[name="recipients[]"]:checked');
		if (!hasMethod || !hasRecipient) {
			setPaymentRequestEmailStatus(elements, tutorhelperProFinance.paymentRequestOptionsError, 'error');
			return false;
		}
		if (!elements.subject || !elements.subject.value.trim() || !elements.body || !elements.body.value.trim()) {
			setPaymentRequestEmailStatus(elements, tutorhelperProFinance.paymentRequestFieldsError, 'error');
			return false;
		}
		return true;
	}

	function openPaymentRequestEmail(form) {
		var elements = paymentRequestEmailElements(form);
		if (!elements.modal || !validatePaymentRequestEmail(elements)) {
			return;
		}
		elements.modal.hidden = false;
		form.paymentRequestReturnFocus = document.activeElement;
		document.body.classList.add('tutorhelper-modal-open');
		if (elements.subject) {
			elements.subject.focus();
		}
		refreshPaymentRequestEmail(form);
	}

	function closePaymentRequestEmail(form) {
		var elements = paymentRequestEmailElements(form);
		if (elements.modal) {
			elements.modal.hidden = true;
		}
		document.body.classList.remove('tutorhelper-modal-open');
		if (form.paymentRequestReturnFocus && 'function' === typeof form.paymentRequestReturnFocus.focus) {
			form.paymentRequestReturnFocus.focus();
		}
		form.paymentRequestReturnFocus = null;
	}

	function refreshPaymentRequestEmail(form) {
		var elements = paymentRequestEmailElements(form);
		if (!validatePaymentRequestEmail(elements)) {
			return;
		}
		var data = new FormData(form);
		data.set('action', tutorhelperProFinance.previewPaymentRequestAction);
		data.set('nonce', tutorhelperProFinance.previewPaymentRequestNonce);
		if (elements.refresh) {
			elements.refresh.disabled = true;
		}
		setPaymentRequestEmailStatus(elements, tutorhelperProFinance.paymentRequestPreviewingLabel, 'loading');
		fetch(tutorhelperProFinance.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
			.then(function (response) { return response.json(); })
			.then(function (payload) {
				if (!payload.success || !payload.data || !payload.data.html) {
					throw new Error(payload.data && payload.data.message ? payload.data.message : tutorhelperProFinance.paymentRequestPreviewError);
				}
				elements.frame.srcdoc = payload.data.html;
				setPaymentRequestEmailStatus(elements, '', '');
			})
			.catch(function (error) {
				setPaymentRequestEmailStatus(elements, error.message || tutorhelperProFinance.paymentRequestPreviewError, 'error');
			})
			.finally(function () {
				if (elements.refresh) {
					elements.refresh.disabled = false;
				}
			});
	}

	document.addEventListener('click', function (event) {
		var close = event.target.closest('[data-payment-request-email-close]');
		if (close) {
			var closeForm = close.closest('.tutorhelper-pro-payment-request__form');
			if (closeForm) {
				closePaymentRequestEmail(closeForm);
			}
			return;
		}
		var refresh = event.target.closest('[data-payment-request-email-refresh]');
		if (refresh) {
			var refreshForm = refresh.closest('.tutorhelper-pro-payment-request__form');
			if (refreshForm) {
				refreshPaymentRequestEmail(refreshForm);
			}
			return;
		}
		var send = event.target.closest('[data-payment-request-email-send]');
		if (send) {
			var sendForm = send.closest('.tutorhelper-pro-payment-request__form');
			var elements = sendForm ? paymentRequestEmailElements(sendForm) : null;
			if (!sendForm || !validatePaymentRequestEmail(elements)) {
				return;
			}
			send.disabled = true;
			send.textContent = tutorhelperProFinance.paymentRequestSendingLabel;
			sendForm.dataset.paymentRequestConfirmed = '1';
			sendForm.requestSubmit();
		}
	});

	document.addEventListener('keydown', function (event) {
		var modal = document.querySelector('[data-payment-request-email-modal]:not([hidden])');
		var form = modal ? modal.closest('.tutorhelper-pro-payment-request__form') : null;
		if ('Escape' === event.key && form) {
			event.preventDefault();
			closePaymentRequestEmail(form);
			return;
		}
		if ('Tab' === event.key && modal) {
			var focusable = Array.prototype.slice.call(modal.querySelectorAll('button:not([disabled]), input:not([disabled]), textarea:not([disabled]), summary, [tabindex]:not([tabindex="-1"])'));
			if (!focusable.length) {
				return;
			}
			var first = focusable[0];
			var last = focusable[focusable.length - 1];
			if (event.shiftKey && document.activeElement === first) {
				event.preventDefault();
				last.focus();
			} else if (!event.shiftKey && document.activeElement === last) {
				event.preventDefault();
				first.focus();
			}
		}
	});

	document.addEventListener(
		'click',
		function (event) {

			var editButton =
				event.target.closest(
					'[data-finance-due-date-edit]'
				);

			if (editButton) {
				openEditor(editButton);
				return;
			}

			var cancelButton =
				event.target.closest(
					'[data-finance-due-date-cancel]'
				);

			if (cancelButton) {
				closeEditor(cancelButton);
				return;
			}

			var saveButton =
				event.target.closest(
					'[data-finance-due-date-save]'
				);

			if (saveButton) {
				saveDueDate(
					saveButton,
					false
				);
				return;
			}

			var clearButton =
				event.target.closest(
					'[data-finance-due-date-clear]'
				);

			if (clearButton) {
				saveDueDate(
					clearButton,
					true
				);
			}
		}
	);


	document.addEventListener(
		'click',
		function (event) {
			var button =
				event.target.closest(
					'[data-finance-bulk-due-date-save]'
				);

			if (!button) {
				return;
			}

			var input =
				document.querySelector(
					'[data-finance-bulk-due-date]'
				);
			var status =
				document.querySelector(
					'[data-finance-bulk-due-date-status]'
				);
			var selected =
				Array.prototype.slice.call(
					document.querySelectorAll(
						'[data-finance-payment-select]:checked'
					)
				);

			if (!selected.length) {
				if (status) {
					status.textContent =
						tutorhelperProFinance.selectLessonsLabel;
				}
				return;
			}

			var data = new FormData();
			data.append(
				'action',
				tutorhelperProFinance.bulkDueDateAction
			);
			data.append(
				'nonce',
				tutorhelperProFinance.bulkDueDateNonce
			);
			data.append(
				'due_date',
				input ? input.value : ''
			);
			selected.forEach(
				function (checkbox) {
					data.append(
						'booking_ids[]',
						checkbox.value
					);
				}
			);

			button.disabled = true;
			if (status) {
				status.textContent =
					tutorhelperProFinance.savingLabel;
			}

			fetch(
				tutorhelperProFinance.ajaxUrl,
				{
					method: 'POST',
					credentials: 'same-origin',
					body: data
				}
			)
				.then(function (response) {
					return response.json();
				})
				.then(function (payload) {
					if (!payload.success) {
						throw new Error(
							payload.data
							&& payload.data.message
								? payload.data.message
								: tutorhelperProFinance.saveFailedLabel
						);
					}

					payload.data.bookingIds.forEach(
						function (bookingId) {
							var cell =
								document.querySelector(
									'[data-finance-due-date][data-booking-id="'
										+ bookingId
										+ '"]'
								);
							if (cell) {
								updateCell(
									cell,
									{
										dueDate:
											payload.data.dueDate,
										dueDateLabel:
											payload.data.dueDateLabel,
										hasDueDate: true,
										financeState: 'future'
									}
								);
							}
						}
					);

					if (status) {
						status.textContent =
							payload.data.message
							|| tutorhelperProFinance.bulkSuccessLabel;
					}
				})
				.catch(function (error) {
					if (window.console && typeof window.console.error === 'function') {
						window.console.error('TutorHelper bulk due-date update failed.', error);
					}
					if (status) {
						status.textContent = error.message;
					}
				})
				.finally(function () {
					button.disabled = false;
				});
		}
	);

	function getCell(element) {
		return element.closest(
			'[data-finance-due-date]'
		);
	}

	function openEditor(button) {

		var cell =
			getCell(button);

		if (!cell) {
			return;
		}

		var editor =
			cell.querySelector(
				'[data-finance-due-date-editor]'
			);

		var input =
			cell.querySelector(
				'[data-finance-due-date-input]'
			);

		if (!editor) {
			return;
		}

		editor.hidden = false;

		button.setAttribute(
			'aria-expanded',
			'true'
		);

		if (input) {
			input.focus();
		}
	}

	function closeEditor(button) {

		var cell =
			getCell(button);

		if (!cell) {
			return;
		}

		var editor =
			cell.querySelector(
				'[data-finance-due-date-editor]'
			);

		var editButton =
			cell.querySelector(
				'[data-finance-due-date-edit]'
			);

		var message =
			cell.querySelector(
				'[data-finance-due-date-message]'
			);

		if (editor) {
			editor.hidden = true;
		}

		if (editButton) {
			editButton.setAttribute(
				'aria-expanded',
				'false'
			);
		}

		if (message) {
			message.hidden = true;
			message.textContent = '';
		}
	}

	function saveDueDate(
		button,
		clear
	) {

		var cell =
			getCell(button);

		if (!cell) {
			return;
		}

		var bookingId =
			cell.dataset.bookingId;

		var input =
			cell.querySelector(
				'[data-finance-due-date-input]'
			);

		var message =
			cell.querySelector(
				'[data-finance-due-date-message]'
			);

		var dueDate =
			clear
				? ''
				: (
					input
						? input.value
						: ''
				);

		var formData =
			new FormData();

		formData.append(
			'action',
			tutorhelperProFinance
				.saveDueDateAction
		);

		formData.append(
			'nonce',
			tutorhelperProFinance
				.saveDueDateNonce
		);

		formData.append(
			'booking_id',
			bookingId
		);

		formData.append(
			'due_date',
			dueDate
		);

		button.disabled = true;

		if (message) {
			message.textContent =
				tutorhelperProFinance
					.savingLabel;

			message.hidden = false;
		}

		fetch(
			tutorhelperProFinance.ajaxUrl,
			{
				method: 'POST',
				credentials: 'same-origin',
				body: formData
			}
		)
			.then(function (response) {
				return response.json();
			})
			.then(function (payload) {

				if (
					! payload
					|| ! payload.success
				) {
					throw new Error(
						payload
						&& payload.data
						&& payload.data.message
							? payload.data.message
							: tutorhelperProFinance
								.saveFailedLabel
					);
				}

				updateCell(
					cell,
					payload.data
				);
			})
			.catch(function (error) {

				if (message) {
					message.textContent =
						error.message;

					message.hidden = false;
				}
			})
			.finally(function () {
				button.disabled = false;
			});
	}

	function updateCell(
		cell,
		data
	) {

		var label =
			cell.querySelector(
				'[data-finance-due-date-label]'
			);

		var input =
			cell.querySelector(
				'[data-finance-due-date-input]'
			);

		var editor =
			cell.querySelector(
				'[data-finance-due-date-editor]'
			);

		var editButton =
			cell.querySelector(
				'[data-finance-due-date-edit]'
			);

		var icon =
			editButton
				? editButton.querySelector(
					'.dashicons'
				)
				: null;

		if (label) {
			label.textContent =
				data.dueDateLabel;
		}

		if (input) {
			input.value =
				data.dueDate || '';
		}

		if (icon) {
			icon.classList.remove(
				'dashicons-edit',
				'dashicons-plus-alt2'
			);

			icon.classList.add(
				data.hasDueDate
					? 'dashicons-edit'
					: 'dashicons-plus-alt2'
			);
		}

		if (editor) {
			editor.hidden = true;
		}

		updateRowState(
			cell,
			data.financeState
		);
	}

	function updateRowState(
		cell,
		state
	) {

		var row =
			cell.closest(
				'.tutorhelper-pro-finance-row'
			);

		if (!row) {
			return;
		}

		var stateClasses = [
			'paid',
			'future',
			'due-soon',
			'overdue',
			'no-due-date',
			'informational'
		];

		stateClasses.forEach(
			function (item) {
				row.classList.remove(
					'tutorhelper-pro-finance-row--'
						+ item
				);
			}
		);

		row.classList.add(
			'tutorhelper-pro-finance-row--'
				+ state
		);
	}
})();
