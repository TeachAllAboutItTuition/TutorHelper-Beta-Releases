<?php
/**
 * TutorHelper Pro uninstall handler.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/*
 * TutorHelper Pro currently creates no persistent data that requires removal.
 */
