<?php
/**
 * Plugin Name:       TutorHelper Pro
 * Plugin URI:        https://tutorhelper.co.uk/wp-plugin-pro
 * Description:       Premium features and integrations for TutorHelper Bookings.
 * Version: 1.3.22
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Requires Plugins:  tutorhelper-bookings
 * Author:            Holly Billinghurst
 * Author URI:        https://tutorhelper.co.uk/
 * Text Domain:       tutorhelper-pro
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'TUTORHELPER_PRO_VERSION' ) ) {
	define( 'TUTORHELPER_PRO_VERSION', '1.3.22' );
}

if ( ! defined( 'TUTORHELPER_PRO_DB_VERSION' ) ) {
	define(
		'TUTORHELPER_PRO_DB_VERSION',
		'1.22.0'
	);
}

if ( ! defined( 'TUTORHELPER_PRO_FILE' ) ) {
	define( 'TUTORHELPER_PRO_FILE', __FILE__ );
}

if ( ! defined( 'TUTORHELPER_PRO_PATH' ) ) {
	define(
		'TUTORHELPER_PRO_PATH',
		plugin_dir_path( TUTORHELPER_PRO_FILE )
	);
}

if ( ! defined( 'TUTORHELPER_PRO_URL' ) ) {
	define(
		'TUTORHELPER_PRO_URL',
		plugin_dir_url( TUTORHELPER_PRO_FILE )
	);
}

if ( ! defined( 'TUTORHELPER_PRO_BASENAME' ) ) {
	define(
		'TUTORHELPER_PRO_BASENAME',
		plugin_basename( TUTORHELPER_PRO_FILE )
	);
}

require_once TUTORHELPER_PRO_PATH . 'includes/class-tutorhelper-pro-dependency.php';
require_once TUTORHELPER_PRO_PATH . 'includes/class-tutorhelper-pro-database.php';
require_once TUTORHELPER_PRO_PATH . 'includes/licensing/class-tutorhelper-pro-license.php';
require_once TUTORHELPER_PRO_PATH . 'includes/licensing/class-tutorhelper-pro-license-api.php';
require_once TUTORHELPER_PRO_PATH . 'includes/licensing/class-tutorhelper-pro-license-controller.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/student-pricing/class-tutorhelper-pro-student-pricing.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/student-pricing/class-tutorhelper-pro-student-pricing-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-payment-settings.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-payment-ledger.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-payment-history.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-stripe.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-stripe-webhook.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-student-payment-checkout.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-student-payment-settings.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-student-finance-visibility.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-bank-details.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-student-payment-methods.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-paid-booking-email.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-student-credits.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/payments/class-tutorhelper-pro-credit-refund-requests.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/finance/class-tutorhelper-pro-finance-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/finance/class-tutorhelper-pro-finance-statements.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/finance/class-tutorhelper-pro-finance-credit-allocations.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/finance/class-tutorhelper-pro-finance-payments.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/finance/class-tutorhelper-pro-finance-adjustments.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/finance/class-tutorhelper-pro-finance-adjustment-ui.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/finance/class-tutorhelper-pro-payment-requests.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/groups/class-tutorhelper-pro-groups.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/online-lessons/class-tutorhelper-pro-online-lessons.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/online-lessons/class-tutorhelper-pro-google-calendar.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/online-lessons/class-tutorhelper-pro-calendar-sync.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/online-lessons/class-tutorhelper-pro-google-calendar-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/online-lessons/class-tutorhelper-pro-online-lessons-dashboard.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/student-dashboard/class-tutorhelper-pro-student-dashboard-table.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/dashboard/class-tutorhelper-pro-dashboard-reports.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/dashboard/class-tutorhelper-pro-dashboard-analytics.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/reporting/class-tutorhelper-pro-student-reporting.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/reporting/class-tutorhelper-pro-progress-reports.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/reporting/class-tutorhelper-pro-parent-finance.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/booking-types/class-tutorhelper-pro-booking-type-settings.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/groups/class-tutorhelper-pro-groups-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/branding/class-tutorhelper-pro-branding.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/branding/class-tutorhelper-pro-email-branding.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/branding/class-tutorhelper-pro-booking-branding.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/branding/class-tutorhelper-pro-dashboard-branding.php';
require_once TUTORHELPER_PRO_PATH . 'includes/admin/class-tutorhelper-pro-settings.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/emails/class-tutorhelper-pro-email-reminders.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/emails/class-tutorhelper-pro-email-reminder-delivery.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/emails/class-tutorhelper-pro-email-delivery-history.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/emails/class-tutorhelper-pro-email-reminder-cron.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/emails/class-tutorhelper-pro-email-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/booking-types/class-tutorhelper-pro-booking-type-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/booking-types/class-tutorhelper-pro-booking-type-access.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-booking-series.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-booking-recurrence.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-recurring-booking-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-recurring-booking-editor.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-booking-series-create.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-booking-series-email.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-booking-attendance.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-lesson-follow-up.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-late-reminder-email.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-student-bookings-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-booking-change-limits.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-booking-page-resolver.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-student-rescheduling.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/bookings/class-tutorhelper-pro-student-rescheduling-ux.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/registrations/class-tutorhelper-pro-onboarding.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/registrations/class-tutorhelper-pro-registration-settings.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/registrations/class-tutorhelper-pro-registration-admin.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/registrations/class-tutorhelper-pro-registration-frontend.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/registrations/class-tutorhelper-pro-registration-emails.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/registrations/class-tutorhelper-pro-registration-handler.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/registrations/class-tutorhelper-pro-terms-update.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/students/class-tutorhelper-pro-student-data.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/students/class-tutorhelper-pro-student-notes.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/students/class-tutorhelper-pro-student-history.php';
require_once TUTORHELPER_PRO_PATH . 'includes/modules/students/class-tutorhelper-pro-student-email.php';
require_once TUTORHELPER_PRO_PATH . 'includes/class-tutorhelper-pro.php';

function tutorhelper_pro_activate() {
	TutorHelper_Pro_Database::create_tables();
	TutorHelper_Pro_Email_Reminder_Cron::activate();
	TutorHelper_Pro_Settings::schedule_license_validation();
}

function tutorhelper_pro_deactivate() {
	TutorHelper_Pro_Email_Reminder_Cron::deactivate();
	TutorHelper_Pro_Settings::unschedule_license_validation();
}

register_deactivation_hook(
	TUTORHELPER_PRO_FILE,
	'tutorhelper_pro_deactivate'
);

register_activation_hook(
	TUTORHELPER_PRO_FILE,
	'tutorhelper_pro_activate'
);

function tutorhelper_pro_run() {
	TutorHelper_Pro_Database::update_check();
	TutorHelper_Pro_Onboarding::ensure_system_questions();
	TutorHelper_Pro::instance()->run();
}

add_action( 'plugins_loaded', 'tutorhelper_pro_run', 20 );
