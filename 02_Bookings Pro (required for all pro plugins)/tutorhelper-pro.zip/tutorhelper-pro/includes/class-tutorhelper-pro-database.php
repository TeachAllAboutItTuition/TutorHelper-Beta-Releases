<?php
/**
 * TutorHelper Pro database schema manager.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates and updates TutorHelper Pro database tables.
 */
final class TutorHelper_Pro_Database {

	/**
	 * Option storing the installed Pro database version.
	 *
	 * @var string
	 */
	const VERSION_OPTION =
		'tutorhelper_pro_db_version';

	/**
	 * Create or update Pro database tables.
	 *
	 * @return void
	 */
	public static function create_tables() {
		global $wpdb;

		require_once ABSPATH
			. 'wp-admin/includes/upgrade.php';

		$charset_collate =
			$wpdb->get_charset_collate();

		$groups_table =
			self::get_table_name( 'groups' );

		$student_groups_table =
			self::get_table_name(
				'student_groups'
			);

		$group_courses_table = self::get_table_name( 'group_courses' );

        $booking_type_groups_table =
            self::get_table_name(
                'booking_type_groups'
            );

        $booking_type_settings_table =
            self::get_table_name(
                'booking_type_settings'
            );

        $booking_series_table =
            self::get_table_name(
                'booking_series'
            );

        $booking_series_items_table =
            self::get_table_name(
                'booking_series_items'
            );

		$booking_attendance_table =
			self::get_table_name(
				'booking_attendance'
			);

		$lesson_follow_up_table =
			self::get_table_name(
				'lesson_follow_up'
			);

		$group_lesson_follow_up_table =
			self::get_table_name(
				'group_lesson_follow_up'
			);

		$lesson_ratings_table =
			self::get_table_name(
				'lesson_ratings'
			);

		$late_reminder_log_table =
			self::get_table_name(
				'late_reminder_log'
			);

		$email_reminders_table =
			self::get_table_name(
				'email_reminders'
			);

		$email_reminder_booking_types_table =
			self::get_table_name(
				'email_reminder_booking_types'
			);

		$email_reminder_deliveries_table =
			self::get_table_name(
				'email_reminder_deliveries'
			);

		$onboarding_questions_table =
			self::get_table_name(
				'onboarding_questions'
			);

		$onboarding_answers_table =
			self::get_table_name(
				'onboarding_answers'
			);

		$email_deliveries_table =
			self::get_table_name(
				'email_deliveries'
			);

		$student_notes_table =
			self::get_table_name(
				'student_notes'
			);


		$finance_transactions_table =
			self::get_table_name(
				'finance_transactions'
			);

		$payment_history_table =
			self::get_table_name(
				'payment_history'
			);

		$booking_finance_table =
			self::get_table_name(
				'booking_finance'
			);

		$credit_refund_requests_table =
			self::get_table_name( 'credit_refund_requests' );

		$payment_requests_table =
			self::get_table_name( 'payment_requests' );



		$groups_sql =
			"CREATE TABLE {$groups_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				name varchar(255) NOT NULL,
				slug varchar(200) NOT NULL,
				description text NULL,
				is_active tinyint(1) NOT NULL DEFAULT 1,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY slug (slug),
				KEY is_active (is_active)
			) {$charset_collate};";

		$student_groups_sql =
			"CREATE TABLE {$student_groups_table} (
				group_id bigint(20) unsigned NOT NULL,
				student_user_id bigint(20) unsigned NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (group_id, student_user_id),
				KEY student_user_id (student_user_id)
			) {$charset_collate};";

		$group_courses_sql =
			"CREATE TABLE {$group_courses_table} (
				group_id bigint(20) unsigned NOT NULL,
				course_id bigint(20) unsigned NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (group_id, course_id),
				KEY course_id (course_id)
			) {$charset_collate};";

        $booking_type_groups_sql =
            "CREATE TABLE {$booking_type_groups_table} (
                group_id bigint(20) unsigned NOT NULL,
                booking_type_id bigint(20) unsigned NOT NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY  (group_id, booking_type_id),
                KEY booking_type_id (booking_type_id)
            ) {$charset_collate};";

        $booking_type_settings_sql =
            "CREATE TABLE {$booking_type_settings_table} (
                booking_type_id bigint(20) unsigned NOT NULL,
                group_access_mode varchar(50) NOT NULL DEFAULT 'none',
                can_reschedule tinyint(1) NOT NULL DEFAULT 0,
                reschedule_notice_hours int(10) unsigned NOT NULL DEFAULT 24,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY  (booking_type_id),
                KEY group_access_mode (group_access_mode),
                KEY can_reschedule (can_reschedule)
            ) {$charset_collate};";

        $booking_series_sql =
            "CREATE TABLE {$booking_series_table} (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                student_user_id bigint(20) unsigned NOT NULL,
                tutor_user_id bigint(20) unsigned NOT NULL,
                booking_type_id bigint(20) unsigned NOT NULL,
                start_date date NOT NULL,
                end_date date NOT NULL,
                frequency varchar(30) NOT NULL,
                start_time time NOT NULL,
                end_time time NOT NULL,
                timezone varchar(100) NOT NULL,
                location_type varchar(50) NOT NULL,
                location_details text NULL,
                booking_status varchar(50) NOT NULL,
                exclude_outside_term_time tinyint(1) NOT NULL DEFAULT 0,
                exclude_public_holidays tinyint(1) NOT NULL DEFAULT 0,
                notes text NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY student_user_id (student_user_id),
                KEY tutor_user_id (tutor_user_id),
                KEY booking_type_id (booking_type_id),
                KEY frequency (frequency),
                KEY start_date (start_date),
                KEY end_date (end_date)
            ) {$charset_collate};";

        $booking_series_items_sql =
            "CREATE TABLE {$booking_series_items_table} (
                series_id bigint(20) unsigned NOT NULL,
                booking_id bigint(20) unsigned NOT NULL,
                occurrence_date date NOT NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY  (series_id, booking_id),
                UNIQUE KEY booking_id (booking_id),
                KEY occurrence_date (occurrence_date)
            ) {$charset_collate};";

		$booking_attendance_sql =
			"CREATE TABLE {$booking_attendance_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				booking_id bigint(20) unsigned NOT NULL,
				attendance_status varchar(30) NOT NULL DEFAULT 'not_recorded',
				recorded_at datetime DEFAULT NULL,
				recorded_by_user_id bigint(20) unsigned DEFAULT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY booking_id (booking_id),
				KEY attendance_status (attendance_status),
				KEY recorded_by_user_id (recorded_by_user_id)
			) {$charset_collate};";

		$lesson_follow_up_sql =
			"CREATE TABLE {$lesson_follow_up_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				booking_id bigint(20) unsigned DEFAULT NULL,
				group_session_id bigint(20) unsigned DEFAULT NULL,
				tutor_feedback longtext DEFAULT NULL,
				homework_title varchar(190) NOT NULL DEFAULT '',
				homework_instructions longtext DEFAULT NULL,
				homework_url text DEFAULT NULL,
				homework_attachment_id bigint(20) unsigned DEFAULT NULL,
				homework_due_booking_id bigint(20) unsigned DEFAULT NULL,
				homework_due_group_session_id bigint(20) unsigned DEFAULT NULL,
				homework_course_id bigint(20) unsigned NOT NULL DEFAULT 0,
				homework_source_group_id bigint(20) unsigned NOT NULL DEFAULT 0,
				homework_topic_ids longtext NULL,
				homework_submission_enabled tinyint(1) NOT NULL DEFAULT 0,
				homework_assessment_type varchar(20) NOT NULL DEFAULT 'completion',
				homework_max_mark decimal(10,2) DEFAULT NULL,
				updated_by_user_id bigint(20) unsigned DEFAULT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY booking_id (booking_id),
				UNIQUE KEY group_session_id (group_session_id),
				KEY homework_due_booking_id (homework_due_booking_id),
				KEY homework_due_group_session_id (homework_due_group_session_id),
				KEY updated_by_user_id (updated_by_user_id)
			) {$charset_collate};";

		$group_lesson_follow_up_sql =
			"CREATE TABLE {$group_lesson_follow_up_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				group_session_id bigint(20) unsigned NOT NULL,
				tutor_feedback longtext DEFAULT NULL,
				homework_title varchar(190) NOT NULL DEFAULT '',
				homework_instructions longtext DEFAULT NULL,
				homework_url text DEFAULT NULL,
				homework_attachment_id bigint(20) unsigned DEFAULT NULL,
				homework_due_group_session_id bigint(20) unsigned DEFAULT NULL,
				homework_course_id bigint(20) unsigned NOT NULL DEFAULT 0,
				homework_source_group_id bigint(20) unsigned NOT NULL DEFAULT 0,
				homework_topic_ids longtext NULL,
				homework_submission_enabled tinyint(1) NOT NULL DEFAULT 0,
				homework_assessment_type varchar(20) NOT NULL DEFAULT 'completion',
				homework_max_mark decimal(10,2) DEFAULT NULL,
				updated_by_user_id bigint(20) unsigned DEFAULT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY group_session_id (group_session_id),
				KEY homework_due_group_session_id (homework_due_group_session_id),
				KEY updated_by_user_id (updated_by_user_id)
			) {$charset_collate};";

		$lesson_ratings_sql =
			"CREATE TABLE {$lesson_ratings_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				booking_id bigint(20) unsigned NOT NULL,
				student_user_id bigint(20) unsigned NOT NULL,
				rating tinyint(1) unsigned NOT NULL,
				comment text DEFAULT NULL,
				submitted_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY booking_id (booking_id),
				KEY student_user_id (student_user_id),
				KEY rating (rating),
				KEY submitted_at (submitted_at)
			) {$charset_collate};";

		$late_reminder_log_sql =
			"CREATE TABLE {$late_reminder_log_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				booking_id bigint(20) unsigned NOT NULL,
				sent_at datetime NOT NULL,
				sent_by_user_id bigint(20) unsigned NOT NULL,
				student_email varchar(190) NOT NULL DEFAULT '',
				parent_email varchar(190) NOT NULL DEFAULT '',
				PRIMARY KEY  (id),
				KEY booking_id (booking_id),
				KEY sent_at (sent_at),
				KEY sent_by_user_id (sent_by_user_id)
			) {$charset_collate};";

		$email_reminders_sql =
			"CREATE TABLE {$email_reminders_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				name varchar(190) NOT NULL,
				slug varchar(190) NOT NULL,
				subject varchar(255) NOT NULL,
				body longtext NOT NULL,
				recipient_student tinyint(1) NOT NULL DEFAULT 1,
				recipient_parent tinyint(1) NOT NULL DEFAULT 1,
				recipient_tutor tinyint(1) NOT NULL DEFAULT 0,
				timing_amount int(10) unsigned NOT NULL DEFAULT 24,
				timing_unit varchar(20) NOT NULL DEFAULT 'hours',
				timing_direction varchar(20) NOT NULL DEFAULT 'before',
				is_enabled tinyint(1) NOT NULL DEFAULT 1,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY slug (slug),
				KEY is_enabled (is_enabled),
				KEY timing_direction (timing_direction)
			) {$charset_collate};";

		$email_reminder_booking_types_sql =
			"CREATE TABLE {$email_reminder_booking_types_table} (
				reminder_id bigint(20) unsigned NOT NULL,
				booking_type_id bigint(20) unsigned NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (reminder_id, booking_type_id),
				KEY booking_type_id (booking_type_id)
			) {$charset_collate};";

		$email_reminder_deliveries_sql =
			"CREATE TABLE {$email_reminder_deliveries_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				reminder_id bigint(20) unsigned NOT NULL,
				booking_id bigint(20) unsigned NOT NULL,
				recipient_type varchar(20) NOT NULL,
				recipient_email varchar(190) NOT NULL DEFAULT '',
				scheduled_for datetime NOT NULL,
				status varchar(20) NOT NULL DEFAULT 'pending',
				attempts smallint(5) unsigned NOT NULL DEFAULT 0,
				last_attempt_at datetime DEFAULT NULL,
				sent_at datetime DEFAULT NULL,
				error_message text DEFAULT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY reminder_booking_recipient (
					reminder_id,
					booking_id,
					recipient_type
				),
				KEY status (status),
				KEY scheduled_for (scheduled_for),
				KEY booking_id (booking_id)
			) {$charset_collate};";

		$onboarding_questions_sql =
			"CREATE TABLE {$onboarding_questions_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				question_key varchar(100) DEFAULT NULL,
				is_system tinyint(1) NOT NULL DEFAULT 0,
				question_text text NOT NULL,
				question_type varchar(30) NOT NULL DEFAULT 'short_text',
				question_options longtext NULL,
				is_required tinyint(1) NOT NULL DEFAULT 0,
				data_category varchar(30) NOT NULL DEFAULT 'standard',
				sort_order int(10) unsigned NOT NULL DEFAULT 0,
				is_active tinyint(1) NOT NULL DEFAULT 1,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY question_key (question_key),
				KEY is_system (is_system),
				KEY question_type (question_type),
				KEY data_category (data_category),
				KEY is_active (is_active),
				KEY sort_order (sort_order)
			) {$charset_collate};";

		$onboarding_answers_sql =
			"CREATE TABLE {$onboarding_answers_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				student_user_id bigint(20) unsigned NOT NULL,
				question_id bigint(20) unsigned NOT NULL,
				question_text_snapshot text NOT NULL,
				question_type_snapshot varchar(30) NOT NULL,
				data_category_snapshot varchar(30) NOT NULL DEFAULT 'standard',
				answer longtext NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY student_question (
					student_user_id,
					question_id
				),
				KEY student_user_id (student_user_id),
				KEY question_id (question_id),
				KEY data_category_snapshot (
					data_category_snapshot
				)
			) {$charset_collate};";

		$email_deliveries_sql =
			"CREATE TABLE {$email_deliveries_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				template_key varchar(190) NOT NULL,
				delivery_type varchar(50) NOT NULL DEFAULT 'automatic',
				related_object_type varchar(50) NOT NULL DEFAULT '',
				related_object_id bigint(20) unsigned NOT NULL DEFAULT 0,
				recipient_type varchar(30) NOT NULL DEFAULT '',
				recipient_email varchar(190) NOT NULL DEFAULT '',
				subject_snapshot text DEFAULT NULL,
				html_snapshot longtext DEFAULT NULL,
				context_snapshot longtext DEFAULT NULL,
				status varchar(20) NOT NULL,
				error_message text DEFAULT NULL,
				sent_at datetime DEFAULT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY template_key (template_key),
				KEY delivery_type (delivery_type),
				KEY status (status),
				KEY recipient_email (recipient_email),
				KEY related_object (
					related_object_type,
					related_object_id
				)
			) {$charset_collate};";

		$student_notes_sql =
			"CREATE TABLE {$student_notes_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				student_user_id bigint(20) unsigned NOT NULL,
				author_user_id bigint(20) unsigned NOT NULL,
				note_content longtext NOT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY student_created (student_user_id, created_at),
				KEY author_user_id (author_user_id)
			) {$charset_collate};";

		$finance_transactions_sql =
			"CREATE TABLE {$finance_transactions_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				booking_id bigint(20) unsigned DEFAULT NULL,
				student_user_id bigint(20) unsigned NOT NULL,
				tutor_user_id bigint(20) unsigned NOT NULL,
				transaction_type varchar(50) NOT NULL,
				amount_minor_units bigint(20) NOT NULL DEFAULT 0,
				currency char(3) NOT NULL DEFAULT 'GBP',
				payment_method varchar(50) NOT NULL DEFAULT '',
				manual_payment_type varchar(30) NOT NULL DEFAULT '',
				payment_provider varchar(50) NOT NULL DEFAULT '',
				provider_reference varchar(255) NOT NULL DEFAULT '',
				provider_event_id varchar(190) DEFAULT NULL,
				description text DEFAULT NULL,
				transaction_date datetime NOT NULL,
				created_by_user_id bigint(20) unsigned DEFAULT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY booking_id (booking_id),
				KEY student_user_id (student_user_id),
				KEY tutor_user_id (tutor_user_id),
				KEY transaction_type (transaction_type),
				KEY payment_provider (payment_provider),
				KEY transaction_date (transaction_date),
				UNIQUE KEY provider_event (
					payment_provider,
					provider_event_id
				)
			) {$charset_collate};";

		$payment_history_sql =
			"CREATE TABLE {$payment_history_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				booking_id bigint(20) unsigned NOT NULL,
				student_user_id bigint(20) unsigned NOT NULL,
				previous_payment_status varchar(50) NOT NULL DEFAULT '',
				new_payment_status varchar(50) NOT NULL,
				previous_booking_status varchar(50) NOT NULL DEFAULT '',
				new_booking_status varchar(50) NOT NULL DEFAULT '',
				amount_minor_units bigint(20) NOT NULL DEFAULT 0,
				currency char(3) NOT NULL DEFAULT 'GBP',
				payment_method varchar(50) NOT NULL DEFAULT '',
				payment_provider varchar(50) NOT NULL DEFAULT '',
				provider_reference varchar(255) NOT NULL DEFAULT '',
				provider_event_id varchar(190) DEFAULT NULL,
				change_source varchar(50) NOT NULL DEFAULT 'system',
				changed_by_user_id bigint(20) unsigned DEFAULT NULL,
				changed_at datetime NOT NULL,
				notes text DEFAULT NULL,
				PRIMARY KEY  (id),
				KEY booking_id (booking_id),
				KEY student_user_id (student_user_id),
				KEY new_payment_status (new_payment_status),
				KEY payment_provider (payment_provider),
				UNIQUE KEY provider_event (
					payment_provider,
					provider_event_id
				),
				KEY change_source (change_source),
				KEY changed_at (changed_at)
			) {$charset_collate};";

		$credit_refund_requests_sql =
			"CREATE TABLE {$credit_refund_requests_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				student_user_id bigint(20) unsigned NOT NULL,
				amount_minor_units bigint(20) unsigned NOT NULL,
				currency char(3) NOT NULL DEFAULT 'GBP',
				status varchar(20) NOT NULL DEFAULT 'pending',
				student_note text DEFAULT NULL,
				requested_at datetime NOT NULL,
				resolved_at datetime DEFAULT NULL,
				resolved_by_user_id bigint(20) unsigned DEFAULT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY student_status (student_user_id, status),
				KEY status (status),
				KEY requested_at (requested_at)
			) {$charset_collate};";

		$payment_requests_sql =
			"CREATE TABLE {$payment_requests_table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				student_user_id bigint(20) unsigned NOT NULL,
				tutor_user_id bigint(20) unsigned NOT NULL,
				booking_ids longtext NOT NULL,
				allocations longtext NOT NULL,
				amount_minor_units bigint(20) unsigned NOT NULL DEFAULT 0,
				currency char(3) NOT NULL DEFAULT 'GBP',
				payment_methods longtext NOT NULL,
				recipients longtext NOT NULL,
				stripe_checkout_session_id varchar(255) NOT NULL DEFAULT '',
				stripe_checkout_url text DEFAULT NULL,
				status varchar(30) NOT NULL DEFAULT 'prepared',
				created_by_user_id bigint(20) unsigned NOT NULL,
				created_at datetime NOT NULL,
				sent_at datetime DEFAULT NULL,
				paid_at datetime DEFAULT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY student_user_id (student_user_id),
				KEY status (status),
				KEY stripe_checkout_session_id (stripe_checkout_session_id)
			) {$charset_collate};";

		$booking_finance_sql =
			"CREATE TABLE {$booking_finance_table} (
				booking_id bigint(20) unsigned NOT NULL,
				payment_due_date date DEFAULT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (booking_id),
				KEY payment_due_date (payment_due_date)
			) {$charset_collate};";




		dbDelta( $groups_sql );
		dbDelta( $student_groups_sql );
		dbDelta( $group_courses_sql );
        dbDelta( $booking_type_groups_sql );
        dbDelta( $booking_type_settings_sql );
        dbDelta( $booking_series_sql );
        dbDelta( $booking_series_items_sql );
		dbDelta( $booking_attendance_sql );
		dbDelta( $lesson_follow_up_sql );
		dbDelta( $group_lesson_follow_up_sql );
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time schema migration preserves any shared Group Session follow-ups created before the dedicated table was introduced.
			$wpdb->prepare(
				'INSERT IGNORE INTO %i (group_session_id, tutor_feedback, homework_title, homework_instructions, homework_url, homework_attachment_id, homework_due_group_session_id, updated_by_user_id, created_at, updated_at) SELECT group_session_id, tutor_feedback, homework_title, homework_instructions, homework_url, homework_attachment_id, homework_due_group_session_id, updated_by_user_id, created_at, updated_at FROM %i WHERE group_session_id IS NOT NULL',
				$group_lesson_follow_up_table,
				$lesson_follow_up_table
			)
		);
		dbDelta( $lesson_ratings_sql );
		dbDelta( $late_reminder_log_sql );
		dbDelta( $email_reminders_sql );
		dbDelta( $email_reminder_booking_types_sql );
		dbDelta( $email_reminder_deliveries_sql );
		dbDelta( $email_deliveries_sql );
		dbDelta( $student_notes_sql );
		dbDelta( $finance_transactions_sql );
		dbDelta( $payment_history_sql );
		dbDelta( $booking_finance_sql );
		dbDelta( $credit_refund_requests_sql );
		dbDelta( $payment_requests_sql );
		dbDelta( $onboarding_questions_sql );
		dbDelta( $onboarding_answers_sql );

		if (
			self::table_exists( $group_lesson_follow_up_table )
			&& self::table_exists( $student_notes_table )
			&& self::table_exists( $group_courses_table )
		) {
			update_option(
				self::VERSION_OPTION,
				TUTORHELPER_PRO_DB_VERSION
			);
		} elseif ( class_exists( 'TutorHelper_Logger' ) ) {
			TutorHelper_Logger::error(
				'TutorHelper Pro database schema update did not create a required table.',
				array(
					'database_version' => TUTORHELPER_PRO_DB_VERSION,
					'tables'           => array(
						$group_lesson_follow_up_table,
						$student_notes_table,
					),
					'database_error'   => sanitize_text_field( $wpdb->last_error ),
				)
			);
		}
	}

	/**
	 * Create or update tables when the installed schema
	 * is older than the current Pro schema.
	 *
	 * @return void
	 */
	public static function update_check() {

		$installed_version =
			get_option(
				self::VERSION_OPTION,
				'0.0.0'
			);

		$group_follow_up_table =
			self::get_table_name(
				'group_lesson_follow_up'
			);

		$student_notes_table =
			self::get_table_name(
				'student_notes'
			);

		$group_courses_table =
			self::get_table_name( 'group_courses' );

		if (
			version_compare(
				$installed_version,
				TUTORHELPER_PRO_DB_VERSION,
				'<'
			)
			|| ! self::table_exists( $group_follow_up_table )
			|| ! self::table_exists( $student_notes_table )
			|| ! self::table_exists( $group_courses_table )
		) {
			self::create_tables();

			if (
				self::table_exists( $group_follow_up_table )
				&& self::table_exists( $student_notes_table )
				&& class_exists(
					'TutorHelper_Logger'
				)
			) {
				TutorHelper_Logger::success(
					'TutorHelper Pro database schema checked.',
					array(
						'database_version' =>
							TUTORHELPER_PRO_DB_VERSION,
					)
				);
			}
		}
	}

	/**
	 * Check that one Pro database table exists.
	 *
	 * This guards against a staged plugin upload recording a schema version
	 * before every updated PHP file has reached the server.
	 *
	 * @param string $table_name Full database table name.
	 * @return bool
	 */
	private static function table_exists( $table_name ) {
		global $wpdb;

		return $table_name === $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- The schema check must inspect the current database state.
			$wpdb->prepare(
				'SHOW TABLES LIKE %s',
				$wpdb->esc_like( $table_name )
			)
		);
	}

	/**
	 * Return a TutorHelper Pro table name.
	 *
	 * @param string $table Short table identifier.
	 *
	 * @return string
	 */
	public static function get_table_name(
		$table
	) {
		global $wpdb;

		$tables = array(
			'groups' =>
				$wpdb->prefix
				. 'tutorhelper_pro_groups',

			'student_groups' =>
				$wpdb->prefix
				. 'tutorhelper_pro_student_groups',

			'group_courses' =>
				$wpdb->prefix
				. 'tutorhelper_pro_group_courses',

            'booking_type_groups' =>
                $wpdb->prefix
                    . 'tutorhelper_pro_booking_type_groups',

            'booking_type_settings' =>
                $wpdb->prefix
                    . 'tutorhelper_pro_booking_type_settings',

            'booking_series' =>
                $wpdb->prefix
                . 'tutorhelper_pro_booking_series',

            'booking_series_items' =>
                $wpdb->prefix
                . 'tutorhelper_pro_booking_series_items',

			'booking_attendance' =>
				$wpdb->prefix
				. 'tutorhelper_pro_booking_attendance',

			'lesson_follow_up' =>
				$wpdb->prefix
					. 'tutorhelper_pro_lesson_follow_up',

			'group_lesson_follow_up' =>
				$wpdb->prefix
					. 'tutorhelper_pro_group_lesson_follow_up',

			'lesson_ratings' =>
				$wpdb->prefix
				. 'tutorhelper_pro_lesson_ratings',

			'late_reminder_log' =>
				$wpdb->prefix
				. 'tutorhelper_pro_late_reminder_log',

			'email_reminders' =>
				$wpdb->prefix
				. 'tutorhelper_pro_email_reminders',

			'email_reminder_booking_types' =>
				$wpdb->prefix
				. 'tutorhelper_pro_email_reminder_booking_types',

			'email_reminder_deliveries' =>
				$wpdb->prefix
				. 'tutorhelper_pro_email_reminder_deliveries',

			'email_deliveries' =>
				$wpdb->prefix
				. 'tutorhelper_pro_email_deliveries',

			'student_notes' =>
				$wpdb->prefix
				. 'tutorhelper_pro_student_notes',

			'finance_transactions' =>
				$wpdb->prefix
				. 'tutorhelper_pro_finance_transactions',

			'payment_history' =>
				$wpdb->prefix
				. 'tutorhelper_pro_payment_history',

			'booking_finance' =>
				$wpdb->prefix
				. 'tutorhelper_pro_booking_finance',

			'credit_refund_requests' =>
				$wpdb->prefix
				. 'tutorhelper_pro_credit_refund_requests',

			'payment_requests' =>
				$wpdb->prefix
				. 'tutorhelper_pro_payment_requests',

			'onboarding_questions' =>
				$wpdb->prefix
				. 'tutorhelper_pro_onboarding_questions',

			'onboarding_answers' =>
				$wpdb->prefix
				. 'tutorhelper_pro_onboarding_answers',

		);

		return isset( $tables[ $table ] )
			? $tables[ $table ]
			: '';
	}
}
