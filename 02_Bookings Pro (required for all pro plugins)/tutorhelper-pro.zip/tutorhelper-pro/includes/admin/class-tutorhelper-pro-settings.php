<?php
/**
 * TutorHelper Pro settings integration.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Extends the TutorHelper Core Settings screen.
 */
class TutorHelper_Pro_Settings {

	/**
	 * Pro licence tab key.
	 */
	const LICENSE_TAB = 'pro-license';

    /**
     * Online Lessons settings tab key.
     */
    const ONLINE_LESSONS_TAB =
        'online-lessons';


    /**
     * Online Lessons settings save action.
     */
    const SAVE_ONLINE_LESSONS_ACTION =
        'tutorhelper_pro_save_online_lessons';

    /**
     * Licence activation action.
     */
    const ACTIVATE_ACTION =
        'tutorhelper_pro_activate_license';

    /**
     * Licence validation action.
     */
    const VALIDATE_ACTION =
        'tutorhelper_pro_validate_license';

    /**
     * Licence deactivation action.
     */
    const DEACTIVATE_ACTION =
        'tutorhelper_pro_deactivate_license';

    /**
     * Saved licence-key removal action.
     */
    const REMOVE_KEY_ACTION =
        'tutorhelper_pro_remove_license_key';

    /**
     * Daily licence validation hook.
     */
    const LICENSE_CRON_HOOK =
        'tutorhelper_pro_daily_license_check';


    /**
	 * Branding settings tab key.
	 */
	const BRANDING_TAB =
		'branding';

    /**
     * Payments settings tab key.
     *
     * @var string
     */
    const PAYMENTS_TAB =
        'payments';

    /**
     * Payment settings save action.
     *
     * @var string
     */
    const SAVE_PAYMENTS_ACTION =
        'tutorhelper_pro_save_payments';


	/**
	 * Branding save action.
	 */
	const SAVE_BRANDING_ACTION =
		'tutorhelper_pro_save_branding';

    /**
     * Branding colour reset action.
     */
    const RESET_BRANDING_COLOURS_ACTION =
        'tutorhelper_pro_reset_branding_colours';



	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {

        add_action(
            'admin_enqueue_scripts',
            array(
                __CLASS__,
                'enqueue_branding_assets',
            )
        );


        add_filter(
            'tutorhelper_settings_tabs',
            array(
                __CLASS__,
                'add_settings_tabs',
            )
        );

        add_action(
            'tutorhelper_settings_render_tab',
            array(
                __CLASS__,
                'render_settings_tab',
            )
        );

        add_action(
            'admin_post_' . self::ACTIVATE_ACTION,
            array(
                __CLASS__,
                'handle_activate',
            )
        );

        add_action(
            'admin_post_' . self::VALIDATE_ACTION,
            array(
                __CLASS__,
                'handle_validate',
            )
        );

        add_action(
            'admin_post_' . self::DEACTIVATE_ACTION,
            array(
                __CLASS__,
                'handle_deactivate',
            )
        );

        add_action(
            'admin_post_' . self::REMOVE_KEY_ACTION,
            array(
                __CLASS__,
                'handle_remove_key',
            )
        );

        add_action(
            self::LICENSE_CRON_HOOK,
            array(
                __CLASS__,
                'daily_validate_license',
            )
        );

        self::schedule_license_validation();

        add_action(
            'admin_post_'
                . self::SAVE_ONLINE_LESSONS_ACTION,
            array(
                __CLASS__,
                'handle_save_online_lessons',
            )
        );

        add_action(
            'admin_post_'
                . self::SAVE_BRANDING_ACTION,
            array(
                __CLASS__,
                'handle_save_branding',
            )
        );

        add_action(
            'admin_post_'
                . self::SAVE_PAYMENTS_ACTION,
            array(
                __CLASS__,
                'handle_save_payments',
            )
        );

        add_action(
            'admin_post_'
                . self::RESET_BRANDING_COLOURS_ACTION,
            array(
                __CLASS__,
                'handle_reset_branding_colours',
            )
        );


    }

	/**
	 * Add TutorHelper Pro tabs to Core Settings.
	 *
	 * @param array $tabs Existing settings tabs.
	 * @return array
	 */
	public static function add_settings_tabs(
		$tabs
	) {


		$tabs[ self::LICENSE_TAB ] = array(
			'label' => __(
				'Pro Licence',
				'tutorhelper-pro'
			),

			'icon' =>
				'dashicons-admin-network',
		);

        if (
            TutorHelper_Pro_License::is_active()
        ) {
            $tabs[
                self::BRANDING_TAB
            ] =
                array(
                    'label' =>
                        __(
                            'Branding',
                            'tutorhelper-pro'
                        ),

                    'icon' =>
                        'dashicons-art',
                );
            
            $tabs[
                self::PAYMENTS_TAB
            ] = array(
                'label' => __(
                    'Payments',
                    'tutorhelper-pro'
                ),

                'icon' =>
                    'dashicons-money-alt',
            );

            $tabs[
                self::ONLINE_LESSONS_TAB
            ] = array(
                'label' => __(
                    'Online Lessons',
                    'tutorhelper-pro'
                ),

                'icon' =>
                    'dashicons-video-alt3',
            );
        }

		return $tabs;
	}

	/**
	 * Render TutorHelper Pro tab content.
	 *
	 * @param string $selected_tab Selected tab key.
	 * @return void
	 */
	public static function render_settings_tab(
		$selected_tab
	) {


		if (
            self::LICENSE_TAB
            === $selected_tab
        ) {
            self::render_license_tab();
            return;
        }

        if (
            self::BRANDING_TAB
            === $selected_tab
            && TutorHelper_Pro_License::
                is_active()
        ) {

            self::render_branding_tab();

            return;
        }

        if (
            self::PAYMENTS_TAB
            === $selected_tab
            && TutorHelper_Pro_License::
                is_active()
        ) {

            self::render_payments_tab();

            return;
        }

        if (
            self::ONLINE_LESSONS_TAB
            === $selected_tab
            && TutorHelper_Pro_License::is_active()
        ) {
            self::render_online_lessons_tab();
        }
	}


    /**
     * Render the Payments settings tab.
     *
     * @return void
     */
    private static function render_payments_tab() {

        $providers =
            TutorHelper_Pro_Payment_Settings::
                get_providers();

        $mode =
            TutorHelper_Pro_Payment_Settings::
                get_stripe_mode();

        $webhook_url =
            TutorHelper_Pro_Payment_Settings::
                get_stripe_webhook_url();

        ?>
        <section class="tutorhelper-main-section">

            <header
                class="
                    tutorhelper-main-section__header
                    is-compact
                "
            >
                <div
                    class="
                        tutorhelper-main-section__header-content
                    "
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Payments',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        echo esc_html__(
                            'Choose how students can pay for TutorHelper bookings.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="
                    tutorhelper-main-section__body
                    tutorhelper-settings-section__body
                "
            >

                <?php
                self::render_payments_notice();
                ?>

                <div class="tutorhelper-pro-payment-section">

                    <h3>
                        <?php
                        echo esc_html__(
                            'Payment providers',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h3>

                    <div
                        class="
                            tutorhelper-pro-payment-providers
                        "
                    >
                        <?php
                        foreach (
                            $providers
                            as $provider
                        ) {
                            self::
                                render_payment_provider_card(
                                    $provider
                                );
                        }
                        ?>
                    </div>

                </div>

                <div class="tutorhelper-pro-payment-section">

                    <h3>
                        <?php
                        echo esc_html__(
                            'Stripe configuration',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h3>

                    <p class="description">
                        <?php
                        echo esc_html__(
                            'Stripe Checkout securely handles card details on Stripe’s website. TutorHelper never stores card information.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                    <form
                        method="post"
                        action="<?php
                            echo esc_url(
                                admin_url(
                                    'admin-post.php'
                                )
                            );
                        ?>"
                        class="tutorhelper-settings-form"
                    >

                        <input
                            type="hidden"
                            name="action"
                            value="<?php
                                echo esc_attr(
                                    self::
                                        SAVE_PAYMENTS_ACTION
                                );
                            ?>"
                        />

                        <?php
                        wp_nonce_field(
                            self::
                                SAVE_PAYMENTS_ACTION,
                            'tutorhelper_pro_payments_nonce'
                        );
                        ?>

                        <?php
                        self::
                            render_stripe_mode_control(
                                $mode
                            );

                        self::
                            render_stripe_credentials(
                                'test'
                            );

                        self::
                            render_stripe_credentials(
                                'live'
                            );
                        ?>

                        <div
                            class="
                                tutorhelper-input-field
                                is-full-width
                            "
                        >
                            <label>
                                <?php
                                echo esc_html__(
                                    'Webhook endpoint',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </label>

                            <input
                                type="url"
                                class="
                                    tutorhelper-admin-control
                                    tutorhelper-pro-webhook-url
                                "
                                value="<?php
                                    echo esc_attr(
                                        $webhook_url
                                    );
                                ?>"
                                readonly
                            />

                            <p class="description">
                                <?php
                                echo esc_html__(
                                    'Keep this endpoint handy. Stripe webhook processing will be enabled in the next payment setup stage.',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </p>
                        </div>

                        <div
                            class="
                                tutorhelper-settings-form__actions
                            "
                        >
                            <button
                                type="submit"
                                class="
                                    button
                                    tutorhelper-admin-button
                                    tutorhelper-admin-button--primary
                                "
                            >
                                <?php
                                echo esc_html__(
                                    'Save payment settings',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </button>
                        </div>

                    </form>

                </div>

            </div>

        </section>
        <?php
    }


    /**
     * Render one payment provider card.
     *
     * @param array $provider Provider data.
     *
     * @return void
     */
    private static function render_payment_provider_card(
        $provider
    ) {

        $is_available =
            TutorHelper_Pro_Payment_Settings::
                STATUS_AVAILABLE
            === $provider['status'];

        ?>
        <div
            class="
                tutorhelper-pro-payment-provider
                <?php
                echo $is_available
                    ? 'is-available'
                    : 'is-coming-soon';
                ?>
            "
        >

            <div
                class="
                    tutorhelper-pro-payment-provider__heading
                "
            >
                <h4>
                    <?php
                    echo esc_html(
                        $provider['name']
                    );
                    ?>
                </h4>

                <span
                    class="
                        tutorhelper-pro-payment-provider__status
                    "
                >
                    <?php
                    echo esc_html(
                        $is_available
                            ? __(
                                'Available',
                                'tutorhelper-pro'
                            )
                            : __(
                                'Coming soon',
                                'tutorhelper-pro'
                            )
                    );
                    ?>
                </span>
            </div>

            <p>
                <?php
                echo esc_html(
                    $provider['description']
                );
                ?>
            </p>

        </div>
        <?php
    }


    /**
     * Render Stripe mode controls.
     *
     * @param string $mode Active Stripe mode.
     *
     * @return void
     */
    private static function render_stripe_mode_control(
        $mode
    ) {
        ?>
        <div class="tutorhelper-pro-payment-mode">

            <h4>
                <?php
                echo esc_html__(
                    'Stripe mode',
                    'tutorhelper-pro'
                );
                ?>
            </h4>

            <label>
                <input
                    type="radio"
                    name="stripe_mode"
                    value="test"
                    <?php
                    checked(
                        'test',
                        $mode
                    );
                    ?>
                />

                <?php
                echo esc_html__(
                    'Test mode',
                    'tutorhelper-pro'
                );
                ?>
            </label>

            <label>
                <input
                    type="radio"
                    name="stripe_mode"
                    value="live"
                    <?php
                    checked(
                        'live',
                        $mode
                    );
                    ?>
                />

                <?php
                echo esc_html__(
                    'Live mode',
                    'tutorhelper-pro'
                );
                ?>
            </label>

            <p class="description">
                <?php
                echo esc_html__(
                    'Use Test mode while configuring Stripe. Switch to Live mode only when live keys and a live webhook are ready.',
                    'tutorhelper-pro'
                );
                ?>
            </p>

        </div>
        <?php
    }


    /**
     * Render Stripe credential controls for one mode.
     *
     * @param string $mode test|live.
     *
     * @return void
     */
    private static function render_stripe_credentials(
        $mode
    ) {

        $is_live =
            'live' === $mode;

        $label =
            $is_live
                ? __(
                    'Live credentials',
                    'tutorhelper-pro'
                )
                : __(
                    'Test credentials',
                    'tutorhelper-pro'
                );

        $secret_field =
            $is_live
                ? 'stripe_live_secret'
                : 'stripe_test_secret';

        $webhook_field =
            $is_live
                ? 'stripe_live_webhook_secret'
                : 'stripe_test_webhook_secret';

        $secret_constant =
            $is_live
                ? 'TUTORHELPER_PRO_STRIPE_LIVE_SECRET_KEY'
                : 'TUTORHELPER_PRO_STRIPE_TEST_SECRET_KEY';

        $webhook_constant =
            $is_live
                ? 'TUTORHELPER_PRO_STRIPE_LIVE_WEBHOOK_SECRET'
                : 'TUTORHELPER_PRO_STRIPE_TEST_WEBHOOK_SECRET';

        ?>
        <div class="tutorhelper-pro-payment-credentials">

            <h4>
                <?php
                echo esc_html(
                    $label
                );
                ?>
            </h4>

            <?php
            self::render_stripe_secret_field(
                $secret_field,
                __(
                    'Secret key',
                    'tutorhelper-pro'
                ),
                'secret_key',
                $mode,
                $secret_constant
            );

            self::render_stripe_secret_field(
                $webhook_field,
                __(
                    'Webhook signing secret',
                    'tutorhelper-pro'
                ),
                'webhook_secret',
                $mode,
                $webhook_constant
            );
            ?>

        </div>
        <?php
    }

    /**
     * Render one secret credential field.
     *
     * @param string $field_name Form field name.
     * @param string $label      Field label.
     * @param string $type       Credential type.
     * @param string $mode       Stripe mode.
     * @param string $constant   wp-config constant.
     *
     * @return void
     */
    private static function render_stripe_secret_field(
        $field_name,
        $label,
        $type,
        $mode,
        $constant
    ) {

        $managed_by_config =
            defined( $constant );

        $masked =
            TutorHelper_Pro_Payment_Settings::
                get_masked_credential(
                    $type,
                    $mode
                );

        ?>
        <div
            class="
                tutorhelper-input-field
                is-full-width
            "
        >
            <label
                for="<?php
                    echo esc_attr(
                        $field_name
                    );
                ?>"
            >
                <?php
                echo esc_html(
                    $label
                );
                ?>
            </label>

            <?php
            if ( $managed_by_config ) {
                ?>

                <input
                    type="text"
                    class="tutorhelper-admin-control"
                    value="<?php
                        echo esc_attr(
                            $masked
                        );
                    ?>"
                    disabled
                />

                <p class="description">
                    <?php
                    echo esc_html__(
                        'Managed in wp-config.php.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

                <?php
            } else {
                ?>

                <input
                    type="password"
                    id="<?php
                        echo esc_attr(
                            $field_name
                        );
                    ?>"
                    name="<?php
                        echo esc_attr(
                            $field_name
                        );
                    ?>"
                    class="tutorhelper-admin-control"
                    value=""
                    autocomplete="new-password"
                    placeholder="<?php
                        echo esc_attr(
                            $masked
                                ? sprintf(
                                    __(
                                        'Saved: %s',
                                        'tutorhelper-pro'
                                    ),
                                    $masked
                                )
                                : __(
                                    'Not configured',
                                    'tutorhelper-pro'
                                )
                        );
                    ?>"
                />

                <p class="description">
                    <?php
                    echo esc_html__(
                        'Leave blank to keep the saved credential.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

                <?php
                if ( $masked ) {
                    ?>
                    <label>
                        <input
                            type="checkbox"
                            name="<?php
                                echo esc_attr(
                                    $field_name
                                    . '_remove'
                                );
                            ?>"
                            value="1"
                        />

                        <?php
                        echo esc_html__(
                            'Remove saved credential',
                            'tutorhelper-pro'
                        );
                        ?>
                    </label>
                    <?php
                }
            }
            ?>

        </div>
        <?php
    }


    /**
     * Save payment settings.
     *
     * @return void
     */
    public static function handle_save_payments() {

        if (
            ! current_user_can(
                'manage_options'
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to change these settings.',
                    'tutorhelper-pro'
                )
            );
        }

        check_admin_referer(
            self::SAVE_PAYMENTS_ACTION,
            'tutorhelper_pro_payments_nonce'
        );

        TutorHelper_Pro_Payment_Settings::
            save(
                $_POST
            );

        $url = add_query_arg(
            array(
                'page' =>
                    TutorHelper_Settings::
                        PAGE_SLUG,

                'tab' =>
                    self::PAYMENTS_TAB,

                'tutorhelper_pro_payments_status' =>
                    'saved',
            ),
            admin_url(
                'admin.php'
            )
        );

        wp_safe_redirect(
            $url
        );

        exit;
    }


    /**
     * Render payment settings notice.
     *
     * @return void
     */
    private static function render_payments_notice() {

        $status = isset(
            $_GET[
                'tutorhelper_pro_payments_status'
            ]
        )
            ? sanitize_key(
                wp_unslash(
                    $_GET[
                        'tutorhelper_pro_payments_status'
                    ]
                )
            )
            : '';

        if ( 'saved' !== $status ) {
            return;
        }

        ?>
        <div class="notice notice-success inline">
            <p>
                <?php
                echo esc_html__(
                    'Payment settings saved.',
                    'tutorhelper-pro'
                );
                ?>
            </p>
        </div>
        <?php
    }


    /**
     * Render the Branding settings tab.
     *
     * @return void
     */
    private static function render_branding_tab() {

        $settings =
            TutorHelper_Pro_Branding::
                get_all();

        $logo_url =
            TutorHelper_Pro_Branding::
                get_image_url(
                    'logo_attachment_id',
                    'medium'
                );

        $banner_url =
            TutorHelper_Pro_Branding::
                get_image_url(
                    'email_banner_attachment_id',
                    'large'
                );

        ?>
        <section class="tutorhelper-main-section">

            <header
                class="
                    tutorhelper-main-section__header
                    is-compact
                "
            >
                <div
                    class="tutorhelper-main-section__header-content"
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Branding',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        echo esc_html__(
                            'Apply your business identity consistently to TutorHelper emails and student-facing pages.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="
                    tutorhelper-main-section__body
                    tutorhelper-settings-section__body
                "
            >

                <?php
                self::render_branding_notice();
                ?>
                <div class="tutorhelper-pro-branding-actions">

                <form
                    method="post"
                    action="<?php
                        echo esc_url(
                            admin_url(
                                'admin-post.php'
                            )
                        );
                    ?>"
                    class="
                        tutorhelper-settings-form
                        tutorhelper-pro-branding-form
                    "
                >

                    <input
                        type="hidden"
                        name="action"
                        value="<?php
                            echo esc_attr(
                                self::
                                    SAVE_BRANDING_ACTION
                            );
                        ?>"
                    />

                    <?php
                    wp_nonce_field(
                        self::
                            SAVE_BRANDING_ACTION,
                        'tutorhelper_pro_branding_nonce'
                    );

                    self::render_branding_identity(
                        $settings,
                        $logo_url,
                        $banner_url
                    );

                    self::render_branding_colors(
                        $settings
                    );

                    self::render_email_branding(
                        $settings
                    );

                    self::render_student_branding(
                        $settings
                    );
                    ?>

                    <div
                        class="tutorhelper-settings-form__actions"
                    >
                        <button
                            type="submit"
                            class="
                                button
                                tutorhelper-admin-button
                                tutorhelper-admin-button--primary
                            "
                        >
                            <?php
                            echo esc_html__(
                                'Save Branding',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>
                    </div>

                </form>

                <form
                    method="post"
                    action="<?php
                        echo esc_url(
                            admin_url(
                                'admin-post.php'
                            )
                        );
                    ?>"
                    class="tutorhelper-pro-branding-reset-form"
                >
                    <input
                        type="hidden"
                        name="action"
                        value="<?php
                            echo esc_attr(
                                self::
                                    RESET_BRANDING_COLOURS_ACTION
                            );
                        ?>"
                    />

                    <?php
                    wp_nonce_field(
                        self::
                            RESET_BRANDING_COLOURS_ACTION,
                        'tutorhelper_pro_reset_branding_colours_nonce'
                    );
                    ?>

                    <button
                        type="submit"
                        class="
                            button
                            tutorhelper-admin-button
                        "
                    >
                        <?php
                        echo esc_html__(
                            'Reset Colours',
                            'tutorhelper-pro'
                        );
                        ?>
                    </button>
                </form>
                </div>

            </div>
        </section>
        <?php
    }

    


    /**
     * Render business identity controls.
     *
     * @param array  $settings   Branding settings.
     * @param string $logo_url   Logo URL.
     * @param string $banner_url Email banner URL.
     *
     * @return void
     */
    private static function render_branding_identity(
        $settings,
        $logo_url,
        $banner_url
    ) {
        ?>
        <div class="tutorhelper-pro-branding-section">

            <h3>
                <?php
                echo esc_html__(
                    'Business identity',
                    'tutorhelper-pro'
                );
                ?>
            </h3>

            <div class="tutorhelper-input-fields">

                <div
                    class="
                        tutorhelper-input-field
                        is-full-width
                    "
                >
                    <label
                        for="tutorhelper_pro_business_name"
                    >
                        <?php
                        echo esc_html__(
                            'Business or tutor name',
                            'tutorhelper-pro'
                        );
                        ?>
                    </label>

                    <input
                        type="text"
                        id="tutorhelper_pro_business_name"
                        name="business_name"
                        class="tutorhelper-admin-control"
                        value="<?php
                            echo esc_attr(
                                $settings[
                                    'business_name'
                                ]
                            );
                        ?>"
                        data-branding-business-name
                    />
                </div>

                <?php
                self::render_branding_image_control(
                    'logo_attachment_id',
                    __(
                        'Logo',
                        'tutorhelper-pro'
                    ),
                    $settings[
                        'logo_attachment_id'
                    ],
                    $logo_url,
                    __(
                        'Choose logo',
                        'tutorhelper-pro'
                    )
                );

                self::render_branding_image_control(
                    'email_banner_attachment_id',
                    __(
                        'Email banner image',
                        'tutorhelper-pro'
                    ),
                    $settings[
                        'email_banner_attachment_id'
                    ],
                    $banner_url,
                    __(
                        'Choose banner',
                        'tutorhelper-pro'
                    )
                );
                ?>

                <div class="tutorhelper-input-field">
                    <label
                        for="tutorhelper_pro_branding_tagline"
                    >
                        <?php
                        echo esc_html__(
                            'Tagline',
                            'tutorhelper-pro'
                        );
                        ?>
                    </label>

                    <input
                        type="text"
                        id="tutorhelper_pro_branding_tagline"
                        name="tagline"
                        class="tutorhelper-admin-control"
                        value="<?php
                            echo esc_attr(
                                $settings[
                                    'tagline'
                                ]
                            );
                        ?>"
                        data-branding-tagline
                    />
                </div>

                <div class="tutorhelper-input-field">
                    <label
                        for="tutorhelper_pro_branding_website"
                    >
                        <?php
                        echo esc_html__(
                            'Website',
                            'tutorhelper-pro'
                        );
                        ?>
                    </label>

                    <input
                        type="url"
                        id="tutorhelper_pro_branding_website"
                        name="website_url"
                        class="tutorhelper-admin-control"
                        value="<?php
                            echo esc_attr(
                                $settings[
                                    'website_url'
                                ]
                            );
                        ?>"
                    />
                </div>

            </div>
        </div>
        <?php
    }


    /**
     * Render a media-library image control.
     *
     * @param string $key           Setting key.
     * @param string $label         Field label.
     * @param int    $attachment_id Attachment ID.
     * @param string $image_url     Current image URL.
     * @param string $button_label  Choose button label.
     *
     * @return void
     */
    private static function render_branding_image_control(
        $key,
        $label,
        $attachment_id,
        $image_url,
        $button_label
    ) {
        ?>
        <div
            class="
                tutorhelper-input-field
                is-full-width
                tutorhelper-pro-branding-image
            "
            data-tutorhelper-branding-image
            data-branding-image-type="<?php
                echo esc_attr(
                    $key
                );
            ?>"
        >
            <label>
                <?php
                echo esc_html(
                    $label
                );
                ?>
            </label>

            <input
                type="hidden"
                name="<?php
                    echo esc_attr(
                        $key
                    );
                ?>"
                value="<?php
                    echo esc_attr(
                        absint(
                            $attachment_id
                        )
                    );
                ?>"
                data-branding-image-id
            />

            <div
                class="tutorhelper-pro-branding-image__preview"
                data-branding-image-preview
            >
                <?php
                if ( $image_url ) :
                    ?>
                    <img
                        src="<?php
                            echo esc_url(
                                $image_url
                            );
                        ?>"
                        alt=""
                    />
                <?php endif; ?>
            </div>

            <div
                class="tutorhelper-pro-branding-image__actions"
            >
                <button
                    type="button"
                    class="
                        button
                        tutorhelper-admin-button
                    "
                    data-branding-image-select
                >
                    <?php
                    echo esc_html(
                        $button_label
                    );
                    ?>
                </button>

                <button
                    type="button"
                    class="
                        button
                        tutorhelper-admin-button
                    "
                    data-branding-image-remove
                    <?php
                    disabled(
                        ! $attachment_id
                    );
                    ?>
                >
                    <?php
                    echo esc_html__(
                        'Remove',
                        'tutorhelper-pro'
                    );
                    ?>
                </button>
            </div>
        </div>
        <?php
    }


    /**
     * Render brand colour and typography controls.
     *
     * @param array $settings Branding settings.
     *
     * @return void
     */
    private static function render_branding_colors(
        $settings
    ) {

        $font_options =
            TutorHelper_Pro_Branding::
                get_font_options();

        ?>
        <div class="tutorhelper-pro-branding-section">

            <h3>
                <?php
                echo esc_html__(
                    'Brand colours and typography',
                    'tutorhelper-pro'
                );
                ?>
            </h3>

            <div class="tutorhelper-pro-branding-customiser">

                <div
                    class="tutorhelper-pro-branding-customiser__controls"
                >

                    <div
                        class="tutorhelper-pro-branding-grid"
                    >

                        <?php
                        self::render_branding_color_control(
                            'primary_color',
                            __(
                                'Primary colour',
                                'tutorhelper-pro'
                            ),
                            $settings['primary_color'],
                            __(
                                'Used for prominent branded elements such as selected dates and times, primary booking buttons and links in branded emails.',
                                'tutorhelper-pro'
                            )
                        );

                        self::render_branding_color_control(
                            'accent_color',
                            __(
                                'Accent colour',
                                'tutorhelper-pro'
                            ),
                            $settings['accent_color'],
                            __(
                                'Used for smaller highlights such as the email accent line, the current-day calendar outline and other secondary emphasis.',
                                'tutorhelper-pro'
                            )
                        );

                        self::render_branding_color_control(
                            'text_color',
                            __(
                                'Main text colour',
                                'tutorhelper-pro'
                            ),
                            $settings['text_color'],
                            __(
                                'Controls the colour of normal body text in branded emails, booking forms and student-facing areas.',
                                'tutorhelper-pro'
                            )
                        );
                        ?>

                        <div class="tutorhelper-input-field">
                            <label for="tutorhelper_pro_text_font">
                                <?php
                                echo esc_html__(
                                    'Main text font',
                                    'tutorhelper-pro'
                                );

                                self::render_branding_help(
                                    __(
                                        'Applies your configured colours and typography to the student dashboard while preserving Booking Type colours, lesson statuses, warnings and cancellation colours.',
                                        'tutorhelper-pro'
                                    )
                                );
                                ?>
                            </label>

                            <select
                                id="tutorhelper_pro_text_font"
                                name="text_font"
                                class="tutorhelper-admin-control"
                                data-branding-preview-text-font
                            >
                                <?php
                                foreach (
                                    $font_options
                                    as $value => $label
                                ) :
                                    ?>
                                    <option
                                        value="<?php
                                            echo esc_attr(
                                                $value
                                            );
                                        ?>"
                                        <?php
                                        selected(
                                            $settings[
                                                'text_font'
                                            ],
                                            $value
                                        );
                                        ?>
                                    >
                                        <?php
                                        echo esc_html(
                                            $label
                                        );
                                        ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <?php
                        self::render_branding_color_control(
                            'heading_color',
                            __(
                                'Heading colour',
                                'tutorhelper-pro'
                            ),
                            $settings['heading_color'],
                            __(
                                'Controls main headings and section headings in branded emails, booking forms and student-facing areas.',
                                'tutorhelper-pro'
                            )
                        );
                        ?>

                        <div class="tutorhelper-input-field">
                            <label for="tutorhelper_pro_heading_font">
                                <?php
                                echo esc_html__(
                                    'Heading font',
                                    'tutorhelper-pro'
                                );

                                self::render_branding_help(
                                    __(
                                        'Used for main headings and section headings in branded emails, booking forms and student-facing areas.',
                                        'tutorhelper-pro'
                                    )
                                );
                                ?>
                            </label>

                            <select
                                id="tutorhelper_pro_heading_font"
                                name="heading_font"
                                class="tutorhelper-admin-control"
                                data-branding-preview-heading-font
                            >
                                <?php
                                foreach (
                                    $font_options
                                    as $value => $label
                                ) :
                                    ?>
                                    <option
                                        value="<?php
                                            echo esc_attr(
                                                $value
                                            );
                                        ?>"
                                        <?php
                                        selected(
                                            $settings[
                                                'heading_font'
                                            ],
                                            $value
                                        );
                                        ?>
                                    >
                                        <?php
                                        echo esc_html(
                                            $label
                                        );
                                        ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <?php
                        self::render_branding_color_control(
                            'background_color',
                            __(
                                'Email background colour',
                                'tutorhelper-pro'
                            ),
                            $settings['background_color'],
                            __(
                                'Controls the background surrounding the main content card in branded HTML emails.',
                                'tutorhelper-pro'
                            )
                        );

                        self::render_branding_color_control(
                            'form_background_color',
                            __(
                                'Form background colour',
                                'tutorhelper-pro'
                            ),
                            $settings['form_background_color'],
                            __(
                                'Controls the outer background of the student booking form and student dashboard.',
                                'tutorhelper-pro'
                            )
                        );

                        self::render_branding_color_control(
                            'form_box_color',
                            __(
                                'Form boxes colour',
                                'tutorhelper-pro'
                            ),
                            $settings['form_box_color'],
                            __(
                                'Controls content panels in the student booking form and student dashboard, including booking sections, summaries and lesson cards.',
                                'tutorhelper-pro'
                            )
                        );

                        self::render_branding_color_control(
                            'calendar_color',
                            __(
                                'Calendar colour',
                                'tutorhelper-pro'
                            ),
                            $settings['calendar_color'],
                            __(
                                'Controls the calendar heading area and dates which are not currently selected. Available dates retain their green availability colour.',
                                'tutorhelper-pro'
                            )
                        );

                        self::render_branding_color_control(
                            'button_text_color',
                            __(
                                'Button text colour',
                                'tutorhelper-pro'
                            ),
                            $settings['button_text_color'],
                            __(
                                'Controls text shown over the primary brand colour, including booking buttons and selected date or time controls.',
                                'tutorhelper-pro'
                            )
                        );
                        ?>

                    </div>

                </div>

                <div
                    class="tutorhelper-pro-branding-customiser__preview"
                >
                    <?php
                    self::render_branding_preview(
                        $settings
                    );
                    ?>
                </div>

            </div>

        </div>
        <?php
    }


    /**
     * Render a colour field.
     *
     * @param string $key   Setting key.
     * @param string $label Field label.
     * @param string $value Current colour.
     *
     * @return void
     */
    private static function render_branding_color_control(
        $key,
        $label,
        $value,
        $help_text = ''
    ) {
        ?>
        <div
            class="tutorhelper-input-field tutorhelper-pro-branding-color"
        >
            <label
                for="tutorhelper_pro_<?php
                    echo esc_attr(
                        $key
                    );
                ?>"
            >
                <?php
                echo esc_html(
                    $label
                );
                self::render_branding_help(
                    $help_text
                );
                ?>
            </label>

            <div
                class="tutorhelper-pro-branding-color__control"
            >
                <input
                    type="color"
                    id="tutorhelper_pro_<?php
                        echo esc_attr(
                            $key
                        );
                    ?>"
                    name="<?php
                        echo esc_attr(
                            $key
                        );
                    ?>"
                    value="<?php
                        echo esc_attr(
                            $value
                        );
                    ?>"
                    data-branding-color="<?php
                        echo esc_attr(
                            $key
                        );
                    ?>"
                />

                <code
                    data-branding-color-value="<?php
                        echo esc_attr(
                            $key
                        );
                    ?>"
                >
                    <?php
                    echo esc_html(
                        $value
                    );
                    ?>
                </code>
            </div>
        </div>
        <?php
    }


    /**
     * Render live branding preview.
     *
     * @param array $settings Branding settings.
     *
     * @return void
     */
    private static function render_branding_preview(
        $settings
    ) {

        $logo_url =
            TutorHelper_Pro_Branding::
                get_image_url(
                    'logo_attachment_id',
                    'medium'
                );

        $banner_url =
            TutorHelper_Pro_Branding::
                get_image_url(
                    'email_banner_attachment_id',
                    'large'
                );

        ?>
        <div
            class="tutorhelper-pro-branding-preview"
            data-branding-preview
            style="
                --branding-primary: <?php
                    echo esc_attr(
                        $settings[
                            'primary_color'
                        ]
                    );
                ?>;
                --branding-accent: <?php
                    echo esc_attr(
                        $settings[
                            'accent_color'
                        ]
                    );
                ?>;
                --branding-text: <?php
                    echo esc_attr(
                        $settings[
                            'text_color'
                        ]
                    );
                ?>;
                --branding-heading: <?php
                    echo esc_attr(
                        $settings[
                            'heading_color'
                        ]
                    );
                ?>;
                --branding-background: <?php
                    echo esc_attr(
                        $settings[
                            'background_color'
                        ]
                    );
                ?>;
                --branding-text-font: <?php
                    echo esc_attr(
                        $settings[
                            'text_font'
                        ]
                    );
                ?>;
                --branding-heading-font: <?php
                    echo esc_attr(
                        $settings[
                            'heading_font'
                        ]
                    );
                ?>;
            "
        >

            <div
                class="
                    tutorhelper-pro-branding-preview__banner
                    <?php
                    echo $banner_url
                        ? ''
                        : 'is-empty';
                    ?>
                "
                data-branding-preview-banner
            >
                <?php
                if ( $banner_url ) :
                    ?>
                    <img
                        src="<?php
                            echo esc_url(
                                $banner_url
                            );
                        ?>"
                        alt=""
                    />
                <?php else : ?>
                    <span>
                        <?php
                        echo esc_html__(
                            'Email banner',
                            'tutorhelper-pro'
                        );
                        ?>
                    </span>
                <?php endif; ?>
            </div>

            <div
                class="tutorhelper-pro-branding-preview__body"
            >
                <div
                    class="tutorhelper-pro-branding-preview__accent"
                ></div>

                <h4
                    data-branding-preview-heading
                >
                    <?php
                    echo esc_html__(
                        'Your lesson is confirmed',
                        'tutorhelper-pro'
                    );
                    ?>
                </h4>

                <p>
                    <?php
                    echo esc_html__(
                        'Hello Alex, your lesson booking has been confirmed. You can find the lesson details and joining information below.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

                <button
                    type="button"
                    class="tutorhelper-pro-branding-preview__button"
                >
                    Click a button
                </button>
            </div>

            <div
                class="tutorhelper-pro-branding-preview__footer"
            >
                <div
                    class="tutorhelper-pro-branding-preview__logo"
                    data-branding-preview-logo
                >
                    <?php
                    if ( $logo_url ) :
                        ?>
                        <img
                            src="<?php
                                echo esc_url(
                                    $logo_url
                                );
                            ?>"
                            alt=""
                        />
                    <?php endif; ?>
                </div>

                <div>
                    <strong
                        data-branding-preview-business-name
                    >
                        <?php
                        echo esc_html(
                            $settings[
                                'business_name'
                            ]
                        );
                        ?>
                    </strong>

                    <p
                        data-branding-preview-tagline
                    >
                        <?php
                        echo esc_html(
                            $settings[
                                'tagline'
                            ]
                        );
                        ?>
                    </p>
                </div>
            </div>

        </div>
        <?php
    }


    /**
     * Render email-specific branding controls.
     *
     * @param array $settings Branding settings.
     *
     * @return void
     */
    private static function render_email_branding(
        $settings
    ) {
        ?>
        <div class="tutorhelper-pro-branding-section">

            <h3>
                <?php
                echo esc_html__(
                    'Email branding',
                    'tutorhelper-pro'
                );
                ?>
            </h3>

            <div class="tutorhelper-pro-branding-options">

                <label>
                    <input
                        type="checkbox"
                        name="email_show_banner"
                        value="1"
                        <?php
                        checked(
                            ! empty(
                                $settings[
                                    'email_show_banner'
                                ]
                            )
                        );
                        ?>
                    />

                    <?php
                    echo esc_html__(
                        'Show email banner at the top of emails',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="email_show_logo_footer"
                        value="1"
                        <?php
                        checked(
                            ! empty(
                                $settings[
                                    'email_show_logo_footer'
                                ]
                            )
                        );
                        ?>
                    />

                    <?php
                    echo esc_html__(
                        'Show logo in the email footer',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="email_show_business_name"
                        value="1"
                        <?php
                        checked(
                            ! empty(
                                $settings[
                                    'email_show_business_name'
                                ]
                            )
                        );
                        ?>
                    />

                    <?php
                    echo esc_html__(
                        'Show business name in emails',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

            </div>

            <div
                class="
                    tutorhelper-input-field
                    is-full-width
                "
            >
                <label
                    for="tutorhelper_pro_email_footer_text"
                >
                    <?php
                    echo esc_html__(
                        'Footer text',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

                <textarea
                    id="tutorhelper_pro_email_footer_text"
                    name="email_footer_text"
                    rows="3"
                    class="tutorhelper-admin-control"
                ><?php
                    echo esc_textarea(
                        $settings[
                            'email_footer_text'
                        ]
                    );
                ?></textarea>
            </div>

            <div
                class="
                    tutorhelper-input-field
                    is-full-width
                "
            >
                <label
                    for="tutorhelper_pro_email_footer_url"
                >
                    <?php
                    echo esc_html__(
                        'Footer website or link',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

                <input
                    type="url"
                    id="tutorhelper_pro_email_footer_url"
                    name="email_footer_url"
                    class="tutorhelper-admin-control"
                    value="<?php
                        echo esc_attr(
                            $settings[
                                'email_footer_url'
                            ]
                        );
                    ?>"
                />
            </div>

        </div>
        <?php
    }


    /**
     * Render student-facing branding controls.
     *
     * @param array $settings Branding settings.
     *
     * @return void
     */
    private static function render_student_branding(
        $settings
    ) {
        ?>
        <div class="tutorhelper-pro-branding-section">

            <h3>
                <?php
                echo esc_html__(
                    'Student-facing branding',
                    'tutorhelper-pro'
                );
                ?>
            </h3>

            <div class="tutorhelper-pro-branding-options">

                <label>
                    <input
                        type="checkbox"
                        name="booking_form_branding"
                        value="1"
                        <?php
                        checked(
                            ! empty(
                                $settings[
                                    'booking_form_branding'
                                ]
                            )
                        );
                        ?>
                    />

                    <?php
                    echo esc_html__(
                        'Apply branding to the student booking form',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="registration_form_branding"
                        value="1"
                        <?php
                        checked(
                            ! empty(
                                $settings[
                                    'registration_form_branding'
                                ]
                            )
                        );
                        ?>
                    />

                    <?php
                    echo esc_html__(
                        'Apply branding to the student registration form',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="student_dashboard_branding"
                        value="1"
                        <?php
                        checked(
                            ! empty(
                                $settings[
                                    'student_dashboard_branding'
                                ]
                            )
                        );
                        ?>
                    />

                    <?php
                    echo esc_html__(
                        'Apply branding to the student dashboard',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="parent_dashboard_branding"
                        value="1"
                        <?php
                        checked(
                            ! empty(
                                $settings[
                                    'parent_dashboard_branding'
                                ]
                            )
                        );
                        ?>
                    />

                    <?php
                    echo esc_html__(
                        'Apply branding to the Parent Dashboard',
                        'tutorhelper-pro'
                    );
                    ?>
                </label>

            </div>
        </div>
        <?php
    }

    /**
     * Save branding settings.
     *
     * @return void
     */
    public static function handle_save_branding() {

        if (
            ! current_user_can(
                'manage_options'
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to change these settings.',
                    'tutorhelper-pro'
                )
            );
        }

        check_admin_referer(
            self::SAVE_BRANDING_ACTION,
            'tutorhelper_pro_branding_nonce'
        );

        TutorHelper_Pro_Branding::
            save(
                $_POST
            );

        $url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Settings::
                            PAGE_SLUG,

                    'tab' =>
                        self::BRANDING_TAB,

                    'tutorhelper_pro_branding_status' =>
                        'saved',
                ),
                admin_url(
                    'admin.php'
                )
            );

        wp_safe_redirect(
            $url
        );

        exit;
    }


    /**
     * Render branding save notice.
     *
     * @return void
     */
    private static function render_branding_notice() {

        $status =
            isset(
                $_GET[
                    'tutorhelper_pro_branding_status'
                ]
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_pro_branding_status'
                        ]
                    )
                )
                : '';

        if (
            ! in_array(
                $status,
                array(
                    'saved',
                    'reset',
                ),
                true
            )
        ) {
            return;
        }

        $message =
            'reset' === $status
                ? __(
                    'Brand colours and typography have been reset to their default values.',
                    'tutorhelper-pro'
                )
                : __(
                    'Branding settings saved.',
                    'tutorhelper-pro'
                );

        ?>
        <div class="notice notice-success inline">
            <p>
                <?php
                echo esc_html(
                    $message
                );
                ?>
            </p>
        </div>
        <?php
    }


    /**
     * Render an accessible help tooltip beside a field label.
     *
     * @param string $help_text Tooltip explanation.
     *
     * @return void
     */
    private static function render_branding_help(
        $help_text
    ) {

        if ( '' === $help_text ) {
            return;
        }

        ?>
        <span class="tutorhelper-pro-branding-help">
            <button
                type="button"
                class="tutorhelper-pro-branding-help__button"
                aria-label="<?php
                    echo esc_attr__(
                        'More information',
                        'tutorhelper-pro'
                    );
                ?>"
            >
                <span
                    class="
                        dashicons
                        dashicons-editor-help
                    "
                    aria-hidden="true"
                ></span>
            </button>

            <span
                class="tutorhelper-pro-branding-help__tooltip"
                role="tooltip"
            >
                <?php
                echo esc_html(
                    $help_text
                );
                ?>
            </span>
        </span>
        <?php
    }


    /**
     * Render the Online Lessons settings tab.
     *
     * @return void
     */
    private static function render_online_lessons_tab() {

        $zoom_url =
            TutorHelper_Pro_Online_Lessons::
                get_zoom_url();

        ?>
        <section class="tutorhelper-main-section">

            <header
                class="
                    tutorhelper-main-section__header
                    is-compact
                "
            >
                <div
                    class="
                        tutorhelper-main-section__header-content
                    "
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Online Lessons',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        echo esc_html__(
                            'Configure the meeting details used for online student lessons.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="
                    tutorhelper-main-section__body
                    tutorhelper-settings-section__body
                "
            >
                <?php
                self::render_online_lessons_notice();
                ?>

                <form
                    method="post"
                    action="<?php
                        echo esc_url(
                            admin_url(
                                'admin-post.php'
                            )
                        );
                    ?>"
                    class="tutorhelper-settings-form"
                >
                    <input
                        type="hidden"
                        name="action"
                        value="<?php
                            echo esc_attr(
                                self::
                                    SAVE_ONLINE_LESSONS_ACTION
                            );
                        ?>"
                    >

                    <?php
                    wp_nonce_field(
                        self::
                            SAVE_ONLINE_LESSONS_ACTION,
                        'tutorhelper_pro_online_lessons_nonce'
                    );
                    ?>

                    <div class="tutorhelper-input-fields">

                        <div
                            class="
                                tutorhelper-input-field
                                is-full-width
                            "
                        >
                            <label
                                for="tutorhelper_pro_zoom_url"
                            >
                                <?php
                                echo esc_html__(
                                    'Zoom meeting link',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </label>

                            <input
                                type="url"
                                id="tutorhelper_pro_zoom_url"
                                name="zoom_url"
                                value="<?php
                                    echo esc_attr(
                                        $zoom_url
                                    );
                                ?>"
                                class="regular-text"
                                placeholder="https://zoom.us/j/..."
                            >

                            <p
                                class="
                                    tutorhelper-settings-field__description
                                "
                            >
                                <?php
                                echo esc_html__(
                                    'Enter the persistent Zoom meeting link students should use for online lessons. Leave this blank if you do not use Zoom.',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </p>
                        </div>

                    </div>

                    <div
                        class="
                            tutorhelper-settings-form__actions
                        "
                    >
                        <?php
                        submit_button(
                            __(
                                'Save Online Lesson Settings',
                                'tutorhelper-pro'
                            ),
                            'primary tutorhelper-action-button',
                            'submit',
                            false
                        );
                        ?>
                    </div>

                </form>

            </div>

        </section>
        <?php
    }

	/**
	 * Render the Pro Licence tab.
	 *
	 * @return void
	 */
	private static function render_license_tab() {
		?>
		<section class="tutorhelper-main-section">

			<header
				class="
					tutorhelper-main-section__header
					is-compact
				"
			>
				<div
					class="
						tutorhelper-main-section__header-content
					"
				>
					<h2>
						<?php
						echo esc_html__(
							'TutorHelper Pro Licence',
							'tutorhelper-pro'
						);
						?>
					</h2>

					<p>
						<?php
						echo esc_html__(
							'Activate and manage the TutorHelper Pro licence for this site.',
							'tutorhelper-pro'
						);
						?>
					</p>
				</div>
			</header>

			<div
                class="
                    tutorhelper-main-section__body
                    tutorhelper-settings-section__body
                "
            >
                <?php
                self::render_notice();

                $status =
                    TutorHelper_Pro_License::get_status();

                $license_key =
                    TutorHelper_Pro_License::get_key();

                self::render_status(
                    $status
                );

                if ( 'active' === $status ) {
                    self::render_expiry();

                    self::render_active_license(
                        $license_key
                    );
                } else {
                    self::render_activation_form(
                        $license_key
                    );

                    if ( '' !== $license_key ) {
                        self::render_remove_key_form();
                    }
                }
                ?>
            </div>

		</section>
		<?php
	}


    /**
     * Render the current licence status.
     *
     * @param string $status Licence status.
     * @return void
     */
    private static function render_status(
        $status
    ) {

        $labels = array(
            'active' => __(
                'Active',
                'tutorhelper-pro'
            ),
            'inactive' => __(
                'Inactive',
                'tutorhelper-pro'
            ),
            'expired' => __(
                'Expired',
                'tutorhelper-pro'
            ),
            'invalid' => __(
                'Invalid',
                'tutorhelper-pro'
            ),
        );

        $label = isset(
            $labels[ $status ]
        )
            ? $labels[ $status ]
            : $labels['inactive'];

        ?>
        <div class="tutorhelper-input-field is-full-width">

            <label>
                <?php
                echo esc_html__(
                    'Licence status',
                    'tutorhelper-pro'
                );
                ?>
            </label>

            <p>
                <strong>
                    <?php
                    echo esc_html(
                        $label
                    );
                    ?>
                </strong>
            </p>

        </div>
        <?php
    }


    /**
     * Render the saved annual renewal date or lifetime status.
     *
     * @return void
     */
    private static function render_expiry() {
        if ( TutorHelper_Pro_License::is_lifetime() ) {
            ?>
            <p>
                <strong><?php esc_html_e( 'Renewal', 'tutorhelper-pro' ); ?>:</strong>
                <?php esc_html_e( 'Lifetime licence', 'tutorhelper-pro' ); ?>
            </p>
            <?php
            return;
        }

        $timestamp = TutorHelper_Pro_License::expiry_timestamp();

        if ( $timestamp ) {
            ?>
            <p>
                <strong><?php esc_html_e( 'Renewal date', 'tutorhelper-pro' ); ?>:</strong>
                <?php echo esc_html( wp_date( get_option( 'date_format' ), $timestamp ) ); ?>
            </p>
            <?php
        }
    }


    /**
     * Render the licence activation form.
     *
     * @param string $license_key Stored licence key.
     * @return void
     */
    private static function render_activation_form(
        $license_key
    ) {
        ?>
        <form
            method="post"
            action="<?php echo esc_url(
                admin_url( 'admin-post.php' )
            ); ?>"
            class="tutorhelper-settings-form"
        >

            <input
                type="hidden"
                name="action"
                value="<?php echo esc_attr(
                    self::ACTIVATE_ACTION
                ); ?>"
            >

            <?php
            wp_nonce_field(
                self::ACTIVATE_ACTION,
                'tutorhelper_pro_license_nonce'
            );
            ?>

            <div class="tutorhelper-input-fields">

                <div
                    class="
                        tutorhelper-input-field
                        is-full-width
                    "
                >

                    <label for="tutorhelper_pro_license_key">
                        <?php
                        echo esc_html__(
                            'Licence key',
                            'tutorhelper-pro'
                        );
                        ?>
                    </label>

                    <input
                        type="text"
                        id="tutorhelper_pro_license_key"
                        name="license_key"
                        value="<?php echo esc_attr(
                            $license_key
                        ); ?>"
                        class="regular-text"
                        autocomplete="off"
                        required
                    >

                    <p
                        class="
                            tutorhelper-settings-field__description
                        "
                    >
                        <?php
                        echo esc_html__(
                            'Enter the TutorHelper Pro licence key supplied with your purchase.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                </div>

            </div>

            <div
                class="
                    tutorhelper-settings-form__actions
                "
            >
                <?php
                submit_button(
                    __(
                        'Activate Licence',
                        'tutorhelper-pro'
                    ),
                    'primary tutorhelper-action-button',
                    'submit',
                    false
                );
                ?>
            </div>

        </form>
        <?php
    }

    /**
     * Render the deliberate saved-key removal control.
     *
     * @return void
     */
    private static function render_remove_key_form() {
        ?>
        <form
            method="post"
            action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
            class="tutorhelper-settings-form"
        >
            <input
                type="hidden"
                name="action"
                value="<?php echo esc_attr( self::REMOVE_KEY_ACTION ); ?>"
            >

            <?php
            wp_nonce_field(
                self::REMOVE_KEY_ACTION,
                'tutorhelper_pro_license_nonce'
            );
            ?>

            <?php
            submit_button(
                __( 'Remove saved key', 'tutorhelper-pro' ),
                'secondary',
                'submit',
                false
            );
            ?>
        </form>
        <?php
    }


    /**
     * Render controls for an active licence.
     *
     * @param string $license_key Stored licence key.
     * @return void
     */
    private static function render_active_license(
        $license_key
    ) {

        $masked_key =
            self::mask_license_key(
                $license_key
            );

        ?>
        <div class="tutorhelper-input-field is-full-width">

            <label>
                <?php
                echo esc_html__(
                    'Licence key',
                    'tutorhelper-pro'
                );
                ?>
            </label>

            <p>
                <code>
                    <?php
                    echo esc_html(
                        $masked_key
                    );
                    ?>
                </code>
            </p>

        </div>

        <div
            class="
                tutorhelper-settings-form__actions
            "
        >

            <form
                method="post"
                action="<?php echo esc_url(
                    admin_url( 'admin-post.php' )
                ); ?>"
                style="display:inline-block;"
            >

                <input
                    type="hidden"
                    name="action"
                    value="<?php echo esc_attr(
                        self::VALIDATE_ACTION
                    ); ?>"
                >

                <?php
                wp_nonce_field(
                    self::VALIDATE_ACTION,
                    'tutorhelper_pro_license_nonce'
                );
                ?>

                <?php
                submit_button(
                    __(
                        'Validate Licence',
                        'tutorhelper-pro'
                    ),
                    'secondary',
                    'submit',
                    false
                );
                ?>

            </form>

            <form
                method="post"
                action="<?php echo esc_url(
                    admin_url( 'admin-post.php' )
                ); ?>"
                style="display:inline-block;"
            >

                <input
                    type="hidden"
                    name="action"
                    value="<?php echo esc_attr(
                        self::DEACTIVATE_ACTION
                    ); ?>"
                >

                <?php
                wp_nonce_field(
                    self::DEACTIVATE_ACTION,
                    'tutorhelper_pro_license_nonce'
                );
                ?>

                <?php
                submit_button(
                    __(
                        'Deactivate Licence',
                        'tutorhelper-pro'
                    ),
                    'secondary',
                    'submit',
                    false
                );
                ?>

            </form>

        </div>
        <?php
    }


    /**
     * Mask a licence key for display.
     *
     * @param string $license_key Licence key.
     * @return string
     */
    private static function mask_license_key(
        $license_key
    ) {

        $license_key =
            (string) $license_key;

        if ( strlen( $license_key ) <= 10 ) {
            return str_repeat(
                '•',
                strlen( $license_key )
            );
        }

        return substr(
            $license_key,
            0,
            5
        )
        . str_repeat(
            '•',
            max(
                4,
                strlen( $license_key ) - 10
            )
        )
        . substr(
            $license_key,
            -5
        );
    }


    /**
     * Save Online Lessons settings.
     *
     * @return void
     */
    public static function handle_save_online_lessons() {

        self::check_permission();

        if (
            ! TutorHelper_Pro_License::is_active()
        ) {
            wp_die(
                esc_html__(
                    'An active TutorHelper Pro licence is required to manage Online Lesson settings.',
                    'tutorhelper-pro'
                ),
                esc_html__(
                    'Permission denied',
                    'tutorhelper-pro'
                ),
                array(
                    'response' => 403,
                )
            );
        }

        check_admin_referer(
            self::SAVE_ONLINE_LESSONS_ACTION,
            'tutorhelper_pro_online_lessons_nonce'
        );

        $zoom_url = '';

        if (
            isset(
                $_POST['zoom_url']
            )
            && ! is_array(
                $_POST['zoom_url']
            )
        ) {
            $zoom_url =
                esc_url_raw(
                    wp_unslash(
                        $_POST['zoom_url']
                    ),
                    array(
                        'http',
                        'https',
                    )
                );
        }

        TutorHelper_Pro_Online_Lessons::
            set_zoom_url(
                $zoom_url
            );

        self::redirect_online_lessons_notice(
            'success',
            'saved'
        );
    }


    /**
     * Handle licence activation.
     *
     * @return void
     */
    public static function handle_activate() {

        self::check_permission();

        check_admin_referer(
            self::ACTIVATE_ACTION,
            'tutorhelper_pro_license_nonce'
        );

        $license_key = '';

        if (
            isset( $_POST['license_key'] )
            && ! is_array( $_POST['license_key'] )
        ) {
            $license_key = sanitize_text_field(
                wp_unslash(
                    $_POST['license_key']
                )
            );
        }

        $result =
            TutorHelper_Pro_License_Controller::activate(
                $license_key
            );

        if ( is_wp_error( $result ) ) {
            self::redirect_with_notice(
                'error',
                $result->get_error_code()
            );
        }

        self::redirect_with_notice(
            'success',
            'activated'
        );
    }


    /**
     * Handle licence validation.
     *
     * @return void
     */
    public static function handle_validate() {

        self::check_permission();

        check_admin_referer(
            self::VALIDATE_ACTION,
            'tutorhelper_pro_license_nonce'
        );

        $result =
            TutorHelper_Pro_License_Controller::validate();

        if ( is_wp_error( $result ) ) {
            self::redirect_with_notice(
                'error',
                $result->get_error_code()
            );
        }

        self::redirect_with_notice(
            'success',
            'validated'
        );
    }


    /**
     * Handle licence deactivation.
     *
     * @return void
     */
    public static function handle_deactivate() {

        self::check_permission();

        check_admin_referer(
            self::DEACTIVATE_ACTION,
            'tutorhelper_pro_license_nonce'
        );

        $result =
            TutorHelper_Pro_License_Controller::deactivate();

        if ( is_wp_error( $result ) ) {
            self::redirect_with_notice(
                'error',
                $result->get_error_code()
            );
        }

        self::redirect_with_notice(
            'success',
            'deactivated'
        );
    }

    /**
     * Handle deliberate removal of an inactive saved key.
     *
     * @return void
     */
    public static function handle_remove_key() {
        self::check_permission();

        check_admin_referer(
            self::REMOVE_KEY_ACTION,
            'tutorhelper_pro_license_nonce'
        );

        if ( TutorHelper_Pro_License::is_active() ) {
            self::redirect_with_notice(
                'error',
                'tutorhelper_pro_deactivate_before_removing'
            );
        }

        if ( ! TutorHelper_Pro_License::remove_key() ) {
            self::redirect_with_notice(
                'error',
                'tutorhelper_pro_license_not_removed'
            );
        }

        self::redirect_with_notice(
            'success',
            'key_removed'
        );
    }


    /**
     * Check whether the current user may manage Pro.
     *
     * @return void
     */
    private static function check_permission() {

        if ( current_user_can( 'manage_options' ) ) {
            return;
        }

        wp_die(
            esc_html__(
                'You do not have permission to manage the TutorHelper Pro licence.',
                'tutorhelper-pro'
            ),
            esc_html__(
                'Permission denied',
                'tutorhelper-pro'
            ),
            array(
                'response' => 403,
            )
        );
    }


    /**
     * Redirect back to Online Lessons settings.
     *
     * @param string $type    Notice type.
     * @param string $message Notice identifier.
     *
     * @return void
     */
    private static function redirect_online_lessons_notice(
        $type,
        $message
    ) {

        $url = add_query_arg(
            array(
                'page' =>
                    TutorHelper_Settings::PAGE_SLUG,

                'tab' =>
                    self::ONLINE_LESSONS_TAB,

                'tutorhelper_pro_online_notice' =>
                    sanitize_key(
                        $type
                    ),

                'tutorhelper_pro_online_message' =>
                    sanitize_key(
                        $message
                    ),
            ),
            admin_url(
                'admin.php'
            )
        );

        wp_safe_redirect(
            $url
        );

        exit;
    }


    /**
     * Redirect back to the Pro Licence Settings tab.
     *
     * @param string $type    Notice type.
     * @param string $message Notice identifier.
     * @return void
     */
    private static function redirect_with_notice(
        $type,
        $message
    ) {

        $url = add_query_arg(
            array(
                'page' =>
                    TutorHelper_Settings::PAGE_SLUG,

                'tab' =>
                    self::LICENSE_TAB,

                'tutorhelper_pro_notice' =>
                    sanitize_key( $type ),

                'tutorhelper_pro_message' =>
                    sanitize_key( $message ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }


    /**
     * Render Online Lessons settings feedback.
     *
     * @return void
     */
    private static function render_online_lessons_notice() {

        $type = '';
        $message = '';

        if (
            isset(
                $_GET[
                    'tutorhelper_pro_online_notice'
                ]
            )
            && ! is_array(
                $_GET[
                    'tutorhelper_pro_online_notice'
                ]
            )
        ) {
            $type =
                sanitize_key(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_pro_online_notice'
                        ]
                    )
                );
        }

        if (
            isset(
                $_GET[
                    'tutorhelper_pro_online_message'
                ]
            )
            && ! is_array(
                $_GET[
                    'tutorhelper_pro_online_message'
                ]
            )
        ) {
            $message =
                sanitize_key(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_pro_online_message'
                        ]
                    )
                );
        }

        if (
            'saved'
            !== $message
        ) {
            return;
        }

        $notice_class =
            'success'
            === $type
                ? 'notice notice-success inline'
                : 'notice notice-error inline';

        ?>
        <div
            class="<?php
                echo esc_attr(
                    $notice_class
                );
            ?>"
        >
            <p>
                <?php
                echo esc_html__(
                    'Online Lesson settings saved.',
                    'tutorhelper-pro'
                );
                ?>
            </p>
        </div>
        <?php
    }


    /**
     * Render licence action feedback.
     *
     * @return void
     */
    private static function render_notice() {

        $type = '';
        $message = '';

        if ( isset( $_GET['tutorhelper_pro_notice'] ) ) {
            $type = sanitize_key(
                wp_unslash(
                    $_GET['tutorhelper_pro_notice']
                )
            );
        }

        if ( isset( $_GET['tutorhelper_pro_message'] ) ) {
            $message = sanitize_key(
                wp_unslash(
                    $_GET['tutorhelper_pro_message']
                )
            );
        }

        if ( '' === $message ) {
            return;
        }

        $messages = array(
            'activated' => __(
                'TutorHelper Pro has been activated successfully.',
                'tutorhelper-pro'
            ),

            'validated' => __(
                'Your TutorHelper Pro licence is valid.',
                'tutorhelper-pro'
            ),

            'deactivated' => __(
                'TutorHelper Pro has been deactivated on this site.',
                'tutorhelper-pro'
            ),

            'key_removed' => __(
                'The saved TutorHelper Pro licence key has been removed.',
                'tutorhelper-pro'
            ),

            'tutorhelper_pro_deactivate_before_removing' => __(
                'Deactivate the licence before removing its saved key.',
                'tutorhelper-pro'
            ),

            'tutorhelper_pro_license_not_removed' => __(
                'The saved licence key could not be removed.',
                'tutorhelper-pro'
            ),

            'tutorhelper_pro_license_not_saved' => __(
                'The licence key could not be saved on this site.',
                'tutorhelper-pro'
            ),

            'tutorhelper_pro_expired_license' => __(
                'Your TutorHelper Pro licence has expired.',
                'tutorhelper-pro'
            ),

            'tutorhelper_pro_invalid_license' => __(
                'This TutorHelper Pro licence is not valid for this installation.',
                'tutorhelper-pro'
            ),

            'tutorhelper_pro_activation_failed' => __(
                'The TutorHelper Pro licence could not be activated.',
                'tutorhelper-pro'
            ),

            'tutorhelper_pro_missing_license_key' => __(
                'Please enter a TutorHelper Pro licence key.',
                'tutorhelper-pro'
            ),
        );

        $display_message =
            isset( $messages[ $message ] )
                ? $messages[ $message ]
                : __(
                    'The licence request could not be completed.',
                    'tutorhelper-pro'
                );

        $notice_class =
            'success' === $type
                ? 'notice notice-success inline'
                : 'notice notice-error inline';

        ?>
        <div class="<?php echo esc_attr(
            $notice_class
        ); ?>">
            <p>
                <?php
                echo esc_html(
                    $display_message
                );
                ?>
            </p>
        </div>
        <?php
    }


    /**
     * Reset Branding colours and typography.
     *
     * @return void
     */
    public static function handle_reset_branding_colours() {

        if (
            ! current_user_can(
                'manage_options'
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to change these settings.',
                    'tutorhelper-pro'
                )
            );
        }

        check_admin_referer(
            self::RESET_BRANDING_COLOURS_ACTION,
            'tutorhelper_pro_reset_branding_colours_nonce'
        );

        TutorHelper_Pro_Branding::
            reset_colours();

        $url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Settings::
                            PAGE_SLUG,

                    'tab' =>
                        self::BRANDING_TAB,

                    'tutorhelper_pro_branding_status' =>
                        'reset',
                ),
                admin_url(
                    'admin.php'
                )
            );

        wp_safe_redirect(
            $url
        );

        exit;
    }



    /**
     * Load Branding admin assets.
     *
     * @param string $hook_suffix Current admin hook.
     *
     * @return void
     */
    public static function enqueue_branding_assets(
        $hook_suffix
    ) {

        /*
        * The Branding screen is a tab of the TutorHelper
        * Settings submenu, so checking for a top-level
        * admin hook is not reliable here.
        *
        * Instead, confirm both the Settings page slug
        * and the selected Branding tab.
        */
        $page =
            isset(
                $_GET['page']
            )
            && ! is_array(
                $_GET['page']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET['page']
                    )
                )
                : '';

        $selected_tab =
            isset(
                $_GET['tab']
            )
            && ! is_array(
                $_GET['tab']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET['tab']
                    )
                )
                : '';

        if (
            ! in_array(
                $selected_tab,
                array(
                    self::BRANDING_TAB,
                    self::PAYMENTS_TAB,
                ),
                true
            )
        ) {
            return;
        }

        /*
        * WordPress media library.
        */
        wp_enqueue_media();


        /*
        * Branding admin stylesheet.
        */
        $style_path =
            TUTORHELPER_PRO_PATH
            . 'assets/css/tutorhelper-pro-admin.css';

        wp_enqueue_style(
            'tutorhelper-pro-admin',
            TUTORHELPER_PRO_URL
                . 'assets/css/tutorhelper-pro-admin.css',
            array(),
            file_exists(
                $style_path
            )
                ? (string) filemtime(
                    $style_path
                )
                : TUTORHELPER_PRO_VERSION
        );


        if (
            self::BRANDING_TAB
            === $selected_tab
        ) {

            /*
            * Branding media picker and live preview.
            */
            $script_path =
                TUTORHELPER_PRO_PATH
                . 'assets/js/tutorhelper-pro-branding-admin.js';

            wp_enqueue_script(
                'tutorhelper-pro-branding-admin',
                TUTORHELPER_PRO_URL
                    . 'assets/js/tutorhelper-pro-branding-admin.js',
                array(),
                file_exists(
                    $script_path
                )
                    ? (string) filemtime(
                        $script_path
                    )
                    : TUTORHELPER_PRO_VERSION,
                true
            );
        }
    }



    /**
     * Schedule daily licence validation.
     *
     * @return void
     */
    public static function schedule_license_validation() {
        if ( ! wp_next_scheduled( self::LICENSE_CRON_HOOK ) ) {
            wp_schedule_event(
                time() + HOUR_IN_SECONDS,
                'daily',
                self::LICENSE_CRON_HOOK
            );
        }
    }

    /**
     * Stop daily licence validation.
     *
     * @return void
     */
    public static function unschedule_license_validation() {
        wp_clear_scheduled_hook( self::LICENSE_CRON_HOOK );
    }

    /**
     * Validate a stored licence without disabling Pro for temporary failures.
     *
     * @return void
     */
    public static function daily_validate_license() {
        if ( '' === TutorHelper_Pro_License::get_key() ) {
            return;
        }

        $result = TutorHelper_Pro_License_Controller::validate();
        if ( is_wp_error( $result ) && class_exists( 'TutorHelper_Logger' ) ) {
            $data = $result->get_error_data();
            $context = array(
                'error_code' => sanitize_key( $result->get_error_code() ),
            );
            if ( is_array( $data ) && isset( $data['status'] ) ) {
                $context['http_status'] = absint( $data['status'] );
            }
            TutorHelper_Logger::warning(
                'TutorHelper Pro scheduled licence validation did not complete.',
                $context
            );
        }
    }

}
