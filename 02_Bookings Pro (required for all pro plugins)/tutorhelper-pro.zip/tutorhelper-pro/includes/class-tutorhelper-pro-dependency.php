<?php
/**
 * TutorHelper Pro dependency checks.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks whether TutorHelper Pro's required Core plugin is available.
 */
class TutorHelper_Pro_Dependency {

	/**
	 * Check whether TutorHelper Bookings is loaded.
	 *
	 * @return bool
	 */
	public static function core_is_available() {
		return defined( 'TUTORHELPER_BOOKINGS_VERSION' );
	}

	/**
	 * Get the installed TutorHelper Bookings version.
	 *
	 * @return string
	 */
	public static function get_core_version() {
		if ( ! self::core_is_available() ) {
			return '';
		}

		return TUTORHELPER_BOOKINGS_VERSION;
	}
}
