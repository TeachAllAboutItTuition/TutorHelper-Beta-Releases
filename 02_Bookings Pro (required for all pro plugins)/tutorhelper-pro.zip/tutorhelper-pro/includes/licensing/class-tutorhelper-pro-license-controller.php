<?php
/**
 * TutorHelper Pro licence controller.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Coordinates remote licence requests and local licence state.
 */
class TutorHelper_Pro_License_Controller {

	/**
	 * Activate a TutorHelper Pro licence.
	 *
	 * @param string $license_key Licence key.
	 * @return true|WP_Error
	 */
	public static function activate( $license_key ) {

		$license_key = trim( sanitize_text_field( $license_key ) );

		if ( '' === $license_key ) {
			return new WP_Error(
				'tutorhelper_pro_missing_license_key',
				__(
					'A licence key is required.',
					'tutorhelper-pro'
				)
			);
		}

		if ( ! TutorHelper_Pro_License::set_key( $license_key ) ) {
			return new WP_Error(
				'tutorhelper_pro_license_not_saved',
				__(
					'The licence key could not be saved on this site.',
					'tutorhelper-pro'
				)
			);
		}

		$response =
			TutorHelper_Pro_License_API::activate(
				$license_key
			);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if (
			empty( $response['success'] )
			|| empty( $response['activation_token'] )
			|| 'active' !== ( $response['status'] ?? '' )
		) {
			return new WP_Error(
				'tutorhelper_pro_activation_failed',
				__(
					'The licence could not be activated.',
					'tutorhelper-pro'
				)
			);
		}

		TutorHelper_Pro_License::activate_local(
			$license_key,
			$response['activation_token'],
			$response
		);

		return true;
	}


    /**
     * Deactivate the current TutorHelper Pro licence.
     *
     * @return true|WP_Error
     */
    public static function deactivate() {

        $license_key =
            TutorHelper_Pro_License::get_key();

        $token =
            TutorHelper_Pro_License::get_token();

        if (
            '' === $license_key
            || '' === $token
        ) {
            return new WP_Error(
                'tutorhelper_pro_no_active_license',
                __(
                    'No active licence was found for this installation.',
                    'tutorhelper-pro'
                )
            );
        }

        $response =
            TutorHelper_Pro_License_API::deactivate(
                $license_key,
                $token
            );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if (
            empty( $response['success'] )
            || 'inactive' !== ( $response['status'] ?? '' )
        ) {
            return new WP_Error(
                'tutorhelper_pro_deactivation_failed',
                __(
                    'The licence could not be deactivated.',
                    'tutorhelper-pro'
                )
            );
        }

        TutorHelper_Pro_License::deactivate_local();

        return true;
    }


    /**
     * Validate the stored TutorHelper Pro licence.
     *
     * @return true|WP_Error
     */
    public static function validate() {

        $license_key =
            TutorHelper_Pro_License::get_key();

        if ( '' === $license_key ) {
            return new WP_Error(
                'tutorhelper_pro_missing_license',
                __(
                    'No licence key is stored.',
                    'tutorhelper-pro'
                )
            );
        }

        $response =
            TutorHelper_Pro_License_API::validate(
                $license_key
            );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $response_status = sanitize_key( $response['status'] ?? '' );

        if (
            ! empty( $response['success'] )
            && in_array( $response_status, array( 'valid', 'active' ), true )
        ) {
            TutorHelper_Pro_License::store_validation(
                $response
            );

            return true;
        }

        if ( 'expired' === $response_status ) {
            TutorHelper_Pro_License::set_status(
                'expired'
            );

            return new WP_Error(
                'tutorhelper_pro_expired_license',
                __(
                    'The licence has expired.',
                    'tutorhelper-pro'
                )
            );
        }

        if ( in_array( $response_status, array( 'invalid', 'inactive', 'revoked' ), true ) ) {
            TutorHelper_Pro_License::set_status(
                'invalid'
            );

            return new WP_Error(
                'tutorhelper_pro_invalid_license',
                __(
                    'The licence is not valid for this installation.',
                    'tutorhelper-pro'
                )
            );
        }

        return new WP_Error(
            'tutorhelper_pro_license_unconfirmed',
            __(
                'The licence server returned an unexpected response. The previous local licence state has been kept.',
                'tutorhelper-pro'
            )
        );


    }



}
