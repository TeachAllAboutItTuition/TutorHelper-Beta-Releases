<?php
/**
 * TutorHelper Pro licence state.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages the locally stored TutorHelper Pro licence state.
 */
class TutorHelper_Pro_License {

	/**
	 * Licence key option.
	 */
	const KEY_OPTION = 'tutorhelper_pro_license_key';

	/**
	 * Licence status option.
	 */
	const STATUS_OPTION = 'tutorhelper_pro_license_status';

	/**
	 * Installation ID option.
	 */
	const INSTANCE_OPTION = 'tutorhelper_pro_instance_id';


	/**
	 * Activation token option.
	 */
	const TOKEN_OPTION = 'tutorhelper_pro_license_token';

	/**
	 * Licence expiry option.
	 */
	const EXPIRES_OPTION = 'tutorhelper_pro_license_expires';

	/**
	 * Lifetime licence option.
	 */
	const LIFETIME_OPTION = 'tutorhelper_pro_license_lifetime';

	/**
	 * Last successful check option.
	 */
	const LAST_CHECK_OPTION = 'tutorhelper_pro_license_last_check';


	/**
	 * Get the stored licence key.
	 *
	 * @return string
	 */
	public static function get_key() {
		return (string) get_option( self::KEY_OPTION, '' );
	}

	/**
	 * Store a licence key.
	 *
	 * @param string $license_key Licence key.
	 * @return bool
	 */
	public static function set_key( $license_key ) {
		$license_key = trim(
			sanitize_text_field( $license_key )
		);

		update_option(
			self::KEY_OPTION,
			$license_key,
			false
		);

		return hash_equals(
			$license_key,
			self::get_key()
		);
	}

	/**
	 * Get the stored activation token.
	 *
	 * @return string
	 */
	public static function get_token() {
		return (string) get_option( self::TOKEN_OPTION, '' );
	}

	/**
	 * Store the activation token.
	 *
	 * @param string $token Activation token.
	 * @return bool
	 */
	public static function set_token( $token ) {
		$token = sanitize_text_field( $token );

		return update_option(
			self::TOKEN_OPTION,
			$token,
			false
		);
	}

	/**
	 * Store a successful licence activation.
	 *
	 * @param string $license_key Licence key.
	 * @param string $token       Activation token.
	 * @return void
	 */
	public static function activate_local( $license_key, $token, $response = array() ) {

		self::set_key( $license_key );
		self::set_token( $token );
		self::store_metadata( $response );
		self::set_status( 'active' );
	}

	/**
	 * Store a successful validation response.
	 *
	 * @param array $response Licence server response.
	 * @return void
	 */
	public static function store_validation( $response ) {
		self::store_metadata( $response );
		self::set_status( 'active' );
	}

	/**
	 * Store expiry metadata returned by the bridge.
	 *
	 * @param array $response Licence server response.
	 * @return void
	 */
	private static function store_metadata( $response ) {
		$lifetime = ! empty( $response['lifetime'] );
		$expires  = isset( $response['expires_at'] ) && is_scalar( $response['expires_at'] )
			? sanitize_text_field( (string) $response['expires_at'] )
			: '';

		if ( array_key_exists( 'lifetime', $response ) || array_key_exists( 'expires_at', $response ) ) {
			update_option( self::LIFETIME_OPTION, $lifetime ? 1 : 0, false );
			update_option( self::EXPIRES_OPTION, $lifetime ? '' : $expires, false );
		}

		update_option( self::LAST_CHECK_OPTION, time(), false );
	}

	/**
	 * Determine whether this is a lifetime licence.
	 *
	 * @return bool
	 */
	public static function is_lifetime() {
		return (bool) get_option( self::LIFETIME_OPTION, false );
	}

	/**
	 * Return the stored expiry timestamp.
	 *
	 * @return int
	 */
	public static function expiry_timestamp() {
		$expires = sanitize_text_field( get_option( self::EXPIRES_OPTION, '' ) );
		return '' === $expires ? 0 : (int) strtotime( $expires );
	}


	/**
	 * Mark the local licence as deactivated.
	 *
	 * Keeps the licence key and installation ID,
	 * but removes the activation token.
	 *
	 * @return void
	 */
	public static function deactivate_local() {

		delete_option( self::TOKEN_OPTION );

		self::set_status( 'inactive' );
	}

	/**
	 * Deliberately remove the saved licence credentials.
	 *
	 * The installation ID is retained so this site keeps a stable identity.
	 *
	 * @return bool
	 */
	public static function remove_key() {
		delete_option( self::KEY_OPTION );
		delete_option( self::TOKEN_OPTION );
		delete_option( self::STATUS_OPTION );
		delete_option( self::EXPIRES_OPTION );
		delete_option( self::LIFETIME_OPTION );
		delete_option( self::LAST_CHECK_OPTION );

		return '' === self::get_key();
	}



	/**
	 * Get the locally stored licence status.
	 *
	 * @return string
	 */
	public static function get_status() {
		return sanitize_key(
			get_option( self::STATUS_OPTION, 'inactive' )
		);
	}

	/**
	 * Store the local licence status.
	 *
	 * @param string $status Licence status.
	 * @return bool
	 */
	public static function set_status( $status ) {
		$allowed_statuses = array(
			'inactive',
			'active',
			'expired',
			'invalid',
		);

		$status = sanitize_key( $status );

		if ( ! in_array( $status, $allowed_statuses, true ) ) {
			$status = 'invalid';
		}

		return update_option(
			self::STATUS_OPTION,
			$status,
			false
		);
	}

	/**
	 * Determine whether the locally cached licence is active.
	 *
	 * @return bool
	 */
	public static function is_active() {
		if ( 'active' !== self::get_status() ) {
			return false;
		}

		if ( self::is_lifetime() ) {
			return true;
		}

		$expires = self::expiry_timestamp();
		if ( $expires && $expires < time() ) {
			self::set_status( 'expired' );
			return false;
		}

		return true;
	}

	/**
	 * Get or create the unique ID for this WordPress installation.
	 *
	 * @return string
	 */
	public static function get_instance_id() {
		$instance_id = (string) get_option(
			self::INSTANCE_OPTION,
			''
		);

		if ( '' !== $instance_id ) {
			return $instance_id;
		}

		$instance_id = wp_generate_uuid4();

		update_option(
			self::INSTANCE_OPTION,
			$instance_id,
			false
		);

		return $instance_id;
	}

	/**
	 * Clear the locally stored licence state.
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::KEY_OPTION );
		delete_option( self::STATUS_OPTION );
		delete_option( self::TOKEN_OPTION );
		delete_option( self::EXPIRES_OPTION );
		delete_option( self::LIFETIME_OPTION );
		delete_option( self::LAST_CHECK_OPTION );
	}
}
