<?php
/**
 * TutorHelper Pro licence API client.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Communicates with the TutorHelper licensing server.
 */
class TutorHelper_Pro_License_API {

	/**
	 * Base licence API URL.
	 */
	const API_URL = 'https://tutorhelper.co.uk/wp-json/tutorhelper-license/v1/';

	/**
	 * Send a request to the licence server.
	 *
	 * @param string $endpoint API endpoint.
	 * @param array  $body     Request data.
	 * @return array|WP_Error
	 */
	private static function request( $endpoint, $body ) {

		$url = trailingslashit( self::API_URL ) . ltrim( $endpoint, '/' );

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 15,
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		$data = json_decode(
			wp_remote_retrieve_body( $response ),
			true
		);

		if ( $status_code < 200 || $status_code >= 300 ) {
			$message = __( 'The licence server returned an error.', 'tutorhelper-pro' );

			if ( ! empty( $data['message'] ) ) {
				$message = sanitize_text_field( $data['message'] );
			}

			return new WP_Error(
				'tutorhelper_pro_license_api_error',
				$message,
				array(
					'status' => $status_code,
				)
			);
		}

		if ( ! is_array( $data ) ) {
			return new WP_Error(
				'tutorhelper_pro_license_invalid_response',
				__( 'The licence server returned an invalid response.', 'tutorhelper-pro' )
			);
		}

		return $data;
	}

	/**
	 * Build the shared request data.
	 *
	 * @param string $license_key Licence key.
	 * @return array
	 */
	private static function get_request_data( $license_key ) {
		return array(
			'license_key' => sanitize_text_field( $license_key ),
			'instance_id' => TutorHelper_Pro_License::get_instance_id(),
			'site_url'    => home_url( '/' ),
		);
	}

	/**
	 * Activate a licence.
	 *
	 * @param string $license_key Licence key.
	 * @return array|WP_Error
	 */
	public static function activate( $license_key ) {
		return self::request(
			'activate',
			self::get_request_data( $license_key )
		);
	}


	/**
     * Validate a licence.
     *
     * @param string $license_key Licence key.
     * @return array|WP_Error
     */
    public static function validate( $license_key ) {

        $data = self::get_request_data(
            $license_key
        );

        $token =
            TutorHelper_Pro_License::get_token();

        if ( '' !== $token ) {
            $data['activation_token'] =
                sanitize_text_field( $token );
        }

        return self::request(
            'validate',
            $data
        );
    }


    /**
     * Deactivate a licence activation.
     *
     * @param string $license_key Licence key.
     * @param string $token       Activation token.
     * @return array|WP_Error
     */
    public static function deactivate(
        $license_key,
        $token
    ) {

        $data = self::get_request_data(
            $license_key
        );

        $data['activation_token'] =
            sanitize_text_field( $token );

        return self::request(
            'deactivate',
            $data
        );
    }


}
