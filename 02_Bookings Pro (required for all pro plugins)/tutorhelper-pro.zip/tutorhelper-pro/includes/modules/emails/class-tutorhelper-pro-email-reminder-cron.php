<?php
/**
 * TutorHelper Pro email reminder cron.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Runs scheduled reminder checks.
 */
final class TutorHelper_Pro_Email_Reminder_Cron {

	/**
	 * WordPress cron hook.
	 *
	 * @var string
	 */
	const CRON_HOOK =
		'tutorhelper_pro_process_email_reminders';

	/**
	 * Custom schedule key.
	 *
	 * @var string
	 */
	const SCHEDULE =
		'tutorhelper_pro_every_15_minutes';

	/**
	 * Polling interval.
	 *
	 * @var int
	 */
	const INTERVAL =
		15 * 60;

	/**
	 * Grace period for delayed WP-Cron execution.
	 *
	 * @var int
	 */
	const LOOKBACK =
		60 * 60;

    
    const LAST_RUN_OPTION =
	'tutorhelper_pro_email_reminder_last_run';

    /**
     * Last cron result.
     *
     * @var string
     */
    const LAST_RESULT_OPTION =
        'tutorhelper_pro_email_reminder_last_result';


	/**
	 * Register cron hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'cron_schedules',
			array(
				__CLASS__,
				'add_schedule',
			)
		);

		add_action(
			self::CRON_HOOK,
			array(
				__CLASS__,
				'run',
			)
		);

		self::ensure_scheduled();
	}


	/**
	 * Add the 15-minute schedule.
	 *
	 * @param array $schedules Existing schedules.
	 *
	 * @return array
	 */
	public static function add_schedule(
		$schedules
	) {

		$schedules[
			self::SCHEDULE
		] =
			array(
				'interval' =>
					self::INTERVAL,

				'display' =>
					__(
						'Every 15 minutes',
						'tutorhelper-pro'
					),
			);

		return $schedules;
	}


	/**
	 * Ensure the reminder event exists.
	 *
	 * @return void
	 */
	public static function ensure_scheduled() {

		if (
			wp_next_scheduled(
				self::CRON_HOOK
			)
		) {
			return;
		}

		wp_schedule_event(
			time()
				+ MINUTE_IN_SECONDS,
			self::SCHEDULE,
			self::CRON_HOOK
		);
	}


	/**
	 * Schedule cron on plugin activation.
	 *
	 * @return void
	 */
	public static function activate() {

		add_filter(
			'cron_schedules',
			array(
				__CLASS__,
				'add_schedule',
			)
		);

		self::ensure_scheduled();
	}


	/**
	 * Remove cron on plugin deactivation.
	 *
	 * @return void
	 */
	public static function deactivate() {

		wp_clear_scheduled_hook(
			self::CRON_HOOK
		);
	}


	/**
     * Run the reminder delivery pass.
     *
     * @return void
     */
    public static function run() {

        $now =
            time();

        /*
        * Always record that the event ran, even if the licence
        * prevents reminder processing.
        */
        update_option(
            self::LAST_RUN_OPTION,
            $now,
            false
        );

        if (
            ! TutorHelper_Pro_License::
                is_active()
        ) {

            update_option(
                self::LAST_RESULT_OPTION,
                array(
                    'status' =>
                        'license_inactive',

                    'reminders_checked' =>
                        0,

                    'bookings_matched' =>
                        0,

                    'recipients_processed' =>
                        0,

                    'sent' =>
                        0,

                    'failed' =>
                        0,

                    'skipped' =>
                        0,
                ),
                false
            );

            return;
        }

        $window_start =
            $now
            - self::LOOKBACK;

        $result =
            TutorHelper_Pro_Email_Reminder_Delivery::
                process_due_reminders(
                    $window_start,
                    $now
                );

        $result['status'] =
            'completed';

        $result['window_start'] =
            $window_start;

        $result['window_end'] =
            $now;

        update_option(
            self::LAST_RESULT_OPTION,
            $result,
            false
        );
    }


    /**
     * Return the most recent cron run timestamp.
     *
     * @return int
     */
    public static function get_last_run() {

        return absint(
            get_option(
                self::LAST_RUN_OPTION,
                0
            )
        );
    }


    /**
     * Return the most recent cron result.
     *
     * @return array
     */
    public static function get_last_result() {

        $result =
            get_option(
                self::LAST_RESULT_OPTION,
                array()
            );

        return is_array( $result )
            ? $result
            : array();
    }


    /**
     * Return the next scheduled cron timestamp.
     *
     * @return int
     */
    public static function get_next_run() {

        return absint(
            wp_next_scheduled(
                self::CRON_HOOK
            )
        );
    }


}
