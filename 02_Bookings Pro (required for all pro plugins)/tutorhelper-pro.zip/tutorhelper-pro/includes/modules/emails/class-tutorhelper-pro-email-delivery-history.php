<?php
/**
 * TutorHelper Pro reminder delivery history.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads scheduled reminder delivery history.
 */
final class TutorHelper_Pro_Email_Delivery_History {

	/**
	 * Delivery status: sent.
	 *
	 * @var string
	 */
	const STATUS_SENT =
		'sent';

	/**
	 * Delivery status: failed.
	 *
	 * @var string
	 */
	const STATUS_FAILED =
		'failed';


	/**
	 * Register email-delivery hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'tutorhelper_email_sent',
			array(
				__CLASS__,
				'record_sent',
			),
			10,
			3
		);

		add_action(
			'tutorhelper_email_failed',
			array(
				__CLASS__,
				'record_failed',
			),
			10,
			3
		);
	}

	/**
	 * Retrieve reminder delivery records.
	 *
	 * @param array $args Query arguments.
	 *
	 * @return array
	 */
	public static function get_all(
		$args = array()
	) {

		global $wpdb;

		$args =
			wp_parse_args(
				$args,
				array(
					'status' =>
						'',

					'reminder_id' =>
						0,

					'page' =>
						1,

					'per_page' =>
						20,
				)
			);

		$status =
			sanitize_key(
				$args['status']
			);

		$reminder_id =
			absint(
				$args[
					'reminder_id'
				]
			);

		$page =
			max(
				1,
				absint(
					$args['page']
				)
			);

		$per_page =
			max(
				1,
				min(
					100,
					absint(
						$args[
							'per_page'
						]
					)
				)
			);

		$offset =
			( $page - 1 )
			* $per_page;

		$delivery_table =
			TutorHelper_Pro_Database::
				get_table_name(
					'email_reminder_deliveries'
				);

		$reminder_table =
			TutorHelper_Pro_Database::
				get_table_name(
					'email_reminders'
				);

		$sql =
			'SELECT
				d.*,
				r.name AS reminder_name
			FROM %i d
			LEFT JOIN %i r
				ON r.id = d.reminder_id
			WHERE 1 = 1';

		$query_args =
			array(
				$delivery_table,
				$reminder_table,
			);

		if (
			in_array(
				$status,
				array(
					'sent',
					'failed',
					'skipped',
				),
				true
			)
		) {

			$sql .=
				' AND d.status = %s';

			$query_args[] =
				$status;
		}

		if ( $reminder_id ) {

			$sql .=
				' AND d.reminder_id = %d';

			$query_args[] =
				$reminder_id;
		}

		$sql .=
			' ORDER BY
				COALESCE(
					d.last_attempt_at,
					d.scheduled_for
				) DESC
			LIMIT %d
			OFFSET %d';

		$query_args[] =
			$per_page;

		$query_args[] =
			$offset;

		$rows =
			$wpdb->get_results(
				$wpdb->prepare(
					$sql,
					$query_args
				)
			);

		return is_array( $rows )
			? $rows
			: array();
	}


	/**
	 * Count matching history rows.
	 *
	 * @param array $args Query arguments.
	 *
	 * @return int
	 */
	public static function get_count(
		$args = array()
	) {

		global $wpdb;

		$args =
			wp_parse_args(
				$args,
				array(
					'status' =>
						'',

					'reminder_id' =>
						0,
				)
			);

		$delivery_table =
			TutorHelper_Pro_Database::
				get_table_name(
					'email_reminder_deliveries'
				);

		$sql =
			'SELECT COUNT(*)
			FROM %i
			WHERE 1 = 1';

		$query_args =
			array(
				$delivery_table,
			);

		$status =
			sanitize_key(
				$args['status']
			);

		if (
			in_array(
				$status,
				array(
					'sent',
					'failed',
					'skipped',
				),
				true
			)
		) {

			$sql .=
				' AND status = %s';

			$query_args[] =
				$status;
		}

		$reminder_id =
			absint(
				$args[
					'reminder_id'
				]
			);

		if ( $reminder_id ) {

			$sql .=
				' AND reminder_id = %d';

			$query_args[] =
				$reminder_id;
		}

		return absint(
			$wpdb->get_var(
				$wpdb->prepare(
					$sql,
					$query_args
				)
			)
		);
	}


	/**
	 * Retrieve generic TutorHelper email delivery history.
	 *
	 * @param array $args Query arguments.
	 *
	 * @return array
	 */
	public static function get_generic(
		$args = array()
	) {

		global $wpdb;

		$args =
			wp_parse_args(
				$args,
				array(
					'status' =>
						'',

					'template_key' =>
						'',

					'date_from' =>
						'',

					'date_to' =>
						'',

					'page' =>
						1,

					'per_page' =>
						20,
				)
			);

		$status =
			sanitize_key(
				$args['status']
			);

		$template_key =
			sanitize_key(
				$args[
					'template_key'
				]
			);

		$date_from =
			isset(
				$args['date_from']
			)
				? sanitize_text_field(
					$args['date_from']
				)
				: '';

		$date_to =
			isset(
				$args['date_to']
			)
				? sanitize_text_field(
					$args['date_to']
				)
				: '';

		$page =
			max(
				1,
				absint(
					$args['page']
				)
			);

		$per_page =
			max(
				1,
				min(
					100,
					absint(
						$args[
							'per_page'
						]
					)
				)
			);

		$offset =
			( $page - 1 )
			* $per_page;

		$table_name =
			TutorHelper_Pro_Database::
				get_table_name(
					'email_deliveries'
				);

		$sql =
			'SELECT *
			FROM %i
			WHERE 1 = 1';

		$query_args =
			array(
				$table_name,
			);

		if (
			in_array(
				$status,
				array(
					self::STATUS_SENT,
					self::STATUS_FAILED,
				),
				true
			)
		) {

			$sql .=
				' AND status = %s';

			$query_args[] =
				$status;
		}

		if ( $template_key ) {

			$sql .=
				' AND template_key = %s';

			$query_args[] =
				$template_key;
		}

		if ( $date_from ) {

			$sql .=
				' AND created_at >= %s';

			$query_args[] =
				$date_from;
		}

		if ( $date_to ) {

			$sql .=
				' AND created_at <= %s';

			$query_args[] =
				$date_to;
		}

		$sql .=
			' ORDER BY created_at DESC
			LIMIT %d
			OFFSET %d';

		$query_args[] =
			$per_page;

		$query_args[] =
			$offset;

		$rows =
			$wpdb->get_results(
				$wpdb->prepare(
					$sql,
					$query_args
				)
			);

		return is_array( $rows )
			? $rows
			: array();
	}


	/**
	 * Count generic TutorHelper email delivery rows.
	 *
	 * @param array $args Query arguments.
	 *
	 * @return int
	 */
	public static function get_generic_count(
		$args = array()
	) {

		global $wpdb;

		$args =
			wp_parse_args(
				$args,
				array(
					'status' =>
						'',

					'template_key' =>
						'',

					'date_from' =>
						'',

					'date_to' =>
						'',
				)
			);

		$table_name =
			TutorHelper_Pro_Database::
				get_table_name(
					'email_deliveries'
				);

		$sql =
			'SELECT COUNT(*)
			FROM %i
			WHERE 1 = 1';

		$query_args =
			array(
				$table_name,
			);

		$status =
			sanitize_key(
				$args['status']
			);

		$date_from =
			isset(
				$args['date_from']
			)
				? sanitize_text_field(
					$args['date_from']
				)
				: '';

		$date_to =
			isset(
				$args['date_to']
			)
				? sanitize_text_field(
					$args['date_to']
				)
				: '';

		if (
			in_array(
				$status,
				array(
					self::STATUS_SENT,
					self::STATUS_FAILED,
				),
				true
			)
		) {

			$sql .=
				' AND status = %s';

			$query_args[] =
				$status;
		}

		$template_key =
			sanitize_key(
				$args[
					'template_key'
				]
			);

		if ( $template_key ) {

			$sql .=
				' AND template_key = %s';

			$query_args[] =
				$template_key;
		}

		
		if ( $date_from ) {

			$sql .=
				' AND created_at >= %s';

			$query_args[] =
				$date_from;
		}

		if ( $date_to ) {

			$sql .=
				' AND created_at <= %s';

			$query_args[] =
				$date_to;
		}

		

		return absint(
			$wpdb->get_var(
				$wpdb->prepare(
					$sql,
					$query_args
				)
			)
		);
	}



	/**
	 * Record a successful TutorHelper email.
	 *
	 * @param string $template_key Template identifier.
	 * @param string $recipient    Recipient email address.
	 * @param array  $context      Email context.
	 *
	 * @return void
	 */
	public static function record_sent(
		$template_key,
		$recipient,
		$context
	) {

		self::record_generic_delivery(
			$template_key,
			$recipient,
			self::STATUS_SENT,
			$context
		);
	}


	/**
	 * Record a failed TutorHelper email.
	 *
	 * @param string $template_key Template identifier.
	 * @param string $recipient    Recipient email address.
	 * @param array  $context      Email context.
	 *
	 * @return void
	 */
	public static function record_failed(
		$template_key,
		$recipient,
		$context
	) {

		self::record_generic_delivery(
			$template_key,
			$recipient,
			self::STATUS_FAILED,
			$context,
			__(
				'WordPress mail delivery returned a failure.',
				'tutorhelper-pro'
			)
		);
	}


	/**
	 * Store one generic email-delivery event.
	 *
	 * Only known non-message metadata is persisted.
	 *
	 * @param string $template_key Template identifier.
	 * @param string $recipient    Recipient email.
	 * @param string $status       Delivery status.
	 * @param array  $context      Email context.
	 * @param string $error        Optional error message.
	 *
	 * @return bool
	 */
	private static function record_generic_delivery(
		$template_key,
		$recipient,
		$status,
		$context,
		$error = ''
	) {

		global $wpdb;

		$template_key =
			sanitize_key(
				$template_key
			);

		$recipient =
			sanitize_email(
				$recipient
			);

		$status =
			sanitize_key(
				$status
			);

		$context =
			is_array( $context )
				? $context
				: array();

		if (
			! $template_key
			|| ! in_array(
				$status,
				array(
					self::STATUS_SENT,
					self::STATUS_FAILED,
				),
				true
			)
		) {
			return false;
		}


		$delivery_type = 'automatic';

		if (
			! empty(
				$context['email_type']
			)
		) {

			$delivery_type =
				sanitize_key(
					$context['email_type']
				);

		} elseif (
			! empty(
				$context['action']
			)
		) {

			$delivery_type =
				sanitize_key(
					$context['action']
				);
		}


		$recipient_type =
			isset(
				$context[
					'recipient_type'
				]
			)
				? sanitize_key(
					$context[
						'recipient_type'
					]
				)
				: '';


		$related_object_type = '';
		$related_object_id   = 0;

		if ( ! empty( $context['related_object_type'] ) ) {
			$related_object_type = sanitize_key( $context['related_object_type'] );
		}
		if ( ! empty( $context['related_object_id'] ) ) {
			$related_object_id = absint( $context['related_object_id'] );
		}


		/*
		* Scheduled reminder context already provides
		* its booking ID.
		*/
		if (
			! $related_object_id
			&&
			! empty(
				$context['booking_id']
			)
		) {

			$related_object_type =
				'booking';

			$related_object_id =
				absint(
					$context[
						'booking_id'
					]
				);
		}


		/*
		* Registration emails will provide the
		* student user ID when we add them next.
		*/
		if (
			! $related_object_id
			&&
			! empty(
				$context[
					'student_user_id'
				]
			)
		) {

			$related_object_type =
				'student';

			$related_object_id =
				absint(
					$context[
						'student_user_id'
					]
				);
		}


		$now =
			current_time(
				'mysql',
				true
			);

		$table_name =
			TutorHelper_Pro_Database::
				get_table_name(
					'email_deliveries'
				);

		if ( ! $table_name ) {
			return false;
		}


	$result =
			$wpdb->insert(
				$table_name,
				array(
					'template_key' =>
						$template_key,

					'delivery_type' =>
						$delivery_type,

					'related_object_type' =>
						$related_object_type,

					'related_object_id' =>
						$related_object_id,

					'recipient_type' =>
						$recipient_type,

					'recipient_email' =>
						$recipient,

					'subject_snapshot' =>
						isset( $context['rendered_subject'] )
							? sanitize_text_field( $context['rendered_subject'] )
							: null,

					'html_snapshot' =>
						isset( $context['rendered_html'] )
							? (string) $context['rendered_html']
							: null,

					'context_snapshot' =>
						wp_json_encode(
							array_diff_key(
								$context,
								array( 'rendered_html' => true )
							)
						),

					'status' =>
						$status,

					'error_message' =>
						$error
							? sanitize_text_field(
								$error
							)
							: null,

					'sent_at' =>
						self::STATUS_SENT
						=== $status
							? $now
							: null,

					'created_at' =>
						$now,
				),
				array(
					'%s',
					'%s',
					'%s',
					'%d',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
				)
			);

		return false !== $result;
	}


}
