<?php
/**
 * TutorHelper Pro scheduled reminder delivery.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds, sends and records scheduled reminder deliveries.
 */
final class TutorHelper_Pro_Email_Reminder_Delivery {

	/**
	 * Delivery status: sent.
	 *
	 * @var string
	 */
	const STATUS_SENT = 'sent';

	/**
	 * Delivery status: failed.
	 *
	 * @var string
	 */
	const STATUS_FAILED = 'failed';

	/**
	 * Delivery status: skipped.
	 *
	 * @var string
	 */
	const STATUS_SKIPPED = 'skipped';


	/**
	 * Register delivery maintenance hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'tutorhelper_booking_updated',
			array( __CLASS__, 'reset_after_reschedule' ),
			10,
			3
		);
	}


	/**
	 * Clear reminder delivery history when a lesson time changes.
	 *
	 * A reminder is complete per booking and recipient. Once a lesson is
	 * rescheduled, that completion record must not suppress the reminders
	 * appropriate to its new time. Ordinary booking edits leave the history
	 * intact.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param object $updated    Updated booking record.
	 * @param object $previous   Booking record before the update.
	 *
	 * @return void
	 */
	public static function reset_after_reschedule(
		$booking_id,
		$updated,
		$previous
	) {
		$booking_id = absint( $booking_id );

		if (
			! $booking_id
			|| ! is_object( $updated )
			|| ! is_object( $previous )
		) {
			return;
		}

		$start_changed = isset( $updated->booking_start, $previous->booking_start )
			&& (string) $updated->booking_start !== (string) $previous->booking_start;
		$end_changed = isset( $updated->booking_end, $previous->booking_end )
			&& (string) $updated->booking_end !== (string) $previous->booking_end;

		if ( ! $start_changed && ! $end_changed ) {
			return;
		}

		global $wpdb;

		$table_name = TutorHelper_Pro_Database::get_table_name(
			'email_reminder_deliveries'
		);
		$deleted = $wpdb->delete(
			$table_name,
			array(
				'booking_id' => $booking_id,
			),
			array(
				'%d',
			)
		);

		if ( false === $deleted ) {
			return;
		}

		TutorHelper_Logger::success(
			'Scheduled reminder deliveries reset after booking reschedule.',
			array(
				'booking_id' => $booking_id,
				'previous_start_utc' => isset( $previous->booking_start )
					? (string) $previous->booking_start
					: '',
				'new_start_utc' => isset( $updated->booking_start )
					? (string) $updated->booking_start
					: '',
			)
		);
	}


	/**
     * Process all reminders due within a UTC time window.
     *
     * @param int $window_start Start timestamp.
     * @param int $window_end   End timestamp.
     *
     * @return array
     */
    public static function process_due_reminders(
        $window_start,
        $window_end
    ) {

        $result =
            array(
                'reminders_checked' =>
                    0,

                'bookings_matched' =>
                    0,

                'recipients_processed' =>
                    0,

                'sent' =>
                    0,

                'failed' =>
                    0,

                'skipped' =>
                    0,
            );

        $reminders =
            TutorHelper_Pro_Email_Reminders::
                get_all();

        foreach (
            $reminders as $reminder
        ) {

            if (
                empty(
                    $reminder->is_enabled
                )
            ) {
                continue;
            }

            $result[
                'reminders_checked'
            ]++;

            $reminder_result =
                self::process_reminder(
                    $reminder,
                    $window_start,
                    $window_end
                );

            foreach (
                array(
                    'bookings_matched',
                    'recipients_processed',
                    'sent',
                    'failed',
                    'skipped',
                )
                as $key
            ) {

                $result[ $key ] +=
                    isset(
                        $reminder_result[
                            $key
                        ]
                    )
                        ? absint(
                            $reminder_result[
                                $key
                            ]
                        )
                        : 0;
            }
        }

        return $result;
    }

   /**
     * Process one reminder.
     *
     * @param object $reminder     Reminder record.
     * @param int    $window_start UTC window start.
     * @param int    $window_end   UTC window end.
     *
     * @return array
     */
    private static function process_reminder(
        $reminder,
        $window_start,
        $window_end
    ) {

        $result =
            array(
                'bookings_matched' =>
                    0,

                'recipients_processed' =>
                    0,

                'sent' =>
                    0,

                'failed' =>
                    0,

                'skipped' =>
                    0,
            );

        $booking_ids =
            self::get_due_booking_ids(
                $reminder,
                $window_start,
                $window_end
            );

        $result[
            'bookings_matched'
        ] =
            count(
                $booking_ids
            );

        foreach (
            $booking_ids
            as $booking_id
        ) {

            $booking_result =
                self::process_booking(
                    $reminder,
                    $booking_id
                );

            foreach (
                array(
                    'recipients_processed',
                    'sent',
                    'failed',
                    'skipped',
                )
                as $key
            ) {

                $result[ $key ] +=
                    isset(
                        $booking_result[
                            $key
                        ]
                    )
                        ? absint(
                            $booking_result[
                                $key
                            ]
                        )
                        : 0;
            }
        }

        return $result;
    }


    /**
     * Find confirmed bookings whose reminder is due.
     *
     * Before reminders are calculated from booking_start.
     * After reminders are calculated from booking_end.
     *
     * @param object $reminder     Reminder record.
     * @param int    $window_start UTC window start.
     * @param int    $window_end   UTC window end.
     *
     * @return array
     */
    private static function get_due_booking_ids(
        $reminder,
        $window_start,
        $window_end
    ) {

        global $wpdb;

        $minutes =
            TutorHelper_Pro_Email_Reminders::
                convert_timing_to_minutes(
                    $reminder->timing_amount,
                    $reminder->timing_unit
                );

        $offset =
            $minutes
            * 60;

        $is_before =
            'before'
            === sanitize_key(
                $reminder->
                    timing_direction
            );

        if ( $is_before ) {

            /*
            * due = booking_start - offset
            *
            * Therefore:
            * booking_start = due + offset.
            */
            $booking_window_start =
                $window_start
                + $offset;

            $booking_window_end =
                $window_end
                + $offset;

            $time_column =
                'booking_start';

        } else {

            /*
            * due = booking_end + offset
            *
            * Therefore:
            * booking_end = due - offset.
            */
            $booking_window_start =
                $window_start
                - $offset;

            $booking_window_end =
                $window_end
                - $offset;

            $time_column =
                'booking_end';
        }

        $table_name =
            TutorHelper_Booking_Records::
                get_table_name();

        $sql =
            'SELECT id
            FROM %i
            WHERE status = %s
            AND %i >= %s
            AND %i <= %s';

        $args =
            array(
                $table_name,

                TutorHelper_Booking_Records::
                    STATUS_CONFIRMED,

                $time_column,

                gmdate(
                    'Y-m-d H:i:s',
                    $booking_window_start
                ),

                $time_column,

                gmdate(
                    'Y-m-d H:i:s',
                    $booking_window_end
                ),
            );

        /*
        * A before-lesson reminder must never be sent once
        * that lesson has actually started.
        */
        if ( $is_before ) {

            $sql .=
                ' AND booking_start > %s';

            $args[] =
                gmdate(
                    'Y-m-d H:i:s',
                    $window_end
                );
        }

        $booking_type_ids =
            TutorHelper_Pro_Email_Reminders::
                get_booking_type_ids(
                    absint(
                        $reminder->id
                    )
                );

        if (
            ! empty(
                $booking_type_ids
            )
        ) {

            $placeholders =
                implode(
                    ', ',
                    array_fill(
                        0,
                        count(
                            $booking_type_ids
                        ),
                        '%d'
                    )
                );

            $sql .=
                ' AND booking_type_id IN ('
                . $placeholders
                . ')';

            foreach (
                $booking_type_ids
                as $booking_type_id
            ) {
                $args[] =
                    absint(
                        $booking_type_id
                    );
            }
        }

        $ids =
            $wpdb->get_col(
                $wpdb->prepare(
                    $sql,
                    $args
                )
            );

        return array_values(
            array_filter(
                array_map(
                    'absint',
                    is_array( $ids )
                        ? $ids
                        : array()
                )
            )
        );
    }


    /**
     * Deliver one reminder for one booking.
     *
     * @param object $reminder   Reminder record.
     * @param int    $booking_id Booking ID.
     *
     * @return array
     */
    private static function process_booking(
        $reminder,
        $booking_id
    ) {

        $result =
            array(
                'recipients_processed' =>
                    0,

                'sent' =>
                    0,

                'failed' =>
                    0,

                'skipped' =>
                    0,
            );

        $context =
            TutorHelper_Booking_Email_Context::
                build(
                    $booking_id
                );

        if ( is_wp_error( $context ) ) {

            if (
                class_exists(
                    'TutorHelper_Logger'
                )
            ) {
                TutorHelper_Logger::error(
                    'TutorHelper reminder booking context could not be built.',
                    array(
                        'booking_id' =>
                            absint(
                                $booking_id
                            ),

                        'error' =>
                            $context->
                                get_error_message(),
                    )
                );
            }

            return $result;
        }

        $booking =
            $context['booking'];

		$context = self::add_online_lesson_placeholders(
			$context,
			$booking_id
		);
		if ( class_exists( 'TutorHelper_Pro_Lesson_Follow_Up' ) ) {
			$context['placeholders'] = array_merge(
				isset( $context['placeholders'] ) && is_array( $context['placeholders'] ) ? $context['placeholders'] : array(),
				TutorHelper_Pro_Lesson_Follow_Up::get_reminder_homework_placeholders( $booking_id )
			);
		}

        $template_key =
            TutorHelper_Pro_Email_Reminders::
                get_template_key(
                    absint(
                        $reminder->id
                    )
                );

        $scheduled_for =
            self::get_scheduled_time(
                $reminder,
                $booking
            );

        if (
            ! empty(
                $reminder->
                    recipient_student
            )
        ) {

            $status =
                self::send_recipient(
                    $reminder,
                    $booking_id,
                    'student',
                    $context[
                        'student_email'
                    ],
                    $scheduled_for,
                    $template_key,
                    $context
                );

            self::add_recipient_result(
                $result,
                $status
            );
        }

        if (
            ! empty(
                $reminder->
                    recipient_parent
            )
        ) {

            $parent =
                TutorHelper_Students::
                    get_parent_details(
                        absint(
                            $booking->
                                student_user_id
                        )
                    );

            $parent_email =
                isset(
                    $parent['email']
                )
                    ? sanitize_email(
                        $parent['email']
                    )
                    : '';

            $status =
                self::send_recipient(
                    $reminder,
                    $booking_id,
                    'parent',
                    $parent_email,
                    $scheduled_for,
                    $template_key,
                    $context
                );

            self::add_recipient_result(
                $result,
                $status
            );
        }

        if (
            ! empty(
                $reminder->
                    recipient_tutor
            )
        ) {
            $tutor =
                get_userdata(
                    absint(
                        $booking->
                            tutor_user_id
                    )
                );

            $tutor_email =
                $tutor
                && ! empty( $tutor->user_email )
                    ? sanitize_email(
                        $tutor->user_email
                    )
                    : '';

            $status =
                self::send_recipient(
                    $reminder,
                    $booking_id,
                    'tutor',
                    $tutor_email,
                    $scheduled_for,
                    $template_key,
                    $context
                );

            self::add_recipient_result(
                $result,
                $status
            );
        }

        return $result;
    }


	/**
	 * Add the resolved Zoom or Google Meet URL to reminder placeholders.
	 *
	 * The existing joining details are retained so tutors may include their
	 * own instructions. The resolved meeting URL is appended only for online
	 * lessons and is also exposed separately for custom reminder templates.
	 *
	 * @param array $context    Core booking email context.
	 * @param int   $booking_id Core booking ID.
	 *
	 * @return array
	 */
	private static function add_online_lesson_placeholders(
		$context,
		$booking_id
	) {
		if ( ! class_exists( 'TutorHelper_Pro_Online_Lessons' ) ) {
			return $context;
		}

		return TutorHelper_Pro_Online_Lessons::filter_booking_email_context(
			$context,
			$booking_id
		);
	}

    /**
     * Add one recipient result to a booking summary.
     *
     * @param array  $result Result counters.
     * @param string $status Delivery result.
     *
     * @return void
     */
    private static function add_recipient_result(
        &$result,
        $status
    ) {

        if ( '' === $status ) {
            return;
        }

        $result[
            'recipients_processed'
        ]++;

        if (
            isset(
                $result[ $status ]
            )
        ) {
            $result[ $status ]++;
        }
    }



    /**
     * Calculate when one reminder is due.
     *
     * @param object $reminder Reminder definition.
     * @param object $booking  Booking record.
     *
     * @return string
     */
    private static function get_scheduled_time(
        $reminder,
        $booking
    ) {

        $minutes =
            TutorHelper_Pro_Email_Reminders::
                convert_timing_to_minutes(
                    $reminder->timing_amount,
                    $reminder->timing_unit
                );

        $offset =
            $minutes
            * 60;

        if (
            'before'
            === sanitize_key(
                $reminder->
                    timing_direction
            )
        ) {

            $base =
                strtotime(
                    $booking->booking_start
                    . ' UTC'
                );

            $timestamp =
                $base
                - $offset;

        } else {

            $base =
                strtotime(
                    $booking->booking_end
                    . ' UTC'
                );

            $timestamp =
                $base
                + $offset;
        }

        return gmdate(
            'Y-m-d H:i:s',
            $timestamp
        );
    }


    /**
     * Send and record one reminder recipient.
     *
     * @param object $reminder      Reminder record.
     * @param int    $booking_id    Booking ID.
     * @param string $recipient_type student|parent.
     * @param string $recipient_email Email address.
     * @param string $scheduled_for Scheduled UTC datetime.
     * @param string $template_key  Core template key.
     * @param array  $context       Booking email context.
     *
     * @return string
     */
    private static function send_recipient(
        $reminder,
        $booking_id,
        $recipient_type,
        $recipient_email,
        $scheduled_for,
        $template_key,
        $context
    ) {

        $reminder_id =
            absint(
                $reminder->id
            );

        if (
            self::delivery_complete(
                $reminder_id,
                $booking_id,
                $recipient_type
            )
        ) {
            return;
        }

        $recipient_email =
            sanitize_email(
                $recipient_email
            );

        if (
            ! $recipient_email
            || ! is_email(
                $recipient_email
            )
        ) {

            self::record_delivery(
                $reminder_id,
                $booking_id,
                $recipient_type,
                '',
                $scheduled_for,
                self::STATUS_SKIPPED,
                __(
                    'No valid recipient email address was available.',
                    'tutorhelper-pro'
                )
            );

            return;
        }

        $result =
            TutorHelper_Email_Sender::send(
                $template_key,
                $recipient_email,
                $context[
                    'placeholders'
                ],
                array(
                    'reply_to_email' =>
                        $context[
                            'tutor_email'
                        ],

                    'reply_to_name' =>
                        isset(
                            $context[
                                'placeholders'
                            ][
                                '{tutor_name}'
                            ]
                        )
                            ? $context[
                                'placeholders'
                            ][
                                '{tutor_name}'
                            ]
                            : '',

                    'context' =>
                        array(
                            'booking_id' =>
                                $booking_id,

                            'reminder_id' =>
                                $reminder_id,

                            'recipient_type' =>
                                $recipient_type,

                            'action' =>
                                'scheduled_reminder',
                        ),
                )
            );

        if ( is_wp_error( $result ) ) {

            self::record_delivery(
                $reminder_id,
                $booking_id,
                $recipient_type,
                $recipient_email,
                $scheduled_for,
                self::STATUS_FAILED,
                $result->
                    get_error_message()
            );

            return self::STATUS_FAILED;
        }

        self::record_delivery(
            $reminder_id,
            $booking_id,
            $recipient_type,
            $recipient_email,
            $scheduled_for,
            self::STATUS_SENT
        );

        return self::STATUS_SENT;
    }


    /**
     * Determine whether a recipient is already complete.
     *
     * Sent and intentionally skipped deliveries should not run again.
     * Failed deliveries may be retried during the cron grace window.
     *
     * @param int    $reminder_id   Reminder ID.
     * @param int    $booking_id    Booking ID.
     * @param string $recipient_type Recipient type.
     *
     * @return bool
     */
    private static function delivery_complete(
        $reminder_id,
        $booking_id,
        $recipient_type
    ) {

        global $wpdb;

        $table_name =
            TutorHelper_Pro_Database::
                get_table_name(
                    'email_reminder_deliveries'
                );

        $status =
            $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT status
                    FROM %i
                    WHERE reminder_id = %d
                    AND booking_id = %d
                    AND recipient_type = %s',
                    $table_name,
                    $reminder_id,
                    $booking_id,
                    $recipient_type
                )
            );

        return in_array(
            $status,
            array(
                self::STATUS_SENT,
                self::STATUS_SKIPPED,
            ),
            true
        );
    }


    /**
     * Create or update a delivery record.
     *
     * @param int    $reminder_id    Reminder ID.
     * @param int    $booking_id     Booking ID.
     * @param string $recipient_type Recipient type.
     * @param string $recipient_email Recipient email.
     * @param string $scheduled_for  Scheduled UTC datetime.
     * @param string $status         Delivery status.
     * @param string $error_message  Optional error message.
     *
     * @return void
     */
    private static function record_delivery(
        $reminder_id,
        $booking_id,
        $recipient_type,
        $recipient_email,
        $scheduled_for,
        $status,
        $error_message = ''
    ) {

        global $wpdb;

        $table_name =
            TutorHelper_Pro_Database::
                get_table_name(
                    'email_reminder_deliveries'
                );

        $now =
            current_time(
                'mysql',
                true
            );

        $existing_id =
            $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT id
                    FROM %i
                    WHERE reminder_id = %d
                    AND booking_id = %d
                    AND recipient_type = %s',
                    $table_name,
                    $reminder_id,
                    $booking_id,
                    $recipient_type
                )
            );

        $data =
            array(
                'recipient_email' =>
                    $recipient_email,

                'scheduled_for' =>
                    $scheduled_for,

                'status' =>
                    $status,

                'last_attempt_at' =>
                    $now,

                'updated_at' =>
                    $now,

                'error_message' =>
                    $error_message,
            );

        if (
            self::STATUS_SENT
            === $status
        ) {
            $data['sent_at'] =
                $now;
        }

        if ( $existing_id ) {

            $wpdb->query(
                $wpdb->prepare(
                    'UPDATE %i
                    SET recipient_email = %s,
                        scheduled_for = %s,
                        status = %s,
                        attempts = attempts + 1,
                        last_attempt_at = %s,
                        sent_at = %s,
                        error_message = %s,
                        updated_at = %s
                    WHERE id = %d',
                    $table_name,
                    $recipient_email,
                    $scheduled_for,
                    $status,
                    $now,
                    self::STATUS_SENT
                        === $status
                            ? $now
                            : null,
                    $error_message,
                    $now,
                    absint(
                        $existing_id
                    )
                )
            );

            return;
        }

        $wpdb->insert(
            $table_name,
            array(
                'reminder_id' =>
                    $reminder_id,

                'booking_id' =>
                    $booking_id,

                'recipient_type' =>
                    $recipient_type,

                'recipient_email' =>
                    $recipient_email,

                'scheduled_for' =>
                    $scheduled_for,

                'status' =>
                    $status,

                'attempts' =>
                    1,

                'last_attempt_at' =>
                    $now,

                'sent_at' =>
                    self::STATUS_SENT
                    === $status
                        ? $now
                        : null,

                'error_message' =>
                    $error_message,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now,
            )
        );
    }

}
