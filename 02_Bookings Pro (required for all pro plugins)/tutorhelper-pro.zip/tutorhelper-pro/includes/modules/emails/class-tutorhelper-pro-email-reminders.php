<?php
/**
 * TutorHelper Pro custom email reminders.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages custom reminder template records.
 */
final class TutorHelper_Pro_Email_Reminders {



	/**
	 * Retrieve all custom reminders.
	 *
	 * @return array
	 */
	public static function get_all() {

		global $wpdb;

		$table_name =
			TutorHelper_Pro_Database::get_table_name(
				'email_reminders'
			);

		$results =
			$wpdb->get_results(
				$wpdb->prepare(
					'SELECT *
					FROM %i
					ORDER BY name ASC',
					$table_name
				)
			);

		return is_array( $results )
			? $results
			: array();
	}


    /**
     * Return the Core email-template key for a reminder.
     *
     * @param int $reminder_id Reminder ID.
     *
     * @return string
     */
    public static function get_template_key(
        $reminder_id
    ) {

        return 'tutorhelper_pro_reminder_'
            . absint(
                $reminder_id
            );
    }


    /**
     * Register custom reminders with the shared Core email registry.
     *
     * This allows reminders to use TutorHelper_Email_Sender and the
     * standard TutorHelper email wrapper.
     *
     * @return void
     */
    public static function register_templates() {

        $reminders =
            self::get_all();

        foreach (
            $reminders as $reminder
        ) {

            $reminder_id =
                absint(
                    $reminder->id
                );

            if ( ! $reminder_id ) {
                continue;
            }

            TutorHelper_Email_Templates::register(
                self::get_template_key(
                    $reminder_id
                ),
                array(
                    'module' =>
                        'pro_reminders',

                    'label' =>
                        sanitize_text_field(
                            $reminder->name
                        ),

                    'description' =>
                        __(
                            'Custom TutorHelper Pro lesson reminder.',
                            'tutorhelper-pro'
                        ),

                    'heading' =>
                        sanitize_text_field(
                            $reminder->name
                        ),

                    'recipient' =>
                        'custom',

                    'enabled' =>
                        ! empty(
                            $reminder->is_enabled
                        ),

                    'subject' =>
                        $reminder->subject,

                    'body' =>
                        $reminder->body,

                    'placeholders' =>
                        array(
                            '{student_name}',
                            '{first_name}',
                            '{student_email}',
                            '{booking_type}',
                            '{lesson_date}',
                            '{lesson_time}',
                            '{location_type}',
                            '{joining_details}',
							'{lesson_link}',
							'{homework_set}',
							'{homework_due}',
                            '{tutor_name}',
                            '{site_name}',
                            '{student_dashboard_url}',
                        ),
                )
            );
        }
    }




	/**
	 * Retrieve one reminder.
	 *
	 * @param int $reminder_id Reminder ID.
	 *
	 * @return object|null
	 */
	public static function get_by_id(
		$reminder_id
	) {

		global $wpdb;

		$reminder_id =
			absint( $reminder_id );

		if ( ! $reminder_id ) {
			return null;
		}

		$table_name =
			TutorHelper_Pro_Database::get_table_name(
				'email_reminders'
			);

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT *
				FROM %i
				WHERE id = %d',
				$table_name,
				$reminder_id
			)
		);
	}


    /**
     * Return Booking Type IDs assigned to a reminder.
     *
     * An empty array means all Booking Types.
     *
     * @param int $reminder_id Reminder ID.
     *
     * @return array
     */
    public static function get_booking_type_ids(
        $reminder_id
    ) {

        global $wpdb;

        $reminder_id =
            absint( $reminder_id );

        if ( ! $reminder_id ) {
            return array();
        }

        $table_name =
            TutorHelper_Pro_Database::get_table_name(
                'email_reminder_booking_types'
            );

        $ids =
            $wpdb->get_col(
                $wpdb->prepare(
                    'SELECT booking_type_id
                    FROM %i
                    WHERE reminder_id = %d
                    ORDER BY booking_type_id ASC',
                    $table_name,
                    $reminder_id
                )
            );

        return array_values(
            array_filter(
                array_map(
                    'absint',
                    is_array( $ids )
                        ? $ids
                        : array()
                )
            )
        );
    }


    /**
     * Replace Booking Type relationships for one reminder.
     *
     * @param int   $reminder_id     Reminder ID.
     * @param array $booking_type_ids Booking Type IDs.
     *
     * @return true|WP_Error
     */
    private static function save_booking_types(
        $reminder_id,
        $booking_type_ids
    ) {

        global $wpdb;

        $reminder_id =
            absint( $reminder_id );

        $table_name =
            TutorHelper_Pro_Database::get_table_name(
                'email_reminder_booking_types'
            );

        $wpdb->delete(
            $table_name,
            array(
                'reminder_id' =>
                    $reminder_id,
            ),
            array(
                '%d',
            )
        );

        $booking_type_ids =
            array_values(
                array_unique(
                    array_filter(
                        array_map(
                            'absint',
                            is_array(
                                $booking_type_ids
                            )
                                ? $booking_type_ids
                                : array()
                        )
                    )
                )
            );

        foreach (
            $booking_type_ids
            as $booking_type_id
        ) {

            if (
                ! TutorHelper_Booking_Types::get_by_id(
                    $booking_type_id
                )
            ) {
                continue;
            }

            $inserted =
                $wpdb->insert(
                    $table_name,
                    array(
                        'reminder_id' =>
                            $reminder_id,

                        'booking_type_id' =>
                            $booking_type_id,

                        'created_at' =>
                            current_time(
                                'mysql',
                                true
                            ),
                    ),
                    array(
                        '%d',
                        '%d',
                        '%s',
                    )
                );

            if ( false === $inserted ) {
                return new WP_Error(
                    'tutorhelper_pro_reminder_booking_types_failed',
                    __(
                        'The reminder Booking Types could not be saved.',
                        'tutorhelper-pro'
                    )
                );
            }
        }

        return true;
    }


    /**
     * Sanitise submitted reminder data.
     *
     * @param array $data Raw reminder data.
     *
     * @return array
     */
    private static function sanitize_data(
        $data
    ) {

        $data =
            is_array( $data )
                ? $data
                : array();

        return array(
            'name' =>
                isset( $data['name'] )
                && ! is_array( $data['name'] )
                    ? sanitize_text_field(
                        wp_unslash(
                            $data['name']
                        )
                    )
                    : '',

            'subject' =>
                isset( $data['subject'] )
                && ! is_array( $data['subject'] )
                    ? sanitize_text_field(
                        wp_unslash(
                            $data['subject']
                        )
                    )
                    : '',

            'body' =>
                isset( $data['body'] )
                && ! is_array( $data['body'] )
                    ? wp_kses_post(
                        wp_unslash(
                            $data['body']
                        )
                    )
                    : '',

            'recipient_student' =>
                ! empty(
                    $data[
                        'recipient_student'
                    ]
                )
                    ? 1
                    : 0,

            'recipient_parent' =>
                ! empty(
                    $data[
                        'recipient_parent'
                    ]
                )
                    ? 1
                    : 0,

            'recipient_tutor' =>
                ! empty(
                    $data[
                        'recipient_tutor'
                    ]
                )
                    ? 1
                    : 0,

            'timing_amount' =>
                isset(
                    $data[
                        'timing_amount'
                    ]
                )
                    ? absint(
                        $data[
                            'timing_amount'
                        ]
                    )
                    : 0,

            'timing_unit' =>
                isset(
                    $data[
                        'timing_unit'
                    ]
                )
                && ! is_array(
                    $data[
                        'timing_unit'
                    ]
                )
                    ? sanitize_key(
                        wp_unslash(
                            $data[
                                'timing_unit'
                            ]
                        )
                    )
                    : '',

            'timing_direction' =>
                isset(
                    $data[
                        'timing_direction'
                    ]
                )
                && ! is_array(
                    $data[
                        'timing_direction'
                    ]
                )
                    ? sanitize_key(
                        wp_unslash(
                            $data[
                                'timing_direction'
                            ]
                        )
                    )
                    : '',

            'is_enabled' =>
                ! empty(
                    $data['is_enabled']
                )
                    ? 1
                    : 0,
        );
    }


    /**
     * Validate reminder data.
     *
     * @param array $data Sanitised reminder data.
     *
     * @return true|WP_Error
     */
    private static function validate_data(
        $data
    ) {

        if ( '' === trim( $data['name'] ) ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_name_required',
                __(
                    'Enter a name for the reminder.',
                    'tutorhelper-pro'
                )
            );
        }

        if ( '' === trim( $data['subject'] ) ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_subject_required',
                __(
                    'Enter an email subject.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            '' === trim(
                wp_strip_all_tags(
                    $data['body']
                )
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_body_required',
                __(
                    'Enter a reminder message.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            ! $data['recipient_student']
            && ! $data['recipient_parent']
            && ! $data['recipient_tutor']
        ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_recipient_required',
                __(
                    'Select at least one reminder recipient.',
                    'tutorhelper-pro'
                )
            );
        }

        if ( ! $data['timing_amount'] ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_timing_required',
                __(
                    'Enter when the reminder should be sent.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            ! in_array(
                $data['timing_unit'],
                array(
                    'minutes',
                    'hours',
                    'days',
                ),
                true
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_unit_invalid',
                __(
                    'The reminder timing unit is invalid.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            ! in_array(
                $data['timing_direction'],
                array(
                    'before',
                    'after',
                ),
                true
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_direction_invalid',
                __(
                    'The reminder timing direction is invalid.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            'before'
            === $data['timing_direction']
        ) {

            $timing_minutes =
                self::convert_timing_to_minutes(
                    $data['timing_amount'],
                    $data['timing_unit']
                );

            if ( $timing_minutes < 15 ) {
                return new WP_Error(
                    'tutorhelper_pro_reminder_timing_too_short',
                    __(
                        'Reminders scheduled before a lesson must be set at least 15 minutes in advance.',
                        'tutorhelper-pro'
                    )
                );
            }
        }

        return true;
    }


    /**
     * Convert reminder timing to minutes.
     *
     * @param int    $amount Timing amount.
     * @param string $unit   Timing unit.
     *
     * @return int
     */
    public static function convert_timing_to_minutes(
        $amount,
        $unit
    ) {

        $amount =
            absint(
                $amount
            );

        switch ( $unit ) {

            case 'days':
                return $amount
                    * 24 * 60;

            case 'hours':
                return $amount
                    * 60;

            case 'minutes':
            default:
                return $amount;
        }
    }



    /**
     * Create a custom reminder.
     *
     * @param array $data Raw submitted data.
     *
     * @return int|WP_Error
     */
    public static function create(
        $data
    ) {

        global $wpdb;

        $clean =
            self::sanitize_data(
                $data
            );

        $validation =
            self::validate_data(
                $clean
            );

        if ( is_wp_error( $validation ) ) {
            return $validation;
        }

        $slug =
        'reminder-'
        . wp_generate_uuid4();

        $now =
            current_time(
                'mysql',
                true
            );

        $table_name =
            TutorHelper_Pro_Database::get_table_name(
                'email_reminders'
            );

        $inserted =
            $wpdb->insert(
                $table_name,
                array(
                    'name' =>
                        $clean['name'],

                    'slug' =>
                        $slug,

                    'subject' =>
                        $clean['subject'],

                    'body' =>
                        $clean['body'],

                    'recipient_student' =>
                        $clean[
                            'recipient_student'
                        ],

                    'recipient_parent' =>
                        $clean[
                            'recipient_parent'
                        ],

                    'recipient_tutor' =>
                        $clean[
                            'recipient_tutor'
                        ],

                    'timing_amount' =>
                        $clean[
                            'timing_amount'
                        ],

                    'timing_unit' =>
                        $clean[
                            'timing_unit'
                        ],

                    'timing_direction' =>
                        $clean[
                            'timing_direction'
                        ],

                    'is_enabled' =>
                        $clean['is_enabled'],

                    'created_at' =>
                        $now,

                    'updated_at' =>
                        $now,
                )
            );

        if ( false === $inserted ) {

            TutorHelper_Logger::error(
                'Pro email reminder creation failed.',
                array(
                    'database_error' =>
                        $wpdb->last_error,
                )
            );

            return new WP_Error(
                'tutorhelper_pro_reminder_create_failed',
                __(
                    'The reminder could not be created.',
                    'tutorhelper-pro'
                )
            );
        }

        $reminder_id =
            absint(
                $wpdb->insert_id
            );

        $booking_types =
            isset(
                $data[
                    'booking_type_ids'
                ]
            )
            && is_array(
                $data[
                    'booking_type_ids'
                ]
            )
                ? $data[
                    'booking_type_ids'
                ]
                : array();

        $result =
            self::save_booking_types(
                $reminder_id,
                $booking_types
            );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return $reminder_id;
    }


    /**
     * Update a reminder.
     *
     * @param int   $reminder_id Reminder ID.
     * @param array $data        Raw submitted data.
     *
     * @return true|WP_Error
     */
    public static function update(
        $reminder_id,
        $data
    ) {

        global $wpdb;

        $reminder_id =
            absint( $reminder_id );

        if (
            ! $reminder_id
            || ! self::get_by_id(
                $reminder_id
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_not_found',
                __(
                    'The reminder could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        $clean =
            self::sanitize_data(
                $data
            );

        $validation =
            self::validate_data(
                $clean
            );

        if ( is_wp_error( $validation ) ) {
            return $validation;
        }

        $table_name =
            TutorHelper_Pro_Database::get_table_name(
                'email_reminders'
            );

        $updated =
            $wpdb->update(
                $table_name,
                array(
                    'name' =>
                        $clean['name'],

                    'subject' =>
                        $clean['subject'],

                    'body' =>
                        $clean['body'],

                    'recipient_student' =>
                        $clean[
                            'recipient_student'
                        ],

                    'recipient_parent' =>
                        $clean[
                            'recipient_parent'
                        ],

                    'recipient_tutor' =>
                        $clean[
                            'recipient_tutor'
                        ],

                    'timing_amount' =>
                        $clean[
                            'timing_amount'
                        ],

                    'timing_unit' =>
                        $clean[
                            'timing_unit'
                        ],

                    'timing_direction' =>
                        $clean[
                            'timing_direction'
                        ],

                    'is_enabled' =>
                        $clean['is_enabled'],

                    'updated_at' =>
                        current_time(
                            'mysql',
                            true
                        ),
                ),
                array(
                    'id' =>
                        $reminder_id,
                )
            );

        if ( false === $updated ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_update_failed',
                __(
                    'The reminder could not be updated.',
                    'tutorhelper-pro'
                )
            );
        }

        $booking_types =
            isset(
                $data[
                    'booking_type_ids'
                ]
            )
            && is_array(
                $data[
                    'booking_type_ids'
                ]
            )
                ? $data[
                    'booking_type_ids'
                ]
                : array();

        return self::save_booking_types(
            $reminder_id,
            $booking_types
        );
    }


    /**
     * Delete a custom reminder.
     *
     * @param int $reminder_id Reminder ID.
     *
     * @return true|WP_Error
     */
    public static function delete(
        $reminder_id
    ) {

        global $wpdb;

        $reminder_id =
            absint( $reminder_id );

        if ( ! $reminder_id ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_invalid',
                __(
                    'The reminder could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        $relationship_table =
            TutorHelper_Pro_Database::get_table_name(
                'email_reminder_booking_types'
            );

        $wpdb->delete(
            $relationship_table,
            array(
                'reminder_id' =>
                    $reminder_id,
            ),
            array(
                '%d',
            )
        );

        $table_name =
            TutorHelper_Pro_Database::get_table_name(
                'email_reminders'
            );

        $deleted =
            $wpdb->delete(
                $table_name,
                array(
                    'id' =>
                        $reminder_id,
                ),
                array(
                    '%d',
                )
            );

        if ( false === $deleted ) {
            return new WP_Error(
                'tutorhelper_pro_reminder_delete_failed',
                __(
                    'The reminder could not be deleted.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }
}
