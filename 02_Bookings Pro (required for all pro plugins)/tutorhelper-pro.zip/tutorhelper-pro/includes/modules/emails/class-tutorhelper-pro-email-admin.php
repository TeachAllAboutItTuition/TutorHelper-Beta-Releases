<?php
/**
 * Enhanced TutorHelper Pro booking email administration.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides the enhanced Pro Booking Hub email interface.
 */
final class TutorHelper_Pro_Email_Admin {


    /**
     * Save reminder admin-post action.
     *
     * @var string
     */
    const SAVE_REMINDER_ACTION =
        'tutorhelper_pro_save_email_reminder';


    /**
     * Delete reminder admin-post action.
     *
     * @var string
     */
    const DELETE_REMINDER_ACTION =
        'tutorhelper_pro_delete_email_reminder';

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_booking_emails_rendered',
			array(
				__CLASS__,
				'render_email_manager',
			)
		);

		add_action(
			'admin_enqueue_scripts',
			array(
				__CLASS__,
				'enqueue_assets',
			)
		);

        add_action(
            'admin_post_'
                . self::SAVE_REMINDER_ACTION,
            array(
                __CLASS__,
                'handle_save_reminder',
            )
        );

        add_action(
            'admin_post_'
                . self::DELETE_REMINDER_ACTION,
            array(
                __CLASS__,
                'handle_delete_reminder',
            )
        );
	}

    /**
     * Render the enhanced Pro Booking Email Manager.
     *
     * @param bool $already_rendered Whether another extension has
     *                               already rendered the tab.
     *
     * @return bool
     */
    public static function render_email_manager(
        $already_rendered
    ) {

        if ( $already_rendered ) {
            return true;
        }

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            return false;
        }

        $modules = apply_filters(
            'tutorhelper_pro_email_template_modules',
            array(
                'bookings',
                'registrations',
            )
        );

        $modules = array_values(
            array_unique(
                array_filter(
                    array_map(
                        'sanitize_key',
                        is_array( $modules )
                            ? $modules
                            : array()
                    )
                )
            )
        );

        $templates = array();

        foreach ( $modules as $module ) {
            $templates = array_merge(
                $templates,
                TutorHelper_Email_Templates::
                    get_by_module(
                        $module
                    )
            );
        }

        $reminders =
            TutorHelper_Pro_Email_Reminders::
                get_all();

        self::render_notices();

        ?>
        <div
            class="tutorhelper-pro-email-manager"
        >
            <?php
            self::render_overview(
                $templates
            );

            self::render_template_list(
                $templates
            );

            self::render_reminder_list(
                $reminders
            );

            self::render_delivery_history();
            ?>
        </div>
        <?php

        return true;
    }


    /**
     * Render universal TutorHelper email delivery history.
     *
     * @return void
     */
    private static function render_delivery_history() {

        $status_filter =
            isset(
                $_GET[
                    'delivery_status'
                ]
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'delivery_status'
                        ]
                    )
                )
                : '';

        $template_filter =
            isset(
                $_GET[
                    'delivery_template'
                ]
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'delivery_template'
                        ]
                    )
                )
                : '';

        $date_from_input =
            isset(
                $_GET[
                    'delivery_date_from'
                ]
            )
                ? sanitize_text_field(
                    wp_unslash(
                        $_GET[
                            'delivery_date_from'
                        ]
                    )
                )
                : '';

        $date_to_input =
            isset(
                $_GET[
                    'delivery_date_to'
                ]
            )
                ? sanitize_text_field(
                    wp_unslash(
                        $_GET[
                            'delivery_date_to'
                        ]
                    )
                )
                : '';

        $date_from = '';
        $date_to   = '';

        $site_timezone =
            wp_timezone();

        $utc_timezone =
            new DateTimeZone(
                'UTC'
            );

        if (
            $date_from_input
            || $date_to_input
        ) {

            if ( $date_from_input ) {

                $from =
                    DateTimeImmutable::
                        createFromFormat(
                            '!Y-m-d',
                            $date_from_input,
                            $site_timezone
                        );

                if ( $from ) {

                    $date_from =
                        $from
                            ->setTime(
                                0,
                                0,
                                0
                            )
                            ->setTimezone(
                                $utc_timezone
                            )
                            ->format(
                                'Y-m-d H:i:s'
                            );
                }
            }

            if ( $date_to_input ) {

                $to =
                    DateTimeImmutable::
                        createFromFormat(
                            '!Y-m-d',
                            $date_to_input,
                            $site_timezone
                        );

                if ( $to ) {

                    $date_to =
                        $to
                            ->setTime(
                                23,
                                59,
                                59
                            )
                            ->setTimezone(
                                $utc_timezone
                            )
                            ->format(
                                'Y-m-d H:i:s'
                            );
                }
            }

        } else {

            /*
            * Default history view:
            * rolling previous 24 hours.
            */
            $now =
                new DateTimeImmutable(
                    'now',
                    $site_timezone
                );

            $date_from =
                $now
                    ->modify(
                        '-24 hours'
                    )
                    ->setTimezone(
                        $utc_timezone
                    )
                    ->format(
                        'Y-m-d H:i:s'
                    );

            $date_to =
                $now
                    ->setTimezone(
                        $utc_timezone
                    )
                    ->format(
                        'Y-m-d H:i:s'
                    );
        }


        $page =
            isset(
                $_GET[
                    'delivery_page'
                ]
            )
                ? max(
                    1,
                    absint(
                        $_GET[
                            'delivery_page'
                        ]
                    )
                )
                : 1;

        $query =
            array(
                'status' =>
                    $status_filter,

                'template_key' =>
                    $template_filter,

                'date_from' =>
                    $date_from,

                'date_to' =>
                    $date_to,

                'page' =>
                    $page,

                'per_page' =>
                    20,
            );

        $deliveries =
            TutorHelper_Pro_Email_Delivery_History::
                get_generic(
                    $query
                );

        $total =
            TutorHelper_Pro_Email_Delivery_History::
                get_generic_count(
                    $query
                );

        $templates =
            TutorHelper_Email_Templates::
                get_all();

        ?>
        <section
			id="tutorhelper-pro-email-delivery-history"
			tabindex="-1"
            class="
                tutorhelper-main-section
                tutorhelper-pro-email-history
            "
        >
            <header
                class="
                    tutorhelper-main-section__header
                    is-compact
                "
            >
                <div
                    class="
                        tutorhelper-main-section__header-content
                    "
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Email delivery history',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        echo esc_html__(
                            'Review automatic TutorHelper email delivery results.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="
                    tutorhelper-main-section__body
                "
            >
                <?php
                /*
                * Keep the reminder worker diagnostics because
                * scheduled reminders still use WP Cron.
                */
                self::render_cron_diagnostics();

                self::render_delivery_filters(
                    $templates,
                    $status_filter,
                    $template_filter,
                    $date_from_input,
                    $date_to_input
                );

                self::render_delivery_table(
                    $deliveries
                );

                self::render_delivery_pagination(
                    $total,
                    $page,
                    20
                );
                ?>
            </div>
        </section>
        <?php
    }


    /**
     * Render reminder cron diagnostics.
     *
     * @return void
     */
    private static function render_cron_diagnostics() {

        $last_run =
            TutorHelper_Pro_Email_Reminder_Cron::
                get_last_run();

        $next_run =
            TutorHelper_Pro_Email_Reminder_Cron::
                get_next_run();

        $result =
            TutorHelper_Pro_Email_Reminder_Cron::
                get_last_result();

        ?>
        <div
            class="tutorhelper-pro-email-cron-summary"
        >
            <div>
                <strong>
                    <?php
                    echo esc_html__(
                        'Last reminder check',
                        'tutorhelper-pro'
                    );
                    ?>
                </strong>

                <span>
                    <?php
                    echo $last_run
                        ? esc_html(
                            wp_date(
                                get_option(
                                    'date_format'
                                )
                                . ' '
                                . get_option(
                                    'time_format'
                                ),
                                $last_run
                            )
                        )
                        : esc_html__(
                            'Not run yet',
                            'tutorhelper-pro'
                        );
                    ?>
                </span>
            </div>

            <div>
                <strong>
                    <?php
                    echo esc_html__(
                        'Next scheduled check',
                        'tutorhelper-pro'
                    );
                    ?>
                </strong>

                <span>
                    <?php
                    echo $next_run
                        ? esc_html(
                            wp_date(
                                get_option(
                                    'date_format'
                                )
                                . ' '
                                . get_option(
                                    'time_format'
                                ),
                                $next_run
                            )
                        )
                        : esc_html__(
                            'Not scheduled',
                            'tutorhelper-pro'
                        );
                    ?>
                </span>
            </div>

            <div>
                <strong>
                    <?php
                    echo esc_html__(
                        'Reminders checked',
                        'tutorhelper-pro'
                    );
                    ?>
                </strong>

                <span>
                    <?php
                    echo esc_html(
                        (string) absint(
                            $result[
                                'reminders_checked'
                            ]
                            ?? 0
                        )
                    );
                    ?>
                </span>
            </div>

            <div>
                <strong>
                    <?php
                    echo esc_html__(
                        'Bookings matched',
                        'tutorhelper-pro'
                    );
                    ?>
                </strong>

                <span>
                    <?php
                    echo esc_html(
                        (string) absint(
                            $result[
                                'bookings_matched'
                            ]
                            ?? 0
                        )
                    );
                    ?>
                </span>
            </div>

            <div>
                <strong>
                    <?php
                    echo esc_html__(
                        'Emails sent',
                        'tutorhelper-pro'
                    );
                    ?>
                </strong>

                <span>
                    <?php
                    echo esc_html(
                        (string) absint(
                            $result['sent']
                            ?? 0
                        )
                    );
                    ?>
                </span>
            </div>

            <div>
                <strong>
                    <?php
                    echo esc_html__(
                        'Failed',
                        'tutorhelper-pro'
                    );
                    ?>
                </strong>

                <span>
                    <?php
                    echo esc_html(
                        (string) absint(
                            $result['failed']
                            ?? 0
                        )
                    );
                    ?>
                </span>
            </div>
        </div>
        <?php
    }


    /**
     * Render universal email-history filters.
     *
     * @param array  $templates         Registered templates.
     * @param string $selected_status   Selected status.
     * @param string $selected_template Selected template.
     *
     * @return void
     */
    private static function render_delivery_filters(
        $templates,
        $selected_status,
        $selected_template,
        $date_from,
        $date_to
    ) {
        ?>
        <form
            method="get"
            class="
                tutorhelper-pro-email-history__filters
            "
        >
            <input
                type="hidden"
                name="page"
                value="<?php
                    echo esc_attr(
                        TutorHelper_Booking_Hub::
                            PAGE_SLUG
                    );
                ?>"
            />

            <input
                type="hidden"
                name="tab"
                value="<?php
                    echo esc_attr(
                        TutorHelper_Booking_Email_Admin::
                            TAB_KEY
                    );
                ?>"
            />

            <select
                name="delivery_status"
                class="tutorhelper-admin-control"
            >
                <option value="">
                    <?php
                    echo esc_html__(
                        'All statuses',
                        'tutorhelper-pro'
                    );
                    ?>
                </option>

                <option
                    value="sent"
                    <?php
                    selected(
                        $selected_status,
                        'sent'
                    );
                    ?>
                >
                    <?php
                    echo esc_html__(
                        'Sent',
                        'tutorhelper-pro'
                    );
                    ?>
                </option>

                <option
                    value="failed"
                    <?php
                    selected(
                        $selected_status,
                        'failed'
                    );
                    ?>
                >
                    <?php
                    echo esc_html__(
                        'Failed',
                        'tutorhelper-pro'
                    );
                    ?>
                </option>
            </select>


            <select
                name="delivery_template"
                class="tutorhelper-admin-control"
            >
                <option value="">
                    <?php
                    echo esc_html__(
                        'All email types',
                        'tutorhelper-pro'
                    );
                    ?>
                </option>

                <?php
                foreach (
                    $templates
                    as $template_key => $template
                ) :
                    ?>
                    <option
                        value="<?php
                            echo esc_attr(
                                $template_key
                            );
                        ?>"
                        <?php
                        selected(
                            $selected_template,
                            $template_key
                        );
                        ?>
                    >
                        <?php
                        echo esc_html(
                            $template[
                                'label'
                            ]
                        );
                        ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label
                class="
                    tutorhelper-pro-email-history__date-filter
                "
            >
                <span>
                    <?php
                    echo esc_html__(
                        'From',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <input
                    type="date"
                    name="delivery_date_from"
                    value="<?php
                        echo esc_attr(
                            $date_from
                        );
                    ?>"
                    class="tutorhelper-admin-control"
                />
            </label>


            <label
                class="
                    tutorhelper-pro-email-history__date-filter
                "
            >
                <span>
                    <?php
                    echo esc_html__(
                        'To',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <input
                    type="date"
                    name="delivery_date_to"
                    value="<?php
                        echo esc_attr(
                            $date_to
                        );
                    ?>"
                    class="tutorhelper-admin-control"
                />
            </label>

            <?php if (
                ! $date_from
                && ! $date_to
            ) : ?>
                <p
                    class="
                        tutorhelper-pro-email-history__range-note
                    "
                >
                    <?php
                    echo esc_html__(
                        'Showing email activity from the past 24 hours. Choose a date range to view older delivery history.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            <?php endif; ?>


            <button
                type="submit"
                class="
                    button
                    tutorhelper-admin-button
                "
            >
                <?php
                echo esc_html__(
                    'Filter',
                    'tutorhelper-pro'
                );
                ?>
            </button>
        </form>
        <?php
    }

    /**
     * Render universal email delivery records.
     *
     * @param array $deliveries Delivery records.
     *
     * @return void
     */
    private static function render_delivery_table(
        $deliveries
    ) {

        if ( empty( $deliveries ) ) {
            ?>
            <p
                class="
                    tutorhelper-pro-email-history__empty
                "
            >
                <?php
                echo esc_html__(
                    'No TutorHelper email delivery attempts have been recorded yet.',
                    'tutorhelper-pro'
                );
                ?>
            </p>
            <?php

            return;
        }

        ?>
        <div
            class="
                tutorhelper-pro-email-history__table-wrap
            "
        >
            <table
                class="
                    widefat
                    striped
                    tutorhelper-pro-email-history__table
                "
            >
                <thead>
                    <tr>
                        <th>
                            <?php
                            echo esc_html__(
                                'Sent',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th>
                            <?php
                            echo esc_html__(
                                'Email',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th>
                            <?php
                            echo esc_html__(
                                'Related to',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th>
                            <?php
                            echo esc_html__(
                                'Recipient',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th>
                            <?php
                            echo esc_html__(
                                'Status',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th>
                            <?php echo esc_html__( 'Saved copy', 'tutorhelper-pro' ); ?>
                        </th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    foreach (
                        $deliveries
                        as $delivery
                    ) {
                        self::render_delivery_row(
                            $delivery
                        );
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <?php
    }


    /**
     * Render one universal email-delivery row.
     *
     * @param object $delivery Delivery record.
     *
     * @return void
     */
    private static function render_delivery_row(
        $delivery
    ) {

        $template_key =
            sanitize_key(
                $delivery->template_key
            );

        $template =
            TutorHelper_Email_Templates::get(
                $template_key
            );

        $email_label =
            $template
            && ! empty(
                $template['label']
            )
                ? $template['label']
                : ucwords(
                    str_replace(
                        '_',
                        ' ',
                        sanitize_key(
                            $delivery->
                                delivery_type
                        )
                    )
                );


        $status =
            sanitize_key(
                $delivery->status
            );

        $status_label =
            'failed' === $status
                ? __(
                    'Failed',
                    'tutorhelper-pro'
                )
                : __(
                    'Sent',
                    'tutorhelper-pro'
                );


        $related_type =
            sanitize_key(
                $delivery->
                    related_object_type
            );

        $related_id =
            absint(
                $delivery->
                    related_object_id
            );

        $related_label =
            __( '—', 'tutorhelper-pro' );

        if (
            $related_id
            && 'booking'
            === $related_type
        ) {

            $related_label =
                sprintf(
                    /* translators: %d: Booking ID. */
                    __(
                        'Booking #%d',
                        'tutorhelper-pro'
                    ),
                    $related_id
                );

        } elseif (
            $related_id
            && 'student'
            === $related_type
        ) {

            $student =
                get_userdata(
                    $related_id
                );

            if (
                $student
                instanceof WP_User
            ) {

                $related_label =
                    $student->
                        display_name;

            } else {

                $related_label =
                    sprintf(
                        /* translators: %d: Student user ID. */
                        __(
                            'Student #%d',
                            'tutorhelper-pro'
                        ),
                        $related_id
                );
            }
        } elseif ( $related_id && 'payment_request' === $related_type ) {
            $related_label = sprintf(
                /* translators: %d: Payment request ID. */
                __( 'Payment request #%d', 'tutorhelper-pro' ),
                $related_id
            );
        }


        $sent_time =
            ! empty(
                $delivery->sent_at
            )
                ? $delivery->sent_at
                : $delivery->created_at;

        $timestamp =
            $sent_time
                ? strtotime(
                    $sent_time
                    . ' UTC'
                )
                : false;

        ?>
        <tr>
            <td>
                <?php
                echo $timestamp
                    ? esc_html(
                        wp_date(
                            get_option(
                                'date_format'
                            )
                            . ' '
                            . get_option(
                                'time_format'
                            ),
                            $timestamp
                        )
                    )
                    : '—';
                ?>
            </td>

            <td>
                <strong>
                    <?php
                    echo esc_html(
                        $email_label
                    );
                    ?>
                </strong>

                <?php
                if (
                    ! empty(
                        $delivery->
                            delivery_type
                    )
                ) :
                    ?>
                    <br />

                    <small>
                        <?php
                        echo esc_html(
                            $delivery->
                                delivery_type
                        );
                        ?>
                    </small>
                <?php endif; ?>
            </td>

            <td>
                <?php
                echo esc_html(
                    $related_label
                );
                ?>
            </td>

            <td>
                <?php
                if (
                    ! empty(
                        $delivery->
                            recipient_type
                    )
                ) :
                    ?>
                    <strong>
                        <?php
                        echo esc_html(
                            ucfirst(
                                $delivery->
                                    recipient_type
                            )
                        );
                        ?>
                    </strong>

                    <br />
                <?php endif; ?>

                <?php
                echo esc_html(
                    $delivery->
                        recipient_email
                );
                ?>
            </td>

            <td>
                <span
                    class="<?php
                        echo esc_attr(
                            'tutorhelper-pro-email-status '
                            . 'is-'
                            . $status
                        );
                    ?>"
                >
                    <?php
                    echo esc_html(
                        $status_label
                    );
                    ?>
                </span>

                <?php
                if (
                    'failed' === $status
                    && ! empty(
                        $delivery->
                            error_message
                    )
                ) :
                    ?>
                    <br />

                    <small>
                        <?php
                        echo esc_html(
                            $delivery->
                                error_message
                        );
                        ?>
                    </small>
                <?php endif; ?>
            </td>

            <td>
                <?php if ( ! empty( $delivery->html_snapshot ) ) : ?>
                    <details class="tutorhelper-pro-email-snapshot">
                        <summary><?php esc_html_e( 'View saved copy', 'tutorhelper-pro' ); ?></summary>
                        <p><strong><?php echo esc_html( $delivery->subject_snapshot ); ?></strong></p>
                        <div class="tutorhelper-pro-email-snapshot__body">
                            <?php echo wp_kses_post( $delivery->html_snapshot ); ?>
                        </div>
                    </details>
                <?php else : ?>
                    <?php echo esc_html__( 'Not retained', 'tutorhelper-pro' ); ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php
    }


    /**
     * Render delivery-history pagination.
     *
     * @param int $total    Total matching rows.
     * @param int $page     Current page.
     * @param int $per_page Rows per page.
     *
     * @return void
     */
    private static function render_delivery_pagination(
        $total,
        $page,
        $per_page
    ) {

        $total_pages =
            (int) ceil(
                $total
                / $per_page
            );

        if ( $total_pages <= 1 ) {
            return;
        }

        $base_url =
            remove_query_arg(
                'delivery_page'
            );

        ?>
        <div
            class="tutorhelper-pro-email-history__pagination"
        >
            <?php
            echo wp_kses_post(
                paginate_links(
                    array(
                        'base' =>
                            add_query_arg(
                                'delivery_page',
                                '%#%',
                                $base_url
                            ),

                        'format' =>
                            '',

                        'current' =>
                            $page,

                        'total' =>
                            $total_pages,

                        'prev_text' =>
                            '&lsaquo;',

                        'next_text' =>
                            '&rsaquo;',
                    )
                )
            );
            ?>
        </div>
        <?php
    }



    /**
     * Render the Email Manager introduction.
     *
     * @param array $templates Registered booking email templates.
     *
     * @return void
     */
    private static function render_overview(
        $templates
    ) {

        $new_reminder_url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Booking_Hub::
                            PAGE_SLUG,

                    'tab' =>
                        TutorHelper_Booking_Email_Admin::
                            TAB_KEY,

                    'new_reminder' =>
                        1,
                ),
                admin_url(
                    'admin.php'
                )
            );

        $new_reminder_url .=
            '#tutorhelper-reminder-editor';

        $template_count =
            is_array( $templates )
                ? count( $templates )
                : 0;

        $enabled_count = 0;

        

        foreach ( $templates as $template ) {
            if (
                ! empty(
                    $template['enabled']
                )
            ) {
                ++$enabled_count;
            }
        }

        ?>
        <section
            class="
                tutorhelper-main-section
                tutorhelper-pro-email-overview
            "
        >
            <header
                class="
                    tutorhelper-main-section__header
                    is-compact
                "
            >
                <div
                    class="
                        tutorhelper-main-section__header-content
                    "
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Email Manager',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        echo esc_html__(
                            'Manage automatic booking emails and create reminder messages for students.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                </div>

                <div
                    class="tutorhelper-pro-email-overview__actions"
                >

                <a
                    class="
                        button
                        tutorhelper-admin-button
                        tutorhelper-admin-button--primary
                    "
                    href="<?php
                        echo esc_url(
                            $new_reminder_url
                        );
                    ?>"
                >
                    <?php
                    echo esc_html__(
                        '+ New reminder',
                        'tutorhelper-pro'
                    );
                    ?>
                </a>
                </div>
            </header>

            <div
                class="
                    tutorhelper-main-section__body
                    tutorhelper-pro-email-summary
                "
            >
                <div
                    class="tutorhelper-pro-email-summary__item"
                >
                    <strong>
                        <?php
                        echo esc_html(
                            $template_count
                        );
                        ?>
                    </strong>

                    <span>
                        <?php
                        echo esc_html__(
                            'Automatic emails',
                            'tutorhelper-pro'
                        );
                        ?>
                    </span>
                </div>

                <div
                    class="tutorhelper-pro-email-summary__item"
                >
                    <strong>
                        <?php
                        echo esc_html(
                            $enabled_count
                        );
                        ?>
                    </strong>

                    <span>
                        <?php
                        echo esc_html__(
                            'Enabled',
                            'tutorhelper-pro'
                        );
                        ?>
                    </span>
                </div>
            </div>
        </section>
        <?php
    }


    /**
     * Render registered automatic booking emails.
     *
     * @param array $templates Registered templates.
     *
     * @return void
     */
    private static function render_template_list(
        $templates
    ) {
        $editing_key =
            isset(
                $_GET['edit_email']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'edit_email'
                        ]
                    )
                )
                : '';

        $editing_template =
            $editing_key
            && isset(
                $templates[
                    $editing_key
                ]
            )
                ? $templates[
                    $editing_key
                ]
                : null;

        ?>
        <section
            class="
                tutorhelper-main-section
                tutorhelper-pro-email-templates
            "
        >
            <header
                class="
                    tutorhelper-main-section__header
                    is-compact
                "
            >
                <div
                    class="
                        tutorhelper-main-section__header-content
                    "
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Automatic emails',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        echo esc_html__(
                            'These messages are sent automatically when the corresponding booking event occurs.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="
                    tutorhelper-main-section__body
                    tutorhelper-pro-email-template-list
                "
            >

                <?php
                if ( $editing_template ) {
                    self::render_template_editor(
                        $editing_template
                    );
                }
                ?>

                <?php if ( empty( $templates ) ) : ?>

                    <p>
                        <?php
                        echo esc_html__(
                            'No booking email templates are currently registered.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                <?php else : ?>

                    <?php
                    foreach (
                        $templates
                        as $template
                    ) {
                        self::render_template_row(
                            $template
                        );
                    }
                    ?>

                <?php endif; ?>

            </div>
        </section>
        <?php
    }

    /**
     * Render one registered system email.
     *
     * @param array $template Template definition.
     *
     * @return void
     */
    private static function render_template_row(
        $template
    ) {

        if (
            empty( $template['key'] )
            || empty( $template['label'] )
        ) {
            return;
        }

        $template_key =
            sanitize_key(
                $template['key']
            );

        $recipient =
            isset( $template['recipient'] )
                ? sanitize_key(
                    $template['recipient']
                )
                : '';

        $enabled =
            ! empty(
                $template['enabled']
            );

        $edit_url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Booking_Hub::
                            PAGE_SLUG,

                    'tab' =>
                        TutorHelper_Booking_Email_Admin::
                            TAB_KEY,

                    'edit_email' =>
                        $template_key,
                ),
                admin_url(
                    'admin.php'
                )
            );
        
        $edit_url .=
            '#tutorhelper-email-editor';

        ?>
        <article
            class="tutorhelper-pro-email-template-row"
        >
            <div
                class="tutorhelper-pro-email-template-row__main"
            >
                <div
                    class="tutorhelper-pro-email-template-row__heading"
                >
                    <h3>
                        <?php
                        echo esc_html(
                            $template['label']
                        );
                        ?>
                    </h3>

                    <span
                        class="
                            tutorhelper-pro-email-badge
                            is-system
                        "
                    >
                        <?php
                        echo esc_html__(
                            'System',
                            'tutorhelper-pro'
                        );
                        ?>
                    </span>
                </div>

                <?php if (
                    ! empty(
                        $template[
                            'description'
                        ]
                    )
                ) : ?>

                    <p>
                        <?php
                        echo esc_html(
                            $template[
                                'description'
                            ]
                        );
                        ?>
                    </p>

                <?php endif; ?>

                <div
                    class="tutorhelper-pro-email-template-row__meta"
                >
                    <span>
                        <strong>
                            <?php
                            echo esc_html__(
                                'To:',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <?php
                        echo esc_html(
                            ucfirst(
                                $recipient
                            )
                        );
                        ?>
                    </span>

                    <span>
                        <strong>
                            <?php
                            echo esc_html__(
                                'Subject:',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <?php
                        echo esc_html(
                            isset(
                                $template[
                                    'subject'
                                ]
                            )
                                ? $template[
                                    'subject'
                                ]
                                : ''
                        );
                        ?>
                    </span>
                </div>
            </div>

            <div
                class="tutorhelper-pro-email-template-row__status"
            >
                <span
                    class="
                        tutorhelper-pro-email-status
                        <?php
                        echo $enabled
                            ? 'is-enabled'
                            : 'is-disabled';
                        ?>
                    "
                >
                    <?php
                    echo esc_html(
                        $enabled
                            ? __(
                                'Enabled',
                                'tutorhelper-pro'
                            )
                            : __(
                                'Disabled',
                                'tutorhelper-pro'
                            )
                    );
                    ?>
                </span>
            </div>

            <div
                class="tutorhelper-pro-email-template-row__actions"
            >
                <a
                    class="
                        button
                        tutorhelper-admin-button
                    "
                    href="<?php
                        echo esc_url(
                            $edit_url
                        );
                    ?>"
                >
                    <?php
                    echo esc_html__(
                        'Edit',
                        'tutorhelper-pro'
                    );
                    ?>
                </a>
            </div>
        </article>
        <?php
    }


    /**
     * Render the editor for one registered email.
     *
     * @param array $template Template definition.
     *
     * @return void
     */
    private static function render_template_editor(
        $template
    ) {

        if ( empty( $template['key'] ) ) {
            return;
        }

        $template_key =
            sanitize_key(
                $template['key']
            );

        $subject =
            isset(
                $template['subject']
            )
                ? $template['subject']
                : '';

        $body =
            isset(
                $template['body']
            )
                ? $template['body']
                : '';

        $placeholders =
            isset(
                $template[
                    'placeholders'
                ]
            )
            && is_array(
                $template[
                    'placeholders'
                ]
            )
                ? $template[
                    'placeholders'
                ]
                : array();

        $close_url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Booking_Hub::
                            PAGE_SLUG,

                    'tab' =>
                        TutorHelper_Booking_Email_Admin::
                            TAB_KEY,
                ),
                admin_url(
                    'admin.php'
                )
            );

        ?>
        <div
            id="tutorhelper-email-editor"
            class="tutorhelper-pro-email-editor"
        >
            <div
                class="tutorhelper-pro-email-editor__form"
            >
                <header
                    class="tutorhelper-pro-email-editor__header"
                >
                    <div>
                        <h3>
                            <?php
                            printf(
                                /* translators: %s: email template name. */
                                esc_html__(
                                    'Edit: %s',
                                    'tutorhelper-pro'
                                ),
                                esc_html(
                                    $template[
                                        'label'
                                    ]
                                )
                            );
                            ?>
                        </h3>

                        <?php if (
                            ! empty(
                                $template[
                                    'description'
                                ]
                            )
                        ) : ?>

                            <p>
                                <?php
                                echo esc_html(
                                    $template[
                                        'description'
                                    ]
                                );
                                ?>
                            </p>

                        <?php endif; ?>
                    </div>
                </header>

                <form
                    method="post"
                    action="<?php
                        echo esc_url(
                            admin_url(
                                'admin-post.php'
                            )
                        );
                    ?>"
                >
                    <input
                        type="hidden"
                        name="action"
                        value="<?php
                            echo esc_attr(
                                TutorHelper_Email_Admin::
                                    SAVE_ACTION
                            );
                        ?>"
                    />

                    <input
                        type="hidden"
                        name="template_key"
                        value="<?php
                            echo esc_attr(
                                $template_key
                            );
                        ?>"
                    />

                    <?php
                    wp_nonce_field(
                        TutorHelper_Email_Admin::
                            SAVE_ACTION
                        . '_'
                        . $template_key
                    );
                    ?>

                    <label
                        class="tutorhelper-pro-email-editor__enabled"
                    >
                        <input
                            type="checkbox"
                            name="enabled"
                            value="1"
                            <?php
                            checked(
                                ! empty(
                                    $template[
                                        'enabled'
                                    ]
                                )
                            );
                            ?>
                        />

                        <span>
                            <?php
                            echo esc_html__(
                                'Send this email',
                                'tutorhelper-pro'
                            );
                            ?>
                        </span>
                    </label>

                    <div
                        class="
                            tutorhelper-input-field
                            is-full-width
                        "
                    >
                        <label
                            for="tutorhelper-pro-email-subject"
                        >
                            <?php
                            echo esc_html__(
                                'Subject',
                                'tutorhelper-pro'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            id="tutorhelper-pro-email-subject"
                            name="subject"
                            class="tutorhelper-admin-control"
                            value="<?php
                                echo esc_attr(
                                    $subject
                                );
                            ?>"
                            required
                        />
                    </div>

                    <div
                        class="
                            tutorhelper-input-field
                            is-full-width
                        "
                    >
                        <label
                            for="tutorhelper-pro-email-body"
                        >
                            <?php
                            echo esc_html__(
                                'Message',
                                'tutorhelper-pro'
                            );
                            ?>
                        </label>

                        <?php
                            wp_editor(
                                $body,
                                'tutorhelper_pro_email_body',
                                array(
                                    'textarea_name' =>
                                        'body',

                                    'textarea_rows' =>
                                        14,

                                    'media_buttons' =>
                                        false,

                                    'teeny' =>
                                        false,

                                    'quicktags' =>
                                        false,

                                    'tinymce' =>
                                        array(
                                            'toolbar1' =>
                                                'bold italic forecolor | bullist numlist | link unlink | undo redo',

                                            'toolbar2' =>
                                                '',
                                        ),
                                )
                            );
                            ?>
                    </div>

                    <?php if (
                        ! empty(
                            $placeholders
                        )
                    ) : ?>

                        <div
                            class="tutorhelper-pro-email-placeholders"
                        >
                            <strong>
                                <?php
                                echo esc_html__(
                                    'Available placeholders',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </strong>

                            <div
                                class="
                                    tutorhelper-pro-email-placeholders__list
                                "
                            >
                                <?php
                                foreach (
                                    $placeholders
                                    as $placeholder
                                ) :
                                    ?>
                                    <button
                                        type="button"
                                        class="tutorhelper-pro-email-placeholder"
                                        data-email-placeholder="<?php
                                            echo esc_attr(
                                                $placeholder
                                            );
                                        ?>"
                                        data-email-editor="tutorhelper_pro_email_body"
                                        title="<?php
                                            echo esc_attr__(
                                                'Insert placeholder',
                                                'tutorhelper-pro'
                                            );
                                        ?>"
                                    >
                                        <code>
                                            <?php
                                            echo esc_html(
                                                $placeholder
                                            );
                                            ?>
                                        </code>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        </div>

                    <?php endif; ?>

                    <div
                        class="tutorhelper-settings-form__actions"
                    >
                        <button
                            type="submit"
                            class="
                                button
                                tutorhelper-admin-button
                                tutorhelper-admin-button--primary
                            "
                        >
                            <?php
                            echo esc_html__(
                                'Save email',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>

                        <a
                            class="
                                button
                                tutorhelper-admin-button
                            "
                            href="<?php
                                echo esc_url(
                                    $close_url
                                );
                            ?>"
                        >
                            <?php
                            echo esc_html__(
                                'Close',
                                'tutorhelper-pro'
                            );
                            ?>
                        </a>
                    </div>
                </form>

                <?php
                self::render_restore_form(
                    $template_key
                );
                ?>
            </div>

            <div
                class="tutorhelper-pro-email-editor__preview"
            >
                <?php
                self::render_preview(
                    $template
                );
                ?>
            </div>
        </div>
        <?php
    }


    /**
     * Render the Restore Default action.
     *
     * @param string $template_key Template key.
     *
     * @return void
     */
    private static function render_restore_form(
        $template_key
    ) {
        ?>
        <form
            method="post"
            action="<?php
                echo esc_url(
                    admin_url(
                        'admin-post.php'
                    )
                );
            ?>"
            class="tutorhelper-pro-email-editor__restore"
        >
            <input
                type="hidden"
                name="action"
                value="<?php
                    echo esc_attr(
                        TutorHelper_Email_Admin::
                            RESTORE_ACTION
                    );
                ?>"
            />

            <input
                type="hidden"
                name="template_key"
                value="<?php
                    echo esc_attr(
                        $template_key
                    );
                ?>"
            />

            <?php
            wp_nonce_field(
                TutorHelper_Email_Admin::
                    RESTORE_ACTION
                . '_'
                . $template_key
            );
            ?>

            <button
                type="submit"
                class="
                    button
                    tutorhelper-admin-button
                "
            >
                <?php
                echo esc_html__(
                    'Restore default',
                    'tutorhelper-pro'
                );
                ?>
            </button>
        </form>
        <?php
    }


    /**
     * Render the current email content as a simple preview.
     *
     * @param array $template Template definition.
     *
     * @return void
     */
    private static function render_preview(
        $template
    ) {

        $subject =
            isset(
                $template['subject']
            )
                ? $template['subject']
                : '';

        $body =
            isset(
                $template['body']
            )
                ? $template['body']
                : '';

        ?>
        <div
            class="tutorhelper-pro-email-preview"
            data-email-preview
            data-email-editor-id="tutorhelper_pro_email_body"
            data-email-subject-id="tutorhelper-pro-email-subject"
        >
            <span
                class="tutorhelper-pro-email-preview__label"
            >
                <?php
                echo esc_html__(
                    'Preview',
                    'tutorhelper-pro'
                );
                ?>
            </span>

            <div
                class="tutorhelper-pro-email-preview__message"
            >
                <strong
                    data-email-preview-subject
                >
                    <?php
                    echo esc_html(
                        $subject
                    );
                    ?>
                </strong>

                <div
                    class="tutorhelper-pro-email-preview__body"
                    data-email-preview-body
                >
                    <?php
                    echo wp_kses_post(
                        wpautop(
                            $body
                        )
                    );
                    ?>
                </div>
            </div>

            <p
                class="description"
            >
                <?php
                echo esc_html__(
                    'Live placeholder replacement and test sending will be added in a later phase.',
                    'tutorhelper-pro'
                );
                ?>
            </p>
        </div>
        <?php
    }


    /**
     * Render Email Manager feedback notices.
     *
     * @return void
     */
    private static function render_notices() {

        $status =
            isset(
                $_GET[
                    'tutorhelper_email_status'
                ]
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_email_status'
                        ]
                    )
                )
                : '';

        $reminder_status =
            isset(
                $_GET[
                    'tutorhelper_pro_reminder_status'
                ]
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_pro_reminder_status'
                        ]
                    )
                )
                : '';

        if ( 'saved' === $status ) {
            ?>
            <div
                class="notice notice-success inline"
            >
                <p>
                    <?php
                    echo esc_html__(
                        'Email template saved.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </div>
            <?php

            return;
        }

        if ( 'restored' === $status ) {
            ?>
            <div
                class="notice notice-success inline"
            >
                <p>
                    <?php
                    echo esc_html__(
                        'Email template restored to its default settings.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </div>
            <?php

            return;
        }

        if ( 'error' === $status ) {
            ?>
            <div
                class="notice notice-error inline"
            >
                <p>
                    <?php
                    echo esc_html__(
                        'The email template could not be saved. Check the subject and message and try again.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </div>
            <?php
        }

        if ( 'saved' === $reminder_status ) {
            ?>
            <div
                class="notice notice-success inline"
            >
                <p>
                    <?php
                    echo esc_html__(
                        'The reminder was saved.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </div>
            <?php
        }

        if ( 'deleted' === $reminder_status ) {
            ?>
            <div
                class="notice notice-success inline"
            >
                <p>
                    <?php
                    echo esc_html__(
                        'The reminder template was successfully removed.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </div>
            <?php
        }

        if ( 'error' === $reminder_status ) {
            ?>
            <div
                class="notice notice-error inline"
            >
                <p>
                    <?php
                    echo esc_html__(
                        'The reminder could not be saved.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </div>
            <?php
        }

    }


    /**
     * Load the enhanced Email Manager assets.
     *
     * @param string $hook_suffix Current WordPress admin hook.
     *
     * @return void
     */
    public static function enqueue_assets(
        $hook_suffix
    ) {

        $expected_hook =
            'toplevel_page_'
            . TutorHelper_Admin::MENU_SLUG;

        if (
            $expected_hook
            !== $hook_suffix
        ) {
            return;
        }

        $selected_tab =
            isset( $_GET['tab'] )
                ? sanitize_key(
                    wp_unslash(
                        $_GET['tab']
                    )
                )
                : '';

        if (
            TutorHelper_Booking_Email_Admin::
                TAB_KEY
            !== $selected_tab
        ) {
            return;
        }

        $css_path =
            TUTORHELPER_PRO_PATH
            . 'assets/css/tutorhelper-pro-admin.css';

        wp_enqueue_style(
            'tutorhelper-pro-admin',
            TUTORHELPER_PRO_URL
                . 'assets/css/tutorhelper-pro-admin.css',
            array(
                'tutorhelper-booking-hub',
            ),
            file_exists(
                $css_path
            )
                ? (string) filemtime(
                    $css_path
                )
                : TUTORHELPER_PRO_VERSION
        );

        $script_path =
            TUTORHELPER_PRO_PATH
            . 'assets/js/tutorhelper-pro-email-admin.js';

        wp_enqueue_script(
            'tutorhelper-pro-email-admin',
            TUTORHELPER_PRO_URL
                . 'assets/js/tutorhelper-pro-email-admin.js',
            array(),
            file_exists(
                $script_path
            )
                ? (string) filemtime(
                    $script_path
                )
                : TUTORHELPER_PRO_VERSION,
            true
        );

        wp_localize_script(
            'tutorhelper-pro-email-admin',
            'tutorhelperProEmailAdmin',
            array(
                'placeholders' =>
                    array(
                        '{student_name}' =>
                            'Alex Student',

                        '{first_name}' =>
                            'Alex',

                        '{student_email}' =>
                            'alex@example.com',

                        '{booking_type}' =>
                            'GCSE Maths',

                        '{lesson_date}' =>
                            'Wednesday 26 August 2026',

                        '{lesson_time}' =>
                            '4:30 pm–5:30 pm',

                        '{location_type}' =>
                            'Online',

                        '{student_notes}' =>
                            'Please focus on algebra and quadratic equations.',

                        '{joining_details}' =>
                            'Join online: https://meet.example.com/lesson',

                        '{lesson_link}' =>
                            'https://meet.example.com/lesson',

						'{homework_set}' =>
							'Complete questions 1-5 from the worksheet: https://example.com/homework',

						'{homework_due}' =>
							'Bring your completed binary conversion worksheet.',

                        '{cancellation_reason}' =>
                            'Student is unavailable.',

                        '{tutor_name}' =>
                            'Your Tutor',

                        '{site_name}' =>
                            get_bloginfo(
                                'name'
                            ),

                        '{calendar_url}' =>
                            admin_url(
                                'admin.php?page=tutorhelper'
                            ),

                        '{student_dashboard_url}' =>
                            home_url(
                                '/student-dashboard/'
                            ),
                    ),
            )
        );
    }


    /**
     * Render custom lesson reminders.
     *
     * @param array $reminders Reminder records.
     *
     * @return void
     */
    private static function render_reminder_list(
        $reminders
    ) {

        $new_reminder =
            ! empty(
                $_GET[
                    'new_reminder'
                ]
            );

        $editing_id =
            isset(
                $_GET[
                    'edit_reminder'
                ]
            )
                ? absint(
                    $_GET[
                        'edit_reminder'
                    ]
                )
                : 0;

        $editing_reminder =
            $editing_id
                ? TutorHelper_Pro_Email_Reminders::
                    get_by_id(
                        $editing_id
                    )
                : null;

        ?>
        <section
            class="
                tutorhelper-main-section
                tutorhelper-pro-email-reminders
            "
        >
            <header
                class="
                    tutorhelper-main-section__header
                    is-compact
                "
            >
                <div
                    class="
                        tutorhelper-main-section__header-content
                    "
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Lesson reminders',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        echo esc_html__(
                            'Create scheduled reminder messages for upcoming or recently completed lessons.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="
                    tutorhelper-main-section__body
                    tutorhelper-pro-email-template-list
                "
            >
                <?php
                if ( $new_reminder ) {
                    self::render_reminder_editor();
                } elseif ( $editing_reminder ) {
                    self::render_reminder_editor(
                        $editing_reminder
                    );
                }

                if ( empty( $reminders ) ) {
                    ?>
                    <div
                        class="tutorhelper-pro-email-reminders__empty"
                    >
                        <p>
                            <?php
                            echo esc_html__(
                                'No custom lesson reminders have been created yet.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </p>
                    </div>
                    <?php
                } else {
                    foreach (
                        $reminders as $reminder
                    ) {
                        self::render_reminder_row(
                            $reminder
                        );
                    }
                }
                ?>
            </div>
        </section>
        <?php
    }


    /**
     * Render one custom reminder row.
     *
     * @param object $reminder Reminder record.
     *
     * @return void
     */
    private static function render_reminder_row(
        $reminder
    ) {

        $reminder_id =
            absint(
                $reminder->id
            );

        $edit_url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Booking_Hub::
                            PAGE_SLUG,

                    'tab' =>
                        TutorHelper_Booking_Email_Admin::
                            TAB_KEY,

                    'edit_reminder' =>
                        $reminder_id,
                ),
                admin_url(
                    'admin.php'
                )
            );

        $edit_url .=
            '#tutorhelper-reminder-editor';

        $recipients = array();

        if (
            ! empty(
                $reminder->
                    recipient_student
            )
        ) {
            $recipients[] =
                __(
                    'Student',
                    'tutorhelper-pro'
                );
        }

        if (
            ! empty(
                $reminder->
                    recipient_parent
            )
        ) {
            $recipients[] =
                __(
                    'Parent / guardian',
                    'tutorhelper-pro'
                );
        }

        if (
            ! empty(
                $reminder->
                    recipient_tutor
            )
        ) {
            $recipients[] =
                __(
                    'Tutor',
                    'tutorhelper-pro'
                );
        }

        $booking_type_ids =
            TutorHelper_Pro_Email_Reminders::
                get_booking_type_ids(
                    $reminder_id
                );

        ?>
        <article
            class="tutorhelper-pro-email-template-row"
        >
            <div
                class="tutorhelper-pro-email-template-row__main"
            >
                <div
                    class="tutorhelper-pro-email-template-row__heading"
                >
                    <h3>
                        <?php
                        echo esc_html(
                            $reminder->name
                        );
                        ?>
                    </h3>

                    <span
                        class="
                            tutorhelper-pro-email-badge
                            is-reminder
                        "
                    >
                        <?php
                        echo esc_html__(
                            'Reminder',
                            'tutorhelper-pro'
                        );
                        ?>
                    </span>
                </div>

                <div
                    class="tutorhelper-pro-email-template-row__meta"
                >
                    <span>
                        <strong>
                            <?php
                            echo esc_html__(
                                'To:',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <?php
                        echo esc_html(
                            implode(
                                ', ',
                                $recipients
                            )
                        );
                        ?>
                    </span>

                    <span>
                        <strong>
                            <?php
                            echo esc_html__(
                                'Timing:',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <?php
                        printf(
                            '%1$d %2$s %3$s',
                            absint(
                                $reminder->
                                    timing_amount
                            ),
                            esc_html(
                                $reminder->
                                    timing_unit
                            ),
                            esc_html(
                                $reminder->
                                    timing_direction
                            )
                        );
                        ?>
                    </span>

                    <span>
                        <strong>
                            <?php
                            echo esc_html__(
                                'Booking Types:',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <?php
                        echo empty(
                            $booking_type_ids
                        )
                            ? esc_html__(
                                'All',
                                'tutorhelper-pro'
                            )
                            : esc_html(
                                (string) count(
                                    $booking_type_ids
                                )
                            );
                        ?>
                    </span>
                </div>
            </div>

            <div
                class="tutorhelper-pro-email-template-row__status"
            >
                <span
                    class="
                        tutorhelper-pro-email-status
                        <?php
                        echo ! empty(
                            $reminder->
                                is_enabled
                        )
                            ? 'is-enabled'
                            : 'is-disabled';
                        ?>
                    "
                >
                    <?php
                    echo ! empty(
                        $reminder->
                            is_enabled
                    )
                        ? esc_html__(
                            'Enabled',
                            'tutorhelper-pro'
                        )
                        : esc_html__(
                            'Disabled',
                            'tutorhelper-pro'
                        );
                    ?>
                </span>
            </div>

            <div
                class="tutorhelper-pro-email-template-row__actions"
            >
                <a
                    class="
                        button
                        tutorhelper-admin-button
                    "
                    href="<?php
                        echo esc_url(
                            $edit_url
                        );
                    ?>"
                >
                    <?php
                    echo esc_html__(
                        'Edit',
                        'tutorhelper-pro'
                    );
                    ?>
                </a>
            </div>
        </article>
        <?php
    }


    /**
     * Render the custom reminder editor.
     *
     * @param object|null $reminder Existing reminder, if editing.
     *
     * @return void
     */
    private static function render_reminder_editor(
        $reminder = null
    ) {

        $is_editing =
            $reminder
            && ! empty(
                $reminder->id
            );

        $reminder_id =
            $is_editing
                ? absint(
                    $reminder->id
                )
                : 0;

        $name =
            $is_editing
                ? $reminder->name
                : '';

        $subject =
            $is_editing
                ? $reminder->subject
                : __(
                    'Reminder: your {booking_type} lesson',
                    'tutorhelper-pro'
                );

        $body =
            $is_editing
                ? $reminder->body
                : __(
                    "Hello {student_name},\n\nThis is a reminder about your upcoming {booking_type} lesson.\n\nDate: {lesson_date}\nTime: {lesson_time}\nLocation: {location_type}\n\n{joining_details}\n\nBest wishes,\n{tutor_name}",
                    'tutorhelper-pro'
                );

        $selected_booking_types =
            $is_editing
                ? TutorHelper_Pro_Email_Reminders::
                    get_booking_type_ids(
                        $reminder_id
                    )
                : array();

        $booking_types =
            TutorHelper_Booking_Types::
                get_active();

        $close_url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Booking_Hub::
                            PAGE_SLUG,

                    'tab' =>
                        TutorHelper_Booking_Email_Admin::
                            TAB_KEY,
                ),
                admin_url(
                    'admin.php'
                )
            );

        $placeholders =
            array(
                '{student_name}',
                '{first_name}',
                '{student_email}',
                '{booking_type}',
                '{lesson_date}',
                '{lesson_time}',
                '{location_type}',
                '{joining_details}',
				'{lesson_link}',
				'{homework_set}',
				'{homework_due}',
                '{tutor_name}',
                '{site_name}',
                '{student_dashboard_url}',
            );

        ?>
        <div
            id="tutorhelper-reminder-editor"
            class="
                tutorhelper-pro-reminder-editor
            "
        >
            <header
                class="tutorhelper-pro-email-editor__header"
            >
                <h3>
                    <?php
                    echo esc_html(
                        $is_editing
                            ? __(
                                'Edit reminder',
                                'tutorhelper-pro'
                            )
                            : __(
                                'Create reminder',
                                'tutorhelper-pro'
                            )
                    );
                    ?>
                </h3>

                <p>
                    <?php
                    echo esc_html__(
                        'Choose when this reminder should be sent and which lessons and recipients it applies to.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </header>

            <form
                method="post"
                action="<?php
                    echo esc_url(
                        admin_url(
                            'admin-post.php'
                        )
                    );
                ?>"
            >
                <input
                    type="hidden"
                    name="action"
                    value="<?php
                        echo esc_attr(
                            self::
                                SAVE_REMINDER_ACTION
                        );
                    ?>"
                />

                <input
                    type="hidden"
                    name="reminder_id"
                    value="<?php
                        echo esc_attr(
                            $reminder_id
                        );
                    ?>"
                />

                <?php
                wp_nonce_field(
                    self::
                        SAVE_REMINDER_ACTION
                );
                ?>

                <!-- ==================================================
                    Reminder configuration
                    ================================================== -->

                <div
                    class="tutorhelper-pro-reminder-editor__configuration"
                >
                    <div
                        class="
                            tutorhelper-input-field
                            is-full-width
                            tutorhelper-pro-reminder-editor__name
                        "
                    >
                        <label
                            for="tutorhelper-pro-reminder-name"
                        >
                            <?php
                            echo esc_html__(
                                'Reminder name',
                                'tutorhelper-pro'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            id="tutorhelper-pro-reminder-name"
                            name="name"
                            class="tutorhelper-admin-control"
                            value="<?php
                                echo esc_attr(
                                    $name
                                );
                            ?>"
                            required
                        />
                    </div>

                    <div
                        class="tutorhelper-pro-reminder-editor__enabled"
                    >
                        <label
                            class="tutorhelper-pro-email-editor__enabled"
                        >
                            <input
                                type="checkbox"
                                name="is_enabled"
                                value="1"
                                <?php
                                checked(
                                    ! $is_editing
                                    || ! empty(
                                        $reminder->
                                            is_enabled
                                    )
                                );
                                ?>
                            />

                            <span>
                                <?php
                                echo esc_html__(
                                    'Enable this reminder',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </span>
                        </label>
                    </div>

                    <fieldset
                        class="
                            tutorhelper-pro-reminder-options
                            tutorhelper-pro-reminder-editor__recipients
                        "
                    >
                        <legend>
                            <?php
                            echo esc_html__(
                                'Recipients',
                                'tutorhelper-pro'
                            );
                            ?>
                        </legend>

                        <label>
                            <input
                                type="checkbox"
                                name="recipient_student"
                                value="1"
                                <?php
                                checked(
                                    ! $is_editing
                                    || ! empty(
                                        $reminder->
                                            recipient_student
                                    )
                                );
                                ?>
                            />

                            <?php
                            echo esc_html__(
                                'Student',
                                'tutorhelper-pro'
                            );
                            ?>
                        </label>

                        <label>
                            <input
                                type="checkbox"
                                name="recipient_parent"
                                value="1"
                                <?php
                                checked(
                                    ! $is_editing
                                    || ! empty(
                                        $reminder->
                                            recipient_parent
                                    )
                                );
                                ?>
                            />

                            <?php
                            echo esc_html__(
                                'Parent / guardian',
                                'tutorhelper-pro'
                            );
                            ?>
                        </label>

                        <label>
                            <input
                                type="checkbox"
                                name="recipient_tutor"
                                value="1"
                                <?php
                                checked(
                                    $is_editing
                                    && ! empty(
                                        $reminder->
                                            recipient_tutor
                                    )
                                );
                                ?>
                            />

                            <?php
                            echo esc_html__(
                                'Tutor',
                                'tutorhelper-pro'
                            );
                            ?>
                        </label>
                    </fieldset>

                    <fieldset
                        class="
                            tutorhelper-pro-reminder-options
                            tutorhelper-pro-reminder-editor__timing
                        "
                    >
                        <legend>
                            <?php
                            echo esc_html__(
                                'Timing',
                                'tutorhelper-pro'
                            );
                            ?>
                        </legend>

                        <div
                            class="tutorhelper-pro-reminder-timing"
                        >
                            <input
                                type="number"
                                min="1"
                                id="tutorhelper-pro-reminder-timing-amount"
                                name="timing_amount"
                                class="tutorhelper-admin-control"
                                value="<?php
                                    echo esc_attr(
                                        $is_editing
                                            ? absint(
                                                $reminder->
                                                    timing_amount
                                            )
                                            : 24
                                    );
                                ?>"
                                required
                            />

                            <select
                                id="tutorhelper-pro-reminder-timing-unit"
                                name="timing_unit"
                                class="tutorhelper-admin-control"
                            >
                                <?php
                                $timing_units =
                                    array(
                                        'minutes' =>
                                            __(
                                                'minutes',
                                                'tutorhelper-pro'
                                            ),

                                        'hours' =>
                                            __(
                                                'hours',
                                                'tutorhelper-pro'
                                            ),

                                        'days' =>
                                            __(
                                                'days',
                                                'tutorhelper-pro'
                                            ),
                                    );

                                foreach (
                                    $timing_units
                                    as $value =>
                                        $label
                                ) :
                                    ?>
                                    <option
                                        value="<?php
                                            echo esc_attr(
                                                $value
                                            );
                                        ?>"
                                        <?php
                                        selected(
                                            $is_editing
                                                ? $reminder->
                                                    timing_unit
                                                : 'hours',
                                            $value
                                        );
                                        ?>
                                    >
                                        <?php
                                        echo esc_html(
                                            $label
                                        );
                                        ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <select
                                id="tutorhelper-pro-reminder-timing-direction"
                                name="timing_direction"
                                class="tutorhelper-admin-control"
                            >
                                <option
                                    value="before"
                                    <?php
                                    selected(
                                        $is_editing
                                            ? $reminder->
                                                timing_direction
                                            : 'before',
                                        'before'
                                    );
                                    ?>
                                >
                                    <?php
                                    echo esc_html__(
                                        'before the lesson',
                                        'tutorhelper-pro'
                                    );
                                    ?>
                                </option>

                                <option
                                    value="after"
                                    <?php
                                    selected(
                                        $is_editing
                                            ? $reminder->
                                                timing_direction
                                            : 'before',
                                        'after'
                                    );
                                    ?>
                                >
                                    <?php
                                    echo esc_html__(
                                        'after the lesson',
                                        'tutorhelper-pro'
                                    );
                                    ?>
                                </option>
                            </select>
                            </div>
                            <p
                                class="tutorhelper-pro-reminder-timing__error"
                                data-reminder-timing-error
                                role="alert"
                                hidden
                            >
                                <?php
                                echo esc_html__(
                                    'Before-lesson reminders must be scheduled at least 15 minutes before the lesson.',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </p>
                        
                    </fieldset>

                    <fieldset
                        class="
                            tutorhelper-pro-reminder-options
                            tutorhelper-pro-reminder-editor__booking-types
                        "
                    >
                        <legend>
                            <?php
                            echo esc_html__(
                                'Booking Types',
                                'tutorhelper-pro'
                            );
                            ?>
                        </legend>

                        <p class="description">
                            <?php
                            echo esc_html__(
                                'Leave all Booking Types unselected to use this reminder for every Booking Type.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </p>

                        <div
                            class="tutorhelper-pro-reminder-booking-types"
                        >
                            <?php
                            foreach (
                                $booking_types
                                as $booking_type
                            ) :

                                $booking_type_id =
                                    absint(
                                        $booking_type->id
                                    );
                                ?>
                                <label>
                                    <input
                                        type="checkbox"
                                        name="booking_type_ids[]"
                                        value="<?php
                                            echo esc_attr(
                                                $booking_type_id
                                            );
                                        ?>"
                                        <?php
                                        checked(
                                            in_array(
                                                $booking_type_id,
                                                $selected_booking_types,
                                                true
                                            )
                                        );
                                        ?>
                                    />

                                    <?php
                                    echo esc_html(
                                        $booking_type->title
                                    );
                                    ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>
                </div>

                <!-- ==================================================
                    Email composition + preview
                    ================================================== -->

                <div
                    class="tutorhelper-pro-reminder-editor__content"
                >
                    <div
                        class="tutorhelper-pro-reminder-editor__compose"
                    >
                        <div
                            class="
                                tutorhelper-input-field
                                is-full-width
                            "
                        >
                            <label
                                for="tutorhelper-pro-reminder-subject"
                            >
                                <?php
                                echo esc_html__(
                                    'Subject',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </label>

                            <input
                                type="text"
                                id="tutorhelper-pro-reminder-subject"
                                name="subject"
                                class="tutorhelper-admin-control"
                                value="<?php
                                    echo esc_attr(
                                        $subject
                                    );
                                ?>"
                                required
                            />
                        </div>

                        <div
                            class="
                                tutorhelper-input-field
                                is-full-width
                                tutorhelper-pro-reminder-editor__message
                            "
                        >
                            <label>
                                <?php
                                echo esc_html__(
                                    'Message',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </label>

                            <?php
                            wp_editor(
                                $body,
                                'tutorhelper_pro_reminder_body',
                                array(
                                    'textarea_name' =>
                                        'body',

                                    'textarea_rows' =>
                                        14,

                                    'media_buttons' =>
                                        false,

                                    'teeny' =>
                                        false,

                                    'quicktags' =>
                                        false,

                                    'tinymce' =>
                                        array(
                                            'toolbar1' =>
                                                'bold italic forecolor | bullist numlist | link unlink | undo redo',

                                            'toolbar2' =>
                                                '',
                                        ),
                                )
                            );
                            ?>
                        </div>

                        <div
                            class="tutorhelper-pro-email-placeholders"
                        >
                            <strong>
                                <?php
                                echo esc_html__(
                                    'Available placeholders',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </strong>

                            <div
                                class="tutorhelper-pro-email-placeholders__list"
                            >
                                <?php
                                foreach (
                                    $placeholders
                                    as $placeholder
                                ) :
                                    ?>
                                    <button
                                        type="button"
                                        class="tutorhelper-pro-email-placeholder"
                                        data-email-placeholder="<?php
                                            echo esc_attr(
                                                $placeholder
                                            );
                                        ?>"
                                        data-email-editor="tutorhelper_pro_reminder_body"
                                        title="<?php
                                            echo esc_attr__(
                                                'Insert placeholder',
                                                'tutorhelper-pro'
                                            );
                                        ?>"
                                    >
                                        <code>
                                            <?php
                                            echo esc_html(
                                                $placeholder
                                            );
                                            ?>
                                        </code>
                                    </button>
                                <?php endforeach; ?>
                            </div>

							<p class="description">
								<?php
								echo wp_kses_post(
									__(
										'For online lessons, TutorHelper automatically adds the booking\'s Google Meet or configured Zoom URL to <code>{joining_details}</code>. Use <code>{lesson_link}</code> if you would like to place the URL separately in your reminder.',
										'tutorhelper-pro'
									)
								);
								?>
							</p>
                        </div>

                        <div
                            class="tutorhelper-settings-form__actions"
                        >
                            <button
                                type="submit"
                                class="
                                    button
                                    tutorhelper-admin-button
                                    tutorhelper-admin-button--primary
                                "
                            >
                                <?php
                                echo esc_html(
                                    $is_editing
                                        ? __(
                                            'Save reminder',
                                            'tutorhelper-pro'
                                        )
                                        : __(
                                            'Create reminder',
                                            'tutorhelper-pro'
                                        )
                                );
                                ?>
                            </button>

                            <a
                                class="
                                    button
                                    tutorhelper-admin-button
                                "
                                href="<?php
                                    echo esc_url(
                                        $close_url
                                    );
                                ?>"
                            >
                                <?php
                                echo esc_html__(
                                    'Close',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </a>
                        </div>
                    </div>

                    <div
                        class="tutorhelper-pro-email-editor__preview"
                    >
                        <?php
                        self::render_reminder_preview(
                            $subject,
                            $body
                        );
                        ?>
                    </div>
                </div>
            </form>

            <?php
            if ( $is_editing ) {
                self::render_reminder_delete_form(
                    $reminder_id
                );
            }
            ?>
        </div>
        <?php
    }


    /**
     * Render a live preview for a custom reminder.
     *
     * @param string $subject Reminder subject.
     * @param string $body    Reminder body.
     *
     * @return void
     */
    private static function render_reminder_preview(
        $subject,
        $body
    ) {
        ?>
        <div
            class="tutorhelper-pro-email-preview"
            data-email-preview
            data-email-editor-id="tutorhelper_pro_reminder_body"
            data-email-subject-id="tutorhelper-pro-reminder-subject"
        >
            <span
                class="tutorhelper-pro-email-preview__label"
            >
                <?php
                echo esc_html__(
                    'Preview',
                    'tutorhelper-pro'
                );
                ?>
            </span>

            <div
                class="tutorhelper-pro-email-preview__message"
            >
                <strong
                    data-email-preview-subject
                >
                    <?php
                    echo esc_html(
                        $subject
                    );
                    ?>
                </strong>

                <div
                    class="tutorhelper-pro-email-preview__body"
                    data-email-preview-body
                >
                    <?php
                    echo wp_kses_post(
                        wpautop(
                            $body
                        )
                    );
                    ?>
                </div>
            </div>

            <p class="description">
                <?php
                echo esc_html__(
                    'Example booking details are used in this preview.',
                    'tutorhelper-pro'
                );
                ?>
            </p>
        </div>
        <?php
    }


    /**
     * Render the Delete Reminder action.
     *
     * @param int $reminder_id Reminder ID.
     *
     * @return void
     */
    private static function render_reminder_delete_form(
        $reminder_id
    ) {

        $reminder_id =
            absint(
                $reminder_id
            );

        if ( ! $reminder_id ) {
            return;
        }

        ?>
        <form
            method="post"
            action="<?php
                echo esc_url(
                    admin_url(
                        'admin-post.php'
                    )
                );
            ?>"
            class="tutorhelper-pro-reminder-delete"
            onsubmit="return confirm('<?php
                echo esc_js(
                    __(
                        'Delete this reminder permanently?',
                        'tutorhelper-pro'
                    )
                );
            ?>');"
        >
            <input
                type="hidden"
                name="action"
                value="<?php
                    echo esc_attr(
                        self::
                            DELETE_REMINDER_ACTION
                    );
                ?>"
            />

            <input
                type="hidden"
                name="reminder_id"
                value="<?php
                    echo esc_attr(
                        $reminder_id
                    );
                ?>"
            />

            <?php
            wp_nonce_field(
                self::
                    DELETE_REMINDER_ACTION
                . '_'
                . $reminder_id
            );
            ?>

            <button
                type="submit"
                class="
                    button
                    tutorhelper-admin-button
                "
            >
                <?php
                echo esc_html__(
                    'Delete reminder',
                    'tutorhelper-pro'
                );
                ?>
            </button>
        </form>
        <?php
    }


    /**
     * Create or update a reminder.
     *
     * @return void
     */
    public static function handle_save_reminder() {

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to manage reminders.',
                    'tutorhelper-pro'
                )
            );
        }

        check_admin_referer(
            self::SAVE_REMINDER_ACTION
        );

        $reminder_id =
            isset(
                $_POST[
                    'reminder_id'
                ]
            )
                ? absint(
                    $_POST[
                        'reminder_id'
                    ]
                )
                : 0;

        $result =
            $reminder_id
                ? TutorHelper_Pro_Email_Reminders::
                    update(
                        $reminder_id,
                        $_POST
                    )
                : TutorHelper_Pro_Email_Reminders::
                    create(
                        $_POST
                    );

        if ( is_wp_error( $result ) ) {
            self::redirect_reminder(
                'error',
                $result->
                    get_error_code()
            );
        }

        self::redirect_reminder(
            'saved'
        );
    }


    /**
     * Delete one custom reminder.
     *
     * @return void
     */
    public static function handle_delete_reminder() {

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to manage reminders.',
                    'tutorhelper-pro'
                )
            );
        }

        $reminder_id =
            isset(
                $_POST[
                    'reminder_id'
                ]
            )
                ? absint(
                    $_POST[
                        'reminder_id'
                    ]
                )
                : 0;

        check_admin_referer(
            self::DELETE_REMINDER_ACTION
            . '_'
            . $reminder_id
        );

        $result =
            TutorHelper_Pro_Email_Reminders::
                delete(
                    $reminder_id
                );

        if ( is_wp_error( $result ) ) {
            self::redirect_reminder(
                'error',
                $result->
                    get_error_code()
            );
        }

        self::redirect_reminder(
            'deleted'
        );
    }


    /**
     * Redirect back to the Email Manager.
     *
     * @param string $status     Result status.
     * @param string $error_code Optional error code.
     *
     * @return void
     */
    private static function redirect_reminder(
        $status,
        $error_code = ''
    ) {

        $args =
            array(
                'page' =>
                    TutorHelper_Booking_Hub::
                        PAGE_SLUG,

                'tab' =>
                    TutorHelper_Booking_Email_Admin::
                        TAB_KEY,

                'tutorhelper_pro_reminder_status' =>
                    sanitize_key(
                        $status
                    ),
            );

        if ( $error_code ) {
            $args[
                'tutorhelper_pro_reminder_error'
            ] =
                sanitize_key(
                    $error_code
                );
        }

        wp_safe_redirect(
            add_query_arg(
                $args,
                admin_url(
                    'admin.php'
                )
            )
        );

        exit;
    }


}
