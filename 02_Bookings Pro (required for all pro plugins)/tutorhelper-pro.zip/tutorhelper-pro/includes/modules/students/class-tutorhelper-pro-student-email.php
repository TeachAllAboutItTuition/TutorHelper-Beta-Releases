<?php
/**
 * Bespoke student and parent email workflow.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds a branded, auditable email composer to Student Management.
 */
final class TutorHelper_Pro_Student_Email {

	/** Email template used to apply the shared branded wrapper. */
	const TEMPLATE_KEY = 'pro_student_bespoke_email';

	/** AJAX actions. */
	const PREVIEW_ACTION = 'tutorhelper_pro_preview_student_email';
	const SEND_ACTION    = 'tutorhelper_pro_send_student_email';
	const HOMEWORK_PREVIEW_ACTION = 'tutorhelper_pro_preview_homework_reminder';
	const HOMEWORK_SEND_ACTION    = 'tutorhelper_pro_send_homework_reminder';

	/** Shared AJAX nonce action. */
	const NONCE_ACTION = 'tutorhelper_pro_student_email';

	/** Editor identifier. */
	const EDITOR_ID = 'tutorhelper-bespoke-email-message';

	/** @var array<int,array<int,string>> Reminder dates indexed by due booking ID. */
	private static $homework_reminder_dates = array();

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		self::register_template();

		add_action(
			'tutorhelper_pro_student_communication_tools',
			array( __CLASS__, 'render_composer' )
		);

		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' )
		);

		add_action(
			'wp_ajax_' . self::PREVIEW_ACTION,
			array( __CLASS__, 'handle_preview' )
		);

		add_action(
			'wp_ajax_' . self::SEND_ACTION,
			array( __CLASS__, 'handle_send' )
		);
		add_action( 'wp_ajax_' . self::HOMEWORK_PREVIEW_ACTION, array( __CLASS__, 'handle_homework_preview' ) );
		add_action( 'wp_ajax_' . self::HOMEWORK_SEND_ACTION, array( __CLASS__, 'handle_homework_send' ) );
	}

	/**
	 * Register a hidden transport template.
	 *
	 * The template belongs to a separate module so it is not presented as an
	 * automatic email in Email Manager. Tutors compose each message in context.
	 *
	 * @return void
	 */
	private static function register_template() {
		TutorHelper_Email_Templates::register(
			self::TEMPLATE_KEY,
			array(
				'module'      => 'student_communication',
				'label'       => __( 'Bespoke student email', 'tutorhelper-pro' ),
				'description' => __( 'A manually composed email sent from Student Management.', 'tutorhelper-pro' ),
				'heading'     => __( 'Message from your tutor', 'tutorhelper-pro' ),
				'recipient'   => 'student',
				'enabled'     => true,
				'subject'     => '{bespoke_subject}',
				'body'        => '{bespoke_message}',
				'placeholders' => array(
					'{bespoke_subject}',
					'{bespoke_message}',
				),
			)
		);
	}

	/**
	 * Enqueue the composer only on the Students tab.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {
		if (
			! current_user_can( TutorHelper_Admin::CAPABILITY )
			|| ( ! self::is_students_page() && ! self::is_dashboard_page() )
		) {
			return;
		}

		$style_path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-student-email.css';
		$script_path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-student-email.js';

		wp_enqueue_style(
			'tutorhelper-pro-student-email',
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-student-email.css',
			array( 'tutorhelper-pro-admin' ),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_PRO_VERSION
		);

		wp_enqueue_editor();

		wp_enqueue_script(
			'tutorhelper-pro-student-email',
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-student-email.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_PRO_VERSION,
			true
		);

		wp_localize_script(
			'tutorhelper-pro-student-email',
			'tutorhelperProStudentEmail',
			array(
				'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
				'nonce'           => wp_create_nonce( self::NONCE_ACTION ),
				'previewAction'   => self::PREVIEW_ACTION,
				'sendAction'      => self::SEND_ACTION,
				'editorId'        => self::EDITOR_ID,
				'defaultSubject'  => __( 'A message from {tutor_name}', 'tutorhelper-pro' ),
				'defaultMessage'  => '<p>'
					. esc_html__( 'Hello {recipient_first_name},', 'tutorhelper-pro' )
					. '</p><p><br></p><p>'
					. esc_html__( 'Best wishes,', 'tutorhelper-pro' )
					. '<br>{tutor_name}</p>',
				'previewingLabel' => __( 'Preparing preview…', 'tutorhelper-pro' ),
				'sendingLabel'    => __( 'Sending…', 'tutorhelper-pro' ),
				'previewError'    => __( 'The email preview could not be prepared.', 'tutorhelper-pro' ),
				'sendError'       => __( 'The email could not be sent.', 'tutorhelper-pro' ),
				'chooseRecipient' => __( 'Choose at least one recipient.', 'tutorhelper-pro' ),
				'completeFields'  => __( 'Add a subject and message before continuing.', 'tutorhelper-pro' ),
			)
		);
		if ( self::is_dashboard_page() ) {
			$reminder_script_path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-homework-reminder.js';
			wp_enqueue_script(
				'tutorhelper-pro-homework-reminder',
				TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-homework-reminder.js',
				array(),
				file_exists( $reminder_script_path ) ? (string) filemtime( $reminder_script_path ) : TUTORHELPER_PRO_VERSION,
				true
			);
			wp_localize_script(
				'tutorhelper-pro-homework-reminder',
				'tutorhelperProHomeworkReminder',
				array(
					'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
					'nonce'         => wp_create_nonce( self::NONCE_ACTION ),
					'previewAction' => self::HOMEWORK_PREVIEW_ACTION,
					'sendAction'    => self::HOMEWORK_SEND_ACTION,
					'editorId'      => 'tutorhelper-homework-reminder-message',
					'defaultSubject'=> __( 'Homework reminder from {tutor_name}', 'tutorhelper-pro' ),
					'defaultMessage'=> '<p>' . esc_html__( 'Hello {recipient_first_name},', 'tutorhelper-pro' ) . '</p><p>' . esc_html__( 'This is a reminder that the following homework is still outstanding:', 'tutorhelper-pro' ) . '</p><p>{homework_due}</p><p>' . esc_html__( 'Best wishes,', 'tutorhelper-pro' ) . '<br>{tutor_name}</p>',
					'previewingLabel'=> __( 'Preparing preview…', 'tutorhelper-pro' ),
					'sendingLabel'  => __( 'Sending…', 'tutorhelper-pro' ),
					'chooseRecipient'=> __( 'Choose at least one recipient.', 'tutorhelper-pro' ),
					'completeFields'=> __( 'Add a subject and message before continuing.', 'tutorhelper-pro' ),
				)
			);
		}
	}

	/**
	 * Render the composer trigger and modal.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render_composer( $student ) {
		if (
			! $student instanceof WP_User
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$recipients = self::get_recipients( $student );
		$has_recipient = ! empty( $recipients['student']['email'] )
			|| ! empty( $recipients['parent']['email'] );
		?>
		<section class="tutorhelper-pro-student-email" data-student-email-composer data-student-id="<?php echo esc_attr( absint( $student->ID ) ); ?>">
			<div>
				<h4><?php echo esc_html__( 'Email student or parent', 'tutorhelper-pro' ); ?></h4>
				<p><?php echo esc_html__( 'Compose a branded email and record its delivery in this communication history.', 'tutorhelper-pro' ); ?></p>
			</div>
			<button
				type="button"
				class="button tutorhelper-action-button"
				data-student-email-open
				<?php disabled( ! $has_recipient ); ?>
			>
				<span class="dashicons dashicons-email-alt" aria-hidden="true"></span>
				<?php echo esc_html__( 'Send email', 'tutorhelper-pro' ); ?>
			</button>
			<?php if ( ! $has_recipient ) : ?>
				<p class="description"><?php echo esc_html__( 'Add a valid student or parent email address before sending a message.', 'tutorhelper-pro' ); ?></p>
			<?php endif; ?>

			<div class="tutorhelper-admin-modal tutorhelper-pro-student-email__modal" data-student-email-modal hidden>
				<div class="tutorhelper-admin-modal__backdrop" data-student-email-close></div>
				<div
					class="tutorhelper-admin-modal__dialog tutorhelper-pro-student-email__dialog"
					role="dialog"
					aria-modal="true"
					aria-labelledby="tutorhelper-student-email-title"
				>
					<header class="tutorhelper-admin-modal__header">
						<div>
							<h3 id="tutorhelper-student-email-title"><?php echo esc_html__( 'Send bespoke email', 'tutorhelper-pro' ); ?></h3>
							<p><?php echo esc_html( $student->display_name ); ?></p>
						</div>
						<button type="button" class="tutorhelper-admin-modal__close" data-student-email-close aria-label="<?php echo esc_attr__( 'Close', 'tutorhelper-pro' ); ?>">&times;</button>
					</header>

					<div class="tutorhelper-admin-modal__body tutorhelper-pro-student-email__body">
						<div class="tutorhelper-pro-student-email__compose">
							<fieldset class="tutorhelper-pro-student-email__recipients">
								<legend><?php echo esc_html__( 'Recipients', 'tutorhelper-pro' ); ?></legend>
								<?php self::render_recipient_option( 'student', $recipients['student'], true ); ?>
								<?php self::render_recipient_option( 'parent', $recipients['parent'], false ); ?>
								<label>
									<input type="checkbox" value="1" data-student-email-copy-tutor />
									<span><?php echo esc_html__( 'Send a copy to me', 'tutorhelper-pro' ); ?></span>
								</label>
							</fieldset>

							<label class="tutorhelper-pro-student-email__subject">
								<span><?php echo esc_html__( 'Subject', 'tutorhelper-pro' ); ?></span>
								<input type="text" class="widefat" maxlength="200" data-student-email-subject />
							</label>

							<div class="tutorhelper-pro-student-email__editor">
								<label for="<?php echo esc_attr( self::EDITOR_ID ); ?>"><?php echo esc_html__( 'Message', 'tutorhelper-pro' ); ?></label>
								<?php
								wp_editor(
									'',
									self::EDITOR_ID,
									array(
										'media_buttons' => false,
										'teeny'         => false,
										'textarea_rows' => 12,
										'quicktags'     => true,
										'tinymce'       => array(
											'toolbar1' => 'formatselect,bold,italic,bullist,numlist,blockquote,link,unlink,undo,redo',
											'toolbar2' => '',
										),
									)
								);
								?>
							</div>

							<details class="tutorhelper-pro-student-email__placeholders">
								<summary><?php echo esc_html__( 'Available personalisation', 'tutorhelper-pro' ); ?></summary>
								<p><?php echo esc_html__( 'You can use these in the subject or message:', 'tutorhelper-pro' ); ?></p>
								<code>{recipient_first_name}</code>
								<code>{student_first_name}</code>
								<code>{student_name}</code>
								<code>{parent_name}</code>
								<code>{tutor_name}</code>
								<code>{site_name}</code>
							</details>
						</div>

						<section class="tutorhelper-pro-student-email__preview" aria-labelledby="tutorhelper-student-email-preview-title">
							<div class="tutorhelper-pro-student-email__preview-heading">
								<h4 id="tutorhelper-student-email-preview-title"><?php echo esc_html__( 'Preview', 'tutorhelper-pro' ); ?></h4>
								<button type="button" class="button" data-student-email-preview><?php echo esc_html__( 'Refresh preview', 'tutorhelper-pro' ); ?></button>
							</div>
							<iframe title="<?php echo esc_attr__( 'Branded email preview', 'tutorhelper-pro' ); ?>" sandbox="" data-student-email-preview-frame></iframe>
						</section>
					</div>

					<div class="tutorhelper-pro-student-email__status" role="status" aria-live="polite" data-student-email-status></div>

					<footer class="tutorhelper-admin-modal__footer">
						<button type="button" class="button tutorhelper-admin-button" data-student-email-close><?php echo esc_html__( 'Cancel', 'tutorhelper-pro' ); ?></button>
						<button type="button" class="button tutorhelper-admin-button tutorhelper-admin-button--primary" data-student-email-send><?php echo esc_html__( 'Send email', 'tutorhelper-pro' ); ?></button>
					</footer>
				</div>
			</div>
		</section>
		<?php
	}

	/**
	 * Render one recipient checkbox.
	 *
	 * @param string $type      Recipient type.
	 * @param array  $recipient Recipient data.
	 * @param bool   $checked   Default selection.
	 * @return void
	 */
	private static function render_recipient_option( $type, $recipient, $checked ) {
		$email = isset( $recipient['email'] ) ? sanitize_email( $recipient['email'] ) : '';
		$name  = isset( $recipient['name'] ) ? sanitize_text_field( $recipient['name'] ) : '';
		$label = 'parent' === $type
			? __( 'Parent / guardian', 'tutorhelper-pro' )
			: __( 'Student', 'tutorhelper-pro' );
		?>
		<label class="<?php echo $email ? '' : 'is-unavailable'; ?>">
			<input
				type="checkbox"
				value="<?php echo esc_attr( $type ); ?>"
				data-student-email-recipient
				<?php checked( $checked && $email ); ?>
				<?php disabled( ! $email ); ?>
			/>
			<span>
				<strong><?php echo esc_html( $label ); ?></strong>
				<small>
					<?php
					echo esc_html(
						$email
							? trim( $name . ( $name ? ' — ' : '' ) . $email )
							: __( 'No valid email address', 'tutorhelper-pro' )
					);
					?>
				</small>
			</span>
		</label>
		<?php
	}


	/**
	 * Return the local calendar dates on which overdue-homework reminders were sent.
	 *
	 * One date is shown once even when the same reminder was delivered to both a
	 * student and parent/guardian on that day.
	 *
	 * @param int $booking_id Due booking ID.
	 * @return array<int,string>
	 */
	public static function get_homework_reminder_dates( $booking_id ) {
		$booking_id = absint( $booking_id );
		if ( ! $booking_id ) {
			return array();
		}
		if ( isset( self::$homework_reminder_dates[ $booking_id ] ) ) {
			return self::$homework_reminder_dates[ $booking_id ];
		}

		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'email_deliveries' );
		$sql = 'SELECT COALESCE( sent_at, created_at ) FROM %i WHERE related_object_type = %s AND related_object_id = %d AND delivery_type = %s AND status = %s ORDER BY COALESCE( sent_at, created_at ) DESC LIMIT 100';
		$values = $wpdb->get_col(
			$wpdb->prepare(
				$sql,
				$table,
				'booking',
				$booking_id,
				'homework_overdue_reminder',
				'sent'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Uses the Pro delivery audit log for the tutor-facing reminder cadence.

		$dates = array();
		foreach ( (array) $values as $value ) {
			$timestamp = strtotime( (string) $value . ' UTC' );
			if ( $timestamp ) {
				$dates[] = wp_date( get_option( 'date_format' ), $timestamp, wp_timezone() );
			}
		}
		self::$homework_reminder_dates[ $booking_id ] = array_values( array_unique( $dates ) );
		return self::$homework_reminder_dates[ $booking_id ];
	}

	/**
	 * Render one overdue-homework reminder trigger in the dashboard table.
	 *
	 * @param int $student_id Student ID.
	 * @param int $booking_id Due booking ID.
	 * @return void
	 */
	public static function render_homework_reminder_button( $student_id, $booking_id ) {
		$student = TutorHelper_Students::get_student( absint( $student_id ) );
		if ( ! $student instanceof WP_User ) {
			return;
		}
		$recipients = self::get_recipients( $student );
		$available = ! empty( $recipients['student']['email'] ) || ! empty( $recipients['parent']['email'] );
		?>
		<button type="button" class="button tutorhelper-ui-button tutorhelper-ui-button--primary" data-homework-reminder-open
			data-student-id="<?php echo esc_attr( absint( $student->ID ) ); ?>"
			data-booking-id="<?php echo esc_attr( absint( $booking_id ) ); ?>"
			data-student-name="<?php echo esc_attr( $student->display_name ); ?>"
			data-student-email="<?php echo esc_attr( $recipients['student']['email'] ); ?>"
			data-parent-name="<?php echo esc_attr( $recipients['parent']['name'] ); ?>"
			data-parent-email="<?php echo esc_attr( $recipients['parent']['email'] ); ?>"
			<?php disabled( ! $available ); ?>>
			<span class="dashicons dashicons-email-alt" aria-hidden="true"></span>
			<?php esc_html_e( 'Send reminder', 'tutorhelper-pro' ); ?>
		</button>
		<?php
	}

	/** Render the single reusable dashboard reminder modal. */
	public static function render_homework_reminder_composer() {
		?>
		<div class="tutorhelper-admin-modal tutorhelper-pro-student-email__modal" data-homework-reminder-modal hidden>
			<div class="tutorhelper-admin-modal__backdrop" data-homework-reminder-close></div>
			<div class="tutorhelper-admin-modal__dialog tutorhelper-pro-student-email__dialog" role="dialog" aria-modal="true" aria-labelledby="tutorhelper-homework-reminder-title">
				<header class="tutorhelper-admin-modal__header">
					<div><h3 id="tutorhelper-homework-reminder-title"><?php esc_html_e( 'Send homework reminder', 'tutorhelper-pro' ); ?></h3><p data-homework-reminder-student></p></div>
					<button type="button" class="tutorhelper-admin-modal__close" data-homework-reminder-close aria-label="<?php esc_attr_e( 'Close', 'tutorhelper-pro' ); ?>">&times;</button>
				</header>
				<div class="tutorhelper-admin-modal__body tutorhelper-pro-student-email__body">
					<div class="tutorhelper-pro-student-email__compose">
						<fieldset class="tutorhelper-pro-student-email__recipients"><legend><?php esc_html_e( 'Recipients', 'tutorhelper-pro' ); ?></legend>
							<label><input type="checkbox" value="student" data-homework-reminder-recipient><span><strong><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></strong><small data-homework-reminder-student-email></small></span></label>
							<label><input type="checkbox" value="parent" data-homework-reminder-recipient><span><strong><?php esc_html_e( 'Parent / guardian', 'tutorhelper-pro' ); ?></strong><small data-homework-reminder-parent-email></small></span></label>
							<label><input type="checkbox" value="1" data-homework-reminder-copy><span><?php esc_html_e( 'Send a copy to me', 'tutorhelper-pro' ); ?></span></label>
						</fieldset>
						<label class="tutorhelper-pro-student-email__subject"><span><?php esc_html_e( 'Subject', 'tutorhelper-pro' ); ?></span><input type="text" class="widefat" maxlength="200" data-homework-reminder-subject></label>
						<div class="tutorhelper-pro-student-email__editor"><label for="tutorhelper-homework-reminder-message"><?php esc_html_e( 'Message', 'tutorhelper-pro' ); ?></label><?php wp_editor( '', 'tutorhelper-homework-reminder-message', array( 'media_buttons' => false, 'textarea_rows' => 12, 'quicktags' => true, 'tinymce' => array( 'toolbar1' => 'formatselect,bold,italic,bullist,numlist,link,unlink,undo,redo', 'toolbar2' => '' ) ) ); ?></div>
						<details class="tutorhelper-pro-student-email__placeholders"><summary><?php esc_html_e( 'Available personalisation', 'tutorhelper-pro' ); ?></summary><code>{recipient_first_name}</code> <code>{student_first_name}</code> <code>{tutor_name}</code> <code>{homework_due}</code></details>
					</div>
					<section class="tutorhelper-pro-student-email__preview"><div class="tutorhelper-pro-student-email__preview-heading"><h4><?php esc_html_e( 'Preview', 'tutorhelper-pro' ); ?></h4><button type="button" class="button" data-homework-reminder-preview><?php esc_html_e( 'Refresh preview', 'tutorhelper-pro' ); ?></button></div><iframe title="<?php esc_attr_e( 'Branded email preview', 'tutorhelper-pro' ); ?>" sandbox="" data-homework-reminder-frame></iframe></section>
					<div class="tutorhelper-pro-student-email__status" role="status" aria-live="polite" data-homework-reminder-status></div>
					<footer class="tutorhelper-admin-modal__footer"><button type="button" class="button tutorhelper-admin-button" data-homework-reminder-close><?php esc_html_e( 'Cancel', 'tutorhelper-pro' ); ?></button><button type="button" class="button tutorhelper-admin-button tutorhelper-admin-button--primary" data-homework-reminder-send><?php esc_html_e( 'Send reminder', 'tutorhelper-pro' ); ?></button></footer>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Return student and parent recipient details.
	 *
	 * @param WP_User $student Student account.
	 * @return array
	 */
	private static function get_recipients( $student ) {
		$student_email = sanitize_email( $student->user_email );
		$parent = TutorHelper_Students::get_parent_details( absint( $student->ID ) );
		$parent_email = ! empty( $parent['email'] ) ? sanitize_email( $parent['email'] ) : '';

		if ( $parent_email && $parent_email === $student_email ) {
			$parent_email = '';
		}

		return array(
			'student' => array(
				'name'  => sanitize_text_field( $student->display_name ),
				'email' => is_email( $student_email ) ? $student_email : '',
			),
			'parent' => array(
				'name'  => ! empty( $parent['name'] ) ? sanitize_text_field( $parent['name'] ) : '',
				'email' => is_email( $parent_email ) ? $parent_email : '',
			),
		);
	}

	/** Return whether the current request is the TutorHelper dashboard. */
	private static function is_dashboard_page() {
		$page = isset( $_GET['page'] ) && ! is_array( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		return TutorHelper_Admin::MENU_SLUG === $page;
	}

	/**
	 * Return whether the current request is the Booking Hub Students tab.
	 *
	 * @return bool
	 */
	private static function is_students_page() {
		$page = isset( $_GET['page'] ) && ! is_array( $_GET['page'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing.
			? sanitize_key( wp_unslash( $_GET['page'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';

		return TutorHelper_Booking_Hub::PAGE_SLUG === $page
			&& TutorHelper_Students_Admin::TAB_KEY === $tab;
	}

	/**
	 * Return validated composer data from the AJAX request.
	 *
	 * @return array|WP_Error
	 */
	private static function get_request_data() {
		$student_id = isset( $_POST['student_id'] ) && ! is_array( $_POST['student_id'] )
			? absint( wp_unslash( $_POST['student_id'] ) )
			: 0;
		$subject = isset( $_POST['subject'] ) && ! is_array( $_POST['subject'] )
			? sanitize_text_field( wp_unslash( $_POST['subject'] ) )
			: '';
		$message = isset( $_POST['message'] ) && ! is_array( $_POST['message'] )
			? wp_kses_post( wp_unslash( $_POST['message'] ) )
			: '';
		$student = TutorHelper_Students::get_student( $student_id );

		if ( ! $student instanceof WP_User ) {
			return new WP_Error( 'tutorhelper_pro_student_email_missing', __( 'The student account could not be found.', 'tutorhelper-pro' ) );
		}

		if ( '' === trim( $subject ) || '' === trim( wp_strip_all_tags( $message ) ) ) {
			return new WP_Error( 'tutorhelper_pro_student_email_empty', __( 'Add a subject and message before continuing.', 'tutorhelper-pro' ) );
		}

		return array(
			'student' => $student,
			'subject' => function_exists( 'mb_substr' ) ? mb_substr( $subject, 0, 200 ) : substr( $subject, 0, 200 ),
			'message' => $message,
		);
	}

	/**
	 * Prepare and return the branded email preview.
	 *
	 * @return void
	 */
	public static function handle_preview() {
		self::verify_ajax_request();
		$data = self::get_request_data();

		if ( is_wp_error( $data ) ) {
			wp_send_json_error( array( 'message' => $data->get_error_message() ), 400 );
		}

		$recipient_type = isset( $_POST['recipient_type'] ) && ! is_array( $_POST['recipient_type'] )
			? sanitize_key( wp_unslash( $_POST['recipient_type'] ) )
			: 'student';

		if ( ! in_array( $recipient_type, array( 'student', 'parent' ), true ) ) {
			$recipient_type = 'student';
		}

		$rendered = self::render_message( $data, $recipient_type );

		if ( is_wp_error( $rendered ) ) {
			wp_send_json_error( array( 'message' => $rendered->get_error_message() ), 400 );
		}

		wp_send_json_success(
			array(
				'html' => $rendered['html'],
			)
		);
	}

	/**
	 * Send the bespoke email to each selected recipient.
	 *
	 * @return void
	 */
	public static function handle_send() {
		self::verify_ajax_request();
		$data = self::get_request_data();

		if ( is_wp_error( $data ) ) {
			wp_send_json_error( array( 'message' => $data->get_error_message() ), 400 );
		}

		$requested = isset( $_POST['recipients'] ) && is_array( $_POST['recipients'] )
			? array_map( 'sanitize_key', wp_unslash( $_POST['recipients'] ) )
			: array();
		$requested = array_values( array_intersect( array_unique( $requested ), array( 'student', 'parent' ) ) );

		if ( empty( $requested ) ) {
			wp_send_json_error( array( 'message' => __( 'Choose at least one recipient.', 'tutorhelper-pro' ) ), 400 );
		}

		$student = $data['student'];
		$recipients = self::get_recipients( $student );
		$sender = self::get_sender();
		$sent = array();
		$failed = array();

		$copy_tutor = isset( $_POST['copy_tutor'] )
			&& '1' === sanitize_text_field( wp_unslash( $_POST['copy_tutor'] ) );

		foreach ( $requested as $recipient_type ) {
			$email = $recipients[ $recipient_type ]['email'];

			if ( ! $email ) {
				$failed[ $recipient_type ] = __( 'No valid email address is available.', 'tutorhelper-pro' );
				continue;
			}

			$rendered = self::render_message( $data, $recipient_type );

			if ( is_wp_error( $rendered ) ) {
				$failed[ $recipient_type ] = $rendered->get_error_message();
				continue;
			}

			$result = TutorHelper_Email_Sender::send(
				self::TEMPLATE_KEY,
				$email,
				$rendered['transport_placeholders'],
				array(
					'reply_to_email' => $sender['email'],
					'reply_to_name'  => $sender['name'],
					'context'        => array(
						'student_user_id'    => absint( $student->ID ),
						'related_object_type' => 'student',
						'related_object_id'   => absint( $student->ID ),
						'recipient_type'      => $recipient_type,
						'email_type'          => 'bespoke',
						'action'              => 'student_bespoke_email',
						'sent_by_user_id'     => get_current_user_id(),
					),
				)
			);

			if ( is_wp_error( $result ) ) {
				$failed[ $recipient_type ] = $result->get_error_message();
			} else {
				$sent[] = $recipient_type;
			}
		}

		if ( $copy_tutor && is_email( $sender['email'] ) ) {
			$copy_rendered = self::render_message( $data, $requested[0] );
			if ( is_wp_error( $copy_rendered ) ) {
				$failed['tutor'] = $copy_rendered->get_error_message();
			} else {
				$copy_result = TutorHelper_Email_Sender::send(
					self::TEMPLATE_KEY,
					$sender['email'],
					$copy_rendered['transport_placeholders'],
					array(
						'reply_to_email' => $sender['email'],
						'reply_to_name'  => $sender['name'],
						'context'        => array(
							'student_user_id'    => absint( $student->ID ),
							'related_object_type' => 'student',
							'related_object_id'   => absint( $student->ID ),
							'recipient_type'      => 'tutor',
							'email_type'          => 'bespoke_copy',
							'action'              => 'student_bespoke_email',
							'sent_by_user_id'     => get_current_user_id(),
						),
					)
				);
				if ( is_wp_error( $copy_result ) ) {
					$failed['tutor'] = $copy_result->get_error_message();
				} else {
					$sent[] = 'tutor';
				}
			}
		}

		if ( ! empty( $failed ) ) {
			$reference = 'TH-SE-' . strtoupper( wp_generate_password( 8, false, false ) );

			if ( class_exists( 'TutorHelper_Logger' ) ) {
				TutorHelper_Logger::error(
					'Bespoke student email was not delivered to every selected recipient.',
					array(
						'student_user_id' => absint( $student->ID ),
						'sent_by_user_id' => get_current_user_id(),
						'sent_recipients' => $sent,
						'failed_recipients' => array_keys( $failed ),
						'errors'          => $failed,
						'reference'       => $reference,
					)
				);
			}

			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s: diagnostic reference. */
						__( 'The email was not delivered to every selected recipient. Reference: %s', 'tutorhelper-pro' ),
						$reference
					),
					'sentRecipientTypes'   => $sent,
					'failedRecipientTypes' => array_keys( $failed ),
				),
				500
			);
		}

		wp_send_json_success(
			array(
				'message' => _n(
					'Email sent and added to the communication history.',
					'Emails sent and added to the communication history.',
					count( $sent ),
					'tutorhelper-pro'
				),
				'sentRecipientTypes' => $sent,
			)
		);
	}

	/** Preview a branded overdue-homework reminder. */
	public static function handle_homework_preview() {
		self::verify_ajax_request();
		$data = self::get_homework_reminder_request();
		if ( is_wp_error( $data ) ) { wp_send_json_error( array( 'message' => $data->get_error_message() ), 400 ); }
		$type = self::posted_recipient_type();
		$rendered = self::render_message( $data, $type, self::homework_values( $data ) );
		if ( is_wp_error( $rendered ) ) { wp_send_json_error( array( 'message' => $rendered->get_error_message() ), 400 ); }
		wp_send_json_success( array( 'html' => $rendered['html'] ) );
	}

	/** Send a branded overdue-homework reminder and retain normal delivery history. */
	public static function handle_homework_send() {
		self::verify_ajax_request();
		$data = self::get_homework_reminder_request();
		if ( is_wp_error( $data ) ) { wp_send_json_error( array( 'message' => $data->get_error_message() ), 400 ); }
		$requested = isset( $_POST['recipients'] ) && is_array( $_POST['recipients'] ) ? array_values( array_intersect( array_unique( array_map( 'sanitize_key', wp_unslash( $_POST['recipients'] ) ) ), array( 'student', 'parent' ) ) ) : array();
		if ( empty( $requested ) ) { wp_send_json_error( array( 'message' => __( 'Choose at least one recipient.', 'tutorhelper-pro' ) ), 400 ); }
		$recipients = self::get_recipients( $data['student'] );
		$sender = self::get_sender(); $sent=array(); $failed=array();
		foreach ( $requested as $type ) {
			$email = $recipients[$type]['email'];
			if ( ! $email ) { $failed[$type]=__( 'No valid email address is available.', 'tutorhelper-pro' ); continue; }
			$rendered=self::render_message($data,$type,self::homework_values($data));
			$result=is_wp_error($rendered)?$rendered:TutorHelper_Email_Sender::send(self::TEMPLATE_KEY,$email,$rendered['transport_placeholders'],array('reply_to_email'=>$sender['email'],'reply_to_name'=>$sender['name'],'context'=>array('student_user_id'=>absint($data['student']->ID),'related_object_type'=>'booking','related_object_id'=>absint($data['booking']->id),'recipient_type'=>$type,'email_type'=>'homework_overdue_reminder','action'=>'homework_overdue_reminder','sent_by_user_id'=>get_current_user_id())));
			if(is_wp_error($result)){$failed[$type]=$result->get_error_message();}else{$sent[]=$type;}
		}
		if ( ! empty( $_POST['copy_tutor'] ) && is_email( $sender['email'] ) ) {
			$rendered=self::render_message($data,$requested[0],self::homework_values($data));
			$result=is_wp_error($rendered)?$rendered:TutorHelper_Email_Sender::send(self::TEMPLATE_KEY,$sender['email'],$rendered['transport_placeholders'],array('reply_to_email'=>$sender['email'],'reply_to_name'=>$sender['name'],'context'=>array('student_user_id'=>absint($data['student']->ID),'related_object_type'=>'booking','related_object_id'=>absint($data['booking']->id),'recipient_type'=>'tutor','email_type'=>'homework_overdue_reminder_copy','action'=>'homework_overdue_reminder','sent_by_user_id'=>get_current_user_id())));
			if(is_wp_error($result)){$failed['tutor']=$result->get_error_message();}else{$sent[]='tutor';}
		}
		if($failed){wp_send_json_error(array('message'=>__( 'The reminder was not delivered to every selected recipient.', 'tutorhelper-pro' ),'sentRecipientTypes'=>$sent),500);}
		wp_send_json_success(array('message'=>__( 'Homework reminder sent and added to the communication history.', 'tutorhelper-pro' )));
	}

	/** Validate reminder request and re-check that homework remains overdue. */
	private static function get_homework_reminder_request() {
		$student_id=isset($_POST['student_id'])?absint(wp_unslash($_POST['student_id'])):0;
		$booking_id=isset($_POST['booking_id'])?absint(wp_unslash($_POST['booking_id'])):0;
		$base=self::get_request_data();
		if(is_wp_error($base)){return $base;}
		$booking=TutorHelper_Booking_Records::get_by_id($booking_id);
		if(!$booking||absint($booking->student_user_id)!==absint($base['student']->ID)||'cancelled'===sanitize_key($booking->status)||(string)$booking->booking_end>current_time('mysql',true)){return new WP_Error('tutorhelper_pro_homework_reminder_invalid',__( 'This homework reminder is no longer available.', 'tutorhelper-pro' ));}
		$state=TutorHelper_Pro_Lesson_Follow_Up::get_homework_state_for_booking($booking_id);
		if(empty($state['due'])||!empty($state['completed'])){return new WP_Error('tutorhelper_pro_homework_reminder_complete',__( 'This homework is no longer outstanding.', 'tutorhelper-pro' ));}
		$base['booking']=$booking;
		$placeholders=TutorHelper_Pro_Lesson_Follow_Up::get_reminder_homework_placeholders($booking_id);
		$base['homework']=isset($placeholders['{homework_due}'])?(string)$placeholders['{homework_due}']:'';
		return $base;
	}
	private static function posted_recipient_type(){ $type=isset($_POST['recipient_type'])?sanitize_key(wp_unslash($_POST['recipient_type'])):'student';return in_array($type,array('student','parent'),true)?$type:'student';}
	private static function homework_values($data){return array('{homework_due}'=>nl2br(esc_html($data['homework'])));}

	/**
	 * Render one recipient-specific message.
	 *
	 * @param array  $data           Validated message data.
	 * @param string $recipient_type Student or parent.
	 * @return array|WP_Error
	 */
	private static function render_message( $data, $recipient_type, $extra_values = array() ) {
		$student = $data['student'];
		$recipients = self::get_recipients( $student );
		$sender = self::get_sender();
		$recipient_name = $recipients[ $recipient_type ]['name'];
		$values = array(
			'{recipient_first_name}' => self::get_first_name( $recipient_name ),
			'{student_first_name}'   => self::get_first_name( $student->first_name ? $student->first_name : $student->display_name ),
			'{student_name}'         => sanitize_text_field( $student->display_name ),
			'{parent_name}'          => sanitize_text_field( $recipients['parent']['name'] ),
			'{tutor_name}'           => $sender['name'],
			'{site_name}'            => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
		$values = array_merge( $values, is_array( $extra_values ) ? $extra_values : array() );
		$allowed = array_keys( $values );
		$subject = TutorHelper_Email_Placeholders::replace( $data['subject'], $values, $allowed );
		$message = TutorHelper_Email_Placeholders::replace( $data['message'], $values, $allowed );
		$transport = array(
			'{bespoke_subject}' => $subject,
			'{bespoke_message}' => $message,
		);
		$rendered = TutorHelper_Email_Renderer::render( self::TEMPLATE_KEY, $transport );

		if ( is_wp_error( $rendered ) ) {
			return $rendered;
		}

		$rendered['transport_placeholders'] = $transport;
		return $rendered;
	}

	/**
	 * Return the sending tutor/admin identity for display and Reply-To.
	 *
	 * @return array
	 */
	private static function get_sender() {
		$user = wp_get_current_user();
		$name = $user instanceof WP_User ? sanitize_text_field( $user->display_name ) : '';
		$email = $user instanceof WP_User ? sanitize_email( $user->user_email ) : '';

		if ( ! $name ) {
			$name = sanitize_text_field( TutorHelper_Email_Settings::get( 'sender_name' ) );
		}
		if ( ! is_email( $email ) ) {
			$email = sanitize_email( TutorHelper_Email_Settings::get( 'contact_email' ) );
		}

		return array(
			'name'  => $name ? $name : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'email' => is_email( $email ) ? $email : sanitize_email( get_option( 'admin_email' ) ),
		);
	}

	/**
	 * Return the first word of a display name.
	 *
	 * @param string $name Full name.
	 * @return string
	 */
	private static function get_first_name( $name ) {
		$name = trim( sanitize_text_field( $name ) );
		if ( '' === $name ) {
			return __( 'there', 'tutorhelper-pro' );
		}
		$parts = preg_split( '/\s+/', $name );
		return isset( $parts[0] ) ? $parts[0] : $name;
	}

	/**
	 * Verify capability and nonce for AJAX endpoints.
	 *
	 * @return void
	 */
	private static function verify_ajax_request() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to email students.', 'tutorhelper-pro' ) ), 403 );
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
	}
}
