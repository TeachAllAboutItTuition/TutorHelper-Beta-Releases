<?php
/**
 * Student notes and communication timeline.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds private notes and email history to the student detail screen.
 */
final class TutorHelper_Pro_Student_Notes {

	/**
	 * Admin action used to create a note.
	 *
	 * @var string
	 */
	const ADD_ACTION = 'tutorhelper_pro_add_student_note';

	/**
	 * Timeline anchor.
	 *
	 * @var string
	 */
	const ANCHOR = 'tutorhelper-notes-communication';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'tutorhelper_students_detail_notes_communication',
			array( __CLASS__, 'render' ),
			20
		);

		add_action(
			'admin_post_' . self::ADD_ACTION,
			array( __CLASS__, 'handle_add_note' )
		);
	}

	/**
	 * Render the disclosure beneath Registration & Onboarding.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render( $student ) {
		if (
			! $student instanceof WP_User
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$filters  = self::get_filters();
		$timeline = self::get_timeline( absint( $student->ID ), $filters );
		$status   = isset( $_GET['student_note_status'] ) && ! is_array( $_GET['student_note_status'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only redirect status.
			? sanitize_key( wp_unslash( $_GET['student_note_status'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
		$reference = isset( $_GET['student_note_reference'] ) && ! is_array( $_GET['student_note_reference'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only diagnostic reference.
			? sanitize_text_field( wp_unslash( $_GET['student_note_reference'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
		?>
		<div id="<?php echo esc_attr( self::ANCHOR ); ?>" class="tutorhelper-pro-student-notes">
			<?php self::render_notice( $status, $reference ); ?>
			<?php
			/**
			 * Render communication tools supplied by Pro modules.
			 *
			 * @param WP_User $student Student account.
			 */
			do_action( 'tutorhelper_pro_student_communication_tools', $student );
			?>

			<details class="tutorhelper-pro-student-notes__composer tutorhelper-admin-disclosure">
				<summary>
					<span class="dashicons dashicons-edit" aria-hidden="true"></span>
					<span>
						<strong><?php esc_html_e( 'Add a private note', 'tutorhelper-pro' ); ?></strong>
						<small><?php esc_html_e( 'Record information visible only to tutors and administrators.', 'tutorhelper-pro' ); ?></small>
					</span>
				</summary>
				<div class="tutorhelper-pro-student-notes__composer-content">
					<p><?php esc_html_e( 'Notes are included in the student data export. Do not include passwords or payment-card details.', 'tutorhelper-pro' ); ?></p>
					<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::ADD_ACTION ); ?>" />
						<input type="hidden" name="student_id" value="<?php echo esc_attr( absint( $student->ID ) ); ?>" />
						<?php wp_nonce_field( self::ADD_ACTION . '_' . absint( $student->ID ) ); ?>
						<label for="tutorhelper-student-note"><?php esc_html_e( 'Note', 'tutorhelper-pro' ); ?></label>
						<?php
						wp_editor(
							'',
							'tutorhelper-student-note',
							array(
								'textarea_name' => 'note_content',
								'textarea_rows' => 8,
								'media_buttons' => false,
								'quicktags'     => true,
								'teeny'         => false,
							)
						);
						?>
						<button type="submit" class="button tutorhelper-action-button"><?php esc_html_e( 'Add note', 'tutorhelper-pro' ); ?></button>
					</form>
				</div>
			</details>

			<section class="tutorhelper-pro-student-notes__history" aria-labelledby="tutorhelper-communication-history-heading">
				<h4 id="tutorhelper-communication-history-heading"><?php esc_html_e( 'Communication history', 'tutorhelper-pro' ); ?></h4>
				<?php self::render_filters( $filters ); ?>
				<?php self::render_table( $timeline['rows'] ); ?>
				<?php self::render_pagination( $timeline ); ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Save a new student note.
	 *
	 * @return void
	 */
	public static function handle_add_note() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die(
				esc_html__( 'You do not have permission to add student notes.', 'tutorhelper-pro' ),
				esc_html__( 'Permission denied', 'tutorhelper-pro' ),
				array( 'response' => 403 )
			);
		}

		$student_id = isset( $_POST['student_id'] ) && ! is_array( $_POST['student_id'] )
			? absint( wp_unslash( $_POST['student_id'] ) )
			: 0;

		check_admin_referer( self::ADD_ACTION . '_' . $student_id );

		$student = $student_id ? get_userdata( $student_id ) : false;
		$raw_content = isset( $_POST['note_content'] ) && ! is_array( $_POST['note_content'] )
			? wp_unslash( $_POST['note_content'] )
			: '';
		$content = wp_kses_post( $raw_content );

		if ( ! $student instanceof WP_User || '' === trim( wp_strip_all_tags( $content ) ) ) {
			self::redirect( 'invalid' );
		}

		if ( strlen( $raw_content ) > 50000 ) {
			self::redirect( 'too_long' );
		}

		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name( 'student_notes' );
		$now   = current_time( 'mysql', true );
		$saved = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- This is the canonical note write.
			$table,
			array(
				'student_user_id' => $student_id,
				'author_user_id'  => get_current_user_id(),
				'note_content'    => $content,
				'created_at'      => $now,
				'updated_at'      => $now,
			),
			array( '%d', '%d', '%s', '%s', '%s' )
		);

		if ( false === $saved ) {
			$reference = 'TH-SN-' . strtoupper( wp_generate_password( 8, false, false ) );

			if ( class_exists( 'TutorHelper_Logger' ) ) {
				TutorHelper_Logger::error(
					'Student note database write failed.',
					array(
						'student_user_id' => $student_id,
						'author_user_id'  => get_current_user_id(),
						'table'           => $table,
						'reference'       => $reference,
						'database_error'  => sanitize_text_field( $wpdb->last_error ),
					)
				);
			}

			self::redirect( 'error', $reference );
		}

		self::redirect( 'added' );
	}

	/**
	 * Read and validate timeline filters.
	 *
	 * @return array
	 */
	private static function get_filters() {
		$keyword = isset( $_GET['th_comm_q'] ) && ! is_array( $_GET['th_comm_q'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only communication filter.
			? sanitize_text_field( wp_unslash( $_GET['th_comm_q'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
		$from = isset( $_GET['th_comm_from'] ) && ! is_array( $_GET['th_comm_from'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only communication filter.
			? self::sanitise_date( wp_unslash( $_GET['th_comm_from'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
		$to = isset( $_GET['th_comm_to'] ) && ! is_array( $_GET['th_comm_to'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only communication filter.
			? self::sanitise_date( wp_unslash( $_GET['th_comm_to'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
		$type = isset( $_GET['th_comm_type'] ) && ! is_array( $_GET['th_comm_type'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only communication filter.
			? sanitize_key( wp_unslash( $_GET['th_comm_type'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
		$per_page = isset( $_GET['th_comm_per_page'] ) && ! is_array( $_GET['th_comm_per_page'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only pagination preference.
			? absint( wp_unslash( $_GET['th_comm_per_page'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: 10;
		$page = isset( $_GET['th_comm_page'] ) && ! is_array( $_GET['th_comm_page'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only pagination.
			? max( 1, absint( wp_unslash( $_GET['th_comm_page'] ) ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: 1;

		return array(
			'keyword'  => $keyword,
			'from'     => $from,
			'to'       => $to,
			'type'     => in_array( $type, array( '', 'note', 'email' ), true ) ? $type : '',
			'per_page' => in_array( $per_page, array( 10, 20, 50 ), true ) ? $per_page : 10,
			'page'     => $page,
		);
	}

	/**
	 * Return a valid ISO date or an empty string.
	 *
	 * @param string $date Candidate date.
	 * @return string
	 */
	private static function sanitise_date( $date ) {
		$date = sanitize_text_field( $date );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : '';
	}

	/**
	 * Whether any timeline filter is active.
	 *
	 * @param array $filters Filters.
	 * @return bool
	 */
	private static function filters_are_active( $filters ) {
		return '' !== $filters['keyword']
			|| '' !== $filters['from']
			|| '' !== $filters['to']
			|| '' !== $filters['type']
			|| 10 !== $filters['per_page']
			|| 1 < $filters['page'];
	}

	/**
	 * Render the filter form.
	 *
	 * @param array $filters Current filters.
	 * @return void
	 */
	private static function render_filters( $filters ) {
		?>
		<form method="get" class="tutorhelper-pro-student-notes__filters">
			<?php
			foreach ( $_GET as $key => $value ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Preserves the current read-only admin screen.
				$key = sanitize_key( $key );
				if ( is_array( $value ) || 0 === strpos( $key, 'th_comm_' ) || in_array( $key, array( 'student_note_status', 'student_note_reference' ), true ) ) {
					continue;
				}
				?>
				<input type="hidden" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $value ) ) ); ?>" />
				<?php
			}
			?>
			<label><span><?php esc_html_e( 'Search', 'tutorhelper-pro' ); ?></span><input type="search" name="th_comm_q" value="<?php echo esc_attr( $filters['keyword'] ); ?>" /></label>
			<label><span><?php esc_html_e( 'Type', 'tutorhelper-pro' ); ?></span><select name="th_comm_type"><option value=""><?php esc_html_e( 'Notes and emails', 'tutorhelper-pro' ); ?></option><option value="note" <?php selected( $filters['type'], 'note' ); ?>><?php esc_html_e( 'Private notes', 'tutorhelper-pro' ); ?></option><option value="email" <?php selected( $filters['type'], 'email' ); ?>><?php esc_html_e( 'Emails', 'tutorhelper-pro' ); ?></option></select></label>
			<label><span><?php esc_html_e( 'From', 'tutorhelper-pro' ); ?></span><input type="date" name="th_comm_from" value="<?php echo esc_attr( $filters['from'] ); ?>" /></label>
			<label><span><?php esc_html_e( 'To', 'tutorhelper-pro' ); ?></span><input type="date" name="th_comm_to" value="<?php echo esc_attr( $filters['to'] ); ?>" /></label>
			<label><span><?php esc_html_e( 'Items per page', 'tutorhelper-pro' ); ?></span><select name="th_comm_per_page"><?php foreach ( array( 10, 20, 50 ) as $size ) : ?><option value="<?php echo esc_attr( $size ); ?>" <?php selected( $filters['per_page'], $size ); ?>><?php echo esc_html( $size ); ?></option><?php endforeach; ?></select></label>
			<div class="tutorhelper-pro-student-notes__filter-actions">
				<button type="submit" class="button tutorhelper-action-button"><?php esc_html_e( 'Apply filters', 'tutorhelper-pro' ); ?></button>
				<?php if ( self::filters_are_active( $filters ) ) : ?><a class="button tutorhelper-hub-pill-button" href="<?php echo esc_url( self::get_reset_url() ); ?>"><?php esc_html_e( 'Clear', 'tutorhelper-pro' ); ?></a><?php endif; ?>
			</div>
		</form>
		<?php
	}

	/**
	 * Build a reset URL that retains the selected student.
	 *
	 * @return string
	 */
	private static function get_reset_url() {
		return remove_query_arg(
			array( 'th_comm_q', 'th_comm_type', 'th_comm_from', 'th_comm_to', 'th_comm_per_page', 'th_comm_page', 'student_note_status', 'student_note_reference' )
		) . '#' . self::ANCHOR;
	}

	/**
	 * Build the combined timeline.
	 *
	 * @param int   $student_id Student user ID.
	 * @param array $filters    Timeline filters.
	 * @return array
	 */
	private static function get_timeline( $student_id, $filters ) {
		$timeline = array_merge(
			self::get_note_entries( $student_id, $filters ),
			self::get_email_entries( $student_id, $filters )
		);

		if ( '' !== $filters['type'] ) {
			$timeline = array_values(
				array_filter(
					$timeline,
					static function ( $entry ) use ( $filters ) {
						return $filters['type'] === $entry['type'];
					}
				)
			);
		}

		usort(
			$timeline,
			static function ( $first, $second ) {
				return strcmp( $second['timestamp'], $first['timestamp'] );
			}
		);

		$total       = count( $timeline );
		$total_pages = $total ? (int) ceil( $total / $filters['per_page'] ) : 0;
		$page        = $total_pages ? min( $filters['page'], $total_pages ) : 1;

		return array(
			'rows'        => array_slice( $timeline, ( $page - 1 ) * $filters['per_page'], $filters['per_page'] ),
			'total'       => $total,
			'page'        => $page,
			'total_pages' => $total_pages,
		);
	}

	/**
	 * Retrieve matching note entries.
	 *
	 * @param int   $student_id Student user ID.
	 * @param array $filters    Timeline filters.
	 * @return array
	 */
	private static function get_note_entries( $student_id, $filters ) {
		global $wpdb;

		$table      = TutorHelper_Pro_Database::get_table_name( 'student_notes' );
		$sql        = 'SELECT * FROM %i WHERE student_user_id = %d';
		$query_args = array( $table, absint( $student_id ) );

		self::add_date_conditions( $sql, $query_args, 'created_at', $filters );

		if ( '' !== $filters['keyword'] ) {
			$sql         .= ' AND note_content LIKE %s';
			$query_args[] = '%' . $wpdb->esc_like( $filters['keyword'] ) . '%';
		}

		$sql .= ' ORDER BY created_at DESC LIMIT 250';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $query_args ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Timeline must reflect current private notes.
		$entries = array();

		foreach ( (array) $rows as $row ) {
			$author = get_userdata( absint( $row->author_user_id ) );
			$entries[] = array(
				'type'      => 'note',
				'timestamp' => (string) $row->created_at,
				'title'     => __( 'Private note', 'tutorhelper-pro' ),
				'body'      => (string) $row->note_content,
				'meta'      => $author instanceof WP_User ? $author->display_name : __( 'Unknown user', 'tutorhelper-pro' ),
				'status'    => '',
				'snapshot'  => '',
			);
		}

		return $entries;
	}

	/**
	 * Retrieve email entries linked to the student or their bookings.
	 *
	 * @param int   $student_id Student user ID.
	 * @param array $filters    Timeline filters.
	 * @return array
	 */
	private static function get_email_entries( $student_id, $filters ) {
		global $wpdb;

		$table       = TutorHelper_Pro_Database::get_table_name( 'email_deliveries' );
		$booking_ids = self::get_booking_ids( $student_id );
		$sql         = 'SELECT * FROM %i WHERE ((related_object_type = %s AND related_object_id = %d)';
		$query_args  = array( $table, 'student', absint( $student_id ) );

		if ( ! empty( $booking_ids ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $booking_ids ), '%d' ) );
			$sql         .= " OR (related_object_type = %s AND related_object_id IN ({$placeholders}))";
			$query_args[] = 'booking';
			$query_args   = array_merge( $query_args, $booking_ids );
		}

		$sql .= ') AND (recipient_type IN (%s, %s, %s) OR recipient_type = %s)';
		$query_args = array_merge( $query_args, array( 'student', 'parent', 'guardian', '' ) );
		self::add_date_conditions( $sql, $query_args, 'created_at', $filters );

		if ( '' !== $filters['keyword'] ) {
			$like = '%' . $wpdb->esc_like( $filters['keyword'] ) . '%';
			$sql .= ' AND (subject_snapshot LIKE %s OR html_snapshot LIKE %s OR recipient_email LIKE %s OR template_key LIKE %s)';
			$query_args = array_merge( $query_args, array( $like, $like, $like, $like ) );
		}

		$sql .= ' ORDER BY created_at DESC LIMIT 250';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $query_args ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Timeline must reflect current communication records.
		$entries = array();

		foreach ( (array) $rows as $row ) {
			$recipient = $row->recipient_type
				? ucfirst( sanitize_key( $row->recipient_type ) )
				: __( 'Recipient', 'tutorhelper-pro' );
			$meta = sprintf(
				/* translators: 1: recipient type, 2: email address. */
				__( '%1$s: %2$s', 'tutorhelper-pro' ),
				$recipient,
				(string) $row->recipient_email
			);
			$context = ! empty( $row->context_snapshot )
				? json_decode( $row->context_snapshot, true )
				: array();
			$sender_id = is_array( $context ) && ! empty( $context['sent_by_user_id'] )
				? absint( $context['sent_by_user_id'] )
				: 0;
			$sender = $sender_id ? get_userdata( $sender_id ) : null;

			if ( $sender instanceof WP_User ) {
				$meta .= ' · ' . sprintf(
					/* translators: %s: tutor or administrator name. */
					__( 'Sent by %s', 'tutorhelper-pro' ),
					$sender->display_name
				);
			}

			$entries[] = array(
				'type'      => 'email',
				'timestamp' => (string) $row->created_at,
				'title'     => $row->subject_snapshot ? (string) $row->subject_snapshot : __( 'Email', 'tutorhelper-pro' ),
				'body'      => '',
				'meta'      => $meta,
				'status'    => sanitize_key( $row->status ),
				'snapshot'  => (string) $row->html_snapshot,
			);
		}

		return $entries;
	}

	/**
	 * Add common date constraints to a prepared query.
	 *
	 * @param string $sql        SQL string, passed by reference.
	 * @param array  $query_args Query values, passed by reference.
	 * @param string $column     Trusted date column.
	 * @param array  $filters    Timeline filters.
	 * @return void
	 */
	private static function add_date_conditions( &$sql, &$query_args, $column, $filters ) {
		if ( '' !== $filters['from'] ) {
			$sql         .= " AND {$column} >= %s";
			$query_args[] = self::local_date_boundary_to_gmt( $filters['from'], false );
		}

		if ( '' !== $filters['to'] ) {
			$sql         .= " AND {$column} <= %s";
			$query_args[] = self::local_date_boundary_to_gmt( $filters['to'], true );
		}
	}

	/**
	 * Convert a site-local filter date into the UTC used by delivery records.
	 *
	 * @param string $date       ISO date.
	 * @param bool   $end_of_day Whether to return the final second of the day.
	 * @return string
	 */
	private static function local_date_boundary_to_gmt( $date, $end_of_day ) {
		$time = $end_of_day ? '23:59:59' : '00:00:00';

		try {
			$boundary = new DateTimeImmutable( $date . ' ' . $time, wp_timezone() );
			return $boundary->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		} catch ( Exception $exception ) {
			unset( $exception );
			return $date . ' ' . $time;
		}
	}

	/**
	 * Return booking IDs owned by a student.
	 *
	 * @param int $student_id Student user ID.
	 * @return array
	 */
	private static function get_booking_ids( $student_id ) {
		global $wpdb;

		$table = TutorHelper_Bookings_Database::get_table_name( 'bookings' );
		$ids   = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Required to link booking emails to the student timeline.
			$wpdb->prepare(
				'SELECT id FROM %i WHERE student_user_id = %d',
				$table,
				absint( $student_id )
			)
		);

		return array_values( array_filter( array_map( 'absint', (array) $ids ) ) );
	}

	/**
	 * Render the combined timeline.
	 *
	 * @param array $timeline Timeline entries.
	 * @return void
	 */
	private static function render_table( $timeline ) {
		?>
		<div class="tutorhelper-pro-student-notes__table-wrap">
			<table class="widefat striped tutorhelper-student-table tutorhelper-pro-student-notes__table">
				<caption class="screen-reader-text"><?php esc_html_e( 'Filtered student notes and communication history', 'tutorhelper-pro' ); ?></caption>
				<thead><tr><th scope="col"><?php esc_html_e( 'Date', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Type', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Details', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Recipient / Author', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Status', 'tutorhelper-pro' ); ?></th></tr></thead>
				<tbody>
				<?php if ( empty( $timeline ) ) : ?>
					<tr><td colspan="5"><?php esc_html_e( 'No notes or communication match these filters.', 'tutorhelper-pro' ); ?></td></tr>
				<?php else : foreach ( $timeline as $entry ) : ?>
					<tr>
						<td data-label="<?php esc_attr_e( 'Date', 'tutorhelper-pro' ); ?>"><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), strtotime( $entry['timestamp'] . ' UTC' ), wp_timezone() ) ); ?></td>
						<td data-label="<?php esc_attr_e( 'Type', 'tutorhelper-pro' ); ?>"><span class="tutorhelper-pro-student-notes__badge"><?php echo esc_html( 'email' === $entry['type'] ? __( 'Email', 'tutorhelper-pro' ) : __( 'Private note', 'tutorhelper-pro' ) ); ?></span></td>
						<td data-label="<?php esc_attr_e( 'Details', 'tutorhelper-pro' ); ?>"><strong><?php echo esc_html( $entry['title'] ); ?></strong><?php if ( $entry['body'] ) : ?><div class="tutorhelper-pro-student-notes__body"><?php echo wp_kses_post( wpautop( $entry['body'] ) ); ?></div><?php endif; ?><?php if ( $entry['snapshot'] ) : ?><details class="tutorhelper-pro-student-notes__message"><summary><?php esc_html_e( 'View email', 'tutorhelper-pro' ); ?></summary><div class="tutorhelper-pro-student-notes__message-content"><?php echo wp_kses_post( $entry['snapshot'] ); ?></div></details><?php endif; ?></td>
						<td data-label="<?php esc_attr_e( 'Recipient / Author', 'tutorhelper-pro' ); ?>"><?php echo esc_html( $entry['meta'] ); ?></td>
						<td data-label="<?php esc_attr_e( 'Status', 'tutorhelper-pro' ); ?>"><?php echo esc_html( self::status_label( $entry['status'] ) ); ?></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}


	/**
	 * Return a translated communication delivery status.
	 *
	 * @param string $status Stored delivery status.
	 * @return string
	 */
	private static function status_label( $status ) {
		$labels = array(
			'sent'      => __( 'Sent', 'tutorhelper-pro' ),
			'failed'    => __( 'Failed', 'tutorhelper-pro' ),
			'pending'   => __( 'Pending', 'tutorhelper-pro' ),
			'queued'    => __( 'Queued', 'tutorhelper-pro' ),
			'skipped'   => __( 'Skipped', 'tutorhelper-pro' ),
			'cancelled' => __( 'Cancelled', 'tutorhelper-pro' ),
		);

		$status = sanitize_key( $status );
		return isset( $labels[ $status ] ) ? $labels[ $status ] : '—';
	}

	/**
	 * Render compact communication pagination.
	 *
	 * @param array $timeline Paginated communication data.
	 * @return void
	 */
	private static function render_pagination( $timeline ) {
		if ( 1 >= $timeline['total_pages'] ) {
			return;
		}

		$links = paginate_links(
			array(
				'base'         => add_query_arg( 'th_comm_page', '%#%' ),
				'format'       => '',
				'current'      => $timeline['page'],
				'total'        => $timeline['total_pages'],
				'type'         => 'plain',
				'add_fragment' => '#' . self::ANCHOR,
			)
		);

		if ( $links ) {
			?>
			<nav class="tutorhelper-student-pagination tutorhelper-pro-student-notes__pagination" aria-label="<?php esc_attr_e( 'Communication history pages', 'tutorhelper-pro' ); ?>">
				<span class="tutorhelper-student-pagination__count">
					<?php
					printf(
						/* translators: %s: Total number of matching communication records. */
						esc_html( _n( '%s item', '%s items', $timeline['total'], 'tutorhelper-pro' ) ),
						esc_html( number_format_i18n( $timeline['total'] ) )
					);
					?>
				</span>
				<div class="tutorhelper-student-pagination__links"><?php echo wp_kses_post( $links ); ?></div>
			</nav>
			<?php
		}
	}

	/**
	 * Render note-save feedback.
	 *
	 * @param string $status    Status key.
	 * @param string $reference Diagnostic reference.
	 * @return void
	 */
	private static function render_notice( $status, $reference ) {
		if ( 'added' === $status ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Student note added.', 'tutorhelper-pro' ) . '</p></div>';
		} elseif ( 'invalid' === $status ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'Enter a note before saving.', 'tutorhelper-pro' ) . '</p></div>';
		} elseif ( 'too_long' === $status ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'The note is too long. Please shorten it before saving.', 'tutorhelper-pro' ) . '</p></div>';
		} elseif ( 'error' === $status ) {
			$message = __( 'The student note could not be saved.', 'tutorhelper-pro' );
			if ( $reference ) {
				$message .= ' ' . sprintf(
					/* translators: %s: diagnostic reference. */
					__( 'Reference: %s', 'tutorhelper-pro' ),
					$reference
				);
			}
			echo '<div class="notice notice-error inline"><p>' . esc_html( $message ) . '</p></div>';
		}
	}

	/**
	 * Redirect back to the student screen.
	 *
	 * @param string $status    Status key.
	 * @param string $reference Optional diagnostic reference.
	 * @return void
	 */
	private static function redirect( $status, $reference = '' ) {
		$url = wp_get_referer();
		$url = $url ? wp_validate_redirect( $url, admin_url() ) : admin_url();
		$url = remove_query_arg( array( 'student_note_status', 'student_note_reference' ), $url );
		$url = add_query_arg( 'student_note_status', sanitize_key( $status ), $url );

		if ( $reference ) {
			$url = add_query_arg( 'student_note_reference', sanitize_text_field( $reference ), $url );
		}

		wp_safe_redirect( $url . '#' . self::ANCHOR );
		exit;
	}
}
