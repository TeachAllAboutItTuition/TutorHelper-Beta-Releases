<?php
/**
 * TutorHelper Pro student data export and erasure.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Extends Core student data management with Pro records.
 */
final class TutorHelper_Pro_Student_Data {

	/**
	 * Initialise Pro student data hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_student_data_export',
			array(
				__CLASS__,
				'add_export_data',
			),
			10,
			2
		);

		add_action(
			'tutorhelper_before_student_data_delete',
			array(
				__CLASS__,
				'handle_delete',
			),
			10,
			3
		);
	}


    /**
     * Return Pro-owned student user-meta keys.
     *
     * @return array
     */
    private static function get_student_meta_keys() {

        return array(
            TutorHelper_Pro_Student_Pricing::
                META_KEY,

            'tutorhelper_registration_source',
            'tutorhelper_registration_status',
            'tutorhelper_registration_type',
            'tutorhelper_registration_submitted_at',

            'tutorhelper_registration_reviewed_at',
            'tutorhelper_registration_reviewed_by',
            'tutorhelper_registration_decision',
            'tutorhelper_registration_decided_at',
            'tutorhelper_registration_decided_by',
            'tutorhelper_registration_waitlisted_at',
            'tutorhelper_registration_waitlisted_by',
            'tutorhelper_registration_promoted_at',
            'tutorhelper_registration_promoted_by',

            'tutorhelper_privacy_acknowledged_at',
            'tutorhelper_terms_agreed_at',

            'tutorhelper_marketing_opt_in',
            'tutorhelper_marketing_source',
            'tutorhelper_marketing_opt_in_at',
        );
    }


    /**
     * Remove TutorHelper Pro user metadata for a student.
     *
     * @param int $student_id Student user ID.
     *
     * @return void
     */
    private static function delete_student_meta(
        $student_id
    ) {

        $student_id =
            absint(
                $student_id
            );

        if ( ! $student_id ) {
            return;
        }

        foreach (
            self::get_student_meta_keys()
            as $meta_key
        ) {
            delete_user_meta(
                $student_id,
                $meta_key
            );
        }
    }


	/**
	 * Add TutorHelper Pro information to a student export.
	 *
	 * @param array   $data    Existing Core export data.
	 * @param WP_User $student Student account.
	 *
	 * @return array
	 */
	public static function add_export_data(
		$data,
		$student
	) {

		if (
			! is_array( $data )
			|| ! $student instanceof WP_User
		) {
			return $data;
		}

		$student_id =
			absint(
				$student->ID
			);

		$booking_ids =
			self::get_student_booking_ids(
				$student_id
			);

		$data['pro'] =
			array(
				'onboarding_answers' =>
					self::get_rows_by_student(
						'onboarding_answers',
						$student_id
					),

				'group_memberships' =>
                    self::get_group_membership_export(
                        $student_id
                    ),

				'finance_transactions' =>
					self::get_rows_by_student(
						'finance_transactions',
						$student_id
					),

				'payment_history' =>
					self::get_rows_by_student(
						'payment_history',
						$student_id
					),

				'booking_finance' =>
					self::get_rows_by_booking_ids(
						'booking_finance',
						$booking_ids
					),

				'booking_attendance' =>
                    self::get_booking_attendance_export(
                        $booking_ids
                    ),

				'late_reminders' =>
                    self::get_late_reminder_export(
                        $booking_ids
                    ),

				'reminder_deliveries' =>
                    self::get_reminder_delivery_export(
                        $booking_ids
                    ),
                
                'student_email_deliveries' =>
                    self::get_student_email_deliveries(
                        $student_id
                    ),

				'student_notes' =>
					self::get_rows_by_student(
						'student_notes',
						$student_id
					),

                'user_meta' =>
                    self::get_export_user_meta(
                        $student_id
                    ),

                'student_prices' =>
                    self::get_student_price_export(
                        $student_id
                    ),
			);

		return $data;
	}



    /**
     * Return readable manually-sent late reminder records.
     *
     * @param array $booking_ids Booking IDs.
     *
     * @return array
     */
    private static function get_late_reminder_export(
        $booking_ids
    ) {

        $records =
            self::get_rows_by_booking_ids(
                'late_reminder_log',
                $booking_ids
            );

        $export = array();

        foreach (
            $records
            as $record
        ) {

            $booking_id =
                isset(
                    $record[
                        'booking_id'
                    ]
                )
                    ? absint(
                        $record[
                            'booking_id'
                        ]
                    )
                    : 0;

            $export[] =
                array(
                    'booking_id' =>
                        $booking_id,

                    'booking_type' =>
                        self::get_booking_type_title(
                            $booking_id
                        ),

                    'sent_at' =>
                        isset(
                            $record[
                                'sent_at'
                            ]
                        )
                            ? $record[
                                'sent_at'
                            ]
                            : '',

                    'student_email' =>
                        isset(
                            $record[
                                'student_email'
                            ]
                        )
                            ? $record[
                                'student_email'
                            ]
                            : '',

                    'parent_email' =>
                        isset(
                            $record[
                                'parent_email'
                            ]
                        )
                            ? $record[
                                'parent_email'
                            ]
                            : '',
                );
        }

        return $export;
    }


    /**
     * Return readable booking reminder delivery records.
     *
     * @param array $booking_ids Booking IDs.
     *
     * @return array
     */
    private static function get_reminder_delivery_export(
        $booking_ids
    ) {

        $records =
            self::get_rows_by_booking_ids(
                'email_reminder_deliveries',
                $booking_ids
            );

        $export = array();

        foreach (
            $records
            as $record
        ) {

            $booking_id =
                isset(
                    $record[
                        'booking_id'
                    ]
                )
                    ? absint(
                        $record[
                            'booking_id'
                        ]
                    )
                    : 0;

            $export[] =
                array(
                    'booking_id' =>
                        $booking_id,

                    'booking_type' =>
                        self::get_booking_type_title(
                            $booking_id
                        ),

                    'recipient_type' =>
                        isset(
                            $record[
                                'recipient_type'
                            ]
                        )
                            ? $record[
                                'recipient_type'
                            ]
                            : '',

                    'recipient_email' =>
                        isset(
                            $record[
                                'recipient_email'
                            ]
                        )
                            ? $record[
                                'recipient_email'
                            ]
                            : '',

                    'scheduled_for' =>
                        isset(
                            $record[
                                'scheduled_for'
                            ]
                        )
                            ? $record[
                                'scheduled_for'
                            ]
                            : '',

                    'status' =>
                        isset(
                            $record[
                                'status'
                            ]
                        )
                            ? $record[
                                'status'
                            ]
                            : '',

                    'sent_at' =>
                        isset(
                            $record[
                                'sent_at'
                            ]
                        )
                            ? $record[
                                'sent_at'
                            ]
                            : '',
                );
        }

        return $export;
    }


    /**
     * Return readable booking attendance records.
     *
     * @param array $booking_ids Booking IDs.
     *
     * @return array
     */
    private static function get_booking_attendance_export(
        $booking_ids
    ) {

        $records =
            self::get_rows_by_booking_ids(
                'booking_attendance',
                $booking_ids
            );

        $export = array();

        foreach (
            $records
            as $record
        ) {

            $booking_id =
                isset(
                    $record[
                        'booking_id'
                    ]
                )
                    ? absint(
                        $record[
                            'booking_id'
                        ]
                    )
                    : 0;

            $export[] =
                array(
                    'booking_id' =>
                        $booking_id,

                    'booking_type' =>
                        self::get_booking_type_title(
                            $booking_id
                        ),

                    'attendance_status' =>
                        isset(
                            $record[
                                'attendance_status'
                            ]
                        )
                            ? $record[
                                'attendance_status'
                            ]
                            : '',

                    'recorded_at' =>
                        isset(
                            $record[
                                'recorded_at'
                            ]
                        )
                            ? $record[
                                'recorded_at'
                            ]
                            : '',
                );
        }

        return $export;
    }


    /**
     * Return readable group memberships for a student.
     *
     * @param int $student_id Student user ID.
     *
     * @return array
     */
    private static function get_group_membership_export(
        $student_id
    ) {

        $memberships =
            self::get_rows_by_student(
                'student_groups',
                $student_id
            );

        $export = array();

        foreach (
            $memberships
            as $membership
        ) {

            $group_id =
                isset(
                    $membership[
                        'group_id'
                    ]
                )
                    ? absint(
                        $membership[
                            'group_id'
                        ]
                    )
                    : 0;

            $group =
                $group_id
                    ? TutorHelper_Pro_Groups::
                        get_by_id(
                            $group_id
                        )
                    : null;

            $export[] =
                array(
                    'group_name' =>
                        $group
                        && isset(
                            $group->name
                        )
                            ? $group->name
                            : __(
                                'Unknown group',
                                'tutorhelper-pro'
                            ),

                    'added_to_group_at' =>
                        isset(
                            $membership[
                                'created_at'
                            ]
                        )
                            ? $membership[
                                'created_at'
                            ]
                            : '',
                );
        }

        return $export;
    }


    /**
     * Return the Booking Type title for a Core booking.
     *
     * @param int $booking_id Booking ID.
     *
     * @return string
     */
    private static function get_booking_type_title(
        $booking_id
    ) {

        $booking_id =
            absint(
                $booking_id
            );

        if ( ! $booking_id ) {
            return '';
        }

        $booking =
            TutorHelper_Booking_Records::
                get_by_id(
                    $booking_id
                );

        if (
            ! $booking
            || empty(
                $booking->booking_type_id
            )
        ) {
            return '';
        }

        $booking_type =
            TutorHelper_Booking_Types::
                get_by_id(
                    absint(
                        $booking->
                            booking_type_id
                    )
                );

        if (
            ! $booking_type
            || empty(
                $booking_type->title
            )
        ) {
            return '';
        }

        return sanitize_text_field(
            $booking_type->title
        );
    }


    /**
     * Return readable student-specific Booking Type prices.
     *
     * @param int $student_id Student user ID.
     *
     * @return array
     */
    private static function get_student_price_export(
        $student_id
    ) {

        $prices =
            TutorHelper_Pro_Student_Pricing::
                get_prices(
                    $student_id
                );

        if ( empty( $prices ) ) {
            return array();
        }

        $currency =
            TutorHelper_Currency::
                get_currency();

        $export = array();

        foreach (
            $prices
            as $booking_type_id =>
                $price_minor_units
        ) {

            $booking_type =
                TutorHelper_Booking_Types::
                    get_by_id(
                        $booking_type_id
                    );

            $export[] =
                array(
                    'booking_type' =>
                        $booking_type
                        && isset(
                            $booking_type->title
                        )
                            ? $booking_type->title
                            : __(
                                'Unknown booking type',
                                'tutorhelper-pro'
                            ),

                    'price' =>
                        TutorHelper_Currency::
                            format_minor_units(
                                absint(
                                    $price_minor_units
                                ),
                                $currency
                            ),
                );
        }

        return $export;
    }


    /**
     * Return generic email delivery rows linked directly
     * to a student.
     *
     * @param int $student_id Student user ID.
     *
     * @return array
     */
    private static function get_student_email_deliveries(
        $student_id
    ) {

        global $wpdb;

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'email_deliveries'
                );

        if ( '' === $table ) {
            return array();
        }

        $rows =
            $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Privacy export must reflect current data.
                $wpdb->prepare(
                    'SELECT *
                    FROM %i
                    WHERE related_object_type = %s
                    AND related_object_id = %d',
                    $table,
                    'student',
                    absint(
                        $student_id
                    )
                ),
                ARRAY_A
            );

        return is_array(
            $rows
        )
            ? $rows
            : array();
    }

    /**
     * Return Pro-owned student metadata for export.
     *
     * @param int $student_id Student user ID.
     *
     * @return array
     */
    private static function get_export_user_meta(
        $student_id
    ) {

        $data = array();

        foreach (
            self::get_student_meta_keys()
            as $meta_key
        ) {

            if (
                TutorHelper_Pro_Student_Pricing::
                    META_KEY
                === $meta_key
            ) {
                continue;
            }

            $value =
                get_user_meta(
                    $student_id,
                    $meta_key,
                    true
                );

            if (
                ''
                === $value
                || null === $value
            ) {
                continue;
            }

            $data[
                $meta_key
            ] =
                $value;
        }

        return $data;
    }


	/**
	 * Handle a Core student-data deletion request.
	 *
	 * @param int     $student_id Student user ID.
	 * @param WP_User $student    Student account.
	 * @param string  $mode       Deletion mode.
	 *
	 * @return void
	 */
	public static function handle_delete(
		$student_id,
		$student,
		$mode
	) {

		unset( $student );

		$student_id =
			absint(
				$student_id
			);

		if ( ! $student_id ) {
			return;
		}

		$booking_ids =
			self::get_student_booking_ids(
				$student_id
			);

		if (
			TutorHelper_Student_Data::
				DELETE_MODE_FULL
			=== $mode
		) {
			self::fully_delete_pro_data(
				$student_id,
				$booking_ids
			);

			return;
		}

		if (
			TutorHelper_Student_Data::
				DELETE_MODE_ERASE
			=== $mode
		) {
			self::erase_pro_personal_data(
				$student_id,
				$booking_ids
			);
		}
	}


	/**
	 * Return Core booking IDs for a student.
	 *
	 * This is called before Core removes or anonymises
	 * the booking records.
	 *
	 * @param int $student_id Student user ID.
	 *
	 * @return array
	 */
	private static function get_student_booking_ids(
		$student_id
	) {

		global $wpdb;

		$table =
			TutorHelper_Bookings_Database::
				get_table_name(
					'bookings'
				);

		if ( '' === $table ) {
			return array();
		}

		$ids =
			$wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Required immediately for privacy/data-management operations.
				$wpdb->prepare(
					'SELECT id
					FROM %i
					WHERE student_user_id = %d',
					$table,
					absint(
						$student_id
					)
				)
			);

		return array_values(
			array_filter(
				array_map(
					'absint',
					(array) $ids
				)
			)
		);
	}


	/**
	 * Permanently remove all Pro data for a student.
	 *
	 * Used for test, duplicate or incorrectly-created accounts.
	 *
	 * @param int   $student_id Student user ID.
	 * @param array $booking_ids Booking IDs.
	 *
	 * @return void
	 */
	private static function fully_delete_pro_data(
		$student_id,
		$booking_ids
	) {

		self::delete_rows_by_booking_ids(
			'booking_finance',
			$booking_ids
		);

		self::delete_rows_by_booking_ids(
			'booking_attendance',
			$booking_ids
		);

		self::delete_rows_by_booking_ids(
			'late_reminder_log',
			$booking_ids
		);

		self::delete_rows_by_booking_ids(
			'email_reminder_deliveries',
			$booking_ids
		);

		self::delete_rows_by_booking_ids(
			'booking_series_items',
			$booking_ids
		);

		self::delete_rows_by_student(
			'student_groups',
			$student_id
		);

		self::delete_rows_by_student(
			'onboarding_answers',
			$student_id
		);

		self::delete_rows_by_student(
			'student_notes',
			$student_id
		);

		self::delete_rows_by_student(
			'finance_transactions',
			$student_id
		);

		self::delete_rows_by_student(
			'payment_history',
			$student_id
		);

		self::delete_booking_series(
			$student_id
		);

		self::delete_email_delivery_rows(
            $student_id,
            $booking_ids
        );

        self::delete_student_meta(
            $student_id
        );
	}


	/**
	 * Erase personal Pro data while retaining anonymised
	 * financial records where appropriate.
	 *
	 * @param int   $student_id Student user ID.
	 * @param array $booking_ids Booking IDs.
	 *
	 * @return void
	 */
	private static function erase_pro_personal_data(
		$student_id,
		$booking_ids
	) {

		/*
		 * Personal / operational records that do not need
		 * to survive privacy erasure.
		 */
		self::delete_rows_by_student(
			'student_groups',
			$student_id
		);

		self::delete_rows_by_student(
			'onboarding_answers',
			$student_id
		);

		self::delete_rows_by_student(
			'student_notes',
			$student_id
		);

		self::delete_rows_by_booking_ids(
			'booking_attendance',
			$booking_ids
		);

		self::delete_rows_by_booking_ids(
			'late_reminder_log',
			$booking_ids
		);

		self::delete_rows_by_booking_ids(
			'email_reminder_deliveries',
			$booking_ids
		);

		self::delete_rows_by_booking_ids(
			'booking_series_items',
			$booking_ids
		);

		self::delete_booking_series(
			$student_id
		);

		self::delete_email_delivery_rows(
            $student_id,
            $booking_ids
        );

		/*
		 * Retained financial records remain, but their
		 * direct student account reference is removed.
		 */
		self::anonymise_student_reference(
			'finance_transactions',
			$student_id
		);

		self::anonymise_student_reference(
			'payment_history',
			$student_id
		);

        self::delete_student_meta(
            $student_id
        );

		/*
		 * booking_finance remains untouched because it
		 * contains only booking_id, due date and timestamps.
		 * Core will anonymise the associated booking.
		 */
	}


	/**
	 * Delete rows from a Pro table by student_user_id.
	 *
	 * @param string $table_key  Pro table key.
	 * @param int    $student_id Student user ID.
	 *
	 * @return void
	 */
	private static function delete_rows_by_student(
		$table_key,
		$student_id
	) {

		global $wpdb;

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					$table_key
				);

		if ( '' === $table ) {
			return;
		}

		$wpdb->delete(
			$table,
			array(
				'student_user_id' =>
					absint(
						$student_id
					),
			),
			array(
				'%d',
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit privacy/data-management operation.
	}


	/**
	 * Delete rows from a Pro table by booking IDs.
	 *
	 * @param string $table_key  Pro table key.
	 * @param array  $booking_ids Booking IDs.
	 *
	 * @return void
	 */
	private static function delete_rows_by_booking_ids(
		$table_key,
		$booking_ids
	) {

		global $wpdb;

		if ( empty( $booking_ids ) ) {
			return;
		}

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					$table_key
				);

		if ( '' === $table ) {
			return;
		}

		$booking_ids =
			array_values(
				array_filter(
					array_map(
						'absint',
						$booking_ids
					)
				)
			);

		if ( empty( $booking_ids ) ) {
			return;
		}

		$placeholders =
			implode(
				',',
				array_fill(
					0,
					count(
						$booking_ids
					),
					'%d'
				)
			);

		$sql =
			$wpdb->prepare(
				"DELETE FROM %i
				WHERE booking_id IN ({$placeholders})",
				array_merge(
					array(
						$table,
					),
					$booking_ids
				)
			);

		$wpdb->query(
			$sql
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit privacy/data-management operation.
	}


	/**
	 * Delete booking series belonging to the student.
	 *
	 * Series items are removed separately before this method.
	 *
	 * @param int $student_id Student user ID.
	 *
	 * @return void
	 */
	private static function delete_booking_series(
		$student_id
	) {

		global $wpdb;

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'booking_series'
				);

		if ( '' === $table ) {
			return;
		}

		$wpdb->delete(
			$table,
			array(
				'student_user_id' =>
					absint(
						$student_id
					),
			),
			array(
				'%d',
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit privacy/data-management operation.
	}


	/**
     * Remove generic Pro email-delivery records associated
     * with a student or their bookings.
     *
     * @param int   $student_id  Student user ID.
     * @param array $booking_ids Booking IDs.
     *
     * @return void
     */
    private static function delete_email_delivery_rows(
        $student_id,
        $booking_ids
    ) {

        global $wpdb;

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'email_deliveries'
                );

        if ( '' === $table ) {
            return;
        }

        $student_id =
            absint(
                $student_id
            );

        /*
        * Registration and other student-level email history.
        */
        if ( $student_id ) {

            $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit privacy/data-management operation.
                $wpdb->prepare(
                    'DELETE FROM %i
                    WHERE related_object_type = %s
                    AND related_object_id = %d',
                    $table,
                    'student',
                    $student_id
                )
            );
        }

        /*
        * Booking-level email history.
        */
        if ( empty( $booking_ids ) ) {
            return;
        }

        $booking_ids =
            array_values(
                array_filter(
                    array_map(
                        'absint',
                        $booking_ids
                    )
                )
            );

        if ( empty( $booking_ids ) ) {
            return;
        }

        $placeholders =
            implode(
                ',',
                array_fill(
                    0,
                    count(
                        $booking_ids
                    ),
                    '%d'
                )
            );

        $sql =
            $wpdb->prepare(
                "DELETE FROM %i
                WHERE related_object_type = %s
                AND related_object_id IN ({$placeholders})",
                array_merge(
                    array(
                        $table,
                        'booking',
                    ),
                    $booking_ids
                )
            );

        $wpdb->query(
            $sql
        ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit privacy/data-management operation.
    }


	/**
	 * Remove the direct student account reference from
	 * retained Pro financial records.
	 *
	 * @param string $table_key  Pro table key.
	 * @param int    $student_id Student user ID.
	 *
	 * @return void
	 */
	private static function anonymise_student_reference(
		$table_key,
		$student_id
	) {

		global $wpdb;

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					$table_key
				);

		if ( '' === $table ) {
			return;
		}

		$wpdb->update(
			$table,
			array(
				'student_user_id' =>
					0,
			),
			array(
				'student_user_id' =>
					absint(
						$student_id
					),
			),
			array(
				'%d',
			),
			array(
				'%d',
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit privacy-erasure operation.
	}


	/**
	 * Return rows from a Pro table belonging directly
	 * to a student.
	 *
	 * @param string $table_key  Pro table key.
	 * @param int    $student_id Student user ID.
	 *
	 * @return array
	 */
	private static function get_rows_by_student(
		$table_key,
		$student_id
	) {

		global $wpdb;

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					$table_key
				);

		if ( '' === $table ) {
			return array();
		}

		$rows =
			$wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Privacy export must reflect current stored data.
				$wpdb->prepare(
					'SELECT *
					FROM %i
					WHERE student_user_id = %d',
					$table,
					absint(
						$student_id
					)
				),
				ARRAY_A
			);

		return is_array(
			$rows
		)
			? $rows
			: array();
	}


	/**
	 * Return rows from a Pro table linked to bookings.
	 *
	 * @param string $table_key  Pro table key.
	 * @param array  $booking_ids Booking IDs.
	 *
	 * @return array
	 */
	private static function get_rows_by_booking_ids(
		$table_key,
		$booking_ids
	) {

		global $wpdb;

		if ( empty( $booking_ids ) ) {
			return array();
		}

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					$table_key
				);

		if ( '' === $table ) {
			return array();
		}

		$booking_ids =
			array_values(
				array_filter(
					array_map(
						'absint',
						$booking_ids
					)
				)
			);

		if ( empty( $booking_ids ) ) {
			return array();
		}

		$placeholders =
			implode(
				',',
				array_fill(
					0,
					count(
						$booking_ids
					),
					'%d'
				)
			);

		$sql =
			$wpdb->prepare(
				"SELECT *
				FROM %i
				WHERE booking_id IN ({$placeholders})",
				array_merge(
					array(
						$table,
					),
					$booking_ids
				)
			);

		$rows =
			$wpdb->get_results(
				$sql,
				ARRAY_A
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Privacy export must reflect current stored data.

		return is_array(
			$rows
		)
			? $rows
			: array();
	}
}
