<?php
/**
 * Student educational history workspace.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Combines bookings, attendance, feedback and homework for one student. */
final class TutorHelper_Pro_Student_History {

	/** Disclosure anchor. */
	const ANCHOR = 'tutorhelper-student-history';

	/** Maximum booking records inspected by one request. */
	const QUERY_LIMIT = 1000;

	/** Register admin hooks. */
	public static function init() {
		add_action( 'tutorhelper_students_detail_lesson_history', array( __CLASS__, 'render' ), 30 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/** Load presentation only on the TutorHelper Students screen. */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix ) {
			return;
		}
		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
		if ( TutorHelper_Students_Admin::TAB_KEY !== $tab ) {
			return;
		}
		$path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-student-history.css';
		wp_enqueue_style( 'tutorhelper-pro-student-history', TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-student-history.css', array(), file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_PRO_VERSION );
	}

	/** Render the educational-history disclosure. */
	public static function render( $student ) {
		if ( ! $student instanceof WP_User || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		$filters = self::get_filters();
		$history = self::get_history( absint( $student->ID ), $filters );
		?>
		<div id="<?php echo esc_attr( self::ANCHOR ); ?>" class="tutorhelper-pro-student-history">
			<?php self::render_filters( $filters ); ?>
			<?php self::render_table( $history['rows'] ); ?>
			<?php self::render_pagination( $history, $filters ); ?>
		</div>
		<?php
	}

	/** Read and allowlist read-only history filters. */
	private static function get_filters() {
		$filters = array(
			'from'       => self::request_date( 'th_history_from' ),
			'to'         => self::request_date( 'th_history_to' ),
			'period'     => self::request_key( 'th_history_period' ),
			'type_id'    => self::request_int( 'th_history_type' ),
			'attendance' => self::request_key( 'th_history_attendance' ),
			'homework'   => self::request_key( 'th_history_homework' ),
			'lesson_kind'=> self::request_key( 'th_history_kind' ),
			'keyword'    => self::request_text( 'th_history_q' ),
			'sort'       => self::request_key( 'th_history_sort' ),
			'page'       => max( 1, self::request_int( 'th_history_page' ) ),
			'per_page'   => self::request_int( 'th_history_per_page' ),
		);
		if ( ! in_array( $filters['period'], array( '', 'upcoming', 'past' ), true ) ) {
			$filters['period'] = '';
		}
		if ( ! in_array( $filters['attendance'], array( '', 'attended', 'late', 'missed', 'cancelled', 'info_only', 'not_recorded' ), true ) ) {
			$filters['attendance'] = '';
		}
		if ( ! in_array( $filters['homework'], array( '', 'none', 'outstanding', 'overdue', 'completed' ), true ) ) {
			$filters['homework'] = '';
		}
		if ( ! in_array( $filters['lesson_kind'], array( '', 'individual', 'group' ), true ) ) {
			$filters['lesson_kind'] = '';
		}
		if ( ! in_array( $filters['sort'], array( 'date_desc', 'date_asc', 'type_asc', 'attendance_asc', 'homework_asc' ), true ) ) {
			$filters['sort'] = 'date_desc';
		}
		if ( ! in_array( $filters['per_page'], array( 10, 20, 50 ), true ) ) {
			$filters['per_page'] = 10;
		}
		return $filters;
	}

	/** Return a sanitized scalar request value. */
	private static function request_text( $key ) {
		return isset( $_GET[ $key ] ) && ! is_array( $_GET[ $key ] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only history filter.
			? sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';
	}

	/** Return a sanitized key request value. */
	private static function request_key( $key ) {
		return sanitize_key( self::request_text( $key ) );
	}

	/** Return a positive integer request value. */
	private static function request_int( $key ) {
		return absint( self::request_text( $key ) );
	}

	/** Return a valid ISO date request value. */
	private static function request_date( $key ) {
		$value = self::request_text( $key );
		$date  = DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
		return $date && $date->format( 'Y-m-d' ) === $value ? $value : '';
	}

	/** Whether filters beyond the default sort/page are active. */
	private static function filters_are_active( $filters ) {
		return (bool) ( $filters['from'] || $filters['to'] || $filters['period'] || $filters['type_id'] || $filters['attendance'] || $filters['homework'] || $filters['lesson_kind'] || $filters['keyword'] || 10 !== $filters['per_page'] || 1 < $filters['page'] );
	}

	/** Build and filter the student history in bounded batches. */
	private static function get_history( $student_id, $filters ) {
		$query = array(
			'student_user_id' => $student_id,
			'date_from'       => $filters['from'] ? self::local_boundary( $filters['from'], false ) : '',
			'date_to'         => $filters['to'] ? self::local_boundary( $filters['to'], true ) : '',
			'limit'           => self::QUERY_LIMIT,
		);
		if ( $filters['type_id'] ) {
			$query['booking_type_id'] = $filters['type_id'];
		}
		$bookings = TutorHelper_Booking_Records::get_all( $query );
		$booking_ids = array_map( 'absint', wp_list_pluck( $bookings, 'id' ) );
		$attendance = TutorHelper_Pro_Student_Reporting::get_attendance( $student_id, $booking_ids );
		$follow_ups = TutorHelper_Pro_Student_Reporting::get_follow_ups( $student_id, $booking_ids );
		$type_map   = self::get_type_map();
		$group_ids  = self::get_group_booking_ids( $booking_ids );
		$rows = array();

		foreach ( $bookings as $booking ) {
			$id = absint( $booking->id );
			$attendance_row = isset( $attendance['records'][ $id ] ) ? $attendance['records'][ $id ] : array( 'status' => 'not_recorded', 'label' => __( 'Not recorded', 'tutorhelper-pro' ), 'icon' => '📅' );
			$follow_up = isset( $follow_ups[ $id ] ) ? $follow_ups[ $id ] : array();
			$is_group = in_array( $id, $group_ids, true );
			$homework_status  = self::get_homework_status( $follow_up );
			$booking_timestamp = strtotime( $booking->booking_start . ' UTC' );
			$period            = $booking_timestamp >= current_time( 'timestamp', true )
				? 'upcoming'
				: 'past';
			$searchable = strtolower( implode( ' ', array( isset( $type_map[ absint( $booking->booking_type_id ) ] ) ? $type_map[ absint( $booking->booking_type_id ) ] : '', $is_group ? 'group' : 'individual', $attendance_row['label'], isset( $follow_up['feedback'] ) ? $follow_up['feedback'] : '', isset( $follow_up['homework_title'] ) ? $follow_up['homework_title'] : '', isset( $follow_up['instructions'] ) ? $follow_up['instructions'] : '' ) ) );
			if ( $filters['period'] && $filters['period'] !== $period ) {
				continue;
			}
			if ( $filters['attendance'] && $filters['attendance'] !== $attendance_row['status'] ) {
				continue;
			}
			if ( $filters['homework'] && $filters['homework'] !== $homework_status ) {
				continue;
			}
			if ( $filters['lesson_kind'] && $filters['lesson_kind'] !== ( $is_group ? 'group' : 'individual' ) ) {
				continue;
			}
			if ( $filters['keyword'] && false === strpos( $searchable, strtolower( $filters['keyword'] ) ) ) {
				continue;
			}
			$rows[] = array( 'booking' => $booking, 'type' => isset( $type_map[ absint( $booking->booking_type_id ) ] ) ? $type_map[ absint( $booking->booking_type_id ) ] : __( 'Lesson', 'tutorhelper-pro' ), 'kind' => $is_group ? __( 'Group', 'tutorhelper-pro' ) : __( 'Individual', 'tutorhelper-pro' ), 'attendance' => $attendance_row, 'follow_up' => $follow_up, 'homework_status' => $homework_status, 'period' => $period );
		}

		usort( $rows, static function ( $left, $right ) use ( $filters ) {
			switch ( $filters['sort'] ) {
				case 'type_asc':
					$result = strcasecmp( $left['type'], $right['type'] );
					break;
				case 'attendance_asc':
					$result = strcasecmp( $left['attendance']['label'], $right['attendance']['label'] );
					break;
				case 'homework_asc':
					$result = strcmp( $left['homework_status'], $right['homework_status'] );
					break;
				default:
					$result = strcmp( $left['booking']->booking_start, $right['booking']->booking_start );
					return 'date_desc' === $filters['sort'] ? -$result : $result;
			}
			return 0 !== $result ? $result : strcmp( $right['booking']->booking_start, $left['booking']->booking_start );
		} );
		$total = count( $rows );
		$per_page = $filters['per_page'];
		$total_pages = $total ? (int) ceil( $total / $per_page ) : 0;
		$page = $total_pages ? min( $filters['page'], $total_pages ) : 1;
		return array( 'rows' => array_slice( $rows, ( $page - 1 ) * $per_page, $per_page ), 'total' => $total, 'page' => $page, 'total_pages' => $total_pages );
	}

	/** Convert a site-local date boundary to UTC storage time. */
	private static function local_boundary( $date, $end ) {
		$local = new DateTimeImmutable( $date . ( $end ? ' 23:59:59' : ' 00:00:00' ), wp_timezone() );
		return $local->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	}

	/** Return active Booking Type labels keyed by ID. */
	private static function get_type_map() {
		$map = array();
		foreach ( (array) TutorHelper_Booking_Types::get_all() as $type ) {
			$map[ absint( $type->id ) ] = sanitize_text_field( $type->title );
		}
		return $map;
	}

	/** Return booking IDs created for Group Sessions in one query. */
	private static function get_group_booking_ids( $booking_ids ) {
		global $wpdb;
		if ( empty( $booking_ids ) || ! class_exists( 'TutorHelper_Group_Enrolment_Bookings' ) || ! method_exists( 'TutorHelper_Group_Enrolment_Bookings', 'get_table_name' ) ) {
			return array();
		}
		$placeholders = implode( ',', array_fill( 0, count( $booking_ids ), '%d' ) );
		return array_map( 'absint', $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current Group Session membership is required for this admin history.
			$wpdb->prepare( "SELECT booking_id FROM %i WHERE booking_id IN ({$placeholders})", array_merge( array( TutorHelper_Group_Enrolment_Bookings::get_table_name() ), $booking_ids ) ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Interpolated fragment contains generated %d placeholders only.
		) );
	}

	/** Resolve homework state for filtering and display. */
	private static function get_homework_status( $follow_up ) {
		$has_homework = ! empty( $follow_up['homework_title'] ) || ! empty( $follow_up['instructions'] ) || ! empty( $follow_up['homework_url'] ) || ! empty( $follow_up['attachment_url'] );
		if ( ! $has_homework ) {
			return 'none';
		}
		if ( ! empty( $follow_up['homework_completed'] ) ) {
			return 'completed';
		}
		return ! empty( $follow_up['due_timestamp'] ) && $follow_up['due_timestamp'] < current_time( 'timestamp', true ) ? 'overdue' : 'outstanding';
	}

	/** Render filters with current admin navigation preserved. */
	private static function render_filters( $filters ) {
		$types = self::get_type_map();
		?>
		<form method="get" class="tutorhelper-pro-student-history__filters">
			<?php foreach ( $_GET as $key => $value ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Preserves read-only admin navigation. ?>
				<?php $key = sanitize_key( $key ); ?>
				<?php if ( is_array( $value ) || 0 === strpos( $key, 'th_history_' ) ) { continue; } ?>
				<input type="hidden" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $value ) ) ); ?>" />
			<?php endforeach; ?>
			<label><span><?php esc_html_e( 'From', 'tutorhelper-pro' ); ?></span><input type="date" name="th_history_from" value="<?php echo esc_attr( $filters['from'] ); ?>" /></label>
			<label><span><?php esc_html_e( 'To', 'tutorhelper-pro' ); ?></span><input type="date" name="th_history_to" value="<?php echo esc_attr( $filters['to'] ); ?>" /></label>
			<label><span><?php esc_html_e( 'Lesson period', 'tutorhelper-pro' ); ?></span><select name="th_history_period"><?php self::render_options( array( '' => __( 'Past and upcoming', 'tutorhelper-pro' ), 'upcoming' => __( 'Upcoming lessons', 'tutorhelper-pro' ), 'past' => __( 'Past lessons', 'tutorhelper-pro' ) ), $filters['period'] ); ?></select></label>
			<label><span><?php esc_html_e( 'Lesson type', 'tutorhelper-pro' ); ?></span><select name="th_history_type"><option value="0"><?php esc_html_e( 'All lesson types', 'tutorhelper-pro' ); ?></option><?php foreach ( $types as $id => $title ) : ?><option value="<?php echo esc_attr( $id ); ?>" <?php selected( $filters['type_id'], $id ); ?>><?php echo esc_html( $title ); ?></option><?php endforeach; ?></select></label>
			<label><span><?php esc_html_e( 'Attendance', 'tutorhelper-pro' ); ?></span><select name="th_history_attendance"><?php self::render_options( array( '' => __( 'All attendance', 'tutorhelper-pro' ), 'attended' => __( 'Attended', 'tutorhelper-pro' ), 'late' => __( 'Late', 'tutorhelper-pro' ), 'missed' => __( 'Missed', 'tutorhelper-pro' ), 'cancelled' => __( 'Cancelled', 'tutorhelper-pro' ), 'info_only' => __( 'Information only', 'tutorhelper-pro' ), 'not_recorded' => __( 'Not recorded', 'tutorhelper-pro' ) ), $filters['attendance'] ); ?></select></label>
			<label><span><?php esc_html_e( 'Homework', 'tutorhelper-pro' ); ?></span><select name="th_history_homework"><?php self::render_options( array( '' => __( 'All homework', 'tutorhelper-pro' ), 'none' => __( 'No homework', 'tutorhelper-pro' ), 'outstanding' => __( 'Outstanding', 'tutorhelper-pro' ), 'overdue' => __( 'Overdue', 'tutorhelper-pro' ), 'completed' => __( 'Completed', 'tutorhelper-pro' ) ), $filters['homework'] ); ?></select></label>
			<label><span><?php esc_html_e( 'Lesson format', 'tutorhelper-pro' ); ?></span><select name="th_history_kind"><?php self::render_options( array( '' => __( 'Individual and Group', 'tutorhelper-pro' ), 'individual' => __( 'Individual', 'tutorhelper-pro' ), 'group' => __( 'Group', 'tutorhelper-pro' ) ), $filters['lesson_kind'] ); ?></select></label>
			<label><span><?php esc_html_e( 'Keyword', 'tutorhelper-pro' ); ?></span><input type="search" name="th_history_q" value="<?php echo esc_attr( $filters['keyword'] ); ?>" /></label>
			<label><span><?php esc_html_e( 'Sort', 'tutorhelper-pro' ); ?></span><select name="th_history_sort"><?php self::render_options( array( 'date_desc' => __( 'Newest first', 'tutorhelper-pro' ), 'date_asc' => __( 'Oldest first', 'tutorhelper-pro' ), 'type_asc' => __( 'Lesson type', 'tutorhelper-pro' ), 'attendance_asc' => __( 'Attendance', 'tutorhelper-pro' ), 'homework_asc' => __( 'Homework status', 'tutorhelper-pro' ) ), $filters['sort'] ); ?></select></label>
			<label><span><?php esc_html_e( 'Items per page', 'tutorhelper-pro' ); ?></span><select name="th_history_per_page"><?php self::render_options( array( 10 => '10', 20 => '20', 50 => '50' ), $filters['per_page'] ); ?></select></label>
			<button type="submit" class="button tutorhelper-action-button"><?php esc_html_e( 'Apply filters', 'tutorhelper-pro' ); ?></button>
			<?php if ( self::filters_are_active( $filters ) ) : ?><a class="button tutorhelper-hub-pill-button" href="<?php echo esc_url( self::reset_url() ); ?>"><?php esc_html_e( 'Clear', 'tutorhelper-pro' ); ?></a><?php endif; ?>
		</form>
		<?php
	}

	/** Render allowlisted select options. */
	private static function render_options( $options, $selected ) {
		foreach ( $options as $value => $label ) {
			?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected, $value ); ?>><?php echo esc_html( $label ); ?></option><?php
		}
	}

	/** Render accessible history table. */
	private static function render_table( $rows ) {
		?>
		<div class="tutorhelper-pro-student-history__table-wrap tutorhelper-student-table-wrap">
			<table class="widefat striped tutorhelper-student-table tutorhelper-pro-student-history__table">
				<caption class="screen-reader-text"><?php esc_html_e( 'Filtered student lesson history', 'tutorhelper-pro' ); ?></caption>
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Lesson', 'tutorhelper-pro' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Attendance', 'tutorhelper-pro' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Feedback', 'tutorhelper-pro' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Homework', 'tutorhelper-pro' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Due date', 'tutorhelper-pro' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Actions', 'tutorhelper-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $rows ) ) : ?>
						<tr><td colspan="6"><?php esc_html_e( 'No lessons match the selected filters.', 'tutorhelper-pro' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $rows as $row ) : ?>
							<?php
							$booking = $row['booking'];
							$follow  = $row['follow_up'];
							?>
							<tr>
								<td data-label="<?php esc_attr_e( 'Lesson', 'tutorhelper-pro' ); ?>">
									<strong><?php echo esc_html( $row['type'] ); ?></strong><br />
									<span><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), strtotime( $booking->booking_start . ' UTC' ), wp_timezone() ) ); ?></span><br />
									<small><?php echo esc_html( $row['kind'] ); ?></small>
									<span class="tutorhelper-pro-student-history__period tutorhelper-pro-student-history__period--<?php echo esc_attr( $row['period'] ); ?>"><?php echo esc_html( 'upcoming' === $row['period'] ? __( 'Upcoming', 'tutorhelper-pro' ) : __( 'Past', 'tutorhelper-pro' ) ); ?></span>
								</td>
								<td data-label="<?php esc_attr_e( 'Attendance', 'tutorhelper-pro' ); ?>"><span aria-hidden="true"><?php echo esc_html( $row['attendance']['icon'] ); ?></span> <?php echo esc_html( $row['attendance']['label'] ); ?></td>
								<td data-label="<?php esc_attr_e( 'Feedback', 'tutorhelper-pro' ); ?>"><?php echo ! empty( $follow['feedback'] ) ? wp_kses_post( wpautop( $follow['feedback'] ) ) : esc_html( '—' ); ?></td>
								<td data-label="<?php esc_attr_e( 'Homework', 'tutorhelper-pro' ); ?>">
									<strong><?php echo ! empty( $follow['homework_title'] ) ? esc_html( $follow['homework_title'] ) : esc_html( self::homework_label( $row['homework_status'] ) ); ?></strong>
									<?php if ( ! empty( $follow['instructions'] ) ) : ?><div><?php echo wp_kses_post( wpautop( $follow['instructions'] ) ); ?></div><?php endif; ?>
								</td>
								<td data-label="<?php esc_attr_e( 'Due date', 'tutorhelper-pro' ); ?>">
									<?php echo ! empty( $follow['due_label'] ) ? esc_html( $follow['due_label'] ) : esc_html( '—' ); ?><br />
									<small class="is-<?php echo esc_attr( $row['homework_status'] ); ?>"><?php echo esc_html( self::homework_label( $row['homework_status'] ) ); ?></small>
								</td>
								<td class="tutorhelper-student-table__actions" data-label="<?php esc_attr_e( 'Actions', 'tutorhelper-pro' ); ?>"><a class="button tutorhelper-hub-pill-button" href="<?php echo esc_url( self::edit_url( absint( $booking->id ) ) ); ?>"><?php esc_html_e( 'Open record', 'tutorhelper-pro' ); ?></a></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/** Return a translated homework status. */
	private static function homework_label( $status ) {
		$labels = array( 'none' => __( 'No homework', 'tutorhelper-pro' ), 'outstanding' => __( 'Outstanding', 'tutorhelper-pro' ), 'overdue' => __( 'Overdue', 'tutorhelper-pro' ), 'completed' => __( 'Completed', 'tutorhelper-pro' ) );
		return isset( $labels[ $status ] ) ? $labels[ $status ] : $labels['none'];
	}

	/** Render compact pagination. */
	private static function render_pagination( $history, $filters ) {
		unset( $filters );

		if ( 1 >= $history['total_pages'] ) {
			return;
		}

		$links = paginate_links(
			array(
				'base'         => add_query_arg( 'th_history_page', '%#%' ),
				'format'       => '',
				'current'      => $history['page'],
				'total'        => $history['total_pages'],
				'type'         => 'plain',
				'add_fragment' => '#' . self::ANCHOR,
			)
		);

		if ( $links ) {
			?>
			<nav class="tutorhelper-student-pagination tutorhelper-pro-student-history__pagination" aria-label="<?php esc_attr_e( 'Lesson history pages', 'tutorhelper-pro' ); ?>">
				<span class="tutorhelper-student-pagination__count">
					<?php
					printf(
						/* translators: %s: Total number of matching lesson records. */
						esc_html( _n( '%s lesson', '%s lessons', $history['total'], 'tutorhelper-pro' ) ),
						esc_html( number_format_i18n( $history['total'] ) )
					);
					?>
				</span>
				<div class="tutorhelper-student-pagination__links"><?php echo wp_kses_post( $links ); ?></div>
			</nav>
			<?php
		}
	}

	/** Build edit link for a canonical booking record. */
	private static function edit_url( $booking_id ) {
		return add_query_arg( array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => TutorHelper_Tutor_Booking_Admin::TAB_KEY, 'mode' => TutorHelper_Tutor_Booking_Admin::MODE_EDIT, 'tutor_booking_id' => $booking_id ), admin_url( 'admin.php' ) );
	}

	/** Clear only history filters while retaining the student screen. */
	private static function reset_url() {
		return remove_query_arg( array( 'th_history_from', 'th_history_to', 'th_history_period', 'th_history_type', 'th_history_attendance', 'th_history_homework', 'th_history_kind', 'th_history_q', 'th_history_sort', 'th_history_per_page', 'th_history_page' ) ) . '#' . self::ANCHOR;
	}
}
