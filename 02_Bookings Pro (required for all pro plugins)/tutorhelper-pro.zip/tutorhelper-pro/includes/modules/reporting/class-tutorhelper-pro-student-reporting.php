<?php
/**
 * Read-only, student-scoped reporting services for trusted TutorHelper extensions.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Provides safe attendance and follow-up data without exposing Pro tables. */
final class TutorHelper_Pro_Student_Reporting {

	/**
	 * Return attendance data for bookings belonging to one student.
	 *
	 * @param int   $student_user_id Student account ID.
	 * @param int[] $booking_ids     Requested booking IDs.
	 * @return array{records: array, totals: array}
	 */
	public static function get_attendance( $student_user_id, $booking_ids ) {
		$booking_ids = self::authorised_booking_ids( $student_user_id, $booking_ids );
		$stored      = TutorHelper_Pro_Booking_Attendance::get_for_booking_ids( $booking_ids );
		$records     = array();
		$totals      = array_fill_keys(
			array( 'attended', 'late', 'missed', 'info_only', 'not_recorded' ),
			0
		);

		foreach ( $booking_ids as $booking_id ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
			$status  = self::attendance_status( $booking, isset( $stored[ $booking_id ] ) ? $stored[ $booking_id ] : null );

			$records[ $booking_id ] = array(
				'status' => $status,
				'label'  => self::attendance_label( $status ),
				'icon'   => self::attendance_icon( $status ),
			);

			if ( isset( $totals[ $status ] ) ) {
				++$totals[ $status ];
			}
		}

		return array( 'records' => $records, 'totals' => $totals );
	}

	/**
	 * Return read-only feedback and homework for bookings belonging to one student.
	 *
	 * @param int   $student_user_id Student account ID.
	 * @param int[] $booking_ids     Requested booking IDs.
	 * @return array<int, array>
	 */
	public static function get_follow_ups( $student_user_id, $booking_ids ) {
		global $wpdb;

		$booking_ids = self::authorised_booking_ids( $student_user_id, $booking_ids );

		if ( empty( $booking_ids ) ) {
			return array();
		}

		$table        = TutorHelper_Pro_Database::get_table_name( 'lesson_follow_up' );
		$placeholders = implode( ', ', array_fill( 0, count( $booking_ids ), '%d' ) );
		$sql          = $wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Placeholder list contains only generated %d tokens.
			"SELECT * FROM %i WHERE booking_id IN ({$placeholders})",
			array_merge( array( $table ), $booking_ids )
		);
		$rows         = $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reports must show current tutor feedback.
		$by_booking   = array();

		foreach ( $rows as $row ) {
			$by_booking[ absint( $row->booking_id ) ] = $row;
		}

		$group_rows = self::get_group_fallbacks( $booking_ids, array_keys( $by_booking ) );
		$result     = array();

		foreach ( $booking_ids as $booking_id ) {
			$row = isset( $by_booking[ $booking_id ] )
				? $by_booking[ $booking_id ]
				: ( isset( $group_rows[ $booking_id ] ) ? $group_rows[ $booking_id ] : null );

			if ( ! $row ) {
				continue;
			}

			$prepared = self::prepare_follow_up( $row, $booking_id );

			if ( $prepared['has_content'] ) {
				$result[ $booking_id ] = $prepared;
			}
		}

		return $result;
	}

	/** Only retain bookings whose canonical student ID matches the requested student. */
	private static function authorised_booking_ids( $student_user_id, $booking_ids ) {
		global $wpdb;

		$student_user_id = absint( $student_user_id );
		$booking_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'absint', (array) $booking_ids )
				)
			)
		);

		if ( ! $student_user_id || empty( $booking_ids ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $booking_ids ), '%d' ) );
		return array_map(
			'absint',
			$wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Authorisation must use current booking ownership.
				$wpdb->prepare(
					"SELECT id FROM %i WHERE student_user_id = %d AND id IN ({$placeholders})", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Interpolated fragment contains generated %d placeholders only.
					array_merge(
						array( TutorHelper_Booking_Records::get_table_name(), $student_user_id ),
						$booking_ids
					)
				)
			)
		);
	}

	/** Resolve attendance while preserving Cancelled as a booking state. */
	private static function attendance_status( $booking, $record ) {
		if ( ! $booking || TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
			return 'cancelled';
		}

		$status = $record && ! empty( $record->attendance_status )
			? sanitize_key( $record->attendance_status )
			: TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED;

		return TutorHelper_Pro_Booking_Attendance::STATUS_NOT_APPLICABLE === $status
			? TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED
			: $status;
	}

	/** Return a text label without relying on emoji alone. */
	private static function attendance_label( $status ) {
		$labels = array(
			'attended'     => __( 'Attended', 'tutorhelper-pro' ),
			'late'         => __( 'Late', 'tutorhelper-pro' ),
			'missed'       => __( 'Missed', 'tutorhelper-pro' ),
			'info_only'    => __( 'Information only', 'tutorhelper-pro' ),
			'not_recorded' => __( 'Not recorded', 'tutorhelper-pro' ),
			'cancelled'    => __( 'Cancelled', 'tutorhelper-pro' ),
		);

		return isset( $labels[ $status ] ) ? $labels[ $status ] : $labels['not_recorded'];
	}

	/** Return a decorative icon for attendance. */
	private static function attendance_icon( $status ) {
		$icons = array( 'attended' => '✅', 'late' => '🕓', 'missed' => '❌', 'info_only' => 'ℹ️', 'not_recorded' => '📅', 'cancelled' => '✖️' );
		return isset( $icons[ $status ] ) ? $icons[ $status ] : '📅';
	}

	/** Resolve shared Group Session follow-up when no individual override exists. */
	private static function get_group_fallbacks( $booking_ids, $individual_ids ) {
		global $wpdb;

		if ( ! class_exists( 'TutorHelper_Group_Enrolment_Bookings' ) || ! method_exists( 'TutorHelper_Group_Enrolment_Bookings', 'get_table_name' ) ) {
			return array();
		}

		$remaining = array_values( array_diff( $booking_ids, array_map( 'absint', $individual_ids ) ) );

		if ( empty( $remaining ) ) {
			return array();
		}

		$placeholders = implode( ', ', array_fill( 0, count( $remaining ), '%d' ) );
		$mapping_sql  = $wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT booking_id, session_id FROM %i WHERE booking_id IN ({$placeholders})",
			array_merge( array( TutorHelper_Group_Enrolment_Bookings::get_table_name() ), $remaining )
		);
		$mappings     = $wpdb->get_results( $mapping_sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( empty( $mappings ) ) {
			return array();
		}

		$session_ids = array_values( array_unique( array_map( 'absint', wp_list_pluck( $mappings, 'session_id' ) ) ) );
		$session_sql = $wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			'SELECT * FROM %i WHERE group_session_id IN (' . implode( ', ', array_fill( 0, count( $session_ids ), '%d' ) ) . ')',
			array_merge( array( TutorHelper_Pro_Database::get_table_name( 'group_lesson_follow_up' ) ), $session_ids )
		);
		$shared      = $wpdb->get_results( $session_sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$by_session  = array();

		foreach ( $shared as $row ) {
			$by_session[ absint( $row->group_session_id ) ] = $row;
		}

		$result = array();
		foreach ( $mappings as $mapping ) {
			$session_id = absint( $mapping->session_id );
			if ( isset( $by_session[ $session_id ] ) ) {
				$result[ absint( $mapping->booking_id ) ] = $by_session[ $session_id ];
			}
		}

		return $result;
	}

	/** Prepare a safe, read-only follow-up record. */
	private static function prepare_follow_up( $row, $booking_id ) {
		$attachment_id  = isset( $row->homework_attachment_id ) ? absint( $row->homework_attachment_id ) : 0;
		$attachment_url = $attachment_id ? wp_get_attachment_url( $attachment_id ) : '';
		$due            = self::due_details( $row );
		$feedback       = isset( $row->tutor_feedback ) ? trim( (string) $row->tutor_feedback ) : '';
		$title          = isset( $row->homework_title ) ? trim( (string) $row->homework_title ) : '';
		$instructions   = isset( $row->homework_instructions ) ? trim( (string) $row->homework_instructions ) : '';
		$url            = isset( $row->homework_url ) ? esc_url_raw( (string) $row->homework_url ) : '';
		$completed      = class_exists( 'TutorHelper_Pro_Lesson_Follow_Up' )
			? TutorHelper_Pro_Lesson_Follow_Up::is_homework_completed( $booking_id )
			: false;

		return array(
			'feedback'         => $feedback,
			'homework_title'    => $title,
			'instructions'      => $instructions,
			'homework_url'      => $url,
			'attachment_url'    => $attachment_url ? esc_url_raw( $attachment_url ) : '',
			'attachment_label'  => $attachment_id ? sanitize_text_field( get_the_title( $attachment_id ) ) : '',
			'due_label'         => $due['label'],
			'due_timestamp'     => $due['timestamp'],
			'homework_completed' => $completed,
			'is_outstanding'    => ! $completed && ( $title || $instructions || $url || $attachment_url ) && ( ! $due['timestamp'] || $due['timestamp'] >= current_time( 'timestamp', true ) ),
			'has_content'       => (bool) ( $feedback || $title || $instructions || $url || $attachment_url ),
		);
	}

	/** Resolve homework due lesson/date without exposing booking records. */
	private static function due_details( $row ) {
		$booking_id = isset( $row->homework_due_booking_id ) ? absint( $row->homework_due_booking_id ) : 0;
		$booking    = $booking_id ? TutorHelper_Booking_Records::get_by_id( $booking_id ) : null;

		if ( $booking && ! empty( $booking->booking_start ) ) {
			$timestamp = strtotime( $booking->booking_start . ' UTC' );
			return array(
				'label'     => $timestamp ? wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), $timestamp, wp_timezone() ) : '',
				'timestamp' => $timestamp ? $timestamp : 0,
			);
		}

		$session_id = isset( $row->homework_due_group_session_id ) ? absint( $row->homework_due_group_session_id ) : 0;
		$session    = $session_id && class_exists( 'TutorHelper_Group_Sessions' ) ? TutorHelper_Group_Sessions::get_by_id( $session_id ) : null;
		$timestamp  = $session && ! empty( $session->booking_start ) ? strtotime( $session->booking_start . ' UTC' ) : 0;

		return array(
			'label'     => $timestamp ? wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), $timestamp, wp_timezone() ) : '',
			'timestamp' => $timestamp ? $timestamp : 0,
		);
	}
}
