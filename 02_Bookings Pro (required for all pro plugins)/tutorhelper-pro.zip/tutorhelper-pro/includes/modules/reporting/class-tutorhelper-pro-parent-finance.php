<?php
/**
 * Student-scoped finance service for trusted TutorHelper extensions.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Exposes prepared finance data and a secure multi-booking Stripe checkout.
 */
final class TutorHelper_Pro_Parent_Finance {

	const CHECKOUT_CONTEXT = 'parent_finance';

	/** Register the signed Stripe webhook extension. */
	public static function init() {
		add_filter(
			'tutorhelper_pro_stripe_webhook_extension_result',
			array( __CLASS__, 'handle_stripe_webhook' ),
			20,
			3
		);
	}

	/**
	 * Return student-scoped finance data.
	 *
	 * The calling add-on must authorise the viewer/student relationship.
	 *
	 * @param int $student_id Student user ID.
	 * @return array
	 */
	public static function get_snapshot( $student_id ) {
		$student_id = absint( $student_id );
		if ( ! $student_id || ! TutorHelper_Students::get_student( $student_id ) ) {
			return array(
				'due' => array(),
				'statement' => array(),
				'methods' => array(),
				'bank_details' => array(),
			);
		}

		$bookings = TutorHelper_Booking_Records::get_all(
			array(
				'student_user_id' => $student_id,
				'limit' => 1000,
			)
		);
		$payments = self::payment_totals( $student_id );
		$now = current_time( 'timestamp', true );
		$cutoff = $now + ( 30 * DAY_IN_SECONDS );
		$due = array();
		$statement = array();

		foreach ( $bookings as $booking ) {
			$row = self::prepare_booking( $booking, $payments );
			if ( empty( $row ) ) {
				continue;
			}

			if (
				$row['balance_minor_units'] > 0
				&& $row['start_timestamp'] <= $cutoff
				&& TutorHelper_Booking_Records::STATUS_CANCELLED !== $row['booking_status']
			) {
				$due[] = $row;
			} else {
				$statement[] = self::booking_statement_row( $row );
			}
		}

		usort(
			$due,
			static function ( $a, $b ) {
				$priority_a = $a['paid_minor_units'] > 0 ? 0 : 1;
				$priority_b = $b['paid_minor_units'] > 0 ? 0 : 1;
				if ( $priority_a !== $priority_b ) {
					return $priority_a <=> $priority_b;
				}
				return $a['start_timestamp'] <=> $b['start_timestamp'];
			}
		);

		$statement = array_merge( $statement, self::transaction_rows( $student_id ) );
		usort(
			$statement,
			static function ( $a, $b ) {
				return $b['timestamp'] <=> $a['timestamp'];
			}
		);

		$methods = array(
			'card' => TutorHelper_Pro_Student_Payment_Methods::card_is_allowed( $student_id )
				&& TutorHelper_Pro_Payment_Settings::stripe_is_configured(),
			'bank_transfer' => TutorHelper_Pro_Student_Payment_Methods::bank_is_allowed( $student_id ),
			'invoice' => TutorHelper_Pro_Student_Payment_Methods::invoice_is_allowed( $student_id ),
		);

		return array(
			'due' => $due,
			'statement' => $statement,
			'methods' => $methods,
			'bank_details' => $methods['bank_transfer'] && TutorHelper_Pro_Bank_Details::is_configured()
				? TutorHelper_Pro_Bank_Details::get_details()
				: array(),
			'currency' => TutorHelper_Currency::get_currency(),
			'credit_balance_minor_units' => TutorHelper_Pro_Student_Credits::get_balance(
				$student_id,
				TutorHelper_Currency::get_currency()
			),
		);
	}

	/**
	 * Start a Stripe Checkout for selected unpaid lessons.
	 *
	 * @param int    $student_id Student user ID.
	 * @param int    $parent_id  Parent/guardian user ID.
	 * @param array  $booking_ids Selected booking IDs.
	 * @param string $return_url Dashboard return URL.
	 * @return array|WP_Error
	 */
	public static function create_checkout( $student_id, $parent_id, $booking_ids, $return_url ) {
		$student_id = absint( $student_id );
		$parent_id = absint( $parent_id );
		$ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $booking_ids ) ) ) );

		if (
			! $student_id
			|| ! $parent_id
			|| empty( $ids )
			|| ! TutorHelper_Pro_Student_Payment_Methods::card_is_allowed( $student_id )
		) {
			return new WP_Error(
				'tutorhelper_pro_parent_checkout_invalid',
				__( 'Select at least one payable lesson.', 'tutorhelper-pro' )
			);
		}

		$totals = self::payment_totals( $student_id );
		$amount = 0;
		$currency = '';
		$valid_ids = array();
		$checkout_allocations = array();

		foreach ( $ids as $booking_id ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
			if (
				! $booking
				|| $student_id !== absint( $booking->student_user_id )
				|| TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status )
			) {
				return new WP_Error(
					'tutorhelper_pro_parent_checkout_booking_invalid',
					__( 'One of the selected lessons is no longer payable.', 'tutorhelper-pro' )
				);
			}

			$booking_currency = strtoupper( sanitize_text_field( $booking->currency ) );
			if ( '' !== $currency && $currency !== $booking_currency ) {
				return new WP_Error(
					'tutorhelper_pro_parent_checkout_currency_mismatch',
					__( 'Lessons using different currencies must be paid separately.', 'tutorhelper-pro' )
				);
			}
			$currency = $booking_currency;
			$paid = isset( $totals[ $booking_id ] ) ? max( 0, intval( $totals[ $booking_id ] ) ) : 0;
			$balance = max( 0, absint( $booking->price_minor_units ) - $paid );
			if ( 0 === $balance ) {
				continue;
			}
			$amount += $balance;
			$valid_ids[] = $booking_id;
			$checkout_allocations[] = $booking_id . ':' . $balance;
		}

		if ( 0 === $amount || empty( $valid_ids ) ) {
			return new WP_Error(
				'tutorhelper_pro_parent_checkout_nothing_due',
				__( 'The selected lessons no longer have a balance due.', 'tutorhelper-pro' )
			);
		}

		$return_url = wp_validate_redirect( $return_url, home_url( '/' ) );
		$success_url = add_query_arg( 'tutorhelper_parent_payment', 'success', $return_url );
		$success_url = esc_url_raw( $success_url ) . '&session_id={CHECKOUT_SESSION_ID}';
		$cancel_url = add_query_arg( 'tutorhelper_parent_payment', 'cancelled', $return_url );
		$student = get_userdata( $student_id );
		$parent = get_userdata( $parent_id );

		$checkout = TutorHelper_Pro_Stripe::create_extension_checkout_session(
			array(
				'amount_minor_units' => $amount,
				'currency' => $currency,
				'product_name' => sprintf(
					/* translators: %s: student name. */
					__( 'Tuition fees for %s', 'tutorhelper-pro' ),
					$student ? $student->display_name : __( 'student', 'tutorhelper-pro' )
				),
				'description' => sprintf(
					/* translators: %d: lesson count. */
					_n( '%d selected lesson', '%d selected lessons', count( $valid_ids ), 'tutorhelper-pro' ),
					count( $valid_ids )
				),
				'customer_email' => $parent ? $parent->user_email : '',
				'client_reference_id' => 'thpc-' . $parent_id . '-' . $student_id,
				'success_url' => $success_url,
				'cancel_url' => esc_url_raw( $cancel_url ),
				'metadata' => array(
					'tutorhelper_context' => self::CHECKOUT_CONTEXT,
					'student_user_id' => $student_id,
					'parent_user_id' => $parent_id,
					'booking_ids' => implode( ',', $valid_ids ),
					'allocations' => implode( ',', $checkout_allocations ),
				),
			)
		);

		if ( is_wp_error( $checkout ) ) {
			return $checkout;
		}

		foreach ( $valid_ids as $booking_id ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
			TutorHelper_Booking_Records::update_payment_details(
				$booking_id,
				array(
					'payment_status' => sanitize_key( $booking->payment_status ),
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
					'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					'payment_reference' => sanitize_text_field( $checkout['id'] ),
					'booking_status' => sanitize_key( $booking->status ),
				),
				sanitize_key( $booking->payment_status )
			);
		}

		return $checkout;
	}

	/**
	 * Claim and process Parent & Child Stripe events.
	 *
	 * @param mixed  $result     Existing extension result.
	 * @param array  $event      Verified Stripe event.
	 * @param string $event_type Stripe event type.
	 * @return mixed
	 */
	public static function handle_stripe_webhook( $result, $event, $event_type ) {
		if ( null !== $result ) {
			return $result;
		}

		$session = isset( $event['data']['object'] ) && is_array( $event['data']['object'] )
			? $event['data']['object']
			: array();
		$metadata = isset( $session['metadata'] ) && is_array( $session['metadata'] )
			? $session['metadata']
			: array();

		if ( self::CHECKOUT_CONTEXT !== ( $metadata['tutorhelper_context'] ?? '' ) ) {
			return null;
		}

		if ( 'checkout.session.expired' === $event_type ) {
			return true;
		}

		if ( 'checkout.session.completed' !== $event_type ) {
			return true;
		}

		if ( 'paid' !== sanitize_key( $session['payment_status'] ?? '' ) ) {
			return new WP_Error(
				'tutorhelper_pro_parent_checkout_not_paid',
				'Parent finance Checkout has not been paid.',
				array( 'status' => 409 )
			);
		}

		$student_id = absint( $metadata['student_user_id'] ?? 0 );
		$booking_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'absint', explode( ',', (string) ( $metadata['booking_ids'] ?? '' ) ) )
				)
			)
		);
		$session_id = sanitize_text_field( $session['id'] ?? '' );
		$event_id = sanitize_text_field( $event['id'] ?? '' );
		$currency = strtoupper( sanitize_text_field( $session['currency'] ?? '' ) );
		$allocation_map = array();
		foreach ( explode( ',', (string) ( $metadata['allocations'] ?? '' ) ) as $allocation ) {
			$parts = array_map( 'absint', explode( ':', $allocation, 2 ) );
			if ( 2 === count( $parts ) && $parts[0] && $parts[1] ) {
				$allocation_map[ $parts[0] ] = $parts[1];
			}
		}
		$expected = 0;
		$allocations = array();

		foreach ( $booking_ids as $booking_id ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
			if ( ! $booking || $student_id !== absint( $booking->student_user_id ) ) {
				return new WP_Error(
					'tutorhelper_pro_parent_checkout_scope_invalid',
					'Parent finance booking scope is invalid.',
					array( 'status' => 409 )
				);
			}
			$allocation_amount = absint( $allocation_map[ $booking_id ] ?? 0 );
			if ( 0 === $allocation_amount || $allocation_amount > absint( $booking->price_minor_units ) ) {
				return new WP_Error(
					'tutorhelper_pro_parent_checkout_allocation_invalid',
					'Parent finance Checkout allocation is invalid.',
					array( 'status' => 409 )
				);
			}
			$expected += $allocation_amount;
			$allocations[] = array( 'booking' => $booking, 'amount' => $allocation_amount );
		}

		if (
			$expected !== absint( $session['amount_total'] ?? 0 )
			|| empty( $allocations )
		) {
			return new WP_Error(
				'tutorhelper_pro_parent_checkout_amount_mismatch',
				'Parent finance Checkout amount does not match the selected lessons.',
				array( 'status' => 409 )
			);
		}

		foreach ( $allocations as $allocation ) {
			$booking = $allocation['booking'];
			$amount = $allocation['amount'];
			if ( 0 === $amount ) {
				continue;
			}
			$unique_event_id = $event_id . '-' . absint( $booking->id );
			if ( TutorHelper_Pro_Payment_Ledger::get_by_provider_event( TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE, $unique_event_id ) ) {
				continue;
			}
			$ledger_id = TutorHelper_Pro_Payment_Ledger::record(
				array(
					'booking_id' => absint( $booking->id ),
					'student_user_id' => $student_id,
					'tutor_user_id' => absint( $booking->tutor_user_id ),
					'transaction_type' => TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
					'amount_minor_units' => $amount,
					'currency' => $currency,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
					'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					'provider_reference' => $session_id,
					'provider_event_id' => $unique_event_id,
					'description' => __( 'Parent/guardian Stripe payment.', 'tutorhelper-pro' ),
					'created_by_user_id' => absint( $metadata['parent_user_id'] ?? 0 ),
				)
			);
			if ( is_wp_error( $ledger_id ) ) {
				return $ledger_id;
			}

			$previous_booking_status = sanitize_key(
				$booking->status
			);
			$target_booking_status =
				TutorHelper_Booking_Records::
					STATUS_UNCONFIRMED
				=== $previous_booking_status
					? TutorHelper_Booking_Records::
						STATUS_CONFIRMED
					: $previous_booking_status;

			$update = TutorHelper_Booking_Records::update_payment_details(
				absint( $booking->id ),
				array(
					'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
					'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					'payment_reference' => $session_id,

					/*
					 * Match the Tutor Finance payment workflow: a fully
					 * paid unconfirmed lesson becomes confirmed.
					 */
					'booking_status' => $target_booking_status,
				),
				sanitize_key( $booking->payment_status )
			);
			if ( is_wp_error( $update ) ) {
				return $update;
			}

			TutorHelper_Pro_Payment_History::record(
				array(
					'booking_id' => absint( $booking->id ),
					'student_user_id' => $student_id,
					'previous_payment_status' => sanitize_key( $booking->payment_status ),
					'new_payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
					'previous_booking_status' => $previous_booking_status,
					'new_booking_status' => $target_booking_status,
					'amount_minor_units' => $amount,
					'currency' => $currency,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
					'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					'provider_reference' => $session_id,
					'provider_event_id' => $unique_event_id,
					'change_source' => TutorHelper_Pro_Payment_History::SOURCE_PROVIDER_WEBHOOK,
					'notes' => __( 'Parent/guardian paid selected lessons through Stripe.', 'tutorhelper-pro' ),
				)
			);
			do_action( 'tutorhelper_pro_booking_payment_received', absint( $booking->id ), TutorHelper_Booking_Records::get_by_id( $booking->id ), $booking );
		}

		return true;
	}

	/** Return paid allocations per booking from the immutable ledger. */
	private static function payment_totals( $student_id ) {
		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT booking_id, transaction_type, SUM(amount_minor_units) AS total
				FROM %i
				WHERE student_user_id = %d
				AND booking_id IS NOT NULL
				AND transaction_type IN (%s, %s, %s, %s)
				GROUP BY booking_id, transaction_type',
				$table,
				absint( $student_id ),
				TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
				TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
				TutorHelper_Pro_Payment_Ledger::TYPE_REFUND
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance balances must be current.

		$totals = array();
		foreach ( (array) $rows as $row ) {
			$booking_id = absint( $row->booking_id );
			$amount = intval( $row->total );
			if ( TutorHelper_Pro_Payment_Ledger::TYPE_REFUND === $row->transaction_type ) {
				$amount *= -1;
			}
			$totals[ $booking_id ] = ( $totals[ $booking_id ] ?? 0 ) + $amount;
		}
		return $totals;
	}

	/** Prepare one booking row for a trusted extension. */
	private static function prepare_booking( $booking, $payments ) {
		$booking_id = absint( $booking->id );
		$price = absint( $booking->price_minor_units );
		if ( 0 === $price ) {
			return array();
		}
		$paid = max( 0, intval( $payments[ $booking_id ] ?? 0 ) );
		$start = strtotime( $booking->booking_start . ' UTC' );
		$type = TutorHelper_Booking_Types::get_by_id( absint( $booking->booking_type_id ) );
		$balance = max( 0, $price - $paid );

		return array(
			'booking_id' => $booking_id,
			'title' => $type ? sanitize_text_field( $type->title ) : __( 'Lesson', 'tutorhelper-pro' ),
			'booking_start' => sanitize_text_field( $booking->booking_start ),
			'start_timestamp' => $start ? $start : 0,
			'date_label' => $start ? wp_date( get_option( 'date_format' ), $start, wp_timezone() ) : '',
			'booking_status' => sanitize_key( $booking->status ),
			'payment_status' => 0 === $balance
				? TutorHelper_Booking_Records::PAYMENT_STATUS_PAID
				: ( $paid > 0 ? 'part_paid' : sanitize_key( $booking->payment_status ) ),
			'price_minor_units' => $price,
			'paid_minor_units' => $paid,
			'balance_minor_units' => $balance,
			'currency' => strtoupper( sanitize_text_field( $booking->currency ) ),
		);
	}

	/** Convert one booking into a statement row. */
	private static function booking_statement_row( $booking ) {
		return array(
			'id' => 'booking-' . $booking['booking_id'],
			'timestamp' => $booking['start_timestamp'],
			'date_label' => $booking['date_label'],
			'type' => 'lesson',
			'type_label' => __( 'Lesson', 'tutorhelper-pro' ),
			'description' => $booking['title'],
			'amount_minor_units' => $booking['price_minor_units'],
			'currency' => $booking['currency'],
			'status' => $booking['payment_status'],
		);
	}

	/** Return normalised immutable ledger rows. */
	private static function transaction_rows( $student_id ) {
		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, booking_id, transaction_type, amount_minor_units, currency, description, transaction_date
				FROM %i
				WHERE student_user_id = %d
				ORDER BY transaction_date DESC, id DESC
				LIMIT 1000',
				$table,
				absint( $student_id )
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Statements must show current immutable ledger data.

		$labels = array(
			TutorHelper_Pro_Payment_Ledger::TYPE_BOOKING_CHARGE => __( 'Lesson charge', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT => __( 'Payment', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT => __( 'Deposit', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_REFUND => __( 'Refund', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED => __( 'Credit issued', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED => __( 'Account credit applied', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_ADJUSTMENT => __( 'Adjustment', 'tutorhelper-pro' ),
		);

		$prepared = array();
		foreach ( (array) $rows as $row ) {
			$timestamp = strtotime( $row->transaction_date . ' UTC' );
			$type = sanitize_key( $row->transaction_type );
			$prepared[] = array(
				'id' => 'transaction-' . absint( $row->id ),
				'timestamp' => $timestamp ? $timestamp : 0,
				'date_label' => $timestamp ? wp_date( get_option( 'date_format' ), $timestamp, wp_timezone() ) : '',
				'type' => $type,
				'type_label' => $labels[ $type ] ?? ucfirst( str_replace( '_', ' ', $type ) ),
				'description' => $row->description ? sanitize_text_field( $row->description ) : ( $labels[ $type ] ?? '' ),
				'amount_minor_units' => intval( $row->amount_minor_units ),
				'currency' => strtoupper( sanitize_text_field( $row->currency ) ),
				'status' => 'recorded',
				'booking_id' => absint( $row->booking_id ),
			);
		}
		return $prepared;
	}
}
