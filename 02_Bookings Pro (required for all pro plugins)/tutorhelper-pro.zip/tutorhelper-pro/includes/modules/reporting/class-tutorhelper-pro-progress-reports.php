<?php
/**
 * Student tuition report previews, PDFs, history and delivery.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Builds student-scoped tuition reports without retaining generated PDF files. */
final class TutorHelper_Pro_Progress_Reports {

	/** Core email template key. */
	const TEMPLATE_KEY = 'student_progress_report';

	/** Admin actions. */
	const PREVIEW_ACTION = 'tutorhelper_pro_preview_progress_report';
	const PREVIEW_AJAX_ACTION = 'tutorhelper_pro_preview_progress_report_ajax';
	const DOWNLOAD_ACTION = 'tutorhelper_pro_download_progress_report';
	const SEND_ACTION = 'tutorhelper_pro_send_progress_report';
	const STORED_DOWNLOAD_ACTION = 'tutorhelper_pro_download_saved_progress_report';
	const SAVE_AI_ACTION = 'tutorhelper_pro_save_report_ai';
	const POST_TYPE = 'th_progress_report';
	const OPENAI_KEY_OPTION = 'tutorhelper_pro_openai_api_key';
	const OPENAI_MODEL_OPTION = 'tutorhelper_pro_openai_model';
	const OPENAI_ENABLED_OPTION = 'tutorhelper_pro_openai_reports_enabled';

	/** Maximum bookings included in one report. */
	const MAX_BOOKINGS = 1000;

	/** Whether the report history has already rendered in this shortcode request. */
	private static $student_reports_rendered = false;

	/** Register report hooks. */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_email_template' ) );
		add_action( 'init', array( __CLASS__, 'register_report_post_type' ) );
		add_action( 'tutorhelper_dashboard_after_widgets', array( __CLASS__, 'render_section' ) );
		add_action( 'tutorhelper_student_dashboard_after_sections', array( __CLASS__, 'render_student_dashboard_reports' ) );
		add_action( 'tutorhelper_students_detail_notes_communication', array( __CLASS__, 'render_student_detail_reports' ), 80, 1 );
		add_filter( 'tutorhelper_parent_child_dashboard_sections', array( __CLASS__, 'add_parent_reports_section' ) );
		add_filter( 'tutorhelper_parent_dashboard_section_rendered', array( __CLASS__, 'render_parent_reports_section' ), 20, 3 );
		add_action( 'admin_post_' . self::PREVIEW_ACTION, array( __CLASS__, 'handle_preview' ) );
		add_action( 'wp_ajax_' . self::PREVIEW_AJAX_ACTION, array( __CLASS__, 'handle_preview_ajax' ) );
		add_action( 'admin_post_' . self::DOWNLOAD_ACTION, array( __CLASS__, 'handle_download' ) );
		add_action( 'admin_post_' . self::SEND_ACTION, array( __CLASS__, 'handle_send' ) );
		add_action( 'admin_post_' . self::STORED_DOWNLOAD_ACTION, array( __CLASS__, 'handle_stored_download' ) );
		add_action( 'admin_post_' . self::SAVE_AI_ACTION, array( __CLASS__, 'handle_save_ai_settings' ) );
		add_filter( 'do_shortcode_tag', array( __CLASS__, 'append_student_reports_fallback' ), 20, 4 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue_dashboard_style' ), 40 );
	}

	/** Register private report records without exposing a public archive or editor. */
	public static function register_report_post_type() {
		register_post_type(
			self::POST_TYPE,
			array(
				'label'        => __( 'Student tuition reports', 'tutorhelper-pro' ),
				'public'       => false,
				'show_ui'      => false,
				'show_in_rest' => false,
				'supports'     => array( 'title', 'author' ),
			)
		);
	}

	/** Register the editable email used by Core's sender and delivery history. */
	public static function register_email_template() {
		if ( ! class_exists( 'TutorHelper_Email_Templates' ) ) {
			return;
		}

		TutorHelper_Email_Templates::register(
			self::TEMPLATE_KEY,
			array(
				'module'       => 'progress-reports',
				'label'        => __( 'Student tuition report', 'tutorhelper-pro' ),
				'description'  => __( 'Sent when a tutor publishes a student tuition report.', 'tutorhelper-pro' ),
				'heading'      => __( 'Your tuition report', 'tutorhelper-pro' ),
				'recipient'    => 'selected',
				'enabled'      => true,
				'subject'      => __( 'Tuition report for {student_name}', 'tutorhelper-pro' ),
				'body'         => __( '<p>Hello,</p><p>Your TutorHelper tuition report for {student_name}, covering {report_period}, is ready.</p><p>{report_summary}</p><p><a href="{report_url}">Log in to your dashboard to download the report</a></p>', 'tutorhelper-pro' ),
				'placeholders' => array( '{student_name}', '{report_period}', '{report_summary}', '{report_url}' ),
			)
		);
	}

	/** Load report styling on the Tutor Dashboard only. */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix ) {
			return;
		}
		self::enqueue_report_style();

		$script_path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-progress-reports.js';
		wp_enqueue_script(
			'tutorhelper-pro-progress-reports',
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-progress-reports.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_PRO_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-pro-progress-reports',
			'tutorhelperProProgressReports',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action' => self::PREVIEW_AJAX_ACTION,
				'errorText' => __( 'The report preview could not be generated. Please check the report details and try again.', 'tutorhelper-pro' ),
			)
		);
	}

	/** Enqueue the report builder/history stylesheet in admin or dashboards. */
	private static function enqueue_report_style() {
		$path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-progress-reports.css';
		wp_enqueue_style(
			'tutorhelper-pro-progress-reports',
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-progress-reports.css',
			is_admin() ? array( 'tutorhelper-admin-dashboard' ) : array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_PRO_VERSION
		);
	}

	/** Load report history styles for authenticated student or parent dashboards. */
	public static function maybe_enqueue_dashboard_style() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$roles = (array) wp_get_current_user()->roles;
		if (
			in_array( TutorHelper_Students::STUDENT_ROLE, $roles, true )
			|| in_array( TutorHelper_Roles::PARENT_ROLE, $roles, true )
		) {
			self::enqueue_report_style();
		}
	}

	/** Render the builder and, after a valid POST, its mandatory preview. */
	public static function render_section() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}

		$students = get_users(
			array(
				'role'    => TutorHelper_Students::STUDENT_ROLE,
				'orderby' => 'display_name',
				'order'   => 'ASC',
			)
		);
		$token = self::read_query_token();
		$report = $token ? self::get_preview( $token ) : null;
		?>
		<section class="tutorhelper-progress-reports" id="student-progress-reports">
			<header>
				<p class="tutorhelper-dashboard__eyebrow"><?php esc_html_e( 'PDF reports', 'tutorhelper-pro' ); ?></p>
				<h2><?php esc_html_e( 'Student tuition report', 'tutorhelper-pro' ); ?></h2>
				<p><?php esc_html_e( 'Choose the reporting period, content and authorised recipients. You will preview the report before it can be downloaded or sent.', 'tutorhelper-pro' ); ?></p>
			</header>

			<?php self::render_notice(); ?>
			<?php self::render_ai_settings(); ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-progress-reports__form">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::PREVIEW_ACTION ); ?>" />
				<?php wp_nonce_field( self::PREVIEW_ACTION ); ?>
				<label>
					<span><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></span>
					<select name="student_ids[]" multiple size="8" required aria-describedby="tutorhelper-progress-students-help">
						<?php foreach ( $students as $student ) : ?>
							<option value="<?php echo esc_attr( $student->ID ); ?>"><?php echo esc_html( $student->display_name ); ?></option>
						<?php endforeach; ?>
					</select>
					<small id="tutorhelper-progress-students-help"><?php esc_html_e( 'Select one or more students. Use Ctrl or Command to select several.', 'tutorhelper-pro' ); ?></small>
				</label>
				<label><span><?php esc_html_e( 'Start date', 'tutorhelper-pro' ); ?></span><input type="date" name="date_from" required /></label>
				<label><span><?php esc_html_e( 'End date', 'tutorhelper-pro' ); ?></span><input type="date" name="date_to" required /></label>

				<fieldset>
					<legend><?php esc_html_e( 'Included sections', 'tutorhelper-pro' ); ?></legend>
					<?php foreach ( self::section_labels() as $key => $label ) : ?>
						<label><input type="checkbox" name="sections[]" value="<?php echo esc_attr( $key ); ?>" checked /> <?php echo esc_html( $label ); ?></label>
					<?php endforeach; ?>
				</fieldset>

				<?php if ( self::ai_is_ready() ) : ?>
					<fieldset>
						<legend><?php esc_html_e( 'AI summary', 'tutorhelper-pro' ); ?></legend>
						<label><input type="checkbox" name="include_ai_summary" value="1" /> <?php esc_html_e( 'Include an OpenAI-generated summary of the tutor feedback', 'tutorhelper-pro' ); ?></label>
						<small><?php esc_html_e( 'The reporting period, student’s first name, attendance percentage, tutor feedback and relevant homework details are sent. No surname, email address or contact details are included.', 'tutorhelper-pro' ); ?></small>
					</fieldset>
				<?php endif; ?>

				<div class="tutorhelper-progress-reports__note">
					<label for="tutorhelper-report-introduction"><?php esc_html_e( 'Report introduction', 'tutorhelper-pro' ); ?></label>
					<p class="description"><?php esc_html_e( 'Edit the introductory message shown near the start of each student’s report.', 'tutorhelper-pro' ); ?></p>
					<?php
					wp_editor(
						self::default_introduction(),
						'tutorhelper-report-introduction',
						self::editor_settings( 'introduction' )
					);
					?>
				</div>

				<div class="tutorhelper-progress-reports__note">
					<label for="tutorhelper-progress-extra-note"><?php esc_html_e( 'Additional note', 'tutorhelper-pro' ); ?></label>
					<p class="description"><?php esc_html_e( 'Optional information such as term dates, upcoming availability or Group lesson opportunities.', 'tutorhelper-pro' ); ?></p>
					<?php
					wp_editor(
						'',
						'tutorhelper-progress-extra-note',
						self::editor_settings( 'extra_note' )
					);
					?>
				</div>

				<fieldset>
					<legend><?php esc_html_e( 'Recipients', 'tutorhelper-pro' ); ?></legend>
					<label><input type="checkbox" name="send_student" value="1" checked /> <?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></label>
					<label><input type="checkbox" name="send_parents" value="1" /> <?php esc_html_e( 'All linked parents', 'tutorhelper-pro' ); ?></label>
					<label><input type="checkbox" name="cc_tutor" value="1" /> <?php esc_html_e( 'CC the tutor', 'tutorhelper-pro' ); ?></label>
				</fieldset>

				<button type="submit" class="button button-primary" data-progress-report-build data-loading-label="<?php esc_attr_e( 'Generating report…', 'tutorhelper-pro' ); ?>"><?php esc_html_e( 'Build preview', 'tutorhelper-pro' ); ?></button>
				<span class="tutorhelper-progress-reports__generating" role="status" aria-live="polite" data-progress-report-status hidden><?php esc_html_e( 'Generating the report and AI summary. Please wait…', 'tutorhelper-pro' ); ?></span>
			</form>

			<div
				class="tutorhelper-progress-reports__preview-region"
				data-progress-report-preview
				aria-live="polite"
				tabindex="-1"
			>
				<?php
				if ( is_array( $report ) ) {
					self::render_preview( $report, $token );
				}
				?>
			</div>
		</section>
		<?php
	}


	/**
	 * Render a stored report preview and its protected actions.
	 *
	 * @param array  $report Preview data.
	 * @param string $token  User-bound preview token.
	 * @return void
	 */
	private static function render_preview( $report, $token ) {
		$preview_report = ! empty( $report['students'][0] )
			? self::single_student_report( $report, $report['students'][0] )
			: $report;
		?>
		<div class="tutorhelper-progress-reports__preview" aria-labelledby="tutorhelper-progress-preview-title">
			<h3 id="tutorhelper-progress-preview-title"><?php esc_html_e( 'Report preview', 'tutorhelper-pro' ); ?></h3>
			<?php if ( 1 < count( $report['students'] ) ) : ?>
				<p class="description">
					<?php
					printf(
						/* translators: %s: Number of student reports in the combined PDF. */
						esc_html__( 'Showing the first selected student. Download the PDF to view all %s student reports.', 'tutorhelper-pro' ),
						esc_html( number_format_i18n( count( $report['students'] ) ) )
					);
					?>
				</p>
			<?php endif; ?>
			<?php if ( self::has_ai_summary_failures( $preview_report ) ) : ?>
				<div class="notice notice-warning"><p><?php esc_html_e( 'The OpenAI feedback summary could not be generated. The report preview was created without it and details were added to Diagnostics.', 'tutorhelper-pro' ); ?></p></div>
			<?php endif; ?>
			<?php echo wp_kses( self::build_report_html( $preview_report ), wp_kses_allowed_html( 'post' ), array( 'http', 'https', 'data' ) ); ?>
			<div class="tutorhelper-progress-reports__actions">
				<?php self::render_action_form( self::DOWNLOAD_ACTION, $token, __( 'Download PDF', 'tutorhelper-pro' ), false ); ?>
				<?php self::render_action_form( self::SEND_ACTION, $token, __( 'Send report', 'tutorhelper-pro' ), true ); ?>
			</div>
		</div>
		<?php
	}

	/** Render a protected preview action form. */
	private static function render_action_form( $action, $token, $label, $primary ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>" />
			<input type="hidden" name="report_token" value="<?php echo esc_attr( $token ); ?>" />
			<?php wp_nonce_field( $action . '_' . $token ); ?>
			<button type="submit" class="button<?php echo $primary ? ' button-primary' : ''; ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	/** Render the opt-in OpenAI connection used only for feedback summaries. */
	private static function render_ai_settings() {
		$enabled = (bool) get_option( self::OPENAI_ENABLED_OPTION, false );
		$has_key = '' !== trim( (string) get_option( self::OPENAI_KEY_OPTION, '' ) );
		$model = sanitize_text_field( (string) get_option( self::OPENAI_MODEL_OPTION, 'gpt-5-mini' ) );
		?>
		<details class="tutorhelper-progress-reports__ai-settings">
			<summary><?php esc_html_e( 'OpenAI feedback summaries', 'tutorhelper-pro' ); ?> — <?php echo esc_html( $enabled && $has_key ? __( 'Connected', 'tutorhelper-pro' ) : __( 'Not configured', 'tutorhelper-pro' ) ); ?></summary>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_AI_ACTION ); ?>" />
				<?php wp_nonce_field( self::SAVE_AI_ACTION ); ?>
				<p><?php esc_html_e( 'When enabled, the reporting period, student’s first name, attendance percentage, tutor feedback and relevant homework details selected for a report are sent to the OpenAI API. TutorHelper does not add surnames, email addresses or lesson contact details. Check tutor-entered text for identifying information before use.', 'tutorhelper-pro' ); ?></p>
				<label for="tutorhelper-report-openai-key"><?php esc_html_e( 'OpenAI API key', 'tutorhelper-pro' ); ?></label>
				<input id="tutorhelper-report-openai-key" type="password" name="openai_api_key" value="" autocomplete="new-password" placeholder="<?php echo esc_attr( $has_key ? __( 'Key saved — leave blank to keep it', 'tutorhelper-pro' ) : 'sk-…' ); ?>" />
				<label for="tutorhelper-report-openai-model"><?php esc_html_e( 'Model', 'tutorhelper-pro' ); ?></label>
				<input id="tutorhelper-report-openai-model" type="text" name="openai_model" value="<?php echo esc_attr( $model ); ?>" />
				<label><input type="checkbox" name="openai_enabled" value="1" <?php checked( $enabled ); ?> /> <?php esc_html_e( 'Allow OpenAI feedback summaries in tuition reports', 'tutorhelper-pro' ); ?></label>
				<label><input type="checkbox" name="remove_openai_key" value="1" /> <?php esc_html_e( 'Remove the saved API key', 'tutorhelper-pro' ); ?></label>
				<button type="submit" class="button"><?php esc_html_e( 'Save AI settings', 'tutorhelper-pro' ); ?></button>
			</form>
		</details>
		<?php
	}

	/** Save the report-only OpenAI connection without exposing the stored key. */
	public static function handle_save_ai_settings() {
		self::guard( self::SAVE_AI_ACTION );
		$key = isset( $_POST['openai_api_key'] ) && ! is_array( $_POST['openai_api_key'] )
			? trim( sanitize_text_field( wp_unslash( $_POST['openai_api_key'] ) ) )
			: '';
		$model = isset( $_POST['openai_model'] ) && ! is_array( $_POST['openai_model'] )
			? sanitize_key( wp_unslash( $_POST['openai_model'] ) )
			: 'gpt-5-mini';
		if ( ! empty( $_POST['remove_openai_key'] ) ) {
			delete_option( self::OPENAI_KEY_OPTION );
			update_option( self::OPENAI_ENABLED_OPTION, false, false );
		} elseif ( '' !== $key ) {
			update_option( self::OPENAI_KEY_OPTION, $key, false );
		}
		update_option( self::OPENAI_MODEL_OPTION, $model ?: 'gpt-5-mini', false );
		if ( empty( $_POST['remove_openai_key'] ) ) {
			update_option( self::OPENAI_ENABLED_OPTION, ! empty( $_POST['openai_enabled'] ), false );
		}
		self::redirect_status( 'ai_saved' );
	}

	/** Whether a tutor has explicitly configured and enabled the API connection. */
	private static function ai_is_ready() {
		return (bool) get_option( self::OPENAI_ENABLED_OPTION, false )
			&& '' !== trim( (string) get_option( self::OPENAI_KEY_OPTION, '' ) );
	}

	/** Validate input, build current student-scoped data and redirect to preview. */
	public static function handle_preview() {
		self::guard( self::PREVIEW_ACTION );

		$preview = self::prepare_preview_from_request();
		if ( is_wp_error( $preview ) ) {
			self::redirect_status( $preview->get_error_code() );
		}

		$token = self::store_preview( $preview['report'] );
		wp_safe_redirect( self::dashboard_url( array( 'progress_preview' => $token ) ) );
		exit;
	}

	/**
	 * Build a report preview without navigating away from the Tutor Dashboard.
	 *
	 * @return array|WP_Error
	 */
	private static function prepare_preview_from_request() {
		$student_ids = array();
		$date_from = '';
		$date_to = '';

		try {
			$student_ids = self::post_ids( 'student_ids' );
			$students = array();
			foreach ( $student_ids as $student_id ) {
				$student = TutorHelper_Students::get_student( $student_id );
				if ( $student instanceof WP_User ) {
					$students[] = $student;
				}
			}
			$date_from = self::post_date( 'date_from' );
			$date_to = self::post_date( 'date_to' );
			$sections = self::post_sections();

			if ( empty( $students ) || count( $students ) !== count( $student_ids ) || ! $date_from || ! $date_to ) {
				return new WP_Error( 'invalid' );
			}
			if ( $date_to < $date_from ) {
				return new WP_Error( 'reversed' );
			}
			if ( empty( $sections ) ) {
				return new WP_Error( 'sections' );
			}

			$report = self::build_report(
				$students,
				$date_from,
				$date_to,
				$sections,
				! empty( $_POST['send_student'] ),
				! empty( $_POST['send_parents'] ),
				! empty( $_POST['cc_tutor'] ),
				self::post_rich_text( 'extra_note' ),
				self::post_rich_text( 'introduction' ),
				self::ai_is_ready() && ! empty( $_POST['include_ai_summary'] )
			);

			if ( is_wp_error( $report ) ) {
				self::log_preview_failure( $report, $student_ids, $date_from, $date_to );
				return new WP_Error( 'preview_failed' );
			}

			return array(
				'report' => $report,
			);
		} catch ( Throwable $error ) {
			self::log_preview_failure( $error, $student_ids, $date_from, $date_to );
			return new WP_Error( 'preview_failed' );
		}
	}

	/**
	 * Store a user-bound preview for its later download or sending actions.
	 *
	 * @param array $report Report data.
	 * @return string
	 */
	private static function store_preview( $report ) {
		$token = wp_generate_password( 24, false, false );
		set_transient( self::transient_key( $token ), $report, 30 * MINUTE_IN_SECONDS );

		return $token;
	}

	/**
	 * Generate and return only the report-preview region for the dashboard.
	 *
	 * @return void
	 */
	public static function handle_preview_ajax() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to generate this report.', 'tutorhelper-pro' ),
				),
				403
			);
		}

		check_ajax_referer( self::PREVIEW_ACTION );

		$preview = self::prepare_preview_from_request();
		if ( is_wp_error( $preview ) ) {
			wp_send_json_error(
				array(
					'message' => self::preview_error_message( $preview->get_error_code() ),
				),
				400
			);
		}

		$token = self::store_preview( $preview['report'] );
		ob_start();
		self::render_preview( $preview['report'], $token );
		wp_send_json_success(
			array(
				'html' => ob_get_clean(),
			)
		);
	}

	/**
	 * Return a concise, safe message for preview validation failures.
	 *
	 * @param string $code Error code.
	 * @return string
	 */
	private static function preview_error_message( $code ) {
		$messages = array(
			'invalid' => __( 'Select a valid student and date range.', 'tutorhelper-pro' ),
			'reversed' => __( 'The end date must be on or after the start date.', 'tutorhelper-pro' ),
			'sections' => __( 'Select at least one report section.', 'tutorhelper-pro' ),
			'preview_failed' => __( 'The report preview could not be created. Details were added to Diagnostics; please try again.', 'tutorhelper-pro' ),
		);

		return isset( $messages[ $code ] )
			? $messages[ $code ]
			: __( 'The report preview could not be created. Please try again.', 'tutorhelper-pro' );
	}

	/** Download the already-previewed report without storing it. */
	public static function handle_download() {
		$report = self::require_preview( self::DOWNLOAD_ACTION );
		$pdf = self::generate_pdf( $report );
		if ( is_wp_error( $pdf ) ) {
			self::log_failure( 'Student progress PDF generation failed.', $pdf, $report );
			self::redirect_status( 'pdf_failed' );
		}

		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( self::filename( $report ) ) . '"' );
		header( 'Content-Length: ' . strlen( $pdf ) );
		echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Binary PDF response generated by Dompdf.
		exit;
	}

	/** Publish the previewed report and send a dashboard link through Core. */
	public static function handle_send() {
		$report = self::require_preview( self::SEND_ACTION );
		$failed = 0;
		$period = self::period_label( $report );
		foreach ( $report['students'] as $student_report ) {
			$student_pdf_report = self::single_student_report( $report, $student_report );
			$recipients = self::resolve_recipients( $student_pdf_report );
			if ( is_wp_error( $recipients ) ) {
				++$failed;
				self::log_failure( 'Student progress report recipient resolution failed.', $recipients, $student_pdf_report );
				continue;
			}
			$student_sent = 0;
			$sent_to = array();
			foreach ( $recipients as $index => $recipient ) {
				$headers = array();
				if ( 0 === $index && ! empty( $report['cc_tutor'] ) ) {
					$tutor = wp_get_current_user();
					if ( is_email( $tutor->user_email ) ) {
						$headers[] = 'Cc: ' . sanitize_email( $tutor->user_email );
					}
				}
				$result = TutorHelper_Email_Sender::send(
					self::TEMPLATE_KEY,
					$recipient,
					array(
						'{student_name}'  => $student_report['student_name'],
						'{report_period}' => $period,
						'{report_summary}' => self::summary_text( $student_pdf_report ),
						'{report_url}'     => self::report_dashboard_url(),
					),
					array(
						'headers' => $headers,
						'context' => array(
							'student_user_id' => $student_report['student_id'],
							'report_date_from' => $report['date_from'],
							'report_date_to' => $report['date_to'],
						),
					)
				);
				if ( is_wp_error( $result ) ) {
					++$failed;
					self::log_failure( 'Student progress report email failed.', $result, $student_pdf_report );
				} else {
					++$student_sent;
					$sent_to[] = sanitize_email( $recipient );
				}
			}
			if ( $student_sent ) {
				if ( ! empty( $student_pdf_report['cc_tutor'] ) ) {
					$tutor = wp_get_current_user();
					if ( is_email( $tutor->user_email ) ) {
						$sent_to[] = sanitize_email( $tutor->user_email );
					}
				}
				self::store_sent_report( $student_pdf_report, $sent_to );
			}
		}

		self::redirect_status( $failed ? 'send_failed' : 'sent' );
	}

	/** Create the student-specific payload used for private email delivery. */
	private static function single_student_report( $report, $student_report ) {
		$single = $report;
		$single['student_ids'] = array( absint( $student_report['student_id'] ) );
		$single['student_name'] = sanitize_text_field( $student_report['student_name'] );
		$single['students'] = array( $student_report );
		$student = TutorHelper_Students::get_student( $student_report['student_id'] );
		$single['recipient_display'] = $student instanceof WP_User
			? self::recipient_display( array( $student ), $report['send_student'], $report['send_parents'], $report['cc_tutor'] )
			: array();
		return $single;
	}

	/** Persist an immutable student-specific snapshot after at least one delivery succeeds. */
	private static function store_sent_report( $report, $sent_to ) {
		$student_id = isset( $report['student_ids'][0] ) ? absint( $report['student_ids'][0] ) : 0;
		if ( ! $student_id ) {
			return new WP_Error( 'report_student_missing' );
		}
		$post_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_author' => get_current_user_id(),
				'post_title'  => sprintf(
					/* translators: 1: Student name, 2: Report end date. */
					__( 'Tuition report — %1$s — %2$s', 'tutorhelper-pro' ),
					$report['student_name'],
					$report['date_to']
				),
			),
			true
		);
		if ( is_wp_error( $post_id ) ) {
			self::log_failure( 'Student tuition report record could not be saved.', $post_id, $report );
			return $post_id;
		}
		update_post_meta( $post_id, '_tutorhelper_report_student_id', $student_id );
		update_post_meta( $post_id, '_tutorhelper_report_snapshot', $report );
		update_post_meta( $post_id, '_tutorhelper_report_sent_to', array_values( array_unique( array_map( 'sanitize_email', $sent_to ) ) ) );
		$recipient_names = isset( $report['recipient_display'] ) ? (array) $report['recipient_display'] : array();
		if ( ! empty( $report['students'][0]['recipient_display'] ) ) {
			$recipient_names = (array) $report['students'][0]['recipient_display'];
		}
		$recipient_names = array_map(
			static function ( $label ) {
				return preg_replace( '/^[^:]+:\s*/', '', sanitize_text_field( $label ) );
			},
			$recipient_names
		);
		update_post_meta( $post_id, '_tutorhelper_report_recipient_names', array_values( array_unique( array_filter( $recipient_names ) ) ) );
		update_post_meta( $post_id, '_tutorhelper_report_sent_at', time() );
		return $post_id;
	}

	/** Securely regenerate a saved report rather than exposing a stored PDF file. */
	public static function handle_stored_download() {
		$report_id = isset( $_GET['report_id'] ) && ! is_array( $_GET['report_id'] ) ? absint( $_GET['report_id'] ) : 0;
		check_admin_referer( self::STORED_DOWNLOAD_ACTION . '_' . $report_id );
		$report = self::get_stored_report( $report_id );
		if ( is_wp_error( $report ) || ! self::current_user_can_access_report( $report_id ) ) {
			wp_die( esc_html__( 'You do not have permission to download this tuition report.', 'tutorhelper-pro' ) );
		}
		$pdf = self::generate_pdf( $report );
		if ( is_wp_error( $pdf ) ) {
			self::log_failure( 'Saved student tuition report regeneration failed.', $pdf, $report );
			wp_die( esc_html__( 'The tuition report could not be regenerated.', 'tutorhelper-pro' ) );
		}
		self::record_report_download( $report_id );
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( self::filename( $report ) ) . '"' );
		header( 'Content-Length: ' . strlen( $pdf ) );
		echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Binary PDF response generated by Dompdf.
		exit;
	}

	/** Render saved reports after the standard student dashboard lesson sections. */
	public static function render_student_dashboard_reports() {
		if ( self::$student_reports_rendered ) {
			return;
		}
		$user_id = get_current_user_id();
		if ( ! $user_id || ! TutorHelper_Students::get_student( $user_id ) ) {
			return;
		}
		self::$student_reports_rendered = true;
		self::enqueue_report_style();
		echo '<section class="tutorhelper-progress-report-history"><h2>' . esc_html__( 'Tuition reports', 'tutorhelper-pro' ) . '</h2>';
		self::render_saved_reports( $user_id, 'dashboard' );
		echo '</section>';
	}

	/** Append report history for Core versions without the post-sections hook. */
	public static function append_student_reports_fallback( $output, $tag, $attr, $shortcode_match ) {
		unset( $attr, $shortcode_match );
		if ( 'tutorhelper_student_dashboard' !== $tag || self::$student_reports_rendered || ! is_user_logged_in() ) {
			return $output;
		}
		$user_id = get_current_user_id();
		if ( ! TutorHelper_Students::get_student( $user_id ) ) {
			return $output;
		}
		ob_start();
		self::render_student_dashboard_reports();
		$reports = ob_get_clean();
		$position = strrpos( $output, '</section>' );
		return false === $position
			? $output . $reports
			: substr_replace( $output, $reports . '</section>', $position, strlen( '</section>' ) );
	}

	/** Add report history to Student Notes & Communication for tutors. */
	public static function render_student_detail_reports( $student ) {
		if ( $student instanceof WP_User && current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			echo '<section class="tutorhelper-progress-report-history"><h4>' . esc_html__( 'Tuition reports', 'tutorhelper-pro' ) . '</h4>';
			self::render_saved_reports( $student->ID, 'admin' );
			echo '</section>';
		}
	}

	/** Add a Reports tab when Parent & Child exposes its section registry. */
	public static function add_parent_reports_section( $sections ) {
		if ( is_array( $sections ) ) {
			$sections['reports'] = __( 'Reports', 'tutorhelper-pro' );
		}
		return $sections;
	}

	/** Render only the selected child's reports in the parent dashboard. */
	public static function render_parent_reports_section( $rendered, $section, $child ) {
		if ( $rendered || 'reports' !== $section || ! $child instanceof WP_User ) {
			return $rendered;
		}
		self::enqueue_report_style();
		echo '<section class="tutorhelper-progress-report-history"><h4>' . esc_html__( 'Tuition reports', 'tutorhelper-pro' ) . '</h4>';
		self::render_saved_reports( $child->ID, 'parent' );
		echo '</section>';
		return true;
	}

	/** Render a compact report history with nonce-protected download links. */
	private static function render_saved_reports( $student_id, $context ) {
		$reports = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 50,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'meta_key'       => '_tutorhelper_report_student_id',
				'meta_value'     => absint( $student_id ),
			)
		);
		if ( empty( $reports ) ) {
			echo '<p>' . esc_html__( 'No tuition reports have been sent yet.', 'tutorhelper-pro' ) . '</p>';
			return;
		}
		$wrap_class = 'parent' === $context ? 'tutorhelper-parent-table-wrap' : ( 'admin' === $context ? 'tutorhelper-student-table-wrap' : 'tutorhelper-pro-dashboard-table tutorhelper-pro-dashboard-table__scroll' );
		$table_class = 'parent' === $context ? 'tutorhelper-parent-table' : ( 'admin' === $context ? 'tutorhelper-student-table' : 'tutorhelper-pro-dashboard-table__table' );
		echo '<div class="tutorhelper-progress-report-list ' . esc_attr( $wrap_class ) . '" data-context="' . esc_attr( $context ) . '"><table class="' . esc_attr( $table_class ) . '"><thead><tr><th>' . esc_html__( 'Report', 'tutorhelper-pro' ) . '</th><th>' . esc_html__( 'Created', 'tutorhelper-pro' ) . '</th><th>' . esc_html__( 'Sent to', 'tutorhelper-pro' ) . '</th>';
		if ( 'admin' === $context ) {
			echo '<th>' . esc_html__( 'Access history', 'tutorhelper-pro' ) . '</th>';
		}
		echo '<th>' . esc_html__( 'Download', 'tutorhelper-pro' ) . '</th></tr></thead><tbody>';
		foreach ( $reports as $report_post ) {
			$report_id = absint( $report_post->ID );
			$stored_report = self::get_stored_report( $report_id );
			$can_download = ! is_wp_error( $stored_report )
				&& self::current_user_can_access_report( $report_id );
			$sent_to = (array) get_post_meta( $report_id, '_tutorhelper_report_sent_to', true );
			$url = $can_download
				? wp_nonce_url(
					add_query_arg(
						array(
							'action'    => self::STORED_DOWNLOAD_ACTION,
							'report_id' => $report_id,
						),
						admin_url( 'admin-post.php' )
					),
					self::STORED_DOWNLOAD_ACTION . '_' . $report_id
				)
				: '';
			$recipient_text = 'admin' === $context
				? implode( ', ', array_map( 'sanitize_email', $sent_to ) )
				: implode( ', ', self::stored_recipient_names( $report_post->ID ) );
			echo '<tr><td data-label="' . esc_attr__( 'Report', 'tutorhelper-pro' ) . '">' . esc_html( $report_post->post_title ) . '</td><td data-label="' . esc_attr__( 'Created', 'tutorhelper-pro' ) . '">' . esc_html( get_the_date( '', $report_post ) ) . '</td><td data-label="' . esc_attr__( 'Sent to', 'tutorhelper-pro' ) . '">' . esc_html( $recipient_text ) . '</td>';
			if ( 'admin' === $context ) {
				echo '<td data-label="' . esc_attr__( 'Access history', 'tutorhelper-pro' ) . '">' . wp_kses_post( self::access_history_html( $report_post->ID ) ) . '</td>';
			}
			if ( $can_download ) {
				echo '<td data-label="' . esc_attr__( 'Download', 'tutorhelper-pro' ) . '"><a class="button tutorhelper-progress-report-list__download" href="' . esc_url( $url ) . '">' . esc_html__( 'Download PDF', 'tutorhelper-pro' ) . '</a></td></tr>';
			} else {
				echo '<td data-label="' . esc_attr__( 'Download', 'tutorhelper-pro' ) . '"><span class="tutorhelper-progress-report-list__unavailable">' . esc_html__( 'This report is no longer available to download.', 'tutorhelper-pro' ) . '</span></td></tr>';
			}

		}
		echo '</tbody></table></div>';
	}

	/** Return recipient names from the immutable snapshot, including older reports. */
	private static function stored_recipient_names( $report_id ) {
		$names = get_post_meta( $report_id, '_tutorhelper_report_recipient_names', true );
		if ( is_array( $names ) && ! empty( $names ) ) {
			return array_values( array_filter( array_map( 'sanitize_text_field', $names ) ) );
		}

		if ( ! is_array( $names ) ) {
			if ( '' !== $names && null !== $names ) {
				TutorHelper_Logger::warning(
					'Report recipient names metadata had an unexpected format.',
					array(
						'report_id'     => absint( $report_id ),
						'metadata_type' => sanitize_key( gettype( $names ) ),
					)
				);
			}

			$names = array();
		}

		$report = self::get_stored_report( $report_id );
		if ( is_wp_error( $report ) ) {
			return array( __( 'Authorised recipient', 'tutorhelper-pro' ) );
		}
		$labels = isset( $report['recipient_display'] ) ? (array) $report['recipient_display'] : array();
		if ( ! empty( $report['students'][0]['recipient_display'] ) ) {
			$labels = (array) $report['students'][0]['recipient_display'];
		}
		foreach ( $labels as $label ) {
			$names[] = preg_replace( '/^[^:]+:\s*/', '', sanitize_text_field( $label ) );
		}
		return ! empty( $names ) ? array_values( array_unique( array_filter( $names ) ) ) : array( __( 'Authorised recipient', 'tutorhelper-pro' ) );
	}

	/** Record a successful student or parent download for the tutor audit trail. */
	private static function record_report_download( $report_id ) {
		$user = wp_get_current_user();
		$student_id = absint( get_post_meta( $report_id, '_tutorhelper_report_student_id', true ) );
		if ( ! $user->exists() || ! $student_id ) {
			return;
		}
		$is_student = $user->ID === $student_id;
		$is_parent = ! $is_student && class_exists( 'TutorHelper_Student_Parent_Links' )
			&& TutorHelper_Student_Parent_Links::is_linked( $user->ID, $student_id );
		if ( ! $is_student && ! $is_parent ) {
			return;
		}
		$account_type = $is_student ? 'student' : 'parent';
		$history = get_post_meta( $report_id, '_tutorhelper_report_access_log', true );
		$history = is_array( $history ) ? $history : array();
		$history[] = array(
			'user_id'      => absint( $user->ID ),
			'display_name' => sanitize_text_field( $user->display_name ),
			'account_type' => $account_type,
			'accessed_at'  => time(),
		);
		update_post_meta( $report_id, '_tutorhelper_report_access_log', array_slice( $history, -200 ) );
	}

	/** Format report downloads without exposing the audit trail outside admin. */
	private static function access_history_html( $report_id ) {
		$history = get_post_meta( $report_id, '_tutorhelper_report_access_log', true );
		if ( ! is_array( $history ) || empty( $history ) ) {
			return esc_html__( 'Not downloaded yet', 'tutorhelper-pro' );
		}
		$items = array();
		foreach ( array_reverse( $history ) as $entry ) {
			$timestamp = isset( $entry['accessed_at'] ) ? absint( $entry['accessed_at'] ) : 0;
			if ( ! $timestamp ) {
				continue;
			}
			$role = isset( $entry['account_type'] ) && 'parent' === $entry['account_type'] ? __( 'Parent/Guardian', 'tutorhelper-pro' ) : __( 'Student', 'tutorhelper-pro' );
			$items[] = sprintf(
				'<li><strong>%1$s</strong> (%2$s)<br><time datetime="%3$s">%4$s</time></li>',
				esc_html( isset( $entry['display_name'] ) ? $entry['display_name'] : '' ),
				esc_html( $role ),
				esc_attr( gmdate( 'c', $timestamp ) ),
				esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp, wp_timezone() ) )
			);
		}
		return $items ? '<ul class="tutorhelper-progress-report-list__access">' . implode( '', $items ) . '</ul>' : esc_html__( 'Not downloaded yet', 'tutorhelper-pro' );
	}

	/** Read and validate an immutable stored report snapshot. */
	private static function get_stored_report( $report_id ) {
		$post = get_post( $report_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type || 'publish' !== $post->post_status ) {
			return new WP_Error( 'report_not_found' );
		}
		$snapshot = get_post_meta( $report_id, '_tutorhelper_report_snapshot', true );
		return is_array( $snapshot ) ? $snapshot : new WP_Error( 'report_snapshot_invalid' );
	}

	/** Enforce tutor, student or currently linked parent ownership. */
	private static function current_user_can_access_report( $report_id ) {
		if ( current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return true;
		}
		$user_id = get_current_user_id();
		$student_id = absint( get_post_meta( $report_id, '_tutorhelper_report_student_id', true ) );
		if ( $user_id && $user_id === $student_id ) {
			return true;
		}
		return $user_id && class_exists( 'TutorHelper_Student_Parent_Links' )
			&& TutorHelper_Student_Parent_Links::is_linked( $user_id, $student_id );
	}

	/** Build authorised report data from Core and Pro services. */
	private static function build_report( $students, $date_from, $date_to, $sections, $send_student, $send_parents, $cc_tutor, $extra_note, $introduction, $include_ai_summary ) {
		$timezone = wp_timezone();
		$start = new DateTimeImmutable( $date_from . ' 00:00:00', $timezone );
		$end = new DateTimeImmutable( $date_to . ' 23:59:59', $timezone );
		$utc = new DateTimeZone( 'UTC' );
		$student_reports = array();
		foreach ( $students as $student ) {
			$bookings = TutorHelper_Booking_Records::get_all(
				array(
					'student_user_id' => $student->ID,
					'date_from' => $start->setTimezone( $utc )->format( 'Y-m-d H:i:s' ),
					'date_to' => $end->setTimezone( $utc )->format( 'Y-m-d H:i:s' ),
					'limit' => self::MAX_BOOKINGS,
				)
			);
			$booking_ids = array_map( 'absint', wp_list_pluck( $bookings, 'id' ) );
			$student_report = array(
				'student_id' => absint( $student->ID ),
				'student_name' => sanitize_text_field( $student->display_name ),
				'bookings' => $bookings,
				'attendance' => TutorHelper_Pro_Student_Reporting::get_attendance( $student->ID, $booking_ids ),
				'follow_ups' => TutorHelper_Pro_Student_Reporting::get_follow_ups( $student->ID, $booking_ids ),
				'recipient_display' => self::recipient_display( array( $student ), $send_student, $send_parents, $cc_tutor ),
			);
			if ( $include_ai_summary ) {
				$summary = self::generate_ai_feedback_summary( $student_report, $date_from, $date_to );
				if ( is_wp_error( $summary ) ) {
					$student_report['feedback_summary_error'] = true;
				} elseif ( '' !== $summary ) {
					$student_report['feedback_summary'] = $summary;
				}
			}
			$student_reports[] = apply_filters( 'tutorhelper_pro_progress_report_student_data', $student_report, $date_from, $date_to );
		}
		$branding = TutorHelper_Pro_Branding::get_all();
		return array(
			'owner_id' => get_current_user_id(),
			'student_ids' => array_map( 'absint', wp_list_pluck( $student_reports, 'student_id' ) ),
			'student_name' => implode( ', ', wp_list_pluck( $student_reports, 'student_name' ) ),
			'date_from' => $date_from,
			'date_to' => $date_to,
			'sections' => $sections,
			'send_student' => (bool) $send_student,
			'send_parents' => (bool) $send_parents,
			'cc_tutor' => (bool) $cc_tutor,
			'extra_note' => wp_kses_post( $extra_note ),
			'introduction' => wp_kses_post( $introduction ),
			'include_ai_summary' => (bool) $include_ai_summary,
			'created_at' => time(),
			'recipient_display' => self::recipient_display( $students, $send_student, $send_parents, $cc_tutor ),
			'branding' => $branding,
			'students' => $student_reports,
		);
	}

	/** Produce branded, Dompdf-safe report markup. */
	private static function build_report_html( $report ) {
		$branding = $report['branding'];
		$business = ! empty( $branding['business_name'] ) ? $branding['business_name'] : get_bloginfo( 'name' );
		$banner = self::branding_image_data_uri( 'email_banner_attachment_id' );
		$html = '<article class="tutorhelper-progress-document">';
		foreach ( $report['students'] as $index => $student_report ) {
			$html .= '<section class="student-report' . ( $index ? ' page-break' : '' ) . '"><header class="report-header">';
			$html .= $banner ? '<img src="' . esc_attr( $banner ) . '" alt="">' : '<div class="report-header__brand">' . esc_html( $business ) . '</div>';
			$html .= '<div class="report-header__title"><h1>' . esc_html__( 'Student tuition report', 'tutorhelper-pro' ) . '</h1><p>' . esc_html( self::period_label( $report ) ) . '</p></div></header>';
			$recipient_display = isset( $student_report['recipient_display'] )
				? (array) $student_report['recipient_display']
				: ( 1 === count( $report['students'] ) && isset( $report['recipient_display'] ) ? (array) $report['recipient_display'] : array() );
			$html .= '<div class="report-meta"><h2>' . esc_html( $student_report['student_name'] ) . '</h2><p><strong>' . esc_html__( 'Created:', 'tutorhelper-pro' ) . '</strong> ' . esc_html( self::created_date_label( $report ) ) . '<br><strong>' . esc_html__( 'Sent to:', 'tutorhelper-pro' ) . '</strong> ' . esc_html( implode( ', ', $recipient_display ) ) . '</p></div>';
			if ( ! empty( $report['introduction'] ) ) {
				$html .= '<section class="report-introduction">' . self::embed_local_content_images( $report['introduction'] ) . '</section>';
			}
			if ( ! empty( $student_report['feedback_summary'] ) ) {
				$html .= '<div class="overview"><h3>' . esc_html__( 'Tutor feedback summary', 'tutorhelper-pro' ) . '</h3><p>' . esc_html( $student_report['feedback_summary'] ) . '</p></div>';
			}
			if ( empty( $student_report['bookings'] ) ) {
				$html .= '<p class="empty">' . esc_html__( 'No lessons matched this reporting period.', 'tutorhelper-pro' ) . '</p>';
			} else {
				foreach ( self::group_by_lesson_type( $student_report ) as $group ) {
					$html .= self::lesson_type_html( $group, $student_report, $report['sections'] );
				}
			}
			$extension_html = apply_filters( 'tutorhelper_pro_progress_report_student_sections_html', '', $student_report, $report );
			$html .= wp_kses_post( $extension_html );
			if ( ! empty( $report['extra_note'] ) ) {
				$html .= '<section class="additional-note"><h2>' . esc_html__( 'Additional information', 'tutorhelper-pro' ) . '</h2>' . self::embed_local_content_images( $report['extra_note'] ) . '</section>';
			}
			$html .= '</section>';
		}
		return $html . '</article>';
	}

	/** Attendance summary and detail. */
	private static function attendance_html( $report ) {
		$totals = $report['attendance']['totals'];
		$html = '<section><h2>' . esc_html__( 'Attendance', 'tutorhelper-pro' ) . '</h2><p>';
		foreach ( $totals as $status => $count ) {
			$html .= '<span class="metric"><strong>' . esc_html( number_format_i18n( $count ) ) . '</strong> ' . esc_html( ucwords( str_replace( '_', ' ', $status ) ) ) . '</span> ';
		}
		$html .= '</p><table><thead><tr><th>' . esc_html__( 'Lesson', 'tutorhelper-pro' ) . '</th><th>' . esc_html__( 'Attendance', 'tutorhelper-pro' ) . '</th></tr></thead><tbody>';
		foreach ( $report['bookings'] as $booking ) {
			$id = absint( $booking->id );
			$record = isset( $report['attendance']['records'][ $id ] ) ? $report['attendance']['records'][ $id ] : array( 'label' => __( 'Not recorded', 'tutorhelper-pro' ) );
			$html .= '<tr><td>' . esc_html( self::booking_date( $booking ) ) . '</td><td>' . self::attendance_cell_html( $booking, $record ) . '</td></tr>';
		}
		return $html . '</tbody></table></section>';
	}

	/** Lesson information table. */
	private static function lessons_html( $report ) {
		$html = '<section><h2>' . esc_html__( 'Lesson information', 'tutorhelper-pro' ) . '</h2><table><thead><tr><th>' . esc_html__( 'Date and time', 'tutorhelper-pro' ) . '</th><th>' . esc_html__( 'Attendance', 'tutorhelper-pro' ) . '</th><th>' . esc_html__( 'Status', 'tutorhelper-pro' ) . '</th><th>' . esc_html__( 'Lesson', 'tutorhelper-pro' ) . '</th></tr></thead><tbody>';
		foreach ( $report['bookings'] as $booking ) {
			$id = absint( $booking->id );
			$attendance = isset( $report['attendance']['records'][ $id ] )
				? $report['attendance']['records'][ $id ]
				: array( 'label' => __( 'Not recorded', 'tutorhelper-pro' ) );
			$title = ! empty( $booking->booking_type_name ) ? $booking->booking_type_name : __( 'Lesson', 'tutorhelper-pro' );
			$html .= '<tr><td>' . esc_html( self::booking_date( $booking ) ) . '</td><td>' . self::attendance_cell_html( $booking, $attendance ) . '</td><td>' . esc_html( ucwords( str_replace( '_', ' ', $booking->status ) ) ) . '</td><td>' . esc_html( $title ) . '</td></tr>';
		}
		return $html . '</tbody></table></section>';
	}


	/**
	 * Render the attendance label and an optional cancellation reason.
	 *
	 * @param object $booking    Booking record.
	 * @param array  $attendance Attendance snapshot.
	 * @return string
	 */
	private static function attendance_cell_html( $booking, $attendance ) {
		$label = isset( $attendance['label'] )
			? sanitize_text_field( $attendance['label'] )
			: __( 'Not recorded', 'tutorhelper-pro' );
		$is_cancelled = TutorHelper_Booking_Records::STATUS_CANCELLED
			=== sanitize_key( isset( $booking->status ) ? $booking->status : '' );

		if ( ! $is_cancelled ) {
			return esc_html( $label );
		}

		$html = esc_html__( 'Cancelled', 'tutorhelper-pro' );
		$reason = isset( $booking->cancellation_reason )
			? sanitize_textarea_field( $booking->cancellation_reason )
			: '';

		if ( '' === $reason ) {
			return $html;
		}

		return $html
			. '<small class="tutorhelper-progress-reports__cancellation-reason">'
			. nl2br( esc_html( $reason ) )
			. '</small>';
	}

	/** Feedback entries. */
	private static function feedback_html( $report ) {
		$html = '<section><h2>' . esc_html__( 'Lesson feedback', 'tutorhelper-pro' ) . '</h2>';
		$found = false;
		foreach ( $report['bookings'] as $booking ) {
			$id = absint( $booking->id );
			if ( empty( $report['follow_ups'][ $id ]['feedback'] ) ) {
				continue;
			}
			$found = true;
			$html .= '<div class="entry"><h3>' . esc_html( self::booking_date( $booking ) ) . '</h3>' . wpautop( esc_html( $report['follow_ups'][ $id ]['feedback'] ) ) . '</div>';
		}
		return $html . ( $found ? '' : '<p>' . esc_html__( 'No lesson feedback was recorded in this period.', 'tutorhelper-pro' ) . '</p>' ) . '</section>';
	}

	/** Homework set, due date and completion state. */
	private static function homework_html( $report ) {
		$html = '<section><h2>' . esc_html__( 'Homework', 'tutorhelper-pro' ) . '</h2>';
		$found = false;
		foreach ( $report['bookings'] as $booking ) {
			$id = absint( $booking->id );
			$item = isset( $report['follow_ups'][ $id ] ) ? $report['follow_ups'][ $id ] : array();
			if ( empty( $item['homework_title'] ) && empty( $item['instructions'] ) && empty( $item['homework_url'] ) ) {
				continue;
			}
			$found = true;
			$html .= '<div class="entry"><h3>' . esc_html( $item['homework_title'] ? $item['homework_title'] : __( 'Homework', 'tutorhelper-pro' ) ) . '</h3><p><strong>' . esc_html__( 'Set:', 'tutorhelper-pro' ) . '</strong> ' . esc_html( self::booking_date( $booking ) ) . '<br><strong>' . esc_html__( 'Due:', 'tutorhelper-pro' ) . '</strong> ' . esc_html( $item['due_label'] ? $item['due_label'] : __( 'No due date', 'tutorhelper-pro' ) ) . '<br><strong>' . esc_html__( 'Status:', 'tutorhelper-pro' ) . '</strong> ' . esc_html( $item['homework_completed'] ? __( 'Completed', 'tutorhelper-pro' ) : __( 'Not completed', 'tutorhelper-pro' ) ) . '</p>';
			if ( ! empty( $item['instructions'] ) ) {
				$html .= wpautop( esc_html( $item['instructions'] ) );
			}
			if ( ! empty( $item['homework_url'] ) ) {
				$html .= '<p><a href="' . esc_url( $item['homework_url'] ) . '">' . esc_html__( 'Open homework link', 'tutorhelper-pro' ) . '</a></p>';
			}
			$html .= '</div>';
		}
		return $html . ( $found ? '' : '<p>' . esc_html__( 'No homework was recorded in this period.', 'tutorhelper-pro' ) . '</p>' ) . '</section>';
	}

	/** Group one student's bookings by the canonical Booking Type. */
	private static function group_by_lesson_type( $student_report ) {
		$groups = array();
		foreach ( $student_report['bookings'] as $booking ) {
			$type_id = absint( $booking->booking_type_id );
			if ( ! isset( $groups[ $type_id ] ) ) {
				$type = TutorHelper_Booking_Types::get_by_id( $type_id );
				$groups[ $type_id ] = array(
					'title' => $type && ! empty( $type->title ) ? sanitize_text_field( $type->title ) : __( 'Other lessons', 'tutorhelper-pro' ),
					'bookings' => array(),
				);
			}
			$groups[ $type_id ]['bookings'][] = $booking;
		}
		return $groups;
	}

	/** Return whether any requested AI summary failed for this preview. */
	private static function has_ai_summary_failures( $report ) {
		if ( empty( $report['include_ai_summary'] ) || empty( $report['students'] ) ) {
			return false;
		}
		foreach ( $report['students'] as $student_report ) {
			if ( ! empty( $student_report['feedback_summary_error'] ) ) {
				return true;
			}
		}
		return false;
	}

	/** Calculate attendance excluding information-only lessons. */
	private static function attendance_percentage( $student_report ) {
		$eligible = 0;
		$attended = 0;
		foreach ( $student_report['bookings'] as $booking ) {
			$record = isset( $student_report['attendance']['records'][ $booking->id ] )
				? $student_report['attendance']['records'][ $booking->id ]
				: array();
			$status = isset( $record['status'] ) ? sanitize_key( $record['status'] ) : 'not_recorded';
			if ( 'info_only' === $status ) {
				continue;
			}
			++$eligible;
			if ( in_array( $status, array( 'attended', 'late' ), true ) ) {
				++$attended;
			}
		}
		return $eligible ? (int) round( ( $attended / $eligible ) * 100 ) : 0;
	}

	/** Generate an optional summary using limited, explicitly disclosed context. */
	private static function generate_ai_feedback_summary( $student_report, $date_from, $date_to ) {
		$feedback = array();
		$homework = array();
		foreach ( $student_report['follow_ups'] as $follow_up ) {
			if ( ! empty( $follow_up['feedback'] ) ) {
				$plain = trim( wp_strip_all_tags( $follow_up['feedback'] ) );
				if ( $plain && ! in_array( $plain, $feedback, true ) ) {
					$feedback[] = $plain;
				}
			}
			$has_homework = ! empty( $follow_up['homework_title'] ) || ! empty( $follow_up['instructions'] );
			if ( $has_homework ) {
				$state = self::homework_state( $follow_up );
				$parts = array_filter(
					array(
						! empty( $follow_up['homework_title'] ) ? sanitize_text_field( $follow_up['homework_title'] ) : __( 'Homework', 'tutorhelper-pro' ),
						$state['label'],
						! empty( $follow_up['due_label'] ) ? sanitize_text_field( $follow_up['due_label'] ) : '',
						! empty( $follow_up['instructions'] ) ? trim( wp_strip_all_tags( $follow_up['instructions'] ) ) : '',
					)
				);
				$homework[] = implode( ' — ', $parts );
			}
		}
		if ( empty( $feedback ) || ! self::ai_is_ready() ) {
			return '';
		}

		$student = TutorHelper_Students::get_student( absint( $student_report['student_id'] ) );
		$first_name = $student instanceof WP_User && $student->first_name
			? sanitize_text_field( $student->first_name )
			: sanitize_text_field( strtok( $student_report['student_name'], ' ' ) );
		$attendance = self::attendance_percentage( $student_report );
		$input = implode(
			"\n",
			array(
				'Reporting period: ' . sanitize_text_field( $date_from ) . ' to ' . sanitize_text_field( $date_to ),
				'Student first name: ' . $first_name,
				'Attendance: ' . number_format_i18n( $attendance ) . '%',
				'',
				'Tutor feedback:',
				implode( "\n\n", $feedback ),
				'',
				'Homework shown in the detailed table:',
				! empty( $homework ) ? implode( "\n", array_values( array_unique( $homework ) ) ) : 'No homework recorded.',
			)
		);

		$key = trim( (string) get_option( self::OPENAI_KEY_OPTION, '' ) );
		$model = sanitize_key( (string) get_option( self::OPENAI_MODEL_OPTION, 'gpt-5-mini' ) );
		$request = wp_remote_post(
			'https://api.openai.com/v1/responses',
			array(
				'timeout' => 45,
				'headers' => array(
					'Authorization' => 'Bearer ' . $key,
					'Content-Type'  => 'application/json',
				),
				'body' => wp_json_encode(
					array(
						'model' => $model ?: 'gpt-5-mini',
						'store' => false,
						'max_output_tokens' => 900,
						'reasoning' => array( 'effort' => 'minimal' ),
						'instructions' => 'Write no more than two concise sentences in the first person, as though the tutor wrote them to the parent of the student. Match the tutor’s tone and level of formality from the supplied feedback without copying long phrases. Summarise what went well in the student’s lessons across all of the lessons in the report, and include encouraging ideas for improvement where appropriate; do not describe or imply that the context relates to a single lesson. This is a quick overview introducing the detailed feedback and homework table that follows, not a separate assessment. You may naturally use the supplied first name (avoid directing the summary to the student using "you", instead use the student first name), attendance percentage and completion status of homework where appropriate. Base every statement only on the supplied context. Do not invent attainment, progress, homework completion or recommendations. Do not add a greeting, heading, sign-off or mention AI.',
						'input' => $input,
					)
				),
			)
		);
		if ( is_wp_error( $request ) ) {
			self::log_ai_failure( $request, $student_report['student_id'], $date_from, $date_to );
			return $request;
		}

		$status = wp_remote_retrieve_response_code( $request );
		$data = json_decode( wp_remote_retrieve_body( $request ), true );
		if ( 200 > $status || 299 < $status || ! is_array( $data ) ) {
			$error = new WP_Error( 'openai_http_error', 'OpenAI request failed.', array( 'status' => absint( $status ) ) );
			self::log_ai_failure( $error, $student_report['student_id'], $date_from, $date_to );
			return $error;
		}

		$summary = '';
		foreach ( isset( $data['output'] ) && is_array( $data['output'] ) ? $data['output'] : array() as $item ) {
			if ( 'message' !== ( $item['type'] ?? '' ) || empty( $item['content'] ) || ! is_array( $item['content'] ) ) {
				continue;
			}
			foreach ( $item['content'] as $part ) {
				if ( 'output_text' === ( $part['type'] ?? '' ) && isset( $part['text'] ) && is_string( $part['text'] ) ) {
					$summary .= ' ' . $part['text'];
				}
			}
		}
		$summary = trim( sanitize_textarea_field( $summary ) );
		if ( '' === $summary ) {
			$response_status = isset( $data['status'] ) ? sanitize_key( $data['status'] ) : 'empty';
			$error = new WP_Error( 'openai_empty_response', 'OpenAI returned no summary text.', array( 'response_status' => $response_status ) );
			self::log_ai_failure( $error, $student_report['student_id'], $date_from, $date_to );
			return $error;
		}
		return wp_html_excerpt( $summary, 600, '…' );
	}

	/** Return the display state for one homework item. */
	private static function homework_state( $follow_up ) {
		$has_homework = ! empty( $follow_up['homework_title'] ) || ! empty( $follow_up['instructions'] );
		if ( ! $has_homework ) {
			return array( 'class' => 'none', 'label' => __( 'None set', 'tutorhelper-pro' ) );
		}
		if ( ! empty( $follow_up['homework_completed'] ) ) {
			return array( 'class' => 'completed', 'label' => __( 'Completed', 'tutorhelper-pro' ) );
		}
		$due_timestamp = ! empty( $follow_up['due_timestamp'] ) ? absint( $follow_up['due_timestamp'] ) : 0;
		if ( $due_timestamp && $due_timestamp > current_time( 'timestamp', true ) ) {
			return array( 'class' => 'not-due', 'label' => __( 'Not due', 'tutorhelper-pro' ) );
		}
		return array( 'class' => 'outstanding', 'label' => __( 'Outstanding', 'tutorhelper-pro' ) );
	}

	/** Render a summary and detailed lesson table for one Booking Type. */
	private static function lesson_type_html( $group, $student_report, $sections ) {
		$count = count( $group['bookings'] );
		$seconds = 0;
		$eligible = 0;
		$attended = 0;
		foreach ( $group['bookings'] as $booking ) {
			$start = strtotime( $booking->booking_start . ' UTC' );
			$end = strtotime( $booking->booking_end . ' UTC' );
			if ( $start && $end > $start ) {
				$seconds += $end - $start;
			}
			$record = isset( $student_report['attendance']['records'][ $booking->id ] ) ? $student_report['attendance']['records'][ $booking->id ] : array();
			$status = isset( $record['status'] ) ? $record['status'] : 'not_recorded';
			if ( 'info_only' !== $status ) {
				++$eligible;
				$attended += in_array( $status, array( 'attended', 'late' ), true ) ? 1 : 0;
			}
		}
		$percentage = $eligible ? round( ( $attended / $eligible ) * 100 ) : 0;
		$html = '<section class="lesson-type"><h3>' . esc_html( $group['title'] ) . '</h3><div class="lesson-type__metrics">';
		$html .= '<div><strong>' . esc_html( number_format_i18n( $count ) ) . '</strong><span>' . esc_html__( 'Lessons booked', 'tutorhelper-pro' ) . '</span></div>';
		$html .= '<div><strong>' . esc_html( number_format_i18n( $seconds / HOUR_IN_SECONDS, 1 ) ) . '</strong><span>' . esc_html__( 'Hours booked', 'tutorhelper-pro' ) . '</span></div>';
		$html .= '<div><strong>' . esc_html( number_format_i18n( $percentage ) ) . '%</strong><span>' . esc_html__( 'Attendance', 'tutorhelper-pro' ) . '</span></div></div>';
		$html .= '<table><thead><tr><th>' . esc_html__( 'Lesson date', 'tutorhelper-pro' ) . '</th><th>' . esc_html__( 'Attendance', 'tutorhelper-pro' ) . '</th>';
		if ( in_array( 'feedback', $sections, true ) ) {
			$html .= '<th>' . esc_html__( 'Tutor feedback', 'tutorhelper-pro' ) . '</th>';
		}
		if ( in_array( 'homework', $sections, true ) ) {
			$html .= '<th>' . esc_html__( 'Homework', 'tutorhelper-pro' ) . '</th>';
		}
		$html .= '</tr></thead><tbody>';
		foreach ( $group['bookings'] as $booking ) {
			$id = absint( $booking->id );
			$attendance = isset( $student_report['attendance']['records'][ $id ] )
				? $student_report['attendance']['records'][ $id ]
				: array( 'label' => __( 'Not recorded', 'tutorhelper-pro' ) );
			$follow_up = isset( $student_report['follow_ups'][ $id ] ) ? $student_report['follow_ups'][ $id ] : array();
			$html .= '<tr><td>' . esc_html( self::booking_date( $booking ) ) . '</td><td>' . self::attendance_cell_html( $booking, $attendance ) . '</td>';
			if ( in_array( 'feedback', $sections, true ) ) {
				$html .= '<td>' . ( ! empty( $follow_up['feedback'] ) ? wpautop( esc_html( $follow_up['feedback'] ) ) : '—' ) . '</td>';
			}
			if ( in_array( 'homework', $sections, true ) ) {
				$has_homework = ! empty( $follow_up['homework_title'] ) || ! empty( $follow_up['instructions'] );
				$homework_state = self::homework_state( $follow_up );
				$html .= '<td><span class="homework-status homework-status--' . esc_attr( $homework_state['class'] ) . '">' . esc_html( $homework_state['label'] ) . '</span>';
				if ( $has_homework ) {
					$html .= '<strong>' . esc_html( $follow_up['homework_title'] ) . '</strong>' . wpautop( esc_html( $follow_up['instructions'] ) );
					if ( ! empty( $follow_up['due_label'] ) ) {
						$html .= '<small>' . esc_html__( 'Due:', 'tutorhelper-pro' ) . ' ' . esc_html( $follow_up['due_label'] ) . '</small>';
					}
				}
				$html .= '</td>';
			}
			$html .= '</tr>';
		}
		return $html . '</tbody></table></section>';
	}

	/** Convert the saved email banner to an embeddable local data URI. */
	private static function branding_image_data_uri( $key ) {
		$attachment_id = absint( TutorHelper_Pro_Branding::get( $key ) );
		return self::attachment_data_uri( $attachment_id );
	}

	/** Convert a local media attachment into a Dompdf-safe data URI. */
	private static function attachment_data_uri( $attachment_id ) {
		$attachment_id = absint( $attachment_id );
		$path = $attachment_id ? get_attached_file( $attachment_id ) : '';
		if ( ! $path || ! file_exists( $path ) ) {
			return '';
		}
		global $wp_filesystem;
		require_once ABSPATH . 'wp-admin/includes/file.php';
		if ( ! WP_Filesystem() || ! $wp_filesystem ) {
			return '';
		}
		$contents = $wp_filesystem->get_contents( $path );
		$mime = get_post_mime_type( $attachment_id );
		return $contents && $mime ? 'data:' . sanitize_mime_type( $mime ) . ';base64,' . base64_encode( $contents ) : '';
	}

	/** Embed local Media Library images while leaving remote fetching disabled. */
	private static function embed_local_content_images( $content ) {
		$content = wp_kses_post( $content );
		return preg_replace_callback(
			'/<img\b[^>]*>/i',
			static function ( $matches ) {
				$tag = $matches[0];
				$attachment_id = preg_match( '/\bwp-image-(\d+)\b/i', $tag, $id_match ) ? absint( $id_match[1] ) : 0;
				if ( ! preg_match( '/\bsrc=(["\'])([^"\']+)\1/i', $tag, $src_match ) ) {
					return $tag;
				}
				if ( ! $attachment_id ) {
					$attachment_id = attachment_url_to_postid( $src_match[2] );
				}
				$data_uri = $attachment_id ? self::attachment_data_uri( $attachment_id ) : '';
				return $data_uri
					? str_replace( $src_match[0], 'src=' . $src_match[1] . esc_attr( $data_uri ) . $src_match[1], $tag )
					: $tag;
			},
			$content
		);
	}

	/** Generate a PDF string using Core's bundled Dompdf. */
	private static function generate_pdf( $report ) {
		$autoload = defined( 'TUTORHELPER_BOOKINGS_PATH' ) ? TUTORHELPER_BOOKINGS_PATH . 'vendor/dompdf/autoload.inc.php' : '';
		if ( ! class_exists( '\\Dompdf\\Dompdf' ) && $autoload && file_exists( $autoload ) ) {
			require_once $autoload;
		}
		if ( ! class_exists( '\\Dompdf\\Dompdf' ) ) {
			return new WP_Error( 'dompdf_missing', __( 'The PDF library is unavailable.', 'tutorhelper-pro' ) );
		}
		try {
			$options = new \Dompdf\Options();
			$options->set( 'isRemoteEnabled', false );
			$dompdf = new \Dompdf\Dompdf( $options );
			$dompdf->setPaper( 'A4', 'portrait' );
			$dompdf->loadHtml( self::pdf_document( self::build_report_html( $report ), $report['branding'] ) );
			$dompdf->render();
			$business_name = ! empty( $report['branding']['business_name'] ) ? sanitize_text_field( $report['branding']['business_name'] ) : get_bloginfo( 'name' );
			$font = $dompdf->getFontMetrics()->get_font( 'DejaVu Sans', 'normal' );
			$dompdf->getCanvas()->page_text(
				36,
				806,
				$business_name . '  ·  ' . __( 'Page {PAGE_NUM} of {PAGE_COUNT}', 'tutorhelper-pro' ),
				$font,
				8,
				array( 0.25, 0.25, 0.25 )
			);
			return $dompdf->output();
		} catch ( Throwable $error ) {
			return new WP_Error( 'pdf_generation_failed', $error->getMessage() );
		}
	}

	/** Complete PDF document and print-safe styling. */
	private static function pdf_document( $body, $branding ) {
		$primary = sanitize_hex_color( $branding['primary_color'] ) ?: '#143f4d';
		$accent = sanitize_hex_color( $branding['accent_color'] ) ?: '#f46b3b';
		$text = sanitize_hex_color( $branding['text_color'] ) ?: '#1d2327';
		$heading = sanitize_hex_color( $branding['heading_color'] ) ?: $primary;
		return '<!doctype html><html><head><meta charset="utf-8"><style>@page{margin:16mm 14mm 22mm}body{font-family:DejaVu Sans,sans-serif;color:' . esc_attr( $text ) . ';font-size:9.5pt}.report-header{margin:-16mm -14mm 18px;background:' . esc_attr( $primary ) . ';color:#fff}.report-header img{display:block;width:100%;height:auto}.report-header__brand{padding:24px 30px;font-size:20pt;font-weight:bold}.report-header__title{padding:14px 30px;border-top:4px solid ' . esc_attr( $accent ) . '}.report-header h1{margin:0;color:#fff;font-size:22pt}.report-header p{margin:4px 0 0}.page-break{page-break-before:always}.report-meta{page-break-inside:avoid}h2,h3{color:' . esc_attr( $heading ) . '}h2{font-size:16pt;border-bottom:2px solid ' . esc_attr( $accent ) . ';padding-bottom:5px}h3{font-size:12pt}.report-introduction,.overview,.additional-note{padding:12px;background:#f5f7f8;border-left:5px solid ' . esc_attr( $accent ) . ';page-break-inside:avoid}.report-introduction{margin-bottom:14px}.lesson-type{margin-top:20px}.lesson-type__metrics{display:table;width:100%;margin:8px 0 12px}.lesson-type__metrics div{display:table-cell;width:33%;padding:10px;background:#f5f7f8;border-right:4px solid #fff}.lesson-type__metrics strong,.lesson-type__metrics span{display:block}.lesson-type__metrics strong{font-size:16pt;color:' . esc_attr( $primary ) . '}table{width:100%;border-collapse:collapse;margin:8px 0 16px}thead{display:table-header-group}tr{page-break-inside:avoid}th{background:' . esc_attr( $primary ) . ';color:#fff;text-align:left}th,td{padding:7px;border:1px solid #c8d6dc;vertical-align:top}tr:nth-child(even) td{background:#f7f2e9}.homework-status{display:inline-block;margin:0 0 5px;padding:3px 7px;border-radius:10px;font-weight:bold}.homework-status--completed{background:#d9f2df;color:#17672b}.homework-status--outstanding{background:#ffe0d4;color:#9b2f0a}.homework-status--none{background:#e7ecef;color:#52636b}.empty{padding:12px;background:#fff3df}.additional-note{margin-top:24px}</style></head><body>' . $body . '</body></html>';
	}

	/** Resolve only the selected student and currently linked parents. */
	private static function resolve_recipients( $report ) {
		$emails = array();
		foreach ( $report['student_ids'] as $student_id ) {
			$student = TutorHelper_Students::get_student( $student_id );
			if ( ! $student instanceof WP_User ) {
				return new WP_Error( 'recipient_invalid' );
			}
			if ( ! empty( $report['send_student'] ) && is_email( $student->user_email ) ) {
				$emails[] = sanitize_email( $student->user_email );
			}
			if ( ! empty( $report['send_parents'] ) && class_exists( 'TutorHelper_Student_Parent_Links' ) ) {
				foreach ( TutorHelper_Student_Parent_Links::get_parents( $student->ID ) as $parent ) {
					if ( is_email( $parent->user_email ) ) {
						$emails[] = sanitize_email( $parent->user_email );
					}
				}
			}
		}
		$emails = array_values( array_unique( apply_filters( 'tutorhelper_pro_progress_report_recipients', $emails, $report ) ) );
		return empty( $emails ) ? new WP_Error( 'recipient_missing' ) : $emails;
	}

	/** Require capability, nonce, matching owner and a live preview. */
	private static function require_preview( $action ) {
		$token = isset( $_POST['report_token'] ) && ! is_array( $_POST['report_token'] ) ? sanitize_key( wp_unslash( $_POST['report_token'] ) ) : '';
		self::guard( $action . '_' . $token );
		$report = self::get_preview( $token );
		if ( ! is_array( $report ) || get_current_user_id() !== absint( $report['owner_id'] ) ) {
			self::redirect_status( 'preview_expired' );
		}
		return $report;
	}

	/** Standard mutating request boundary. */
	private static function guard( $nonce_action ) {
		if ( 'POST' !== strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
			wp_die( esc_html__( 'Invalid request method.', 'tutorhelper-pro' ) );
		}
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to create student reports.', 'tutorhelper-pro' ) );
		}
		check_admin_referer( $nonce_action );
	}

	/** Safe request helpers. */
	private static function post_id( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? absint( $_POST[ $key ] ) : 0;
	}

	private static function post_ids( $key ) {
		$values = isset( $_POST[ $key ] ) && is_array( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : array();
		return array_values( array_unique( array_filter( array_map( 'absint', $values ) ) ) );
	}

	private static function post_rich_text( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] )
			? wp_kses_post( wp_unslash( $_POST[ $key ] ) )
			: '';
	}

	/** Full but controlled editor used for report introduction and notes. */
	private static function editor_settings( $textarea_name ) {
		return array(
			'textarea_name' => $textarea_name,
			'media_buttons' => true,
			'teeny'         => false,
			'textarea_rows' => 7,
			'tinymce'       => array(
				'toolbar1' => 'formatselect,fontselect,fontsizeselect,bold,italic,underline,forecolor,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,undo,redo',
				'toolbar2' => 'pastetext,removeformat,charmap,outdent,indent',
			),
		);
	}

	/** Editable starting text rather than a hard-coded message. */
	private static function default_introduction() {
		$default = __( 'This tuition report summarises the lessons, attendance, tutor feedback and homework recorded during the selected period.', 'tutorhelper-pro' );
		return apply_filters( 'tutorhelper_pro_progress_report_default_introduction', $default );
	}

	/** Record the selected human-readable recipients in the report itself. */
	private static function recipient_display( $students, $send_student, $send_parents, $cc_tutor ) {
		$labels = array();
		foreach ( $students as $student ) {
			if ( $send_student && is_email( $student->user_email ) ) {
				$labels[] = sprintf(
					/* translators: %s: Student name. */
					__( 'Student: %s', 'tutorhelper-pro' ),
					$student->display_name
				);
			}
			if ( $send_parents && class_exists( 'TutorHelper_Student_Parent_Links' ) ) {
				foreach ( TutorHelper_Student_Parent_Links::get_parents( $student->ID ) as $parent ) {
					if ( is_email( $parent->user_email ) ) {
						$labels[] = sprintf(
							/* translators: %s: Parent or guardian name. */
							__( 'Parent/Guardian: %s', 'tutorhelper-pro' ),
							$parent->display_name
						);
					}
				}
			}
		}
		if ( $cc_tutor ) {
			$tutor = wp_get_current_user();
			if ( is_email( $tutor->user_email ) ) {
				$labels[] = sprintf(
					/* translators: %s: Tutor name. */
					__( 'Tutor CC: %s', 'tutorhelper-pro' ),
					$tutor->display_name
				);
			}
		}
		return array_values( array_unique( array_map( 'sanitize_text_field', $labels ) ) );
	}

	private static function post_date( $key ) {
		$value = isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) && wp_checkdate( (int) substr( $value, 5, 2 ), (int) substr( $value, 8, 2 ), (int) substr( $value, 0, 4 ), $value ) ? $value : '';
	}

	private static function post_sections() {
		$raw = isset( $_POST['sections'] ) && is_array( $_POST['sections'] ) ? wp_unslash( $_POST['sections'] ) : array();
		return array_values( array_intersect( array_keys( self::section_labels() ), array_map( 'sanitize_key', $raw ) ) );
	}

	private static function section_labels() {
		return array(
			'attendance' => __( 'Attendance summary and detail', 'tutorhelper-pro' ),
			'feedback' => __( 'Lesson feedback', 'tutorhelper-pro' ),
			'homework' => __( 'Homework and completion', 'tutorhelper-pro' ),
			'lesson_info' => __( 'Relevant lesson information', 'tutorhelper-pro' ),
		);
	}

	/** Preview storage is user-bound and short-lived. */
	private static function transient_key( $token ) {
		return 'th_pro_report_' . get_current_user_id() . '_' . sanitize_key( $token );
	}

	private static function get_preview( $token ) {
		return get_transient( self::transient_key( $token ) );
	}

	private static function read_query_token() {
		return isset( $_GET['progress_preview'] ) && ! is_array( $_GET['progress_preview'] ) ? sanitize_key( wp_unslash( $_GET['progress_preview'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only preview identifier; protected actions have nonces.
	}

	private static function dashboard_url( $args = array() ) {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . TutorHelper_Admin::MENU_SLUG ) ) . '#student-progress-reports';
	}

	/** Return the configured authenticated dashboard shared by students and parents. */
	private static function report_dashboard_url() {
		$url = class_exists( 'TutorHelper_Settings' ) ? TutorHelper_Settings::get_student_dashboard_url() : '';
		return $url ? esc_url_raw( $url ) : esc_url_raw( home_url( '/' ) );
	}

	private static function redirect_status( $status ) {
		wp_safe_redirect( self::dashboard_url( array( 'progress_report' => sanitize_key( $status ) ) ) );
		exit;
	}

	/** User-facing result notices. */
	private static function render_notice() {
		$status = isset( $_GET['progress_report'] ) && ! is_array( $_GET['progress_report'] ) ? sanitize_key( wp_unslash( $_GET['progress_report'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status notice.
		$messages = array(
			'invalid' => __( 'Select a valid student and date range.', 'tutorhelper-pro' ),
			'reversed' => __( 'The end date must be on or after the start date.', 'tutorhelper-pro' ),
			'sections' => __( 'Select at least one report section.', 'tutorhelper-pro' ),
			'recipient_missing' => __( 'No selected recipient has a valid email address.', 'tutorhelper-pro' ),
			'recipient_invalid' => __( 'The student account is no longer available.', 'tutorhelper-pro' ),
			'preview_expired' => __( 'That report preview has expired. Build a new preview.', 'tutorhelper-pro' ),
			'preview_failed' => __( 'The report preview could not be created. Details were added to Diagnostics; please try again.', 'tutorhelper-pro' ),
			'pdf_failed' => __( 'The PDF could not be generated. Details were added to Diagnostics.', 'tutorhelper-pro' ),
			'send_failed' => __( 'At least one report email could not be delivered. Details were added to Diagnostics.', 'tutorhelper-pro' ),
			'sent' => __( 'The tuition report was sent and saved successfully.', 'tutorhelper-pro' ),
			'ai_saved' => __( 'OpenAI feedback-summary settings saved.', 'tutorhelper-pro' ),
		);
		if ( isset( $messages[ $status ] ) ) {
			$type = in_array( $status, array( 'sent', 'ai_saved' ), true ) ? 'success' : 'error';
			echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( $messages[ $status ] ) . '</p></div>';
		}
	}

	private static function booking_date( $booking ) {
		$timestamp = ! empty( $booking->booking_start ) ? strtotime( $booking->booking_start . ' UTC' ) : false;
		return $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp, wp_timezone() ) : '';
	}

	private static function period_label( $report ) {
		$from = DateTimeImmutable::createFromFormat( 'Y-m-d', $report['date_from'], wp_timezone() );
		$to = DateTimeImmutable::createFromFormat( 'Y-m-d', $report['date_to'], wp_timezone() );
		return $from && $to ? wp_date( get_option( 'date_format' ), $from->getTimestamp() ) . ' – ' . wp_date( get_option( 'date_format' ), $to->getTimestamp() ) : '';
	}

	private static function created_date_label( $report ) {
		$created_at = isset( $report['created_at'] ) ? $report['created_at'] : '';
		$timestamp = is_numeric( $created_at ) ? absint( $created_at ) : strtotime( $created_at . ' UTC' );
		return $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp, wp_timezone() ) : '';
	}

	private static function summary_text( $report ) {
		$count = 0;
		foreach ( $report['students'] as $student_report ) {
			$count += count( $student_report['bookings'] );
		}
		/* translators: %s: Number of lessons in the published report. */
		return sprintf( _n( 'The report contains %s lesson.', 'The report contains %s lessons.', $count, 'tutorhelper-pro' ), number_format_i18n( $count ) );
	}

	private static function filename( $report ) {
		return 'tutorhelper-tuition-report-' . sanitize_title( $report['student_name'] ) . '-' . $report['date_to'] . '.pdf';
	}

	/** Log an unexpected preview failure without report content or API credentials. */
	private static function log_preview_failure( $error, $student_ids, $date_from, $date_to ) {
		if ( ! class_exists( 'TutorHelper_Logger' ) || ! method_exists( 'TutorHelper_Logger', 'error' ) ) {
			return;
		}
		$is_wp_error = $error instanceof WP_Error;
		TutorHelper_Logger::error(
			'Student tuition report preview generation failed.',
			array(
				'student_user_ids' => array_values( array_filter( array_map( 'absint', (array) $student_ids ) ) ),
				'date_from'        => sanitize_text_field( $date_from ),
				'date_to'          => sanitize_text_field( $date_to ),
				'error_code'       => $is_wp_error ? sanitize_key( $error->get_error_code() ) : 'unexpected_preview_error',
				'error_type'       => $is_wp_error ? 'WP_Error' : sanitize_text_field( get_class( $error ) ),
				'error_message'    => sanitize_text_field( $is_wp_error ? $error->get_error_message() : $error->getMessage() ),
				'error_file'       => $is_wp_error ? '' : sanitize_file_name( basename( $error->getFile() ) ),
				'error_line'       => $is_wp_error ? 0 : absint( $error->getLine() ),
			)
		);
	}

	/** Log only safe identifiers and error codes. */
	private static function log_failure( $message, $error, $report ) {
		if ( class_exists( 'TutorHelper_Logger' ) && method_exists( 'TutorHelper_Logger', 'error' ) ) {
			TutorHelper_Logger::error(
				$message,
				array(
					'student_user_ids' => array_map( 'absint', $report['student_ids'] ),
					'date_from' => sanitize_text_field( $report['date_from'] ),
					'date_to' => sanitize_text_field( $report['date_to'] ),
					'error_code' => $error instanceof WP_Error ? sanitize_key( $error->get_error_code() ) : 'unknown',
				)
			);
		}
	}

	/** Log an AI failure without feedback, API keys, names or contact details. */
	private static function log_ai_failure( $error, $student_id, $date_from, $date_to ) {
		if ( class_exists( 'TutorHelper_Logger' ) && method_exists( 'TutorHelper_Logger', 'error' ) ) {
			TutorHelper_Logger::error(
				'OpenAI tuition report summary generation failed.',
				array(
					'student_user_id' => absint( $student_id ),
					'date_from' => sanitize_text_field( $date_from ),
					'date_to' => sanitize_text_field( $date_to ),
					'error_code' => $error instanceof WP_Error ? sanitize_key( $error->get_error_code() ) : 'unknown',
				)
			);
		}
	}
}
