<?php
/**
 * TutorHelper Pro online lesson settings service.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and retrieves shared online lesson settings.
 */
final class TutorHelper_Pro_Online_Lessons {

	/**
	 * Option storing the tutor's persistent Zoom meeting URL.
	 *
	 * @var string
	 */
	const ZOOM_URL_OPTION =
		'tutorhelper_pro_zoom_url';


	/** Register online-lesson integrations. */
	public static function init() {
		add_filter(
			'tutorhelper_booking_email_context',
			array( __CLASS__, 'filter_booking_email_context' ),
			20,
			2
		);
	}

	/**
	 * Add an individual or shared Group Session joining URL to booking emails.
	 *
	 * @param array $context Booking email context.
	 * @param int   $booking_id Booking ID.
	 * @return array
	 */
	public static function filter_booking_email_context( $context, $booking_id ) {
		if ( ! is_array( $context ) || empty( $context['placeholders'] ) ) {
			return $context;
		}

		$context['placeholders']['{lesson_link}'] = '';
		$booking = isset( $context['booking'] ) ? $context['booking'] : null;
		if ( ! $booking || 'online' !== sanitize_key( $booking->location_type ) ) {
			return $context;
		}

		$meeting = self::get_booking_meeting( $booking_id );
		if ( empty( $meeting['url'] ) ) {
			$meeting = self::get_group_booking_meeting( $booking_id );
		}

		$meeting_url = ! empty( $meeting['url'] )
			? esc_url_raw( $meeting['url'], array( 'http', 'https' ) )
			: '';
		if ( '' === $meeting_url ) {
			return $context;
		}

		$context['placeholders']['{lesson_link}'] = $meeting_url;
		$joining_details = isset( $context['placeholders']['{joining_details}'] )
			? trim( sanitize_textarea_field( $context['placeholders']['{joining_details}'] ) )
			: '';

		if ( false === strpos( $joining_details, $meeting_url ) ) {
			$label = ! empty( $meeting['label'] )
				? sanitize_text_field( $meeting['label'] )
				: __( 'Join your online lesson', 'tutorhelper-pro' );
			$link_details = sprintf(
				/* translators: 1: online meeting label, 2: meeting URL. */
				__( '%1$s: %2$s', 'tutorhelper-pro' ),
				$label,
				$meeting_url
			);
			$joining_details = '' === $joining_details
				? $link_details
				: $joining_details . "\n\n" . $link_details;
		}

		$context['placeholders']['{joining_details}'] = $joining_details;
		return $context;
	}

	/** Resolve the shared Group Session meeting for one child booking. */
	private static function get_group_booking_meeting( $booking_id ) {
		if (
			! class_exists( 'TutorHelper_Group_Enrolment_Bookings' )
			|| ! class_exists( 'TutorHelper_Group_Sessions' )
			|| ! method_exists( 'TutorHelper_Group_Enrolment_Bookings', 'get_table_name' )
		) {
			return array( 'url' => '', 'label' => '', 'provider' => '' );
		}

		global $wpdb;
		$session_id = absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Email delivery requires the current Group Session relationship.
				$wpdb->prepare(
					'SELECT session_id FROM %i WHERE booking_id = %d LIMIT 1',
					TutorHelper_Group_Enrolment_Bookings::get_table_name(),
					absint( $booking_id )
				)
			)
		);
		$session = $session_id ? TutorHelper_Group_Sessions::get_by_id( $session_id ) : null;
		$url = $session && ! empty( $session->meeting_url )
			? esc_url_raw( $session->meeting_url, array( 'http', 'https' ) )
			: '';

		return array(
			'url'      => $url,
			'label'    => $url ? __( 'Join Group Lesson', 'tutorhelper-pro' ) : '',
			'provider' => $url ? 'group_session' : '',
		);
	}


	/**
	 * Return the configured Zoom meeting URL.
	 *
	 * @return string
	 */
	public static function get_zoom_url() {

		$url = get_option(
			self::ZOOM_URL_OPTION,
			''
		);

		if ( ! is_string( $url ) ) {
			return '';
		}

		return esc_url_raw(
			$url
		);
	}


	/**
	 * Resolve the meeting URL and label for a Core booking.
	 *
	 * Google Meet links belong to the individual synchronized booking. A
	 * configured Zoom room remains the fallback when Zoom is the selected
	 * meeting provider.
	 *
	 * @param int $booking_id Core booking ID.
	 *
	 * @return array{url:string,label:string,provider:string}
	 */
	public static function get_booking_meeting(
		$booking_id
	) {

		$booking_id = absint(
			$booking_id
		);

		$meeting_url = '';
		$provider    = '';

		if (
			$booking_id
			&& class_exists(
				'TutorHelper_Pro_Calendar_Sync'
			)
		) {
			$meeting_url =
				TutorHelper_Pro_Calendar_Sync::
					get_meeting_url(
						$booking_id
					);

			$provider =
				TutorHelper_Pro_Calendar_Sync::
					get_meeting_provider(
						$booking_id
					);
		}

		if (
			'' === $meeting_url
			&& class_exists(
				'TutorHelper_Pro_Google_Calendar'
			)
		) {
			$current_provider =
				TutorHelper_Pro_Google_Calendar::
					get_meeting_provider();

			if (
				TutorHelper_Pro_Google_Calendar::PROVIDER_ZOOM
				=== $current_provider
			) {
				$meeting_url = self::get_zoom_url();
				$provider =
					TutorHelper_Pro_Google_Calendar::
						PROVIDER_ZOOM;
			}
		}

		$meeting_url = esc_url_raw(
			$meeting_url,
			array(
				'http',
				'https',
			)
		);

		if ( '' === $meeting_url ) {
			return array(
				'url'      => '',
				'label'    => '',
				'provider' => '',
			);
		}

		$is_google_meet =
			class_exists(
				'TutorHelper_Pro_Google_Calendar'
			)
			&& TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET
			=== $provider;

		return array(
			'url'      => $meeting_url,
			'label'    => $is_google_meet
				? __( 'Join Google Meet', 'tutorhelper-pro' )
				: __( 'Join Zoom Meeting', 'tutorhelper-pro' ),
			'provider' => sanitize_key( $provider ),
		);
	}


	/**
	 * Store the Zoom meeting URL.
	 *
	 * An empty URL clears the setting.
	 *
	 * @param string $url Zoom meeting URL.
	 *
	 * @return bool
	 */
	public static function set_zoom_url(
		$url
	) {

		$url = esc_url_raw(
			(string) $url,
			array(
				'http',
				'https',
			)
		);

		if ( '' === $url ) {
			return delete_option(
				self::ZOOM_URL_OPTION
			);
		}

		return update_option(
			self::ZOOM_URL_OPTION,
			$url,
			false
		);
	}
}
