<?php
/**
 * TutorHelper Pro online lesson student dashboard integration.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds online lesson actions to the student dashboard.
 */
final class TutorHelper_Pro_Online_Lessons_Dashboard {

	/**
	 * Register dashboard hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'tutorhelper_student_dashboard_booking_actions',
			array( __CLASS__, 'render_booking_action' ),
			10,
			2
		);
	}

	/**
	 * Render the synchronized meeting action for an eligible lesson.
	 *
	 * @param array  $booking      Prepared dashboard booking.
	 * @param string $section_type Dashboard section key.
	 * @return void
	 */
	public static function render_booking_action( $booking, $section_type ) {
		if ( 'confirmed' !== sanitize_key( $section_type ) ) {
			return;
		}

		if (
			empty( $booking['status'] )
			|| TutorHelper_Booking_Records::STATUS_CONFIRMED !== sanitize_key( $booking['status'] )
			|| empty( $booking['location_type'] )
			|| 'online' !== sanitize_key( $booking['location_type'] )
			|| empty( $booking['end'] )
			|| ! $booking['end'] instanceof DateTimeInterface
		) {
			return;
		}

		$now_utc = new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		$end_utc = $booking['end']->setTimezone( new DateTimeZone( 'UTC' ) );

		if ( $end_utc <= $now_utc ) {
			return;
		}

		$booking_id = ! empty( $booking['id'] ) ? absint( $booking['id'] ) : 0;
		$meeting = TutorHelper_Pro_Online_Lessons::get_booking_meeting(
			$booking_id
		);
		if ( empty( $meeting['url'] ) ) {
			return;
		}
		?>
		<a
			class="tutorhelper-student-dashboard__action-link tutorhelper-pro-online-meeting-link"
			href="<?php echo esc_url( $meeting['url'] ); ?>"
			target="_blank"
			rel="noopener noreferrer"
		>
			<?php echo esc_html( $meeting['label'] ); ?>
		</a>
		<?php
	}

	/**
	 * Resolve a synchronized meeting URL and provider label for a Core booking.
	 *
	 * @param int $booking_id Core booking ID.
	 * @return array
	 */
	public static function get_booking_meeting( $booking_id ) {
		return TutorHelper_Pro_Online_Lessons::get_booking_meeting(
			$booking_id
		);
	}

}
