<?php
/**
 * TutorHelper Pro booking-to-calendar synchronization.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates, updates and removes Google Calendar events for TutorHelper bookings.
 */
final class TutorHelper_Pro_Calendar_Sync {

	const SCHEMA_OPTION = 'tutorhelper_pro_calendar_sync_schema';
	const SCHEMA_VERSION = '1.0.0';

	/**
	 * Register synchronization hooks.
	 *
	 * @return void
	 */
	public static function init() {
		self::ensure_table();

		add_action( 'tutorhelper_booking_created', array( __CLASS__, 'handle_booking_created' ), 5, 1 );
		add_action( 'tutorhelper_booking_updated', array( __CLASS__, 'handle_booking_updated' ), 5, 3 );
		add_action( 'tutorhelper_booking_schedule_updated', array( __CLASS__, 'handle_schedule_updated' ), 5, 3 );
		add_action( 'tutorhelper_booking_cancelled', array( __CLASS__, 'handle_booking_cancelled' ), 5, 1 );
	}

	/**
	 * Return module table name.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'tutorhelper_pro_calendar_events';
	}

	/**
	 * Ensure module storage exists.
	 *
	 * @return void
	 */
	private static function ensure_table() {
		if ( self::SCHEMA_VERSION === get_option( self::SCHEMA_OPTION, '' ) ) {
			return;
		}

		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			booking_id bigint(20) unsigned NOT NULL,
			calendar_id varchar(255) NOT NULL DEFAULT 'primary',
			google_event_id varchar(255) NOT NULL DEFAULT '',
			meeting_provider varchar(30) NOT NULL DEFAULT 'none',
			meeting_url text NULL,
			calendar_event_url text NULL,
			sync_status varchar(30) NOT NULL DEFAULT 'pending',
			last_error text NULL,
			last_synced_at datetime DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (booking_id),
			KEY google_event_id (google_event_id),
			KEY sync_status (sync_status)
		) {$charset_collate};";

		dbDelta( $sql );
		update_option( self::SCHEMA_OPTION, self::SCHEMA_VERSION, false );
	}

	/**
	 * Sync newly-created confirmed bookings without allowing Calendar to
	 * interrupt the booking request.
	 *
	 * @param int $booking_id Booking ID.
	 * @return void
	 */
	public static function handle_booking_created( $booking_id ) {
		$booking = TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) );
		if ( $booking && TutorHelper_Booking_Records::STATUS_CONFIRMED === sanitize_key( $booking->status ) ) {
			self::safe_sync_booking( $booking, 'booking_created' );
		}
	}

	/**
	 * Synchronize status changes without interrupting the parent request.
	 *
	 * @param int         $booking_id Booking ID.
	 * @param object|null $updated Updated booking.
	 * @param object|null $previous Previous booking.
	 * @return void
	 */
	public static function handle_booking_updated( $booking_id, $updated = null, $previous = null ) {
		unset( $previous );
		$booking = is_object( $updated ) ? $updated : TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) );
		if ( ! $booking ) {
			return;
		}

		if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
			self::safe_delete_event( absint( $booking_id ), 'booking_updated_cancelled' );
			return;
		}

		if ( TutorHelper_Booking_Records::STATUS_CONFIRMED === sanitize_key( $booking->status ) ) {
			self::safe_sync_booking( $booking, 'booking_updated_confirmed' );
		}
	}

	/**
	 * Synchronize rescheduled bookings safely.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param object $before Previous booking.
	 * @param object $updated Updated booking.
	 * @return void
	 */
	public static function handle_schedule_updated( $booking_id, $before, $updated ) {
		unset( $before );
		if ( is_object( $updated ) && TutorHelper_Booking_Records::STATUS_CONFIRMED === sanitize_key( $updated->status ) ) {
			self::safe_sync_booking( $updated, 'booking_rescheduled' );
		} else {
			self::handle_booking_updated( $booking_id, $updated, null );
		}
	}

	/**
	 * Remove a cancelled booking event safely.
	 *
	 * @param int $booking_id Booking ID.
	 * @return void
	 */
	public static function handle_booking_cancelled( $booking_id ) {
		self::safe_delete_event( absint( $booking_id ), 'booking_cancelled' );
	}

	/**
	 * Reconcile future confirmed bookings after Calendar is first connected
	 * or when the tutor explicitly requests a sync.
	 *
	 * No single Google or PHP failure is allowed to stop the reconciliation.
	 *
	 * @return array Summary counts.
	 */
	public static function sync_upcoming_confirmed() {
		$result = array(
			'synced' => 0,
			'failed' => 0,
		);

		try {
			$bookings = TutorHelper_Booking_Records::get_all(
				array(
					'status' => TutorHelper_Booking_Records::STATUS_CONFIRMED,
					'date_from' => current_time( 'mysql', true ),
					'limit' => 1000,
				)
			);
		} catch ( Throwable $error ) {
			self::log_throwable(
				'Google Calendar reconciliation could not load confirmed bookings.',
				$error,
				array( 'operation' => 'reconcile_query' )
			);
			$result['failed']++;
			return $result;
		}

		foreach ( $bookings as $booking ) {
			$sync = self::safe_sync_booking( $booking, 'reconcile_confirmed' );
			if ( is_wp_error( $sync ) ) {
				$result['failed']++;
			} else {
				$result['synced']++;
			}
		}

		TutorHelper_Logger::info(
			'Google Calendar confirmed booking reconciliation completed.',
			$result
		);

		return $result;
	}

	/**
	 * Protect a booking sync from PHP errors and exceptions.
	 *
	 * @param object $booking Booking record.
	 * @param string $operation Diagnostic operation key.
	 * @return array|WP_Error
	 */
	private static function safe_sync_booking( $booking, $operation ) {
		$booking_id = is_object( $booking ) && ! empty( $booking->id ) ? absint( $booking->id ) : 0;
		$provider = self::safe_provider_for_booking( $booking );

		try {
			return self::sync_booking( $booking );
		} catch ( Throwable $error ) {
			self::log_throwable(
				'Google Calendar synchronization crashed.',
				$error,
				array(
					'booking_id' => $booking_id,
					'meeting_provider' => $provider,
					'operation' => sanitize_key( $operation ),
				)
			);

			if ( $booking_id ) {
				try {
					self::save_error( $booking_id, $provider, $error->getMessage() );
				} catch ( Throwable $storage_error ) {
					self::log_throwable(
						'Google Calendar synchronization error could not be stored.',
						$storage_error,
						array( 'booking_id' => $booking_id )
					);
				}
			}

			return new WP_Error(
				'tutorhelper_calendar_sync_crashed',
				__( 'Google Calendar could not synchronize this lesson. The TutorHelper booking was saved successfully.', 'tutorhelper-pro' )
			);
		}
	}

	/**
	 * Protect a Calendar event deletion from PHP errors and exceptions.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param string $operation Diagnostic operation key.
	 * @return true|WP_Error
	 */
	private static function safe_delete_event( $booking_id, $operation ) {
		try {
			self::delete_event( $booking_id );
			return true;
		} catch ( Throwable $error ) {
			self::log_throwable(
				'Google Calendar event removal crashed.',
				$error,
				array(
					'booking_id' => absint( $booking_id ),
					'operation' => sanitize_key( $operation ),
				)
			);

			return new WP_Error(
				'tutorhelper_calendar_delete_crashed',
				__( 'The TutorHelper booking was updated, but its Google Calendar event could not be removed.', 'tutorhelper-pro' )
			);
		}
	}

	/**
	 * Resolve a diagnostic provider without risking another exception.
	 *
	 * @param object $booking Booking record.
	 * @return string
	 */
	private static function safe_provider_for_booking( $booking ) {
		try {
			return self::meeting_provider_for_booking( $booking );
		} catch ( Throwable $error ) {
			return TutorHelper_Pro_Google_Calendar::PROVIDER_NONE;
		}
	}

	/**
	 * Add actionable PHP failure information to TutorHelper Diagnostics.
	 *
	 * @param string    $message Log message.
	 * @param Throwable $error PHP error or exception.
	 * @param array     $context Additional safe context.
	 * @return void
	 */
	private static function log_throwable( $message, $error, $context = array() ) {
		$context = is_array( $context ) ? $context : array();
		$context['error_type'] = get_class( $error );
		$context['error_message'] = sanitize_text_field( $error->getMessage() );
		$context['error_file'] = sanitize_text_field( $error->getFile() );
		$context['error_line'] = absint( $error->getLine() );

		TutorHelper_Logger::error( $message, $context );
	}

	/**
	 * Create or update the Google event for one confirmed booking.
	 *
	 * @param object $booking Booking record.
	 * @return array|WP_Error
	 */
	public static function sync_booking( $booking ) {
		if ( ! TutorHelper_Pro_Google_Calendar::is_connected() ) {
			return new WP_Error( 'tutorhelper_calendar_not_connected', __( 'Google Calendar is not connected.', 'tutorhelper-pro' ) );
		}

		if ( ! is_object( $booking ) || empty( $booking->id ) || TutorHelper_Booking_Records::STATUS_CONFIRMED !== sanitize_key( $booking->status ) ) {
			return new WP_Error( 'tutorhelper_calendar_booking_invalid', __( 'Only confirmed bookings can be added to Google Calendar.', 'tutorhelper-pro' ) );
		}

		$booking_id = absint( $booking->id );
		$existing = self::get_record( $booking_id );
		$provider = self::meeting_provider_for_booking( $booking );
		$payload = self::build_event_payload( $booking, $provider );

		$query = array( 'sendUpdates' => 'none' );

		$existing_event = null;
		if ( $existing && ! empty( $existing->google_event_id ) ) {
			$existing_event = TutorHelper_Pro_Google_Calendar::request(
				'GET',
				'/calendars/primary/events/' . rawurlencode( $existing->google_event_id ),
				null,
				array( 'conferenceDataVersion' => 1 )
			);

			if ( is_wp_error( $existing_event ) && 404 === self::get_error_status( $existing_event ) ) {
				$existing_event = null;
				$existing = null;
			}
		}

		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET === $provider ) {
			$query['conferenceDataVersion'] = 1;

			if ( is_array( $existing_event ) && ! empty( $existing_event['conferenceData'] ) ) {
				$payload['conferenceData'] = $existing_event['conferenceData'];
			} else {
				$payload['conferenceData'] = array(
					'createRequest' => array(
						'requestId' => 'th-' . $booking_id . '-' . substr( wp_generate_uuid4(), 0, 18 ),
						'conferenceSolutionKey' => array( 'type' => 'hangoutsMeet' ),
					),
				);
			}
		} elseif ( is_array( $existing_event ) && ! empty( $existing_event['conferenceData'] ) ) {
			$query['conferenceDataVersion'] = 1;
			$payload['conferenceData'] = null;
		}

		if ( $existing && ! empty( $existing->google_event_id ) ) {
			$result = TutorHelper_Pro_Google_Calendar::request(
				'PATCH',
				'/calendars/primary/events/' . rawurlencode( $existing->google_event_id ),
				$payload,
				$query
			);
		} else {
			$result = TutorHelper_Pro_Google_Calendar::request(
				'POST',
				'/calendars/primary/events',
				$payload,
				$query
			);
		}

		if ( is_wp_error( $result ) ) {
			self::save_error( $booking_id, $provider, $result->get_error_message() );
			TutorHelper_Logger::error(
				'Google Calendar booking sync failed.',
				array(
					'booking_id' => $booking_id,
					'meeting_provider' => $provider,
					'error' => $result->get_error_message(),
					'http_status' => self::get_error_status( $result ),
				)
			);
			return $result;
		}

		$event_id = ! empty( $result['id'] ) ? sanitize_text_field( $result['id'] ) : ( $existing ? $existing->google_event_id : '' );

		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET === $provider && $event_id && empty( $result['hangoutLink'] ) ) {
			$fresh = TutorHelper_Pro_Google_Calendar::request(
				'GET',
				'/calendars/primary/events/' . rawurlencode( $event_id ),
				null,
				array( 'conferenceDataVersion' => 1 )
			);
			if ( ! is_wp_error( $fresh ) ) {
				$result = $fresh;
			}
		}

		$meeting_url = self::extract_meeting_url( $provider, $result );
		self::save_record(
			$booking_id,
			$event_id,
			$provider,
			$meeting_url,
			! empty( $result['htmlLink'] ) ? esc_url_raw( $result['htmlLink'] ) : ''
		);

		TutorHelper_Logger::success(
			'Google Calendar booking synchronized.',
			array(
				'booking_id' => $booking_id,
				'meeting_provider' => $provider,
				'has_meeting_url' => '' !== $meeting_url,
			)
		);

		return $result;
	}

	/**
	 * Read an HTTP status saved in WP_Error data.
	 *
	 * @param WP_Error $error Error object.
	 * @return int
	 */
	private static function get_error_status( $error ) {
		if ( ! is_wp_error( $error ) ) {
			return 0;
		}

		$data = $error->get_error_data();
		return is_array( $data ) && isset( $data['status'] ) ? absint( $data['status'] ) : 0;
	}

	/**
	 * Build event payload.
	 *
	 * @param object $booking Booking record.
	 * @param string $provider Meeting provider snapshot.
	 * @return array
	 */
	private static function build_event_payload( $booking, $provider ) {
		$booking_type = TutorHelper_Booking_Types::get_by_id( absint( $booking->booking_type_id ) );
		$title = $booking_type && ! empty( $booking_type->title ) ? sanitize_text_field( $booking_type->title ) : __( 'TutorHelper lesson', 'tutorhelper-pro' );

		$description = sprintf(
			/* translators: 1: student name, 2: booking ID. */
			__(
				'TutorHelper lesson' . "\n" .
				'Student: %1$s' . "\n" .
				'Booking: #%2$d',
				'tutorhelper-pro'
			),
			sanitize_text_field( $booking->student_name ),
			absint( $booking->id )
		);

		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_ZOOM === $provider ) {
			$zoom_url = TutorHelper_Pro_Online_Lessons::get_zoom_url();
			if ( $zoom_url ) {
				$description .= "\n\n" . __( 'Join Zoom:', 'tutorhelper-pro' ) . ' ' . $zoom_url;
			}
		}

		if ( ! empty( $booking->notes ) ) {
			$description .= "\n\n" . sanitize_textarea_field( $booking->notes );
		}

		$payload = array(
			'summary' => sprintf( '%s – %s', $title, sanitize_text_field( $booking->student_name ) ),
			'description' => $description,
			'start' => self::event_datetime( $booking->booking_start, $booking->timezone ),
			'end' => self::event_datetime( $booking->booking_end, $booking->timezone ),
		);

		if ( 'online' !== sanitize_key( $booking->location_type ) && ! empty( $booking->location_details ) ) {
			$payload['location'] = sanitize_text_field( $booking->location_details );
		}

		return $payload;
	}

	/**
	 * Return RFC3339 event date/time preserving the booking timezone.
	 *
	 * @param string $utc_value Stored UTC datetime.
	 * @param string $timezone_name Booking timezone.
	 * @return array
	 */
	private static function event_datetime( $utc_value, $timezone_name ) {
		try {
			$utc = new DateTimeZone( 'UTC' );
			$timezone_name = in_array( $timezone_name, timezone_identifiers_list(), true ) ? $timezone_name : wp_timezone_string();
			$timezone = new DateTimeZone( $timezone_name ? $timezone_name : 'UTC' );
			$value = new DateTimeImmutable( $utc_value, $utc );
			$value = $value->setTimezone( $timezone );

			return array( 'dateTime' => $value->format( DateTimeInterface::RFC3339 ), 'timeZone' => $timezone->getName() );
		} catch ( Exception $exception ) {
			return array( 'dateTime' => gmdate( 'c', strtotime( $utc_value ) ), 'timeZone' => 'UTC' );
		}
	}

	/**
	 * Determine meeting provider for a booking.
	 *
	 * @param object $booking Booking record.
	 * @return string
	 */
	private static function meeting_provider_for_booking( $booking ) {
		if ( ! is_object( $booking ) || 'online' !== sanitize_key( $booking->location_type ) ) {
			return TutorHelper_Pro_Google_Calendar::PROVIDER_NONE;
		}

		return TutorHelper_Pro_Google_Calendar::get_meeting_provider();
	}

	/**
	 * Extract student join URL.
	 *
	 * @param string $provider Provider key.
	 * @param array  $event Google event response.
	 * @return string
	 */
	private static function extract_meeting_url( $provider, $event ) {
		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_ZOOM === $provider ) {
			return TutorHelper_Pro_Online_Lessons::get_zoom_url();
		}

		if ( TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET === $provider ) {
			if ( ! empty( $event['hangoutLink'] ) ) {
				return esc_url_raw( $event['hangoutLink'] );
			}

			if ( ! empty( $event['conferenceData']['entryPoints'] ) && is_array( $event['conferenceData']['entryPoints'] ) ) {
				foreach ( $event['conferenceData']['entryPoints'] as $entry ) {
					if ( ! empty( $entry['entryPointType'] ) && 'video' === $entry['entryPointType'] && ! empty( $entry['uri'] ) ) {
						return esc_url_raw( $entry['uri'] );
					}
				}
			}
		}

		return '';
	}

	/**
	 * Delete the remote event for a cancelled booking.
	 *
	 * @param int $booking_id Booking ID.
	 * @return void
	 */
	public static function delete_event( $booking_id ) {
		$record = self::get_record( absint( $booking_id ) );
		if ( ! $record || empty( $record->google_event_id ) ) {
			return;
		}

		$result = TutorHelper_Pro_Google_Calendar::request(
			'DELETE',
			'/calendars/primary/events/' . rawurlencode( $record->google_event_id ),
			null,
			array( 'sendUpdates' => 'none' )
		);

		if ( is_wp_error( $result ) && 404 !== self::get_error_status( $result ) ) {
			self::save_error( absint( $booking_id ), sanitize_key( $record->meeting_provider ), $result->get_error_message() );
			TutorHelper_Logger::error(
				'Google Calendar event removal failed.',
				array(
					'booking_id' => absint( $booking_id ),
					'error' => $result->get_error_message(),
					'http_status' => self::get_error_status( $result ),
				)
			);
			return;
		}

		global $wpdb;
		$wpdb->delete( self::get_table_name(), array( 'booking_id' => absint( $booking_id ) ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Module-owned synchronization record.

		TutorHelper_Logger::success( 'Google Calendar event removed for cancelled booking.', array( 'booking_id' => absint( $booking_id ) ) );
	}

	/**
	 * Get calendar record by booking.
	 *
	 * @param int $booking_id Booking ID.
	 * @return object|null
	 */
	public static function get_record( $booking_id ) {
		global $wpdb;
		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Sync metadata must be current.
			$wpdb->prepare( 'SELECT * FROM %i WHERE booking_id = %d LIMIT 1', self::get_table_name(), absint( $booking_id ) )
		);
	}

	/**
	 * Return stored join URL for a booking.
	 *
	 * @param int $booking_id Booking ID.
	 * @return string
	 */
	public static function get_meeting_url( $booking_id ) {
		$record = self::get_record( absint( $booking_id ) );
		return $record && ! empty( $record->meeting_url ) ? esc_url_raw( $record->meeting_url ) : '';
	}

	/**
	 * Return stored meeting provider for a booking.
	 *
	 * @param int $booking_id Booking ID.
	 * @return string
	 */
	public static function get_meeting_provider( $booking_id ) {
		$record = self::get_record( absint( $booking_id ) );
		return $record && ! empty( $record->meeting_provider ) ? sanitize_key( $record->meeting_provider ) : '';
	}

	/**
	 * Save successful synchronization metadata.
	 */
	private static function save_record( $booking_id, $event_id, $provider, $meeting_url, $calendar_url ) {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$table = self::get_table_name();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Module-owned sync metadata upsert.
			$wpdb->prepare(
				'INSERT INTO %i (booking_id, calendar_id, google_event_id, meeting_provider, meeting_url, calendar_event_url, sync_status, last_error, last_synced_at, created_at, updated_at) VALUES (%d, %s, %s, %s, %s, %s, %s, NULL, %s, %s, %s) ON DUPLICATE KEY UPDATE google_event_id = VALUES(google_event_id), meeting_provider = VALUES(meeting_provider), meeting_url = VALUES(meeting_url), calendar_event_url = VALUES(calendar_event_url), sync_status = VALUES(sync_status), last_error = NULL, last_synced_at = VALUES(last_synced_at), updated_at = VALUES(updated_at)',
				$table, absint( $booking_id ), 'primary', sanitize_text_field( $event_id ), sanitize_key( $provider ), esc_url_raw( $meeting_url ), esc_url_raw( $calendar_url ), 'synced', $now, $now, $now
			)
		);
	}

	/**
	 * Save failed synchronization metadata.
	 */
	private static function save_error( $booking_id, $provider, $message ) {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$table = self::get_table_name();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Module-owned sync metadata upsert.
			$wpdb->prepare(
				'INSERT INTO %i (booking_id, calendar_id, meeting_provider, sync_status, last_error, created_at, updated_at) VALUES (%d, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE meeting_provider = VALUES(meeting_provider), sync_status = VALUES(sync_status), last_error = VALUES(last_error), updated_at = VALUES(updated_at)',
				$table, absint( $booking_id ), 'primary', sanitize_key( $provider ), 'error', sanitize_text_field( $message ), $now, $now
			)
		);
	}
}
