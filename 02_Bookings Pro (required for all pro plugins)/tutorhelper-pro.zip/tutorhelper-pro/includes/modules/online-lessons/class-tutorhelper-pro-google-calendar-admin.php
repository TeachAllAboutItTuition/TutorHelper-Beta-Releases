<?php
/**
 * Google Calendar admin integration for TutorHelper Pro.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds Google Calendar connection controls to Online Lessons settings.
 */
final class TutorHelper_Pro_Google_Calendar_Admin {

	const SAVE_ACTION = 'tutorhelper_pro_save_google_calendar';
	const CONNECT_ACTION = 'tutorhelper_pro_google_calendar_connect';
	const CALLBACK_ACTION = 'tutorhelper_pro_google_calendar_callback';
	const DISCONNECT_ACTION = 'tutorhelper_pro_google_calendar_disconnect';
	const SYNC_ACTION = 'tutorhelper_pro_google_calendar_sync';

	/** Register admin hooks. */
	public static function init() {
		add_action( 'tutorhelper_settings_render_tab', array( __CLASS__, 'render_settings' ), 25, 1 );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_' . self::CONNECT_ACTION, array( __CLASS__, 'handle_connect' ) );
		add_action( 'admin_post_' . self::CALLBACK_ACTION, array( __CLASS__, 'handle_callback' ) );
		add_action( 'admin_post_' . self::DISCONNECT_ACTION, array( __CLASS__, 'handle_disconnect' ) );
		add_action( 'admin_post_' . self::SYNC_ACTION, array( __CLASS__, 'handle_sync' ) );
	}

	/**
	 * Render Calendar and online meeting controls.
	 *
	 * @param string $selected_tab Current settings tab.
	 * @return void
	 */
	public static function render_settings( $selected_tab ) {
		if ( TutorHelper_Pro_Settings::ONLINE_LESSONS_TAB !== sanitize_key( $selected_tab ) || ! TutorHelper_Pro_License::is_active() ) {
			return;
		}

		$connected = TutorHelper_Pro_Google_Calendar::is_connected();
		$client_id = TutorHelper_Pro_Google_Calendar::get_client_id();
		$has_secret = '' !== TutorHelper_Pro_Google_Calendar::get_client_secret();
		$provider = TutorHelper_Pro_Google_Calendar::get_meeting_provider();
		$connect_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=' . self::CONNECT_ACTION ),
			self::CONNECT_ACTION
		);
		$disconnect_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=' . self::DISCONNECT_ACTION ),
			self::DISCONNECT_ACTION
		);
		$sync_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=' . self::SYNC_ACTION ),
			self::SYNC_ACTION
		);
		?>
		<section class="tutorhelper-main-section">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'Google Calendar & online meetings', 'tutorhelper-pro' ); ?></h2>
					<p><?php esc_html_e( 'Create a Calendar event automatically when a lesson is confirmed and keep it synchronized when the lesson moves or is cancelled.', 'tutorhelper-pro' ); ?></p>
				</div>
			</header>

			<div class="tutorhelper-main-section__body tutorhelper-settings-section__body">
				<?php self::render_notice(); ?>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-settings-form">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
					<?php wp_nonce_field( self::SAVE_ACTION, 'tutorhelper_pro_google_calendar_nonce' ); ?>

					<div class="tutorhelper-input-fields">
						<div class="tutorhelper-input-field is-full-width">
							<label for="tutorhelper_pro_google_client_id"><?php esc_html_e( 'Google OAuth client ID', 'tutorhelper-pro' ); ?></label>
							<input type="text" id="tutorhelper_pro_google_client_id" name="google_client_id" class="tutorhelper-admin-control" value="<?php echo esc_attr( $client_id ); ?>" <?php disabled( defined( 'TUTORHELPER_PRO_GOOGLE_CLIENT_ID' ) ); ?> />
							<p class="description"><?php esc_html_e( 'Create a Web application OAuth client in Google Cloud and enable the Google Calendar API.', 'tutorhelper-pro' ); ?></p>
						</div>

						<div class="tutorhelper-input-field is-full-width">
							<label for="tutorhelper_pro_google_client_secret"><?php esc_html_e( 'Google OAuth client secret', 'tutorhelper-pro' ); ?></label>
							<input type="password" id="tutorhelper_pro_google_client_secret" name="google_client_secret" class="tutorhelper-admin-control" value="" autocomplete="new-password" placeholder="<?php echo esc_attr( $has_secret ? __( 'Saved — leave blank to keep', 'tutorhelper-pro' ) : __( 'Not configured', 'tutorhelper-pro' ) ); ?>" <?php disabled( defined( 'TUTORHELPER_PRO_GOOGLE_CLIENT_SECRET' ) ); ?> />
							<?php if ( $has_secret && ! defined( 'TUTORHELPER_PRO_GOOGLE_CLIENT_SECRET' ) ) : ?>
								<label class="tutorhelper-pro-google-secret-remove"><input type="checkbox" name="remove_google_client_secret" value="1" /> <?php esc_html_e( 'Remove saved client secret', 'tutorhelper-pro' ); ?></label>
							<?php endif; ?>
						</div>

						<div class="tutorhelper-input-field is-full-width">
							<label><?php esc_html_e( 'Authorised redirect URI', 'tutorhelper-pro' ); ?></label>
							<input type="text" class="tutorhelper-admin-control" readonly value="<?php echo esc_attr( TutorHelper_Pro_Google_Calendar::get_redirect_uri() ); ?>" />
							<p class="description"><?php esc_html_e( 'Add this exact URL to the authorised redirect URIs for the Google OAuth client.', 'tutorhelper-pro' ); ?></p>
						</div>

						<fieldset class="tutorhelper-pro-meeting-provider">
							<legend><?php esc_html_e( 'Online meeting provider', 'tutorhelper-pro' ); ?></legend>

							<div class="tutorhelper-pro-meeting-provider__options">
								<label class="tutorhelper-pro-meeting-provider__option">
									<input type="radio" name="meeting_provider" value="zoom" <?php checked( $provider, TutorHelper_Pro_Google_Calendar::PROVIDER_ZOOM ); ?> />
									<span class="tutorhelper-pro-meeting-provider__copy">
										<strong><?php esc_html_e( 'Zoom', 'tutorhelper-pro' ); ?></strong>
										<small><?php esc_html_e( 'Use your saved Zoom meeting link and add it to the Google Calendar event description.', 'tutorhelper-pro' ); ?></small>
									</span>
								</label>

								<label class="tutorhelper-pro-meeting-provider__option">
									<input type="radio" name="meeting_provider" value="google_meet" <?php checked( $provider, TutorHelper_Pro_Google_Calendar::PROVIDER_GOOGLE_MEET ); ?> />
									<span class="tutorhelper-pro-meeting-provider__copy">
										<strong><?php esc_html_e( 'Google Meet', 'tutorhelper-pro' ); ?></strong>
										<small><?php esc_html_e( 'Create a unique Google Meet link for each confirmed online lesson.', 'tutorhelper-pro' ); ?></small>
									</span>
								</label>

								<label class="tutorhelper-pro-meeting-provider__option">
									<input type="radio" name="meeting_provider" value="none" <?php checked( $provider, TutorHelper_Pro_Google_Calendar::PROVIDER_NONE ); ?> />
									<span class="tutorhelper-pro-meeting-provider__copy">
										<strong><?php esc_html_e( 'No online meeting link', 'tutorhelper-pro' ); ?></strong>
										<small><?php esc_html_e( 'Add confirmed lessons to Google Calendar without attaching Zoom or Google Meet.', 'tutorhelper-pro' ); ?></small>
									</span>
								</label>
							</div>

							<p class="description"><?php esc_html_e( 'This choice only affects lessons whose location is Online. Other confirmed lessons are still added to Google Calendar.', 'tutorhelper-pro' ); ?></p>
						</fieldset>
					</div>

					<div class="tutorhelper-settings-form__actions">
						<button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary"><?php esc_html_e( 'Save Calendar settings', 'tutorhelper-pro' ); ?></button>
					</div>
				</form>

				<div class="tutorhelper-input-field is-full-width tutorhelper-pro-google-calendar-connection">
					<label><?php esc_html_e( 'Google Calendar connection', 'tutorhelper-pro' ); ?></label>
					<?php if ( $connected ) : ?>
						<p><strong><?php esc_html_e( 'Connected', 'tutorhelper-pro' ); ?></strong></p>
						<p class="description"><?php esc_html_e( 'Newly confirmed lessons are synchronized automatically. TutorHelper booking emails remain the student notification source; Google does not send a second invitation email.', 'tutorhelper-pro' ); ?></p>
						<div class="tutorhelper-pro-google-calendar-connection__actions">
							<a href="<?php echo esc_url( $sync_url ); ?>" class="button tutorhelper-admin-button tutorhelper-admin-button--primary"><?php esc_html_e( 'Sync confirmed lessons now', 'tutorhelper-pro' ); ?></a>
							<a href="<?php echo esc_url( $disconnect_url ); ?>" class="button tutorhelper-admin-button"><?php esc_html_e( 'Disconnect Google Calendar', 'tutorhelper-pro' ); ?></a>
						</div>
						<p class="description"><?php esc_html_e( 'Use Sync confirmed lessons now after changing the online meeting provider, or to retry lessons that previously failed to synchronize.', 'tutorhelper-pro' ); ?></p>
					<?php elseif ( TutorHelper_Pro_Google_Calendar::credentials_are_configured() ) : ?>
						<p><?php esc_html_e( 'Connect the tutor Google account whose primary calendar should receive confirmed lessons.', 'tutorhelper-pro' ); ?></p>
						<a href="<?php echo esc_url( $connect_url ); ?>" class="button tutorhelper-admin-button tutorhelper-admin-button--primary"><?php esc_html_e( 'Connect Google Calendar', 'tutorhelper-pro' ); ?></a>
					<?php else : ?>
						<p><?php esc_html_e( 'Save the Google OAuth client ID and client secret before connecting Calendar.', 'tutorhelper-pro' ); ?></p>
					<?php endif; ?>
				</div>
			</div>
		</section>
		<?php
	}

	/**
	 * Save settings only. Remote synchronization is a separate action so a
	 * temporary Google failure can never prevent local settings from saving.
	 *
	 * @return void
	 */
	public static function handle_save() {
		self::check_permission();
		check_admin_referer( self::SAVE_ACTION, 'tutorhelper_pro_google_calendar_nonce' );

		$client_id = isset( $_POST['google_client_id'] ) && ! is_array( $_POST['google_client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['google_client_id'] ) ) : '';
		$client_secret = isset( $_POST['google_client_secret'] ) && ! is_array( $_POST['google_client_secret'] ) ? sanitize_text_field( wp_unslash( $_POST['google_client_secret'] ) ) : '';
		$remove_secret = ! empty( $_POST['remove_google_client_secret'] );
		$provider = isset( $_POST['meeting_provider'] ) && ! is_array( $_POST['meeting_provider'] ) ? sanitize_key( wp_unslash( $_POST['meeting_provider'] ) ) : TutorHelper_Pro_Google_Calendar::PROVIDER_ZOOM;

		TutorHelper_Pro_Google_Calendar::save_credentials( $client_id, $client_secret, $remove_secret );
		TutorHelper_Pro_Google_Calendar::set_meeting_provider( $provider );

		TutorHelper_Logger::success(
			'Google Calendar settings saved.',
			array( 'meeting_provider' => TutorHelper_Pro_Google_Calendar::get_meeting_provider() )
		);

		self::redirect( 'saved' );
	}

	/** Start OAuth flow. */
	public static function handle_connect() {
		self::check_permission();
		check_admin_referer( self::CONNECT_ACTION );
		$url = TutorHelper_Pro_Google_Calendar::get_authorisation_url();
		if ( is_wp_error( $url ) ) {
			self::redirect( $url->get_error_code(), 'error' );
		}
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Destination is Google's fixed OAuth host plus generated query arguments.
		exit;
	}

	/**
	 * Handle OAuth callback. A successful token exchange remains connected even
	 * if the first Calendar reconciliation fails.
	 *
	 * @return void
	 */
	public static function handle_callback() {
		self::check_permission();

		$state = isset( $_GET['state'] ) && ! is_array( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		if ( ! $state || ! TutorHelper_Pro_Google_Calendar::validate_state( $state ) ) {
			self::redirect( 'invalid_state', 'error' );
		}

		if ( ! empty( $_GET['error'] ) ) {
			self::redirect( 'google_denied', 'error' );
		}

		$code = isset( $_GET['code'] ) && ! is_array( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
		$result = TutorHelper_Pro_Google_Calendar::exchange_code( $code );
		if ( is_wp_error( $result ) ) {
			TutorHelper_Logger::error( 'Google Calendar connection failed.', array( 'error' => $result->get_error_message() ) );
			self::redirect( $result->get_error_code(), 'error' );
		}

		$sync = self::run_reconciliation( 'oauth_callback' );

		TutorHelper_Logger::success(
			'Google Calendar connected.',
			array(
				'confirmed_lessons_synced' => absint( $sync['synced'] ),
				'confirmed_lessons_failed' => absint( $sync['failed'] ),
			)
		);

		self::redirect( 0 < absint( $sync['failed'] ) ? 'connected_with_errors' : 'connected' );
	}

	/**
	 * Manually reconcile future confirmed lessons.
	 *
	 * @return void
	 */
	public static function handle_sync() {
		self::check_permission();
		check_admin_referer( self::SYNC_ACTION );

		if ( ! TutorHelper_Pro_Google_Calendar::is_connected() ) {
			self::redirect( 'not_connected', 'error' );
		}

		$sync = self::run_reconciliation( 'manual_sync' );
		self::redirect( 0 < absint( $sync['failed'] ) ? 'sync_with_errors' : 'synced', 0 < absint( $sync['failed'] ) ? 'error' : 'success' );
	}

	/** Disconnect OAuth. */
	public static function handle_disconnect() {
		self::check_permission();
		check_admin_referer( self::DISCONNECT_ACTION );
		TutorHelper_Pro_Google_Calendar::disconnect();
		TutorHelper_Logger::success( 'Google Calendar disconnected.' );
		self::redirect( 'disconnected' );
	}

	/**
	 * Run reconciliation without allowing an unexpected PHP failure to escape
	 * into the OAuth callback or settings request.
	 *
	 * @param string $operation Diagnostic operation key.
	 * @return array
	 */
	private static function run_reconciliation( $operation ) {
		$summary = array(
			'synced' => 0,
			'failed' => 0,
		);

		try {
			$summary = TutorHelper_Pro_Calendar_Sync::sync_upcoming_confirmed();
		} catch ( Throwable $error ) {
			$summary['failed']++;
			self::log_throwable(
				'Google Calendar reconciliation crashed.',
				$error,
				array( 'operation' => sanitize_key( $operation ) )
			);
		}

		return $summary;
	}

	/** Permission check. */
	private static function check_permission() {
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}
		wp_die( esc_html__( 'You do not have permission to manage Google Calendar settings.', 'tutorhelper-pro' ), esc_html__( 'Permission denied', 'tutorhelper-pro' ), array( 'response' => 403 ) );
	}

	/**
	 * Log an unexpected admin integration failure.
	 *
	 * @param string    $message Log message.
	 * @param Throwable $error PHP error or exception.
	 * @param array     $context Additional context.
	 * @return void
	 */
	private static function log_throwable( $message, $error, $context = array() ) {
		$context = is_array( $context ) ? $context : array();
		$context['error_type'] = get_class( $error );
		$context['error_message'] = sanitize_text_field( $error->getMessage() );
		$context['error_file'] = sanitize_text_field( $error->getFile() );
		$context['error_line'] = absint( $error->getLine() );
		TutorHelper_Logger::error( $message, $context );
	}

	/** Render settings feedback. */
	private static function render_notice() {
		$status = isset( $_GET['tutorhelper_pro_calendar_status'] ) && ! is_array( $_GET['tutorhelper_pro_calendar_status'] ) ? sanitize_key( wp_unslash( $_GET['tutorhelper_pro_calendar_status'] ) ) : '';
		$type = isset( $_GET['tutorhelper_pro_calendar_notice'] ) && ! is_array( $_GET['tutorhelper_pro_calendar_notice'] ) ? sanitize_key( wp_unslash( $_GET['tutorhelper_pro_calendar_notice'] ) ) : 'success';
		if ( '' === $status ) {
			return;
		}

		$messages = array(
			'saved' => __( 'Google Calendar settings saved.', 'tutorhelper-pro' ),
			'synced' => __( 'Future confirmed lessons synchronized with Google Calendar.', 'tutorhelper-pro' ),
			'sync_with_errors' => __( 'Calendar synchronization completed, but one or more lessons could not be synchronized. Check TutorHelper Diagnostics for details.', 'tutorhelper-pro' ),
			'connected' => __( 'Google Calendar connected successfully. Future confirmed lessons have been synchronized.', 'tutorhelper-pro' ),
			'connected_with_errors' => __( 'Google Calendar connected successfully, but one or more confirmed lessons could not be synchronized. Check TutorHelper Diagnostics for details.', 'tutorhelper-pro' ),
			'disconnected' => __( 'Google Calendar disconnected. Existing Google Calendar events have not been deleted.', 'tutorhelper-pro' ),
			'not_connected' => __( 'Connect Google Calendar before synchronizing lessons.', 'tutorhelper-pro' ),
			'invalid_state' => __( 'The Google connection could not be verified. Please try again.', 'tutorhelper-pro' ),
			'google_denied' => __( 'Google Calendar access was not granted.', 'tutorhelper-pro' ),
			'tutorhelper_google_credentials_missing' => __( 'Google OAuth credentials are missing.', 'tutorhelper-pro' ),
			'tutorhelper_google_token_exchange_failed' => __( 'Google did not return a reusable Calendar connection. Please connect again.', 'tutorhelper-pro' ),
		);

		$message = isset( $messages[ $status ] ) ? $messages[ $status ] : __( 'The Google Calendar request could not be completed.', 'tutorhelper-pro' );
		$error_statuses = array( 'connected_with_errors', 'sync_with_errors', 'not_connected', 'invalid_state', 'google_denied', 'tutorhelper_google_credentials_missing', 'tutorhelper_google_token_exchange_failed' );
		$notice_type = in_array( $status, $error_statuses, true ) ? 'error' : $type;
		?>
		<div class="notice <?php echo esc_attr( 'error' === $notice_type ? 'notice-error' : 'notice-success' ); ?> inline"><p><?php echo esc_html( $message ); ?></p></div>
		<?php
	}

	/** Redirect to Online Lessons. */
	private static function redirect( $status, $notice = 'success' ) {
		$url = add_query_arg(
			array(
				'page' => TutorHelper_Settings::PAGE_SLUG,
				'tab' => TutorHelper_Pro_Settings::ONLINE_LESSONS_TAB,
				'tutorhelper_pro_calendar_status' => sanitize_key( $status ),
				'tutorhelper_pro_calendar_notice' => sanitize_key( $notice ),
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}
}
