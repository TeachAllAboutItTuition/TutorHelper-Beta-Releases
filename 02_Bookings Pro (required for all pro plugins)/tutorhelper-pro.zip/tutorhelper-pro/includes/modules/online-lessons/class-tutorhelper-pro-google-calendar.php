<?php
/**
 * Google Calendar OAuth and API client for TutorHelper Pro.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles Google Calendar connection and REST API requests without
 * introducing a third-party PHP runtime dependency.
 */
final class TutorHelper_Pro_Google_Calendar {

	const OPTION_CLIENT_ID = 'tutorhelper_pro_google_client_id';
	const OPTION_CLIENT_SECRET = 'tutorhelper_pro_google_client_secret';
	const OPTION_REFRESH_TOKEN = 'tutorhelper_pro_google_refresh_token';
	const OPTION_ACCOUNT_EMAIL = 'tutorhelper_pro_google_account_email';
	const OPTION_MEETING_PROVIDER = 'tutorhelper_pro_online_meeting_provider';
	const TRANSIENT_STATE_PREFIX = 'tutorhelper_pro_google_state_';

	const PROVIDER_NONE = 'none';
	const PROVIDER_ZOOM = 'zoom';
	const PROVIDER_GOOGLE_MEET = 'google_meet';

	const AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
	const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
	const REVOKE_ENDPOINT = 'https://oauth2.googleapis.com/revoke';
	const CALENDAR_API = 'https://www.googleapis.com/calendar/v3';
	const SCOPE = 'https://www.googleapis.com/auth/calendar.events';

	/**
	 * Return configured OAuth client ID.
	 *
	 * @return string
	 */
	public static function get_client_id() {
		if ( defined( 'TUTORHELPER_PRO_GOOGLE_CLIENT_ID' ) ) {
			return sanitize_text_field( TUTORHELPER_PRO_GOOGLE_CLIENT_ID );
		}

		return sanitize_text_field( get_option( self::OPTION_CLIENT_ID, '' ) );
	}

	/**
	 * Return configured OAuth client secret.
	 *
	 * @return string
	 */
	public static function get_client_secret() {
		if ( defined( 'TUTORHELPER_PRO_GOOGLE_CLIENT_SECRET' ) ) {
			return sanitize_text_field( TUTORHELPER_PRO_GOOGLE_CLIENT_SECRET );
		}

		return (string) get_option( self::OPTION_CLIENT_SECRET, '' );
	}

	/**
	 * Save OAuth application credentials.
	 *
	 * @param string $client_id Client ID.
	 * @param string $client_secret Client secret. Blank retains saved value.
	 * @param bool   $remove_secret Remove saved secret.
	 * @return void
	 */
	public static function save_credentials( $client_id, $client_secret, $remove_secret = false ) {
		if ( ! defined( 'TUTORHELPER_PRO_GOOGLE_CLIENT_ID' ) ) {
			update_option( self::OPTION_CLIENT_ID, sanitize_text_field( $client_id ), false );
		}

		if ( ! defined( 'TUTORHELPER_PRO_GOOGLE_CLIENT_SECRET' ) ) {
			if ( $remove_secret ) {
				delete_option( self::OPTION_CLIENT_SECRET );
			} elseif ( '' !== trim( (string) $client_secret ) ) {
				update_option( self::OPTION_CLIENT_SECRET, sanitize_text_field( $client_secret ), false );
			}
		}
	}

	/**
	 * Return OAuth redirect URI.
	 *
	 * @return string
	 */
	public static function get_redirect_uri() {
		return admin_url( 'admin-post.php?action=tutorhelper_pro_google_calendar_callback' );
	}

	/**
	 * Return whether OAuth application credentials exist.
	 *
	 * @return bool
	 */
	public static function credentials_are_configured() {
		return '' !== self::get_client_id() && '' !== self::get_client_secret();
	}

	/**
	 * Return whether Calendar has a refresh token.
	 *
	 * @return bool
	 */
	public static function is_connected() {
		return '' !== (string) get_option( self::OPTION_REFRESH_TOKEN, '' );
	}

	/**
	 * Return connected account label where available.
	 *
	 * @return string
	 */
	public static function get_account_email() {
		return sanitize_email( get_option( self::OPTION_ACCOUNT_EMAIL, '' ) );
	}

	/**
	 * Return selected online meeting provider.
	 *
	 * @return string
	 */
	public static function get_meeting_provider() {
		$provider = sanitize_key( get_option( self::OPTION_MEETING_PROVIDER, self::PROVIDER_ZOOM ) );

		if ( ! in_array( $provider, array( self::PROVIDER_NONE, self::PROVIDER_ZOOM, self::PROVIDER_GOOGLE_MEET ), true ) ) {
			return self::PROVIDER_ZOOM;
		}

		return $provider;
	}

	/**
	 * Save selected online meeting provider.
	 *
	 * @param string $provider Provider key.
	 * @return void
	 */
	public static function set_meeting_provider( $provider ) {
		$provider = sanitize_key( $provider );

		if ( ! in_array( $provider, array( self::PROVIDER_NONE, self::PROVIDER_ZOOM, self::PROVIDER_GOOGLE_MEET ), true ) ) {
			$provider = self::PROVIDER_ZOOM;
		}

		update_option( self::OPTION_MEETING_PROVIDER, $provider, false );
	}

	/**
	 * Build OAuth consent URL and persist a short-lived state token.
	 *
	 * @return string|WP_Error
	 */
	public static function get_authorisation_url() {
		if ( ! self::credentials_are_configured() ) {
			return new WP_Error( 'tutorhelper_google_credentials_missing', __( 'Add the Google OAuth client ID and secret before connecting Calendar.', 'tutorhelper-pro' ) );
		}

		$state = wp_generate_password( 32, false, false );
		set_transient(
			self::TRANSIENT_STATE_PREFIX . hash( 'sha256', $state ),
			get_current_user_id(),
			10 * MINUTE_IN_SECONDS
		);

		return add_query_arg(
			array(
				'client_id' => self::get_client_id(),
				'redirect_uri' => self::get_redirect_uri(),
				'response_type' => 'code',
				'scope' => self::SCOPE,
				'access_type' => 'offline',
				'prompt' => 'consent',
				'include_granted_scopes' => 'true',
				'state' => $state,
			),
			self::AUTH_ENDPOINT
		);
	}

	/**
	 * Validate callback state.
	 *
	 * @param string $state Returned OAuth state.
	 * @return bool
	 */
	public static function validate_state( $state ) {
		$key = self::TRANSIENT_STATE_PREFIX . hash( 'sha256', (string) $state );
		$user_id = absint( get_transient( $key ) );
		delete_transient( $key );

		return $user_id && $user_id === get_current_user_id();
	}

	/**
	 * Exchange OAuth authorisation code and store refresh token.
	 *
	 * @param string $code Authorisation code.
	 * @return true|WP_Error
	 */
	public static function exchange_code( $code ) {
		$response = wp_remote_post(
			self::TOKEN_ENDPOINT,
			array(
				'timeout' => 20,
				'body' => array(
					'code' => sanitize_text_field( $code ),
					'client_id' => self::get_client_id(),
					'client_secret' => self::get_client_secret(),
					'redirect_uri' => self::get_redirect_uri(),
					'grant_type' => 'authorization_code',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== wp_remote_retrieve_response_code( $response ) || ! is_array( $data ) || empty( $data['refresh_token'] ) ) {
			return new WP_Error( 'tutorhelper_google_token_exchange_failed', __( 'Google Calendar connected without a reusable refresh token. Please try connecting again.', 'tutorhelper-pro' ) );
		}

		update_option( self::OPTION_REFRESH_TOKEN, sanitize_text_field( $data['refresh_token'] ), false );

		return true;
	}

	/**
	 * Disconnect Google Calendar and revoke stored refresh token.
	 *
	 * @return void
	 */
	public static function disconnect() {
		$refresh_token = (string) get_option( self::OPTION_REFRESH_TOKEN, '' );

		if ( '' !== $refresh_token ) {
			wp_remote_post(
				self::REVOKE_ENDPOINT,
				array(
					'timeout' => 10,
					'body' => array( 'token' => $refresh_token ),
				)
			);
		}

		delete_option( self::OPTION_REFRESH_TOKEN );
		delete_option( self::OPTION_ACCOUNT_EMAIL );
	}

	/**
	 * Obtain a short-lived access token from the stored refresh token.
	 *
	 * @return string|WP_Error
	 */
	public static function get_access_token() {
		$refresh_token = (string) get_option( self::OPTION_REFRESH_TOKEN, '' );

		if ( '' === $refresh_token ) {
			return new WP_Error( 'tutorhelper_google_not_connected', __( 'Google Calendar is not connected.', 'tutorhelper-pro' ) );
		}

		$cached = get_transient( 'tutorhelper_pro_google_access_token' );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$response = wp_remote_post(
			self::TOKEN_ENDPOINT,
			array(
				'timeout' => 20,
				'body' => array(
					'client_id' => self::get_client_id(),
					'client_secret' => self::get_client_secret(),
					'refresh_token' => $refresh_token,
					'grant_type' => 'refresh_token',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== wp_remote_retrieve_response_code( $response ) || empty( $data['access_token'] ) ) {
			return new WP_Error( 'tutorhelper_google_refresh_failed', __( 'TutorHelper could not refresh Google Calendar access.', 'tutorhelper-pro' ) );
		}

		$ttl = ! empty( $data['expires_in'] ) ? max( 60, absint( $data['expires_in'] ) - 120 ) : 3000;
		set_transient( 'tutorhelper_pro_google_access_token', sanitize_text_field( $data['access_token'] ), $ttl );

		return sanitize_text_field( $data['access_token'] );
	}

	/**
	 * Make an authenticated Calendar API request.
	 *
	 * @param string     $method HTTP method.
	 * @param string     $path API path beginning with slash.
	 * @param array|null $body Optional JSON body.
	 * @param array      $query Optional query args.
	 * @return array|WP_Error
	 */
	public static function request( $method, $path, $body = null, $query = array() ) {
		$access_token = self::get_access_token();
		if ( is_wp_error( $access_token ) ) {
			return $access_token;
		}

		$url = self::CALENDAR_API . '/' . ltrim( $path, '/' );
		if ( ! empty( $query ) ) {
			$url = add_query_arg( $query, $url );
		}

		$args = array(
			'method' => strtoupper( $method ),
			'timeout' => 25,
			'headers' => array(
				'Authorization' => 'Bearer ' . $access_token,
				'Accept' => 'application/json',
			),
		);

		if ( null !== $body ) {
			$args['headers']['Content-Type'] = 'application/json; charset=utf-8';
			$args['body'] = wp_json_encode( $body );
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $status < 200 || $status >= 300 ) {
			$message = is_array( $data ) && ! empty( $data['error']['message'] )
				? sanitize_text_field( $data['error']['message'] )
				: __( 'Google Calendar returned an error.', 'tutorhelper-pro' );

			return new WP_Error( 'tutorhelper_google_calendar_api_error', $message, array( 'status' => $status ) );
		}

		return is_array( $data ) ? $data : array();
	}
}
