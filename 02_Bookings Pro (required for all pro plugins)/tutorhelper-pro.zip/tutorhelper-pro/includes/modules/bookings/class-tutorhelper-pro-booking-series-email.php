<?php
/**
 * TutorHelper Pro recurring booking email.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and sends the recurring booking student email.
 */
final class TutorHelper_Pro_Booking_Series_Email {

	/**
	 * Student recurring-series confirmation template.
	 *
	 * @var string
	 */
	const STUDENT_SERIES_CREATED =
		'pro_booking_series_student_created';

	/**
	 * Register the Pro email template.
	 *
	 * @return void
	 */
	public static function init() {
		self::register_template();
	}

	/**
	 * Register the recurring-series email template.
	 *
	 * @return void
	 */
	private static function register_template() {

		TutorHelper_Email_Templates::register(
			self::STUDENT_SERIES_CREATED,
			array(
				'module' =>
					'bookings',

				'label' =>
					__(
						'Regular lessons booked — Student',
						'tutorhelper-pro'
					),

				'description' =>
					__(
						'Sent to the student when their tutor creates a recurring booking series.',
						'tutorhelper-pro'
					),

				'heading' =>
					__(
						'Regular Lessons Booked',
						'tutorhelper-pro'
					),

				'recipient' =>
					'student',

				'enabled' =>
					true,

				'subject' =>
					__(
						'Your regular {booking_type} lessons have been scheduled',
						'tutorhelper-pro'
					),

				'body' =>
					__(
						"Hello {student_name},\n\n{tutor_name} has scheduled a regular {booking_type} lesson for you.\n\nSchedule: {series_frequency}\nFrom: {series_start_date}\nUntil: {series_end_date}\nTime: {lesson_time}\nLocation: {location_type}\nStatus: {booking_status}\n\n{lesson_count} lessons have been booked.\n{skipped_summary}\n\n{joining_details}\n\nYou can view your lessons here:\n{student_dashboard_url}\n\nBest wishes,\n{tutor_name}",
						'tutorhelper-pro'
					),

				'placeholders' =>
					array(
						'{student_name}',
						'{tutor_name}',
						'{booking_type}',
						'{series_frequency}',
						'{series_start_date}',
						'{series_end_date}',
						'{lesson_time}',
						'{location_type}',
						'{booking_status}',
						'{lesson_count}',
						'{skipped_summary}',
						'{joining_details}',
						'{student_dashboard_url}',
						'{site_name}',
					),
			)
		);
	}

	/**
	 * Send the single student confirmation for a series.
	 *
	 * @param int $series_id       Series ID.
	 * @param int $first_booking_id First created Core booking ID.
	 * @param int $created_count    Number of lessons created.
	 * @param int $skipped_count    Number of dates skipped.
	 *
	 * @return true|WP_Error
	 */
	public static function send(
		$series_id,
		$first_booking_id,
		$created_count,
		$skipped_count
	) {
		$series_id =
			absint( $series_id );

		$first_booking_id =
			absint( $first_booking_id );

		$created_count =
			absint( $created_count );

		$skipped_count =
			absint( $skipped_count );

		if (
			! $series_id
			|| ! $first_booking_id
		) {
			return new WP_Error(
				'tutorhelper_pro_series_email_invalid',
				__(
					'The recurring booking email could not be prepared.',
					'tutorhelper-pro'
				)
			);
		}

		$series =
			TutorHelper_Pro_Booking_Series::
				get_by_id(
					$series_id
				);

		if ( ! is_object( $series ) ) {
			return new WP_Error(
				'tutorhelper_pro_series_email_series_missing',
				__(
					'The recurring booking series could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$context =
			TutorHelper_Booking_Email_Context::
				build(
					$first_booking_id
				);

		if ( is_wp_error( $context ) ) {
			return $context;
		}

		$template_key =
			self::STUDENT_SERIES_CREATED;

		if (
			! TutorHelper_Email_Templates::
				is_enabled(
					$template_key
				)
		) {
			return true;
		}

		$placeholders =
			$context['placeholders'];

		$placeholders[
			'{series_frequency}'
		] =
			self::get_frequency_label(
				$series->frequency
			);

		$placeholders[
			'{series_start_date}'
		] =
			self::format_series_date(
				$series->start_date,
				$series->timezone
			);

		$placeholders[
			'{series_end_date}'
		] =
			self::format_series_date(
				$series->end_date,
				$series->timezone
			);

		$placeholders[
			'{booking_status}'
		] =
			self::get_status_label(
				$series->booking_status
			);

		$placeholders[
			'{lesson_count}'
		] =
			(string) $created_count;

		$placeholders[
			'{skipped_summary}'
		] =
			0 < $skipped_count
				? sprintf(
					/* translators: %d: number of skipped dates. */
					_n(
						'%d date was skipped because it was unavailable.',
						'%d dates were skipped because they were unavailable.',
						$skipped_count,
						'tutorhelper-pro'
					),
					$skipped_count
				)
				: '';

		$result =
			TutorHelper_Email_Sender::send(
				$template_key,
				$context[
					'student_email'
				],
				$placeholders,
				array(
					'reply_to_email' =>
						$context[
							'tutor_email'
						],

					'reply_to_name' =>
						$placeholders[
							'{tutor_name}'
						],

					'context' =>
						array(
							'series_id' =>
								$series_id,

							'booking_id' =>
								$first_booking_id,

							'email_type' =>
								'student_booking_series_created',
						),
				)
			);

		if ( is_wp_error( $result ) ) {
			TutorHelper_Logger::warning(
				'Recurring booking student email was not sent.',
				array(
					'series_id' =>
						$series_id,

					'booking_id' =>
						$first_booking_id,

					'error_code' =>
						$result
							->get_error_code(),
				)
			);

			return $result;
		}

		TutorHelper_Logger::success(
			'Recurring booking student email sent.',
			array(
				'series_id' =>
					$series_id,

				'booking_id' =>
					$first_booking_id,

				'booking_count' =>
					$created_count,
			)
		);

		return true;
	}

	/**
	 * Return the readable recurrence frequency.
	 *
	 * @param string $frequency Frequency key.
	 *
	 * @return string
	 */
	private static function get_frequency_label(
		$frequency
	) {
		$frequency =
			sanitize_key(
				$frequency
			);

		$frequencies =
			TutorHelper_Pro_Booking_Recurrence::
				get_frequencies();

		return isset(
			$frequencies[ $frequency ]
		)
			? sanitize_text_field(
				$frequencies[
					$frequency
				]
			)
			: sanitize_text_field(
				$frequency
			);
	}

	/**
	 * Format a stored series date for email.
	 *
	 * @param string $date          Date in Y-m-d format.
	 * @param string $timezone_name Timezone.
	 *
	 * @return string
	 */
	private static function format_series_date(
		$date,
		$timezone_name
	) {
		$date =
			sanitize_text_field(
				$date
			);

		$timezone_name =
			sanitize_text_field(
				$timezone_name
			);

		try {
			$timezone =
				new DateTimeZone(
					$timezone_name
				);

			$parsed =
				new DateTimeImmutable(
					$date . ' 12:00:00',
					$timezone
				);
		} catch ( Exception $exception ) {
			return $date;
		}

		return wp_date(
			'l j F Y',
			$parsed->getTimestamp(),
			$timezone
		);
	}

	/**
	 * Return a readable booking status.
	 *
	 * @param string $status Status key.
	 *
	 * @return string
	 */
	private static function get_status_label(
		$status
	) {
		$status =
			sanitize_key(
				$status
			);

		$labels = array(
			'confirmed' =>
				__(
					'Confirmed',
					'tutorhelper-pro'
				),

			'unconfirmed' =>
				__(
					'Awaiting confirmation',
					'tutorhelper-pro'
				),

			'cancelled' =>
				__(
					'Cancelled',
					'tutorhelper-pro'
				),
		);

		return isset(
			$labels[ $status ]
		)
			? $labels[ $status ]
			: ucwords(
				str_replace(
					'_',
					' ',
					$status
				)
			);
	}
}
