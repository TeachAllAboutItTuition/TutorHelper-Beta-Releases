<?php
/**
 * TutorHelper Pro recurring booking planner.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates recurring booking occurrence plans.
 *
 * This service plans dates only. It does not create
 * Core booking records.
 */
final class TutorHelper_Pro_Booking_Recurrence {

	/**
	 * Daily recurrence.
	 *
	 * @var string
	 */
	const FREQUENCY_DAILY = 'daily';

	/**
	 * Monday-Friday recurrence.
	 *
	 * @var string
	 */
	const FREQUENCY_WEEKDAYS = 'weekdays';

	/**
	 * Weekly recurrence.
	 *
	 * @var string
	 */
	const FREQUENCY_WEEKLY = 'weekly';

	/**
	 * Every two weeks.
	 *
	 * @var string
	 */
	const FREQUENCY_FORTNIGHTLY = 'fortnightly';

	/**
	 * Return supported frequencies.
	 *
	 * @return array
	 */
	public static function get_frequencies() {
		return array(
			self::FREQUENCY_DAILY =>
				__(
					'Daily',
					'tutorhelper-pro'
				),

			self::FREQUENCY_WEEKDAYS =>
				__(
					'Weekdays',
					'tutorhelper-pro'
				),

			self::FREQUENCY_WEEKLY =>
				__(
					'Weekly',
					'tutorhelper-pro'
				),

			self::FREQUENCY_FORTNIGHTLY =>
				__(
					'Fortnightly',
					'tutorhelper-pro'
				),
		);
	}


    	/**
	 * Parse an exact recurrence date.
	 *
	 * @param mixed $value Raw date.
	 *
	 * @return DateTimeImmutable|WP_Error
	 */
	private static function parse_date(
		$value
	) {
		$value =
			sanitize_text_field(
				(string) $value
			);

		$date =
			DateTimeImmutable::
				createFromFormat(
					'!Y-m-d',
					$value,
					new DateTimeZone(
						'UTC'
					)
				);

		$errors =
			DateTimeImmutable::
				getLastErrors();

		if (
			false === $date
			|| (
				is_array( $errors )
				&& (
					0 < $errors[
						'warning_count'
					]
					|| 0 < $errors[
						'error_count'
					]
				)
			)
			|| $date->format( 'Y-m-d' )
				!== $value
		) {
			return new WP_Error(
				'tutorhelper_pro_recurrence_date_invalid',
				__(
					'Enter a valid recurrence date.',
					'tutorhelper-pro'
				)
			);
		}

		return $date;
	}


    	/**
	 * Generate recurrence dates inclusively.
	 *
	 * Weekly and fortnightly recurrence starts on
	 * the supplied start date.
	 *
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param string $frequency  Recurrence frequency.
	 *
	 * @return array|WP_Error
	 */
	public static function generate_dates(
		$start_date,
		$end_date,
		$frequency
	) {
		$start =
			self::parse_date(
				$start_date
			);

		if ( is_wp_error( $start ) ) {
			return $start;
		}

		$end =
			self::parse_date(
				$end_date
			);

		if ( is_wp_error( $end ) ) {
			return $end;
		}

		if ( $end < $start ) {
			return new WP_Error(
				'tutorhelper_pro_recurrence_end_before_start',
				__(
					'The recurrence end date must not be before its start date.',
					'tutorhelper-pro'
				)
			);
		}

		$frequency =
			sanitize_key(
				$frequency
			);

		if (
			! array_key_exists(
				$frequency,
				self::get_frequencies()
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_recurrence_frequency_invalid',
				__(
					'Select a valid recurrence frequency.',
					'tutorhelper-pro'
				)
			);
		}

		$dates = array();

		switch ( $frequency ) {

			case self::FREQUENCY_WEEKLY:
				$interval =
					new DateInterval(
						'P7D'
					);

				for (
					$current = $start;
					$current <= $end;
					$current =
						$current->add(
							$interval
						)
				) {
					$dates[] =
						$current->format(
							'Y-m-d'
						);
				}

				break;

			case self::FREQUENCY_FORTNIGHTLY:
				$interval =
					new DateInterval(
						'P14D'
					);

				for (
					$current = $start;
					$current <= $end;
					$current =
						$current->add(
							$interval
						)
				) {
					$dates[] =
						$current->format(
							'Y-m-d'
						);
				}

				break;

			case self::FREQUENCY_WEEKDAYS:
				$interval =
					new DateInterval(
						'P1D'
					);

				for (
					$current = $start;
					$current <= $end;
					$current =
						$current->add(
							$interval
						)
				) {
					$weekday =
						(int) $current->format(
							'N'
						);

					if ( 5 >= $weekday ) {
						$dates[] =
							$current->format(
								'Y-m-d'
							);
					}
				}

				break;

			case self::FREQUENCY_DAILY:
				$interval =
					new DateInterval(
						'P1D'
					);

				for (
					$current = $start;
					$current <= $end;
					$current =
						$current->add(
							$interval
						)
				) {
					$dates[] =
						$current->format(
							'Y-m-d'
						);
				}

				break;
		}

		return $dates;
	}


    	/**
	 * Return exclusions affecting one date.
	 *
	 * @param string $date       Occurrence date.
	 * @param array  $exclusions Core exclusions.
	 *
	 * @return array
	 */
	private static function get_date_exclusions(
		$date,
		$exclusions
	) {
		$matches = array();

		foreach ( $exclusions as $exclusion ) {

			if (
				! is_object( $exclusion )
				|| empty(
					$exclusion->start_date
				)
				|| empty(
					$exclusion->end_date
				)
			) {
				continue;
			}

			if (
				$exclusion->start_date
					<= $date
				&& $exclusion->end_date
					>= $date
			) {
				$matches[] = $exclusion;
			}
		}

		return $matches;
	}


    	/**
	 * Build a recurrence plan.
	 *
	 * Supported arguments:
	 *
	 * - tutor_user_id
	 * - start_date
	 * - end_date
	 * - frequency
	 * - exclude_outside_term_time
	 * - exclude_public_holidays
	 *
	 * Tutor unavailable dates are always skipped.
	 *
	 * @param array $args Recurrence arguments.
	 *
	 * @return array|WP_Error
	 */
	public static function plan(
		$args
	) {
		$args = wp_parse_args(
			is_array( $args )
				? $args
				: array(),
			array(
				'tutor_user_id' =>
					0,

				'start_date' =>
					'',

				'end_date' =>
					'',

				'frequency' =>
					self::FREQUENCY_WEEKLY,

				'exclude_outside_term_time' =>
					false,

				'exclude_public_holidays' =>
					false,
			)
		);

		$tutor_user_id =
			absint(
				$args['tutor_user_id']
			);

		if (
			! $tutor_user_id
			|| ! get_user_by(
				'id',
				$tutor_user_id
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_recurrence_tutor_invalid',
				__(
					'The tutor could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$dates =
			self::generate_dates(
				$args['start_date'],
				$args['end_date'],
				$args['frequency']
			);

		if ( is_wp_error( $dates ) ) {
			return $dates;
		}

		$exclusions =
			TutorHelper_Date_Exclusions::
				get_all(
					array(
						'tutor_user_id' =>
							$tutor_user_id,

						'active_only' =>
							true,

						'range_start' =>
							$args['start_date'],

						'range_end' =>
							$args['end_date'],
					)
				);

		if ( is_wp_error( $exclusions ) ) {
			return $exclusions;
		}

		$exclude_outside_term_time =
			! empty(
				$args[
					'exclude_outside_term_time'
				]
			);

		$exclude_public_holidays =
			! empty(
				$args[
					'exclude_public_holidays'
				]
			);

		$occurrences = array();

		$included_count = 0;
		$skipped_count  = 0;

		foreach ( $dates as $date ) {

			$matching =
				self::get_date_exclusions(
					$date,
					$exclusions
				);

			$skip_reason = '';
			$skip_label  = '';

			foreach ( $matching as $exclusion ) {

				$type =
					sanitize_key(
						$exclusion
							->exclusion_type
					);

				/*
				 * Tutor leave/unavailability always wins.
				 */
				if (
					TutorHelper_Date_Exclusions::
						TYPE_UNAVAILABLE
					=== $type
				) {
					$skip_reason =
						'tutor_unavailable';

					$skip_label =
						sanitize_text_field(
							$exclusion->title
						);

					break;
				}

				if (
					$exclude_outside_term_time
					&& TutorHelper_Date_Exclusions::
						TYPE_OUTSIDE_TERM_TIME
						=== $type
				) {
					$skip_reason =
						'outside_term_time';

					$skip_label =
						sanitize_text_field(
							$exclusion->title
						);
				}

				if (
					''
						=== $skip_reason
					&& $exclude_public_holidays
					&& TutorHelper_Date_Exclusions::
						TYPE_HOLIDAY
						=== $type
				) {
					$skip_reason =
						'public_holiday';

					$skip_label =
						sanitize_text_field(
							$exclusion->title
						);
				}
			}

			$should_create =
				'' === $skip_reason;

			if ( $should_create ) {
				$included_count++;
			} else {
				$skipped_count++;
			}

			$occurrences[] = array(
				'date' =>
					$date,

				'should_create' =>
					$should_create,

				'skip_reason' =>
					$skip_reason,

				'skip_label' =>
					$skip_label,
			);
		}

		return array(
			'tutor_user_id' =>
				$tutor_user_id,

			'start_date' =>
				sanitize_text_field(
					$args['start_date']
				),

			'end_date' =>
				sanitize_text_field(
					$args['end_date']
				),

			'frequency' =>
				sanitize_key(
					$args['frequency']
				),

			'exclude_outside_term_time' =>
				$exclude_outside_term_time,

			'exclude_public_holidays' =>
				$exclude_public_holidays,

			'considered_count' =>
				count( $dates ),

			'included_count' =>
				$included_count,

			'skipped_count' =>
				$skipped_count,

			'occurrences' =>
				$occurrences,
		);
	}
}
