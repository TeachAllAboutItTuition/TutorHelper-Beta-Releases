<?php
/**
 * TutorHelper Pro booking series creation service.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates recurring booking series using Core booking services.
 */
final class TutorHelper_Pro_Booking_Series_Create {

	/**
	 * Whether normal individual booking confirmations
	 * are currently being suppressed.
	 *
	 * @var bool
	 */
	private static $suppress_confirmations = false;

	/**
	 * Create a recurring booking series.
	 *
	 * @param array $booking_data   Core booking form data.
	 * @param array $recurrence     Recurrence settings.
	 * @param int   $tutor_user_id  Tutor creating the series.
	 *
	 * @return array|WP_Error
	 */
	public static function create(
		$booking_data,
		$recurrence,
		$tutor_user_id
	) {
		$booking_data =
			is_array( $booking_data )
				? $booking_data
				: array();

		$recurrence =
			is_array( $recurrence )
				? $recurrence
				: array();

		$tutor_user_id =
			absint(
				$tutor_user_id
			);

		$start_date =
			isset(
				$booking_data['booking_date']
			)
				? sanitize_text_field(
					$booking_data['booking_date']
				)
				: '';

		$end_date =
			isset(
				$recurrence['end_date']
			)
				? sanitize_text_field(
					$recurrence['end_date']
				)
				: '';

		$frequency =
			isset(
				$recurrence['frequency']
			)
				? sanitize_key(
					$recurrence['frequency']
				)
				: '';

		$exclude_term =
			! empty(
				$recurrence[
					'exclude_outside_term_time'
				]
			);

		$exclude_holidays =
			! empty(
				$recurrence[
					'exclude_public_holidays'
				]
			);

		/*
		 * Rebuild the authoritative plan.
		 */
		$plan =
			TutorHelper_Pro_Booking_Recurrence::
				plan(
					array(
						'tutor_user_id' =>
							$tutor_user_id,

						'start_date' =>
							$start_date,

						'end_date' =>
							$end_date,

						'frequency' =>
							$frequency,

						'exclude_outside_term_time' =>
							$exclude_term,

						'exclude_public_holidays' =>
							$exclude_holidays,
					)
				);

		if ( is_wp_error( $plan ) ) {
			return $plan;
		}

		if (
			empty(
				$plan['included_count']
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_no_occurrences',
				__(
					'No lessons remain in this recurring booking after exclusions are applied.',
					'tutorhelper-pro'
				)
			);
		}

        $plan =
            self::preflight(
                $plan,
                $booking_data,
                $tutor_user_id
            );

        if ( is_wp_error( $plan ) ) {
            return $plan;
        }

        if (
            empty(
                $plan['included_count']
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_booking_series_no_available_occurrences',
                __(
                    'No lessons could be created because every occurrence was unavailable.',
                    'tutorhelper-pro'
                )
            );
        }

		/*
		 * Create the parent series definition first.
		 */
		$series_id =
			TutorHelper_Pro_Booking_Series::
				create(
					array(
						'student_user_id' =>
							isset(
								$booking_data[
									'student_user_id'
								]
							)
								? absint(
									$booking_data[
										'student_user_id'
									]
								)
								: 0,

						'tutor_user_id' =>
							$tutor_user_id,

						'booking_type_id' =>
							isset(
								$booking_data[
									'booking_type_id'
								]
							)
								? absint(
									$booking_data[
										'booking_type_id'
									]
								)
								: 0,

						'start_date' =>
							$start_date,

						'end_date' =>
							$end_date,

						'frequency' =>
							$frequency,

						'start_time' =>
							isset(
								$booking_data[
									'start_time'
								]
							)
								? sanitize_text_field(
									$booking_data[
										'start_time'
									]
								)
								: '',

						'end_time' =>
							isset(
								$booking_data[
									'end_time'
								]
							)
								? sanitize_text_field(
									$booking_data[
										'end_time'
									]
								)
								: '',

						'timezone' =>
							isset(
								$booking_data[
									'timezone'
								]
							)
								? sanitize_text_field(
									$booking_data[
										'timezone'
									]
								)
								: '',

						'location_type' =>
							isset(
								$booking_data[
									'location_type'
								]
							)
								? sanitize_key(
									$booking_data[
										'location_type'
									]
								)
								: '',

						'location_details' =>
							isset(
								$booking_data[
									'location_details'
								]
							)
								? sanitize_textarea_field(
									$booking_data[
										'location_details'
									]
								)
								: '',

						'booking_status' =>
							isset(
								$booking_data['status']
							)
								? sanitize_key(
									$booking_data['status']
								)
								: '',

						'exclude_outside_term_time' =>
							$exclude_term,

						'exclude_public_holidays' =>
							$exclude_holidays,

						'notes' =>
							isset(
								$booking_data['notes']
							)
								? sanitize_textarea_field(
									$booking_data['notes']
								)
								: '',
					)
				);

		if ( is_wp_error( $series_id ) ) {
			return $series_id;
		}

		$created_booking_ids = array();

		self::$suppress_confirmations =
			true;

		add_filter(
			'tutorhelper_booking_send_student_confirmation',
			array(
				__CLASS__,
				'suppress_confirmation',
			),
			10,
			3
		);

		try {

			foreach (
				$plan['occurrences']
				as $occurrence
			) {
				if (
					empty(
						$occurrence[
							'should_create'
						]
					)
				) {
					continue;
				}

				$occurrence_date =
					sanitize_text_field(
						$occurrence['date']
					);

				$occurrence_data =
					$booking_data;

				$occurrence_data[
					'booking_date'
				] = $occurrence_date;

				$result =
					TutorHelper_Tutor_Booking_Save::
						save(
							$occurrence_data,
							$tutor_user_id
						);

				if ( is_wp_error( $result ) ) {

					TutorHelper_Logger::warning(
						'Recurring booking series creation stopped.',
						array(
							'series_id' =>
								absint(
									$series_id
								),

							'tutor_user_id' =>
								$tutor_user_id,

							'occurrence_date' =>
								$occurrence_date,

							'error_code' =>
								$result
									->get_error_code(),
						)
					);

					return $result;
				}

				$booking_id =
					isset(
						$result['booking_id']
					)
						? absint(
							$result[
								'booking_id'
							]
						)
						: 0;

				if ( ! $booking_id ) {
					return new WP_Error(
						'tutorhelper_pro_booking_series_booking_missing',
						__(
							'A recurring lesson was created but its booking record could not be identified.',
							'tutorhelper-pro'
						)
					);
				}

				$link =
					TutorHelper_Pro_Booking_Series::
						add_booking(
							$series_id,
							$booking_id,
							$occurrence_date
						);

				if ( is_wp_error( $link ) ) {
					return $link;
				}

				$created_booking_ids[] =
					$booking_id;
			}

		} finally {

			self::$suppress_confirmations =
				false;

			remove_filter(
				'tutorhelper_booking_send_student_confirmation',
				array(
					__CLASS__,
					'suppress_confirmation',
				),
				10
			);
		}

		if ( empty( $created_booking_ids ) ) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_empty',
				__(
					'No lessons were created for this recurring booking.',
					'tutorhelper-pro'
				)
			);
		}

        $email_result =
	TutorHelper_Pro_Booking_Series_Email::
		send(
			$series_id,
			reset(
				$created_booking_ids
			),
			count(
				$created_booking_ids
			),
			absint(
				$plan[
					'skipped_count'
				]
			)
		);

        if ( is_wp_error( $email_result ) ) {
            TutorHelper_Logger::warning(
                'Recurring booking series was created but its student email failed.',
                array(
                    'series_id' =>
                        absint(
                            $series_id
                        ),

                    'booking_count' =>
                        count(
                            $created_booking_ids
                        ),

                    'error_code' =>
                        $email_result
                            ->get_error_code(),
                )
            );
        }

		TutorHelper_Logger::success(
			'Recurring booking series created.',
			array(
				'series_id' =>
					absint(
						$series_id
					),

				'tutor_user_id' =>
					$tutor_user_id,

				'booking_count' =>
					count(
						$created_booking_ids
					),

				'skipped_count' =>
					absint(
						$plan[
							'skipped_count'
						]
					),
			)
		);

		return array(
			'booking_id' =>
				reset(
					$created_booking_ids
				),

			'series_id' =>
				absint(
					$series_id
				),

			'booking_ids' =>
				$created_booking_ids,

			'created_count' =>
				count(
					$created_booking_ids
				),

			'skipped_count' =>
				absint(
					$plan[
						'skipped_count'
					]
				),

			'notice' =>
				'recurring_saved',
		);
	}

	/**
	 * Suppress normal individual student confirmations
	 * while a series is being created.
	 *
	 * @param bool  $send        Current send decision.
	 * @param int   $booking_id  Booking ID.
	 * @param array $insert_data Stored booking data.
	 *
	 * @return bool
	 */
	public static function suppress_confirmation(
		$send,
		$booking_id,
		$insert_data
	) {
		unset(
			$booking_id,
			$insert_data
		);

		if (
			self::$suppress_confirmations
		) {
			return false;
		}

		return $send;
	}


    /**
     * Preflight every occurrence before creating any records.
     *
     * Core booking conditions remain authoritative. Warnings do not
     * prevent tutor-created bookings, but blocking conditions do.
     *
     * @param array $plan          Recurrence plan.
     * @param array $booking_data  Core booking data.
     * @param int   $tutor_user_id Tutor ID.
     *
     * @return array|WP_Error
     */
    private static function preflight(
        $plan,
        $booking_data,
        $tutor_user_id
    ) {
        if (
            ! is_array( $plan )
            || empty( $plan['occurrences'] )
            || ! is_array(
                $plan['occurrences']
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_booking_series_plan_invalid',
                __(
                    'The recurring booking plan is invalid.',
                    'tutorhelper-pro'
                )
            );
        }

        $booking_type_id =
            isset(
                $booking_data['booking_type_id']
            )
                ? absint(
                    $booking_data['booking_type_id']
                )
                : 0;

        $start_time =
            isset(
                $booking_data['start_time']
            )
                ? sanitize_text_field(
                    $booking_data['start_time']
                )
                : '';

        $end_time =
            isset(
                $booking_data['end_time']
            )
                ? sanitize_text_field(
                    $booking_data['end_time']
                )
                : '';

        $timezone =
            isset(
                $booking_data['timezone']
            )
                ? sanitize_text_field(
                    $booking_data['timezone']
                )
                : wp_timezone()->getName();

        $location_type =
            isset(
                $booking_data['location_type']
            )
                ? sanitize_key(
                    $booking_data['location_type']
                )
                : '';

        foreach (
            $plan['occurrences']
            as $index => $occurrence
        ) {
            if (
                empty(
                    $occurrence['should_create']
                )
            ) {
                continue;
            }

            $date =
                isset(
                    $occurrence['date']
                )
                    ? sanitize_text_field(
                        $occurrence['date']
                    )
                    : '';

            $evaluation =
                TutorHelper_Booking_Conditions::
                    evaluate(
                        array(
                            'tutor_user_id' =>
                                absint(
                                    $tutor_user_id
                                ),

                            'booking_type_id' =>
                                $booking_type_id,

                            'booking_start' =>
                                $date
                                . ' '
                                . $start_time,

                            'booking_end' =>
                                $date
                                . ' '
                                . $end_time,

                            'timezone' =>
                                $timezone,

                            'location_type' =>
                                $location_type,

                            'exclude_booking_id' =>
                                0,
                        )
                    );

            if ( is_wp_error( $evaluation ) ) {
                return $evaluation;
            }

            if (
                ! empty(
                    $evaluation['can_tutor_save']
                )
            ) {
                continue;
            }

            $blocking =
                isset(
                    $evaluation[
                        'blocking_conditions'
                    ]
                )
                && is_array(
                    $evaluation[
                        'blocking_conditions'
                    ]
                )
                    ? $evaluation[
                        'blocking_conditions'
                    ]
                    : array();

            $condition_code = '';

            foreach (
                $blocking
                as $condition
            ) {
                if (
                    is_array( $condition )
                    && ! empty(
                        $condition['code']
                    )
                ) {
                    $condition_code =
                        sanitize_key(
                            $condition['code']
                        );

                    break;
                }
            }

            TutorHelper_Logger::warning(
                'Recurring booking preflight blocked an occurrence.',
                array(
                    'tutor_user_id' =>
                        absint(
                            $tutor_user_id
                        ),

                    'booking_type_id' =>
                        $booking_type_id,

                    'occurrence_date' =>
                        $date,

                    'condition_code' =>
                        $condition_code,
                )
            );

            if (
                'booking_conflict'
                === $condition_code
            ) {
                $plan['occurrences'][ $index ][
                    'should_create'
                ] = false;

                $plan['occurrences'][ $index ][
                    'skip_reason'
                ] = 'booking_conflict';

                $plan['occurrences'][ $index ][
                    'skip_label'
                ] = __(
                    'Clashes with another booking',
                    'tutorhelper-pro'
                );

                continue;
            }

            return new WP_Error(
                'tutorhelper_pro_booking_series_blocked',
                sprintf(
                    /* translators: %s: booking date. */
                    __(
                        'A lesson could not be created on %s because a booking condition prevents it. No lessons in the series were created.',
                        'tutorhelper-pro'
                    ),
                    wp_date(
                        get_option(
                            'date_format'
                        ),
                        strtotime(
                            $date
                        )
                    )
                )
            );
        }

        $included_count = 0;
        $skipped_count  = 0;

        foreach (
            $plan['occurrences']
            as $occurrence
        ) {
            if (
                ! empty(
                    $occurrence['should_create']
                )
            ) {
                $included_count++;
            } else {
                $skipped_count++;
            }
        }

        $plan['included_count'] =
            $included_count;

        $plan['skipped_count'] =
            $skipped_count;

        return $plan;
    }


}
