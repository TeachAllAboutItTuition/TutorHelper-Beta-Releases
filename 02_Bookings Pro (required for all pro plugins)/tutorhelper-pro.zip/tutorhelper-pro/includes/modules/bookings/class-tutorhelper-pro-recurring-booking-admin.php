<?php
/**
 * TutorHelper Pro recurring booking admin UI.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Extends the Core tutor Add Booking form with recurrence controls.
 */
final class TutorHelper_Pro_Recurring_Booking_Admin {

	/**
	 * AJAX action used to preview a recurrence.
	 *
	 * @var string
	 */
	const PREVIEW_ACTION =
		'tutorhelper_pro_preview_booking_recurrence';

	/**
	 * Nonce action for recurrence previews.
	 *
	 * @var string
	 */
	const PREVIEW_NONCE =
		'tutorhelper_pro_booking_recurrence_preview';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'tutorhelper_tutor_booking_render_create_fields',
			array(
				__CLASS__,
				'render_create_fields',
			)
		);

		add_action(
			'tutorhelper_tutor_booking_render_create_summary',
			array(
				__CLASS__,
				'render_create_summary',
			)
		);

		add_action(
			'wp_ajax_' . self::PREVIEW_ACTION,
			array(
				__CLASS__,
				'handle_preview',
			)
		);

		add_action(
			'admin_enqueue_scripts',
			array(
				__CLASS__,
				'enqueue_assets',
			)
		);

		/*
		 * Safety guard for recurring bookings.
		 *
		 * Override the core plugin single booking feature to create
		 * a recurring submission 
		 */
		add_filter(
            'tutorhelper_tutor_booking_create_result',
            array(
                __CLASS__,
                'handle_recurring_submission',
            ),
            10,
            3
        );

        add_filter(
            'tutorhelper_tutor_booking_notice_messages',
            array(
                __CLASS__,
                'add_notice_messages',
            )
        );

	}


    /**
     * Add recurring booking notices.
     *
     * @param array $messages Existing notices.
     *
     * @return array
     */
    public static function add_notice_messages(
        $messages
    ) {
        $messages =
            is_array( $messages )
                ? $messages
                : array();

        $messages['recurring_saved'] =
            array(
                'type' =>
                    'success',

                'message' =>
                    __(
                        'The recurring booking was created successfully.',
                        'tutorhelper-pro'
                    ),
            );

        return $messages;
    }


	/**
	 * Render recurrence controls.
	 *
	 * @param array $form_state Core form values.
	 *
	 * @return void
	 */
	public static function render_create_fields(
		$form_state
	) {
		unset( $form_state );

		$frequencies =
			TutorHelper_Pro_Booking_Recurrence::
				get_frequencies();
		?>
		<section
			class="tutorhelper-tutor-booking-section tutorhelper-pro-recurrence"
			data-pro-recurrence
			aria-labelledby="tutorhelper-pro-recurrence-heading"
		>
			<header
				class="tutorhelper-tutor-booking-section__header"
			>
				<span
					class="dashicons dashicons-update"
					aria-hidden="true"
				></span>

				<div>
					<h3
						id="tutorhelper-pro-recurrence-heading"
					>
						<?php
						echo esc_html__(
							'Repeat this booking',
							'tutorhelper-pro'
						);
						?>
					</h3>

					<p>
						<?php
						echo esc_html__(
							'Create a regular lesson using the booking date above as the first occurrence.',
							'tutorhelper-pro'
						);
						?>
					</p>
				</div>
			</header>

			<div
				class="tutorhelper-tutor-booking-section__body"
			>
				<div
					class="tutorhelper-tutor-booking__field is-wide tutorhelper-pro-recurrence__toggle"
				>
					<label>
						<input
							type="checkbox"
							name="tutorhelper_pro_recurring"
							value="1"
							data-pro-recurrence-toggle
						/>

						<?php
						echo esc_html__(
							'Create a recurring booking',
							'tutorhelper-pro'
						);
						?>
					</label>
				</div>

				<div
					class="tutorhelper-pro-recurrence__options"
					data-pro-recurrence-options
					hidden
				>
					<div
						class="tutorhelper-tutor-booking__grid"
					>
						<div
							class="tutorhelper-tutor-booking__field"
						>
							<label
								for="tutorhelper-pro-recurrence-frequency"
							>
								<?php
								echo esc_html__(
									'Repeat',
									'tutorhelper-pro'
								);
								?>
							</label>

							<select
								id="tutorhelper-pro-recurrence-frequency"
								name="tutorhelper_pro_recurrence_frequency"
								data-pro-recurrence-field
							>
								<?php
								foreach (
									$frequencies
									as $value => $label
								) :
									?>
									<option
										value="<?php
										echo esc_attr(
											$value
										);
										?>"
										<?php
										selected(
											'weekly',
											$value
										);
										?>
									>
										<?php
										echo esc_html(
											$label
										);
										?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>

						<div
							class="tutorhelper-tutor-booking__field"
						>
							<label
								for="tutorhelper-pro-recurrence-end-date"
							>
								<?php
								echo esc_html__(
									'Repeat until',
									'tutorhelper-pro'
								);
								?>
							</label>

							<input
								type="date"
								id="tutorhelper-pro-recurrence-end-date"
								name="tutorhelper_pro_recurrence_end_date"
								data-pro-recurrence-field
							/>
						</div>
					</div>

					<fieldset
						class="tutorhelper-pro-recurrence__exclusions"
					>
						<legend>
							<?php
							echo esc_html__(
								'Skip dates',
								'tutorhelper-pro'
							);
							?>
						</legend>

						<label>
							<input
								type="checkbox"
								name="tutorhelper_pro_exclude_outside_term_time"
								value="1"
								data-pro-recurrence-field
							/>

							<?php
							echo esc_html__(
								'Term time only',
								'tutorhelper-pro'
							);
							?>
						</label>

						<label>
							<input
								type="checkbox"
								name="tutorhelper_pro_exclude_public_holidays"
								value="1"
								data-pro-recurrence-field
							/>

							<?php
							echo esc_html__(
								'Exclude public holidays',
								'tutorhelper-pro'
							);
							?>
						</label>

						<p class="description">
							<?php
							echo esc_html__(
								'Dates when you are unavailable are always excluded.',
								'tutorhelper-pro'
							);
							?>
						</p>
					</fieldset>
				</div>
			</div>
		</section>
		<?php
	}

	/**
	 * Render the recurring section of the Booking Summary.
	 *
	 * @param array $form_state Core form values.
	 *
	 * @return void
	 */
	public static function render_create_summary(
		$form_state
	) {
		unset( $form_state );
		?>
		<div
			class="tutorhelper-tutor-booking__field is-wide tutorhelper-pro-recurrence-summary"
			data-pro-recurrence-summary
			hidden
		>
			<div
				class="tutorhelper-pro-recurrence-summary__header"
			>
				<strong>
					<?php
					echo esc_html__(
						'Recurring booking',
						'tutorhelper-pro'
					);
					?>
				</strong>

				<span
					class="spinner"
					data-pro-recurrence-spinner
					aria-hidden="true"
				></span>
			</div>

			<p
				data-pro-recurrence-summary-text
			></p>

			<div
				class="tutorhelper-pro-recurrence-summary__counts"
				data-pro-recurrence-counts
			></div>

			<ul
				class="tutorhelper-pro-recurrence-summary__occurrences"
				data-pro-recurrence-occurrences
			></ul>

			<p
				class="description"
				data-pro-recurrence-status
				role="status"
				aria-live="polite"
			></p>
		</div>
		<?php
	}

	/**
	 * Return a live recurrence preview.
	 *
	 * @return void
	 */
	public static function handle_preview() {

		if (
			! current_user_can(
				TutorHelper_Booking_Hub::CAPABILITY
			)
		) {
			wp_send_json_error(
				array(
					'message' => __(
						'You are not allowed to preview recurring bookings.',
						'tutorhelper-pro'
					),
				),
				403
			);
		}

		check_ajax_referer(
			self::PREVIEW_NONCE,
			'nonce'
		);

		$start_date =
			self::get_post_value(
				'start_date'
			);

		$end_date =
			self::get_post_value(
				'end_date'
			);

        $booking_type_id =
            absint(
                self::get_post_value(
                    'booking_type_id'
                )
            );

        $start_time =
            self::get_post_value(
                'start_time'
            );

        $end_time =
            self::get_post_value(
                'end_time'
            );

        $timezone =
            self::get_post_value(
                'timezone'
            );

        $location_type =
            sanitize_key(
                self::get_post_value(
                    'location_type'
                )
            );

        if ( '' === $timezone ) {
            $timezone =
                wp_timezone()->getName();
        }

		$frequency =
			sanitize_key(
				self::get_post_value(
					'frequency'
				)
			);

		if (
			'' === $start_date
			|| '' === $end_date
			|| '' === $frequency
		) {
			wp_send_json_success(
				array(
					'complete' =>
						false,
				)
			);
		}

		$plan =
			TutorHelper_Pro_Booking_Recurrence::
				plan(
					array(
						'tutor_user_id' =>
							get_current_user_id(),

						'start_date' =>
							$start_date,

						'end_date' =>
							$end_date,

						'frequency' =>
							$frequency,

						'exclude_outside_term_time' =>
							self::get_post_flag(
								'exclude_outside_term_time'
							),

						'exclude_public_holidays' =>
							self::get_post_flag(
								'exclude_public_holidays'
							),
					)
				);

		if ( is_wp_error( $plan ) ) {
			wp_send_json_error(
				array(
					'message' =>
						$plan->get_error_message(),
				),
				400
			);
		}

        $preview_included_count = 0;
        $preview_skipped_count  = 0;

		$occurrences =
            array();

        $blocked_count = 0;

        foreach (
            $plan['occurrences']
            as $occurrence
        ) {
            $should_create =
                ! empty(
                    $occurrence[
                        'should_create'
                    ]
                );

            $skip_reason =
                isset(
                    $occurrence['skip_reason']
                )
                    ? sanitize_key(
                        $occurrence['skip_reason']
                    )
                    : '';

            $skip_label =
                isset(
                    $occurrence['skip_label']
                )
                    ? sanitize_text_field(
                        $occurrence['skip_label']
                    )
                    : '';

            $blocked = false;
            $block_reason = '';

            /*
            * Recurrence exclusions have already decided
            * not to create this occurrence, so there is no
            * need to run booking-condition checks for it.
            */
            if (
                $should_create
                && $booking_type_id
                && '' !== $start_time
                && '' !== $end_time
                && '' !== $location_type
            ) {
                $evaluation =
                    TutorHelper_Booking_Conditions::
                        evaluate(
                            array(
                                'tutor_user_id' =>
                                    get_current_user_id(),

                                'booking_type_id' =>
                                    $booking_type_id,

                                'booking_start' =>
                                    $occurrence['date']
                                    . ' '
                                    . $start_time,

                                'booking_end' =>
                                    $occurrence['date']
                                    . ' '
                                    . $end_time,

                                'timezone' =>
                                    $timezone,

                                'location_type' =>
                                    $location_type,

                                'exclude_booking_id' =>
                                    0,
                            )
                        );

                if ( is_wp_error( $evaluation ) ) {
                    wp_send_json_error(
                        array(
                            'message' =>
                                sanitize_text_field(
                                    $evaluation
                                        ->get_error_message()
                                ),
                        ),
                        400
                    );
                }

                if (
                    empty(
                        $evaluation[
                            'can_tutor_save'
                        ]
                    )
                ) {
                    $blocking_conditions =
                        isset(
                            $evaluation[
                                'blocking_conditions'
                            ]
                        )
                        && is_array(
                            $evaluation[
                                'blocking_conditions'
                            ]
                        )
                            ? $evaluation[
                                'blocking_conditions'
                            ]
                            : array();

                    foreach (
                        $blocking_conditions
                        as $condition
                    ) {
                        if (
                            ! is_array(
                                $condition
                            )
                            || empty(
                                $condition['code']
                            )
                        ) {
                            continue;
                        }

                        $code =
                            sanitize_key(
                                $condition['code']
                            );

                        if (
                            'booking_conflict'
                            === $code
                        ) {
                            $should_create = false;

                            $skip_reason =
                                'booking_conflict';

                            $skip_label =
                                __(
                                    'Clashes with another booking',
                                    'tutorhelper-pro'
                                );

                            break;
                        }

                        /*
                        * Any other blocking Core condition should
                        * also prevent this individual occurrence
                        * from being created.
                        */
                        $should_create = false;

                        $skip_reason =
                            $code;

                        $skip_label =
                            isset(
                                $condition['message']
                            )
                                ? sanitize_text_field(
                                    $condition['message']
                                )
                                : __(
                                    'Booking unavailable',
                                    'tutorhelper-pro'
                                );

                        break;
                    }
                }
            }


            if ( $should_create ) {
                $preview_included_count++;
            } else {
                $preview_skipped_count++;
            }

            $occurrences[] =
                array(
                    'date' =>
                        sanitize_text_field(
                            $occurrence['date']
                        ),

                    'shouldCreate' =>
                        $should_create,

                    'skipReason' =>
                        $skip_reason,

                    'skipLabel' =>
                        $skip_label,
                );
        }

		wp_send_json_success(
			array(
				'complete' =>
					true,

				'frequency' =>
					sanitize_key(
						$plan['frequency']
					),

				'consideredCount' =>
					absint(
						$plan[
							'considered_count'
						]
					),

				'includedCount' =>
                    absint(
                        $preview_included_count
                    ),

				'skippedCount' =>
                    absint(
                        $preview_skipped_count
                    ),

				'occurrences' =>
					$occurrences,
			)
		);
	}

	/**
     * Handle a recurring Add Booking submission.
     *
     * Returning null leaves normal single bookings to Core.
     *
     * @param mixed $result        Existing result.
     * @param array $data          Core booking data.
     * @param int   $tutor_user_id Tutor ID.
     *
     * @return mixed
     */
    public static function handle_recurring_submission(
        $result,
        $data,
        $tutor_user_id
    ) {
        if ( null !== $result ) {
            return $result;
        }

        if (
            ! isset(
                $_POST[
                    'tutorhelper_pro_recurring'
                ]
            )
        ) {
            return null;
        }

        $frequency =
            self::get_post_value(
                'tutorhelper_pro_recurrence_frequency'
            );

        $end_date =
            self::get_post_value(
                'tutorhelper_pro_recurrence_end_date'
            );

        return
            TutorHelper_Pro_Booking_Series_Create::
                create(
                    $data,
                    array(
                        'frequency' =>
                            $frequency,

                        'end_date' =>
                            $end_date,

                        'exclude_outside_term_time' =>
                            isset(
                                $_POST[
                                    'tutorhelper_pro_exclude_outside_term_time'
                                ]
                            ),

                        'exclude_public_holidays' =>
                            isset(
                                $_POST[
                                    'tutorhelper_pro_exclude_public_holidays'
                                ]
                            ),
                    ),
                    absint(
                        $tutor_user_id
                    )
                );
    }

	/**
	 * Enqueue recurrence UI assets.
	 *
	 * @param string $hook_suffix Current admin hook.
	 *
	 * @return void
	 */
	public static function enqueue_assets(
		$hook_suffix
	) {
		if (
			'toplevel_page_'
				. TutorHelper_Admin::MENU_SLUG
			!== $hook_suffix
		) {
			return;
		}

		$selected_tab =
			isset( $_GET['tab'] )
				&& ! is_array(
					$_GET['tab']
				)
					? sanitize_key(
						wp_unslash(
							$_GET['tab']
						)
					)
					: '';

		if (
			TutorHelper_Tutor_Booking_Admin::
				TAB_KEY
			!== $selected_tab
		) {
			return;
		}

		$css_path =
			TUTORHELPER_PRO_PATH
			. 'assets/css/tutorhelper-pro-admin.css';

		wp_enqueue_style(
			'tutorhelper-pro-admin',
			TUTORHELPER_PRO_URL
			. 'assets/css/tutorhelper-pro-admin.css',
			array(),
			file_exists( $css_path )
				? (string) filemtime(
					$css_path
				)
				: TUTORHELPER_PRO_VERSION
		);

		$js_path =
			TUTORHELPER_PRO_PATH
			. 'assets/js/tutorhelper-pro-recurring-booking.js';

		wp_enqueue_script(
			'tutorhelper-pro-recurring-booking',
			TUTORHELPER_PRO_URL
			. 'assets/js/tutorhelper-pro-recurring-booking.js',
			array(),
			file_exists( $js_path )
				? (string) filemtime(
					$js_path
				)
				: TUTORHELPER_PRO_VERSION,
			true
		);

		wp_localize_script(
			'tutorhelper-pro-recurring-booking',
			'tutorhelperProRecurrence',
			array(
				'ajaxUrl' =>
					admin_url(
						'admin-ajax.php'
					),

				'action' =>
					self::PREVIEW_ACTION,

				'nonce' =>
					wp_create_nonce(
						self::PREVIEW_NONCE
					),

				'labels' =>
					array(
						'lessons' => __(
							'lessons will be created',
							'tutorhelper-pro'
						),

						'skipped' => __(
							'dates will be skipped',
							'tutorhelper-pro'
						),

						'unavailable' => __(
							'Tutor unavailable',
							'tutorhelper-pro'
						),

						'termTime' => __(
							'Outside term time',
							'tutorhelper-pro'
						),

						'holiday' => __(
							'Public holiday',
							'tutorhelper-pro'
						),

						'failed' => __(
							'The recurring booking preview could not be calculated.',
							'tutorhelper-pro'
						),

                        'clash' => __(
                            'Clashes with another booking',
                            'tutorhelper-pro'
                        ),

                        'blocked' => __(
                            'This recurring booking cannot be created until the clashes are resolved.',
                            'tutorhelper-pro'
                        ),

                        'clashes' => __(
                            'clashes must be resolved',
                            'tutorhelper-pro'
                        ),
					),
			)
		);
	}

	/**
	 * Read one scalar POST value.
	 *
	 * @param string $key Key.
	 *
	 * @return string
	 */
	private static function get_post_value(
		$key
	) {
		if (
			! isset( $_POST[ $key ] )
			|| is_array( $_POST[ $key ] )
		) {
			return '';
		}

		return sanitize_text_field(
			wp_unslash(
				$_POST[ $key ]
			)
		);
	}

	/**
	 * Read one boolean POST flag.
	 *
	 * @param string $key Key.
	 *
	 * @return bool
	 */
	private static function get_post_flag(
		$key
	) {
		return isset( $_POST[ $key ] )
			&& ! is_array( $_POST[ $key ] )
			&& 1 === absint(
				wp_unslash(
					$_POST[ $key ]
				)
			);
	}
}
