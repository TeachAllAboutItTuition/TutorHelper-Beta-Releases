<?php
/**
 * Student late reminder email service.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Registers, prepares and sends student late reminders.
 */
final class TutorHelper_Pro_Late_Reminder_Email {

	/**
	 * Email template key.
	 *
	 * @var string
	 */
	const TEMPLATE_KEY =
		'pro_booking_late_reminder';


	/**
	 * Register the Pro email template.
	 *
	 * @return void
	 */
	public static function register() {

		TutorHelper_Email_Templates::register(
			self::TEMPLATE_KEY,
			array(
				'module' =>
					'bookings',

				'label' =>
					__(
						'Late lesson reminder',
						'tutorhelper-pro'
					),

				'description' =>
					__(
						'Sent manually when a student has not arrived for a lesson.',
						'tutorhelper-pro'
					),

				'heading' =>
					__(
						'Lesson Reminder',
						'tutorhelper-pro'
					),

				'recipient' =>
					'student',

				'enabled' =>
					true,

				'subject' =>
					__(
						'Reminder: your {booking_type} lesson today',
						'tutorhelper-pro'
					),

				'body' =>
					'{late_reminder_message}',

				'placeholders' =>
					array(
						'{student_name}',
						'{booking_type}',
						'{lesson_date}',
						'{lesson_time}',
						'{location_type}',
						'{joining_details}',
						'{tutor_name}',
						'{site_name}',
						'{late_reminder_message}',
					),
			)
		);
	}

    /**
     * Prepare one late reminder.
     *
     * @param int $booking_id Booking ID.
     *
     * @return array|WP_Error
     */
    public static function prepare(
        $booking_id
    ) {

        $booking_id =
            absint( $booking_id );

        $context =
            TutorHelper_Booking_Email_Context::build(
                $booking_id
            );

        if ( is_wp_error( $context ) ) {
            return $context;
        }

        $booking =
            $context['booking'];

        if (
            TutorHelper_Booking_Records::
                STATUS_CANCELLED
            === sanitize_key(
                $booking->status
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_late_reminder_cancelled',
                __(
                    'A late reminder cannot be sent for a cancelled lesson.',
                    'tutorhelper-pro'
                )
            );
        }

        $student =
            $context['student'];

        $student_first_name =
            trim(
                sanitize_text_field(
                    $student->first_name
                )
            );

        if ( '' === $student_first_name ) {
            $student_first_name =
                sanitize_text_field(
                    $student->display_name
                );
        }

        $lesson_start_time =
            self::get_lesson_start_time(
                $booking
            );

        $parent =
            TutorHelper_Students::
                get_parent_details(
                    absint(
                        $booking->student_user_id
                    )
                );

        $parent_email =
            isset( $parent['email'] )
                ? sanitize_email(
                    $parent['email']
                )
                : '';

        $student_email =
            sanitize_email(
                $context['student_email']
            );

        if (
            $parent_email
            && $parent_email === $student_email
        ) {
            $parent_email = '';
        }

        $message =
            self::build_default_message(
                $student_first_name,
                $lesson_start_time,
                $context['placeholders']
            );

        $placeholders =
            $context['placeholders'];

        $placeholders[
            '{late_reminder_message}'
        ] = $message;

        $rendered =
            TutorHelper_Email_Renderer::render(
                self::TEMPLATE_KEY,
                $placeholders
            );

        if ( is_wp_error( $rendered ) ) {
            return $rendered;
        }

        return array(
            'booking' =>
                $booking,

            'context' =>
                $context,

            'student_email' =>
                $student_email,

            'parent_email' =>
                $parent_email,

            'subject' =>
                $rendered['subject'],

            'message' =>
                $message,

            'placeholders' =>
                $placeholders,
        );
    }


    /**
     * Build the default late reminder message.
     *
     * @param string $student_first_name Student first name.
     * @param string $lesson_start_time  Scheduled lesson start time.
     * @param array  $placeholders       Booking placeholders.
     *
     * @return string
     */
    private static function build_default_message(
        $student_first_name,
        $lesson_start_time,
        $placeholders
    ) {

        $booking_type =
            isset(
                $placeholders[
                    '{booking_type}'
                ]
            )
                ? $placeholders[
                    '{booking_type}'
                ]
                : '';

        $lesson_date =
            isset(
                $placeholders[
                    '{lesson_date}'
                ]
            )
                ? $placeholders[
                    '{lesson_date}'
                ]
                : '';

        $lesson_time =
            isset(
                $placeholders[
                    '{lesson_time}'
                ]
            )
                ? $placeholders[
                    '{lesson_time}'
                ]
                : '';

        $location_type =
            isset(
                $placeholders[
                    '{location_type}'
                ]
            )
                ? $placeholders[
                    '{location_type}'
                ]
                : '';

        $joining_details =
            isset(
                $placeholders[
                    '{joining_details}'
                ]
            )
                ? trim(
                    $placeholders[
                        '{joining_details}'
                    ]
                )
                : '';

        $tutor_name =
            isset(
                $placeholders[
                    '{tutor_name}'
                ]
            )
                ? $placeholders[
                    '{tutor_name}'
                ]
                : '';

        $message =
            sprintf(
                /* translators: 1: student name, 2: lesson start time. */
                __(
                    "Dear %1\$s,\n\nThis is just a quick email to remind you that our lesson was due to start at %2\$s.\n\nI've included the details of our lesson below, but please let me know if you're having trouble attending.\n\nLesson: %3\$s\nDate: %4\$s\nTime: %5\$s\nLocation: %6\$s",
                    'tutorhelper-pro'
                ),
                $student_first_name,
                $lesson_start_time,
                $booking_type,
                $lesson_date,
                $lesson_time,
                $location_type
            );

        if ( '' !== $joining_details ) {
            $message .=
                "\n\n"
                . $joining_details;
        }

        $message .=
            "\n\n"
            . sprintf(
                /* translators: %s: tutor name. */
                __(
                    "Best wishes,\n%s",
                    'tutorhelper-pro'
                ),
                $tutor_name
            );

        return $message;
    }


    /**
     * Format the scheduled lesson start time.
     *
     * @param object $booking Booking record.
     *
     * @return string
     */
    private static function get_lesson_start_time(
        $booking
    ) {

        if (
            empty(
                $booking->booking_start
            )
        ) {
            return '';
        }

        $timezone_name =
            ! empty(
                $booking->timezone
            )
                ? sanitize_text_field(
                    $booking->timezone
                )
                : wp_timezone_string();

        if ( ! $timezone_name ) {
            $timezone_name = 'UTC';
        }

        try {

            $timezone =
                new DateTimeZone(
                    $timezone_name
                );

            $start =
                new DateTimeImmutable(
                    $booking->booking_start,
                    new DateTimeZone(
                        'UTC'
                    )
                );

            $start =
                $start->setTimezone(
                    $timezone
                );

        } catch ( Exception $exception ) {
            return '';
        }

        return wp_date(
            get_option(
                'time_format'
            ),
            $start->getTimestamp(),
            $timezone
        );
    }

    /**
     * Send a late reminder.
     *
     * @param int    $booking_id Booking ID.
     * @param string $message    Tutor-reviewed message.
     *
     * @return true|WP_Error
     */
    public static function send(
        $booking_id,
        $message
    ) {

        $prepared =
            self::prepare(
                $booking_id
            );

        if ( is_wp_error( $prepared ) ) {
            return $prepared;
        }

        $message =
            sanitize_textarea_field(
                $message
            );

        if ( '' === trim( $message ) ) {
            return new WP_Error(
                'tutorhelper_pro_late_reminder_empty',
                __(
                    'The reminder message cannot be empty.',
                    'tutorhelper-pro'
                )
            );
        }

        $placeholders =
            $prepared['placeholders'];

        $placeholders[
            '{late_reminder_message}'
        ] = $message;

        $headers = array();

        if (
            ! empty(
                $prepared['parent_email']
            )
        ) {
            $headers[] =
                'Bcc: '
                . $prepared[
                    'parent_email'
                ];
        }

        $context =
            $prepared['context'];

        $send_result =
            TutorHelper_Email_Sender::send(
                self::TEMPLATE_KEY,
                $prepared['student_email'],
                $placeholders,
                array(
                    'reply_to_email' =>
                        $context['tutor_email'],

                    'reply_to_name' =>
                        $context['placeholders'][
                            '{tutor_name}'
                        ],

                    'headers' =>
                        $headers,

                    'context' =>
                        array(
                            'booking_id' =>
                                absint(
                                    $booking_id
                                ),

                            'action' =>
                                'late_reminder',
                        ),
                )
            );

            if ( is_wp_error( $send_result ) ) {
                return $send_result;
            }

            $log_result =
                self::log_send(
                    $booking_id,
                    get_current_user_id(),
                    $prepared['student_email'],
                    $prepared['parent_email']
                );

            if ( is_wp_error( $log_result ) ) {

                /*
                * The email itself has already been sent.
                * Log the secondary failure without falsely telling
                * the tutor that sending failed.
                */
                if (
                    class_exists(
                        'TutorHelper_Logger'
                    )
                ) {
                    TutorHelper_Logger::error(
                        'Late reminder sent but reminder history could not be stored.',
                        array(
                            'booking_id' =>
                                absint(
                                    $booking_id
                                ),

                            'error' =>
                                $log_result->
                                    get_error_message(),
                        )
                    );
                }
            }

            return true;


    }


    /**
     * Record a successfully sent late reminder.
     *
     * @param int    $booking_id      Booking ID.
     * @param int    $sent_by_user_id User who sent the reminder.
     * @param string $student_email   Student email address.
     * @param string $parent_email    Parent email address, if present.
     *
     * @return true|WP_Error
     */
    private static function log_send(
        $booking_id,
        $sent_by_user_id,
        $student_email,
        $parent_email = ''
    ) {

        global $wpdb;

        $booking_id =
            absint( $booking_id );

        $sent_by_user_id =
            absint( $sent_by_user_id );

        if (
            ! $booking_id
            || ! $sent_by_user_id
        ) {
            return new WP_Error(
                'tutorhelper_pro_late_reminder_log_invalid',
                __(
                    'The late reminder could not be logged.',
                    'tutorhelper-pro'
                )
            );
        }

        $table_name =
            TutorHelper_Pro_Database::get_table_name(
                'late_reminder_log'
            );

        $inserted =
            $wpdb->insert(
                $table_name,
                array(
                    'booking_id' =>
                        $booking_id,

                    'sent_at' =>
                        current_time(
                            'mysql',
                            true
                        ),

                    'sent_by_user_id' =>
                        $sent_by_user_id,

                    'student_email' =>
                        sanitize_email(
                            $student_email
                        ),

                    'parent_email' =>
                        sanitize_email(
                            $parent_email
                        ),
                ),
                array(
                    '%d',
                    '%s',
                    '%d',
                    '%s',
                    '%s',
                )
            );

        if ( false === $inserted ) {
            return new WP_Error(
                'tutorhelper_pro_late_reminder_log_failed',
                __(
                    'The late reminder was sent but its history could not be recorded.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }


    /**
     * Retrieve reminder history for one booking.
     *
     * @param int $booking_id Booking ID.
     *
     * @return array
     */
    public static function get_history(
        $booking_id
    ) {

        global $wpdb;

        $booking_id =
            absint( $booking_id );

        if ( ! $booking_id ) {
            return array();
        }

        $table_name =
            TutorHelper_Pro_Database::get_table_name(
                'late_reminder_log'
            );

        $results =
            $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT *
                    FROM %i
                    WHERE booking_id = %d
                    ORDER BY sent_at DESC,
                    id DESC',
                    $table_name,
                    $booking_id
                )
            );

        return is_array( $results )
            ? $results
            : array();
    }

    /**
     * Return a reminder-history summary for one booking.
     *
     * @param int $booking_id Booking ID.
     *
     * @return array
     */
    public static function get_history_summary(
        $booking_id
    ) {

        $history =
            self::get_history(
                $booking_id
            );

        if ( empty( $history ) ) {
            return array(
                'count' =>
                    0,

                'latest' =>
                    null,
            );
        }

        return array(
            'count' =>
                count( $history ),

            'latest' =>
                $history[0],
        );
    }



}
