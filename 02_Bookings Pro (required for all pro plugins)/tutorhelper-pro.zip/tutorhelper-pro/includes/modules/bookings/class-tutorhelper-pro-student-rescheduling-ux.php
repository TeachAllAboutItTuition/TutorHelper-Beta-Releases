<?php
/**
 * Student-facing cancellation and reschedule presentation helpers.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds Pro booking-change controls without duplicating Core cancellation UI.
 */
final class TutorHelper_Pro_Student_Rescheduling_UX {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		/*
		 * Remove the first F5 dashboard policy renderer. The permanent yellow
		 * policy box is no longer used; terms are shown contextually instead.
		 */
		remove_action(
			'tutorhelper_student_dashboard_booking_actions',
			array(
				'TutorHelper_Pro_Student_Rescheduling',
				'render_dashboard_terms_and_actions',
			),
			5
		);

		add_action(
			'tutorhelper_student_dashboard_booking_actions',
			array( __CLASS__, 'render_booking_controls' ),
			6,
			2
		);
	}

	/**
	 * Render Pro metadata and the Reschedule action.
	 *
	 * Core remains responsible for the existing Cancel lesson control.
	 * The external Pro script adds the student's cancellation terms inside
	 * that existing Core control when it is expanded.
	 *
	 * @param array  $booking      Prepared dashboard booking.
	 * @param string $section_type Dashboard section key.
	 * @return void
	 */
	public static function render_booking_controls( $booking, $section_type ) {
		if (
			! is_user_logged_in()
			|| ! is_array( $booking )
			|| empty( $booking['id'] )
			|| ! in_array(
				sanitize_key( $section_type ),
				array( 'pending', 'confirmed' ),
				true
			)
		) {
			return;
		}

		$student_id = get_current_user_id();
		$record = TutorHelper_Booking_Records::get_by_id(
			absint( $booking['id'] )
		);

		if (
			! $record
			|| absint( $record->student_user_id ) !== $student_id
		) {
			return;
		}

		$is_cancelled =
			TutorHelper_Booking_Records::STATUS_CANCELLED
			=== sanitize_key( $record->status );

		$cancel_available =
			! $is_cancelled
			&& ! empty( $booking['cancellation']['can_cancel'] )
			&& ! is_wp_error(
				TutorHelper_Pro_Booking_Change_Limits::can_cancel(
					$student_id
				)
			);

		$cancel_terms = $cancel_available
			? self::get_cancel_terms( $record, $student_id )
			: '';

		$reschedule_available =
			! $is_cancelled
			&& self::can_reschedule( $record, $student_id );

		$reschedule_url = '';
		if ( $reschedule_available ) {
			$booking_url = TutorHelper_Settings::get_student_booking_url();

			if ( $booking_url ) {
				$reschedule_url = add_query_arg(
					TutorHelper_Pro_Student_Rescheduling::QUERY_ARG,
					absint( $record->id ),
					$booking_url
				);
			} else {
				$reschedule_available = false;
			}
		}

		?>
		<span
			hidden
			class="tutorhelper-pro-booking-change-state<?php echo $is_cancelled ? ' tutorhelper-pro-booking-change-state--cancelled' : ''; ?>"
			data-tutorhelper-pro-booking-change-meta
			data-cancelled="<?php echo esc_attr( $is_cancelled ? '1' : '0' ); ?>"
			data-cancel-available="<?php echo esc_attr( $cancel_available ? '1' : '0' ); ?>"
			data-cancel-terms="<?php echo esc_attr( $cancel_terms ); ?>"
			aria-hidden="true"
		></span>
		<?php

		if ( $reschedule_available && $reschedule_url ) {
			?>
			<a
				class="tutorhelper-student-dashboard__reschedule-button"
				href="<?php echo esc_url( $reschedule_url ); ?>"
			>
				<?php esc_html_e( 'Reschedule lesson', 'tutorhelper-pro' ); ?>
			</a>
			<?php
		}
	}

	/**
	 * Return concise cancellation wording for the expanded Cancel control.
	 *
	 * @param object $booking    Booking record.
	 * @param int    $student_id Student ID.
	 * @return string
	 */
	private static function get_cancel_terms( $booking, $student_id ) {
		$booking_type = TutorHelper_Booking_Types::get_by_id(
			absint( $booking->booking_type_id )
		);

		if ( ! $booking_type ) {
			return '';
		}

		$deadline = self::get_deadline(
			$booking,
			absint( $booking_type->cancellation_notice_hours )
		);

		$deadline_text = $deadline
			? sprintf(
				/* translators: %s: cancellation deadline. */
				__( 'You can cancel this lesson online until %s.', 'tutorhelper-pro' ),
				self::format_datetime( $deadline )
			)
			: __( 'You can cancel this lesson online before it starts.', 'tutorhelper-pro' );

		$limit = TutorHelper_Pro_Booking_Change_Limits::get_cancellation_limit(
			$student_id
		);
		$used = TutorHelper_Pro_Booking_Change_Limits::count_recent_cancellations(
			$student_id
		);

		if ( 0 === $limit ) {
			$allowance_text = __(
				'Your tutor has not set a cancellation limit within 3 months.',
				'tutorhelper-pro'
			);
		} else {
			$remaining = max( 0, $limit - $used );
			$allowance_text = sprintf(
				/* translators: 1: remaining cancellations, 2: total allowance. */
				_n(
					'You have %1$d of your %2$d change remaining (within 3 months).',
					'You have %1$d of your %2$d changes remaining (within 3 months).',
					$remaining,
					'tutorhelper-pro'
				),
				$remaining,
				$limit
			);
		}

		return trim( $deadline_text . ' ' . $allowance_text );
	}

	/**
	 * Determine whether this confirmed lesson can be rescheduled now.
	 *
	 * @param object $booking    Booking record.
	 * @param int    $student_id Student ID.
	 * @return bool
	 */
	private static function can_reschedule( $booking, $student_id ) {
		if (
			TutorHelper_Booking_Records::STATUS_CONFIRMED
			!== sanitize_key( $booking->status )
			|| ! TutorHelper_Pro_Booking_Type_Settings::can_reschedule(
				absint( $booking->booking_type_id )
			)
		) {
			return false;
		}

		$booking_type = TutorHelper_Booking_Types::get_by_id(
			absint( $booking->booking_type_id )
		);

		if (
			! $booking_type
			|| ! TutorHelper_Student_Booking_Access::can_book(
				$booking_type,
				$student_id
			)
		) {
			return false;
		}

		$deadline = self::get_deadline(
			$booking,
			TutorHelper_Pro_Booking_Type_Settings::get_reschedule_notice_hours(
				absint( $booking->booking_type_id )
			)
		);

		if ( ! $deadline ) {
			return false;
		}

		$now = new DateTimeImmutable(
			'now',
			new DateTimeZone( 'UTC' )
		);

		if ( $now > $deadline ) {
			return false;
		}

		return ! is_wp_error(
			TutorHelper_Pro_Booking_Change_Limits::can_reschedule(
				$student_id
			)
		);
	}

	/**
	 * Calculate the notice deadline from the stored UTC booking start.
	 *
	 * @param object $booking      Booking record.
	 * @param int    $notice_hours Notice hours.
	 * @return DateTimeImmutable|null
	 */
	private static function get_deadline( $booking, $notice_hours ) {
		try {
			$start = new DateTimeImmutable(
				sanitize_text_field( $booking->booking_start ),
				new DateTimeZone( 'UTC' )
			);
		} catch ( Exception $exception ) {
			return null;
		}

		return $start->modify(
			'-' . absint( $notice_hours ) . ' hours'
		);
	}

	/**
	 * Format UTC date/time in the site's timezone.
	 *
	 * @param DateTimeImmutable $datetime UTC datetime.
	 * @return string
	 */
	private static function format_datetime( $datetime ) {
		$local = $datetime->setTimezone( wp_timezone() );

		return wp_date(
			'l j F Y \\a\\t ' . get_option( 'time_format' ),
			$local->getTimestamp(),
			wp_timezone()
		);
	}
}
