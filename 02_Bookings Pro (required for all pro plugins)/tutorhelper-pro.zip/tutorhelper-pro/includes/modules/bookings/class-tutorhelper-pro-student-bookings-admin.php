<?php
/**
 * TutorHelper Pro Student Bookings administration.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides the Pro Student Bookings Booking Hub tab.
 */
final class TutorHelper_Pro_Student_Bookings_Admin {

	/**
	 * Booking Hub tab key.
	 *
	 * @var string
	 */
	const TAB_KEY = 'student-bookings';

	/**
	 * Per-user Student Bookings page-size preference.
	 *
	 * @var string
	 */
	const USER_META_PER_PAGE =
		'tutorhelper_pro_student_bookings_per_page';
    
    /**
     * AJAX action used to refresh the bookings table.
     *
     * @var string
     */
    const TABLE_AJAX_ACTION =
        'tutorhelper_pro_student_bookings_table';


	/**
	 * Nonce action for Student Bookings table refreshes.
	 *
	 * @var string
	 */
	const TABLE_AJAX_NONCE =
		'tutorhelper_pro_student_bookings_table';

	/** Admin-post action for printable PDF exports. */
	const PDF_EXPORT_ACTION = 'tutorhelper_pro_student_bookings_pdf';


		/**
	 * AJAX action used to confirm a booking.
	 *
	 * @var string
	 */
	const CONFIRM_AJAX_ACTION =
		'tutorhelper_pro_confirm_booking';


	/**
	 * Nonce action for quick booking confirmation.
	 *
	 * @var string
	 */
	const CONFIRM_AJAX_NONCE =
		'tutorhelper_pro_confirm_booking';

	/**
	 * AJAX action used to decline an unpaid lesson request.
	 *
	 * @var string
	 */
	const DECLINE_AJAX_ACTION =
		'tutorhelper_pro_decline_unpaid_booking';

	/**
	 * Nonce action for unpaid request declines.
	 *
	 * @var string
	 */
	const DECLINE_AJAX_NONCE =
		'tutorhelper_pro_decline_unpaid_booking';

	
	/**
	 * AJAX action used to save attendance.
	 *
	 * @var string
	 */
	const ATTENDANCE_AJAX_ACTION =
		'tutorhelper_pro_update_booking_attendance';


	/**
	 * Nonce action used to save attendance.
	 *
	 * @var string
	 */
	const ATTENDANCE_AJAX_NONCE =
		'tutorhelper_pro_update_booking_attendance';

	/**
	 * AJAX action used to prepare a late reminder.
	 *
	 * @var string
	 */
	const LATE_REMINDER_PREPARE_ACTION =
		'tutorhelper_pro_prepare_late_reminder';


	/**
	 * AJAX action used to send a late reminder.
	 *
	 * @var string
	 */
	const LATE_REMINDER_SEND_ACTION =
		'tutorhelper_pro_send_late_reminder';


	/**
	 * Nonce used by late reminder actions.
	 *
	 * @var string
	 */
	const LATE_REMINDER_NONCE =
		'tutorhelper_pro_late_reminder';



	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_booking_hub_tabs',
			array( __CLASS__, 'register_tab' )
		);

        add_filter(
            'tutorhelper_booking_hub_summary_cards',
            array(
                __CLASS__,
                'add_summary_card_links',
            )
        );

		add_action(
			'tutorhelper_booking_hub_render_tab',
			array( __CLASS__, 'render_tab' ),
			10,
			2
		);

        add_action(
            'admin_enqueue_scripts',
            array(
                __CLASS__,
                'enqueue_assets',
            )
        );

		add_action(
			'admin_post_' . self::PDF_EXPORT_ACTION,
			array( __CLASS__, 'handle_pdf_export' )
		);

        add_action(
            'wp_ajax_'
                . self::TABLE_AJAX_ACTION,
            array(
                __CLASS__,
                'handle_table_ajax',
            )
        );

		add_action(
			'wp_ajax_'
				. self::CONFIRM_AJAX_ACTION,
			array(
				__CLASS__,
				'handle_confirm_ajax',
			)
		);

		add_action(
			'wp_ajax_'
				. self::DECLINE_AJAX_ACTION,
			array(
				__CLASS__,
				'handle_decline_ajax',
			)
		);

		add_action(
			'wp_ajax_'
				. self::ATTENDANCE_AJAX_ACTION,
			array(
				__CLASS__,
				'handle_attendance_ajax',
			)
		);

		add_action(
			'wp_ajax_'
				. self::LATE_REMINDER_PREPARE_ACTION,
			array(
				__CLASS__,
				'handle_late_reminder_prepare_ajax',
			)
		);

		add_action(
			'wp_ajax_'
				. self::LATE_REMINDER_SEND_ACTION,
			array(
				__CLASS__,
				'handle_late_reminder_send_ajax',
			)
		);
	}


    /**
     * Add Student Bookings destinations to Booking Hub summary cards.
     *
     * @param array $cards Booking Hub summary cards.
     *
     * @return array
     */
    public static function add_summary_card_links(
        $cards
    ) {

        if ( ! is_array( $cards ) ) {
            return $cards;
        }

        $base_args = array(
            'page' =>
                TutorHelper_Admin::MENU_SLUG,

            'tab' =>
                self::TAB_KEY,
        );

        if (
            isset(
                $cards['upcoming_bookings']
            )
        ) {
            $cards[
                'upcoming_bookings'
            ]['url'] =
                add_query_arg(
                    array_merge(
                        $base_args,
                        array(
                            'student_bookings_status' =>
                                TutorHelper_Booking_Records::
                                    STATUS_UNCONFIRMED,

                            'student_bookings_time_scope' =>
                                'all',

                            'student_bookings_sort_order' =>
                                'upcoming_first',
                        )
                    ),
                    admin_url(
                        'admin.php'
                    )
                );
        }

        if (
            isset(
                $cards['lessons_today']
            )
        ) {
            $today =
                wp_date(
                    'Y-m-d',
                    null,
                    wp_timezone()
                );

            $cards[
                'lessons_today'
            ]['url'] =
                add_query_arg(
                    array_merge(
                        $base_args,
                        array(
                            'student_bookings_date_from' =>
                                $today,

                            'student_bookings_date_to' =>
                                $today,

                            'student_bookings_status_exclude' =>
                                TutorHelper_Booking_Records::
                                    STATUS_CANCELLED,

                            'student_bookings_time_scope' =>
                                'all',

                            'student_bookings_sort_order' =>
                                'date_asc',
                        )
                    ),
                    admin_url(
                        'admin.php'
                    )
                );
        }

        return $cards;
    }


	/**
	 * Enable the Student Bookings Pro tab.
	 *
	 * Core already supplies the tab definition. Pro only needs to make
	 * the tab available while the licensed module is active.
	 *
	 * @param array $tabs Booking Hub tabs.
	 *
	 * @return array
	 */
	public static function register_tab( $tabs ) {

		if ( isset( $tabs[ self::TAB_KEY ] ) ) {
			$tabs[ self::TAB_KEY ]['status'] =
				'available';
		}

		return $tabs;
	}


    /**
     * Enqueue Student Bookings admin styling.
     *
     * @param string $hook_suffix Current admin page hook.
     *
     * @return void
     */
    public static function enqueue_assets(
        $hook_suffix
    ) {

        if (
            'toplevel_page_'
                . TutorHelper_Admin::MENU_SLUG
            !== $hook_suffix
        ) {
            return;
        }

        $selected_tab =
            isset( $_GET['tab'] )
            && ! is_array(
                $_GET['tab']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET['tab']
                    )
                )
                : '';

        if (
            self::TAB_KEY
            !== $selected_tab
        ) {
            return;
        }

        $css_path =
            TUTORHELPER_PRO_PATH
            . 'assets/css/tutorhelper-pro-admin.css';

        wp_enqueue_style(
            'tutorhelper-pro-admin',
            TUTORHELPER_PRO_URL
                . 'assets/css/tutorhelper-pro-admin.css',
            array(
                'tutorhelper-booking-hub',
            ),
            file_exists( $css_path )
                ? (string) filemtime(
                    $css_path
                )
                : TUTORHELPER_PRO_VERSION
        );

        $js_path =
            TUTORHELPER_PRO_PATH
            . 'assets/js/tutorhelper-pro-student-bookings.js';

        wp_enqueue_script(
            'tutorhelper-pro-student-bookings',
            TUTORHELPER_PRO_URL
                . 'assets/js/tutorhelper-pro-student-bookings.js',
            array(),
            file_exists( $js_path )
                ? (string) filemtime(
                    $js_path
                )
                : TUTORHELPER_PRO_VERSION,
            true
        );

        wp_localize_script(
            'tutorhelper-pro-student-bookings',
            'tutorhelperProStudentBookings',
            array(
                'ajaxUrl' =>
                    admin_url(
                        'admin-ajax.php'
                    ),

                'action' =>
                    self::TABLE_AJAX_ACTION,

                'nonce' =>
                    wp_create_nonce(
                        self::TABLE_AJAX_NONCE
                    ),

				'confirmAction' =>
					self::CONFIRM_AJAX_ACTION,

				'confirmNonce' =>
					wp_create_nonce(
						self::CONFIRM_AJAX_NONCE
					),

				'confirmingLabel' =>
					__(
						'Confirming…',
						'tutorhelper-pro'
					),

				'confirmedLabel' =>
					__(
						'Confirmed',
						'tutorhelper-pro'
					),

				'confirmFailedLabel' =>
					__(
						'The booking could not be confirmed.',
						'tutorhelper-pro'
					),

				'declineAction' =>
					self::DECLINE_AJAX_ACTION,

				'declineNonce' =>
					wp_create_nonce(
						self::DECLINE_AJAX_NONCE
					),

				'declineConfirmLabel' =>
					__(
						'Decline this unpaid lesson request? The student will be told that it was declined.',
						'tutorhelper-pro'
					),

				'declineFailedLabel' =>
					__(
						'The unpaid lesson request could not be declined.',
						'tutorhelper-pro'
					),

				'attendanceAction' =>
					self::ATTENDANCE_AJAX_ACTION,

				'attendanceNonce' =>
					wp_create_nonce(
						self::ATTENDANCE_AJAX_NONCE
					),

				'attendanceSavingLabel' =>
					__(
						'Saving…',
						'tutorhelper-pro'
					),

				'attendanceSavedLabel' =>
					__(
						'Saved',
						'tutorhelper-pro'
					),

				'attendanceFailedLabel' =>
					__(
						'Attendance could not be updated.',
						'tutorhelper-pro'
					),

				'lateReminderPrepareAction' =>
					self::LATE_REMINDER_PREPARE_ACTION,

				'lateReminderSendAction' =>
					self::LATE_REMINDER_SEND_ACTION,

				'lateReminderNonce' =>
					wp_create_nonce(
						self::LATE_REMINDER_NONCE
					),

				'lateReminderLoadingLabel' =>
					__(
						'Preparing reminder…',
						'tutorhelper-pro'
					),

				'lateReminderSendingLabel' =>
					__(
						'Sending…',
						'tutorhelper-pro'
					),

				'lateReminderSentLabel' =>
					__(
						'Reminder sent',
						'tutorhelper-pro'
					),

				'lateReminderFailedLabel' =>
					__(
						'The reminder could not be sent.',
						'tutorhelper-pro'
					),
            )
        );

		
    }


    /**
     * Refresh the Student Bookings results through AJAX.
     *
     * @return void
     */
    public static function handle_table_ajax() {

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_send_json_error(
                array(
                    'message' =>
                        __(
                            'You do not have permission to view student bookings.',
                            'tutorhelper-pro'
                        ),
                ),
                403
            );
        }

        check_ajax_referer(
            self::TABLE_AJAX_NONCE,
            'nonce'
        );

        $filters =
            self::get_filters(
                $_POST
            );

        $query_args =
            self::build_query_args(
                $filters
            );

        $booking_query =
            TutorHelper_Booking_Records::query(
                $query_args
            );

        $bookings =
            isset(
                $booking_query['bookings']
            )
            && is_array(
                $booking_query['bookings']
            )
                ? $booking_query['bookings']
                : array();

        ob_start();

        self::render_results_region(
            $bookings,
            $booking_query,
            $filters
        );

        $html =
            ob_get_clean();

        wp_send_json_success(
            array(
                'html' =>
                    $html,
            )
        );
    }


	/**
	 * Confirm an unconfirmed booking through AJAX.
	 *
	 * @return void
	 */
	public static function handle_confirm_ajax() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'You do not have permission to update bookings.',
							'tutorhelper-pro'
						),
				),
				403
			);
		}

		check_ajax_referer(
			self::CONFIRM_AJAX_NONCE,
			'nonce'
		);

		$booking_id =
			isset( $_POST['booking_id'] )
				&& ! is_array(
					$_POST['booking_id']
				)
					? absint(
						$_POST['booking_id']
					)
					: 0;

		if ( ! $booking_id ) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'The booking could not be found.',
							'tutorhelper-pro'
						),
				),
				400
			);
		}

		$result =
			TutorHelper_Booking_Records::
				update_status(
					$booking_id,
					TutorHelper_Booking_Records::
						STATUS_CONFIRMED,
					TutorHelper_Booking_Records::
						STATUS_UNCONFIRMED
				);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' =>
						$result->get_error_message(),
				),
				409
			);
		}

		wp_send_json_success(
			array(
				'status' =>
					TutorHelper_Booking_Records::
						STATUS_CONFIRMED,

				'label' =>
					__(
						'Confirmed',
						'tutorhelper-pro'
					),
			)
		);
	}


	/**
	 * Decline a student-created unpaid lesson request through AJAX.
	 *
	 * @return void
	 */
	public static function handle_decline_ajax() {

		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to update bookings.', 'tutorhelper-pro' ) ),
				403
			);
		}

		check_ajax_referer( self::DECLINE_AJAX_NONCE, 'nonce' );

		$booking_id = isset( $_POST['booking_id'] ) && ! is_array( $_POST['booking_id'] )
			? absint( $_POST['booking_id'] )
			: 0;
		$booking = $booking_id ? TutorHelper_Booking_Records::get_by_id( $booking_id ) : null;

		if (
			! $booking
			|| TutorHelper_Booking_Records::SOURCE_STUDENT !== sanitize_key( $booking->source )
			|| TutorHelper_Booking_Records::STATUS_UNCONFIRMED !== sanitize_key( $booking->status )
			|| TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING !== sanitize_key( $booking->payment_status )
		) {
			wp_send_json_error(
				array( 'message' => __( 'This booking is no longer an unpaid lesson request.', 'tutorhelper-pro' ) ),
				409
			);
		}

		$result = TutorHelper_Tutor_Booking_Update::update(
			$booking_id,
			array(
				'status' => TutorHelper_Booking_Records::STATUS_CANCELLED,
				'cancellation_reason' => __( 'Your unpaid lesson request was declined by the tutor.', 'tutorhelper-pro' ),
			),
			get_current_user_id()
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 409 );
		}

		wp_send_json_success(
			array(
				'bookingId' => $booking_id,
				'label' => __( 'Cancelled', 'tutorhelper-pro' ),
			)
		);
	}


	/**
	 * Update attendance for one booking through AJAX.
	 *
	 * @return void
	 */
	public static function handle_attendance_ajax() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'You do not have permission to update attendance.',
							'tutorhelper-pro'
						),
				),
				403
			);
		}

		check_ajax_referer(
			self::ATTENDANCE_AJAX_NONCE,
			'nonce'
		);

		$booking_id =
			isset( $_POST['booking_id'] )
			&& ! is_array(
				$_POST['booking_id']
			)
				? absint(
					$_POST['booking_id']
				)
				: 0;

		$attendance_status =
			isset( $_POST['attendance_status'] )
			&& ! is_array(
				$_POST['attendance_status']
			)
				? sanitize_key(
					wp_unslash(
						$_POST['attendance_status']
					)
				)
				: '';

		if (
			! $booking_id
			|| '' === $attendance_status
		) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'The attendance information was invalid.',
							'tutorhelper-pro'
						),
				),
				400
			);
		}

		$booking =
			TutorHelper_Booking_Records::get_by_id(
				$booking_id
			);

		if ( ! $booking ) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'The booking could not be found.',
							'tutorhelper-pro'
						),
				),
				404
			);
		}

		if (
			TutorHelper_Booking_Records::
				STATUS_CANCELLED
			=== sanitize_key(
				$booking->status
			)
		) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'Attendance cannot be recorded for a cancelled booking.',
							'tutorhelper-pro'
						),
				),
				409
			);
		}

		$result =
			TutorHelper_Pro_Booking_Attendance::save(
				$booking_id,
				$attendance_status,
				get_current_user_id()
			);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' =>
						$result->get_error_message(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'bookingId' =>
					$booking_id,

				'status' =>
					$attendance_status,

				'label' =>
					TutorHelper_Pro_Booking_Attendance::
						get_status_label(
							$attendance_status
						),
			)
		);
	}


	/**
	 * Prepare a late reminder through AJAX.
	 *
	 * @return void
	 */
	public static function handle_late_reminder_prepare_ajax() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'You do not have permission to send lesson reminders.',
							'tutorhelper-pro'
						),
				),
				403
			);
		}

		check_ajax_referer(
			self::LATE_REMINDER_NONCE,
			'nonce'
		);

		$booking_id =
			isset( $_POST['booking_id'] )
			&& ! is_array(
				$_POST['booking_id']
			)
				? absint(
					$_POST['booking_id']
				)
				: 0;

		if ( ! $booking_id ) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'The booking could not be found.',
							'tutorhelper-pro'
						),
				),
				400
			);
		}

		$prepared =
			TutorHelper_Pro_Late_Reminder_Email::
				prepare(
					$booking_id
				);

		if ( is_wp_error( $prepared ) ) {
			wp_send_json_error(
				array(
					'message' =>
						$prepared->
							get_error_message(),
				),
				400
			);
		}

		$recipients =
			$prepared['student_email'];

		if (
			! empty(
				$prepared['parent_email']
			)
		) {
			$recipients .=
				', '
				. $prepared[
					'parent_email'
				];
		}

		wp_send_json_success(
			array(
				'bookingId' =>
					$booking_id,

				'recipients' =>
					$recipients,

				'subject' =>
					$prepared['subject'],

				'message' =>
					$prepared['message'],
			)
		);
	}


	/**
	 * Send a late reminder through AJAX.
	 *
	 * @return void
	 */
	public static function handle_late_reminder_send_ajax() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'You do not have permission to send lesson reminders.',
							'tutorhelper-pro'
						),
				),
				403
			);
		}

		check_ajax_referer(
			self::LATE_REMINDER_NONCE,
			'nonce'
		);

		$booking_id =
			isset( $_POST['booking_id'] )
			&& ! is_array(
				$_POST['booking_id']
			)
				? absint(
					$_POST['booking_id']
				)
				: 0;

		$message =
			isset( $_POST['message'] )
			&& ! is_array(
				$_POST['message']
			)
				? sanitize_textarea_field(
					wp_unslash(
						$_POST['message']
					)
				)
				: '';

		if (
			! $booking_id
			|| '' === trim( $message )
		) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'The reminder information was invalid.',
							'tutorhelper-pro'
						),
				),
				400
			);
		}

		$result =
			TutorHelper_Pro_Late_Reminder_Email::send(
				$booking_id,
				$message
			);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' =>
						$result->get_error_message(),
				),
				400
			);
		}

		$history =
			TutorHelper_Pro_Late_Reminder_Email::
				get_history_summary(
					$booking_id
				);

		wp_send_json_success(
			array(
				'bookingId' =>
					$booking_id,

				'message' =>
					__(
						'Reminder sent.',
						'tutorhelper-pro'
					),

				'reminderCount' =>
					absint(
						$history['count']
					),

				'sentAt' =>
					! empty(
						$history['latest']->sent_at
					)
						? $history[
							'latest'
						]->sent_at
						: '',
			)
		);

	}


	/**
	 * Determine whether the current filters represent Lessons Today.
	 *
	 * @param array $filters Current filters.
	 *
	 * @return bool
	 */
	private static function is_lessons_today_view(
		$filters
	) {

		if (
			empty( $filters['date_from'] )
			|| empty( $filters['date_to'] )
		) {
			return false;
		}

		$today =
			wp_date(
				'Y-m-d',
				null,
				wp_timezone()
			);

		return $today
			=== $filters['date_from']
			&& $today
			=== $filters['date_to'];
	}


	/**
	 * Render the Student Bookings tab.
	 *
	 * @param string $selected_tab Selected Hub tab.
	 * @param array  $active_tab   Active tab definition.
	 *
	 * @return void
	 */
	public static function render_tab(
		$selected_tab,
		$active_tab
	) {
		unset( $active_tab );

		if ( self::TAB_KEY !== $selected_tab ) {
			return;
		}

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		$filters = self::get_filters();

		$query_args = self::build_query_args(
			$filters
		);

		$booking_query =
            TutorHelper_Booking_Records::query(
                $query_args
            );

        $bookings =
            $booking_query['bookings'];

		$booking_types =
			TutorHelper_Booking_Types::get_all(
				array(
					'active_only' => false,
				)
			);

		self::render_workspace(
            $bookings,
            $booking_types,
            $filters,
            $booking_query
        );
	}


	/**
	 * Read and sanitise Student Bookings filters.
	 *
	 * @return array
	 */
	private static function get_filters(
        $request = null
    ) {

        if ( null === $request ) {
            $request = $_GET;
        }

        $request =
            is_array( $request )
                ? $request
                : array();

        $student_search = isset(
            $request['student_bookings_student_search']
        )
            ? sanitize_text_field(
                wp_unslash(
                    $request[
                        'student_bookings_student_search'
                    ]
                )
            )
            : '';

		$date_from = isset(
			$request['student_bookings_date_from']
		)
			? sanitize_text_field(
				wp_unslash(
					$request[
						'student_bookings_date_from'
					]
				)
			)
			: '';

		$date_to = isset(
			$request['student_bookings_date_to']
		)
			? sanitize_text_field(
				wp_unslash(
					$request[
						'student_bookings_date_to'
					]
				)
			)
			: '';

		$booking_type_id = isset(
			$request[
				'student_bookings_booking_type_id'
			]
		)
			? absint(
				$request[
					'student_bookings_booking_type_id'
				]
			)
			: 0;

		$status = isset(
			$request['student_bookings_status']
		)
			? sanitize_key(
				wp_unslash(
					$request[
						'student_bookings_status'
					]
				)
			)
			: '';

        $status_exclude = isset(
            $request[
                'student_bookings_status_exclude'
            ]
        )
            ? sanitize_key(
                wp_unslash(
                    $request[
                        'student_bookings_status_exclude'
                    ]
                )
            )
            : '';

		$time_scope = isset(
			$request['student_bookings_time_scope']
		)
			? sanitize_key(
				wp_unslash(
					$request[
						'student_bookings_time_scope'
					]
				)
			)
			: 'all';

        $sort_order = isset(
            $request['student_bookings_sort_order']
        )
            ? sanitize_key(
                wp_unslash(
                    $request[
                        'student_bookings_sort_order'
                    ]
                )
            )
            : 'upcoming_first';

        $page = isset(
            $request['student_bookings_page']
        )
            ? max(
                1,
                absint(
                    $request[
                        'student_bookings_page'
                    ]
                )
            )
            : 1;

        $allowed_page_sizes = array(
            10,
            25,
            50,
            100,
        );

        $saved_page_size = absint(
            get_user_meta(
                get_current_user_id(),
                self::USER_META_PER_PAGE,
                true
            )
        );

        $per_page = in_array(
            $saved_page_size,
            $allowed_page_sizes,
            true
        )
            ? $saved_page_size
            : 25;

        if (
            isset( $request['student_bookings_per_page'] )
            && ! is_array( $request['student_bookings_per_page'] )
        ) {
            $requested_page_size = absint(
                $request['student_bookings_per_page']
            );

            if (
                in_array(
                    $requested_page_size,
                    $allowed_page_sizes,
                    true
                )
            ) {
                $per_page = $requested_page_size;

                update_user_meta(
                    get_current_user_id(),
                    self::USER_META_PER_PAGE,
                    $per_page
                );
            }
        }

		$allowed_statuses = array(
			'',
			TutorHelper_Booking_Records::
				STATUS_CONFIRMED,
			TutorHelper_Booking_Records::
				STATUS_UNCONFIRMED,
			TutorHelper_Booking_Records::
				STATUS_CANCELLED,
		);

		if (
			! in_array(
				$status,
				$allowed_statuses,
				true
			)
		) {
			$status = '';
		}


        $allowed_excluded_statuses = array(
            '',
            TutorHelper_Booking_Records::
                STATUS_CANCELLED,
        );

        if (
            ! in_array(
                $status_exclude,
                $allowed_excluded_statuses,
                true
            )
        ) {
            $status_exclude = '';
        }


		if (
			! in_array(
				$time_scope,
				array(
					'all',
					'upcoming',
				),
				true
			)
		) {
			$time_scope = 'all';
		}


        if (
            ! in_array(
                $sort_order,
                array(
                    'upcoming_first',
                    'date_asc',
                    'date_desc',
                ),
                true
            )
        ) {
            $sort_order =
                'upcoming_first';
        }


		return array(
            'student_search' =>
                $student_search,

            'date_from' =>
				self::sanitize_date(
					$date_from
				),

			'date_to' =>
				self::sanitize_date(
					$date_to
				),

			'booking_type_id' =>
				$booking_type_id,

			'status' =>
				$status,

            'status_exclude' =>
	            $status_exclude,

			'time_scope' =>
                $time_scope,

            'sort_order' =>
                $sort_order,

            'page' =>
                $page,

            'per_page' =>
                $per_page,
		);
	}


	/**
	 * Convert UI filters into Booking Records query arguments.
	 *
	 * @param array $filters Sanitised filters.
	 *
	 * @return array
	 */
	private static function build_query_args(
		$filters
	) {

		$date_from = '';

		if ( ! empty( $filters['date_from'] ) ) {
			$date_from =
				self::local_date_to_utc(
					$filters['date_from'],
					false
				);
		}

		$date_to = '';

		if ( ! empty( $filters['date_to'] ) ) {
			$date_to =
				self::local_date_to_utc(
					$filters['date_to'],
					true
				);
		}

		

		return array(
            'student_search' =>
                $filters['student_search'],

            'booking_type_id' =>
				$filters['booking_type_id'],

			'status' =>
				$filters['status'],

            'status_exclude' =>
	            $filters['status_exclude'],

			'date_from' =>
				$date_from,

			'date_to' =>
				$date_to,

			'time_scope' =>
                $filters['time_scope'],

            'sort_order' =>
                $filters['sort_order'],

            'page' =>
                $filters['page'],

            'per_page' =>
                $filters['per_page'],
		);
	}


	/**
	 * Render the Student Bookings workspace.
	 *
	 * @param array $bookings      Booking records.
	 * @param array $booking_types Booking Types.
	 * @param array $filters       Current filters.
     * @param array $booking_query Pagination query result.
	 *
	 * @return void
	 */
	private static function render_workspace(
		$bookings,
		$booking_types,
		$filters,
        $booking_query
	) {

		?>
		<section
            class="tutorhelper-pro-student-bookings"
        >
            <header
                class="tutorhelper-pro-student-bookings__header"
            >
                <div>
					<h2>
						<?php
						echo esc_html__(
							'Student Bookings',
							'tutorhelper-pro'
						);
						?>
					</h2>

					<p>
						<?php
						echo esc_html__(
							'Search and review upcoming and previous student lessons.',
							'tutorhelper-pro'
						);
						?>
					</p>
						</div>
            </header>

            <div
                class="tutorhelper-pro-student-bookings__body"
            >
            <?php
            self::render_filters(
				$booking_types,
				$filters
			);
			?>

			<?php
			self::render_results_region(
                $bookings,
                $booking_query,
                $filters
            );
            ?>
                </div>

				<div
					class="tutorhelper-admin-modal"
					data-late-reminder-modal
					hidden
				>
					<div
						class="tutorhelper-admin-modal__backdrop"
						data-late-reminder-close
					></div>

					<div
						class="tutorhelper-admin-modal__dialog"
						role="dialog"
						aria-modal="true"
						aria-labelledby="tutorhelper-late-reminder-title"
					>
						<header
							class="tutorhelper-admin-modal__header"
						>
							<h3
								id="tutorhelper-late-reminder-title"
							>
								<?php
								echo esc_html__(
									'Send late reminder',
									'tutorhelper-pro'
								);
								?>
							</h3>

							<button
								type="button"
								class="tutorhelper-admin-modal__close"
								data-late-reminder-close
								aria-label="<?php
									echo esc_attr__(
										'Close',
										'tutorhelper-pro'
									);
								?>"
							>
								&times;
							</button>
						</header>

						<div
							class="tutorhelper-admin-modal__body"
						>
							<p>
								<strong>
									<?php
									echo esc_html__(
										'Recipients:',
										'tutorhelper-pro'
									);
									?>
								</strong>

								<span
									data-late-reminder-recipients
								></span>
							</p>

							<p>
								<strong>
									<?php
									echo esc_html__(
										'Subject:',
										'tutorhelper-pro'
									);
									?>
								</strong>

								<span
									data-late-reminder-subject
								></span>
							</p>

							<label>
								<span>
									<?php
									echo esc_html__(
										'Message',
										'tutorhelper-pro'
									);
									?>
								</span>

								<textarea
									class="tutorhelper-admin-control tutorhelper-admin-control--textarea"
									rows="12"
									data-late-reminder-message
								></textarea>
							</label>
						</div>

						<footer
							class="tutorhelper-admin-modal__footer"
						>
							<button
								type="button"
								class="button tutorhelper-admin-button"
								data-late-reminder-close
							>
								<?php
								echo esc_html__(
									'Cancel',
									'tutorhelper-pro'
								);
								?>
							</button>

							<button
								type="button"
								class="button tutorhelper-admin-button tutorhelper-admin-button--primary"
								data-late-reminder-send
							>
								<?php
								echo esc_html__(
									'Send reminder',
									'tutorhelper-pro'
								);
								?>
							</button>
						</footer>
					</div>
				</div>

            </section>
		<?php
	}


	/**
	 * Render the booking filter controls.
	 *
	 * @param array $booking_types Booking Types.
	 * @param array $filters       Current filters.
	 *
	 * @return void
	 */
	private static function render_filters(
		$booking_types,
		$filters
	) {

		$today = new DateTimeImmutable(
			'today',
			wp_timezone()
		);
		$this_week_start = $today->modify( 'monday this week' );
		$this_week_end = $this_week_start->modify( '+6 days' );
		$next_week_start = $this_week_start->modify( '+7 days' );
		$next_week_end = $next_week_start->modify( '+6 days' );

		$shortcuts = array(
			'today' => array(
				'label' => __( 'Today', 'tutorhelper-pro' ),
				'from'  => $today->format( 'Y-m-d' ),
				'to'    => $today->format( 'Y-m-d' ),
			),
			'tomorrow' => array(
				'label' => __( 'Tomorrow', 'tutorhelper-pro' ),
				'from'  => $today->modify( '+1 day' )->format( 'Y-m-d' ),
				'to'    => $today->modify( '+1 day' )->format( 'Y-m-d' ),
			),
			'this-week' => array(
				'label' => __( 'This Week', 'tutorhelper-pro' ),
				'from'  => $this_week_start->format( 'Y-m-d' ),
				'to'    => $this_week_end->format( 'Y-m-d' ),
			),
			'next-week' => array(
				'label' => __( 'Next Week', 'tutorhelper-pro' ),
				'from'  => $next_week_start->format( 'Y-m-d' ),
				'to'    => $next_week_end->format( 'Y-m-d' ),
			),
		);

		$clear_url = add_query_arg(
			array(
				'page' =>
					TutorHelper_Admin::MENU_SLUG,

				'tab' =>
					self::TAB_KEY,
			),
			admin_url( 'admin.php' )
		);

		?>
		<form
			method="get"
			action="<?php
				echo esc_url(
					admin_url( 'admin.php' )
				);
			?>"
			class="tutorhelper-student-bookings-filter"
		>
			<input
				type="hidden"
				name="page"
				value="<?php
					echo esc_attr(
						TutorHelper_Admin::
							MENU_SLUG
					);
				?>"
			>

			<input
				type="hidden"
				name="tab"
				value="<?php
					echo esc_attr(
						self::TAB_KEY
					);
				?>"
			>

            <div class="tutorhelper-student-bookings-filter__shortcuts" role="group" aria-label="<?php echo esc_attr__( 'Date shortcuts', 'tutorhelper-pro' ); ?>">
                <?php foreach ( $shortcuts as $shortcut_key => $shortcut ) : ?>
                    <button
                        type="button"
                        class="button tutorhelper-admin-button"
                        data-student-bookings-date-shortcut="<?php echo esc_attr( $shortcut_key ); ?>"
                        data-date-from="<?php echo esc_attr( $shortcut['from'] ); ?>"
                        data-date-to="<?php echo esc_attr( $shortcut['to'] ); ?>"
                    >
                        <?php echo esc_html( $shortcut['label'] ); ?>
                    </button>
                <?php endforeach; ?>
            </div>

            <label>
                <span>
                    <?php
                    echo esc_html__(
                        'Student',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <input
                    type="search"
					class="tutorhelper-admin-control"
                    name="student_bookings_student_search"
                    value="<?php
                        echo esc_attr(
                            $filters['student_search']
                        );
                    ?>"
                    placeholder="<?php
                        echo esc_attr__(
                            'Search student name',
                            'tutorhelper-pro'
                        );
                    ?>"
                >
            </label>

			<label>
				<span>
					<?php
					echo esc_html__(
						'From',
						'tutorhelper-pro'
					);
					?>
				</span>

                

				<input
					type="date"
					class="tutorhelper-admin-control"
					name="student_bookings_date_from"
					value="<?php
						echo esc_attr(
							$filters['date_from']
						);
					?>"
				>
			</label>

			<label>
				<span>
					<?php
					echo esc_html__(
						'To',
						'tutorhelper-pro'
					);
					?>
				</span>

				<input
					type="date"
					class="tutorhelper-admin-control"
					name="student_bookings_date_to"
					value="<?php
						echo esc_attr(
							$filters['date_to']
						);
					?>"
				>
			</label>

			<label>
				<span>
					<?php
					echo esc_html__(
						'Booking Type',
						'tutorhelper-pro'
					);
					?>
				</span>

				<select
					name="student_bookings_booking_type_id"
					class="tutorhelper-admin-control"
				>
					<option value="0">
						<?php
						echo esc_html__(
							'All Booking Types',
							'tutorhelper-pro'
						);
						?>
					</option>

					<?php
					foreach (
						$booking_types as $booking_type
					) :
						?>
						<option
							value="<?php
								echo esc_attr(
									$booking_type->id
								);
							?>"
							<?php
							selected(
								$filters[
									'booking_type_id'
								],
								absint(
									$booking_type->id
								)
							);
							?>
						>
							<?php
							echo esc_html(
								$booking_type->title
							);
							?>
						</option>
					<?php endforeach; ?>
				</select>
			</label>

			<label>
				<span>
					<?php
					echo esc_html__(
						'Status',
						'tutorhelper-pro'
					);
					?>
				</span>

				<select
					name="student_bookings_status"
					class="tutorhelper-admin-control"
				>
					<option
						value=""
						<?php
						selected(
							$filters['status'],
							''
						);
						?>
					>
						<?php
						echo esc_html__(
							'All statuses',
							'tutorhelper-pro'
						);
						?>
					</option>

					<option
						value="confirmed"
						<?php
						selected(
							$filters['status'],
							'confirmed'
						);
						?>
					>
						<?php
						echo esc_html__(
							'Confirmed',
							'tutorhelper-pro'
						);
						?>
					</option>

					<option
						value="unconfirmed"
						<?php
						selected(
							$filters['status'],
							'unconfirmed'
						);
						?>
					>
						<?php
						echo esc_html__(
							'Unconfirmed',
							'tutorhelper-pro'
						);
						?>
					</option>

					<option
						value="cancelled"
						<?php
						selected(
							$filters['status'],
							'cancelled'
						);
						?>
					>
						<?php
						echo esc_html__(
							'Cancelled',
							'tutorhelper-pro'
						);
						?>
					</option>
				</select>
			</label>

			<label>
				<span>
					<?php
					echo esc_html__(
						'Show',
						'tutorhelper-pro'
					);
					?>
				</span>

				<select
					name="student_bookings_time_scope"
					class="tutorhelper-admin-control"
				>
					<option
						value="all"
						<?php
						selected(
							$filters['time_scope'],
							'all'
						);
						?>
					>
						<?php
						echo esc_html__(
							'All bookings',
							'tutorhelper-pro'
						);
						?>
					</option>

					<option
						value="upcoming"
						<?php
						selected(
							$filters['time_scope'],
							'upcoming'
						);
						?>
					>
						<?php
						echo esc_html__(
							'Upcoming only',
							'tutorhelper-pro'
						);
						?>
					</option>
				</select>
			</label>

            <label>
                <span>
                    <?php
                    echo esc_html__(
                        'Sort',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <select
                    name="student_bookings_sort_order"
					class="tutorhelper-admin-control"
                >
                    <option
                        value="upcoming_first"
                        <?php
                        selected(
                            $filters['sort_order'],
                            'upcoming_first'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Upcoming first',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="date_asc"
                        <?php
                        selected(
                            $filters['sort_order'],
                            'date_asc'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Date ascending',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="date_desc"
                        <?php
                        selected(
                            $filters['sort_order'],
                            'date_desc'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Date descending',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>
                </select>
            </label>

            <label>
                <span>
                    <?php echo esc_html__( 'Bookings per page', 'tutorhelper-pro' ); ?>
                </span>

                <select
                    name="student_bookings_per_page"
                    class="tutorhelper-admin-control"
                >
                    <?php foreach ( array( 10, 25, 50, 100 ) as $page_size ) : ?>
                        <option value="<?php echo esc_attr( $page_size ); ?>" <?php selected( $filters['per_page'], $page_size ); ?>>
                            <?php echo esc_html( $page_size ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>

			<div
				class="tutorhelper-student-bookings-filter__actions"
			>
				<button
					type="submit"
					class="button tutorhelper-admin-button tutorhelper-admin-button--primary"
				>
					<?php
					echo esc_html__(
						'Apply filters',
						'tutorhelper-pro'
					);
					?>
				</button>

				<a
					class="button tutorhelper-admin-button"
                    data-student-bookings-clear
					href="<?php
						echo esc_url(
							$clear_url
						);
					?>"
				>
					<?php
					echo esc_html__(
						'Clear',
						'tutorhelper-pro'
					);
					?>
				</a>

				<button
					type="submit"
					name="action"
					value="<?php echo esc_attr( self::PDF_EXPORT_ACTION ); ?>"
					formaction="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					class="button tutorhelper-admin-button"
				>
					<span class="dashicons dashicons-pdf" aria-hidden="true"></span>
					<?php echo esc_html__( 'Export current view as PDF', 'tutorhelper-pro' ); ?>
				</button>
				<?php wp_nonce_field( self::PDF_EXPORT_ACTION, '_tutorhelper_pdf_nonce' ); ?>
			</div>
		</form>
		<?php
	}

    /**
     * Render the refreshable Student Bookings results region.
     *
     * @param array $bookings      Booking records.
     * @param array $booking_query Pagination query result.
     * @param array $filters       Current filters.
     *
     * @return void
     */
    private static function render_results_region(
        $bookings,
        $booking_query,
        $filters
    ) {
        ?>
        <div
            class="tutorhelper-student-bookings-results-region"
            data-student-bookings-results
        >
            <?php
            self::render_bookings_table(
				$bookings,
				$filters
			);

            self::render_pagination(
                $booking_query,
                $filters
            );
            ?>
        </div>
        <?php
    }


	/**
	 * Render the bookings table.
	 *
	 * @param array $bookings Booking records.
	 * @param array $filters  Current Student Bookings filters.
	 *
	 * @return void
	 */
	private static function render_bookings_table(
		$bookings,
		$filters
	) {

	$show_time_sections =
		isset( $filters['time_scope'] )
		&& 'all' === $filters['time_scope'];

	$is_lessons_today =
		self::is_lessons_today_view(
			$filters
		);

	$table_column_count =
		$is_lessons_today
			? 9
			: 8;

	$current_time_section = '';

	$booking_ids = array();

	foreach ( $bookings as $booking ) {
		if ( ! empty( $booking->id ) ) {
			$booking_ids[] =
				absint( $booking->id );
		}
	}

	$attendance_records =
		TutorHelper_Pro_Booking_Attendance::
			get_for_booking_ids(
				$booking_ids
			);

		?>
		<div
			class="tutorhelper-student-bookings-results"
		>
			<table
				class="widefat striped tutorhelper-student-bookings-table"
			>
				<thead>
					<tr>
                        <th
                            scope="col"
                            class="tutorhelper-student-bookings-table__colour-heading"
                        >
                            <span class="screen-reader-text">
                                <?php
                                echo esc_html__(
                                    'Booking Type colour',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </span>
                        </th>

						<th scope="col">
							<?php
							echo esc_html__(
								'Student',
								'tutorhelper-pro'
							);
							?>
						</th>

						<th scope="col">
							<?php
							echo esc_html__(
								'Date / Time',
								'tutorhelper-pro'
							);
							?>
						</th>

						<th scope="col">
							<?php
							echo esc_html__(
								'Booking Type',
								'tutorhelper-pro'
							);
							?>
						</th>

						<th scope="col">
							<?php
							echo esc_html__(
								'Status',
								'tutorhelper-pro'
							);
							?>
						</th>
						<th scope="col">
							<?php
							echo esc_html__(
								'Attendance',
								'tutorhelper-pro'
							);
							?>
						</th>

						<th scope="col">
							<?php echo esc_html__( 'Feedback & homework', 'tutorhelper-pro' ); ?>
						</th>

						<th scope="col">
							<?php echo esc_html__( 'Rating', 'tutorhelper-pro' ); ?>
						</th>

						<?php if ( $is_lessons_today ) : ?>
							<th scope="col">
								<?php
								echo esc_html__(
									'Actions',
									'tutorhelper-pro'
								);
								?>
							</th>
						<?php endif; ?>

					</tr>
				</thead>

				<tbody>
					<?php if ( empty( $bookings ) ) : ?>
						<tr>
							<td
								colspan="<?php
									echo esc_attr(
										$table_column_count
									);
								?>"
							>
								<?php
								echo esc_html__(
									'No bookings match the selected filters.',
									'tutorhelper-pro'
								);
								?>
							</td>
						</tr>
					<?php else : ?>

						<?php
						foreach (
							$bookings as $booking
						) :
							?>
							<?php
							if ( $show_time_sections ) {

								$booking_time_section =
									self::get_booking_time_section(
										$booking
									);

								if (
									$booking_time_section
									!== $current_time_section
								) {

									self::render_table_section(
										$booking_time_section,
										$table_column_count
									);

									$current_time_section =
										$booking_time_section;
								}
							}

							$booking_id =
								absint( $booking->id );

							$attendance_record =
								isset(
									$attendance_records[
										$booking_id
									]
								)
									? $attendance_records[
										$booking_id
									]
									: null;

							self::render_booking_row(
								$booking,
								$attendance_record,
								$is_lessons_today
							);
							?>
						<?php endforeach; ?>

					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}


	/**
	 * Determine whether a booking belongs to the upcoming or past section.
	 *
	 * Booking end dates are stored in UTC.
	 *
	 * @param object $booking Booking record.
	 *
	 * @return string
	 */
	private static function get_booking_time_section(
		$booking
	) {

		if (
			empty(
				$booking->booking_end
			)
		) {
			return 'upcoming';
		}

		$booking_timestamp =
			strtotime(
				$booking->booking_end
				. ' UTC'
			);

		if ( false === $booking_timestamp ) {
			return 'upcoming';
		}

		$now_timestamp =
			current_time(
				'timestamp',
				true
			);

		return $booking_timestamp
			< $now_timestamp
				? 'past'
				: 'upcoming';
	}

	/**
	 * Render a shared TutorHelper table section heading.
	 *
	 * @param string $section Section key.
	 * @param int    $colspan Number of table columns.
	 *
	 * @return void
	 */
	private static function render_table_section(
		$section,
		$colspan
	) {

		$label =
			'past' === $section
				? __(
					'Past lessons',
					'tutorhelper-pro'
				)
				: __(
					'Upcoming lessons',
					'tutorhelper-pro'
				);

		?>
		<tr
			class="tutorhelper-admin-table-section"
		>
			<th
				scope="rowgroup"
				colspan="<?php
					echo esc_attr(
						absint( $colspan )
					);
				?>"
			>
				<span>
					<?php
					echo esc_html(
						$label
					);
					?>
				</span>
			</th>
		</tr>
		<?php
	}


	/**
	 * Render one booking row.
	 *
	 * @param object      $booking           Booking record.
	 * @param object|null $attendance_record Attendance record.
	 * @param object|false $is_lessons_today matching today date flag.
	 *
	 * @return void
	 */
	private static function render_booking_row(
		$booking,
		$attendance_record = null,
		$is_lessons_today = false
	) {

		$student_name =
			self::get_student_name(
				$booking
			);

		$rating =
			TutorHelper_Pro_Lesson_Follow_Up::get_rating_for_booking(
				absint( $booking->id )
			);

		$booking_type_name =
			self::get_booking_type_name(
				$booking
			);

        $booking_type_colour =
            self::get_booking_type_colour(
                $booking
            );

		$series_item =
			TutorHelper_Pro_Booking_Series::
				get_series_for_booking(
					absint( $booking->id )
				);

		$booking_status =
			sanitize_key(
				$booking->status
			);

		$is_cancelled =
			TutorHelper_Booking_Records::
				STATUS_CANCELLED
			=== $booking_status;

		$can_decline_unpaid_request =
			TutorHelper_Booking_Records::SOURCE_STUDENT === sanitize_key( $booking->source )
			&& TutorHelper_Booking_Records::STATUS_UNCONFIRMED === $booking_status
			&& TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING === sanitize_key( $booking->payment_status );

		$booking_end_timestamp =
			! empty( $booking->booking_end )
				? strtotime(
					$booking->booking_end
						. ' UTC'
				)
				: false;

		$is_completed =
			false !== $booking_end_timestamp
			&& $booking_end_timestamp
				<= current_time(
					'timestamp',
					true
				);

		if ( $is_cancelled ) {

			/*
			* Cancellation takes precedence over any historical
			* attendance record.
			*/
			$attendance_status =
				TutorHelper_Pro_Booking_Attendance::
					STATUS_NOT_APPLICABLE;

		} elseif (
			$attendance_record
			&& ! empty(
				$attendance_record->attendance_status
			)
		) {

			$attendance_status =
				sanitize_key(
					$attendance_record->attendance_status
				);

		} else {

			$attendance_status =
				TutorHelper_Pro_Booking_Attendance::
					STATUS_NOT_RECORDED;
		}

		$meeting = array( 'url' => '', 'label' => '' );

		if (
			$is_lessons_today
			&& ! $is_cancelled
			&& TutorHelper_Booking_Records::STATUS_CONFIRMED === $booking_status
			&& ! empty( $booking->location_type )
			&& 'online' === sanitize_key( $booking->location_type )
			&& false !== $booking_end_timestamp
			&& $booking_end_timestamp > current_time( 'timestamp', true )
			&& class_exists( 'TutorHelper_Pro_Online_Lessons_Dashboard' )
		) {
			$meeting = TutorHelper_Pro_Online_Lessons_Dashboard::get_booking_meeting(
				absint( $booking->id )
			);
		}

		$can_send_late_reminder =
			false;

		if (
			$is_lessons_today
			&& ! $is_cancelled
			&& TutorHelper_Pro_Booking_Attendance::
				STATUS_NOT_RECORDED
			=== $attendance_status
			&& ! empty(
				$booking->booking_start
			)
		) {

			$booking_start_timestamp =
				strtotime(
					$booking->booking_start
					. ' UTC'
				);

			$can_send_late_reminder =
				false !== $booking_start_timestamp
				&& $booking_start_timestamp
					<= current_time(
						'timestamp',
						true
					);
		}

		$late_reminder_history =
			array(
				'count' =>
					0,

				'latest' =>
					null,
			);

		if ( $is_lessons_today ) {
			$late_reminder_history =
				TutorHelper_Pro_Late_Reminder_Email::
					get_history_summary(
						absint(
							$booking->id
						)
					);
		}

		$attendance_statuses =
			TutorHelper_Pro_Booking_Attendance::
				get_statuses();

		?>
		<tr
            class="tutorhelper-student-bookings-table__row"
            style="<?php
                echo esc_attr(
                    '--tutorhelper-booking-type-colour: '
                    . $booking_type_colour
                    . ';'
                );
            ?>"
        >

        <td
            class="tutorhelper-student-bookings-table__colour"
            aria-hidden="true"
        ></td>

			<td>
				<strong>
					<?php
					echo esc_html(
						$student_name
					);
					?>
				</strong>
			</td>

			<td>
				<?php
				echo esc_html(
					self::format_booking_date(
						$booking
					)
				);
				?>

				<?php if ( $series_item ) : ?>
					<br>

					<span
						class="tutorhelper-pro-recurring-indicator"
					>
						<span
							class="dashicons dashicons-update"
							aria-hidden="true"
						></span>

						<?php
						echo esc_html__(
							'Recurring',
							'tutorhelper-pro'
						);
						?>
					</span>
				<?php endif; ?>
			</td>

			<td>
				<?php
				echo esc_html(
					$booking_type_name
				);
				?>
			</td>

			<td
				class="tutorhelper-student-bookings-table__status"
			>
				<?php

				if (
					TutorHelper_Booking_Records::
						STATUS_UNCONFIRMED
					=== $booking_status
				) :
					?>
					<label
						class="tutorhelper-student-bookings-confirm"
						data-booking-confirm-wrapper
					>
						<input
							type="checkbox"
							value="1"
							data-booking-confirm
							data-booking-id="<?php
								echo esc_attr(
									absint(
										$booking->id
									)
								);
							?>"
						>

						<span
							data-booking-confirm-label
						>
							<?php
							echo esc_html__(
								'Confirm',
								'tutorhelper-pro'
							);
							?>
						</span>
					</label>

					<?php if ( $can_decline_unpaid_request ) : ?>
						<button
							type="button"
							class="button tutorhelper-admin-button tutorhelper-admin-button--danger"
							data-booking-decline
							data-booking-id="<?php echo esc_attr( absint( $booking->id ) ); ?>"
						>
							<?php echo esc_html__( 'Decline', 'tutorhelper-pro' ); ?>
						</button>
					<?php endif; ?>
				<?php else : ?>
					<span
						class="tutorhelper-student-bookings-status-text"
					>
						<?php
						echo esc_html(
							$is_completed
							&& ! $is_cancelled
							&& TutorHelper_Pro_Booking_Attendance::
								STATUS_NOT_RECORDED
								!== $attendance_status
								? TutorHelper_Pro_Booking_Attendance::
									get_status_label(
										$attendance_status
									)
								: self::get_status_label(
									$booking_status
								)
						);
						?>
					</span>
				<?php endif; ?>
			</td>

			<td
				class="tutorhelper-student-bookings-table__attendance"
			>
				<?php if ( $is_cancelled ) : ?>

					<span
						class="tutorhelper-student-bookings-attendance__not-applicable"
					>
						<?php
						echo esc_html(
							TutorHelper_Pro_Booking_Attendance::
								get_status_label(
									TutorHelper_Pro_Booking_Attendance::
										STATUS_NOT_APPLICABLE
								)
						);
						?>
					</span>

				<?php else : ?>

					<label>
						<span class="screen-reader-text">
							<?php
							echo esc_html__(
								'Attendance',
								'tutorhelper-pro'
							);
							?>
						</span>

						<select
							class="tutorhelper-admin-control"
							data-booking-attendance
							data-booking-id="<?php
								echo esc_attr(
									absint(
										$booking->id
									)
								);
							?>"
							data-previous-status="<?php
								echo esc_attr(
									$attendance_status
								);
							?>"
						>
							<?php
							foreach (
								$attendance_statuses
									as $status_key =>
										$status_label
							) :

								/*
								* Not Applicable is controlled by booking
								* state rather than manually selected.
								*/
								if (
									TutorHelper_Pro_Booking_Attendance::
										STATUS_NOT_APPLICABLE
									=== $status_key
								) {
									continue;
								}
								?>
								<option
									value="<?php
										echo esc_attr(
											$status_key
										);
									?>"
									<?php
									selected(
										$attendance_status,
										$status_key
									);
									?>
								>
									<?php
									echo esc_html(
										$status_label
									);
									?>
								</option>
							<?php endforeach; ?>
						</select>
					</label>

					<span
						class="tutorhelper-student-bookings-attendance__save-status"
						data-attendance-save-status
						aria-live="polite"
					></span>


				<?php endif; ?>
			</td>

			<td class="tutorhelper-student-bookings-table__follow-up">
				<?php if ( $is_cancelled ) : ?>
					<span aria-hidden="true">—</span>
				<?php else : ?>
					<?php TutorHelper_Pro_Lesson_Follow_Up::render_tutor_button( absint( $booking->id ) ); ?>
				<?php endif; ?>
			</td>

			<td class="tutorhelper-student-bookings-table__rating">
				<?php if ( $rating ) : ?>
					<button
						type="button"
						class="button tutorhelper-pro-follow-up-open"
						data-follow-up-booking-id="<?php echo esc_attr( absint( $booking->id ) ); ?>"
						data-follow-up-group-session-id="0"
						data-follow-up-scope="booking"
						aria-label="<?php echo esc_attr__( 'View rating and comment', 'tutorhelper-pro' ); ?>"
					>
						<?php
						echo esc_html(
							sprintf(
								/* translators: %d: lesson rating out of five. */
								__( '%d / 5', 'tutorhelper-pro' ),
								absint( $rating->rating )
							)
						);
						?>
						<span class="dashicons dashicons-star-filled" aria-hidden="true"></span>
					</button>
				<?php else : ?>
					<span aria-hidden="true">—</span>
				<?php endif; ?>
			</td>

			<?php if ( $is_lessons_today ) : ?>

			<td
				class="tutorhelper-student-bookings-table__actions"
			>
				<?php if ( ! empty( $meeting['url'] ) ) : ?>
					<a
						class="button tutorhelper-admin-button tutorhelper-admin-button--primary"
						href="<?php echo esc_url( $meeting['url'] ); ?>"
						target="_blank"
						rel="noopener noreferrer"
					>
						<?php echo esc_html( $meeting['label'] ); ?>
					</a>
				<?php endif; ?>

				<?php if ( $can_send_late_reminder ) : ?>

					<button
						type="button"
						class="button tutorhelper-admin-button"
						data-late-reminder
						data-booking-id="<?php
							echo esc_attr(
								absint(
									$booking->id
								)
							);
						?>"
					>
						<?php
						echo esc_html__(
							'Send late reminder',
							'tutorhelper-pro'
						);
						?>
					</button>

					<span
						data-late-reminder-status
						aria-live="polite"
					></span>

					<?php
						if (
							! empty(
								$late_reminder_history[
									'latest'
								]
							)
						) :

							$latest_reminder =
								$late_reminder_history[
									'latest'
								];

							$latest_timestamp =
								strtotime(
									$latest_reminder->sent_at
									. ' UTC'
								);
							?>

							<div
								class="tutorhelper-late-reminder-history"
								data-late-reminder-history
							>
								<?php
								if (
									false !==
									$latest_timestamp
								) :
									?>
									<span>
										<?php
										printf(
											/* translators: %s: latest reminder time. */
											esc_html__(
												'Last sent %s',
												'tutorhelper-pro'
											),
											esc_html(
												wp_date(
													get_option(
														'time_format'
													),
													$latest_timestamp,
													wp_timezone()
												)
											)
										);
										?>
									</span>
								<?php endif; ?>

								<?php
								if (
									1
									< absint(
										$late_reminder_history[
											'count'
										]
									)
								) :
									?>
									<span>
										<?php
										printf(
											/* translators: %d: number of reminders sent. */
											esc_html__(
												'· %d sent',
												'tutorhelper-pro'
											),
											absint(
												$late_reminder_history[
													'count'
												]
											)
										);
										?>
									</span>
								<?php endif; ?>
							</div>

						<?php endif; ?>

				<?php elseif ( empty( $meeting['url'] ) ) : ?>

					<span
						class="tutorhelper-admin-action-unavailable"
						aria-hidden="true"
					>
						—
					</span>

				<?php endif; ?>
			</td>

		<?php endif; ?>

		</tr>
		<?php
	}


	/**
	 * Return the booking's student display name.
	 *
	 * Prefer the stored booking snapshot because it records the student
	 * name at the time the booking was created.
	 *
	 * @param object $booking Booking record.
	 *
	 * @return string
	 */
	private static function get_student_name(
		$booking
	) {

		if (
			isset( $booking->student_name )
			&& ''
				!== trim(
					(string) $booking->student_name
				)
		) {
			return (string)
				$booking->student_name;
		}

		$student = get_user_by(
			'id',
			absint(
				$booking->student_user_id
			)
		);

		if ( $student instanceof WP_User ) {
			return $student->display_name;
		}

		return __(
			'Unknown student',
			'tutorhelper-pro'
		);
	}


	/**
	 * Return the Booking Type title.
	 *
	 * @param object $booking Booking record.
	 *
	 * @return string
	 */
	private static function get_booking_type_name(
		$booking
	) {

		$booking_type =
			TutorHelper_Booking_Types::get_by_id(
				absint(
					$booking->booking_type_id
				)
			);

		if (
			$booking_type
			&& ! empty(
				$booking_type->title
			)
		) {
			return $booking_type->title;
		}

		return sprintf(
			/* translators: %d: Booking Type ID. */
			__(
				'Booking Type #%d',
				'tutorhelper-pro'
			),
			absint(
				$booking->booking_type_id
			)
		);
	}


    /**
     * Return the Booking Type colour.
     *
     * @param object $booking Booking record.
     *
     * @return string
     */
    private static function get_booking_type_colour(
        $booking
    ) {

        $booking_type =
            TutorHelper_Booking_Types::get_by_id(
                absint(
                    $booking->booking_type_id
                )
            );

        if (
            $booking_type
            && ! empty(
                $booking_type->colour
            )
        ) {
            $colour =
                sanitize_hex_color(
                    $booking_type->colour
                );

            if ( $colour ) {
                return $colour;
            }
        }

        return '#ff6326';
    }


	/**
	 * Format a booking date for display.
	 *
	 * Booking records store UTC values. Display them using the timezone
	 * stored with the booking, falling back to the WordPress timezone.
	 *
	 * @param object $booking Booking record.
	 *
	 * @return string
	 */
	private static function format_booking_date(
		$booking
	) {

		if ( empty( $booking->booking_start ) ) {
			return '';
		}

		try {
			$utc_timezone =
				new DateTimeZone( 'UTC' );

			$date =
				new DateTimeImmutable(
					$booking->booking_start,
					$utc_timezone
				);

			$timezone =
				self::get_booking_timezone(
					$booking
				);

			return wp_date(
				get_option( 'date_format' )
					. ' '
					. get_option( 'time_format' ),
				$date->getTimestamp(),
				$timezone
			);
		} catch ( Exception $exception ) {

			TutorHelper_Logger::warning(
				'Student Bookings could not format a booking date.',
				array(
					'booking_id' =>
						isset( $booking->id )
							? absint(
								$booking->id
							)
							: 0,
				)
			);

			return (string)
				$booking->booking_start;
		}
	}


	/**
	 * Return the booking timezone.
	 *
	 * @param object $booking Booking record.
	 *
	 * @return DateTimeZone
	 */
	private static function get_booking_timezone(
		$booking
	) {

		if (
			! empty( $booking->timezone )
			&& in_array(
				$booking->timezone,
				timezone_identifiers_list(),
				true
			)
		) {
			try {
				return new DateTimeZone(
					$booking->timezone
				);
			} catch ( Exception $exception ) {
				// Fall through to the site timezone.
			}
		}

		return wp_timezone();
	}


	/**
	 * Return a readable booking status label.
	 *
	 * @param string $status Booking status.
	 *
	 * @return string
	 */
	private static function get_status_label(
		$status
	) {

		switch ( sanitize_key( $status ) ) {

			case TutorHelper_Booking_Records::
				STATUS_CONFIRMED:
				return __(
					'Confirmed',
					'tutorhelper-pro'
				);

			case TutorHelper_Booking_Records::
				STATUS_UNCONFIRMED:
				return __(
					'Unconfirmed',
					'tutorhelper-pro'
				);

			case TutorHelper_Booking_Records::
				STATUS_CANCELLED:
				return __(
					'Cancelled',
					'tutorhelper-pro'
				);

			default:
				return ucfirst(
					str_replace(
						'_',
						' ',
						sanitize_key(
							$status
						)
					)
				);
		}
	}


    /**
     * Render Student Bookings pagination.
     *
     * @param array $booking_query Query result.
     * @param array $filters       Current filters.
     *
     * @return void
     */
    private static function render_pagination(
        $booking_query,
        $filters
    ) {

        $total =
            isset(
                $booking_query['total']
            )
                ? absint(
                    $booking_query['total']
                )
                : 0;

        $total_pages =
            isset(
                $booking_query['total_pages']
            )
                ? absint(
                    $booking_query[
                        'total_pages'
                    ]
                )
                : 0;

        $current_page =
            isset(
                $booking_query['page']
            )
                ? max(
                    1,
                    absint(
                        $booking_query['page']
                    )
                )
                : 1;

        if ( ! $total ) {
            return;
        }

        ?>
        <div
            class="tutorhelper-student-bookings-pagination"
        >
            <div
                class="tutorhelper-student-bookings-pagination__count"
            >
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: %d: total number of bookings. */
                        _n(
                            '%d booking',
                            '%d bookings',
                            $total,
                            'tutorhelper-pro'
                        ),
                        $total
                    )
                );
                ?>
            </div>

            <?php if ( 1 < $total_pages ) : ?>
                <div
                    class="tutorhelper-student-bookings-pagination__links"
                >
                    <?php
                    echo wp_kses_post(
                        paginate_links(
                            array(
                                'base' =>
                                    add_query_arg(
                                        array(
                                            'page' =>
                                                TutorHelper_Admin::
                                                    MENU_SLUG,

                                            'tab' =>
                                                self::TAB_KEY,

                                            'student_bookings_student_search' =>
                                                $filters[
                                                    'student_search'
                                                ],

                                            'student_bookings_date_from' =>
                                                $filters[
                                                    'date_from'
                                                ],

                                            'student_bookings_date_to' =>
                                                $filters[
                                                    'date_to'
                                                ],

                                            'student_bookings_booking_type_id' =>
                                                $filters[
                                                    'booking_type_id'
                                                ],

                                            'student_bookings_status' =>
                                                $filters[
                                                    'status'
                                                ],

                                            'student_bookings_status_exclude' =>
                                                $filters[
                                                    'status_exclude'
                                                ],

                                            'student_bookings_time_scope' =>
                                                $filters[
                                                    'time_scope'
                                                ],

                                            'student_bookings_sort_order' =>
                                                $filters[
                                                    'sort_order'
                                                ],

                                            'student_bookings_per_page' =>
                                                $filters[
                                                    'per_page'
                                                ],

                                            'student_bookings_page' =>
                                                '%#%',
                                        ),
                                        admin_url(
                                            'admin.php'
                                        )
                                    ),

                                'format' =>
                                    '',

                                'current' =>
                                    $current_page,

                                'total' =>
                                    $total_pages,

                                'prev_text' =>
                                    __(
                                        '‹ Previous',
                                        'tutorhelper-pro'
                                    ),

                                'next_text' =>
                                    __(
                                        'Next ›',
                                        'tutorhelper-pro'
                                    ),
                            )
                        )
                    );
                    ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }


	/**
	 * Validate a YYYY-MM-DD filter value.
	 *
	 * @param string $date Date value.
	 *
	 * @return string
	 */
	private static function sanitize_date(
		$date
	) {

		if (
			! is_string( $date )
			|| ! preg_match(
				'/^\d{4}-\d{2}-\d{2}$/',
				$date
			)
		) {
			return '';
		}

		$parts = array_map(
			'absint',
			explode( '-', $date )
		);

		if (
			3 !== count( $parts )
			|| ! checkdate(
				$parts[1],
				$parts[2],
				$parts[0]
			)
		) {
			return '';
		}

		return $date;
	}


	/**
	 * Convert a site-local date boundary into UTC.
	 *
	 * @param string $date       YYYY-MM-DD date.
	 * @param bool   $end_of_day Whether to use the end of the day.
	 *
	 * @return string
	 */
	private static function local_date_to_utc(
		$date,
		$end_of_day = false
	) {

		try {
			$local_timezone =
				wp_timezone();

			$local_date =
				new DateTimeImmutable(
					$date
					. (
						$end_of_day
							? ' 23:59:59'
							: ' 00:00:00'
					),
					$local_timezone
				);

			return $local_date
				->setTimezone(
					new DateTimeZone( 'UTC' )
				)
				->format(
					'Y-m-d H:i:s'
				);
		} catch ( Exception $exception ) {

			TutorHelper_Logger::warning(
				'Student Bookings could not convert a filter date.',
				array()
			);

			return '';
		}
	}

	/**
	 * Export the currently filtered Student Bookings view as a printable PDF.
	 *
	 * @return void
	 */
	public static function handle_pdf_export() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to export student bookings.', 'tutorhelper-pro' ) );
		}

		check_admin_referer( self::PDF_EXPORT_ACTION, '_tutorhelper_pdf_nonce' );

		$filters = self::get_filters( $_GET );
		$query_args = self::build_query_args( $filters );
		$query_args['page'] = 1;
		$query_args['per_page'] = 500;
		$result = TutorHelper_Booking_Records::query( $query_args );
		$bookings = isset( $result['bookings'] ) && is_array( $result['bookings'] )
			? $result['bookings']
			: array();

		if ( ! class_exists( '\\Dompdf\\Dompdf' ) && defined( 'TUTORHELPER_BOOKINGS_PATH' ) ) {
			$dompdf_autoloader = TUTORHELPER_BOOKINGS_PATH . 'vendor/dompdf/autoload.inc.php';
			if ( file_exists( $dompdf_autoloader ) ) {
				require_once $dompdf_autoloader;
			}
		}

		if ( ! class_exists( '\\Dompdf\\Dompdf' ) ) {
			TutorHelper_Logger::warning(
				'Core Dompdf was unavailable; Student Bookings used the basic PDF fallback.',
				array( 'user_id' => get_current_user_id(), 'booking_count' => count( $bookings ) )
			);
			self::stream_basic_pdf( $bookings );
		}

		ob_start();
		?>
		<!doctype html>
		<html>
		<head>
			<meta charset="utf-8">
			<style>
				@page { margin: 24px; }
				body { margin: 0; font-family: DejaVu Sans, sans-serif; color: #133949; font-size: 10px; }
				h1 { margin: 0; color: #133949; font-size: 22px; }
				.report-meta { margin: 4px 0 16px; color: #60727d; }
				.booking-card { margin: 0 0 14px; border: 1px solid #cfdae0; border-left: 9px solid #ff6326; border-radius: 8px; page-break-inside: avoid; }
				.booking-heading { padding: 9px 12px; background: #133949; color: #fff; }
				.booking-heading strong { font-size: 13px; }
				.booking-heading span { float: right; font-size: 10px; }
				.booking-body { padding: 10px 12px 12px; }
				.details { width: 100%; margin: 0 0 9px; border-collapse: collapse; }
				.details td { width: 25%; padding: 0 10px 5px 0; vertical-align: top; }
				.label { display: block; margin-bottom: 2px; color: #60727d; font-size: 8px; font-weight: bold; text-transform: uppercase; }
				.homework { min-height: 34px; padding: 8px 10px; border: 1px solid #e1d3c8; border-radius: 6px; background: #fff8f3; }
				.homework strong { display: block; margin-bottom: 4px; color: #133949; }
				.homework-empty { color: #60727d; font-style: italic; }
				.notes { margin-top: 9px; }
				.notes strong { display: block; margin-bottom: 4px; }
				.notes-space { height: 62px; border: 1px solid #9eb0b8; border-radius: 6px; background: #fff; }
				.clear { clear: both; }
			</style>
		</head>
		<body>
			<h1><?php echo esc_html__( 'Student Bookings — Tutor Notes', 'tutorhelper-pro' ); ?></h1>
			<p class="report-meta"><?php echo esc_html( sprintf( __( 'Exported %1$s · %2$d lessons', 'tutorhelper-pro' ), wp_date( get_option( 'date_format' ) ), count( $bookings ) ) ); ?></p>

			<?php if ( empty( $bookings ) ) : ?>
				<p><?php esc_html_e( 'No bookings matched the current filters.', 'tutorhelper-pro' ); ?></p>
			<?php endif; ?>

			<?php foreach ( $bookings as $booking ) : ?>
				<?php
				$booking_id = absint( $booking->id );
				$colour = self::get_booking_type_colour( $booking );
				$homework_due = '';
				if ( class_exists( 'TutorHelper_Pro_Lesson_Follow_Up' ) ) {
					$homework_placeholders = TutorHelper_Pro_Lesson_Follow_Up::get_reminder_homework_placeholders( $booking_id );
					$homework_due = isset( $homework_placeholders['{homework_due}'] )
						? trim( (string) $homework_placeholders['{homework_due}'] )
						: '';
				}
				?>
				<section class="booking-card" style="border-left-color: <?php echo esc_attr( $colour ); ?>;">
					<header class="booking-heading">
						<strong><?php echo esc_html( self::get_student_name( $booking ) ); ?></strong>
						<span><?php echo esc_html( self::get_booking_type_name( $booking ) ); ?></span>
						<div class="clear"></div>
					</header>
					<div class="booking-body">
						<table class="details" role="presentation">
							<tr>
								<td><span class="label"><?php esc_html_e( 'Date and time', 'tutorhelper-pro' ); ?></span><?php echo esc_html( self::format_booking_date( $booking ) ); ?></td>
								<td><span class="label"><?php esc_html_e( 'Location', 'tutorhelper-pro' ); ?></span><?php echo esc_html( isset( $booking->location_type ) ? ucfirst( sanitize_key( $booking->location_type ) ) : '—' ); ?></td>
								<td><span class="label"><?php esc_html_e( 'Attendance', 'tutorhelper-pro' ); ?></span><?php esc_html_e( 'Not recorded', 'tutorhelper-pro' ); ?></td>
								<td><span class="label"><?php esc_html_e( 'Booking', 'tutorhelper-pro' ); ?></span>#<?php echo esc_html( $booking_id ); ?></td>
							</tr>
						</table>
						<div class="homework">
							<strong><?php esc_html_e( 'Homework due for this lesson', 'tutorhelper-pro' ); ?></strong>
							<?php if ( '' !== $homework_due ) : ?>
								<?php echo wp_kses_post( nl2br( esc_html( $homework_due ) ) ); ?>
							<?php else : ?>
								<span class="homework-empty"><?php esc_html_e( 'No homework is due for this lesson.', 'tutorhelper-pro' ); ?></span>
							<?php endif; ?>
						</div>
						<div class="notes">
							<strong><?php esc_html_e( 'Tutor notes', 'tutorhelper-pro' ); ?></strong>
							<div class="notes-space">&nbsp;</div>
						</div>
					</div>
				</section>
			<?php endforeach; ?>
		</body>
		</html>
		<?php
		$html = ob_get_clean();

		try {
			$pdf = new \Dompdf\Dompdf( array( 'isRemoteEnabled' => false ) );
			$pdf->loadHtml( $html );
			$pdf->setPaper( 'A4', 'landscape' );
			$pdf->render();
			$pdf->stream( 'student-bookings-' . wp_date( 'Y-m-d' ) . '.pdf', array( 'Attachment' => true ) );
		} catch ( Throwable $exception ) {
			TutorHelper_Logger::error( 'Student Bookings PDF export failed.', array( 'message' => $exception->getMessage(), 'booking_count' => count( $bookings ), 'user_id' => get_current_user_id() ) );
			wp_die( esc_html__( 'The PDF could not be generated. Please review TutorHelper diagnostics and try again.', 'tutorhelper-pro' ) );
		}
		exit;
	}

	/**
	 * Stream a dependency-free, printable PDF when Dompdf is unavailable.
	 *
	 * @param array $bookings Filtered booking records.
	 * @return void
	 */
	private static function stream_basic_pdf( $bookings ) {
		$lines = array( __( 'Student Bookings', 'tutorhelper-pro' ), wp_date( get_option( 'date_format' ) ), '' );
		foreach ( $bookings as $booking ) {
			$lines[] = sprintf(
				'%1$s | %2$s | %3$s | %4$s',
				self::get_student_name( $booking ),
				self::format_booking_date( $booking ),
				self::get_booking_type_name( $booking ),
				isset( $booking->location_type ) ? ucfirst( sanitize_key( $booking->location_type ) ) : ''
			);
			$lines[] = __( 'Notes:', 'tutorhelper-pro' ) . ' ________________________________________________';
			$lines[] = '';
		}
		if ( 3 === count( $lines ) ) {
			$lines[] = __( 'No bookings matched the current filters.', 'tutorhelper-pro' );
		}

		$pages = array_chunk( $lines, 36 );
		$objects = array(
			1 => '<< /Type /Catalog /Pages 2 0 R >>',
			3 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
		);
		$kids = array();
		$object_number = 4;
		foreach ( $pages as $page_lines ) {
			$page_number = $object_number++;
			$content_number = $object_number++;
			$kids[] = $page_number . ' 0 R';
			$content = "BT\n/F1 10 Tf\n36 555 Td\n14 TL\n";
			foreach ( $page_lines as $line ) {
				$line = remove_accents( wp_strip_all_tags( (string) $line ) );
				$line = preg_replace( '/[^\x20-\x7E]/', '', $line );
				$line = str_replace( array( '\\\\', '(', ')' ), array( '\\\\\\\\', '\\(', '\\)' ), $line );
				$content .= '(' . $line . ") Tj\nT*\n";
			}
			$content .= 'ET';
			$objects[ $page_number ] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /Font << /F1 3 0 R >> >> /Contents ' . $content_number . ' 0 R >>';
			$objects[ $content_number ] = '<< /Length ' . strlen( $content ) . ">>\nstream\n" . $content . "\nendstream";
		}
		$objects[2] = '<< /Type /Pages /Kids [' . implode( ' ', $kids ) . '] /Count ' . count( $pages ) . ' >>';
		ksort( $objects );

		$pdf = "%PDF-1.4\n";
		$offsets = array( 0 );
		foreach ( $objects as $number => $object ) {
			$offsets[ $number ] = strlen( $pdf );
			$pdf .= $number . " 0 obj\n" . $object . "\nendobj\n";
		}
		$xref = strlen( $pdf );
		$pdf .= 'xref' . "\n0 " . ( count( $objects ) + 1 ) . "\n0000000000 65535 f \n";
		for ( $number = 1; $number <= count( $objects ); $number++ ) {
			$pdf .= sprintf( "%010d 00000 n \n", $offsets[ $number ] );
		}
		$pdf .= 'trailer << /Size ' . ( count( $objects ) + 1 ) . ' /Root 1 0 R >>' . "\nstartxref\n" . $xref . "\n%%EOF";

		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="student-bookings-' . esc_attr( wp_date( 'Y-m-d' ) ) . '.pdf"' );
		header( 'Content-Length: ' . strlen( $pdf ) );
		echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Binary PDF generated from escaped plain-text values.
		exit;
	}

}
