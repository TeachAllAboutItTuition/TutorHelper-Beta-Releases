<?php
/**
 * TutorHelper Pro student booking change limits and history.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages per-student rolling cancellation/reschedule allowances and
 * records student booking changes for future reporting.
 */
final class TutorHelper_Pro_Booking_Change_Limits {

	const META_CANCELLATION_LIMIT = 'tutorhelper_pro_cancellation_limit';
	const META_RESCHEDULE_LIMIT = 'tutorhelper_pro_reschedule_limit';

	const DEFAULT_CANCELLATION_LIMIT = 3;
	const DEFAULT_RESCHEDULE_LIMIT = 3;

	const ACTION_CANCELLATION = 'cancellation';
	const ACTION_RESCHEDULE = 'reschedule';

	const SAVE_ACTION = 'tutorhelper_pro_save_booking_change_limits';
	const SCHEMA_OPTION = 'tutorhelper_pro_booking_change_schema';
	const SCHEMA_VERSION = '1.0.0';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		self::ensure_schema();

		add_action(
			'tutorhelper_students_detail_lesson_options_pricing',
			array( __CLASS__, 'render_student_settings' ),
			40,
			1
		);

		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array( __CLASS__, 'handle_save' )
		);

		add_filter(
			'tutorhelper_student_can_cancel_booking',
			array( __CLASS__, 'filter_can_cancel' ),
			20,
			3
		);

		add_action(
			'tutorhelper_student_booking_cancelled',
			array( __CLASS__, 'record_student_cancellation' ),
			20,
			3
		);

		add_filter(
			'tutorhelper_student_data_export',
			array( __CLASS__, 'add_privacy_export_data' ),
			40,
			2
		);

		add_action(
			'tutorhelper_before_student_data_delete',
			array( __CLASS__, 'delete_privacy_data' ),
			40,
			3
		);
	}

	/**
	 * Cancellation allowance. Missing meta means the default of three.
	 * Zero means unlimited.
	 *
	 * @param int $student_id Student user ID.
	 * @return int
	 */
	public static function get_cancellation_limit( $student_id ) {
		return self::get_limit(
			$student_id,
			self::META_CANCELLATION_LIMIT,
			self::DEFAULT_CANCELLATION_LIMIT
		);
	}

	/**
	 * Reschedule allowance. Missing meta means the default of three.
	 * Zero means unlimited.
	 *
	 * @param int $student_id Student user ID.
	 * @return int
	 */
	public static function get_reschedule_limit( $student_id ) {
		return self::get_limit(
			$student_id,
			self::META_RESCHEDULE_LIMIT,
			self::DEFAULT_RESCHEDULE_LIMIT
		);
	}

	/**
	 * Count recent student cancellations.
	 *
	 * @param int $student_id Student user ID.
	 * @return int
	 */
	public static function count_recent_cancellations( $student_id ) {
		return self::count_recent_actions(
			$student_id,
			self::ACTION_CANCELLATION
		);
	}

	/**
	 * Count recent student reschedules.
	 *
	 * @param int $student_id Student user ID.
	 * @return int
	 */
	public static function count_recent_reschedules( $student_id ) {
		return self::count_recent_actions(
			$student_id,
			self::ACTION_RESCHEDULE
		);
	}

	/**
	 * Return whether the student's rolling cancellation allowance permits
	 * another cancellation. Core Booking Type and notice rules are checked
	 * separately before this method is called.
	 *
	 * @param int $student_id Student user ID.
	 * @return true|WP_Error
	 */
	public static function can_cancel( $student_id ) {
		$limit = self::get_cancellation_limit( $student_id );

		if ( 0 === $limit ) {
			return true;
		}

		$used = self::count_recent_cancellations( $student_id );

		if ( $used >= $limit ) {
			return new WP_Error(
				'tutorhelper_pro_cancellation_limit_reached',
				sprintf(
					/* translators: %d: cancellation allowance. */
					_n(
						'You have used your %d cancellation in the current 3-month period.',
						'You have used your %d cancellations in the current 3-month period.',
						$limit,
						'tutorhelper-pro'
					),
					$limit
				)
			);
		}

		return true;
	}

	/**
	 * Return whether the student's rolling reschedule allowance permits
	 * another reschedule. Booking Type/notice checks are added by the
	 * reschedule workflow in the next implementation stage.
	 *
	 * @param int $student_id Student user ID.
	 * @return true|WP_Error
	 */
	public static function can_reschedule( $student_id ) {
		$limit = self::get_reschedule_limit( $student_id );

		if ( 0 === $limit ) {
			return true;
		}

		$used = self::count_recent_reschedules( $student_id );

		if ( $used >= $limit ) {
			return new WP_Error(
				'tutorhelper_pro_reschedule_limit_reached',
				sprintf(
					/* translators: %d: reschedule allowance. */
					_n(
						'You have used your %d reschedule in the current 3-month period.',
						'You have used your %d reschedules in the current 3-month period.',
						$limit,
						'tutorhelper-pro'
					),
					$limit
				)
			);
		}

		return true;
	}

	/**
	 * Core cancellation extension point.
	 *
	 * @param true|WP_Error $allowed    Current decision.
	 * @param int           $booking_id Booking ID.
	 * @param int           $student_id Student user ID.
	 * @return true|WP_Error
	 */
	public static function filter_can_cancel( $allowed, $booking_id, $student_id ) {
		unset( $booking_id );

		if ( is_wp_error( $allowed ) || true !== $allowed ) {
			return $allowed;
		}

		return self::can_cancel( $student_id );
	}

	/**
	 * Record a successful student cancellation. Tutor cancellations never
	 * pass through this student-only Core action and therefore do not count.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param int    $student_id Student user ID.
	 * @param string $reason     Cancellation reason.
	 * @return void
	 */
	public static function record_student_cancellation( $booking_id, $student_id, $reason ) {
		self::record_action(
			array(
				'booking_id' => absint( $booking_id ),
				'student_user_id' => absint( $student_id ),
				'action_type' => self::ACTION_CANCELLATION,
				'reason' => sanitize_textarea_field( $reason ),
			)
		);
	}

	/**
	 * Record a student reschedule. Exposed now so the next stage can use the
	 * same reporting history without another schema change.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param int    $student_id Student user ID.
	 * @param string $old_start  Previous UTC start.
	 * @param string $old_end    Previous UTC end.
	 * @param string $new_start  New UTC start.
	 * @param string $new_end    New UTC end.
	 * @return bool
	 */
	public static function record_student_reschedule(
		$booking_id,
		$student_id,
		$old_start,
		$old_end,
		$new_start,
		$new_end
	) {
		return self::record_action(
			array(
				'booking_id' => absint( $booking_id ),
				'student_user_id' => absint( $student_id ),
				'action_type' => self::ACTION_RESCHEDULE,
				'old_booking_start' => sanitize_text_field( $old_start ),
				'old_booking_end' => sanitize_text_field( $old_end ),
				'new_booking_start' => sanitize_text_field( $new_start ),
				'new_booking_end' => sanitize_text_field( $new_end ),
			)
		);
	}

	/**
	 * Return booking-change history. This deliberately supports filters that
	 * the reporting module can reuse later.
	 *
	 * @param array $args Query arguments.
	 * @return array
	 */
	public static function get_actions( $args = array() ) {
		global $wpdb;

		$table = self::get_table_name();
		if ( '' === $table ) {
			return array();
		}

		$args = wp_parse_args(
			is_array( $args ) ? $args : array(),
			array(
				'student_user_id' => 0,
				'action_type' => '',
				'date_from' => '',
				'date_to' => '',
				'limit' => 100,
			)
		);

		$where = array( '1=1' );
		$values = array();

		if ( absint( $args['student_user_id'] ) ) {
			$where[] = 'student_user_id = %d';
			$values[] = absint( $args['student_user_id'] );
		}

		$action_type = sanitize_key( $args['action_type'] );
		if ( in_array( $action_type, array( self::ACTION_CANCELLATION, self::ACTION_RESCHEDULE ), true ) ) {
			$where[] = 'action_type = %s';
			$values[] = $action_type;
		}

		if ( '' !== $args['date_from'] ) {
			$where[] = 'occurred_at >= %s';
			$values[] = sanitize_text_field( $args['date_from'] );
		}

		if ( '' !== $args['date_to'] ) {
			$where[] = 'occurred_at <= %s';
			$values[] = sanitize_text_field( $args['date_to'] );
		}

		$limit = min( 1000, max( 1, absint( $args['limit'] ) ) );
		$sql = "SELECT * FROM {$table} WHERE "
			. implode( ' AND ', $where )
			. ' ORDER BY occurred_at DESC, id DESC LIMIT %d';
		$values[] = $limit;

		$prepared = $wpdb->prepare( $sql, $values );
		$rows = $wpdb->get_results( $prepared, ARRAY_A );

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Render per-student limits and current rolling usage.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render_student_settings( $student ) {
		if (
			! $student instanceof WP_User
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$student_id = absint( $student->ID );
		$cancellation_limit = self::get_cancellation_limit( $student_id );
		$reschedule_limit = self::get_reschedule_limit( $student_id );
		$cancellations_used = self::count_recent_cancellations( $student_id );
		$reschedules_used = self::count_recent_reschedules( $student_id );

		self::render_notice();
		?>
		<section class="tutorhelper-student-detail__section tutorhelper-pro-booking-change-limits">
			<h3><?php esc_html_e( 'Booking Changes', 'tutorhelper-pro' ); ?></h3>
			<p><?php esc_html_e( 'Set how many times this student may cancel or reschedule lessons within a rolling three-month period. Set a limit to 0 for unlimited changes.', 'tutorhelper-pro' ); ?></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
				<input type="hidden" name="student_id" value="<?php echo esc_attr( $student_id ); ?>" />
				<?php wp_nonce_field( self::SAVE_ACTION, 'tutorhelper_pro_booking_change_limits_nonce' ); ?>

				<div class="tutorhelper-input-fields">
					<div class="tutorhelper-input-field">
						<label for="tutorhelper-pro-cancellation-limit"><?php esc_html_e( 'Maximum cancellations in 3 months', 'tutorhelper-pro' ); ?></label>
						<input id="tutorhelper-pro-cancellation-limit" class="tutorhelper-admin-control" type="number" min="0" step="1" name="cancellation_limit" value="<?php echo esc_attr( $cancellation_limit ); ?>" />
						<p class="description">
							<?php
							if ( 0 === $cancellation_limit ) {
								printf( esc_html__( 'Used: %d — Unlimited', 'tutorhelper-pro' ), absint( $cancellations_used ) );
							} else {
								printf( esc_html__( 'Used: %1$d of %2$d', 'tutorhelper-pro' ), absint( $cancellations_used ), absint( $cancellation_limit ) );
							}
							?>
						</p>
					</div>

					<div class="tutorhelper-input-field">
						<label for="tutorhelper-pro-reschedule-limit"><?php esc_html_e( 'Maximum reschedules in 3 months', 'tutorhelper-pro' ); ?></label>
						<input id="tutorhelper-pro-reschedule-limit" class="tutorhelper-admin-control" type="number" min="0" step="1" name="reschedule_limit" value="<?php echo esc_attr( $reschedule_limit ); ?>" />
						<p class="description">
							<?php
							if ( 0 === $reschedule_limit ) {
								printf( esc_html__( 'Used: %d — Unlimited', 'tutorhelper-pro' ), absint( $reschedules_used ) );
							} else {
								printf( esc_html__( 'Used: %1$d of %2$d', 'tutorhelper-pro' ), absint( $reschedules_used ), absint( $reschedule_limit ) );
							}
							?>
						</p>
					</div>
				</div>

				<p>
					<button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary">
						<?php esc_html_e( 'Save booking change limits', 'tutorhelper-pro' ); ?>
					</button>
				</p>
			</form>
		</section>
		<?php
	}

	/**
	 * Save student limits.
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die(
				esc_html__( 'You do not have permission to manage booking change limits.', 'tutorhelper-pro' ),
				esc_html__( 'Permission denied', 'tutorhelper-pro' ),
				array( 'response' => 403 )
			);
		}

		check_admin_referer(
			self::SAVE_ACTION,
			'tutorhelper_pro_booking_change_limits_nonce'
		);

		$student_id = isset( $_POST['student_id'] )
			? absint( wp_unslash( $_POST['student_id'] ) )
			: 0;

		if ( ! TutorHelper_Students::get_student( $student_id ) instanceof WP_User ) {
			self::redirect( $student_id, 'invalid_student' );
		}

		$cancellation_limit = isset( $_POST['cancellation_limit'] )
			? absint( wp_unslash( $_POST['cancellation_limit'] ) )
			: self::DEFAULT_CANCELLATION_LIMIT;

		$reschedule_limit = isset( $_POST['reschedule_limit'] )
			? absint( wp_unslash( $_POST['reschedule_limit'] ) )
			: self::DEFAULT_RESCHEDULE_LIMIT;

		update_user_meta( $student_id, self::META_CANCELLATION_LIMIT, $cancellation_limit );
		update_user_meta( $student_id, self::META_RESCHEDULE_LIMIT, $reschedule_limit );

		self::redirect( $student_id, 'saved' );
	}

	/**
	 * Append limits and action history to student privacy exports.
	 *
	 * @param array   $data    Existing export.
	 * @param WP_User $student Student account.
	 * @return array
	 */
	public static function add_privacy_export_data( $data, $student ) {
		if ( ! is_array( $data ) || ! $student instanceof WP_User ) {
			return $data;
		}

		if ( ! isset( $data['pro'] ) || ! is_array( $data['pro'] ) ) {
			$data['pro'] = array();
		}

		$student_id = absint( $student->ID );
		$data['pro']['booking_change_limits'] = array(
			'cancellation_limit' => self::get_cancellation_limit( $student_id ),
			'reschedule_limit' => self::get_reschedule_limit( $student_id ),
		);
		$data['pro']['booking_change_history'] = self::get_actions(
			array(
				'student_user_id' => $student_id,
				'limit' => 1000,
			)
		);

		return $data;
	}

	/**
	 * Remove per-student booking-change data during either TutorHelper
	 * privacy erasure mode. These records are operational history, not
	 * accounting records, so they do not need to be retained.
	 *
	 * @param int    $student_id Student ID.
	 * @param mixed  $student    Student object.
	 * @param string $mode       Core deletion mode.
	 * @return void
	 */
	public static function delete_privacy_data( $student_id, $student, $mode ) {
		global $wpdb;
		unset( $student, $mode );

		$student_id = absint( $student_id );
		delete_user_meta( $student_id, self::META_CANCELLATION_LIMIT );
		delete_user_meta( $student_id, self::META_RESCHEDULE_LIMIT );

		$table = self::get_table_name();
		if ( '' !== $table ) {
			$wpdb->delete(
				$table,
				array( 'student_user_id' => $student_id ),
				array( '%d' )
			);
		}
	}

	/**
	 * Create the reporting/history table once. Kept independently versioned
	 * so this feature can be tested without disturbing existing Pro tables.
	 *
	 * @return void
	 */
	private static function ensure_schema() {
		$installed = get_option( self::SCHEMA_OPTION, '0.0.0' );
		if ( ! version_compare( $installed, self::SCHEMA_VERSION, '<' ) ) {
			return;
		}

		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			booking_id bigint(20) unsigned NOT NULL,
			student_user_id bigint(20) unsigned NOT NULL,
			action_type varchar(30) NOT NULL,
			reason text DEFAULT NULL,
			old_booking_start datetime DEFAULT NULL,
			old_booking_end datetime DEFAULT NULL,
			new_booking_start datetime DEFAULT NULL,
			new_booking_end datetime DEFAULT NULL,
			occurred_at datetime NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY booking_id (booking_id),
			KEY student_user_id (student_user_id),
			KEY action_type (action_type),
			KEY occurred_at (occurred_at),
			KEY student_action_date (student_user_id, action_type, occurred_at)
		) {$charset_collate};";

		dbDelta( $sql );
		update_option( self::SCHEMA_OPTION, self::SCHEMA_VERSION, false );
	}

	private static function get_limit( $student_id, $meta_key, $default ) {
		$value = get_user_meta( absint( $student_id ), $meta_key, true );
		return '' === $value ? absint( $default ) : absint( $value );
	}

	private static function count_recent_actions( $student_id, $action_type ) {
		global $wpdb;

		$student_id = absint( $student_id );
		if ( ! $student_id ) {
			return 0;
		}

		$table = self::get_table_name();
		$from = ( new DateTimeImmutable( 'now', wp_timezone() ) )
			->modify( '-3 months' )
			->setTimezone( new DateTimeZone( 'UTC' ) )
			->format( 'Y-m-d H:i:s' );

		return absint(
			$wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE student_user_id = %d AND action_type = %s AND occurred_at >= %s",
					$student_id,
					sanitize_key( $action_type ),
					$from
				)
			)
		);
	}

	private static function record_action( $args ) {
		global $wpdb;

		$args = wp_parse_args(
			is_array( $args ) ? $args : array(),
			array(
				'booking_id' => 0,
				'student_user_id' => 0,
				'action_type' => '',
				'reason' => '',
				'old_booking_start' => null,
				'old_booking_end' => null,
				'new_booking_start' => null,
				'new_booking_end' => null,
			)
		);

		$action_type = sanitize_key( $args['action_type'] );
		if (
			! absint( $args['booking_id'] )
			|| ! absint( $args['student_user_id'] )
			|| ! in_array( $action_type, array( self::ACTION_CANCELLATION, self::ACTION_RESCHEDULE ), true )
		) {
			return false;
		}

		$now = current_time( 'mysql', true );
		$result = $wpdb->insert(
			self::get_table_name(),
			array(
				'booking_id' => absint( $args['booking_id'] ),
				'student_user_id' => absint( $args['student_user_id'] ),
				'action_type' => $action_type,
				'reason' => '' !== $args['reason'] ? sanitize_textarea_field( $args['reason'] ) : null,
				'old_booking_start' => $args['old_booking_start'],
				'old_booking_end' => $args['old_booking_end'],
				'new_booking_start' => $args['new_booking_start'],
				'new_booking_end' => $args['new_booking_end'],
				'occurred_at' => $now,
				'created_at' => $now,
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		return false !== $result;
	}

	private static function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'tutorhelper_pro_booking_actions';
	}

	private static function redirect( $student_id, $notice ) {
		$url = add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Students_Admin::TAB_KEY,
				'student_id' => absint( $student_id ),
				'tutorhelper_pro_booking_change_notice' => sanitize_key( $notice ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	private static function render_notice() {
		$notice = isset( $_GET['tutorhelper_pro_booking_change_notice'] )
			? sanitize_key( wp_unslash( $_GET['tutorhelper_pro_booking_change_notice'] ) )
			: '';

		if ( 'saved' === $notice ) {
			?>
			<div class="notice notice-success inline"><p><?php esc_html_e( 'Booking change limits saved.', 'tutorhelper-pro' ); ?></p></div>
			<?php
		} elseif ( 'invalid_student' === $notice ) {
			?>
			<div class="notice notice-error inline"><p><?php esc_html_e( 'The selected student could not be found.', 'tutorhelper-pro' ); ?></p></div>
			<?php
		}
	}
}
