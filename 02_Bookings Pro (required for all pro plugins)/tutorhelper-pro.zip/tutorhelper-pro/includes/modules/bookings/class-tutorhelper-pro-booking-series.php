<?php
/**
 * TutorHelper Pro booking series service.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and retrieves recurring booking series.
 */
final class TutorHelper_Pro_Booking_Series {

	/**
	 * Supported recurrence frequencies.
	 *
	 * @var array
	 */
	const FREQUENCIES = array(
		'daily',
		'weekdays',
		'weekly',
		'fortnightly',
	);

	/**
	 * Return the series table name.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		return TutorHelper_Pro_Database::
			get_table_name(
				'booking_series'
			);
	}

	/**
	 * Return the series-items table name.
	 *
	 * @return string
	 */
	public static function get_items_table_name() {
		return TutorHelper_Pro_Database::
			get_table_name(
				'booking_series_items'
			);
	}

	/**
	 * Create a booking series.
	 *
	 * @param array $data Series data.
	 *
	 * @return int|WP_Error
	 */
	public static function create(
		$data
	) {
		global $wpdb;

		$data = self::sanitize_data(
			$data
		);

		$validation =
			self::validate_data(
				$data
			);

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$data = $validation;

		$now = current_time(
			'mysql',
			true
		);

		$data['created_at'] = $now;
		$data['updated_at'] = $now;

		$result = $wpdb->insert(
			self::get_table_name(),
			$data
		);

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_create_failed',
				__(
					'The booking series could not be created.',
					'tutorhelper-pro'
				)
			);
		}

		return absint(
			$wpdb->insert_id
		);
	}

	/**
	 * Retrieve a series by ID.
	 *
	 * @param int $series_id Series ID.
	 *
	 * @return object|null
	 */
	public static function get_by_id(
		$series_id
	) {
		global $wpdb;

		$series_id =
			absint(
				$series_id
			);

		if ( ! $series_id ) {
			return null;
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT *
				FROM %i
				WHERE id = %d',
				self::get_table_name(),
				$series_id
			)
		);
	}

	/**
	 * Link a Core booking to a series.
	 *
	 * @param int    $series_id       Series ID.
	 * @param int    $booking_id      Core booking ID.
	 * @param string $occurrence_date Occurrence date.
	 *
	 * @return true|WP_Error
	 */
	public static function add_booking(
		$series_id,
		$booking_id,
		$occurrence_date
	) {
		global $wpdb;

		$series_id =
			absint(
				$series_id
			);

		$booking_id =
			absint(
				$booking_id
			);

		$occurrence_date =
			sanitize_text_field(
				$occurrence_date
			);

		if (
			! $series_id
			|| ! self::get_by_id(
				$series_id
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_not_found',
				__(
					'The booking series could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! $booking_id
			|| ! TutorHelper_Booking_Records::
				get_by_id(
					$booking_id
				)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_booking_not_found',
				__(
					'The booking could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! self::is_valid_date(
				$occurrence_date
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_date_invalid',
				__(
					'The occurrence date is invalid.',
					'tutorhelper-pro'
				)
			);
		}

		$existing =
			self::get_series_for_booking(
				$booking_id
			);

		if ( $existing ) {
			return (
				absint(
					$existing->series_id
				)
				=== $series_id
			)
				? true
				: new WP_Error(
					'tutorhelper_pro_booking_series_booking_already_linked',
					__(
						'The booking already belongs to another series.',
						'tutorhelper-pro'
					)
				);
		}

		$result = $wpdb->insert(
			self::get_items_table_name(),
			array(
				'series_id' =>
					$series_id,

				'booking_id' =>
					$booking_id,

				'occurrence_date' =>
					$occurrence_date,

				'created_at' =>
					current_time(
						'mysql',
						true
					),
			)
		);

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_link_failed',
				__(
					'The booking could not be linked to the series.',
					'tutorhelper-pro'
				)
			);
		}

		return true;
	}

	/**
	 * Return all items in a series.
	 *
	 * @param int $series_id Series ID.
	 *
	 * @return array
	 */
	public static function get_items(
		$series_id
	) {
		global $wpdb;

		$series_id =
			absint(
				$series_id
			);

		if ( ! $series_id ) {
			return array();
		}

		$results = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT *
				FROM %i
				WHERE series_id = %d
				ORDER BY occurrence_date ASC,
					booking_id ASC',
				self::get_items_table_name(),
				$series_id
			)
		);

		return is_array( $results )
			? $results
			: array();
	}

	/**
	 * Return the series relationship for a Core booking.
	 *
	 * @param int $booking_id Booking ID.
	 *
	 * @return object|null
	 */
	public static function get_series_for_booking(
		$booking_id
	) {
		global $wpdb;

		$booking_id =
			absint(
				$booking_id
			);

		if ( ! $booking_id ) {
			return null;
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT *
				FROM %i
				WHERE booking_id = %d',
				self::get_items_table_name(),
				$booking_id
			)
		);
	}

	/**
	 * Sanitise series data.
	 *
	 * @param array $data Raw data.
	 *
	 * @return array
	 */
	private static function sanitize_data(
		$data
	) {
		$data = is_array( $data )
			? $data
			: array();

		return array(
			'student_user_id' =>
				isset(
					$data['student_user_id']
				)
					? absint(
						$data['student_user_id']
					)
					: 0,

			'tutor_user_id' =>
				isset(
					$data['tutor_user_id']
				)
					? absint(
						$data['tutor_user_id']
					)
					: 0,

			'booking_type_id' =>
				isset(
					$data['booking_type_id']
				)
					? absint(
						$data['booking_type_id']
					)
					: 0,

			'start_date' =>
				isset(
					$data['start_date']
				)
					? sanitize_text_field(
						$data['start_date']
					)
					: '',

			'end_date' =>
				isset(
					$data['end_date']
				)
					? sanitize_text_field(
						$data['end_date']
					)
					: '',

			'frequency' =>
				isset(
					$data['frequency']
				)
					? sanitize_key(
						$data['frequency']
					)
					: '',

			'start_time' =>
				isset(
					$data['start_time']
				)
					? sanitize_text_field(
						$data['start_time']
					)
					: '',

			'end_time' =>
				isset(
					$data['end_time']
				)
					? sanitize_text_field(
						$data['end_time']
					)
					: '',

			'timezone' =>
				isset(
					$data['timezone']
				)
					? sanitize_text_field(
						$data['timezone']
					)
					: '',

			'location_type' =>
				isset(
					$data['location_type']
				)
					? sanitize_key(
						$data['location_type']
					)
					: '',

			'location_details' =>
				isset(
					$data['location_details']
				)
					? sanitize_textarea_field(
						$data['location_details']
					)
					: '',

			'booking_status' =>
				isset(
					$data['booking_status']
				)
					? sanitize_key(
						$data['booking_status']
					)
					: '',

			'exclude_outside_term_time' =>
				! empty(
					$data[
						'exclude_outside_term_time'
					]
				)
					? 1
					: 0,

			'exclude_public_holidays' =>
				! empty(
					$data[
						'exclude_public_holidays'
					]
				)
					? 1
					: 0,

			'notes' =>
				isset(
					$data['notes']
				)
					? sanitize_textarea_field(
						$data['notes']
					)
					: '',
		);
	}

	/**
	 * Validate series data.
	 *
	 * @param array $data Sanitised data.
	 *
	 * @return array|WP_Error
	 */
	private static function validate_data(
		$data
	) {
		if (
			! TutorHelper_Students::
				get_student(
					$data['student_user_id']
				) instanceof WP_User
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_student_invalid',
				__(
					'The selected student could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! get_user_by(
				'id',
				$data['tutor_user_id']
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_tutor_invalid',
				__(
					'The tutor could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$booking_type =
			TutorHelper_Booking_Types::
				get_by_id(
					$data['booking_type_id']
				);

		if (
			! $booking_type
			|| empty(
				$booking_type->is_active
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_type_invalid',
				__(
					'The selected Booking Type is not available.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! self::is_valid_date(
				$data['start_date']
			)
			|| ! self::is_valid_date(
				$data['end_date']
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_dates_invalid',
				__(
					'Enter valid series start and end dates.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			$data['end_date']
			< $data['start_date']
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_end_before_start',
				__(
					'The series end date must not be before its start date.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! in_array(
				$data['frequency'],
				self::FREQUENCIES,
				true
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_frequency_invalid',
				__(
					'Select a valid recurrence frequency.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! self::is_valid_time(
				$data['start_time']
			)
			|| ! self::is_valid_time(
				$data['end_time']
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_times_invalid',
				__(
					'Enter valid lesson start and end times.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			$data['end_time']
			<= $data['start_time']
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_end_time_invalid',
				__(
					'The lesson end time must be after its start time.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! in_array(
				$data['location_type'],
				TutorHelper_Tutor_Booking_Save::
					ALLOWED_LOCATIONS,
				true
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_location_invalid',
				__(
					'Select a valid booking location.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! in_array(
				$data['booking_status'],
				TutorHelper_Tutor_Booking_Save::
					ALLOWED_STATUSES,
				true
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_status_invalid',
				__(
					'Select a valid booking status.',
					'tutorhelper-pro'
				)
			);
		}

		try {
			new DateTimeZone(
				$data['timezone']
			);
		} catch ( Exception $exception ) {
			return new WP_Error(
				'tutorhelper_pro_booking_series_timezone_invalid',
				__(
					'The booking timezone is invalid.',
					'tutorhelper-pro'
				)
			);
		}

		return $data;
	}

	/**
	 * Check an exact Y-m-d date.
	 *
	 * @param string $date Date.
	 *
	 * @return bool
	 */
	private static function is_valid_date(
		$date
	) {
		$parsed =
			DateTimeImmutable::
				createFromFormat(
					'!Y-m-d',
					(string) $date,
					new DateTimeZone(
						'UTC'
					)
				);

		$errors =
			DateTimeImmutable::
				getLastErrors();

		return false !== $parsed
			&& ! (
				is_array( $errors )
				&& (
					0 < $errors[
						'warning_count'
					]
					|| 0 < $errors[
						'error_count'
					]
				)
			)
			&& $parsed->format(
				'Y-m-d'
			) === $date;
	}

	/**
	 * Check an exact H:i or H:i:s time.
	 *
	 * @param string $time Time.
	 *
	 * @return bool
	 */
	private static function is_valid_time(
		$time
	) {
		$time = sanitize_text_field(
			(string) $time
		);

		foreach (
			array(
				'!H:i',
				'!H:i:s',
			)
			as $format
		) {
			$parsed =
				DateTimeImmutable::
					createFromFormat(
						$format,
						$time,
						new DateTimeZone(
							'UTC'
						)
					);

			$errors =
				DateTimeImmutable::
					getLastErrors();

			if (
				false === $parsed
				|| (
					is_array(
						$errors
					)
					&& (
						0 < $errors[
							'warning_count'
						]
						|| 0 < $errors[
							'error_count'
						]
					)
				)
			) {
				continue;
			}

			$expected =
				'!H:i' === $format
					? $parsed->format(
						'H:i'
					)
					: $parsed->format(
						'H:i:s'
					);

			if ( $expected === $time ) {
				return true;
			}
		}

		return false;
	}
}
