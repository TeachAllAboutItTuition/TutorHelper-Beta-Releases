<?php
/**
 * TutorHelper Pro student booking page resolver.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides a non-persistent fallback when Core's Student booking page
 * setting has not yet been selected.
 */
final class TutorHelper_Pro_Booking_Page_Resolver {

	/**
	 * Register the option fallback.
	 *
	 * @return void
	 */
	public static function init() {
		if ( is_admin() ) {
			return;
		}

		add_filter(
			'pre_option_tutorhelper_student_booking_page_id',
			array( __CLASS__, 'resolve_page_id' ),
			10,
			1
		);
	}

	/**
	 * Find a published page containing the Core student-booking shortcode.
	 *
	 * @param mixed $pre_option Existing pre-option value.
	 * @return mixed
	 */
	public static function resolve_page_id( $pre_option ) {
		if ( false !== $pre_option ) {
			return $pre_option;
		}

		static $resolved = null;

		if ( null !== $resolved ) {
			return $resolved ? $resolved : false;
		}

		$resolved = 0;

		$page_ids = get_posts(
			array(
				'post_type' => 'page',
				'post_status' => 'publish',
				'posts_per_page' => -1,
				'orderby' => 'ID',
				'order' => 'ASC',
				'fields' => 'ids',
				'no_found_rows' => true,
				'suppress_filters' => false,
			)
		);

		foreach ( $page_ids as $page_id ) {
			$content = (string) get_post_field(
				'post_content',
				absint( $page_id )
			);

			if (
				has_shortcode(
					$content,
					'tutorhelper_student_booking'
				)
				|| false !== strpos(
					$content,
					'tutorhelper_student_booking'
				)
			) {
				$resolved = absint( $page_id );
				break;
			}
		}

		return $resolved ? $resolved : false;
	}
}

TutorHelper_Pro_Booking_Page_Resolver::init();
