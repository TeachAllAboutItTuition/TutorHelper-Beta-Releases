<?php
/**
 * Recurring booking edit scope.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Adds single-occurrence and future-occurrence update choices. */
final class TutorHelper_Pro_Recurring_Booking_Editor {

	/** Submitted edit-scope field. */
	const FIELD = 'tutorhelper_pro_recurring_edit_scope';

	/** AJAX action used to refresh the recurring-review panel. */
	const REVIEW_ACTION = 'tutorhelper_pro_recurring_booking_review';

	/** Nonce action for refreshing the recurring-review panel. */
	const REVIEW_NONCE = 'tutorhelper_pro_recurring_booking_review';

	/** Register Core extension hooks. */
	public static function init() {
		add_action( 'tutorhelper_tutor_booking_render_edit_fields', array( __CLASS__, 'render_scope' ), 10, 2 );
		add_filter( 'tutorhelper_tutor_booking_update_result', array( __CLASS__, 'update_result' ), 10, 4 );
		add_filter( 'tutorhelper_tutor_booking_notice_messages', array( __CLASS__, 'add_notices' ) );
		add_action( 'wp_ajax_' . self::REVIEW_ACTION, array( __CLASS__, 'handle_review_request' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/** Add allowlisted feedback for recurring edit outcomes. */
	public static function add_notices( $messages ) {
		$messages['updated_future'] = array( 'type' => 'success', 'message' => __( 'This lesson and all editable future lessons in the recurring set were updated.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_edit_unavailable'] = array( 'type' => 'error', 'message' => __( 'This recurring lesson could not be updated.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_cancel_scope'] = array( 'type' => 'error', 'message' => __( 'Cancel recurring lessons individually so each cancellation reason and notification remains accurate.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_future_empty'] = array( 'type' => 'error', 'message' => __( 'There are no editable lessons remaining in this recurring set.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_datetime_invalid'] = array( 'type' => 'error', 'message' => __( 'The recurring lesson date or time is invalid.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_end_invalid'] = array( 'type' => 'error', 'message' => __( 'The lesson end time must be after its start time.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_future_conflict'] = array( 'type' => 'error', 'message' => __( 'A future lesson conflicts with another booking or tutor unavailability. No lessons were changed.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_future_review'] = array( 'type' => 'error', 'message' => __( 'Some future lessons need attention before the recurring update can be applied.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_resolution_required'] = array( 'type' => 'error', 'message' => __( 'Choose how to resolve every conflicting future lesson.', 'tutorhelper-pro' ) );
		$messages['tutorhelper_pro_recurring_resolution_invalid'] = array( 'type' => 'error', 'message' => __( 'Enter a valid date and time for every rescheduled lesson.', 'tutorhelper-pro' ) );
		return $messages;
	}

	/** Render scope choices only for a booking in a recurring series. */
	public static function render_scope( $form_state, $booking ) {
		unset( $form_state );
		if ( ! $booking || ! TutorHelper_Pro_Booking_Series::get_series_for_booking( absint( $booking->id ) ) ) {
			return;
		}
		?>
		<fieldset class="tutorhelper-tutor-booking__field is-wide tutorhelper-pro-recurring-edit-scope">
			<legend><?php esc_html_e( 'Apply changes to', 'tutorhelper-pro' ); ?></legend>
			<label><input type="radio" name="<?php echo esc_attr( self::FIELD ); ?>" value="single" checked /> <?php esc_html_e( 'This lesson only', 'tutorhelper-pro' ); ?></label>
			<label><input type="radio" name="<?php echo esc_attr( self::FIELD ); ?>" value="future" /> <?php esc_html_e( 'This and all future lessons in the recurring set', 'tutorhelper-pro' ); ?></label>
			<p class="description"><?php esc_html_e( 'Future lessons keep their existing dates. The updated time, Booking Type, confirmed or unconfirmed status, location and notes are applied from this lesson onwards. Earlier and already-cancelled lessons are not changed. Cancellations remain individual so their reasons and notifications stay accurate.', 'tutorhelper-pro' ); ?></p>
		</fieldset>
		<div
			class="tutorhelper-pro-recurring-conflict-review-wrap"
			data-tutorhelper-pro-recurring-review
			data-ajax-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
			data-nonce="<?php echo esc_attr( wp_create_nonce( self::REVIEW_NONCE ) ); ?>"
			data-booking-id="<?php echo esc_attr( absint( $booking->id ) ); ?>"
		>
			<?php self::render_conflict_review( $booking ); ?>
		</div>
		<?php
	}

	/** Enqueue the scoped recurring-review refresh behaviour on Edit Booking only. */
	public static function enqueue_assets() {
		if ( ! is_admin() || ! isset( $_GET['page'], $_GET['tab'], $_GET['mode'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen detection.
			return;
		}
		$page = sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen detection.
		$tab = sanitize_key( wp_unslash( $_GET['tab'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen detection.
		$mode = sanitize_key( wp_unslash( $_GET['mode'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen detection.
		if ( TutorHelper_Booking_Hub::PAGE_SLUG !== $page || TutorHelper_Tutor_Booking_Admin::TAB_KEY !== $tab || 'edit' !== $mode ) {
			return;
		}
		wp_enqueue_script( 'tutorhelper-pro-recurring-booking-review', TUTORHELPER_PRO_URL . 'assets/js/recurring-booking-review.js', array(), TUTORHELPER_PRO_VERSION, true );
	}

	/** Return the review panel only; the edit form itself is never reloaded. */
	public static function handle_review_request() {
		if ( ! current_user_can( TutorHelper_Booking_Hub::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to review recurring lessons.', 'tutorhelper-pro' ) ), 403 );
		}
		check_ajax_referer( self::REVIEW_NONCE, 'nonce' );
		$booking_id = isset( $_POST['booking_id'] ) ? absint( wp_unslash( $_POST['booking_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verified above.
		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		$item = $booking_id ? TutorHelper_Pro_Booking_Series::get_series_for_booking( $booking_id ) : null;
		if ( ! $booking || ! $item || get_current_user_id() !== absint( $booking->tutor_user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'This recurring lesson could not be reviewed.', 'tutorhelper-pro' ) ), 400 );
		}
		$data = array(
			'booking_date' => self::review_post_value( 'booking_date' ),
			'start_time' => self::review_post_value( 'start_time' ),
			'end_time' => self::review_post_value( 'end_time' ),
			'timezone' => self::review_post_value( 'timezone' ) ?: wp_timezone()->getName(),
			'booking_type_id' => absint( self::review_post_value( 'booking_type_id' ) ),
			'location_type' => self::review_post_value( 'location_type' ),
		);
		$updates = self::build_updates( $item, $booking_id, $data, get_current_user_id() );
		if ( is_wp_error( $updates ) ) {
			wp_send_json_error( array( 'message' => $updates->get_error_message() ), 400 );
		}
		$conflicts = self::find_conflicts( $updates, get_current_user_id() );
		if ( is_wp_error( $conflicts ) ) {
			wp_send_json_error( array( 'message' => $conflicts->get_error_message() ), 400 );
		}
		self::store_review( $booking_id, get_current_user_id(), absint( $item->series_id ), $updates, $conflicts );
		ob_start();
		self::render_conflict_review( $booking );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/** Read one scalar field after the recurring-review AJAX nonce is verified. */
	private static function review_post_value( $key ) {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] )
			? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The calling AJAX handler verifies its nonce.
			: '';
	}

	/**
	 * Render a short-lived, tutor-specific review of conflicting future lessons.
	 *
	 * @param object $booking Edited booking.
	 * @return void
	 */
	private static function render_conflict_review( $booking ) {
		$review = self::get_review( absint( $booking->id ), get_current_user_id() );
		if ( ! $review ) {
			return;
		}
		?>
		<section class="tutorhelper-tutor-booking__field is-wide tutorhelper-pro-recurring-conflict-review" aria-labelledby="tutorhelper-recurring-conflict-title">
			<h3 id="tutorhelper-recurring-conflict-title"><?php esc_html_e( 'Review future lesson changes', 'tutorhelper-pro' ); ?></h3>
			<p><?php esc_html_e( 'The lessons below will move with your new series details. For any clash, choose a separate date and time, or exclude that occurrence from the recurring set.', 'tutorhelper-pro' ); ?></p>
			<input type="hidden" name="tutorhelper_pro_recurring_conflict_token" value="<?php echo esc_attr( $review['token'] ); ?>" />
			<table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Date', 'tutorhelper-pro' ); ?></th><th><?php esc_html_e( 'Planned time', 'tutorhelper-pro' ); ?></th><th><?php esc_html_e( 'Clashes with', 'tutorhelper-pro' ); ?></th><th><?php esc_html_e( 'Resolution', 'tutorhelper-pro' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $review['occurrences'] as $occurrence ) : ?>
						<?php $id = absint( $occurrence['booking_id'] ); $conflict = ! empty( $occurrence['conflict'] ) && isset( $review['conflicts'][ $id ] ); ?>
						<tr>
							<td><?php echo esc_html( $occurrence['date'] ); ?></td>
							<td><?php echo esc_html( $occurrence['start_time'] . '–' . $occurrence['end_time'] ); ?></td>
							<td><?php echo esc_html( $conflict ? implode( ', ', $review['conflicts'][ $id ]['reasons'] ) : __( 'No clash', 'tutorhelper-pro' ) ); ?></td>
							<td>
								<?php if ( ! $conflict ) : ?>
									<span aria-hidden="true">—</span>
								<?php else : ?>
									<label class="screen-reader-text" for="tutorhelper-recurring-resolution-<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Choose a resolution', 'tutorhelper-pro' ); ?></label>
									<select id="tutorhelper-recurring-resolution-<?php echo esc_attr( $id ); ?>" name="tutorhelper_pro_conflict_action[<?php echo esc_attr( $id ); ?>]">
										<option value=""><?php esc_html_e( 'Choose a resolution…', 'tutorhelper-pro' ); ?></option>
										<?php if ( ! empty( $review['conflicts'][ $id ]['can_override'] ) ) : ?>
											<option value="override"><?php esc_html_e( 'Keep this lesson (override calendar warning)', 'tutorhelper-pro' ); ?></option>
										<?php endif; ?>
										<option value="reschedule"><?php esc_html_e( 'Give this lesson a different date and time', 'tutorhelper-pro' ); ?></option>
										<option value="exclude"><?php echo esc_html( TutorHelper_Booking_Records::STATUS_UNCONFIRMED === sanitize_key( $review['conflicts'][ $id ]['status'] ) ? __( 'Exclude and delete this unconfirmed booking', 'tutorhelper-pro' ) : __( 'Exclude and cancel this confirmed booking', 'tutorhelper-pro' ) ); ?></option>
									</select>
									<?php if ( empty( $review['conflicts'][ $id ]['can_override'] ) ) : ?>
										<p class="description"><?php esc_html_e( 'This clash cannot be overridden.', 'tutorhelper-pro' ); ?></p>
									<?php endif; ?>
									<details>
										<summary><?php esc_html_e( 'Set a different date and time', 'tutorhelper-pro' ); ?></summary>
										<p><label><?php esc_html_e( 'Date', 'tutorhelper-pro' ); ?> <input type="date" name="tutorhelper_pro_conflict_date[<?php echo esc_attr( $id ); ?>]" value="<?php echo esc_attr( $review['conflicts'][ $id ]['date'] ); ?>" /></label></p>
										<p><label><?php esc_html_e( 'Start', 'tutorhelper-pro' ); ?> <input type="time" name="tutorhelper_pro_conflict_start[<?php echo esc_attr( $id ); ?>]" value="<?php echo esc_attr( $review['conflicts'][ $id ]['start_time'] ); ?>" /></label></p>
										<p><label><?php esc_html_e( 'End', 'tutorhelper-pro' ); ?> <input type="time" name="tutorhelper_pro_conflict_end[<?php echo esc_attr( $id ); ?>]" value="<?php echo esc_attr( $review['conflicts'][ $id ]['end_time'] ); ?>" /></label></p>
									</details>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</section>
		<?php
	}

	/** Intercept future-series updates after Core has verified capability and nonce. */
	public static function update_result( $result, $booking_id, $data, $tutor_user_id ) {
		if ( null !== $result ) {
			return $result;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Core invokes this filter only after verifying its booking-update nonce.
		$scope = isset( $_POST[ self::FIELD ] ) && ! is_array( $_POST[ self::FIELD ] )
			? sanitize_key( wp_unslash( $_POST[ self::FIELD ] ) )
			: 'single';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		if ( 'future' !== $scope ) {
			return null;
		}

		$booking_id      = absint( $booking_id );
		$tutor_user_id   = absint( $tutor_user_id );
		$selected        = TutorHelper_Booking_Records::get_by_id( $booking_id );
		$item            = TutorHelper_Pro_Booking_Series::get_series_for_booking( $booking_id );
		if ( ! $selected || ! $item || $tutor_user_id !== absint( $selected->tutor_user_id ) ) {
			return new WP_Error( 'tutorhelper_pro_recurring_edit_unavailable', __( 'This recurring lesson could not be updated.', 'tutorhelper-pro' ) );
		}
		if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( isset( $data['status'] ) ? $data['status'] : '' ) ) {
			return new WP_Error( 'tutorhelper_pro_recurring_cancel_scope', __( 'Cancel recurring lessons individually so each cancellation reason and notification remains accurate.', 'tutorhelper-pro' ) );
		}

		$updates = self::build_updates( $item, $booking_id, $data, $tutor_user_id );
		if ( is_wp_error( $updates ) ) {
			return $updates;
		}

		$review = self::get_review( $booking_id, $tutor_user_id );
		$plan   = array(
			'updates'    => $updates,
			'exclusions' => array(),
			'overrides'  => array(),
		);

		$review_token = isset( $_POST['tutorhelper_pro_recurring_conflict_token'] ) && ! is_array( $_POST['tutorhelper_pro_recurring_conflict_token'] )
			? sanitize_text_field( wp_unslash( $_POST['tutorhelper_pro_recurring_conflict_token'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core has verified the enclosing booking update request.
			: '';
		if ( $review && hash_equals( $review['token'], $review_token ) ) {
			$plan = self::apply_resolutions( $updates, $review, $tutor_user_id );
			if ( is_wp_error( $plan ) ) {
				return $plan;
			}
		}

		$conflicts = self::find_conflicts( $plan['updates'], $tutor_user_id, $plan['overrides'] );
		if ( is_wp_error( $conflicts ) ) {
			return $conflicts;
		}
		if ( ! empty( $conflicts ) ) {
			self::store_review( $booking_id, $tutor_user_id, absint( $item->series_id ), $plan['updates'], $conflicts );
			return new WP_Error( 'tutorhelper_pro_recurring_future_review', __( 'Review the future lessons that need attention before applying this series update.', 'tutorhelper-pro' ) );
		}

		$updated_ids = array();
		foreach ( $plan['updates'] as $update ) {
			$write = TutorHelper_Tutor_Booking_Update::update( $update['booking_id'], $update['data'], $tutor_user_id );
			if ( is_wp_error( $write ) ) {
				TutorHelper_Logger::error( 'Recurring booking update stopped after an unexpected write failure.', array( 'series_id' => absint( $item->series_id ), 'booking_id' => $update['booking_id'], 'updated_booking_ids' => $updated_ids, 'error_code' => $write->get_error_code() ) );
				return $write;
			}
			$updated_ids[] = $update['booking_id'];
		}

		foreach ( $plan['exclusions'] as $exclusion ) {
			$excluded = self::exclude_booking( $exclusion, $tutor_user_id );
			if ( is_wp_error( $excluded ) ) {
				return $excluded;
			}
			self::remove_series_item( absint( $item->series_id ), absint( $exclusion['booking_id'] ) );
		}

		self::update_occurrence_dates( absint( $item->series_id ), $plan['updates'] );
		self::update_series_snapshot( absint( $item->series_id ), $data );
		self::clear_review( $booking_id, $tutor_user_id );

		return array(
			'booking_id'          => $booking_id,
			'updated_booking_ids' => $updated_ids,
			'notice'              => 'updated_future',
		);
	}

	/** Build per-occurrence payloads while preserving each future date. */
	/**
	 * Build future occurrence updates using the selected lesson's date shift.
	 *
	 * A tutor moving the selected occurrence from Monday to Friday expects each
	 * later Monday occurrence to move to its corresponding Friday, rather than
	 * merely inheriting the selected lesson's new time.
	 */
	private static function build_updates( $selected_item, $selected_booking_id, $data, $tutor_user_id ) {
		try {
			$timezone = new DateTimeZone( sanitize_text_field( $data['timezone'] ) );
			$selected_date = new DateTimeImmutable( sanitize_text_field( $selected_item->occurrence_date ) . ' 12:00:00', $timezone );
			$new_date = new DateTimeImmutable( sanitize_text_field( $data['booking_date'] ) . ' 12:00:00', $timezone );
		} catch ( Exception $exception ) {
			return new WP_Error( 'tutorhelper_pro_recurring_datetime_invalid', __( 'The recurring lesson date or time is invalid.', 'tutorhelper-pro' ) );
		}
		if ( $selected_date->format( 'Y-m-d' ) !== sanitize_text_field( $selected_item->occurrence_date ) || $new_date->format( 'Y-m-d' ) !== sanitize_text_field( $data['booking_date'] ) ) {
			return new WP_Error( 'tutorhelper_pro_recurring_datetime_invalid', __( 'The recurring lesson date or time is invalid.', 'tutorhelper-pro' ) );
		}
		$date_shift_days = (int) $selected_date->diff( $new_date )->format( '%r%a' );
		$updates = array();
		foreach ( TutorHelper_Pro_Booking_Series::get_items( absint( $selected_item->series_id ) ) as $item ) {
			if ( (string) $item->occurrence_date < (string) $selected_item->occurrence_date ) {
				continue;
			}
			$booking = TutorHelper_Booking_Records::get_by_id( absint( $item->booking_id ) );
			if ( ! $booking || $tutor_user_id !== absint( $booking->tutor_user_id ) || TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
				continue;
			}
			try {
				$occurrence_date = new DateTimeImmutable( sanitize_text_field( $item->occurrence_date ) . ' 12:00:00', $timezone );
			} catch ( Exception $exception ) {
				return new WP_Error( 'tutorhelper_pro_recurring_datetime_invalid', __( 'The recurring lesson date or time is invalid.', 'tutorhelper-pro' ) );
			}
			$payload = $data;
			$payload['booking_date'] = $occurrence_date->modify( ( $date_shift_days >= 0 ? '+' : '' ) . $date_shift_days . ' days' )->format( 'Y-m-d' );
			$updates[] = array( 'booking_id' => absint( $item->booking_id ), 'data' => $payload );
		}
		return empty( $updates ) ? new WP_Error( 'tutorhelper_pro_recurring_future_empty', __( 'There are no editable lessons remaining in this recurring set.', 'tutorhelper-pro' ) ) : $updates;
	}

	/** Check all future times for clashes before changing any records. */
	private static function preflight( $updates, $tutor_user_id ) {
		foreach ( $updates as $update ) {
			$data = $update['data'];
			try {
				$timezone = new DateTimeZone( sanitize_text_field( $data['timezone'] ) );
				$start = new DateTimeImmutable( sanitize_text_field( $data['booking_date'] ) . ' ' . sanitize_text_field( $data['start_time'] ), $timezone );
				$end = new DateTimeImmutable( sanitize_text_field( $data['booking_date'] ) . ' ' . sanitize_text_field( $data['end_time'] ), $timezone );
			} catch ( Exception $exception ) {
				return new WP_Error( 'tutorhelper_pro_recurring_datetime_invalid', __( 'The recurring lesson date or time is invalid.', 'tutorhelper-pro' ) );
			}
			if ( $end <= $start ) {
				return new WP_Error( 'tutorhelper_pro_recurring_end_invalid', __( 'The lesson end time must be after its start time.', 'tutorhelper-pro' ) );
			}
			$evaluation = TutorHelper_Booking_Conditions::evaluate( array( 'tutor_user_id' => $tutor_user_id, 'booking_type_id' => absint( $data['booking_type_id'] ), 'booking_start' => $start->format( 'Y-m-d H:i:s' ), 'booking_end' => $end->format( 'Y-m-d H:i:s' ), 'timezone' => $timezone->getName(), 'location_type' => sanitize_key( $data['location_type'] ), 'exclude_booking_id' => $update['booking_id'] ) );
			if ( is_wp_error( $evaluation ) ) {
				return $evaluation;
			}
			if ( empty( $evaluation['can_tutor_save'] ) ) {
				return new WP_Error( 'tutorhelper_pro_recurring_future_conflict', sprintf( /* translators: %s: Date of a future lesson that could not be changed. */ __( 'The future lesson on %s conflicts with another booking or tutor unavailability. No lessons were changed.', 'tutorhelper-pro' ), wp_date( get_option( 'date_format' ), $start->getTimestamp(), $timezone ) ) );
			}
		}
		return true;
	}

	/**
	 * Return every conflicting update rather than stopping at the first.
	 *
	 * @param array $updates Proposed update payloads.
	 * @param int   $tutor_user_id Tutor ID.
	 * @return array|WP_Error
	 */
	private static function find_conflicts( $updates, $tutor_user_id, $overrides = array() ) {
		$conflicts = array();
		foreach ( $updates as $update ) {
			$data = $update['data'];
			try {
				$timezone = new DateTimeZone( sanitize_text_field( $data['timezone'] ) );
				$start = new DateTimeImmutable( sanitize_text_field( $data['booking_date'] ) . ' ' . sanitize_text_field( $data['start_time'] ), $timezone );
				$end = new DateTimeImmutable( sanitize_text_field( $data['booking_date'] ) . ' ' . sanitize_text_field( $data['end_time'] ), $timezone );
			} catch ( Exception $exception ) {
				return new WP_Error( 'tutorhelper_pro_recurring_datetime_invalid', __( 'The recurring lesson date or time is invalid.', 'tutorhelper-pro' ) );
			}
			if ( $end <= $start ) {
				return new WP_Error( 'tutorhelper_pro_recurring_end_invalid', __( 'The lesson end time must be after its start time.', 'tutorhelper-pro' ) );
			}
			$evaluation = TutorHelper_Booking_Conditions::evaluate( array( 'tutor_user_id' => $tutor_user_id, 'booking_type_id' => absint( $data['booking_type_id'] ), 'booking_start' => $start->format( 'Y-m-d H:i:s' ), 'booking_end' => $end->format( 'Y-m-d H:i:s' ), 'timezone' => $timezone->getName(), 'location_type' => sanitize_key( $data['location_type'] ), 'exclude_booking_id' => $update['booking_id'] ) );
			if ( is_wp_error( $evaluation ) ) {
				return $evaluation;
			}
			$summary = self::get_conflict_summary( $evaluation );
			if ( ! $summary || ( ! empty( $overrides[ absint( $update['booking_id'] ) ] ) && ! empty( $summary['can_override'] ) ) ) {
				continue;
			}
			$booking = TutorHelper_Booking_Records::get_by_id( absint( $update['booking_id'] ) );
			$conflicts[ absint( $update['booking_id'] ) ] = array_merge( array(
				'booking_id' => absint( $update['booking_id'] ),
				'date'       => sanitize_text_field( $data['booking_date'] ),
				'start_time' => sanitize_text_field( $data['start_time'] ),
				'end_time'   => sanitize_text_field( $data['end_time'] ),
				'status'     => $booking ? sanitize_key( $booking->status ) : '',
			), $summary );
		}
		return $conflicts;
	}

	/** Build a short, specific explanation for a recurring-series clash. */
	private static function get_conflict_summary( $evaluation ) {
		if ( ! is_array( $evaluation ) || empty( $evaluation['conditions'] ) || ! is_array( $evaluation['conditions'] ) ) {
			return null;
		}
		$reasons = array();
		$blocking = false;
		foreach ( $evaluation['conditions'] as $condition ) {
			$code = isset( $condition['code'] ) ? sanitize_key( $condition['code'] ) : '';
			if ( 'booking_conflict' === $code ) {
				$conflict_id = isset( $condition['context']['booking_id'] ) ? absint( $condition['context']['booking_id'] ) : 0;
				$conflicting_booking = $conflict_id ? TutorHelper_Booking_Records::get_by_id( $conflict_id ) : null;
				$student_name = $conflicting_booking && ! empty( $conflicting_booking->student_name ) ? sanitize_text_field( $conflicting_booking->student_name ) : __( 'Another booking', 'tutorhelper-pro' );
				$reasons[] = $student_name;
				$blocking = true;
			} elseif ( 'tutor_leave' === $code ) {
				$reasons[] = __( 'Tutor On Leave', 'tutorhelper-pro' );
				$blocking = true;
			} elseif ( 'outside_term_time' === $code ) {
				$reasons[] = __( 'Out of Term Time', 'tutorhelper-pro' );
			} elseif ( 'public_holiday' === $code ) {
				$reasons[] = __( 'Public Holiday', 'tutorhelper-pro' );
			}
		}
		$reasons = array_values( array_unique( $reasons ) );
		if ( empty( $reasons ) ) {
			return null;
		}
		return array(
			'reasons'      => $reasons,
			'can_override' => ! $blocking,
		);
	}

	/**
	 * Store a short-lived, tutor-specific conflict review.
	 */
	private static function store_review( $booking_id, $tutor_user_id, $series_id, $updates, $conflicts ) {
		$occurrences = array();
		foreach ( $updates as $update ) {
			$occurrences[] = array(
				'booking_id' => absint( $update['booking_id'] ),
				'date'       => sanitize_text_field( $update['data']['booking_date'] ),
				'start_time' => sanitize_text_field( $update['data']['start_time'] ),
				'end_time'   => sanitize_text_field( $update['data']['end_time'] ),
				'conflict'   => isset( $conflicts[ absint( $update['booking_id'] ) ] ),
			);
		}
		set_transient( self::review_key( $booking_id, $tutor_user_id ), array( 'token' => wp_generate_password( 24, false, false ), 'series_id' => absint( $series_id ), 'conflicts' => $conflicts, 'occurrences' => $occurrences ), 15 * MINUTE_IN_SECONDS );
	}

	private static function get_review( $booking_id, $tutor_user_id ) {
		$review = get_transient( self::review_key( $booking_id, $tutor_user_id ) );
		return is_array( $review ) && ! empty( $review['token'] ) && isset( $review['conflicts'] ) ? $review : null;
	}

	private static function clear_review( $booking_id, $tutor_user_id ) {
		delete_transient( self::review_key( $booking_id, $tutor_user_id ) );
	}

	private static function review_key( $booking_id, $tutor_user_id ) {
		return 'tutorhelper_pro_series_review_' . absint( $tutor_user_id ) . '_' . absint( $booking_id );
	}

	/**
	 * Apply submitted individual conflict resolutions to the update plan.
	 */
	private static function apply_resolutions( $updates, $review, $tutor_user_id ) {
		unset( $tutor_user_id );
		$actions = isset( $_POST['tutorhelper_pro_conflict_action'] ) && is_array( $_POST['tutorhelper_pro_conflict_action'] ) ? wp_unslash( $_POST['tutorhelper_pro_conflict_action'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core has verified the enclosing booking update request.
		$dates = isset( $_POST['tutorhelper_pro_conflict_date'] ) && is_array( $_POST['tutorhelper_pro_conflict_date'] ) ? wp_unslash( $_POST['tutorhelper_pro_conflict_date'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core has verified the enclosing booking update request.
		$starts = isset( $_POST['tutorhelper_pro_conflict_start'] ) && is_array( $_POST['tutorhelper_pro_conflict_start'] ) ? wp_unslash( $_POST['tutorhelper_pro_conflict_start'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core has verified the enclosing booking update request.
		$ends = isset( $_POST['tutorhelper_pro_conflict_end'] ) && is_array( $_POST['tutorhelper_pro_conflict_end'] ) ? wp_unslash( $_POST['tutorhelper_pro_conflict_end'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core has verified the enclosing booking update request.
		$plan = array( 'updates' => array(), 'exclusions' => array(), 'overrides' => array() );

		foreach ( $updates as $update ) {
			$id = absint( $update['booking_id'] );
			if ( ! isset( $review['conflicts'][ $id ] ) ) {
				$plan['updates'][] = $update;
				continue;
			}
			$action = isset( $actions[ $id ] ) ? sanitize_key( $actions[ $id ] ) : '';
			if ( 'exclude' === $action ) {
				$plan['exclusions'][] = array( 'booking_id' => $id, 'status' => sanitize_key( $review['conflicts'][ $id ]['status'] ) );
				continue;
			}
			if ( 'override' === $action && ! empty( $review['conflicts'][ $id ]['can_override'] ) ) {
				$plan['overrides'][ $id ] = true;
				$plan['updates'][] = $update;
				continue;
			}
			if ( 'reschedule' !== $action ) {
				return new WP_Error( 'tutorhelper_pro_recurring_resolution_required', __( 'Choose how to resolve every conflicting future lesson.', 'tutorhelper-pro' ) );
			}
			$date = isset( $dates[ $id ] ) ? sanitize_text_field( $dates[ $id ] ) : '';
			$start = isset( $starts[ $id ] ) ? sanitize_text_field( $starts[ $id ] ) : '';
			$end = isset( $ends[ $id ] ) ? sanitize_text_field( $ends[ $id ] ) : '';
			if ( '' === $date || '' === $start || '' === $end ) {
				return new WP_Error( 'tutorhelper_pro_recurring_resolution_invalid', __( 'Enter a date, start time and end time for each rescheduled lesson.', 'tutorhelper-pro' ) );
			}
			$update['data']['booking_date'] = $date;
			$update['data']['start_time'] = $start;
			$update['data']['end_time'] = $end;
			$plan['updates'][] = $update;
		}
		return $plan;
	}

	private static function exclude_booking( $exclusion, $tutor_user_id ) {
		$id = absint( $exclusion['booking_id'] );
		if ( TutorHelper_Booking_Records::STATUS_UNCONFIRMED === sanitize_key( $exclusion['status'] ) ) {
			return TutorHelper_Booking_Records::delete_unconfirmed( $id, $tutor_user_id );
		}
		return TutorHelper_Booking_Records::cancel( $id, __( 'Removed while resolving a recurring lesson clash.', 'tutorhelper-pro' ), 'tutor' );
	}

	private static function remove_series_item( $series_id, $booking_id ) {
		global $wpdb;
		$wpdb->delete( TutorHelper_Pro_Booking_Series::get_items_table_name(), array( 'series_id' => absint( $series_id ), 'booking_id' => absint( $booking_id ) ), array( '%d', '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Pro owns recurring-series item records.
	}

	private static function update_occurrence_dates( $series_id, $updates ) {
		global $wpdb;
		foreach ( $updates as $update ) {
			$wpdb->update( TutorHelper_Pro_Booking_Series::get_items_table_name(), array( 'occurrence_date' => sanitize_text_field( $update['data']['booking_date'] ) ), array( 'series_id' => absint( $series_id ), 'booking_id' => absint( $update['booking_id'] ) ), array( '%s' ), array( '%d', '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Keeps recurring-series dates aligned with resolved booking updates.
		}
	}

	/** Keep the series snapshot aligned with its future occurrences. */
	private static function update_series_snapshot( $series_id, $data ) {
		global $wpdb;
		$items = TutorHelper_Pro_Booking_Series::get_items( $series_id );
		$dates = array_values( array_filter( wp_list_pluck( $items, 'occurrence_date' ) ) );
		sort( $dates );
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Canonical recurring-series snapshot write.
			TutorHelper_Pro_Booking_Series::get_table_name(),
			array( 'booking_type_id' => absint( $data['booking_type_id'] ), 'start_date' => $dates ? reset( $dates ) : sanitize_text_field( $data['booking_date'] ), 'end_date' => $dates ? end( $dates ) : sanitize_text_field( $data['booking_date'] ), 'start_time' => sanitize_text_field( $data['start_time'] ), 'end_time' => sanitize_text_field( $data['end_time'] ), 'timezone' => sanitize_text_field( $data['timezone'] ), 'location_type' => sanitize_key( $data['location_type'] ), 'location_details' => sanitize_textarea_field( $data['location_details'] ), 'booking_status' => sanitize_key( $data['status'] ), 'notes' => sanitize_textarea_field( $data['notes'] ), 'updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => absint( $series_id ) ),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	/** Keep the edited item's occurrence date aligned with its booking. */
	private static function update_selected_occurrence_date( $series_id, $booking_id, $date ) {
		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Canonical recurring-series item write.
			TutorHelper_Pro_Booking_Series::get_items_table_name(),
			array( 'occurrence_date' => sanitize_text_field( $date ) ),
			array( 'series_id' => absint( $series_id ), 'booking_id' => absint( $booking_id ) ),
			array( '%s' ),
			array( '%d', '%d' )
		);
	}
}
