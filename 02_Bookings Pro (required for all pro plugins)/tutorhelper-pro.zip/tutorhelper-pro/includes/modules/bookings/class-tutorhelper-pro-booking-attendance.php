<?php
/**
 * TutorHelper Pro booking attendance data service.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and retrieves attendance records for Core bookings.
 */
final class TutorHelper_Pro_Booking_Attendance {

	/**
	 * Register attendance display integrations.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter(
			'tutorhelper_calendar_booking_records_prepared',
			array( __CLASS__, 'apply_calendar_statuses' ),
			10,
			1
		);
	}

	/**
	 * Attendance status: not yet recorded.
	 *
	 * @var string
	 */
	const STATUS_NOT_RECORDED = 'not_recorded';

	/**
	 * Attendance status: attended.
	 *
	 * @var string
	 */
	const STATUS_ATTENDED = 'attended';

	/**
	 * Attendance status: arrived late.
	 *
	 * @var string
	 */
	const STATUS_LATE = 'late';

	/**
	 * Attendance status: missed lesson.
	 *
	 * @var string
	 */
	const STATUS_MISSED = 'missed';

	/**
	 * Attendance status: information-only booking.
	 *
	 * @var string
	 */
	const STATUS_INFO_ONLY = 'info_only';

    /**
     * Attendance status: attendance does not apply.
     *
     * Used for cancelled bookings and other cases where
     * attendance should not be recorded.
     *
     * @var string
     */
    const STATUS_NOT_APPLICABLE = 'not_applicable';


	/**
	 * Return valid attendance statuses and their labels.
	 *
	 * @return array
	 */
	public static function get_statuses() {
		return array(
			self::STATUS_NOT_RECORDED =>
				__( '📅 Not Recorded', 'tutorhelper-pro' ),

			self::STATUS_ATTENDED =>
				__( '✅ Attended', 'tutorhelper-pro' ),

			self::STATUS_LATE =>
				__( '🕓 Late', 'tutorhelper-pro' ),

			self::STATUS_MISSED =>
				__( '❌ Missed', 'tutorhelper-pro' ),

			self::STATUS_INFO_ONLY =>
				__( 'ℹ️ Info Only', 'tutorhelper-pro' ),

            self::STATUS_NOT_APPLICABLE =>
			__( '➖ Not Applicable', 'tutorhelper-pro' ),
		);
	}


	/**
	 * Return an attendance label.
	 *
	 * @param string $status Attendance status.
	 *
	 * @return string
	 */
	public static function get_status_label( $status ) {

		$statuses = self::get_statuses();

		return isset( $statuses[ $status ] )
			? $statuses[ $status ]
			: $statuses[ self::STATUS_NOT_RECORDED ];
	}


	/**
	 * Return the emoji associated with an attendance status.
	 *
	 * @param string $status Attendance status.
	 *
	 * @return string
	 */
	public static function get_status_icon( $status ) {

		$icons = array(
			self::STATUS_ATTENDED  => '✅',
			self::STATUS_LATE      => '🕓',
			self::STATUS_MISSED    => '❌',
			self::STATUS_INFO_ONLY => 'ℹ️',
		);

		$status = sanitize_key( $status );

		return isset( $icons[ $status ] )
			? $icons[ $status ]
			: '';
	}


	/**
	 * Return attendance records for several bookings.
	 *
	 * @param array $booking_ids Booking IDs.
	 *
	 * @return array
	 */
	public static function get_for_booking_ids(
		$booking_ids
	) {
		global $wpdb;

		$booking_ids = array_values(
			array_filter(
				array_map(
					'absint',
					(array) $booking_ids
				)
			)
		);

		if ( empty( $booking_ids ) ) {
			return array();
		}

		$table_name =
			TutorHelper_Pro_Database::get_table_name(
				'booking_attendance'
			);

		if ( empty( $table_name ) ) {
			return array();
		}

		$placeholders = implode(
			', ',
			array_fill(
				0,
				count( $booking_ids ),
				'%d'
			)
		);

		$sql = $wpdb->prepare(
			"SELECT *
			FROM %i
			WHERE booking_id IN ({$placeholders})",
			array_merge(
				array( $table_name ),
				$booking_ids
			)
		);

		$rows = $wpdb->get_results( $sql );

		$records = array();

		foreach ( $rows as $row ) {
			$records[
				absint( $row->booking_id )
			] = $row;
		}

		return $records;
	}


	/**
	 * Apply recorded attendance as the display status of completed lessons.
	 *
	 * Stored booking state remains unchanged.
	 *
	 * @param array $records Prepared Core calendar records.
	 *
	 * @return array
	 */
	public static function apply_calendar_statuses(
		$records
	) {
		if ( ! is_array( $records ) || empty( $records ) ) {
			return is_array( $records ) ? $records : array();
		}

		$booking_ids = wp_list_pluck(
			$records,
			'id'
		);
		$attendance = self::get_for_booking_ids(
			$booking_ids
		);
		$now = current_time(
			'timestamp',
			true
		);

		foreach ( $records as &$record ) {
			$booking_id = isset( $record['id'] )
				? absint( $record['id'] )
				: 0;
			$status = isset( $record['status'] )
				? sanitize_key( $record['status'] )
				: '';
			$end = isset( $record['utc_end'] )
				? strtotime( $record['utc_end'] . ' UTC' )
				: false;

			if (
				! $booking_id
				|| TutorHelper_Booking_Records::STATUS_CONFIRMED !== $status
				|| empty( $attendance[ $booking_id ]->attendance_status )
			) {
				continue;
			}

			$attendance_status = sanitize_key(
				$attendance[ $booking_id ]->attendance_status
			);

			if (
				in_array(
					$attendance_status,
					array(
						self::STATUS_NOT_RECORDED,
						self::STATUS_NOT_APPLICABLE,
					),
					true
				)
			) {
				continue;
			}

			$record['attendance_status'] =
				$attendance_status;

			$attendance_icon = self::get_status_icon(
				$attendance_status
			);

			if ( '' !== $attendance_icon ) {
				$record['attendance_icon'] = $attendance_icon;

				if (
					! empty( $record['student_name'] )
					&& false === strpos(
						(string) $record['student_name'],
						$attendance_icon
					)
				) {
					$record['student_name'] = sprintf(
						'%1$s %2$s',
						sanitize_text_field( $record['student_name'] ),
						$attendance_icon
					);
				}
			}

			if ( false !== $end && $end <= $now ) {
				$record['display_status_label'] =
					self::get_status_label(
						$attendance_status
					);
			}
		}
		unset( $record );

		return $records;
	}


	/**
	 * Save attendance for one booking.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param string $status Attendance status.
	 * @param int    $recorded_by_user_id User recording attendance.
	 *
	 * @return true|WP_Error
	 */
	public static function save(
		$booking_id,
		$status,
		$recorded_by_user_id
	) {
		global $wpdb;

		$booking_id =
			absint( $booking_id );

		$recorded_by_user_id =
			absint( $recorded_by_user_id );

		$status =
			sanitize_key( $status );

		if ( ! $booking_id ) {
			return new WP_Error(
				'tutorhelper_pro_attendance_invalid_booking',
				__(
					'The booking could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! array_key_exists(
				$status,
				self::get_statuses()
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_attendance_invalid_status',
				__(
					'The attendance status is invalid.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			self::STATUS_NOT_APPLICABLE
			=== $status
		) {
			return new WP_Error(
				'tutorhelper_pro_attendance_not_applicable_manual',
				__(
					'Not Applicable is set automatically for cancelled bookings.',
					'tutorhelper-pro'
				)
			);
		}

		/*
		 * Verify that the Core booking actually exists.
		 */
		$booking =
			TutorHelper_Booking_Records::get_by_id(
				$booking_id
			);

		if ( ! $booking ) {
			return new WP_Error(
				'tutorhelper_pro_attendance_booking_not_found',
				__(
					'The booking could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$table_name =
			TutorHelper_Pro_Database::get_table_name(
				'booking_attendance'
			);

		if ( empty( $table_name ) ) {
			return new WP_Error(
				'tutorhelper_pro_attendance_table_missing',
				__(
					'Attendance could not be saved.',
					'tutorhelper-pro'
				)
			);
		}

		$now = current_time(
			'mysql',
			true
		);

		$existing_id = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id
				FROM %i
				WHERE booking_id = %d',
				$table_name,
				$booking_id
			)
		);

		if ( $existing_id ) {

			$result = $wpdb->update(
				$table_name,
				array(
					'attendance_status' =>
						$status,

					'recorded_at' =>
						$now,

					'recorded_by_user_id' =>
						$recorded_by_user_id,

					'updated_at' =>
						$now,
				),
				array(
					'booking_id' =>
						$booking_id,
				),
				array(
					'%s',
					'%s',
					'%d',
					'%s',
				),
				array(
					'%d',
				)
			);

		} else {

			$result = $wpdb->insert(
				$table_name,
				array(
					'booking_id' =>
						$booking_id,

					'attendance_status' =>
						$status,

					'recorded_at' =>
						$now,

					'recorded_by_user_id' =>
						$recorded_by_user_id,

					'created_at' =>
						$now,

					'updated_at' =>
						$now,
				),
				array(
					'%d',
					'%s',
					'%s',
					'%d',
					'%s',
					'%s',
				)
			);
		}

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_pro_attendance_save_failed',
				__(
					'Attendance could not be saved.',
					'tutorhelper-pro'
				)
			);
		}

		return true;
	}
}
