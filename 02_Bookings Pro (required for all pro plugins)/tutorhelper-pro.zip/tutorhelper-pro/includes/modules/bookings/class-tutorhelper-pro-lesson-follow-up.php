<?php
/**
 * Lesson feedback, homework and student ratings.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores tutor follow-up separately from attendance and exposes it consistently
 * across ordinary and Group Lesson dashboards.
 */
final class TutorHelper_Pro_Lesson_Follow_Up {

	const SETTINGS_TAB = 'lesson-follow-up';
	const SETTINGS_ACTION = 'tutorhelper_pro_save_lesson_follow_up_settings';
	const RATINGS_OPTION = 'tutorhelper_pro_lesson_ratings_enabled';
	const LOAD_ACTION = 'tutorhelper_pro_load_lesson_follow_up';
	const SAVE_ACTION = 'tutorhelper_pro_save_lesson_follow_up';
	const RATING_ACTION = 'tutorhelper_pro_submit_lesson_rating';
	const ADMIN_NONCE = 'tutorhelper_pro_lesson_follow_up';
	const RATING_NONCE = 'tutorhelper_pro_lesson_rating';

	/** @var bool */
	private static $admin_assets_loaded = false;

	/** @var int */
	private static $rating_instance = 0;

	/** Register hooks. */
	public static function init() {
		add_filter( 'tutorhelper_settings_tabs', array( __CLASS__, 'add_settings_tab' ) );
		add_action( 'tutorhelper_settings_render_tab', array( __CLASS__, 'render_settings_tab' ) );
		add_action( 'admin_post_' . self::SETTINGS_ACTION, array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ), 80 );
		add_action( 'admin_footer', array( __CLASS__, 'render_admin_modal' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend_assets' ) );
		add_action( 'wp_ajax_' . self::LOAD_ACTION, array( __CLASS__, 'load_ajax' ) );
		add_action( 'wp_ajax_' . self::SAVE_ACTION, array( __CLASS__, 'save_ajax' ) );
		add_action( 'wp_ajax_' . self::RATING_ACTION, array( __CLASS__, 'save_rating_ajax' ) );
		add_action( 'tutorhelper_student_dashboard_booking_details', array( __CLASS__, 'render_student_details' ), 20, 2 );
		add_action( 'tutorhelper_group_dashboard_session_details', array( __CLASS__, 'render_group_session_details' ), 20, 3 );
	}

	/** Add the Pro lesson follow-up settings tab. */
	public static function add_settings_tab( $tabs ) {
		if ( TutorHelper_Pro_License::is_active() ) {
			$tabs[ self::SETTINGS_TAB ] = array(
				'label' => __( 'Lesson feedback', 'tutorhelper-pro' ),
				'icon'  => 'dashicons-star-filled',
			);
		}
		return $tabs;
	}

	/** Render the lesson follow-up settings. */
	public static function render_settings_tab( $selected_tab ) {
		if ( self::SETTINGS_TAB !== $selected_tab || ! TutorHelper_Pro_License::is_active() ) {
			return;
		}
		?>
		<section class="tutorhelper-main-section">
			<header class="tutorhelper-main-section__header is-compact">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'Lesson feedback and ratings', 'tutorhelper-pro' ); ?></h2>
					<p><?php esc_html_e( 'Choose whether students can rate completed lessons. Tutor feedback and homework remain available regardless of this setting.', 'tutorhelper-pro' ); ?></p>
				</div>
			</header>
			<div class="tutorhelper-main-section__body">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::SETTINGS_ACTION ); ?>" />
					<?php wp_nonce_field( self::SETTINGS_ACTION ); ?>
					<label class="tutorhelper-pro-follow-up-setting">
						<input type="checkbox" name="lesson_ratings_enabled" value="1" <?php checked( self::ratings_enabled() ); ?> />
						<span>
							<strong><?php esc_html_e( 'Allow lesson ratings', 'tutorhelper-pro' ); ?></strong><br />
							<?php esc_html_e( 'Students can submit a 1–5 star rating and an optional private comment after a completed lesson.', 'tutorhelper-pro' ); ?>
						</span>
					</label>
					<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Save settings', 'tutorhelper-pro' ); ?></button></p>
				</form>
			</div>
		</section>
		<?php
	}

	/** Save the rating preference. */
	public static function save_settings() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die(
				esc_html__( 'You do not have permission to change these settings.', 'tutorhelper-pro' ),
				'',
				array( 'response' => 403 )
			);
		}
		check_admin_referer( self::SETTINGS_ACTION );
		update_option( self::RATINGS_OPTION, isset( $_POST['lesson_ratings_enabled'] ) ? '1' : '0' );
		$url = add_query_arg(
			array(
				'page'                    => TutorHelper_Admin::MENU_SLUG,
				'tab'                     => self::SETTINGS_TAB,
				'tutorhelper_pro_updated' => '1',
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}

	/** Whether student lesson ratings are enabled. */
	public static function ratings_enabled() {
		return '1' === get_option( self::RATINGS_OPTION, '0' );
	}

	/** Load tutor-facing assets on TutorHelper admin screens. */
	public static function enqueue_admin_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix || ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return;
		}
		self::$admin_assets_loaded = true;
		wp_enqueue_media();
		self::enqueue_style();
		$path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-lesson-follow-up-admin.js';
		wp_enqueue_script(
			'tutorhelper-pro-lesson-follow-up-admin',
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-lesson-follow-up-admin.js',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_PRO_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-pro-lesson-follow-up-admin',
			'tutorhelperProLessonFollowUp',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'loadAction' => self::LOAD_ACTION,
				'saveAction' => self::SAVE_ACTION,
				'nonce'      => wp_create_nonce( self::ADMIN_NONCE ),
				'chooseFile' => __( 'Choose homework file', 'tutorhelper-pro' ),
				'useFile'    => __( 'Use this file', 'tutorhelper-pro' ),
				'loading'    => __( 'Loading…', 'tutorhelper-pro' ),
				'saving'     => __( 'Saving…', 'tutorhelper-pro' ),
				'failed'     => __( 'The lesson follow-up could not be saved.', 'tutorhelper-pro' ),
				'groupFeedbackLabel' => __( 'Feedback for the group', 'tutorhelper-pro' ),
				'studentFeedbackLabel' => __( 'Feedback for the student', 'tutorhelper-pro' ),
				'homeworkFallback' => __( 'Homework', 'tutorhelper-pro' ),
				'homeworkSetAfter' => __( 'Set after', 'tutorhelper-pro' ),
				'openHomeworkLink' => __( 'Open homework link', 'tutorhelper-pro' ),
				'downloadHomeworkFile' => __( 'Download homework file', 'tutorhelper-pro' ),
			)
		);
	}

	/** Load student-facing rating behaviour and shared styles. */
	public static function enqueue_frontend_assets() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		self::enqueue_style();
		$path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-lesson-rating.js';
		wp_enqueue_script(
			'tutorhelper-pro-lesson-rating',
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-lesson-rating.js',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_PRO_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-pro-lesson-rating',
			'tutorhelperProLessonRating',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => self::RATING_ACTION,
				'nonce'   => wp_create_nonce( self::RATING_NONCE ),
				'saving'  => __( 'Saving…', 'tutorhelper-pro' ),
				'saved'   => __( 'Thank you. Your rating has been saved.', 'tutorhelper-pro' ),
				'failed'  => __( 'Your rating could not be saved. Please try again.', 'tutorhelper-pro' ),
				'update'  => __( 'Update rating', 'tutorhelper-pro' ),
				'stars'   => __( '%1$d out of %2$d stars', 'tutorhelper-pro' ),
			)
		);
	}

	/** Enqueue shared presentation. */
	private static function enqueue_style() {
		$path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-lesson-follow-up.css';
		wp_enqueue_style(
			'tutorhelper-pro-lesson-follow-up',
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-lesson-follow-up.css',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_PRO_VERSION
		);
	}

	/** Render a tutor action beside one booking. */
	public static function render_tutor_button( $booking_id, $group_session_id = 0 ) {
		$booking = TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) );
		if ( ! $booking || TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
			return;
		}
		if ( ! $group_session_id ) {
			$group_context = self::get_group_booking_context( $booking_id );
			$group_session_id = $group_context
				? absint( $group_context['session_id'] )
				: 0;
		}
		?>
		<button
			type="button"
			class="button tutorhelper-admin-button tutorhelper-pro-follow-up-open"
			data-follow-up-booking-id="<?php echo esc_attr( absint( $booking_id ) ); ?>"
			data-follow-up-group-session-id="<?php echo esc_attr( absint( $group_session_id ) ); ?>"
			data-follow-up-scope="<?php echo esc_attr( $group_session_id ? 'student' : 'booking' ); ?>"
		>
			<?php
			echo esc_html(
				$group_session_id
					? __( 'Personalise', 'tutorhelper-pro' )
					: __( 'Feedback & homework', 'tutorhelper-pro' )
			);
			?>
			<?php self::render_homework_indicators( $booking_id ); ?>
		</button>
		<?php
	}

	/**
	 * Render the shared follow-up action for a Group Session.
	 *
	 * @param int $group_session_id Group Session ID.
	 * @return void
	 */
	public static function render_group_tutor_button( $group_session_id ) {
		if ( ! class_exists( 'TutorHelper_Group_Sessions' ) || ! TutorHelper_Group_Sessions::get_by_id( absint( $group_session_id ) ) ) {
			return;
		}
		?>
		<button
			type="button"
			class="button tutorhelper-admin-button tutorhelper-pro-follow-up-open tutorhelper-pro-follow-up-open--group"
			data-follow-up-booking-id="0"
			data-follow-up-group-session-id="<?php echo esc_attr( absint( $group_session_id ) ); ?>"
			data-follow-up-scope="group"
		>
			<?php esc_html_e( 'Feedback & homework for group', 'tutorhelper-pro' ); ?>
		</button>
		<?php
	}

	/** Render the single reusable tutor modal. */
	public static function render_admin_modal() {
		if ( ! self::$admin_assets_loaded ) {
			return;
		}
		?>
		<dialog class="tutorhelper-pro-follow-up-modal" data-follow-up-modal aria-labelledby="tutorhelper-pro-follow-up-title">
			<form method="dialog" class="tutorhelper-pro-follow-up-modal__shell">
				<header>
					<div><h2 id="tutorhelper-pro-follow-up-title"><?php esc_html_e( 'Lesson feedback and homework', 'tutorhelper-pro' ); ?></h2><p data-follow-up-lesson-label></p></div>
					<button type="submit" class="tutorhelper-pro-follow-up-modal__close" aria-label="<?php esc_attr_e( 'Close', 'tutorhelper-pro' ); ?>">×</button>
				</header>
			</form>
			<form class="tutorhelper-pro-follow-up-form" data-follow-up-form>
				<input type="hidden" name="booking_id" value="" />
				<input type="hidden" name="group_session_id" value="" />
				<input type="hidden" name="follow_up_scope" value="booking" />
				<div class="tutorhelper-pro-follow-up-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Homework details', 'tutorhelper-pro' ); ?>">
					<button type="button" role="tab" aria-selected="true" aria-controls="tutorhelper-follow-up-set-panel" id="tutorhelper-follow-up-set-tab" data-follow-up-tab="set">
						<?php esc_html_e( 'Set after this lesson', 'tutorhelper-pro' ); ?>
					</button>
					<button type="button" role="tab" aria-selected="false" aria-controls="tutorhelper-follow-up-due-panel" id="tutorhelper-follow-up-due-tab" data-follow-up-tab="due" hidden>
						<?php esc_html_e( 'Due for this lesson', 'tutorhelper-pro' ); ?>
						<span data-follow-up-due-count></span>
					</button>
				</div>
				<section id="tutorhelper-follow-up-set-panel" role="tabpanel" aria-labelledby="tutorhelper-follow-up-set-tab" data-follow-up-panel="set">
					<label class="tutorhelper-pro-follow-up-use-shared" data-follow-up-use-shared-wrap hidden>
						<input type="checkbox" name="use_group_default" value="1" data-follow-up-use-shared />
						<span><strong><?php esc_html_e( 'Use the shared Group Session feedback and homework', 'tutorhelper-pro' ); ?></strong><br /><?php esc_html_e( 'Untick this only when this student needs different feedback or homework.', 'tutorhelper-pro' ); ?></span>
					</label>
					<div data-follow-up-editable-fields>
						<label><span data-follow-up-feedback-label><?php esc_html_e( 'Feedback for the student', 'tutorhelper-pro' ); ?></span><textarea name="tutor_feedback" rows="5"></textarea></label>
						<fieldset>
							<legend><?php esc_html_e( 'Homework for the next session', 'tutorhelper-pro' ); ?></legend>
							<label><span><?php esc_html_e( 'Homework title', 'tutorhelper-pro' ); ?></span><input type="text" name="homework_title" maxlength="190" /></label>
							<label><span><?php esc_html_e( 'What the student needs to do', 'tutorhelper-pro' ); ?></span><textarea name="homework_instructions" rows="5"></textarea></label>
							<label><span><?php esc_html_e( 'Homework link', 'tutorhelper-pro' ); ?></span><input type="url" name="homework_url" placeholder="https://" /></label>
							<label><span><?php esc_html_e( 'File', 'tutorhelper-pro' ); ?></span>
								<span class="tutorhelper-pro-follow-up-file">
									<input type="hidden" name="homework_attachment_id" value="" />
									<button type="button" class="button" data-follow-up-choose-file><?php esc_html_e( 'Choose file', 'tutorhelper-pro' ); ?></button>
									<button type="button" class="button-link-delete" data-follow-up-remove-file hidden><?php esc_html_e( 'Remove', 'tutorhelper-pro' ); ?></button>
									<output data-follow-up-file-name><?php esc_html_e( 'No file selected', 'tutorhelper-pro' ); ?></output>
								</span>
							</label>
							<label><span><?php esc_html_e( 'Due for lesson', 'tutorhelper-pro' ); ?></span><select name="homework_due_booking_id"><option value="0"><?php esc_html_e( 'No particular lesson', 'tutorhelper-pro' ); ?></option></select></label>
							<div class="tutorhelper-pro-homework-academic-context" data-follow-up-academic-context hidden>
								<label><span><?php esc_html_e( 'Course', 'tutorhelper-pro' ); ?></span><select name="homework_course_id" data-follow-up-course><option value="0"><?php esc_html_e( 'No course selected', 'tutorhelper-pro' ); ?></option></select><span class="description"><?php esc_html_e( 'Optional. Courses are available from the student’s active Groups.', 'tutorhelper-pro' ); ?></span></label>
								<fieldset data-follow-up-topics-wrap hidden><legend><?php esc_html_e( 'Topics', 'tutorhelper-pro' ); ?></legend><div data-follow-up-topics></div><span class="description"><?php esc_html_e( 'Optional. Select the relevant topics for this homework.', 'tutorhelper-pro' ); ?></span></fieldset>
							</div>
							<?php
							/**
							 * TutorHelper LMS Premium can add selectors for reusable, privately stored
							 * teaching resources here. Pro deliberately stores no LMS resource data.
							 */
							do_action( 'tutorhelper_pro_homework_resource_fields' );
							?>
							<label class="tutorhelper-pro-follow-up-submission">
								<input type="checkbox" name="homework_submission_enabled" value="1" />
								<span><strong><?php esc_html_e( 'Accept a student submission for this homework', 'tutorhelper-pro' ); ?></strong><br /><?php esc_html_e( 'When TutorHelper LMS is active, the student can submit one private file or a link from their dashboard.', 'tutorhelper-pro' ); ?></span>
							</label>
							<label><span><?php esc_html_e( 'Assessment type', 'tutorhelper-pro' ); ?></span><select name="homework_assessment_type"><option value="completion"><?php esc_html_e( 'Completion only', 'tutorhelper-pro' ); ?></option><option value="marked"><?php esc_html_e( 'Marked', 'tutorhelper-pro' ); ?></option></select></label>
							<label><span><?php esc_html_e( 'Maximum mark', 'tutorhelper-pro' ); ?></span><input type="number" name="homework_max_mark" min="0.01" step="0.01" /><span class="description"><?php esc_html_e( 'Required only for marked homework.', 'tutorhelper-pro' ); ?></span></label>
						</fieldset>
					</div>
				</section>
				<section id="tutorhelper-follow-up-due-panel" role="tabpanel" aria-labelledby="tutorhelper-follow-up-due-tab" data-follow-up-panel="due" hidden>
					<div class="tutorhelper-pro-homework-due-list" data-homework-due-list></div>
					<label class="tutorhelper-pro-homework-completed" data-homework-completed-wrap hidden>
						<input type="checkbox" name="homework_completed" value="1" />
						<span><?php esc_html_e( 'Homework due for this lesson has been completed', 'tutorhelper-pro' ); ?></span>
					</label>
				</section>
				<div class="tutorhelper-pro-follow-up-rating-summary" data-follow-up-rating-summary hidden></div>
				<p class="tutorhelper-pro-follow-up-form__status" data-follow-up-status aria-live="polite"></p>
				<footer>
					<button type="button" class="button" data-follow-up-cancel><?php esc_html_e( 'Cancel', 'tutorhelper-pro' ); ?></button>
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Save feedback and homework', 'tutorhelper-pro' ); ?></button>
				</footer>
			</form>
		</dialog>
		<?php
	}

	/** Return current follow-up and valid due lessons. */
	public static function load_ajax() {
		self::check_admin_ajax();
		$context = self::posted_context();
		if ( is_wp_error( $context ) ) {
			self::log_follow_up_error(
				'Lesson follow-up context could not be loaded.',
				self::error_context_from_request( 'load', $context->get_error_code() )
			);
			wp_send_json_error( array( 'message' => $context->get_error_message() ), 400 );
		}

		$is_group_default = 'group' === $context['scope'];
		$is_group_override = 'student' === $context['scope'];
		$own_record = ! empty( $context['booking'] ) ? self::get_for_booking( $context['booking']->id ) : self::get_for_group_session( $context['session']->id );
		$shared_record = $is_group_override ? self::get_for_group_session( $context['session']->id ) : null;
		$record = $own_record ? $own_record : $shared_record;
		$rating = ! empty( $context['booking'] ) ? self::get_rating( $context['booking']->id ) : null;
		$academic_context = ! empty( $context['booking'] ) ? self::academic_context_for_student( $context['booking']->student_user_id ) : array();
		$due_options = $is_group_default
			? self::get_due_group_session_options( $context['session'] )
			: self::get_due_booking_options( $context['booking'] );
		$due_id = 0;
		if ( $record && $is_group_default ) {
			$due_id = absint( $record->homework_due_group_session_id );
		} elseif ( $own_record ) {
			$due_id = absint( $own_record->homework_due_booking_id );
		}

		wp_send_json_success(
			array(
				'lessonLabel' => $is_group_default ? self::group_session_label( $context['session'] ) : self::booking_label( $context['booking'] ),
				'isGroupOverride' => $is_group_override,
				'useGroupDefault' => $is_group_override && ! $own_record,
				'followUp' => array(
					'tutor_feedback'           => $record ? (string) $record->tutor_feedback : '',
					'homework_source_id'       => $record ? absint( $record->id ) : 0,
					'homework_title'           => $record ? (string) $record->homework_title : '',
					'homework_instructions'    => $record ? (string) $record->homework_instructions : '',
					'homework_url'             => $record ? (string) $record->homework_url : '',
					'homework_attachment_id'   => $record ? absint( $record->homework_attachment_id ) : 0,
					'homework_attachment_name' => $record && $record->homework_attachment_id ? get_the_title( absint( $record->homework_attachment_id ) ) : '',
					'homework_due_booking_id'  => $due_id,
					'homework_submission_enabled' => $record ? (bool) $record->homework_submission_enabled : false,
					'homework_assessment_type' => $record ? (string) $record->homework_assessment_type : 'completion',
					'homework_max_mark'        => $record && null !== $record->homework_max_mark ? (string) $record->homework_max_mark : '',
					'homework_course_id'       => $record ? absint( $record->homework_course_id ) : 0,
					'homework_topic_ids'       => $record ? self::topic_ids( $record->homework_topic_ids ) : array(),
				),
				'academicContext' => $academic_context,
				'dueBookings' => $due_options,
				'dueHomework' => self::prepare_due_homework( $context ),
				'homeworkCompleted' => ! empty( $context['booking'] )
					? self::is_homework_completed( $context['booking']->id )
					: false,
				'homeworkCompletionManaged' => ! empty( $context['booking'] )
					? (bool) apply_filters(
						'tutorhelper_pro_homework_completion_managed',
						false,
						absint( $context['booking']->id ),
						$context['booking']
					)
					: false,
				'rating' => $rating ? array( 'value' => absint( $rating->rating ), 'comment' => (string) $rating->comment ) : null,
			)
		);
	}

	/** Save tutor feedback and homework. */
	public static function save_ajax() {
		self::check_admin_ajax();
		$context = self::posted_context();
		if ( is_wp_error( $context ) ) {
			self::log_follow_up_error(
				'Lesson follow-up context could not be saved.',
				self::error_context_from_request( 'save', $context->get_error_code() )
			);
			wp_send_json_error( array( 'message' => $context->get_error_message() ), 400 );
		}

		$is_group_default = 'group' === $context['scope'];
		$is_group_override = 'student' === $context['scope'];
		if ( ! empty( $context['booking'] ) && ! apply_filters(
			'tutorhelper_pro_homework_completion_managed',
			false,
			absint( $context['booking']->id ),
			$context['booking']
		) ) {
			self::set_homework_completed(
				$context['booking'],
				isset( $_POST['homework_completed'] )
			);
		}
		$use_group_default = $is_group_override && isset( $_POST['use_group_default'] );
		global $wpdb;
		$booking_table = TutorHelper_Pro_Database::get_table_name( 'lesson_follow_up' );
		$group_table = TutorHelper_Pro_Database::get_table_name( 'group_lesson_follow_up' );
		$table = $is_group_default ? $group_table : $booking_table;

		if ( $use_group_default ) {
			$deleted = $wpdb->delete( $booking_table, array( 'booking_id' => absint( $context['booking']->id ) ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicitly restores inheritance from the shared Group Session record.
			if ( false === $deleted ) {
				self::send_database_error( 'delete_override', $context, $booking_table, 0, 0 );
			}
			wp_send_json_success( array( 'message' => __( 'This student now uses the shared Group Session feedback and homework.', 'tutorhelper-pro' ) ) );
		}

		$feedback = isset( $_POST['tutor_feedback'] ) && ! is_array( $_POST['tutor_feedback'] ) ? sanitize_textarea_field( wp_unslash( $_POST['tutor_feedback'] ) ) : '';
		$title = isset( $_POST['homework_title'] ) && ! is_array( $_POST['homework_title'] ) ? sanitize_text_field( wp_unslash( $_POST['homework_title'] ) ) : '';
		$instructions = isset( $_POST['homework_instructions'] ) && ! is_array( $_POST['homework_instructions'] ) ? sanitize_textarea_field( wp_unslash( $_POST['homework_instructions'] ) ) : '';
		$url = isset( $_POST['homework_url'] ) && ! is_array( $_POST['homework_url'] ) ? esc_url_raw( wp_unslash( $_POST['homework_url'] ), array( 'http', 'https' ) ) : '';
		$attachment_id = isset( $_POST['homework_attachment_id'] ) ? absint( $_POST['homework_attachment_id'] ) : 0;
		$due_id = isset( $_POST['homework_due_booking_id'] ) ? absint( $_POST['homework_due_booking_id'] ) : 0;
		$submission_enabled = isset( $_POST['homework_submission_enabled'] );
		$academic_context = ! empty( $context['booking'] ) ? self::academic_context_for_student( $context['booking']->student_user_id ) : array();
		$course_id = isset( $_POST['homework_course_id'] ) ? absint( $_POST['homework_course_id'] ) : 0;
		$topic_ids = isset( $_POST['homework_topic_ids'] ) && is_array( $_POST['homework_topic_ids'] ) ? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['homework_topic_ids'] ) ) ) ) ) : array();
		$course = self::academic_course( $academic_context, $course_id );
		if ( ! $course ) { $course_id = 0; $topic_ids = array(); }
		$allowed_topic_ids = $course ? wp_list_pluck( $course['topics'], 'id' ) : array();
		$topic_ids = array_values( array_intersect( $topic_ids, array_map( 'absint', $allowed_topic_ids ) ) );
		$source_group_id = $course && ! empty( $course['source_group_ids'] ) ? absint( $course['source_group_ids'][0] ) : 0;
		$assessment_type = isset( $_POST['homework_assessment_type'] ) && ! is_array( $_POST['homework_assessment_type'] )
			? sanitize_key( wp_unslash( $_POST['homework_assessment_type'] ) )
			: 'completion';
		$assessment_type = in_array( $assessment_type, array( 'completion', 'marked' ), true ) ? $assessment_type : 'completion';
		$max_mark = isset( $_POST['homework_max_mark'] ) && ! is_array( $_POST['homework_max_mark'] )
			? (float) wp_unslash( $_POST['homework_max_mark'] )
			: 0;
		if ( $submission_enabled && '' === $title ) {
			wp_send_json_error( array( 'message' => __( 'A homework title is required when accepting student submissions.', 'tutorhelper-pro' ) ), 400 );
		}
		if ( $submission_enabled && 'marked' === $assessment_type && $max_mark <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Enter a maximum mark for marked homework.', 'tutorhelper-pro' ) ), 400 );
		}

		if ( $attachment_id && 'attachment' !== get_post_type( $attachment_id ) ) {
			self::log_follow_up_error(
				'Lesson follow-up rejected an invalid attachment.',
				self::diagnostic_context( 'validate_attachment', $context, $table, $due_id, $attachment_id )
			);
			wp_send_json_error( array( 'message' => __( 'The selected homework file is invalid.', 'tutorhelper-pro' ) ), 400 );
		}
		if ( $due_id && $is_group_default && ! self::is_valid_due_group_session( $context['session'], $due_id ) ) {
			self::log_follow_up_error(
				'Lesson follow-up rejected an invalid Group Session due date.',
				self::diagnostic_context( 'validate_due_session', $context, $table, $due_id, $attachment_id )
			);
			wp_send_json_error( array( 'message' => __( 'The selected Group Session due date is invalid.', 'tutorhelper-pro' ) ), 400 );
		}
		if ( $due_id && ! $is_group_default && ! self::is_valid_due_booking( $context['booking'], $due_id ) ) {
			self::log_follow_up_error(
				'Lesson follow-up rejected an invalid booking due date.',
				self::diagnostic_context( 'validate_due_booking', $context, $table, $due_id, $attachment_id )
			);
			wp_send_json_error( array( 'message' => __( 'The selected homework due lesson is invalid.', 'tutorhelper-pro' ) ), 400 );
		}

		$key = $is_group_default
			? array( 'group_session_id' => absint( $context['session']->id ) )
			: array( 'booking_id' => absint( $context['booking']->id ) );
		$formats = array( '%d' );
		$existing = $is_group_default
			? self::get_for_group_session( $context['session']->id )
			: self::get_for_booking( $context['booking']->id );
		$has_pending_extension_content = (bool) apply_filters(
			'tutorhelper_pro_homework_has_pending_content',
			false,
			$_POST
		); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Pro has verified the follow-up save nonce before extension hooks run.
		if ( '' === $feedback && '' === $title && '' === $instructions && '' === $url && ! $attachment_id && ! $submission_enabled && ! $has_pending_extension_content ) {
			$deleted = $wpdb->delete( $table, $key, $formats ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit removal of one follow-up record.
			if ( false === $deleted ) {
				self::send_database_error( 'clear', $context, $table, $due_id, $attachment_id );
			}
			if ( ! $is_group_default && $existing ) {
				do_action(
					'tutorhelper_pro_homework_submission_updated',
					array(
						'source_id'       => absint( $existing->id ),
						'booking_id'      => absint( $context['booking']->id ),
						'due_booking_id'  => absint( $existing->homework_due_booking_id ),
						'student_user_id' => absint( $context['booking']->student_user_id ),
						'tutor_user_id'   => absint( $context['booking']->tutor_user_id ),
						'enabled'         => false,
					)
				);
			}
			wp_send_json_success( array( 'message' => __( 'Lesson follow-up cleared.', 'tutorhelper-pro' ) ) );
		}

		$now = current_time( 'mysql', true );
		$data = array(
			'tutor_feedback'                => $feedback,
			'homework_title'                => $title,
			'homework_instructions'         => $instructions,
			'homework_url'                  => $url,
			'homework_attachment_id'        => $attachment_id ?: null,
			'homework_submission_enabled'   => $submission_enabled ? 1 : 0,
			'homework_assessment_type'      => $assessment_type,
			'homework_max_mark'             => ( $submission_enabled && 'marked' === $assessment_type ) ? $max_mark : null,
			'homework_course_id'            => $course_id,
			'homework_source_group_id'      => $source_group_id,
			'homework_topic_ids'            => $topic_ids ? wp_json_encode( $topic_ids ) : null,
			'updated_by_user_id'            => get_current_user_id(),
			'updated_at'                    => $now,
		);
		if ( $is_group_default ) {
			$data['group_session_id'] = absint( $context['session']->id );
			$data['homework_due_group_session_id'] = $due_id ?: null;
		} else {
			$data['booking_id'] = absint( $context['booking']->id );
			$data['group_session_id'] = null;
			$data['homework_due_booking_id'] = $due_id ?: null;
			$data['homework_due_group_session_id'] = null;
		}
		$operation = $existing ? 'update' : 'insert';
		if ( $existing ) {
			$saved = $wpdb->update( $table, $data, $key ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current tutor follow-up state.
		} else {
			$data['created_at'] = $now;
			$saved = $wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds one tutor follow-up record.
		}
		if ( false === $saved ) {
			self::send_database_error( $operation, $context, $table, $due_id, $attachment_id );
		}
		if ( ! $is_group_default ) {
			do_action(
				'tutorhelper_pro_homework_submission_updated',
				array(
					'source_id'          => $existing ? absint( $existing->id ) : absint( $wpdb->insert_id ),
					'booking_id'         => absint( $context['booking']->id ),
					'due_booking_id'     => $due_id,
					'student_user_id'    => absint( $context['booking']->student_user_id ),
					'tutor_user_id'      => absint( $context['booking']->tutor_user_id ),
					'enabled'            => $submission_enabled,
					'assessment_type'    => $assessment_type,
					'title'              => $title,
					'instructions'       => $instructions,
					'max_mark'           => ( $submission_enabled && 'marked' === $assessment_type ) ? $max_mark : null,
					'course_id'          => $course_id,
					'source_group_id'    => $source_group_id,
					'topic_ids'          => $topic_ids,
				)
			);
		}
		wp_send_json_success( array( 'message' => __( 'Lesson feedback and homework saved.', 'tutorhelper-pro' ) ) );
	}


	/** Build the course and topic choices available from a student's active Groups. */
	private static function academic_context_for_student( $student_user_id ) {
		$student_user_id = absint( $student_user_id );
		$available = array();

		// LMS Core contributes active direct academic-course links here. Pro does
		// not require LMS, so an empty default preserves standalone operation.
		foreach ( apply_filters( 'tutorhelper_lms_student_academic_courses', array(), $student_user_id ) as $context ) {
			$course_id = absint( $context['course_id'] ?? 0 );
			if ( $course_id ) {
				$available[ $course_id ] = array( 'source_group_ids' => array(), 'direct' => true );
			}
		}

		if ( class_exists( 'TutorHelper_Pro_Groups' ) ) {
			foreach ( TutorHelper_Pro_Groups::get_student_group_courses( $student_user_id ) as $context ) {
				$course_id = absint( $context['course_id'] );
				if ( ! $course_id ) { continue; }
				if ( ! isset( $available[ $course_id ] ) ) {
					$available[ $course_id ] = array( 'source_group_ids' => array(), 'direct' => false );
				}
				$available[ $course_id ]['source_group_ids'] = array_merge( $available[ $course_id ]['source_group_ids'], array_map( 'absint', $context['source_group_ids'] ?? array() ) );
			}
		}

		$courses = array();
		foreach ( $available as $course_id => $context ) {
			if ( 'tutorhelper_course' !== get_post_type( $course_id ) ) { continue; }
			$topics = apply_filters( 'tutorhelper_lms_course_topics', array(), $course_id );
			$courses[] = array( 'id' => $course_id, 'title' => html_entity_decode( get_the_title( $course_id ), ENT_QUOTES, get_bloginfo( 'charset' ) ), 'source_group_ids' => array_values( array_unique( array_filter( $context['source_group_ids'] ) ) ), 'topics' => is_array( $topics ) ? $topics : array() );
		}
		return $courses;
	}

	/** Find one available course context. */
	private static function academic_course( $courses, $course_id ) {
		foreach ( is_array( $courses ) ? $courses : array() as $course ) { if ( absint( $course['id'] ?? 0 ) === absint( $course_id ) ) { return $course; } }
		return null;
	}

	/** Decode stored topic IDs safely. */
	private static function topic_ids( $value ) {
		$ids = is_string( $value ) ? json_decode( $value, true ) : $value;
		return is_array( $ids ) ? array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) ) : array();
	}

	/** Save a student's rating for one completed lesson. */
	public static function save_rating_ajax() {
		check_ajax_referer( self::RATING_NONCE, 'nonce' );
		if ( ! is_user_logged_in() || ! self::ratings_enabled() ) {
			wp_send_json_error( array( 'message' => __( 'Lesson ratings are not available.', 'tutorhelper-pro' ) ), 403 );
		}
		$booking_id = isset( $_POST['booking_id'] ) ? absint( $_POST['booking_id'] ) : 0;
		$rating = isset( $_POST['rating'] ) ? absint( $_POST['rating'] ) : 0;
		$comment = isset( $_POST['comment'] ) && ! is_array( $_POST['comment'] ) ? sanitize_textarea_field( wp_unslash( $_POST['comment'] ) ) : '';
		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		if ( ! self::student_can_rate( $booking, get_current_user_id() ) || $rating < 1 || $rating > 5 ) {
			wp_send_json_error( array( 'message' => __( 'This lesson cannot be rated.', 'tutorhelper-pro' ) ), 400 );
		}
		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'lesson_ratings' );
		$now = current_time( 'mysql', true );
		$existing = self::get_rating( $booking_id );
		$data = array(
			'booking_id'      => $booking_id,
			'student_user_id' => get_current_user_id(),
			'rating'          => $rating,
			'comment'         => $comment,
			'updated_at'      => $now,
		);
		if ( $existing ) {
			$saved = $wpdb->update( $table, $data, array( 'booking_id' => $booking_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current student's own rating.
		} else {
			$data['submitted_at'] = $now;
			$saved = $wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Adds one student rating.
		}
		if ( false === $saved ) {
			wp_send_json_error( array( 'message' => __( 'Your rating could not be saved.', 'tutorhelper-pro' ) ), 500 );
		}
		wp_send_json_success(
			array(
				'message' => __( 'Thank you. Your rating has been saved.', 'tutorhelper-pro' ),
				'rating'  => $rating,
				'comment' => $comment,
			)
		);
	}

	/** Render feedback, homework and the optional rating form for a student. */
	public static function render_student_details( $booking_data, $section = '' ) {
		$booking = self::resolve_booking( $booking_data );
		if ( ! $booking || absint( $booking->student_user_id ) !== get_current_user_id() ) {
			return;
		}
		$follow_up = self::get_for_booking( $booking->id );
		$due_homework = self::get_due_homework( $booking->id );
		$unfiltered_due_homework = $due_homework;
		$completed = self::is_completed( $booking );
		$has_source_content = $completed && $follow_up && ( '' !== trim( (string) $follow_up->tutor_feedback ) || self::has_homework( $follow_up ) );

		// A homework set and due for this same booking is one task, not two cards.
		if ( $follow_up && absint( $follow_up->homework_due_booking_id ) === absint( $booking->id ) ) {
			$due_homework = array_values(
				array_filter(
					$due_homework,
					function ( $homework ) use ( $follow_up ) {
						return absint( $homework->id ) !== absint( $follow_up->id );
					}
				)
			);
		}

		$display = apply_filters(
			'tutorhelper_pro_student_lesson_follow_up_display',
			array(
				'show_feedback'        => true,
				'show_source_homework' => true,
				'due_homework'         => $due_homework,
			),
			$booking,
			$follow_up
		);
		$show_feedback = ! empty( $display['show_feedback'] );
		$show_source_homework = ! empty( $display['show_source_homework'] );
		$due_homework = isset( $display['due_homework'] ) && is_array( $display['due_homework'] )
			? $display['due_homework']
			: $due_homework;
		$can_rate = self::ratings_enabled() && self::student_can_rate( $booking, get_current_user_id() );
		if ( ! $has_source_content && empty( $due_homework ) && ! $can_rate ) {
			return;
		}
		?>
		<div class="tutorhelper-pro-lesson-follow-up">
			<?php if ( $show_feedback && $has_source_content && '' !== trim( (string) $follow_up->tutor_feedback ) ) : ?>
				<section><h4><?php esc_html_e( 'Tutor feedback', 'tutorhelper-pro' ); ?></h4><?php echo wp_kses_post( wpautop( esc_html( $follow_up->tutor_feedback ) ) ); ?></section>
			<?php endif; ?>
			<?php if ( $show_source_homework && $has_source_content && self::has_homework( $follow_up ) ) : ?><?php self::render_homework( $follow_up, __( 'Homework set', 'tutorhelper-pro' ) ); ?><?php endif; ?>
			<?php foreach ( $due_homework as $homework ) : ?><?php self::render_homework( $homework, __( 'Homework due for this lesson', 'tutorhelper-pro' ) ); ?><?php endforeach; ?>
			<?php do_action( 'tutorhelper_pro_student_lesson_follow_up_after_homework', $booking, $follow_up, $unfiltered_due_homework ); ?>
			<?php if ( $can_rate ) : ?><?php self::render_rating_form( $booking ); ?><?php endif; ?>
		</div>
		<?php
	}

	/** Render the same student details for a Group Session child booking. */
	public static function render_group_session_details( $session, $block, $enrolment ) {
		if ( ! class_exists( 'TutorHelper_Group_Enrolment_Bookings' ) ) {
			return;
		}
		$booking_id = self::get_group_child_booking_id( $session->id, $enrolment->id );
		$booking = $booking_id ? TutorHelper_Booking_Records::get_by_id( $booking_id ) : null;
		if ( ! $booking || absint( $booking->student_user_id ) !== get_current_user_id() ) {
			return;
		}

		$individual = self::get_for_booking( $booking->id );
		$shared = self::get_for_group_session( $session->id );
		$follow_up = $individual ? $individual : $shared;
		$completed = self::is_completed( $booking );
		$has_source_content = $completed && $follow_up && ( '' !== trim( (string) $follow_up->tutor_feedback ) || self::has_homework( $follow_up ) );
		$due_homework = self::get_due_homework( $booking->id );

		foreach ( self::get_due_group_homework( $session->id ) as $shared_homework ) {
			$source_booking_id = self::get_group_child_booking_id( $shared_homework->group_session_id, $enrolment->id );
			if ( $source_booking_id && self::get_for_booking( $source_booking_id ) ) {
				continue;
			}
			$due_homework[] = $shared_homework;
		}

		$can_rate = self::ratings_enabled() && self::student_can_rate( $booking, get_current_user_id() );
		if ( ! $has_source_content && empty( $due_homework ) && ! $can_rate ) {
			return;
		}
		?>
		<div class="tutorhelper-pro-lesson-follow-up">
			<?php if ( $has_source_content && '' !== trim( (string) $follow_up->tutor_feedback ) ) : ?>
				<section><h4><?php esc_html_e( 'Tutor feedback', 'tutorhelper-pro' ); ?></h4><?php echo wp_kses_post( wpautop( esc_html( $follow_up->tutor_feedback ) ) ); ?></section>
			<?php endif; ?>
			<?php if ( $has_source_content && self::has_homework( $follow_up ) ) : ?><?php self::render_homework( $follow_up, __( 'Homework set', 'tutorhelper-pro' ) ); ?><?php endif; ?>
			<?php foreach ( $due_homework as $homework ) : ?><?php self::render_homework( $homework, __( 'Homework due for this lesson', 'tutorhelper-pro' ) ); ?><?php endforeach; ?>
			<?php if ( $can_rate ) : ?><?php self::render_rating_form( $booking ); ?><?php endif; ?>
		</div>
		<?php
	}

	/** Render one homework panel. */
	private static function render_homework( $record, $heading ) {
		$attachment_id = absint( $record->homework_attachment_id );
		$attachment_url = $attachment_id ? wp_get_attachment_url( $attachment_id ) : '';
		?>
		<section class="tutorhelper-pro-homework">
			<h4><?php echo esc_html( $heading ); ?></h4>
			<?php if ( '' !== trim( (string) $record->homework_title ) ) : ?><p><strong><?php echo esc_html( $record->homework_title ); ?></strong></p><?php endif; ?>
			<?php if ( '' !== trim( (string) $record->homework_instructions ) ) : ?><?php echo wp_kses_post( wpautop( esc_html( $record->homework_instructions ) ) ); ?><?php endif; ?>
			<p class="tutorhelper-pro-homework__links">
				<?php if ( ! empty( $record->homework_url ) ) : ?><a class="tutorhelper-button" href="<?php echo esc_url( $record->homework_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open homework link', 'tutorhelper-pro' ); ?></a><?php endif; ?>
				<?php if ( $attachment_url ) : ?><a class="tutorhelper-button" href="<?php echo esc_url( $attachment_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( get_the_title( $attachment_id ) ?: __( 'Download homework file', 'tutorhelper-pro' ) ); ?></a><?php endif; ?>
			</p>
			<?php do_action( 'tutorhelper_pro_homework_student_actions', $record ); ?>
		</section>
		<?php
	}

	/** Render the student's rating form. */
	private static function render_rating_form( $booking ) {
		$rating = self::get_rating( $booking->id );
		$current = $rating ? absint( $rating->rating ) : 0;
		$comment = $rating ? (string) $rating->comment : '';
		$booking_id = absint( $booking->id );
		self::$rating_instance++;
		$rating_key = $booking_id . '-' . self::$rating_instance;
		?>
		<div class="tutorhelper-pro-lesson-rating-panel" data-rating-panel data-rating-booking="<?php echo esc_attr( $rating_key ); ?>">
			<div class="tutorhelper-pro-lesson-rating-summary" data-rating-summary data-rating-booking="<?php echo esc_attr( $rating_key ); ?>" data-rating-record="<?php echo esc_attr( $booking_id ); ?>" <?php if ( ! $rating ) : ?>hidden<?php endif; ?>>
				<span class="tutorhelper-pro-lesson-rating-summary__stars" data-rating-summary-stars aria-label="<?php echo esc_attr( sprintf( __( '%1$d out of %2$d stars', 'tutorhelper-pro' ), $current, 5 ) ); ?>"><?php echo esc_html( str_repeat( '★', $current ) . str_repeat( '☆', 5 - $current ) ); ?></span>
				<span class="tutorhelper-pro-lesson-rating-summary__comment" data-rating-summary-comment <?php if ( '' === trim( $comment ) ) : ?>hidden<?php endif; ?>><?php echo esc_html( $comment ); ?></span>
				<button type="button" class="tutorhelper-pro-lesson-rating-summary__edit" data-rating-edit><?php esc_html_e( 'Edit rating', 'tutorhelper-pro' ); ?></button>
				<span class="tutorhelper-pro-lesson-rating-summary__status" data-rating-summary-status aria-live="polite"></span>
			</div>
			<div class="tutorhelper-pro-lesson-rating-editor<?php echo $rating ? ' is-modal' : ''; ?>" data-rating-editor data-rating-booking="<?php echo esc_attr( $rating_key ); ?>" data-rating-record="<?php echo esc_attr( $booking_id ); ?>" <?php if ( $rating ) : ?>hidden<?php endif; ?>>
				<div
					class="tutorhelper-pro-lesson-rating-editor__shell"
					<?php if ( $rating ) : ?>
						role="dialog"
						aria-modal="true"
					<?php endif; ?>
					aria-labelledby="tutorhelper-rating-title-<?php echo esc_attr( $rating_key ); ?>"
				>
					<button type="button" class="tutorhelper-pro-lesson-rating-editor__close" data-rating-close aria-label="<?php esc_attr_e( 'Close rating form', 'tutorhelper-pro' ); ?>">×</button>
					<form class="tutorhelper-pro-lesson-rating" data-lesson-rating>
						<input type="hidden" name="booking_id" value="<?php echo esc_attr( $booking_id ); ?>" />
						<fieldset>
							<legend id="tutorhelper-rating-title-<?php echo esc_attr( $rating_key ); ?>"><?php esc_html_e( 'Rate this lesson', 'tutorhelper-pro' ); ?></legend>
							<div class="tutorhelper-pro-lesson-rating__stars">
								<?php for ( $star = 5; $star >= 1; $star-- ) : ?>
									<label><input type="radio" name="rating" value="<?php echo esc_attr( $star ); ?>" <?php checked( $current, $star ); ?> required /><span aria-hidden="true">★</span><span class="screen-reader-text"><?php echo esc_html( sprintf( _n( '%d star', '%d stars', $star, 'tutorhelper-pro' ), $star ) ); ?></span></label>
								<?php endfor; ?>
							</div>
							<label><span><?php esc_html_e( 'Comment (optional)', 'tutorhelper-pro' ); ?></span><textarea name="comment" rows="3"><?php echo esc_textarea( $comment ); ?></textarea></label>
							<p class="tutorhelper-pro-lesson-rating__help"><?php esc_html_e( 'Your rating and optional comment will be shared with your tutor.', 'tutorhelper-pro' ); ?></p>
							<button type="submit" class="tutorhelper-button"><?php echo esc_html( $rating ? __( 'Update rating', 'tutorhelper-pro' ) : __( 'Submit rating', 'tutorhelper-pro' ) ); ?></button>
							<span data-rating-status aria-live="polite"></span>
						</fieldset>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	/** Check tutor AJAX permissions and nonce. */
	private static function check_admin_ajax() {
		if ( ! check_ajax_referer( self::ADMIN_NONCE, 'nonce', false ) ) {
			self::log_follow_up_error(
				'Lesson follow-up request failed security verification.',
				self::error_context_from_request( 'verify_request', 'invalid_nonce' )
			);
			wp_send_json_error( array( 'message' => __( 'The lesson follow-up request could not be verified. Please refresh the page and try again.', 'tutorhelper-pro' ) ), 403 );
		}
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			self::log_follow_up_error(
				'Lesson follow-up request was denied.',
				self::error_context_from_request( 'authorise_request', 'insufficient_permission' )
			);
			wp_send_json_error( array( 'message' => __( 'You do not have permission to edit lesson follow-up.', 'tutorhelper-pro' ) ), 403 );
		}
	}

	/** Resolve the posted booking. */
	private static function posted_context() {
		$booking_id = isset( $_POST['booking_id'] ) ? absint( $_POST['booking_id'] ) : 0;
		$group_session_id = isset( $_POST['group_session_id'] ) ? absint( $_POST['group_session_id'] ) : 0;
		$scope = isset( $_POST['follow_up_scope'] ) && ! is_array( $_POST['follow_up_scope'] )
			? sanitize_key( wp_unslash( $_POST['follow_up_scope'] ) )
			: 'booking';
		if ( ! in_array( $scope, array( 'booking', 'group', 'student' ), true ) ) {
			$scope = 'booking';
		}
		if ( 'group' === $scope ) {
			$booking_id = 0;
		}
		$booking = $booking_id ? TutorHelper_Booking_Records::get_by_id( $booking_id ) : null;
		$session = $group_session_id && class_exists( 'TutorHelper_Group_Sessions' )
			? TutorHelper_Group_Sessions::get_by_id( $group_session_id )
			: null;

		if ( ! $booking && ! $session ) {
			return new WP_Error( 'tutorhelper_pro_lesson_missing', __( 'The lesson could not be found.', 'tutorhelper-pro' ) );
		}
		if ( 'group' === $scope && ! $session ) {
			return new WP_Error( 'tutorhelper_pro_group_session_missing', __( 'The Group Session could not be found.', 'tutorhelper-pro' ) );
		}
		if ( 'booking' === $scope && ! $booking ) {
			return new WP_Error( 'tutorhelper_pro_booking_missing', __( 'The lesson could not be found.', 'tutorhelper-pro' ) );
		}
		if ( 'student' === $scope && ( ! $booking || ! $session ) ) {
			return new WP_Error( 'tutorhelper_pro_group_student_missing', __( 'The student Group booking could not be found.', 'tutorhelper-pro' ) );
		}
		if ( $booking && TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
			return new WP_Error( 'tutorhelper_pro_booking_cancelled', __( 'Cancelled lessons cannot be updated.', 'tutorhelper-pro' ) );
		}
		if ( $booking && $group_session_id && ! $session ) {
			return new WP_Error( 'tutorhelper_pro_group_session_missing', __( 'The Group Session could not be found.', 'tutorhelper-pro' ) );
		}
		if ( $booking && $session && ! self::booking_belongs_to_group_session( $booking->id, $session->id ) ) {
			return new WP_Error( 'tutorhelper_pro_group_booking_mismatch', __( 'The student booking does not belong to this Group Session.', 'tutorhelper-pro' ) );
		}

		return array(
			'booking' => $booking,
			'session' => $session,
			'scope'   => $scope,
		);
	}

	/** Check whether a child booking belongs to a Group Session. */
	private static function booking_belongs_to_group_session( $booking_id, $session_id ) {
		if ( ! class_exists( 'TutorHelper_Group_Enrolment_Bookings' ) ) {
			return false;
		}
		global $wpdb;
		return (bool) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Security boundary for a submitted Group follow-up context.
			$wpdb->prepare(
				'SELECT booking_id FROM %i WHERE booking_id = %d AND session_id = %d LIMIT 1',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				absint( $booking_id ),
				absint( $session_id )
			)
		);
	}

	/**
	 * Record a follow-up failure without storing lesson content or personal data.
	 *
	 * @param string $message Diagnostic message.
	 * @param array  $context Safe diagnostic context.
	 * @return void
	 */
	private static function log_follow_up_error( $message, $context = array() ) {
		if ( class_exists( 'TutorHelper_Logger' ) ) {
			TutorHelper_Logger::error( $message, $context );
		}
	}

	/**
	 * Build safe context for a request that could not be resolved.
	 *
	 * @param string $operation  Operation being attempted.
	 * @param string $error_code WordPress error code.
	 * @return array
	 */
	private static function error_context_from_request( $operation, $error_code ) {
		return array(
			'operation'        => sanitize_key( $operation ),
			'error_code'       => sanitize_key( $error_code ),
			'scope'            => isset( $_POST['scope'] ) && ! is_array( $_POST['scope'] ) ? sanitize_key( wp_unslash( $_POST['scope'] ) ) : '',
			'booking_id'       => isset( $_POST['booking_id'] ) ? absint( $_POST['booking_id'] ) : 0,
			'group_session_id' => isset( $_POST['group_session_id'] ) ? absint( $_POST['group_session_id'] ) : 0,
			'user_id'          => get_current_user_id(),
		);
	}

	/**
	 * Build diagnostic context that excludes feedback and homework content.
	 *
	 * @param string $operation     Operation being attempted.
	 * @param array  $context       Validated follow-up context.
	 * @param string $table         Database table name.
	 * @param int    $due_id        Selected due lesson/session ID.
	 * @param int    $attachment_id Selected attachment ID.
	 * @return array
	 */
	private static function diagnostic_context( $operation, $context, $table, $due_id, $attachment_id ) {
		return array(
			'operation'        => sanitize_key( $operation ),
			'scope'            => sanitize_key( $context['scope'] ),
			'table'            => sanitize_text_field( $table ),
			'booking_id'       => ! empty( $context['booking'] ) ? absint( $context['booking']->id ) : 0,
			'group_session_id' => ! empty( $context['session'] ) ? absint( $context['session']->id ) : 0,
			'due_id'           => absint( $due_id ),
			'attachment_id'    => absint( $attachment_id ),
			'user_id'          => get_current_user_id(),
		);
	}

	/**
	 * Log a failed database write and return a safe reference to the tutor.
	 *
	 * @param string $operation     Database operation.
	 * @param array  $context       Validated follow-up context.
	 * @param string $table         Database table name.
	 * @param int    $due_id        Selected due lesson/session ID.
	 * @param int    $attachment_id Selected attachment ID.
	 * @return void
	 */
	private static function send_database_error( $operation, $context, $table, $due_id, $attachment_id ) {
		global $wpdb;

		$reference = 'TH-FU-' . strtoupper( substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 8 ) );
		$diagnostic_context = self::diagnostic_context( $operation, $context, $table, $due_id, $attachment_id );
		$diagnostic_context['reference'] = $reference;
		$diagnostic_context['database_error'] = sanitize_text_field( $wpdb->last_error );

		self::log_follow_up_error( 'Lesson follow-up database write failed.', $diagnostic_context );

		wp_send_json_error(
			array(
				'message' => sprintf(
					/* translators: %s: diagnostic reference code. */
					__( 'The lesson follow-up could not be saved. Reference: %s', 'tutorhelper-pro' ),
					$reference
				),
			),
			500
		);
	}


	/** Get one follow-up row. */
	private static function get_for_booking( $booking_id ) {
		global $wpdb;
		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Follow-up must reflect the tutor's latest edit.
			$wpdb->prepare( 'SELECT * FROM %i WHERE booking_id = %d', TutorHelper_Pro_Database::get_table_name( 'lesson_follow_up' ), absint( $booking_id ) )
		);
	}

	/** Get the shared follow-up for one Group Session. */
	private static function get_for_group_session( $group_session_id ) {
		global $wpdb;
		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Shared Group Session follow-up must reflect the tutor's latest edit.
			$wpdb->prepare( 'SELECT * FROM %i WHERE group_session_id = %d', TutorHelper_Pro_Database::get_table_name( 'group_lesson_follow_up' ), absint( $group_session_id ) )
		);
	}

	/** Get shared homework due for one Group Session. */
	private static function get_due_group_homework( $group_session_id ) {
		global $wpdb;
		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Shared homework state must be current.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE homework_due_group_session_id = %d OR ((homework_due_group_session_id = 0 OR homework_due_group_session_id IS NULL) AND group_session_id = %d) ORDER BY created_at ASC',
				TutorHelper_Pro_Database::get_table_name( 'group_lesson_follow_up' ),
				absint( $group_session_id ),
				absint( $group_session_id )
			)
		);
	}

	/** Get homework assigned to a particular booking. */
	private static function get_due_homework( $booking_id ) {
		global $wpdb;
		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Homework state must be current.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE homework_due_booking_id = %d OR ((homework_due_booking_id = 0 OR homework_due_booking_id IS NULL) AND booking_id = %d) ORDER BY created_at ASC',
				TutorHelper_Pro_Database::get_table_name( 'lesson_follow_up' ),
				absint( $booking_id ),
				absint( $booking_id )
			)
		);
	}

	/**
	 * Prepare homework due for the current lesson.
	 *
	 * @param array $context Validated follow-up context.
	 * @return array
	 */
	private static function prepare_due_homework( $context ) {
		$records = array();

		if ( ! empty( $context['booking'] ) ) {
			$records = self::get_due_homework(
				absint( $context['booking']->id )
			);
		}

		if ( ! empty( $context['session'] ) ) {
			$records = array_merge(
				$records,
				self::get_due_group_homework(
					absint( $context['session']->id )
				)
			);
		}

		$homework = array();
		foreach ( $records as $record ) {
			if ( ! self::has_homework( $record ) ) {
				continue;
			}

			$source_label = '';
			if ( ! empty( $record->booking_id ) ) {
				$source = TutorHelper_Booking_Records::get_by_id(
					absint( $record->booking_id )
				);
				$source_label = $source
					? self::booking_label( $source )
					: '';
			} elseif ( ! empty( $record->group_session_id ) && class_exists( 'TutorHelper_Group_Sessions' ) ) {
				$source = TutorHelper_Group_Sessions::get_by_id(
					absint( $record->group_session_id )
				);
				$source_label = $source
					? self::group_session_label( $source )
					: '';
			}

			$attachment_id = absint( $record->homework_attachment_id );
			$attachment_url = $attachment_id
				? wp_get_attachment_url( $attachment_id )
				: '';

			$item = array(
				'title'           => sanitize_text_field( $record->homework_title ),
				'instructions'    => sanitize_textarea_field( $record->homework_instructions ),
				'url'             => esc_url_raw( $record->homework_url, array( 'http', 'https' ) ),
				'attachmentUrl'   => $attachment_url ? esc_url_raw( $attachment_url ) : '',
				'attachmentName'  => $attachment_id ? sanitize_text_field( get_the_title( $attachment_id ) ) : '',
				'sourceLabel'       => sanitize_text_field( $source_label ),
				'sourceId'          => absint( $record->id ),
				'submissionEnabled' => ! empty( $record->homework_submission_enabled ),
			);
			$item = apply_filters( 'tutorhelper_pro_due_homework_item', $item, $record, $context );
			$homework[] = is_array( $item ) ? $item : array();
		}

		return $homework;
	}

	/** Get one student rating. */
	private static function get_rating( $booking_id ) {
		global $wpdb;
		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Rating state must be current.
			$wpdb->prepare( 'SELECT * FROM %i WHERE booking_id = %d', TutorHelper_Pro_Database::get_table_name( 'lesson_ratings' ), absint( $booking_id ) )
		);
	}

	/**
	 * Return one rating for reporting integrations.
	 *
	 * @param int $booking_id Booking ID.
	 * @return object|null
	 */
	public static function get_rating_for_booking( $booking_id ) {
		return self::get_rating( $booking_id );
	}

	/** Return valid future lessons for a homework due date. */
	private static function get_due_booking_options( $booking ) {
		$options = array();
		$bookings = TutorHelper_Booking_Records::get_all(
			array(
				'student_user_id' => absint( $booking->student_user_id ),
				'date_from'       => (string) $booking->booking_end,
				'limit'           => 50,
			)
		);
		foreach ( $bookings as $candidate ) {
			if (
				'cancelled' === sanitize_key( $candidate->status )
				|| absint( $candidate->id ) === absint( $booking->id )
				|| (string) $candidate->booking_start <= (string) $booking->booking_start
			) {
				continue;
			}
			$options[] = array( 'id' => absint( $candidate->id ), 'label' => self::due_booking_label( $candidate ) );
			if ( 10 === count( $options ) ) {
				break;
			}
		}
		return $options;
	}

	/** Return later sessions in the same Group Lesson block. */
	private static function get_due_group_session_options( $session ) {
		$options = array();
		if ( ! $session || ! class_exists( 'TutorHelper_Group_Sessions' ) ) {
			return $options;
		}
		foreach ( TutorHelper_Group_Sessions::get_for_block( absint( $session->block_id ) ) as $candidate ) {
			if ( absint( $candidate->id ) === absint( $session->id ) || (string) $candidate->booking_start <= (string) $session->booking_start || 'cancelled' === sanitize_key( $candidate->status ) ) {
				continue;
			}
			$options[] = array( 'id' => absint( $candidate->id ), 'label' => self::group_session_label( $candidate ) );
			if ( 10 === count( $options ) ) {
				break;
			}
		}
		return $options;
	}

	/** Validate a later Group Session in the same block. */
	private static function is_valid_due_group_session( $source, $due_session_id ) {
		$due = class_exists( 'TutorHelper_Group_Sessions' ) ? TutorHelper_Group_Sessions::get_by_id( $due_session_id ) : null;
		return $due
			&& absint( $due->block_id ) === absint( $source->block_id )
			&& (string) $due->booking_start > (string) $source->booking_start
			&& 'cancelled' !== sanitize_key( $due->status );
	}

	/** Resolve one student's Core child booking for a Group Session. */
	private static function get_group_child_booking_id( $session_id, $enrolment_id ) {
		if ( ! class_exists( 'TutorHelper_Group_Enrolment_Bookings' ) ) {
			return 0;
		}
		global $wpdb;
		return absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Resolves current Group Session membership.
				$wpdb->prepare(
					'SELECT booking_id FROM %i WHERE session_id = %d AND enrolment_id = %d LIMIT 1',
					TutorHelper_Group_Enrolment_Bookings::get_table_name(),
					absint( $session_id ),
					absint( $enrolment_id )
				)
			)
		);
	}

	/** Validate the selected due lesson is a later lesson for the same student/type. */
	private static function is_valid_due_booking( $source, $due_booking_id ) {
		$due = TutorHelper_Booking_Records::get_by_id( $due_booking_id );
		return $due
			&& 'cancelled' !== sanitize_key( $due->status )
			&& absint( $due->student_user_id ) === absint( $source->student_user_id )
			&& (string) $due->booking_start > (string) $source->booking_start;
	}

	/** Resolve a prepared dashboard array or booking object. */
	private static function resolve_booking( $booking_data ) {
		if ( is_object( $booking_data ) && ! empty( $booking_data->id ) ) {
			return $booking_data;
		}
		$booking_id = is_array( $booking_data ) && isset( $booking_data['id'] ) ? absint( $booking_data['id'] ) : 0;
		return $booking_id ? TutorHelper_Booking_Records::get_by_id( $booking_id ) : null;
	}

	/** Whether a booking has ended. */
	private static function is_completed( $booking ) {
		if ( ! $booking || empty( $booking->booking_end ) ) {
			return false;
		}
		return strtotime( $booking->booking_end . ' UTC' ) <= current_time( 'timestamp', true );
	}

	/** Whether the current student may rate this booking. */
	private static function student_can_rate( $booking, $student_user_id ) {
		return $booking
			&& absint( $booking->student_user_id ) === absint( $student_user_id )
			&& TutorHelper_Booking_Records::STATUS_CONFIRMED === sanitize_key( $booking->status )
			&& self::is_completed( $booking );
	}

	/** Return the booking-specific homework completion meta key. */
	private static function homework_completion_meta_key( $booking_id ) {
		return 'tutorhelper_pro_homework_completed_' . absint( $booking_id );
	}

	/** Return the booking-specific no-longer-due homework meta key. */
	private static function homework_not_due_meta_key( $booking_id ) {
		return 'tutorhelper_pro_homework_not_due_' . absint( $booking_id );
	}

	/** Whether homework due for a booking has been recorded as no longer due. */
	public static function is_homework_no_longer_due( $booking_id ) {
		$booking = TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) );
		return $booking && (bool) get_user_meta(
			absint( $booking->student_user_id ),
			self::homework_not_due_meta_key( $booking_id ),
			true
		);
	}

	/**
	 * Record that one student's homework is no longer due without marking it complete.
	 *
	 * @param int $booking_id Due booking ID.
	 * @param int $tutor_user_id Tutor making the change.
	 * @return bool
	 */
	public static function mark_homework_no_longer_due( $booking_id, $tutor_user_id ) {
		$booking = TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) );
		if ( ! $booking || empty( $booking->student_user_id ) ) {
			return false;
		}

		return false !== update_user_meta(
			absint( $booking->student_user_id ),
			self::homework_not_due_meta_key( $booking_id ),
			array(
				'recorded_at'   => current_time( 'mysql', true ),
				'tutor_user_id' => absint( $tutor_user_id ),
			)
		);
	}

	/** Whether homework due for a booking is marked complete. */
	public static function is_homework_completed( $booking_id ) {
		$booking = TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) );
		$completed = $booking && (bool) get_user_meta(
			absint( $booking->student_user_id ),
			self::homework_completion_meta_key( $booking_id ),
			true
		);

		/**
		 * Lets an active LMS submission mark homework complete without making Pro
		 * depend on LMS. Without LMS this remains the tutor's manual checkbox.
		 */
		return (bool) apply_filters(
			'tutorhelper_pro_homework_completed',
			$completed,
			absint( $booking_id ),
			$booking
		);
	}

	/** Save the tutor-controlled homework completion state. */
	private static function set_homework_completed( $booking, $completed ) {
		if ( ! $booking || empty( $booking->student_user_id ) ) {
			return;
		}
		$key = self::homework_completion_meta_key( $booking->id );
		if ( $completed ) {
			update_user_meta(
				absint( $booking->student_user_id ),
				$key,
				current_time( 'mysql', true )
			);
		} else {
			delete_user_meta(
				absint( $booking->student_user_id ),
				$key
			);
		}
	}

	/** Whether a follow-up contains homework. */
	private static function has_homework( $record ) {
		$has_homework = $record && ( '' !== trim( (string) $record->homework_title ) || '' !== trim( (string) $record->homework_instructions ) || '' !== trim( (string) $record->homework_url ) || absint( $record->homework_attachment_id ) );
		/**
		 * Lets optional learning integrations count their own attached content as
		 * homework without Core/Pro storing or understanding that content.
		 */
		return (bool) apply_filters( 'tutorhelper_pro_homework_has_content', $has_homework, $record );
	}

	/**
	 * Return homework indicators for one booking.
	 *
	 * @param int $booking_id Booking ID.
	 * @return array
	 */
	public static function get_homework_state_for_booking( $booking_id ) {
		$booking_id = absint( $booking_id );
		$record     = self::get_for_booking( $booking_id );
		$due        = self::get_due_homework( $booking_id );
		$group      = self::get_group_booking_context( $booking_id );

		if ( $group ) {
			if ( ! $record ) {
				$record = self::get_for_group_session( $group['session_id'] );
			}

			foreach ( self::get_due_group_homework( $group['session_id'] ) as $shared_homework ) {
				$source_booking_id = self::get_group_child_booking_id(
					absint( $shared_homework->group_session_id ),
					$group['enrolment_id']
				);

				if ( $source_booking_id && self::get_for_booking( $source_booking_id ) ) {
					continue;
				}

				$due[] = $shared_homework;
			}
		}

		$has_due = ! empty(
			array_filter(
				$due,
				array( __CLASS__, 'has_homework' )
			)
		);

		return array(
			'set'       => self::has_homework( $record ),
			'due'       => $has_due,
			'completed' => $has_due && self::is_homework_completed( $booking_id ),
			'not_due'   => $has_due && self::is_homework_no_longer_due( $booking_id ),
		);
	}

	/**
	 * Build reminder placeholders for homework set by, and due for, one lesson.
	 *
	 * @param int $booking_id Booking ID.
	 * @return array
	 */
	public static function get_reminder_homework_placeholders( $booking_id ) {
		$booking_id = absint( $booking_id );
		$record = self::get_for_booking( $booking_id );
		$due = self::get_due_homework( $booking_id );
		$group = self::get_group_booking_context( $booking_id );

		if ( $group ) {
			if ( ! $record ) {
				$record = self::get_for_group_session( $group['session_id'] );
			}
			foreach ( self::get_due_group_homework( $group['session_id'] ) as $shared_homework ) {
				$source_booking_id = self::get_group_child_booking_id( absint( $shared_homework->group_session_id ), $group['enrolment_id'] );
				if ( $source_booking_id && self::get_for_booking( $source_booking_id ) ) {
					continue;
				}
				$due[] = $shared_homework;
			}
		}

		$due_text = array();
		foreach ( $due as $due_record ) {
			$text = self::format_homework_for_email( $due_record );
			if ( '' !== $text ) {
				$due_text[] = $text;
			}
		}

		return array(
			'{homework_set}' => self::format_homework_for_email( $record ),
			'{homework_due}' => implode( "\n\n", $due_text ),
		);
	}

	/** Format one homework record for a plain-text or HTML email template. */
	private static function format_homework_for_email( $record ) {
		if ( ! self::has_homework( $record ) ) {
			return '';
		}
		$parts = array_filter( array(
			sanitize_text_field( $record->homework_title ),
			sanitize_textarea_field( $record->homework_instructions ),
			esc_url_raw( $record->homework_url, array( 'http', 'https' ) ),
		) );
		$attachment_id = absint( $record->homework_attachment_id );
		if ( $attachment_id ) {
			$attachment_url = wp_get_attachment_url( $attachment_id );
			if ( $attachment_url ) {
				$parts[] = esc_url_raw( $attachment_url );
			}
		}
		return implode( "\n", $parts );
	}

	/**
	 * Resolve the Group Session and enrolment for a Core child booking.
	 *
	 * @param int $booking_id Booking ID.
	 * @return array|null
	 */
	private static function get_group_booking_context( $booking_id ) {
		if (
			! $booking_id
			|| ! class_exists( 'TutorHelper_Group_Enrolment_Bookings' )
			|| ! method_exists( 'TutorHelper_Group_Enrolment_Bookings', 'get_table_name' )
		) {
			return null;
		}

		global $wpdb;
		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Resolves the current Group booking relationship for live homework state.
			$wpdb->prepare(
				'SELECT session_id, enrolment_id FROM %i WHERE booking_id = %d LIMIT 1',
				TutorHelper_Group_Enrolment_Bookings::get_table_name(),
				absint( $booking_id )
			),
			ARRAY_A
		);

		if ( ! $row ) {
			return null;
		}

		return array(
			'session_id'  => absint( $row['session_id'] ),
			'enrolment_id' => absint( $row['enrolment_id'] ),
		);
	}

	/**
	 * Render compact homework-state icons.
	 *
	 * @param int $booking_id Booking ID.
	 * @return void
	 */
	public static function render_homework_indicators( $booking_id ) {
		$state = self::get_homework_state_for_booking( $booking_id );
		if ( ! $state['set'] && ! $state['due'] && ! $state['completed'] ) {
			return;
		}
		?>
		<span class="tutorhelper-pro-homework-indicators">
			<?php if ( $state['set'] ) : ?>
				<span class="dashicons dashicons-welcome-write-blog" title="<?php esc_attr_e( 'Homework was set after this lesson', 'tutorhelper-pro' ); ?>" aria-label="<?php esc_attr_e( 'Homework was set after this lesson', 'tutorhelper-pro' ); ?>"></span>
			<?php endif; ?>
			<?php if ( $state['completed'] ) : ?>
				<span class="dashicons dashicons-yes-alt" title="<?php esc_attr_e( 'Homework due for this lesson was completed', 'tutorhelper-pro' ); ?>" aria-label="<?php esc_attr_e( 'Homework due for this lesson was completed', 'tutorhelper-pro' ); ?>"></span>
			<?php elseif ( $state['due'] ) : ?>
				<span class="dashicons dashicons-clock" title="<?php esc_attr_e( 'Homework is due for this lesson', 'tutorhelper-pro' ); ?>" aria-label="<?php esc_attr_e( 'Homework is due for this lesson', 'tutorhelper-pro' ); ?>"></span>
			<?php endif; ?>
		</span>
		<?php
	}

	/** Human-readable Group Session date/time. */
	private static function group_session_label( $session ) {
		$timestamp = strtotime( (string) $session->booking_start . ' UTC' );
		return $timestamp ? wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), $timestamp, wp_timezone() ) : __( 'Group Session', 'tutorhelper-pro' );
	}

	/** Human-readable booking date/time. */
	private static function booking_label( $booking ) {
		$timestamp = strtotime( (string) $booking->booking_start . ' UTC' );
		return $timestamp ? wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), $timestamp, wp_timezone() ) : __( 'Lesson', 'tutorhelper-pro' );
	}

	/**
	 * Return a homework due-date label including the next lesson's type.
	 *
	 * @param object $booking Booking record.
	 * @return string
	 */
	private static function due_booking_label( $booking ) {
		$label = self::booking_label( $booking );
		$type = TutorHelper_Booking_Types::get_by_id(
			absint( $booking->booking_type_id )
		);
		$type_name = $type && ! empty( $type->title )
			? sanitize_text_field( $type->title )
			: __( 'Lesson', 'tutorhelper-pro' );

		return sprintf(
			/* translators: 1: Date and time, 2: Booking Type title. */
			__( '%1$s (%2$s)', 'tutorhelper-pro' ),
			$label,
			$type_name
		);
	}
}
