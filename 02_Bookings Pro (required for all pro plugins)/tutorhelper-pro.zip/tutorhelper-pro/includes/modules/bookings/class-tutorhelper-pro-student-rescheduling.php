<?php
/**
 * TutorHelper Pro student rescheduling workflow.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds student-friendly cancellation/reschedule terms and allows eligible
 * students to move an existing confirmed booking to another available slot.
 */
final class TutorHelper_Pro_Student_Rescheduling {

	const QUERY_ARG = 'tutorhelper_reschedule';
	const EXTENSION_FIELD = 'tutorhelper_reschedule_booking_id';
	const SCRIPT_HANDLE = 'tutorhelper-pro-student-rescheduling';
	const STYLE_HANDLE = 'tutorhelper-pro-student-rescheduling';

	const TEMPLATE_STUDENT = 'pro_booking_rescheduled_student';
	const TEMPLATE_TUTOR = 'pro_booking_rescheduled_tutor';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		self::register_templates();

		add_action(
			'tutorhelper_student_dashboard_booking_actions',
			array( __CLASS__, 'render_dashboard_terms_and_actions' ),
			5,
			2
		);

		/*
		 * Run before Core's normal student booking submit callback. A normal
		 * booking simply returns and Core continues at its default priority.
		 */
		add_action(
			'wp_ajax_' . TutorHelper_Student_Booking_Ajax::ACTION_SUBMIT,
			array( __CLASS__, 'maybe_handle_reschedule' ),
			1
		);

		add_action(
			'wp_enqueue_scripts',
			array( __CLASS__, 'enqueue_frontend_assets' ),
			40
		);
	}

	/**
	 * Register editable reschedule emails.
	 *
	 * @return void
	 */
	private static function register_templates() {
		TutorHelper_Email_Templates::register(
			self::TEMPLATE_STUDENT,
			array(
				'module' => 'bookings',
				'label' => __( 'Lesson rescheduled — Student', 'tutorhelper-pro' ),
				'description' => __( 'Sent to a student after they successfully reschedule a lesson.', 'tutorhelper-pro' ),
				'heading' => __( 'Lesson Rescheduled', 'tutorhelper-pro' ),
				'recipient' => 'student',
				'enabled' => true,
				'subject' => __( 'Your {booking_type} lesson has been rescheduled', 'tutorhelper-pro' ),
				'body' => __(
					"Hello {student_name},\n\nYour {booking_type} lesson has been rescheduled.\n\nPrevious lesson: {old_lesson_date} at {old_lesson_time}\nNew lesson: {lesson_date} at {lesson_time}\nLocation: {location_type}\n\n{joining_details}\n\nYou can view your lessons here:\n{student_dashboard_url}\n\nBest wishes,\n{tutor_name}",
					'tutorhelper-pro'
				),
				'placeholders' => array(
					'{student_name}',
					'{tutor_name}',
					'{booking_type}',
					'{old_lesson_date}',
					'{old_lesson_time}',
					'{lesson_date}',
					'{lesson_time}',
					'{location_type}',
					'{joining_details}',
					'{student_dashboard_url}',
					'{site_name}',
				),
			)
		);

		TutorHelper_Email_Templates::register(
			self::TEMPLATE_TUTOR,
			array(
				'module' => 'bookings',
				'label' => __( 'Lesson rescheduled — Tutor', 'tutorhelper-pro' ),
				'description' => __( 'Sent to the tutor after a student successfully reschedules a lesson.', 'tutorhelper-pro' ),
				'heading' => __( 'Student Rescheduled a Lesson', 'tutorhelper-pro' ),
				'recipient' => 'tutor',
				'enabled' => true,
				'subject' => __( '{student_name} rescheduled their {booking_type} lesson', 'tutorhelper-pro' ),
				'body' => __(
					"{student_name} has rescheduled their {booking_type} lesson.\n\nPrevious lesson: {old_lesson_date} at {old_lesson_time}\nNew lesson: {lesson_date} at {lesson_time}\nLocation: {location_type}\n\nOpen your TutorHelper calendar:\n{calendar_url}",
					'tutorhelper-pro'
				),
				'placeholders' => array(
					'{student_name}',
					'{tutor_name}',
					'{booking_type}',
					'{old_lesson_date}',
					'{old_lesson_time}',
					'{lesson_date}',
					'{lesson_time}',
					'{location_type}',
					'{calendar_url}',
					'{site_name}',
				),
			)
		);
	}

	/**
	 * Add student-friendly booking-change terms and a Reschedule action.
	 *
	 * @param array  $booking      Prepared dashboard booking.
	 * @param string $section_type Dashboard section.
	 * @return void
	 */
	public static function render_dashboard_terms_and_actions( $booking, $section_type ) {
		if (
			! is_user_logged_in()
			|| ! is_array( $booking )
			|| empty( $booking['id'] )
			|| ! in_array( sanitize_key( $section_type ), array( 'pending', 'confirmed' ), true )
		) {
			return;
		}

		$student_id = get_current_user_id();
		$record = TutorHelper_Booking_Records::get_by_id( absint( $booking['id'] ) );

		if (
			! $record
			|| absint( $record->student_user_id ) !== $student_id
		) {
			return;
		}

		$cancellation = self::get_cancellation_policy( $record, $student_id );
		$reschedule = self::get_reschedule_policy( $record, $student_id );
		$block_core_cancel = ! empty( $cancellation['blocked_by_allowance'] );
		?>
		<div
			class="tutorhelper-pro-booking-change-policy"
			data-tutorhelper-pro-booking-change-policy
			<?php if ( $block_core_cancel ) : ?>
				data-tutorhelper-pro-cancel-blocked="1"
			<?php endif; ?>
		>
			<p>
				<strong><?php esc_html_e( 'Cancellation:', 'tutorhelper-pro' ); ?></strong>
				<?php echo esc_html( $cancellation['message'] ); ?>
			</p>
			<p>
				<strong><?php esc_html_e( 'Rescheduling:', 'tutorhelper-pro' ); ?></strong>
				<?php echo esc_html( $reschedule['message'] ); ?>
			</p>
		</div>
		<?php

		if ( ! empty( $reschedule['can_reschedule'] ) ) {
			$booking_url = TutorHelper_Settings::get_student_booking_url();
			if ( $booking_url ) {
				$url = add_query_arg(
					self::QUERY_ARG,
					absint( $record->id ),
					$booking_url
				);
				?>
				<a
					class="tutorhelper-student-dashboard__reschedule-button"
					href="<?php echo esc_url( $url ); ?>"
				>
					<?php esc_html_e( 'Reschedule lesson', 'tutorhelper-pro' ); ?>
				</a>
				<?php
			}
		}
	}

	/**
	 * Handle a reschedule request before Core creates a new booking.
	 *
	 * @return void
	 */
	public static function maybe_handle_reschedule() {
		$booking_id = self::get_submitted_reschedule_id();
		if ( ! $booking_id ) {
			return;
		}

		check_ajax_referer(
			TutorHelper_Student_Booking_Ajax::NONCE_ACTION,
			'nonce'
		);

		if ( ! is_user_logged_in() ) {
			wp_send_json_error(
				array( 'message' => __( 'Please log in to reschedule your lesson.', 'tutorhelper-pro' ) ),
				401
			);
		}

		$student_id = get_current_user_id();
		if ( ! TutorHelper_Students::get_student( $student_id ) instanceof WP_User ) {
			wp_send_json_error(
				array( 'message' => __( 'Only registered students can reschedule lessons.', 'tutorhelper-pro' ) ),
				403
			);
		}

		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		if ( ! $booking || absint( $booking->student_user_id ) !== $student_id ) {
			wp_send_json_error(
				array( 'message' => __( 'The lesson could not be found.', 'tutorhelper-pro' ) ),
				404
			);
		}

		$policy = self::get_reschedule_policy( $booking, $student_id );
		if ( empty( $policy['can_reschedule'] ) ) {
			wp_send_json_error(
				array(
					'message' => $policy['message'],
					'code' => 'tutorhelper_pro_reschedule_not_allowed',
				),
				400
			);
		}

		$booking_type_id = isset( $_POST['booking_type_id'] )
			? absint( wp_unslash( $_POST['booking_type_id'] ) )
			: 0;

		if ( $booking_type_id !== absint( $booking->booking_type_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'The lesson type cannot be changed while rescheduling.', 'tutorhelper-pro' ) ),
				400
			);
		}

		$booking_start = isset( $_POST['booking_start'] )
			? sanitize_text_field( wp_unslash( $_POST['booking_start'] ) )
			: '';
		$booking_end = isset( $_POST['booking_end'] )
			? sanitize_text_field( wp_unslash( $_POST['booking_end'] ) )
			: '';
		$timezone = isset( $_POST['timezone'] )
			? sanitize_text_field( wp_unslash( $_POST['timezone'] ) )
			: wp_timezone()->getName();
		$location_type = isset( $_POST['location_type'] )
			? sanitize_key( wp_unslash( $_POST['location_type'] ) )
			: '';

		$slot_valid = self::selected_slot_is_available(
			$booking,
			$booking_start,
			$booking_end,
			$location_type
		);

		if ( is_wp_error( $slot_valid ) ) {
			wp_send_json_error(
				array(
					'message' => $slot_valid->get_error_message(),
					'code' => $slot_valid->get_error_code(),
				),
				400
			);
		}

		$old_start = sanitize_text_field( $booking->booking_start );
		$old_end = sanitize_text_field( $booking->booking_end );
		$old_timezone = sanitize_text_field( $booking->timezone );

		$updated = TutorHelper_Booking_Schedule::update(
			$booking_id,
			array(
				'booking_start' => $booking_start,
				'booking_end' => $booking_end,
				'timezone' => $timezone,
				'location_type' => $location_type,
			),
			TutorHelper_Booking_Records::STATUS_CONFIRMED
		);

		if ( is_wp_error( $updated ) ) {
			wp_send_json_error(
				array(
					'message' => $updated->get_error_message(),
					'code' => $updated->get_error_code(),
				),
				400
			);
		}

		TutorHelper_Pro_Booking_Change_Limits::record_student_reschedule(
			$booking_id,
			$student_id,
			$old_start,
			$old_end,
			sanitize_text_field( $updated->booking_start ),
			sanitize_text_field( $updated->booking_end )
		);

		self::send_reschedule_emails(
			$booking_id,
			$old_start,
			$old_end,
			$old_timezone
		);

		$dashboard_url = TutorHelper_Settings::get_student_dashboard_url();
		$response = array(
			'booking_id' => $booking_id,
			'status' => TutorHelper_Booking_Records::STATUS_CONFIRMED,
			'message' => __( 'Your lesson has been rescheduled. We have emailed you the new lesson details.', 'tutorhelper-pro' ),
		);

		if ( $dashboard_url ) {
			$response['redirect_url'] = add_query_arg(
				'tutorhelper_dashboard_status',
				'rescheduled',
				$dashboard_url
			);
		}

		wp_send_json_success( $response );
	}

	/**
	 * Verify the submitted slot still appears in Core's live availability.
	 *
	 * @param object $booking       Existing booking.
	 * @param string $booking_start Local start.
	 * @param string $booking_end   Local end.
	 * @param string $location_type Location type.
	 * @return true|WP_Error
	 */
	private static function selected_slot_is_available(
		$booking,
		$booking_start,
		$booking_end,
		$location_type
	) {
		if ( strlen( $booking_start ) < 10 ) {
			return new WP_Error(
				'tutorhelper_pro_reschedule_slot_missing',
				__( 'Choose a new date and time for your lesson.', 'tutorhelper-pro' )
			);
		}

		$date = substr( $booking_start, 0, 10 );
		$slots = TutorHelper_Student_Booking_Slots::get_for_date(
			absint( $booking->tutor_user_id ),
			absint( $booking->booking_type_id ),
			$date
		);

		if ( is_wp_error( $slots ) ) {
			return $slots;
		}

		foreach ( $slots as $slot ) {
			if (
				is_array( $slot )
				&& $booking_start === sanitize_text_field( $slot['start'] )
				&& $booking_end === sanitize_text_field( $slot['end'] )
				&& $location_type === sanitize_key( $slot['location_type'] )
			) {
				return true;
			}
		}

		return new WP_Error(
			'tutorhelper_pro_reschedule_slot_unavailable',
			__( 'That time is no longer available. Please choose another date or time.', 'tutorhelper-pro' )
		);
	}

	/**
	 * Describe cancellation terms for this specific lesson and student.
	 *
	 * @param object $booking    Booking record.
	 * @param int    $student_id Student user ID.
	 * @return array
	 */
	private static function get_cancellation_policy( $booking, $student_id ) {
		$booking_type = TutorHelper_Booking_Types::get_by_id( absint( $booking->booking_type_id ) );
		$result = array(
			'message' => __( 'Online cancellation is not available for this lesson.', 'tutorhelper-pro' ),
			'blocked_by_allowance' => false,
		);

		if ( ! $booking_type || empty( $booking_type->cancellations_allowed ) ) {
			$result['message'] = __( 'Your tutor has not enabled online cancellation for this lesson type. Please contact your tutor if you need help.', 'tutorhelper-pro' );
			return $result;
		}

		$status = sanitize_key( $booking->status );
		if ( ! in_array( $status, array( TutorHelper_Booking_Records::STATUS_CONFIRMED, TutorHelper_Booking_Records::STATUS_UNCONFIRMED ), true ) ) {
			$result['message'] = __( 'This lesson is no longer eligible for online cancellation.', 'tutorhelper-pro' );
			return $result;
		}

		$timing = self::get_notice_timing(
			$booking,
			absint( $booking_type->cancellation_notice_hours )
		);

		if ( ! $timing['future'] ) {
			$result['message'] = __( 'This lesson has already started or passed, so it can no longer be cancelled online.', 'tutorhelper-pro' );
			return $result;
		}

		if ( ! $timing['within_notice'] ) {
			$result['message'] = sprintf(
				/* translators: %s: cancellation deadline. */
				__( 'The cancellation window for this lesson closed on %s.', 'tutorhelper-pro' ),
				self::format_datetime( $timing['deadline'] )
			);
			return $result;
		}

		$allowance = self::get_allowance_status(
			$student_id,
			TutorHelper_Pro_Booking_Change_Limits::ACTION_CANCELLATION
		);

		if ( ! $allowance['available'] ) {
			$result['blocked_by_allowance'] = true;
			$result['message'] = self::build_allowance_blocked_message(
				__( 'cancel', 'tutorhelper-pro' ),
				$allowance,
				$timing['deadline']
			);
			return $result;
		}

		$result['message'] = sprintf(
			/* translators: 1: deadline, 2: allowance information. */
			__( 'You can cancel this lesson online until %1$s. %2$s', 'tutorhelper-pro' ),
			self::format_datetime( $timing['deadline'] ),
			$allowance['summary']
		);

		return $result;
	}

	/**
	 * Describe rescheduling terms for this specific lesson and student.
	 *
	 * @param object $booking    Booking record.
	 * @param int    $student_id Student user ID.
	 * @return array
	 */
	private static function get_reschedule_policy( $booking, $student_id ) {
		$result = array(
			'can_reschedule' => false,
			'message' => __( 'Online rescheduling is not available for this lesson.', 'tutorhelper-pro' ),
			'deadline' => null,
		);

		if ( TutorHelper_Booking_Records::STATUS_CONFIRMED !== sanitize_key( $booking->status ) ) {
			$result['message'] = __( 'This lesson must be confirmed before it can be rescheduled online.', 'tutorhelper-pro' );
			return $result;
		}

		$booking_type = TutorHelper_Booking_Types::get_by_id( absint( $booking->booking_type_id ) );
		if ( ! $booking_type ) {
			$result['message'] = __( 'The rescheduling rules for this lesson are unavailable. Please contact your tutor.', 'tutorhelper-pro' );
			return $result;
		}

		if ( ! TutorHelper_Pro_Booking_Type_Settings::can_reschedule( absint( $booking->booking_type_id ) ) ) {
			$result['message'] = __( 'Your tutor has not enabled online rescheduling for this lesson type.', 'tutorhelper-pro' );
			return $result;
		}

		if ( ! TutorHelper_Student_Booking_Access::can_book( $booking_type, $student_id ) ) {
			$result['message'] = __( 'This lesson type is not currently available for you to book online. Please contact your tutor if you need to move the lesson.', 'tutorhelper-pro' );
			return $result;
		}

		$notice_hours = TutorHelper_Pro_Booking_Type_Settings::get_reschedule_notice_hours(
			absint( $booking->booking_type_id )
		);
		$timing = self::get_notice_timing( $booking, $notice_hours );
		$result['deadline'] = $timing['deadline'];

		if ( ! $timing['future'] ) {
			$result['message'] = __( 'This lesson has already started or passed, so it can no longer be rescheduled.', 'tutorhelper-pro' );
			return $result;
		}

		if ( ! $timing['within_notice'] ) {
			$result['message'] = sprintf(
				/* translators: %s: reschedule deadline. */
				__( 'The rescheduling window for this lesson closed on %s.', 'tutorhelper-pro' ),
				self::format_datetime( $timing['deadline'] )
			);
			return $result;
		}

		$allowance = self::get_allowance_status(
			$student_id,
			TutorHelper_Pro_Booking_Change_Limits::ACTION_RESCHEDULE
		);

		if ( ! $allowance['available'] ) {
			$result['message'] = self::build_allowance_blocked_message(
				__( 'reschedule', 'tutorhelper-pro' ),
				$allowance,
				$timing['deadline']
			);
			return $result;
		}

		$result['can_reschedule'] = true;
		$result['message'] = sprintf(
			/* translators: 1: deadline, 2: allowance information. */
			__( 'You can reschedule this lesson online until %1$s. %2$s', 'tutorhelper-pro' ),
			self::format_datetime( $timing['deadline'] ),
			$allowance['summary']
		);

		return $result;
	}

	/**
	 * Build the booking-specific notice deadline in UTC.
	 *
	 * @param object $booking      Booking record.
	 * @param int    $notice_hours Required notice.
	 * @return array
	 */
	private static function get_notice_timing( $booking, $notice_hours ) {
		try {
			$start = new DateTimeImmutable(
				sanitize_text_field( $booking->booking_start ),
				new DateTimeZone( 'UTC' )
			);
			$now = new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		} catch ( Exception $exception ) {
			return array(
				'future' => false,
				'within_notice' => false,
				'deadline' => null,
			);
		}

		$deadline = $start->modify( '-' . absint( $notice_hours ) . ' hours' );
		return array(
			'future' => $start > $now,
			'within_notice' => $now <= $deadline,
			'deadline' => $deadline,
		);
	}

	/**
	 * Return the student's rolling allowance state.
	 *
	 * @param int    $student_id Student ID.
	 * @param string $action_type Action key.
	 * @return array
	 */
	private static function get_allowance_status( $student_id, $action_type ) {
		$is_cancellation = TutorHelper_Pro_Booking_Change_Limits::ACTION_CANCELLATION === $action_type;
		$limit = $is_cancellation
			? TutorHelper_Pro_Booking_Change_Limits::get_cancellation_limit( $student_id )
			: TutorHelper_Pro_Booking_Change_Limits::get_reschedule_limit( $student_id );
		$used = $is_cancellation
			? TutorHelper_Pro_Booking_Change_Limits::count_recent_cancellations( $student_id )
			: TutorHelper_Pro_Booking_Change_Limits::count_recent_reschedules( $student_id );

		if ( 0 === $limit ) {
			return array(
				'available' => true,
				'limit' => 0,
				'used' => $used,
				'next_available' => null,
				'summary' => __( 'Your tutor has not set a 3-month limit for this type of change.', 'tutorhelper-pro' ),
			);
		}

		$remaining = max( 0, $limit - $used );
		if ( 0 < $remaining ) {
			$summary = sprintf(
				/* translators: 1: remaining uses, 2: total allowance. */
				_n(
					'You have %1$d of your %2$d change remaining in the current rolling 3-month period.',
					'You have %1$d of your %2$d changes remaining in the current rolling 3-month period.',
					$remaining,
					'tutorhelper-pro'
				),
				$remaining,
				$limit
			);

			return array(
				'available' => true,
				'limit' => $limit,
				'used' => $used,
				'next_available' => null,
				'summary' => $summary,
			);
		}

		return array(
			'available' => false,
			'limit' => $limit,
			'used' => $used,
			'next_available' => self::get_next_allowance_time( $student_id, $action_type, $limit, $used ),
			'summary' => '',
		);
	}

	/**
	 * Calculate when enough recent actions will fall outside the rolling
	 * three-month window for another change to become available.
	 *
	 * @param int    $student_id Student ID.
	 * @param string $action_type Action key.
	 * @param int    $limit Limit.
	 * @param int    $used Current usage.
	 * @return DateTimeImmutable|null
	 */
	private static function get_next_allowance_time( $student_id, $action_type, $limit, $used ) {
		$now = new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		$from = $now->modify( '-3 months' )->format( 'Y-m-d H:i:s' );
		$actions = TutorHelper_Pro_Booking_Change_Limits::get_actions(
			array(
				'student_user_id' => $student_id,
				'action_type' => $action_type,
				'date_from' => $from,
				'limit' => 1000,
			)
		);

		if ( empty( $actions ) ) {
			return null;
		}

		$ascending = array_reverse( $actions );
		$must_expire = max( 1, $used - $limit + 1 );
		$index = $must_expire - 1;

		if ( ! isset( $ascending[ $index ]['occurred_at'] ) ) {
			return null;
		}

		try {
			$occurred = new DateTimeImmutable(
				sanitize_text_field( $ascending[ $index ]['occurred_at'] ),
				new DateTimeZone( 'UTC' )
			);
			return $occurred->modify( '+3 months' );
		} catch ( Exception $exception ) {
			return null;
		}
	}

	/**
	 * Friendly allowance-blocked wording.
	 *
	 * @param string                 $verb      Action verb.
	 * @param array                  $allowance Allowance state.
	 * @param DateTimeImmutable|null $deadline Booking deadline.
	 * @return string
	 */
	private static function build_allowance_blocked_message( $verb, $allowance, $deadline ) {
		$limit = absint( $allowance['limit'] );
		$next = $allowance['next_available'];

		$message = sprintf(
			/* translators: 1: action verb, 2: allowance number. */
			__( 'You have used all %2$d times you can %1$s a lesson within the current rolling 3-month period.', 'tutorhelper-pro' ),
			$verb,
			$limit
		);

		if ( $next instanceof DateTimeImmutable ) {
			$message .= ' ' . sprintf(
				/* translators: %s: date/time another change becomes available. */
				__( 'Your next one becomes available from %s.', 'tutorhelper-pro' ),
				self::format_datetime( $next )
			);

			if ( $deadline instanceof DateTimeImmutable && $next > $deadline ) {
				$message .= ' ' . __( 'That will be after the change deadline for this particular lesson, so please contact your tutor if you need help with it.', 'tutorhelper-pro' );
			}
		}

		return $message;
	}

	/**
	 * Enqueue the small frontend enhancement and configure reschedule mode.
	 *
	 * @return void
	 */
	public static function enqueue_frontend_assets() {
		if ( ! is_user_logged_in() ) {
			return;
		}

		$script_path = TUTORHELPER_PRO_PATH . 'assets/js/student-rescheduling.js';
		$style_path = TUTORHELPER_PRO_PATH . 'assets/css/student-rescheduling.css';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/js/student-rescheduling.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_PRO_VERSION,
			true
		);
		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/css/student-rescheduling.css',
			array(),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_PRO_VERSION
		);

		$booking_id = self::get_query_reschedule_id();
		if ( ! $booking_id ) {
			return;
		}

		$student_id = get_current_user_id();
		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		if ( ! $booking || absint( $booking->student_user_id ) !== $student_id ) {
			return;
		}

		$policy = self::get_reschedule_policy( $booking, $student_id );
		if ( empty( $policy['can_reschedule'] ) ) {
			return;
		}

		$booking_type = TutorHelper_Booking_Types::get_by_id( absint( $booking->booking_type_id ) );
		$cancellation = self::get_cancellation_policy( $booking, $student_id );

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperProReschedule',
			array(
				'active' => true,
				'bookingId' => $booking_id,
				'bookingTypeId' => absint( $booking->booking_type_id ),
				'bookingTitle' => $booking_type && ! empty( $booking_type->title )
					? sanitize_text_field( $booking_type->title )
					: __( 'lesson', 'tutorhelper-pro' ),
				'policyText' => $cancellation['message'] . ' ' . $policy['message'],
				'strings' => array(
					'heading' => __( 'Reschedule your lesson', 'tutorhelper-pro' ),
					'intro' => __( 'Choose a new date and time. Your current lesson stays booked until you confirm the replacement time.', 'tutorhelper-pro' ),
					'serviceHeading' => __( 'Lesson type', 'tutorhelper-pro' ),
					'policyHeading' => __( 'Cancellation and rescheduling terms', 'tutorhelper-pro' ),
					'agreement' => __( 'I understand the cancellation and rescheduling terms.', 'tutorhelper-pro' ),
					'submit' => __( 'Confirm reschedule', 'tutorhelper-pro' ),
				),
			)
		);
	}

	/**
	 * Send student and tutor notifications after the schedule changes.
	 *
	 * @param int    $booking_id   Booking ID.
	 * @param string $old_start    Previous UTC start.
	 * @param string $old_end      Previous UTC end.
	 * @param string $old_timezone Previous timezone.
	 * @return void
	 */
	private static function send_reschedule_emails( $booking_id, $old_start, $old_end, $old_timezone ) {
		$context = TutorHelper_Booking_Email_Context::build( $booking_id );
		if ( is_wp_error( $context ) ) {
			return;
		}

		$old = self::format_old_lesson( $old_start, $old_end, $old_timezone );
		$placeholders = $context['placeholders'];
		$placeholders['{old_lesson_date}'] = $old['date'];
		$placeholders['{old_lesson_time}'] = $old['time'];

		if ( TutorHelper_Email_Templates::is_enabled( self::TEMPLATE_STUDENT ) ) {
			TutorHelper_Email_Sender::send(
				self::TEMPLATE_STUDENT,
				$context['student_email'],
				$placeholders,
				array(
					'reply_to_email' => $context['tutor_email'],
					'reply_to_name' => $placeholders['{tutor_name}'],
					'context' => array(
						'booking_id' => $booking_id,
						'event' => 'student_rescheduled',
					),
				)
			);
		}

		if ( TutorHelper_Email_Templates::is_enabled( self::TEMPLATE_TUTOR ) ) {
			TutorHelper_Email_Sender::send(
				self::TEMPLATE_TUTOR,
				$context['tutor_email'],
				$placeholders,
				array(
					'reply_to_email' => $context['student_email'],
					'reply_to_name' => $placeholders['{student_name}'],
					'context' => array(
						'booking_id' => $booking_id,
						'event' => 'student_rescheduled',
					),
				)
			);
		}
	}

	/**
	 * Format the original lesson date/time for email placeholders.
	 *
	 * @param string $start_utc UTC start.
	 * @param string $end_utc   UTC end.
	 * @param string $timezone_name Booking timezone.
	 * @return array
	 */
	private static function format_old_lesson( $start_utc, $end_utc, $timezone_name ) {
		try {
			$timezone = new DateTimeZone( $timezone_name ? $timezone_name : wp_timezone()->getName() );
			$start = ( new DateTimeImmutable( $start_utc, new DateTimeZone( 'UTC' ) ) )->setTimezone( $timezone );
			$end = ( new DateTimeImmutable( $end_utc, new DateTimeZone( 'UTC' ) ) )->setTimezone( $timezone );
		} catch ( Exception $exception ) {
			return array( 'date' => '', 'time' => '' );
		}

		return array(
			'date' => wp_date( get_option( 'date_format' ), $start->getTimestamp(), $timezone ),
			'time' => sprintf(
				'%1$s–%2$s',
				wp_date( get_option( 'time_format' ), $start->getTimestamp(), $timezone ),
				wp_date( get_option( 'time_format' ), $end->getTimestamp(), $timezone )
			),
		);
	}

	/**
	 * Format a UTC DateTime in the site's timezone using friendly wording.
	 *
	 * @param DateTimeImmutable|null $date Date/time.
	 * @return string
	 */
	private static function format_datetime( $date ) {
		if ( ! $date instanceof DateTimeImmutable ) {
			return '';
		}

		$local = $date->setTimezone( wp_timezone() );
		return wp_date(
			'l j F Y \a\t ' . get_option( 'time_format' ),
			$local->getTimestamp(),
			wp_timezone()
		);
	}

	/**
	 * Return reschedule booking ID from the booking-page URL.
	 *
	 * @return int
	 */
	private static function get_query_reschedule_id() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only mode selector; ownership and eligibility are checked before any data is exposed or changed.
		return isset( $_GET[ self::QUERY_ARG ] ) && ! is_array( $_GET[ self::QUERY_ARG ] )
			? absint( wp_unslash( $_GET[ self::QUERY_ARG ] ) )
			: 0;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Return reschedule booking ID added by the extension-field bridge.
	 *
	 * @return int
	 */
	private static function get_submitted_reschedule_id() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- The AJAX nonce is checked immediately when this value is non-zero.
		return isset( $_GET[ self::EXTENSION_FIELD ] ) && ! is_array( $_GET[ self::EXTENSION_FIELD ] )
			? absint( wp_unslash( $_GET[ self::EXTENSION_FIELD ] ) )
			: 0;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
	}
}
