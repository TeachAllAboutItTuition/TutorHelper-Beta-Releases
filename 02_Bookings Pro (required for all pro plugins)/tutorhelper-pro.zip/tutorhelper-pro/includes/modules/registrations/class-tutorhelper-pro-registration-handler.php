<?php
/**
 * TutorHelper Pro public registration handler.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles secure public Student Registration submissions.
 */
final class TutorHelper_Pro_Registration_Handler {

	/**
	 * WordPress admin-post action.
	 *
	 * @var string
	 */
	const ACTION =
		'tutorhelper_pro_submit_registration';

	/**
	 * Nonce action.
	 *
	 * @var string
	 */
	const NONCE_ACTION =
		'tutorhelper_pro_registration';

	/**
	 * Nonce field name.
	 *
	 * @var string
	 */
	const NONCE_NAME =
		'tutorhelper_pro_registration_nonce';

	/**
	 * Minimum permitted completion time.
	 *
	 * Very fast submissions are treated as automated.
	 *
	 * @var int
	 */
	const MINIMUM_COMPLETION_SECONDS = 3;

	/**
	 * Rate-limit window in seconds.
	 *
	 * @var int
	 */
	const RATE_LIMIT_WINDOW =
		15 * MINUTE_IN_SECONDS;

	/**
	 * Maximum attempts within the rate-limit window.
	 *
	 * @var int
	 */
	const RATE_LIMIT_ATTEMPTS = 5;


	/**
	 * Register submission hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'admin_post_nopriv_'
				. self::ACTION,
			array(
				__CLASS__,
				'handle_submission',
			)
		);

		add_action(
			'admin_post_'
				. self::ACTION,
			array(
				__CLASS__,
				'handle_submission',
			)
		);

		add_action(
			'tutorhelper_pro_registration_submitted',
			array( __CLASS__, 'sync_parent_details' ),
			5
		);

		add_action(
			'tutorhelper_pro_registration_submitted',
			array( __CLASS__, 'sync_student_phone' ),
			6
		);
	}


	/**
	 * Copy submitted parent/guardian onboarding answers into Core's canonical
	 * parent fields so email and the future parent-account add-on can use them.
	 *
	 * @param int $user_id Student WordPress user ID.
	 * @return void
	 */
	public static function sync_parent_details( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id || ! class_exists( 'TutorHelper_Students' ) ) {
			return;
		}

		$parent_name  = '';
		$parent_email = '';

		foreach ( TutorHelper_Pro_Onboarding::get_answers_for_student( $user_id ) as $answer ) {
			$label = isset( $answer->question_text_snapshot )
				? self::normalise_registration_question_label( $answer->question_text_snapshot )
				: '';
			$value = isset( $answer->answer ) && is_scalar( $answer->answer )
				? trim( (string) $answer->answer )
				: '';

			if (
				'' === $value
				|| ( false === strpos( $label, 'parent' )
					&& false === strpos( $label, 'guardian' )
					&& false === strpos( $label, 'carer' ) )
			) {
				continue;
			}

			if ( '' === $parent_email && false !== strpos( $label, 'email' ) ) {
				$candidate = sanitize_email( $value );
				if ( is_email( $candidate ) ) {
					$parent_email = $candidate;
				}
			} elseif ( '' === $parent_name && false !== strpos( $label, 'name' ) ) {
				$parent_name = sanitize_text_field( $value );
			}
		}

		if ( '' !== $parent_name ) {
			update_user_meta( $user_id, TutorHelper_Students::META_PARENT_NAME, $parent_name );
		}

		if ( '' !== $parent_email ) {
			update_user_meta( $user_id, TutorHelper_Students::META_PARENT_EMAIL, $parent_email );
		}
	}


	/**
	 * Copy a student telephone answer into Core's canonical student phone field.
	 *
	 * Registration questions are tutor-configurable. A question containing
	 * "phone", "telephone" or "mobile" is treated as the student's number
	 * only when it is not labelled for a parent, guardian or carer.
	 *
	 * @param int $user_id Student WordPress user ID.
	 * @return void
	 */
	public static function sync_student_phone( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id || ! class_exists( 'TutorHelper_Students' ) ) {
			return;
		}

		foreach ( TutorHelper_Pro_Onboarding::get_answers_for_student( $user_id ) as $answer ) {
			$label = isset( $answer->question_text_snapshot )
				? self::normalise_registration_question_label(
					$answer->question_text_snapshot
				)
				: '';
			$value = isset( $answer->answer ) && is_scalar( $answer->answer )
				? sanitize_text_field( (string) $answer->answer )
				: '';

			if ( '' === $value || '' === $label ) {
				continue;
			}

			$is_parent_question = false !== strpos( $label, 'parent' )
				|| false !== strpos( $label, 'guardian' )
				|| false !== strpos( $label, 'carer' );
			$is_phone_question = false !== strpos( $label, 'phone' )
				|| false !== strpos( $label, 'telephone' )
				|| false !== strpos( $label, 'mobile' );

			if ( $is_parent_question || ! $is_phone_question ) {
				continue;
			}

			update_user_meta(
				$user_id,
				TutorHelper_Students::META_STUDENT_PHONE,
				$value
			);

			return;
		}
	}


	/** Return a comparable registration-question label. */
	private static function normalise_registration_question_label( $label ) {
		$label = strtolower( remove_accents( wp_strip_all_tags( (string) $label ) ) );
		$label = str_replace( '&', ' and ', $label );

		return trim( preg_replace( '/[^a-z0-9]+/', ' ', $label ) );
	}


	/**
	 * Handle a public registration submission.
	 *
	 * @return void
	 */
	public static function handle_submission() {

		$redirect_url =
			self::get_return_url();

		if (
			'POST'
			!== strtoupper(
				isset(
					$_SERVER['REQUEST_METHOD']
				)
					? sanitize_text_field(
						wp_unslash(
							$_SERVER['REQUEST_METHOD']
						)
					)
					: ''
			)
		) {
			self::redirect_with_error(
				$redirect_url,
				'invalid_request'
			);
		}

		self::verify_nonce(
			$redirect_url
		);

		self::verify_registration_status(
			$redirect_url
		);

		self::verify_honeypot(
			$redirect_url
		);

		self::verify_completion_time(
			$redirect_url
		);

		self::verify_rate_limit(
			$redirect_url
		);

		$system_fields =
            self::get_submitted_system_fields();

        $system_fields =
            self::validate_system_fields(
                $system_fields
            );

        if (
            is_wp_error(
                $system_fields
            )
        ) {
            self::redirect_with_error(
                $redirect_url,
                $system_fields->get_error_code()
            );
        }


        $submitted_answers =
            isset(
                $_POST['onboarding']
            )
                ? wp_unslash(
                    $_POST['onboarding']
                )
                : array();

        $custom_answers =
            TutorHelper_Pro_Onboarding::
                validate_registration_answers(
                    $submitted_answers
                );

        if (
            is_wp_error(
                $custom_answers
            )
        ) {
            self::redirect_with_error(
                $redirect_url,
                $custom_answers->get_error_code()
            );
        }


        $consent =
            self::validate_consent();

        if (
            is_wp_error(
                $consent
            )
        ) {
            self::redirect_with_error(
                $redirect_url,
                $consent->get_error_code()
            );
        }


        $registration_type =
            self::get_registration_type();


        $user_id =
            self::create_student_account(
                $system_fields
            );

        if (
            is_wp_error(
                $user_id
            )
        ) {
            self::redirect_with_error(
                $redirect_url,
                $user_id->get_error_code()
            );
        }


        $stored =
            self::store_student_registration(
                $user_id,
                $system_fields,
                $custom_answers,
                $consent,
                $registration_type
            );

        if (
            is_wp_error(
                $stored
            )
        ) {

            self::rollback_student(
                $user_id
            );

            self::redirect_with_error(
                $redirect_url,
                $stored->get_error_code()
            );
        }


        /*
        * Ask WordPress to send its standard secure
        * new-user/password setup message.
        */
        wp_send_new_user_notifications(
            $user_id,
            'user'
        );


        wp_safe_redirect(
            add_query_arg(
                'tutorhelper_registration',
                'created',
                $redirect_url
            )
        );

        /**
         * Fires after a public student registration
         * has been successfully stored.
         *
         * @param int $user_id Student WordPress user ID.
         */
        do_action(
            'tutorhelper_pro_registration_submitted',
            $user_id
        );

        exit;
	}


	/**
	 * Verify registration nonce.
	 *
	 * @param string $redirect_url Return URL.
	 *
	 * @return void
	 */
	private static function verify_nonce(
		$redirect_url
	) {

		$nonce =
			isset(
				$_POST[
					self::NONCE_NAME
				]
			)
				? sanitize_text_field(
					wp_unslash(
						$_POST[
							self::NONCE_NAME
						]
					)
				)
				: '';

		if (
			! $nonce
			|| ! wp_verify_nonce(
				$nonce,
				self::NONCE_ACTION
			)
		) {
			self::redirect_with_error(
				$redirect_url,
				'invalid_nonce'
			);
		}
	}


	/**
	 * Confirm that registration is still available.
	 *
	 * This is checked server-side rather than trusting the
	 * form state rendered earlier.
	 *
	 * @param string $redirect_url Return URL.
	 *
	 * @return void
	 */
	private static function verify_registration_status(
		$redirect_url
	) {

		$status =
			TutorHelper_Pro_Registration_Settings::
				get_status();

		if (
			! in_array(
				$status,
				array(
					TutorHelper_Pro_Registration_Settings::
						STATUS_OPEN,

					TutorHelper_Pro_Registration_Settings::
						STATUS_WAITING_LIST,
				),
				true
			)
		) {
			self::redirect_with_error(
				$redirect_url,
				'registrations_closed'
			);
		}
	}


	/**
	 * Check the hidden honeypot field.
	 *
	 * @param string $redirect_url Return URL.
	 *
	 * @return void
	 */
	private static function verify_honeypot(
		$redirect_url
	) {

		$honeypot =
			isset(
				$_POST[
					'tutorhelper_website'
				]
			)
				? sanitize_text_field(
					wp_unslash(
						$_POST[
							'tutorhelper_website'
						]
					)
				)
				: '';

		if ( '' !== $honeypot ) {
			self::redirect_with_error(
				$redirect_url,
				'request_rejected'
			);
		}
	}


	/**
	 * Reject unrealistically fast form submissions.
	 *
	 * @param string $redirect_url Return URL.
	 *
	 * @return void
	 */
	private static function verify_completion_time(
		$redirect_url
	) {

		$started =
			isset(
				$_POST[
					'tutorhelper_registration_started'
				]
			)
				? absint(
					$_POST[
						'tutorhelper_registration_started'
					]
				)
				: 0;

		if ( ! $started ) {
			self::redirect_with_error(
				$redirect_url,
				'invalid_request'
			);
		}

		$elapsed =
			time() - $started;

		if (
			$elapsed
			< self::MINIMUM_COMPLETION_SECONDS
		) {
			self::redirect_with_error(
				$redirect_url,
				'request_rejected'
			);
		}
	}


	/**
	 * Apply a short-lived per-client rate limit.
	 *
	 * No raw IP address is stored persistently.
	 *
	 * @param string $redirect_url Return URL.
	 *
	 * @return void
	 */
	private static function verify_rate_limit(
		$redirect_url
	) {

		$key =
			self::get_rate_limit_key();

		if ( ! $key ) {
			return;
		}

		$attempts =
			absint(
				get_transient(
					$key
				)
			);

		if (
			$attempts
			>= self::RATE_LIMIT_ATTEMPTS
		) {
			self::redirect_with_error(
				$redirect_url,
				'rate_limited'
			);
		}

		set_transient(
			$key,
			$attempts + 1,
			self::RATE_LIMIT_WINDOW
		);
	}


	/**
	 * Build an anonymous transient key for rate limiting.
	 *
	 * @return string
	 */
	private static function get_rate_limit_key() {

		$ip =
			isset(
				$_SERVER['REMOTE_ADDR']
			)
				? sanitize_text_field(
					wp_unslash(
						$_SERVER['REMOTE_ADDR']
					)
				)
				: '';

		if ( ! $ip ) {
			return '';
		}

		$hash =
			hash_hmac(
				'sha256',
				$ip,
				wp_salt(
					'nonce'
				)
			);

		return
			'tutorhelper_reg_'
			. substr(
				$hash,
				0,
				32
			);
	}


    /**
     * Return submitted TutorHelper system fields.
     *
     * @return array
     */
    private static function get_submitted_system_fields() {

        $fields =
            isset(
                $_POST['system_fields']
            )
                ? wp_unslash(
                    $_POST['system_fields']
                )
                : array();

        return is_array( $fields )
            ? $fields
            : array();
    }


    /**
     * Validate TutorHelper account fields.
     *
     * Field rules come from TutorHelper's fixed system-question
     * definitions, not from values supplied by the browser.
     *
     * @param array $fields Submitted fields.
     *
     * @return array|WP_Error
     */
    private static function validate_system_fields(
        $fields
    ) {

        $definitions =
            TutorHelper_Pro_Onboarding::
                get_system_question_definitions();

        $clean = array();

        foreach (
            $definitions
            as $key => $definition
        ) {

            $value =
                array_key_exists(
                    $key,
                    $fields
                )
                    ? $fields[
                        $key
                    ]
                    : '';

            if (
                ! is_scalar(
                    $value
                )
            ) {
                $value = '';
            }

            $value =
                trim(
                    (string) $value
                );

            if (
                ! empty(
                    $definition[
                        'is_required'
                    ]
                )
                && '' === $value
            ) {
                return new WP_Error(
                    'tutorhelper_registration_required_field',
                    __(
                        'Please complete all required account fields.',
                        'tutorhelper-pro'
                    )
                );
            }

            switch ( $key ) {

                case TutorHelper_Pro_Onboarding::
                    QUESTION_STUDENT_EMAIL:

                    $value =
                        sanitize_email(
                            $value
                        );

                    if (
                        ! $value
                        || ! is_email(
                            $value
                        )
                    ) {
                        return new WP_Error(
                            'tutorhelper_registration_invalid_email',
                            __(
                                'Please enter a valid student email address.',
                                'tutorhelper-pro'
                            )
                        );
                    }

                    if (
                        email_exists(
                            $value
                        )
                    ) {
                        return new WP_Error(
                            'tutorhelper_registration_email_exists',
                            __(
                                'An account already exists for this email address.',
                                'tutorhelper-pro'
                            )
                        );
                    }

                    break;


                case TutorHelper_Pro_Onboarding::
                    QUESTION_DATE_OF_BIRTH:

                    $value =
                        self::validate_date_of_birth(
                            $value
                        );

                    if (
                        is_wp_error(
                            $value
                        )
                    ) {
                        return $value;
                    }

                    break;


                default:

                    $value =
                        sanitize_text_field(
                            $value
                        );

                    break;
            }

            $clean[
                $key
            ] = $value;
        }

        return $clean;
    }


    /**
     * Validate and normalise a date of birth.
     *
     * @param string $value Submitted DOB.
     *
     * @return string|WP_Error
     */
    private static function validate_date_of_birth(
        $value
    ) {

        $value =
            sanitize_text_field(
                $value
            );

        $date =
            DateTimeImmutable::
                createFromFormat(
                    '!Y-m-d',
                    $value,
                    wp_timezone()
                );

        $errors =
            DateTimeImmutable::
                getLastErrors();

        if (
            ! $date
            || (
                is_array( $errors )
                && (
                    ! empty(
                        $errors[
                            'warning_count'
                        ]
                    )
                    || ! empty(
                        $errors[
                            'error_count'
                        ]
                    )
                )
            )
            || $date->format(
                'Y-m-d'
            ) !== $value
        ) {
            return new WP_Error(
                'tutorhelper_registration_invalid_dob',
                __(
                    'Please enter a valid date of birth.',
                    'tutorhelper-pro'
                )
            );
        }

        $today =
            new DateTimeImmutable(
                'today',
                wp_timezone()
            );

        if (
            $date > $today
        ) {
            return new WP_Error(
                'tutorhelper_registration_invalid_dob',
                __(
                    'The date of birth cannot be in the future.',
                    'tutorhelper-pro'
                )
            );
        }

        /*
        * Prevent clearly erroneous dates while avoiding
        * assumptions about a student's minimum age.
        */
        if (
            (int) $date->format( 'Y' )
            < 1900
        ) {
            return new WP_Error(
                'tutorhelper_registration_invalid_dob',
                __(
                    'Please enter a valid date of birth.',
                    'tutorhelper-pro'
                )
            );
        }

        return $date->format(
            'Y-m-d'
        );
    }


    /**
     * Validate registration acknowledgements.
     *
     * Marketing remains optional and is never implied by
     * accepting the required registration terms.
     *
     * @return array|WP_Error
     */
    private static function validate_consent() {

        $privacy =
            isset(
                $_POST[
                    'privacy_acknowledged'
                ]
            )
                && '1'
                === sanitize_text_field(
                    wp_unslash(
                        $_POST[
                            'privacy_acknowledged'
                        ]
                    )
                );

        $terms =
            isset(
                $_POST[
                    'terms_agreed'
                ]
            )
                && '1'
                === sanitize_text_field(
                    wp_unslash(
                        $_POST[
                            'terms_agreed'
                        ]
                    )
                );

        if (
            ! $privacy
            || ! $terms
        ) {
            return new WP_Error(
                'tutorhelper_registration_consent_required',
                __(
                    'Please review and accept the required privacy and tuition terms.',
                    'tutorhelper-pro'
                )
            );
        }

        $marketing =
            isset(
                $_POST[
                    'marketing_opt_in'
                ]
            )
                && '1'
                === sanitize_text_field(
                    wp_unslash(
                        $_POST[
                            'marketing_opt_in'
                        ]
                    )
                );

        return array(
            'privacy_acknowledged' =>
                true,

            'terms_agreed' =>
                true,

            'marketing_opt_in' =>
                $marketing,
        );
    }


    /**
     * Determine the server-side registration type.
     *
     * Never trust a hidden browser field for this value.
     *
     * @return string
     */
    private static function get_registration_type() {

        $status =
            TutorHelper_Pro_Registration_Settings::
                get_status();

        return
            TutorHelper_Pro_Registration_Settings::
                STATUS_WAITING_LIST
            === $status
                ? 'waiting_list'
                : 'student';
    }



    /**
     * Convert a name to a username-safe component.
     *
     * @param string $name Name component.
     *
     * @return string
     */
    private static function normalise_username_part(
        $name
    ) {

        $name =
            strtolower(
                remove_accents(
                    sanitize_text_field(
                        $name
                    )
                )
            );

        $name =
            preg_replace(
                '/[^a-z0-9]/',
                '',
                $name
            );

        return (string) $name;
    }


    /**
     * Generate a readable unique student username.
     *
     * Example:
     * holly_billinghurst_2642
     *
     * @param string $first_name First name.
     * @param string $last_name  Last name.
     *
     * @return string
     */
    private static function generate_username(
        $first_name,
        $last_name
    ) {

        $first =
            self::normalise_username_part(
                $first_name
            );

        $last =
            self::normalise_username_part(
                $last_name
            );

        if ( '' === $first ) {
            $first = 'student';
        }

        if ( '' === $last ) {
            $last = 'account';
        }

        /*
        * user_login is limited to 60 characters.
        *
        * Reserve six characters for:
        * _ + _ + YY + NN
        */
        $available =
            54;

        if (
            strlen( $first )
            + strlen( $last )
            > $available
        ) {
            $first =
                substr(
                    $first,
                    0,
                    27
                );

            $last =
                substr(
                    $last,
                    0,
                    27
                );
        }

        $year =
            wp_date(
                'y'
            );

        for (
            $attempt = 0;
            $attempt < 100;
            $attempt++
        ) {

            $suffix =
                str_pad(
                    (string) wp_rand(
                        0,
                        99
                    ),
                    2,
                    '0',
                    STR_PAD_LEFT
                );

            $username =
                $first
                . '_'
                . $last
                . '_'
                . $year
                . $suffix;

            $username =
                sanitize_user(
                    $username,
                    true
                );

            if (
                ! username_exists(
                    $username
                )
            ) {
                return $username;
            }
        }

        /*
        * Extremely unlikely fallback with a larger random suffix.
        */
        do {

            $username =
                sanitize_user(
                    substr(
                        $first,
                        0,
                        24
                    )
                    . '_'
                    . substr(
                        $last,
                        0,
                        24
                    )
                    . '_'
                    . $year
                    . wp_rand(
                        100000,
                        999999
                    ),
                    true
                );

        } while (
            username_exists(
                $username
            )
        );

        return $username;
    }


    /**
     * Create the TutorHelper Student WordPress account.
     *
     * @param array $fields Validated account fields.
     *
     * @return int|WP_Error
     */
    private static function create_student_account(
        $fields
    ) {

        $first_name =
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_STUDENT_FIRST_NAME
            ];

        $last_name =
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_STUDENT_LAST_NAME
            ];

        $email =
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_STUDENT_EMAIL
            ];

        for (
            $attempt = 0;
            $attempt < 5;
            $attempt++
        ) {

            $username =
                self::generate_username(
                    $first_name,
                    $last_name
                );

            $user_id =
                wp_insert_user(
                    array(
                        'user_login' =>
                            $username,

                        'user_email' =>
                            $email,

                        'user_pass' =>
                            wp_generate_password(
                                32,
                                true,
                                true
                            ),

                        'first_name' =>
                            $first_name,

                        'last_name' =>
                            $last_name,

                        'display_name' =>
                            trim(
                                $first_name
                                . ' '
                                . $last_name
                            ),

                        'role' =>
                            TutorHelper_Students::
                                STUDENT_ROLE,
                    )
                );

            if (
                ! is_wp_error(
                    $user_id
                )
            ) {
                return absint(
                    $user_id
                );
            }

            /*
            * A simultaneous registration could theoretically
            * claim the username between generation and insert.
            * Generate another one and retry.
            */
            if (
                'existing_user_login'
                !== $user_id->get_error_code()
            ) {
                return $user_id;
            }
        }

        return new WP_Error(
            'tutorhelper_registration_account_failed',
            __(
                'The student account could not be created.',
                'tutorhelper-pro'
            )
        );
    }


    /**
     * Store validated student registration data.
     *
     * @param int    $user_id           Student user ID.
     * @param array  $fields            Validated system fields.
     * @param array  $custom_answers    Validated onboarding answers.
     * @param array  $consent           Consent state.
     * @param string $registration_type Student or waiting_list.
     *
     * @return true|WP_Error
     */
    private static function store_student_registration(
        $user_id,
        $fields,
        $custom_answers,
        $consent,
        $registration_type
    ) {

        $user_id =
            absint(
                $user_id
            );

        if ( ! $user_id ) {
            return new WP_Error(
                'tutorhelper_registration_invalid_student',
                __(
                    'The student account could not be found.',
                    'tutorhelper-pro'
                )
            );
        }


        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_DATE_OF_BIRTH,
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_DATE_OF_BIRTH
            ]
        );


        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_ADDRESS_LINE_1,
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_ADDRESS_1
            ]
        );

        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_ADDRESS_LINE_2,
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_ADDRESS_2
            ]
        );

        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_ADDRESS_CITY,
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_CITY
            ]
        );

        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_ADDRESS_COUNTY,
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_COUNTY
            ]
        );

        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_ADDRESS_POSTCODE,
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_POSTCODE
            ]
        );

        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_ADDRESS_COUNTRY,
            $fields[
                TutorHelper_Pro_Onboarding::
                    QUESTION_COUNTRY
            ]
        );


        /*
        * Registration workflow metadata.
        */
        update_user_meta(
            $user_id,
            'tutorhelper_registration_source',
            'student_registration'
        );

        update_user_meta(
            $user_id,
            'tutorhelper_registration_status',
            'new'
        );

        /*
        * New registrations remain unable to book until
        * the tutor has reviewed the account.
        */
        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_BOOKING_BLOCKED,
            1
        );

        update_user_meta(
            $user_id,
            TutorHelper_Students::
                META_BOOKING_BLOCKED_MESSAGE,
            __(
                'Please allow your tutor to confirm your registration before booking lessons.',
                'tutorhelper-pro'
            )
        );

        update_user_meta(
            $user_id,
            'tutorhelper_registration_type',
            $registration_type
        );

        update_user_meta(
            $user_id,
            'tutorhelper_registration_submitted_at',
            current_time(
                'mysql'
            )
        );


        /*
        * Required privacy/terms acknowledgement.
        *
        * Policy URLs/versions will be added when we connect
        * the Registration Terms settings in the next stage.
        */
        $now =
            current_time(
                'mysql'
            );

        update_user_meta(
            $user_id,
            'tutorhelper_privacy_acknowledged_at',
            $now
        );

        update_user_meta(
            $user_id,
            'tutorhelper_terms_agreed_at',
            $now
        );

        update_user_meta(
            $user_id,
            TutorHelper_Pro_Terms_Update::META_ACCEPTED_AT,
            current_time( 'mysql', true )
        );

        update_user_meta(
            $user_id,
            TutorHelper_Pro_Terms_Update::META_ACCEPTED_VERSION,
            TutorHelper_Pro_Terms_Update::get_current_version()
        );


        /*
        * Marketing is deliberately separate and optional.
        */
        $marketing =
            ! empty(
                $consent[
                    'marketing_opt_in'
                ]
            );

        update_user_meta(
            $user_id,
            'tutorhelper_marketing_opt_in',
            $marketing
                ? 1
                : 0
        );

        update_user_meta(
            $user_id,
            'tutorhelper_marketing_source',
            'student_registration'
        );

        if ( $marketing ) {

            update_user_meta(
                $user_id,
                'tutorhelper_marketing_opt_in_at',
                $now
            );

        } else {

            delete_user_meta(
                $user_id,
                'tutorhelper_marketing_opt_in_at'
            );
        }


        /*
        * Only tutor-created onboarding answers enter
        * the Pro onboarding answers table.
        */
        $answers_saved =
            TutorHelper_Pro_Onboarding::
                save_registration_answers(
                    $user_id,
                    $custom_answers
                );

        if (
            is_wp_error(
                $answers_saved
            )
        ) {
            return $answers_saved;
        }

        return true;
    }


    /**
     * Remove a partially-created registration.
     *
     * @param int $user_id Student user ID.
     *
     * @return void
     */
    private static function rollback_student(
        $user_id
    ) {

        $user_id =
            absint(
                $user_id
            );

        if ( ! $user_id ) {
            return;
        }

        TutorHelper_Pro_Onboarding::
            delete_answers_for_student(
                $user_id
            );

        if (
            ! function_exists(
                'wp_delete_user'
            )
        ) {
            require_once ABSPATH
                . 'wp-admin/includes/user.php';
        }

        wp_delete_user(
            $user_id
        );
    }



	/**
	 * Return the safe page to send the visitor back to.
	 *
	 * @return string
	 */
	private static function get_return_url() {

		$return_url =
			isset(
				$_POST[
					'tutorhelper_return_url'
				]
			)
				? esc_url_raw(
					wp_unslash(
						$_POST[
							'tutorhelper_return_url'
						]
					)
				)
				: '';

		if ( ! $return_url ) {
			$return_url =
				home_url(
					'/'
				);
		}

		return wp_validate_redirect(
			$return_url,
			home_url(
				'/'
			)
		);
	}


	/**
	 * Redirect to the form with an error code.
	 *
	 * @param string $redirect_url Return URL.
	 * @param string $error_code   Error code.
	 *
	 * @return void
	 */
	private static function redirect_with_error(
		$redirect_url,
		$error_code
	) {

		wp_safe_redirect(
			add_query_arg(
				array(
					'tutorhelper_registration' =>
						'error',

					'tutorhelper_registration_error' =>
						sanitize_key(
							$error_code
						),
				),
				$redirect_url
			)
		);

		exit;
	}
}
