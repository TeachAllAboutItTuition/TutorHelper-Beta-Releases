<?php
/**
 * Annual privacy and terms review workflow.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records policy agreement and applies the fourteen-day reminder grace period.
 */
final class TutorHelper_Pro_Terms_Update {

	const META_ACCEPTED_AT      = 'tutorhelper_terms_privacy_accepted_at';
	const META_ACCEPTED_VERSION = 'tutorhelper_terms_privacy_version';
	const META_FIRST_DISMISSED  = 'tutorhelper_terms_privacy_first_dismissed_at';
	const META_LAST_DISMISSED   = 'tutorhelper_terms_privacy_last_dismissed_at';
	const OPTION_VERSION        = 'tutorhelper_pro_terms_privacy_version';
	const ACCEPT_ACTION         = 'tutorhelper_pro_accept_terms_update';
	const DISMISS_ACTION        = 'tutorhelper_pro_dismiss_terms_update';
	const EMAIL_ACTION          = 'tutorhelper_pro_email_terms_update';
	const GRACE_SECONDS         = 14 * DAY_IN_SECONDS;

	/** Register public and tutor-dashboard hooks. */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_style' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_modal' ) );
		add_action( 'admin_post_' . self::ACCEPT_ACTION, array( __CLASS__, 'handle_accept' ) );
		add_action( 'admin_post_' . self::DISMISS_ACTION, array( __CLASS__, 'handle_dismiss' ) );
		add_action( 'admin_post_' . self::EMAIL_ACTION, array( __CLASS__, 'handle_email' ) );
		add_filter( 'tutorhelper_dashboard_widgets', array( __CLASS__, 'add_dashboard_widget' ), 40, 2 );
	}

	/** Current policy version, updateable without a database migration. */
	public static function get_current_version() {
		$version = sanitize_text_field(
			get_option( self::OPTION_VERSION, '2026-09-21' )
		);

		return (string) apply_filters(
			'tutorhelper_pro_terms_privacy_version',
			$version
		);
	}

	/** Whether a user needs to agree again. */
	public static function requires_acceptance( $user_id ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return false;
		}

		$accepted_at = (string) get_user_meta( $user_id, self::META_ACCEPTED_AT, true );
		if ( '' === $accepted_at ) {
			$privacy_at = (string) get_user_meta( $user_id, 'tutorhelper_privacy_acknowledged_at', true );
			$terms_at   = (string) get_user_meta( $user_id, 'tutorhelper_terms_agreed_at', true );
			$accepted_at = $privacy_at && $terms_at ? min( $privacy_at, $terms_at ) : '';
		}

		$accepted_timestamp = $accepted_at ? strtotime( $accepted_at . ' UTC' ) : false;
		$is_older_than_year = ! $accepted_timestamp || $accepted_timestamp < ( time() - YEAR_IN_SECONDS );
		$stored_version     = (string) get_user_meta( $user_id, self::META_ACCEPTED_VERSION, true );
		$version_changed    = '' !== $stored_version && self::get_current_version() !== $stored_version;

		return $is_older_than_year || $version_changed;
	}

	/** Whether the grace period has expired. */
	public static function is_blocking( $user_id ) {
		$dismissed_at = (string) get_user_meta(
			absint( $user_id ),
			self::META_FIRST_DISMISSED,
			true
		);
		$dismissed_timestamp = $dismissed_at ? strtotime( $dismissed_at . ' UTC' ) : false;

		return $dismissed_timestamp && time() >= ( $dismissed_timestamp + self::GRACE_SECONDS );
	}

	/** Load modal styling only when the signed-in user needs it. */
	public static function enqueue_style() {
		if ( ! self::should_render() ) {
			return;
		}

		$path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-terms-update.css';
		wp_enqueue_style(
			'tutorhelper-pro-terms-update',
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-terms-update.css',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_PRO_VERSION
		);
	}

	/** Render the agreement modal above TutorHelper dashboards. */
	public static function render_modal() {
		if ( ! self::should_render() ) {
			return;
		}

		$user_id     = get_current_user_id();
		$is_blocking = self::is_blocking( $user_id );
		$privacy_url = TutorHelper_Settings::get_privacy_url();
		$terms_url   = (string) apply_filters(
			'tutorhelper_registration_terms_url',
			TutorHelper_Settings::get_terms_url()
		);
		?>
		<div class="tutorhelper-pro-terms-gate<?php echo $is_blocking ? ' is-blocking' : ''; ?>" role="dialog" aria-modal="true" aria-labelledby="tutorhelper-pro-terms-title">
			<div class="tutorhelper-pro-terms-gate__dialog">
				<h2 id="tutorhelper-pro-terms-title"><?php esc_html_e( 'Please review our privacy notice and terms', 'tutorhelper-pro' ); ?></h2>
				<p><?php esc_html_e( 'We ask account holders to confirm these details at least once each year.', 'tutorhelper-pro' ); ?></p>
				<p class="tutorhelper-pro-terms-gate__links">
					<?php if ( $privacy_url ) : ?><a href="<?php echo esc_url( $privacy_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View privacy policy', 'tutorhelper-pro' ); ?></a><?php endif; ?>
					<?php if ( $terms_url ) : ?><a href="<?php echo esc_url( $terms_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View terms and conditions', 'tutorhelper-pro' ); ?></a><?php endif; ?>
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::ACCEPT_ACTION ); ?>" />
					<?php wp_nonce_field( self::ACCEPT_ACTION, 'tutorhelper_terms_nonce' ); ?>
					<label><input type="checkbox" name="privacy_acknowledged" value="1" required /> <?php esc_html_e( 'I have reviewed the privacy policy.', 'tutorhelper-pro' ); ?></label>
					<label><input type="checkbox" name="terms_agreed" value="1" required /> <?php esc_html_e( 'I agree to the current terms and conditions.', 'tutorhelper-pro' ); ?></label>
					<button type="submit"><?php esc_html_e( 'Save agreement', 'tutorhelper-pro' ); ?></button>
				</form>
				<?php if ( ! $is_blocking ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-pro-terms-gate__dismiss">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::DISMISS_ACTION ); ?>" />
						<?php wp_nonce_field( self::DISMISS_ACTION, 'tutorhelper_terms_nonce' ); ?>
						<button type="submit"><?php esc_html_e( 'Remind me later', 'tutorhelper-pro' ); ?></button>
					</form>
					<p class="tutorhelper-pro-terms-gate__grace"><?php esc_html_e( 'You can defer this request for 14 days from the first reminder. After that, agreement is required to continue.', 'tutorhelper-pro' ); ?></p>
				<?php else : ?>
					<p class="tutorhelper-pro-terms-gate__required"><?php esc_html_e( 'The 14-day review period has ended. Please record your agreement to continue.', 'tutorhelper-pro' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/** Record policy agreement. */
	public static function handle_accept() {
		self::verify_user_action( self::ACCEPT_ACTION );

		$privacy = isset( $_POST['privacy_acknowledged'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['privacy_acknowledged'] ) );
		$terms   = isset( $_POST['terms_agreed'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['terms_agreed'] ) );
		if ( ! $privacy || ! $terms ) {
			self::redirect_back();
		}

		$user_id = get_current_user_id();
		$now     = current_time( 'mysql', true );
		update_user_meta( $user_id, self::META_ACCEPTED_AT, $now );
		update_user_meta( $user_id, self::META_ACCEPTED_VERSION, self::get_current_version() );
		update_user_meta( $user_id, 'tutorhelper_privacy_acknowledged_at', $now );
		update_user_meta( $user_id, 'tutorhelper_terms_agreed_at', $now );
		delete_user_meta( $user_id, self::META_FIRST_DISMISSED );
		delete_user_meta( $user_id, self::META_LAST_DISMISSED );
		self::redirect_back();
	}

	/** Start the grace period on the first dismissal. */
	public static function handle_dismiss() {
		self::verify_user_action( self::DISMISS_ACTION );
		$user_id = get_current_user_id();
		if ( ! self::is_blocking( $user_id ) ) {
			$now = current_time( 'mysql', true );
			if ( ! get_user_meta( $user_id, self::META_FIRST_DISMISSED, true ) ) {
				update_user_meta( $user_id, self::META_FIRST_DISMISSED, $now );
			}
			update_user_meta( $user_id, self::META_LAST_DISMISSED, $now );
		}
		self::redirect_back();
	}

	/** Add the tutor dashboard Terms Update card. */
	public static function add_dashboard_widget( $widgets, $context ) {
		unset( $context );
		$count = count( self::get_outdated_users() );
		$widgets['terms_update'] = array(
			'label'       => __( 'Terms Update', 'tutorhelper-pro' ),
			'value'       => number_format_i18n( $count ),
			'description' => __( 'Accounts without an agreement recorded in the past year', 'tutorhelper-pro' ),
			'icon'        => 'privacy',
			'tone'        => $count ? 'orange' : 'green',
			'section'     => 'engagement',
			'order'       => 80,
			'panel_callback' => array( __CLASS__, 'render_dashboard_panel' ),
			'panel_args' => array(),
		);
		return $widgets;
	}

	/** Render the review list and protected bulk-email action. */
	public static function render_dashboard_panel() {
		$users = self::get_outdated_users();
		?>
		<section class="tutorhelper-pro-terms-update-panel">
			<h2><?php esc_html_e( 'Terms and privacy review required', 'tutorhelper-pro' ); ?></h2>
			<p><?php esc_html_e( 'These account holders do not have an agreement recorded within the past year.', 'tutorhelper-pro' ); ?></p>
			<?php if ( $users ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-pro-terms-update-panel__form">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::EMAIL_ACTION ); ?>" />
					<?php wp_nonce_field( self::EMAIL_ACTION, 'tutorhelper_terms_email_nonce' ); ?>
					<div class="tutorhelper-pro-terms-update-panel__accounts">
						<?php foreach ( $users as $user ) : ?>
							<label>
								<input type="checkbox" name="user_ids[]" value="<?php echo esc_attr( $user->ID ); ?>" />
								<span><strong><?php echo esc_html( $user->display_name ); ?></strong><br /><?php echo esc_html( $user->user_email ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
					<button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary"><?php esc_html_e( 'Email selected accounts', 'tutorhelper-pro' ); ?></button>
				</form>
			<?php endif; ?>
		</section>
		<?php
	}

	/** Send the templated annual-review reminder. */
	public static function handle_email() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to send these reminders.', 'tutorhelper-pro' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::EMAIL_ACTION, 'tutorhelper_terms_email_nonce' );

		$selected_ids = isset( $_POST['user_ids'] ) && is_array( $_POST['user_ids'] )
			? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['user_ids'] ) ) ) ) )
			: array();
		$outdated = self::get_outdated_users();

		foreach ( $outdated as $user ) {
			if ( ! in_array( absint( $user->ID ), $selected_ids, true ) ) {
				continue;
			}
			$first_name = $user->first_name ? $user->first_name : $user->display_name;
			$subject = __( 'Please review your account details and policies', 'tutorhelper-pro' );
			$message = sprintf(
				/* translators: 1: account holder first name, 2: site name, 3: dashboard URL. */
				__( "Hello %1\$s,\n\nPlease log in to %2\$s to review your account details, privacy information and current terms.\n\n%3\$s", 'tutorhelper-pro' ),
				$first_name,
				wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
				TutorHelper_Settings::get_student_dashboard_url()
			);
			wp_mail( $user->user_email, $subject, $message );
		}

		wp_safe_redirect( add_query_arg( 'terms_update', '1', admin_url( 'admin.php?page=' . TutorHelper_Admin::MENU_SLUG ) ) );
		exit;
	}

	/** Return relevant student and parent accounts that need review. */
	private static function get_outdated_users() {
		$roles = array( TutorHelper_Students::STUDENT_ROLE, TutorHelper_Students::PARENT_ROLE );
		$users = get_users(
			array(
				'role__in' => $roles,
				'orderby'  => 'display_name',
				'order'    => 'ASC',
			)
		);

		return array_values(
			array_filter(
				$users,
				static function ( $user ) {
					return $user instanceof WP_User && self::requires_acceptance( $user->ID );
				}
			)
		);
	}

	/** Whether the current request should show the modal. */
	private static function should_render() {
		$user_id = get_current_user_id();
		if ( is_admin() || ! $user_id || current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			return false;
		}

		if ( ! self::requires_acceptance( $user_id ) ) {
			return false;
		}

		$privacy_page_id =
			absint(
				get_option(
					TutorHelper_Settings::OPTION_PRIVACY_PAGE,
					0
				)
			);

		$terms_page_id =
			absint(
				get_option(
					TutorHelper_Settings::OPTION_TERMS_PAGE,
					0
				)
			);

		if (
			( $privacy_page_id && is_page( $privacy_page_id ) )
			|| ( $terms_page_id && is_page( $terms_page_id ) )
		) {
			return false;
		}

		$last_dismissed = (string) get_user_meta(
			$user_id,
			self::META_LAST_DISMISSED,
			true
		);
		$last_dismissed_timestamp = $last_dismissed
			? strtotime( $last_dismissed . ' UTC' )
			: false;
		$is_snoozed = $last_dismissed_timestamp
			&& time() < ( $last_dismissed_timestamp + DAY_IN_SECONDS );

		if ( $is_snoozed && ! self::is_blocking( $user_id ) ) {
			return false;
		}

		return (bool) apply_filters(
			'tutorhelper_pro_terms_gate_should_render',
			true,
			$user_id
		);
	}

	/** Verify a signed-in user action and its nonce. */
	private static function verify_user_action( $action ) {
		if ( ! get_current_user_id() || ! current_user_can( 'read' ) ) {
			wp_die( esc_html__( 'You must be logged in to update your agreement.', 'tutorhelper-pro' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action, 'tutorhelper_terms_nonce' );
	}

	/** Redirect back to the originating page. */
	private static function redirect_back() {
		$url = wp_get_referer();
		wp_safe_redirect( $url ? $url : home_url( '/' ) );
		exit;
	}
}
