<?php
/**
 * TutorHelper Pro registration emails.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and sends Student Registration emails.
 */
final class TutorHelper_Pro_Registration_Emails {

	/**
	 * Student registration received template.
	 *
	 * @var string
	 */
	const STUDENT_REGISTRATION_RECEIVED =
		'tutorhelper_pro_registration_received';


	/**
	 * Tutor new-registration notification template.
	 *
	 * @var string
	 */
	const TUTOR_NEW_REGISTRATION =
		'tutorhelper_pro_new_registration';


	/**
	 * Student registration approved template.
	 *
	 * @var string
	 */
	const STUDENT_REGISTRATION_APPROVED =
		'tutorhelper_pro_registration_approved';


	/**
	 * Student waiting-list confirmation template.
	 *
	 * @var string
	 */
	const STUDENT_REGISTRATION_WAITLISTED =
		'tutorhelper_pro_registration_waitlisted';


	/**
	 * Register templates and email triggers.
	 *
	 * @return void
	 */
	public static function init() {

		self::register_templates();

		add_action(
			'tutorhelper_pro_registration_submitted',
			array(
				__CLASS__,
				'handle_registration_submitted',
			),
			10,
			1
		);

		add_action(
			'tutorhelper_pro_registration_approved',
			array(
				__CLASS__,
				'handle_registration_approved',
			),
			10,
			2
		);

		add_action(
			'tutorhelper_pro_registration_waitlisted',
			array(
				__CLASS__,
				'handle_registration_waitlisted',
			),
			10,
			2
		);
	}


	/**
	 * Register automatic registration templates.
	 *
	 * @return void
	 */
	private static function register_templates() {

		$student_placeholders =
			array(
				'{student_name}',
				'{student_first_name}',
				'{student_email}',
				'{tutor_name}',
				'{site_name}',
				'{registration_type}',
				'{registration_date}',
				'{login_url}',
			);

		$tutor_placeholders =
			array(
				'{student_name}',
				'{student_first_name}',
				'{student_email}',
				'{tutor_name}',
				'{site_name}',
				'{registration_type}',
				'{registration_date}',
				'{registration_review_url}',
			);


		TutorHelper_Email_Templates::register(
			self::STUDENT_REGISTRATION_RECEIVED,
			array(
				'module' =>
					'registrations',

				'label' =>
					__(
						'Registration received',
						'tutorhelper-pro'
					),

				'description' =>
					__(
						'Sent to a student after they submit the registration form.',
						'tutorhelper-pro'
					),

				'heading' =>
					__(
						'Registration received',
						'tutorhelper-pro'
					),

				'recipient' =>
					'student',

				'enabled' =>
					true,

				'subject' =>
					__(
						'We have received your registration',
						'tutorhelper-pro'
					),

				'body' =>
					__(
						'<p>Hello {student_first_name},</p>
						<p>Thank you for registering with {site_name}.</p>
						<p>Your registration has been received and is waiting for your tutor to review it.</p>
						<p>You will receive another email once your tutor has reviewed your registration.</p>
						<p>You can set up or access your account here: <a href="{login_url}">{login_url}</a></p>',
						'tutorhelper-pro'
					),

				'placeholders' =>
					$student_placeholders,
			)
		);


		TutorHelper_Email_Templates::register(
			self::TUTOR_NEW_REGISTRATION,
			array(
				'module' =>
					'registrations',

				'label' =>
					__(
						'New student registration',
						'tutorhelper-pro'
					),

				'description' =>
					__(
						'Sent to the tutor when a new student registration is received.',
						'tutorhelper-pro'
					),

				'heading' =>
					__(
						'New student registration',
						'tutorhelper-pro'
					),

				'recipient' =>
					'tutor',

				'enabled' =>
					true,

				'subject' =>
					__(
						'New student registration: {student_name}',
						'tutorhelper-pro'
					),

				'body' =>
					__(
						'<p>A new student registration has been received.</p>
						<p><strong>Student:</strong> {student_name}<br />
						<strong>Email:</strong> {student_email}<br />
						<strong>Registration type:</strong> {registration_type}<br />
						<strong>Submitted:</strong> {registration_date}</p>
						<p>Review the registration securely in TutorHelper:</p>
						<p><a href="{registration_review_url}">Review registration</a></p>',
						'tutorhelper-pro'
					),

				'placeholders' =>
					$tutor_placeholders,
			)
		);


		TutorHelper_Email_Templates::register(
			self::STUDENT_REGISTRATION_APPROVED,
			array(
				'module' =>
					'registrations',

				'label' =>
					__(
						'Registration approved',
						'tutorhelper-pro'
					),

				'description' =>
					__(
						'Sent to a student when their registration is approved.',
						'tutorhelper-pro'
					),

				'heading' =>
					__(
						'Registration approved',
						'tutorhelper-pro'
					),

				'recipient' =>
					'student',

				'enabled' =>
					true,

				'subject' =>
					__(
						'Your registration has been approved',
						'tutorhelper-pro'
					),

				'body' =>
					__(
						'<p>Hello {student_first_name},</p>
						<p>Your registration with {site_name} has now been approved.</p>
						<p>You can now sign in and book lessons using your student account.</p>
						<p><a href="{login_url}">Sign in to your account</a></p>',
						'tutorhelper-pro'
					),

				'placeholders' =>
					$student_placeholders,
			)
		);


		TutorHelper_Email_Templates::register(
			self::STUDENT_REGISTRATION_WAITLISTED,
			array(
				'module' =>
					'registrations',

				'label' =>
					__(
						'Added to waiting list',
						'tutorhelper-pro'
					),

				'description' =>
					__(
						'Sent to a student when the tutor adds their registration to the waiting list.',
						'tutorhelper-pro'
					),

				'heading' =>
					__(
						'You are on the waiting list',
						'tutorhelper-pro'
					),

				'recipient' =>
					'student',

				'enabled' =>
					true,

				'subject' =>
					__(
						'You have been added to the waiting list',
						'tutorhelper-pro'
					),

				'body' =>
					__(
						'<p>Hello {student_first_name},</p>
						<p>Your registration with {site_name} has been reviewed and you have been added to the waiting list.</p>
						<p>Your tutor will contact you when a suitable place becomes available. Lesson booking will remain unavailable until your account is made Live.</p>
						<p>You can still access your account here: <a href="{login_url}">{login_url}</a></p>',
						'tutorhelper-pro'
					),

				'placeholders' =>
					$student_placeholders,
			)
		);
	}


    /**
	 * Build safe registration email context.
	 *
	 * No onboarding answers or sensitive account data
	 * are included.
	 *
	 * @param int $student_user_id Student user ID.
	 *
	 * @return array|WP_Error
	 */
	private static function build_context(
		$student_user_id
	) {

		$student_user_id =
			absint(
				$student_user_id
			);

		$student =
			get_userdata(
				$student_user_id
			);

		if (
			! $student instanceof WP_User
		) {
			return new WP_Error(
				'tutorhelper_registration_email_student_missing',
				__(
					'The student account could not be found.',
					'tutorhelper-pro'
				)
			);
		}


		$registration_type =
			sanitize_key(
				get_user_meta(
					$student_user_id,
					'tutorhelper_registration_type',
					true
				)
			);

		$submitted_at =
			get_user_meta(
				$student_user_id,
				'tutorhelper_registration_submitted_at',
				true
			);


		$registration_type_label =
			'waiting_list'
			=== $registration_type
				? __(
					'Waiting list',
					'tutorhelper-pro'
				)
				: __(
					'Student registration',
					'tutorhelper-pro'
				);


		$registration_date = '';

		if ( $submitted_at ) {

			$timestamp =
				strtotime(
					$submitted_at
					. ' UTC'
				);

			if ( $timestamp ) {

				$registration_date =
					wp_date(
						get_option(
							'date_format'
						)
						. ' '
						. get_option(
							'time_format'
						),
						$timestamp
					);
			}
		}


		$tutor_name =
			TutorHelper_Email_Settings::get(
				'sender_name'
			);

		$tutor_email =
			sanitize_email(
				TutorHelper_Email_Settings::get(
					'contact_email'
				)
			);


		$review_url =
			add_query_arg(
				array(
					'page' =>
						TutorHelper_Booking_Hub::
							PAGE_SLUG,

					'tab' =>
						TutorHelper_Students_Admin::
							TAB_KEY,

					'student_view' =>
						TutorHelper_Pro_Registration_Admin::
							VIEW_KEY,

					'registration_id' =>
						$student_user_id,
				),
				admin_url(
					'admin.php'
				)
			);


		return array(
			'student' =>
				$student,

			'tutor_email' =>
				$tutor_email,

			'placeholders' =>
				array(
					'{student_name}' =>
						$student->display_name,

					'{student_first_name}' =>
						$student->first_name,

					'{student_email}' =>
						$student->user_email,

					'{tutor_name}' =>
						$tutor_name,

					'{site_name}' =>
						wp_specialchars_decode(
							get_bloginfo(
								'name'
							),
							ENT_QUOTES
						),

					'{registration_type}' =>
						$registration_type_label,

					'{registration_date}' =>
						$registration_date,

					'{login_url}' =>
						TutorHelper_Settings::get_login_url(),

					'{registration_review_url}' =>
						$review_url,
				),
		);
	}



    /**
	 * Send emails after a successful registration.
	 *
	 * @param int $student_user_id Student user ID.
	 *
	 * @return void
	 */
	public static function handle_registration_submitted(
		$student_user_id
	) {

		$context =
			self::build_context(
				$student_user_id
			);

		if ( is_wp_error( $context ) ) {
			return;
		}


		self::send_student_email(
			self::STUDENT_REGISTRATION_RECEIVED,
			$student_user_id,
			$context,
			'registration_received'
		);


		self::send_tutor_email(
			self::TUTOR_NEW_REGISTRATION,
			$student_user_id,
			$context,
			'new_registration'
		);
	}



    /**
	 * Send the student approval email.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $reviewed_by     Reviewing user ID.
	 *
	 * @return void
	 */
	public static function handle_registration_approved(
		$student_user_id,
		$reviewed_by
	) {

		unset( $reviewed_by );

		$context =
			self::build_context(
				$student_user_id
			);

		if ( is_wp_error( $context ) ) {
			return;
		}

		self::send_student_email(
			self::STUDENT_REGISTRATION_APPROVED,
			$student_user_id,
			$context,
			'registration_approved'
		);
	}


    /**
	 * Send the waiting-list confirmation email.
	 *
	 * @param int $student_user_id Student user ID.
	 * @param int $reviewed_by     Reviewing user ID.
	 * @return void
	 */
	public static function handle_registration_waitlisted(
		$student_user_id,
		$reviewed_by
	) {

		unset( $reviewed_by );

		$context = self::build_context( $student_user_id );

		if ( is_wp_error( $context ) ) {
			return;
		}

		self::send_student_email(
			self::STUDENT_REGISTRATION_WAITLISTED,
			$student_user_id,
			$context,
			'registration_waitlisted'
		);
	}


    /**
	 * Send a registration email to a student.
	 *
	 * @param string $template_key   Template key.
	 * @param int    $student_user_id Student ID.
	 * @param array  $context        Prepared context.
	 * @param string $email_type     Delivery type.
	 *
	 * @return void
	 */
	private static function send_student_email(
		$template_key,
		$student_user_id,
		$context,
		$email_type
	) {

		if (
			! TutorHelper_Email_Templates::
				is_enabled(
					$template_key
				)
		) {
			return;
		}

		$student =
			$context['student'];

		TutorHelper_Email_Sender::send(
			$template_key,
			$student->user_email,
			$context[
				'placeholders'
			],
			array(
				'reply_to_email' =>
					$context[
						'tutor_email'
					],

				'reply_to_name' =>
					$context[
						'placeholders'
					][
						'{tutor_name}'
					],

				'context' =>
					array(
						'student_user_id' =>
							absint(
								$student_user_id
							),

						'recipient_type' =>
							'student',

						'email_type' =>
							sanitize_key(
								$email_type
							),
					),
			)
		);
	}


	/**
	 * Send a registration notification to the tutor.
	 *
	 * @param string $template_key   Template key.
	 * @param int    $student_user_id Student ID.
	 * @param array  $context        Prepared context.
	 * @param string $email_type     Delivery type.
	 *
	 * @return void
	 */
	private static function send_tutor_email(
		$template_key,
		$student_user_id,
		$context,
		$email_type
	) {

		if (
			! TutorHelper_Email_Templates::
				is_enabled(
					$template_key
				)
		) {
			return;
		}

		if (
			empty(
				$context[
					'tutor_email'
				]
			)
			|| ! is_email(
				$context[
					'tutor_email'
				]
			)
		) {
			return;
		}


		TutorHelper_Email_Sender::send(
			$template_key,
			$context[
				'tutor_email'
			],
			$context[
				'placeholders'
			],
			array(
				'reply_to_email' =>
					$context[
						'student'
					]->user_email,

				'reply_to_name' =>
					$context[
						'student'
					]->display_name,

				'context' =>
					array(
						'student_user_id' =>
							absint(
								$student_user_id
							),

						'recipient_type' =>
							'tutor',

						'email_type' =>
							sanitize_key(
								$email_type
							),
					),
			)
		);
	}
}
