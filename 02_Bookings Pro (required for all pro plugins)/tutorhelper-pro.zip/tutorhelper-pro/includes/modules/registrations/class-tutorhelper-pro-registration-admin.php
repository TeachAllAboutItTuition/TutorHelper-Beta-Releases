<?php
/**
 * TutorHelper Pro registration admin interface.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds Student Registration management to the Core Students workspace.
 */
final class TutorHelper_Pro_Registration_Admin {

	/**
	 * Student workspace view key.
	 *
	 * @var string
	 */
	const VIEW_KEY = 'registrations';

	/**
	 * Save-question admin action.
	 *
	 * @var string
	 */
	const SAVE_QUESTION_ACTION =
		'tutorhelper_pro_save_onboarding_question';

	/**
	 * Archive/restore question action.
	 *
	 * @var string
	 */
	const STATUS_QUESTION_ACTION =
		'tutorhelper_pro_change_onboarding_question_status';

	/**
	 * AJAX question reorder action.
	 *
	 * @var string
	 */
	const REORDER_ACTION =
		'tutorhelper_pro_reorder_onboarding_questions';

	/**
	 * Registration admin script handle.
	 *
	 * @var string
	 */
	const SCRIPT_HANDLE =
		'tutorhelper-pro-registration-admin';

	/**
	 * Shared Pro admin stylesheet handle.
	 *
	 * @var string
	 */
	const STYLE_HANDLE =
		'tutorhelper-pro-admin';

    /**
     * Registration status save action.
     *
     * @var string
     */
    const SAVE_STATUS_ACTION =
        'tutorhelper_pro_save_registration_status';

    /**
     * Approve a new registration.
     *
     * @var string
     */
    const APPROVE_REGISTRATION_ACTION =
        'tutorhelper_pro_approve_registration';

    /**
     * Add a new registration to the waiting list.
     *
     * @var string
     */
    const WAITLIST_REGISTRATION_ACTION =
        'tutorhelper_pro_waitlist_registration';

    /**
     * Promote a waiting-list student to Live.
     *
     * @var string
     */
    const PROMOTE_REGISTRATION_ACTION =
        'tutorhelper_pro_promote_registration';

    /** Registration workflow statuses. */
    const STATUS_NEW = 'new';
    const STATUS_WAITING_LIST = 'waiting_list';
    const STATUS_APPROVED = 'approved';

    /** Registration decision values. */
    const DECISION_LIVE = 'live';
    const DECISION_WAITING_LIST = 'waiting_list';


	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'tutorhelper_students_registration_sidebar',
			array(
				__CLASS__,
				'render_registration_preview',
			)
		);

		add_filter(
			'tutorhelper_students_has_custom_workspace',
			array(
				__CLASS__,
				'has_custom_workspace',
			),
			10,
			2
		);

		add_action(
			'tutorhelper_students_render_custom_workspace',
			array(
				__CLASS__,
				'render_custom_workspace',
			)
		);

		add_action(
			'admin_post_'
				. self::SAVE_QUESTION_ACTION,
			array(
				__CLASS__,
				'handle_save_question',
			)
		);

		add_action(
			'admin_post_'
				. self::STATUS_QUESTION_ACTION,
			array(
				__CLASS__,
				'handle_question_status',
			)
		);

		add_action(
			'wp_ajax_'
				. self::REORDER_ACTION,
			array(
				__CLASS__,
				'handle_reorder',
			)
		);

		add_action(
			'admin_enqueue_scripts',
			array(
				__CLASS__,
				'enqueue_assets',
			)
		);

        add_action(
            'admin_post_'
                . self::SAVE_STATUS_ACTION,
            array(
                __CLASS__,
                'handle_save_registration_status',
            )
        );

        add_action(
            'admin_post_'
                . self::APPROVE_REGISTRATION_ACTION,
            array(
                __CLASS__,
                'handle_approve_registration',
            )
        );

        add_action(
            'admin_post_'
                . self::WAITLIST_REGISTRATION_ACTION,
            array(
                __CLASS__,
                'handle_waitlist_registration',
            )
        );

        add_action(
            'admin_post_'
                . self::PROMOTE_REGISTRATION_ACTION,
            array(
                __CLASS__,
                'handle_promote_registration',
            )
        );

        add_action(
            'tutorhelper_students_detail_notes_communication',
            array(
                __CLASS__,
                'render_student_registration_history',
            )
        );

        add_filter(
            'tutorhelper_booking_hub_summary_cards',
            array(
                __CLASS__,
                'populate_booking_hub_summary',
            )
        );

	}


	/**
	 * Determine whether Pro should replace the normal
	 * Students workspace.
	 *
	 * @param bool  $has_custom_workspace Existing result.
	 * @param array $active_tab           Current tab.
	 *
	 * @return bool
	 */
	public static function has_custom_workspace(
		$has_custom_workspace,
		$active_tab
	) {

		unset( $active_tab );

		if ( $has_custom_workspace ) {
			return true;
		}

		return self::is_registration_view();
	}


	/**
	 * Determine whether Registration Settings is open.
	 *
	 * @return bool
	 */
	private static function is_registration_view() {

		$view =
			isset(
				$_GET['student_view'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation value.
			)
				? sanitize_key(
					wp_unslash(
						$_GET['student_view'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation value.
					)
				)
				: '';

		return self::VIEW_KEY === $view;
	}


	/**
	 * Determine whether the current page is the Students tab.
	 *
	 * @return bool
	 */
	private static function is_students_page() {

		$page =
			isset(
				$_GET['page'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation value.
			)
				? sanitize_key(
					wp_unslash(
						$_GET['page'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation value.
					)
				)
				: '';

		$tab =
			isset(
				$_GET['tab'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation value.
			)
				? sanitize_key(
					wp_unslash(
						$_GET['tab'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation value.
					)
				)
				: '';

		return
			TutorHelper_Booking_Hub::PAGE_SLUG
				=== $page
			&& TutorHelper_Students_Admin::TAB_KEY
				=== $tab;
	}


	/**
	 * Enqueue registration admin assets.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {

		if (
			! self::is_students_page()
			|| ! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		$style_path =
			TUTORHELPER_PRO_PATH
			. 'assets/css/'
			. 'tutorhelper-pro-admin.css';

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL
				. 'assets/css/'
				. 'tutorhelper-pro-admin.css',
			array(),
			file_exists( $style_path )
				? (string) filemtime(
					$style_path
				)
				: TUTORHELPER_PRO_VERSION
		);

		if ( ! self::is_registration_view() ) {
			return;
		}

		$script_path =
			TUTORHELPER_PRO_PATH
			. 'assets/js/'
			. 'tutorhelper-pro-registration-admin.js';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL
				. 'assets/js/'
				. 'tutorhelper-pro-registration-admin.js',
			array(
				'jquery',
				'jquery-ui-sortable',
			),
			file_exists( $script_path )
				? (string) filemtime(
					$script_path
				)
				: TUTORHELPER_PRO_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperProRegistrations',
			array(
				'ajaxUrl' =>
					admin_url(
						'admin-ajax.php'
					),

				'reorderAction' =>
					self::REORDER_ACTION,

				'reorderNonce' =>
					wp_create_nonce(
						self::REORDER_ACTION
					),

				'saving' =>
					__(
						'Saving question order...',
						'tutorhelper-pro'
					),

				'failed' =>
					__(
						'The question order could not be saved.',
						'tutorhelper-pro'
					),
			)
		);
	}


	/**
	 * Return Registration Settings URL.
	 *
	 * @param array $args Additional query arguments.
	 *
	 * @return string
	 */
	private static function get_registration_url(
		$args = array()
	) {

		$base_args = array(
			'page' =>
				TutorHelper_Booking_Hub::
					PAGE_SLUG,

			'tab' =>
				TutorHelper_Students_Admin::
					TAB_KEY,

			'student_view' =>
				self::VIEW_KEY,
		);

		return add_query_arg(
			array_merge(
				$base_args,
				is_array( $args )
					? $args
					: array()
			),
			admin_url(
				'admin.php'
			)
		);
	}


	/**
	 * Return normal Students workspace URL.
	 *
	 * @param array $args Additional query arguments.
	 *
	 * @return string
	 */
	private static function get_students_url(
		$args = array()
	) {

		$base_args = array(
			'page' =>
				TutorHelper_Booking_Hub::
					PAGE_SLUG,

			'tab' =>
				TutorHelper_Students_Admin::
					TAB_KEY,
		);

		return add_query_arg(
			array_merge(
				$base_args,
				is_array( $args )
					? $args
					: array()
			),
			admin_url(
				'admin.php'
			)
		);
	}


	/**
	 * Retrieve newly registered students.
	 *
	 * @param int $limit Maximum number of records.
	 *
	 * @return array
	 */
	private static function get_new_registrations(
		$limit = 3
	) {
		return self::get_registrations_by_status(
			self::STATUS_NEW,
			$limit
		);
	}


	/**
	 * Retrieve students on the waiting list.
	 *
	 * @param int $limit Maximum number of records.
	 * @return array
	 */
	private static function get_waiting_list_registrations(
		$limit = 3
	) {
		return self::get_registrations_by_status(
			self::STATUS_WAITING_LIST,
			$limit
		);
	}


	/**
	 * Retrieve registered students in one workflow status.
	 *
	 * @param string $status Registration workflow status.
	 * @param int    $limit  Maximum number of records.
	 * @return array
	 */
	private static function get_registrations_by_status(
		$status,
		$limit = 3
	) {
		$status = sanitize_key( $status );

		return get_users(
			array(
				'role' =>
					TutorHelper_Students::
						STUDENT_ROLE,

				'meta_query' => array(
					'relation' =>
						'AND',

					array(
						'key' =>
							'tutorhelper_registration_source',

						'value' =>
							'student_registration',

						'compare' =>
							'=',
					),

					array(
						'key' =>
							'tutorhelper_registration_status',

						'value' =>
							$status,

						'compare' =>
							'=',
					),
				),

				'orderby' =>
					'registered',

				'order' =>
					'DESC',

				'number' =>
					max(
						1,
						absint(
							$limit
						)
					),
			)
		);
	}


	/**
	 * Count registrations awaiting review.
	 *
	 * @return int
	 */
	private static function get_new_registration_count() {
		return self::get_registration_count_by_status(
			self::STATUS_NEW
		);
	}


	/**
	 * Count students currently on the waiting list.
	 *
	 * @return int
	 */
	private static function get_waiting_list_count() {
		return self::get_registration_count_by_status(
			self::STATUS_WAITING_LIST
		);
	}


	/**
	 * Count registrations in one workflow status.
	 *
	 * @param string $status Registration workflow status.
	 * @return int
	 */
	private static function get_registration_count_by_status(
		$status
	) {
		$status = sanitize_key( $status );

		$query =
			new WP_User_Query(
				array(
					'role' =>
						TutorHelper_Students::
							STUDENT_ROLE,

					'meta_query' => array(
						'relation' =>
							'AND',

						array(
							'key' =>
								'tutorhelper_registration_source',

							'value' =>
								'student_registration',

							'compare' =>
								'=',
						),

						array(
							'key' =>
								'tutorhelper_registration_status',

							'value' =>
								$status,

							'compare' =>
								'=',
						),
					),

					'fields' =>
						'ID',
				)
			);

		return absint(
			$query->get_total()
		);
	}


	/**
	 * Render registration preview in Students sidebar.
	 *
	 * @return void
	 */
	public static function render_registration_preview() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		$registrations =
			self::get_new_registrations(
				3
			);

		$total =
			self::get_new_registration_count();

		?>
		<section
			class="
				tutorhelper-main-section
				tutorhelper-pro-registration-preview
			"
		>
			<header
				class="tutorhelper-main-section__header"
			>
				<div
					class="
						tutorhelper-main-section__header-content
					"
				>
					<h2>
						<?php
						echo esc_html__(
							'New Registrations',
							'tutorhelper-pro'
						);
						?>

						<?php if ( $total > 0 ) : ?>
							<span
								class="
									tutorhelper-pro-registration-count
								"
							>
								<?php
								echo esc_html(
									$total
								);
								?>
							</span>
						<?php endif; ?>
					</h2>

					<p>
						<?php
						echo esc_html__(
							'Review new students and manage your registration form.',
							'tutorhelper-pro'
						);
						?>
					</p>
				</div>
			</header>

			<div
				class="tutorhelper-main-section__body"
			>

				<?php if ( empty( $registrations ) ) : ?>

					<p
						class="
							tutorhelper-pro-registration-preview__empty
						"
					>
						<?php
						echo esc_html__(
							'No new registrations are waiting for review.',
							'tutorhelper-pro'
						);
						?>
					</p>

				<?php else : ?>

					<ul
						class="
							tutorhelper-pro-registration-preview__list
						"
					>
						<?php
						foreach (
							$registrations
							as $student
						) :
							?>
							<li>
                                <span
                                    class="
                                        tutorhelper-pro-registration-preview__student
                                    "
                                >
                                    <strong>
                                        <?php
                                        echo esc_html(
                                            $student->display_name
                                        );
                                        ?>
                                    </strong>

                                    <span
                                        class="
                                            tutorhelper-pro-registration-preview__new
                                        "
                                    >
                                        <?php
                                        echo esc_html__(
                                            'New',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </span>
                                </span>
                            

								<span>
									<?php
									echo esc_html(
										get_date_from_gmt(
											$student->
												user_registered,
											get_option(
												'date_format'
											)
										)
									);
									?>
								</span>
							</li>
						<?php endforeach; ?>
					</ul>

				<?php endif; ?>

				<a
					href="<?php
						echo esc_url(
							self::
								get_registration_url()
						);
					?>"
					class="
						button
						tutorhelper-action-button
					"
				>
					<span
						class="
							dashicons
							dashicons-id
						"
						aria-hidden="true"
					></span>

					<?php
					echo esc_html__(
						'Open Registrations',
						'tutorhelper-pro'
					);
					?>
				</a>

			</div>
		</section>
		<?php

		self::render_waiting_list_preview();
	}


	/**
	 * Render the waiting-list card beneath New Registrations.
	 *
	 * @return void
	 */
	private static function render_waiting_list_preview() {
		$registrations = self::get_waiting_list_registrations( 3 );
		$total = self::get_waiting_list_count();
		?>
		<section class="tutorhelper-main-section tutorhelper-pro-registration-preview tutorhelper-pro-waiting-list-preview">
			<header class="tutorhelper-main-section__header">
				<div class="tutorhelper-main-section__header-content">
					<h2>
						<?php esc_html_e( 'Waiting List', 'tutorhelper-pro' ); ?>
						<?php if ( $total > 0 ) : ?>
							<span class="tutorhelper-pro-registration-count"><?php echo esc_html( $total ); ?></span>
						<?php endif; ?>
					</h2>
					<p><?php esc_html_e( 'Students waiting for a tuition place.', 'tutorhelper-pro' ); ?></p>
				</div>
			</header>
			<div class="tutorhelper-main-section__body">
				<?php if ( empty( $registrations ) ) : ?>
					<p class="tutorhelper-pro-registration-preview__empty"><?php esc_html_e( 'There are no students on the waiting list.', 'tutorhelper-pro' ); ?></p>
				<?php else : ?>
					<ul class="tutorhelper-pro-registration-preview__list">
						<?php foreach ( $registrations as $student ) : ?>
							<li>
								<span class="tutorhelper-pro-registration-preview__student">
									<strong><?php echo esc_html( $student->display_name ); ?></strong>
									<span class="tutorhelper-pro-registration-preview__new tutorhelper-pro-registration-preview__new--waiting"><?php esc_html_e( 'Waiting', 'tutorhelper-pro' ); ?></span>
								</span>
								<span><?php echo esc_html( self::format_registration_decision_date( $student->ID ) ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<a href="<?php echo esc_url( self::get_registration_url() . '#tutorhelper-waiting-list' ); ?>" class="button tutorhelper-action-button">
					<span class="dashicons dashicons-groups" aria-hidden="true"></span>
					<?php esc_html_e( 'Open Waiting List', 'tutorhelper-pro' ); ?>
				</a>
			</div>
		</section>
		<?php
	}


	/**
	 * Render Registration Settings workspace.
	 *
	 * @param array $active_tab Current Students tab.
	 *
	 * @return void
	 */
	public static function render_custom_workspace(
		$active_tab
	) {

		unset( $active_tab );

		if (
			! self::is_registration_view()
			|| ! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

        $registration_id =
            isset(
                $_GET['registration_id'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only registration selection.
            )
                ? absint(
                    $_GET['registration_id'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only registration selection.
                )
                : 0;

		$questions =
			TutorHelper_Pro_Onboarding::
				get_questions(
					false
				);

		$edit_question_id =
			isset(
				$_GET['question_id'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only edit selection.
			)
				? absint(
					$_GET['question_id'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only edit selection.
				)
				: 0;

		$edit_question =
			$edit_question_id
				? TutorHelper_Pro_Onboarding::
					get_question(
						$edit_question_id
					)
				: null;

		?>
		<section
			class="tutorhelper-students-workspace"
		>

			<header
				class="tutorhelper-workspace__header"
			>
				<div>
					<h2>
						<?php
						echo esc_html__(
							'Student Registrations',
							'tutorhelper-pro'
						);
						?>
					</h2>

					<p>
						<?php
						echo esc_html__(
							'Review new registrations and manage the questions shown during student registration.',
							'tutorhelper-pro'
						);
						?>
					</p>
				</div>

				<a
					href="<?php
						echo esc_url(
							self::
								get_students_url()
						);
					?>"
					class="
						button
						tutorhelper-hub-pill-button
					"
				>
					<span
						class="
							dashicons
							dashicons-arrow-left-alt2
						"
						aria-hidden="true"
					></span>

					<?php
					echo esc_html__(
						'Back to Students',
						'tutorhelper-pro'
					);
					?>
				</a>
			</header>

			<?php
			self::render_admin_notice();
			?>

			<div
				class="
					tutorhelper-pro-registration-workspace
				"
			>

				<?php
                if ( $registration_id ) {

                    self::render_registration_review(
                        $registration_id
                    );

                } else {

                    self::render_new_registrations_panel();
                    self::render_waiting_list_panel();
                }

                self::render_registration_status_panel();
				?>

				<div
					class="
						tutorhelper-pro-registration-settings-grid
					"
				>
					<main>
						<?php
						self::render_question_list(
							$questions
						);
						?>
					</main>

					<aside>
						<?php
						self::render_question_form(
							$edit_question
						);
						?>
					</aside>
				</div>

			</div>
		</section>
		<?php
	}


    /**
     * Render one new registration for tutor review.
     *
     * @param int $student_user_id Student WordPress user ID.
     *
     * @return void
     */
    private static function render_registration_review(
        $student_user_id
    ) {

        $student_user_id =
            absint(
                $student_user_id
            );

        $student =
            TutorHelper_Students::
                get_student(
                    $student_user_id
                );

        if ( ! $student ) {
            return;
        }

        $source =
            sanitize_key(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_registration_source',
                    true
                )
            );

        $status =
            sanitize_key(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_registration_status',
                    true
                )
            );

        if (
            'student_registration'
            !== $source
            || ! in_array(
                $status,
                array(
                    self::STATUS_NEW,
                    self::STATUS_WAITING_LIST,
                ),
                true
            )
        ) {
            return;
        }

        $is_waiting = self::STATUS_WAITING_LIST === $status;

        $answers =
            TutorHelper_Pro_Onboarding::
                get_answers_for_student(
                    $student_user_id
                );

        $registration_type =
            sanitize_key(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_registration_type',
                    true
                )
            );

        $marketing =
            1 === absint(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_marketing_opt_in',
                    true
                )
            );

        ?>
        <section
            class="
                tutorhelper-main-section
                tutorhelper-pro-registration-review
            "
        >
            <header
                class="
                    tutorhelper-main-section__header
                "
            >
                <div
                    class="
                        tutorhelper-main-section__header-content
                    "
                >
                    <h2>
                        <?php
                        echo esc_html(
                            $student->display_name
                        );
                        ?>

                        <span
                            class="
                                tutorhelper-pro-registration-preview__new
                                <?php echo esc_attr( $is_waiting ? 'tutorhelper-pro-registration-preview__new--waiting' : '' ); ?>
                            "
                        >
                            <?php
                            echo esc_html(
                                $is_waiting
                                    ? __( 'Waiting', 'tutorhelper-pro' )
                                    : __( 'New', 'tutorhelper-pro' )
                            );
                            ?>
                        </span>
                    </h2>

                    <p>
                        <?php
                        echo esc_html(
                            $is_waiting
                                ? __( 'Review this waiting-list student or make them Live when a place becomes available.', 'tutorhelper-pro' )
                                : __( 'Review the student details, then make them Live or add them to the waiting list.', 'tutorhelper-pro' )
                        );
                        ?>
                    </p>
                </div>
            </header>


            <div
                class="
                    tutorhelper-main-section__body
                    tutorhelper-pro-registration-review__body
                "
            >

                <div
                    class="
                        tutorhelper-pro-registration-review__grid
                    "
                >

                    <div>
                        <strong>
                            <?php
                            echo esc_html__(
                                'Student Name',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <p>
                            <?php
                            echo esc_html(
                                $student->display_name
                            );
                            ?>
                        </p>
                    </div>
                </div>

                <div
                    class="
                        tutorhelper-pro-registration-review__grid
                    "
                >

                    <div>
                        <strong>
                            <?php
                            echo esc_html__(
                                'Email',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <p>
                            <?php
                            echo esc_html(
                                $student->user_email
                            );
                            ?>
                        </p>
                    </div>


                    <div>
                        <strong>
                            <?php
                            echo esc_html__(
                                'Date of birth',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <p>
                            <?php
                            echo esc_html(
                                get_user_meta(
                                    $student_user_id,
                                    TutorHelper_Students::
                                        META_DATE_OF_BIRTH,
                                    true
                                )
                            );
                            ?>
                        </p>
                    </div>


                    <div>
                        <strong>
                            <?php
                            echo esc_html__(
                                'Registration type',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <p>
                            <?php
                            echo esc_html(
                                'waiting_list'
                                === $registration_type
                                    ? __(
                                        'Waiting list',
                                        'tutorhelper-pro'
                                    )
                                    : __(
                                        'Student registration',
                                        'tutorhelper-pro'
                                    )
                            );
                            ?>
                        </p>
                    </div>


                    <div>
                        <strong>
                            <?php
                            echo esc_html__(
                                'Marketing emails',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <p>
                            <?php
                            echo esc_html(
                                $marketing
                                    ? __(
                                        'Opted in',
                                        'tutorhelper-pro'
                                    )
                                    : __(
                                        'Not opted in',
                                        'tutorhelper-pro'
                                    )
                            );
                            ?>
                        </p>
                    </div>

                </div>


                <section
                    class="
                        tutorhelper-pro-registration-review__address
                    "
                >
                    <h3
                        class="
                            tutorhelper-pro-registration-review__section-title
                        "
                    >
                        <?php
                        echo esc_html__(
                            'Address',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h3>

                    <address>
                        <?php
                        $address_parts = array_filter(
                            array(
                                get_user_meta(
                                    $student_user_id,
                                    TutorHelper_Students::
                                        META_ADDRESS_LINE_1,
                                    true
                                ),

                                get_user_meta(
                                    $student_user_id,
                                    TutorHelper_Students::
                                        META_ADDRESS_LINE_2,
                                    true
                                ),

                                get_user_meta(
                                    $student_user_id,
                                    TutorHelper_Students::
                                        META_ADDRESS_CITY,
                                    true
                                ),

                                get_user_meta(
                                    $student_user_id,
                                    TutorHelper_Students::
                                        META_ADDRESS_COUNTY,
                                    true
                                ),

                                get_user_meta(
                                    $student_user_id,
                                    TutorHelper_Students::
                                        META_ADDRESS_POSTCODE,
                                    true
                                ),

                                get_user_meta(
                                    $student_user_id,
                                    TutorHelper_Students::
                                        META_ADDRESS_COUNTRY,
                                    true
                                ),
                            )
                        );

                        foreach (
                            $address_parts
                            as $address_part
                        ) {
                            echo esc_html(
                                $address_part
                            );

                            echo '<br />';
                        }
                        ?>
                    </address>
                </section>


                <section
                    class="
                        tutorhelper-pro-registration-review__answers
                    "
                >
                    <h3
                        class="
                            tutorhelper-pro-registration-review__section-title
                        "
                    >
                        <?php
                        echo esc_html__(
                            'Registration answers',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h3>

                    <?php if ( empty( $answers ) ) : ?>

                        <p>
                            <?php
                            echo esc_html__(
                                'No additional onboarding answers were submitted.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </p>

                    <?php else : ?>

                        <dl>
                            <?php
                            foreach (
                                $answers
                                as $answer
                            ) :
                                ?>
                                <div>
                                    <dt>
                                        <?php
                                        echo esc_html(
                                            $answer->
                                                question_text_snapshot
                                        );
                                        ?>
                                    </dt>

                                    <dd>
                                        <?php
                                        echo esc_html(
                                            $answer->answer
                                        );
                                        ?>
                                    </dd>
                                </div>
                            <?php endforeach; ?>
                        </dl>

                    <?php endif; ?>

                </section>

                


                <div
                    class="
                        tutorhelper-pro-registration-review__actions
                    "
                >
                    <a
                        href="<?php
                            echo esc_url(
                                self::
                                    get_registration_url()
                            );
                        ?>"
                        class="
                            button
                            tutorhelper-admin-button
                        "
                    >
                        <?php
                        echo esc_html__(
                            'Back to Registrations',
                            'tutorhelper-pro'
                        );
                        ?>
                    </a>


                    <div class="tutorhelper-pro-registration-review__decision-actions">
                        <?php if ( ! $is_waiting ) : ?>
                            <?php self::render_registration_action_form(
                                self::WAITLIST_REGISTRATION_ACTION,
                                $student_user_id,
                                __( 'Add to Waiting List', 'tutorhelper-pro' ),
                                false
                            ); ?>
                        <?php endif; ?>

                        <?php self::render_registration_action_form(
                            $is_waiting
                                ? self::PROMOTE_REGISTRATION_ACTION
                                : self::APPROVE_REGISTRATION_ACTION,
                            $student_user_id,
                            __( 'Make Live Student', 'tutorhelper-pro' ),
                            true
                        ); ?>
                    </div>
                </div>

            </div>
        </section>
        <?php
    }


    /**
     * Render one secure registration decision form.
     *
     * @param string $action          Admin-post action.
     * @param int    $student_user_id Student user ID.
     * @param string $label           Button label.
     * @param bool   $primary         Whether to use the primary action style.
     * @return void
     */
    private static function render_registration_action_form(
        $action,
        $student_user_id,
        $label,
        $primary = false
    ) {
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>" />
            <input type="hidden" name="student_id" value="<?php echo esc_attr( absint( $student_user_id ) ); ?>" />
            <?php wp_nonce_field( $action . '_' . absint( $student_user_id ) ); ?>
            <button type="submit" class="button tutorhelper-admin-button<?php echo esc_attr( $primary ? ' tutorhelper-admin-button--primary' : '' ); ?>">
                <?php echo esc_html( $label ); ?>
            </button>
        </form>
        <?php
    }


    /**
     * Approve a new student registration.
     *
     * @return void
     */
    public static function handle_approve_registration() {

        $registration = self::get_registration_action_context(
            self::APPROVE_REGISTRATION_ACTION,
            array( self::STATUS_NEW )
        );

        self::make_registration_live(
            $registration['student_id'],
            $registration['status'],
            false
        );

        self::redirect_registration( 'registration_approved' );
    }


    /**
     * Place a new registration on the waiting list.
     *
     * @return void
     */
    public static function handle_waitlist_registration() {

        $registration = self::get_registration_action_context(
            self::WAITLIST_REGISTRATION_ACTION,
            array( self::STATUS_NEW )
        );

        $student_user_id = $registration['student_id'];
        $reviewed_by = get_current_user_id();
        $reviewed_at = current_time( 'mysql' );

        $saved = self::update_registration_meta(
            $student_user_id,
            array(
                'tutorhelper_registration_decision'     => self::DECISION_WAITING_LIST,
                'tutorhelper_registration_decided_at'   => $reviewed_at,
                'tutorhelper_registration_decided_by'   => $reviewed_by,
                'tutorhelper_registration_waitlisted_at' => $reviewed_at,
                'tutorhelper_registration_waitlisted_by' => $reviewed_by,
                TutorHelper_Students::META_BOOKING_BLOCKED => 1,
                TutorHelper_Students::META_BOOKING_BLOCKED_MESSAGE => __( 'You are currently on the waiting list. Your tutor will let you know when a place becomes available.', 'tutorhelper-pro' ),
                'tutorhelper_registration_status'       => self::STATUS_WAITING_LIST,
            ),
            'waitlist'
        );

        if ( ! $saved ) {
            self::redirect_registration( 'error', 'registration_waitlist_failed' );
        }

        do_action(
            'tutorhelper_pro_registration_waitlisted',
            $student_user_id,
            $reviewed_by
        );

        self::redirect_registration( 'registration_waitlisted' );
    }


    /**
     * Promote a waiting-list student through the normal Live approval path.
     *
     * @return void
     */
    public static function handle_promote_registration() {

        $registration = self::get_registration_action_context(
            self::PROMOTE_REGISTRATION_ACTION,
            array( self::STATUS_WAITING_LIST )
        );

        self::make_registration_live(
            $registration['student_id'],
            $registration['status'],
            true
        );

        self::redirect_registration( 'registration_promoted' );
    }


    /**
     * Validate a registration decision request.
     *
     * @param string $action           Admin-post action.
     * @param array  $allowed_statuses Statuses accepted by this transition.
     * @return array
     */
    private static function get_registration_action_context(
        $action,
        $allowed_statuses
    ) {

        self::verify_admin_request();

        $student_user_id =
            isset(
                $_POST['student_id']
            )
                ? absint(
                    $_POST['student_id']
                )
                : 0;

        if ( ! $student_user_id ) {

            self::redirect_registration(
                'error',
                'invalid_student'
            );
        }

        check_admin_referer(
            $action
            . '_'
            . $student_user_id
        );


        $student =
            TutorHelper_Students::
                get_student(
                    $student_user_id
                );

        if ( ! $student ) {

            self::redirect_registration(
                'error',
                'invalid_student'
            );
        }


        $status =
            sanitize_key(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_registration_status',
                    true
                )
            );

        $source = sanitize_key(
            get_user_meta(
                $student_user_id,
                'tutorhelper_registration_source',
                true
            )
        );

        if (
            'student_registration' !== $source
            || ! in_array( $status, $allowed_statuses, true )
        ) {

            self::redirect_registration(
                'error',
                'registration_transition_invalid'
            );
        }

        return array(
            'student_id' => $student_user_id,
            'student'    => $student,
            'status'     => $status,
        );
    }


    /**
     * Apply the existing Live approval workflow exactly once.
     *
     * @param int    $student_user_id Student user ID.
     * @param string $previous_status Previous workflow status.
     * @param bool   $promoted        Whether this is a waiting-list promotion.
     * @return void
     */
    private static function make_registration_live(
        $student_user_id,
        $previous_status,
        $promoted
    ) {


        $reviewed_by =
            get_current_user_id();

        $reviewed_at =
            current_time(
                'mysql'
            );


        $metadata = array(
            'tutorhelper_registration_reviewed_at' => $reviewed_at,
            'tutorhelper_registration_reviewed_by' => $reviewed_by,
        );

        if ( self::STATUS_NEW === $previous_status ) {
            $metadata['tutorhelper_registration_decision'] = self::DECISION_LIVE;
            $metadata['tutorhelper_registration_decided_at'] = $reviewed_at;
            $metadata['tutorhelper_registration_decided_by'] = $reviewed_by;
        }

        if ( $promoted ) {
            $metadata['tutorhelper_registration_promoted_at'] = $reviewed_at;
            $metadata['tutorhelper_registration_promoted_by'] = $reviewed_by;
        }

        $metadata['tutorhelper_registration_status'] = self::STATUS_APPROVED;

        if ( ! self::update_registration_meta( $student_user_id, $metadata, $promoted ? 'promote' : 'approve' ) ) {
            self::redirect_registration( 'error', 'registration_approval_failed' );
        }


        /*
        * Approval enables lesson booking.
        */
        delete_user_meta(
            $student_user_id,
            TutorHelper_Students::
                META_BOOKING_BLOCKED
        );

        delete_user_meta(
            $student_user_id,
            TutorHelper_Students::
                META_BOOKING_BLOCKED_MESSAGE
        );


        /**
         * Fires after a TutorHelper Pro registration
         * has been approved.
         *
         * The email module will subscribe to this action.
         *
         * @param int $student_user_id Student user ID.
         * @param int $reviewed_by     Tutor user ID.
         */
        do_action(
            'tutorhelper_pro_registration_approved',
            $student_user_id,
            $reviewed_by
        );
    }


    /**
     * Save audited registration metadata and log genuine failures.
     *
     * @param int    $student_user_id Student user ID.
     * @param array  $metadata        Key/value pairs to store.
     * @param string $operation       Diagnostic operation label.
     * @return bool
     */
    private static function update_registration_meta(
        $student_user_id,
        $metadata,
        $operation
    ) {
        foreach ( $metadata as $key => $value ) {
            $updated = update_user_meta( $student_user_id, $key, $value );

            if (
                false === $updated
                && (string) get_user_meta( $student_user_id, $key, true ) !== (string) $value
            ) {
                if ( class_exists( 'TutorHelper_Logger' ) ) {
                    TutorHelper_Logger::error(
                        'TutorHelper Pro registration workflow metadata could not be saved.',
                        array(
                            'operation'  => sanitize_key( $operation ),
                            'student_id' => absint( $student_user_id ),
                            'meta_key'   => sanitize_key( $key ),
                            'user_id'    => get_current_user_id(),
                        )
                    );
                }

                return false;
            }
        }

        return true;
    }




	/**
	 * Render status/error feedback.
	 *
	 * @return void
	 */
	private static function render_admin_notice() {

		$status =
			isset(
				$_GET['registration_status'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			)
				? sanitize_key(
					wp_unslash(
						$_GET['registration_status'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
					)
				)
				: '';

		$error_code =
			isset(
				$_GET['registration_error'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			)
				? sanitize_key(
					wp_unslash(
						$_GET['registration_error'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
					)
				)
				: '';

		$messages = array(
			'created' =>
				__(
					'Onboarding question added.',
					'tutorhelper-pro'
				),

			'updated' =>
				__(
					'Onboarding question updated.',
					'tutorhelper-pro'
				),

			'archived' =>
				__(
					'Onboarding question archived.',
					'tutorhelper-pro'
				),

			'restored' =>
				__(
					'Onboarding question restored.',
					'tutorhelper-pro'
				),

            'registration_status_updated' =>
                __(
                    'Registration availability updated.',
                    'tutorhelper-pro'
                ),
            
            'registration_approved' =>
                __(
                    'The student is now Live and lesson booking has been enabled.',
                    'tutorhelper-pro'
                ),

            'registration_waitlisted' =>
                __(
                    'The student has been added to the waiting list and remains unable to book lessons.',
                    'tutorhelper-pro'
                ),

            'registration_promoted' =>
                __(
                    'The waiting-list student is now Live and lesson booking has been enabled.',
                    'tutorhelper-pro'
                ),
		);

		if (
			isset(
				$messages[ $status ]
			)
		) {
			?>
			<div
				class="
					notice
					notice-success
					is-dismissible
				"
			>
				<p>
					<?php
					echo esc_html(
						$messages[
							$status
						]
					);
					?>
				</p>
			</div>
			<?php

			return;
		}

		if (
			'error' !== $status
		) {
			return;
		}

		$message =
			__(
				'The onboarding question could not be saved.',
				'tutorhelper-pro'
			);

		if ( $error_code ) {
			$message =
				sprintf(
					/* translators: %s: Internal error code. */
					__(
						'The request could not be completed. Error: %s',
						'tutorhelper-pro'
					),
					$error_code
				);
		}

		?>
		<div
			class="
				notice
				notice-error
			"
		>
			<p>
				<?php
				echo esc_html(
					$message
				);
				?>
			</p>
		</div>
		<?php
	}


    /**
     * Render Registration Availability settings.
     *
     * @return void
     */
    private static function render_registration_status_panel() {

        $current_status =
            TutorHelper_Pro_Registration_Settings::
                get_status();

        $statuses =
            TutorHelper_Pro_Registration_Settings::
                get_statuses();

        ?>
        <section
            class="
                tutorhelper-main-section
                tutorhelper-pro-registration-status
            "
        >
            <header
                class="tutorhelper-main-section__header"
            >
                <div
                    class="
                        tutorhelper-main-section__header-content
                    "
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Registration Availability',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        echo esc_html__(
                            'Choose what new students see when they visit your registration page.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="tutorhelper-main-section__body"
            >
                <form
                    method="post"
                    action="<?php
                        echo esc_url(
                            admin_url(
                                'admin-post.php'
                            )
                        );
                    ?>"
                    class="
                        tutorhelper-pro-registration-status__form
                    "
                >

                    <input
                        type="hidden"
                        name="action"
                        value="<?php
                            echo esc_attr(
                                self::
                                    SAVE_STATUS_ACTION
                            );
                        ?>"
                    />

                    <?php
                    wp_nonce_field(
                        self::
                            SAVE_STATUS_ACTION
                    );
                    ?>

                    <div
                        class="
                            tutorhelper-pro-registration-status__options
                        "
                    >
                        <?php
                        foreach (
                            $statuses
                            as $value => $details
                        ) :
                            ?>
                            <label
                                class="
                                    tutorhelper-pro-registration-status__option
                                "
                            >
                                <input
                                    type="radio"
                                    name="registration_status"
                                    value="<?php
                                        echo esc_attr(
                                            $value
                                        );
                                    ?>"
                                    <?php
                                    checked(
                                        $current_status,
                                        $value
                                    );
                                    ?>
                                />

                                <span>
                                    <strong>
                                        <?php
                                        echo esc_html(
                                            $details[
                                                'label'
                                            ]
                                        );
                                        ?>
                                    </strong>

                                    <small>
                                        <?php
                                        echo esc_html(
                                            $details[
                                                'description'
                                            ]
                                        );
                                        ?>
                                    </small>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div
                        class="
                            tutorhelper-pro-registration-status__actions
                        "
                    >
                        <button
                            type="submit"
                            class="
                                button
                                tutorhelper-admin-button
                                tutorhelper-admin-button--primary
                            "
                        >
                            <?php
                            echo esc_html__(
                                'Save Registration Status',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>
                    </div>

                </form>
            </div>
        </section>
        <?php
    }





    /**
     * Save Registration Availability.
     *
     * @return void
     */
    public static function handle_save_registration_status() {

        self::verify_admin_request();

        check_admin_referer(
            self::SAVE_STATUS_ACTION
        );

        $status =
            isset(
                $_POST['registration_status']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_POST[
                            'registration_status'
                        ]
                    )
                )
                : '';

        $result =
            TutorHelper_Pro_Registration_Settings::
                update_status(
                    $status
                );

        if ( is_wp_error( $result ) ) {

            self::redirect_registration(
                'error',
                $result->get_error_code()
            );
        }

        self::redirect_registration(
            'registration_status_updated'
        );
    }




	/**
	 * Render full new-registration summary panel.
	 *
	 * Review actions will be added when the public
	 * registration workflow is implemented.
	 *
	 * @return void
	 */
	private static function render_new_registrations_panel() {

		$registrations =
			self::get_new_registrations(
				10
			);

		$total =
			self::get_new_registration_count();

		?>
		<section
			class="
				tutorhelper-main-section
				tutorhelper-pro-new-registrations
			"
		>
			<header
				class="tutorhelper-main-section__header"
			>
				<div
					class="
						tutorhelper-main-section__header-content
					"
				>
					<h2>
						<?php
						echo esc_html__(
							'New Registrations',
							'tutorhelper-pro'
						);
						?>
					</h2>

					<p>
						<?php
						printf(
							esc_html(
								_n(
									'%d registration awaiting review.',
									'%d registrations awaiting review.',
									$total,
									'tutorhelper-pro'
								)
							),
							absint(
								$total
							)
						);
						?>
					</p>
				</div>
			</header>

			<div
				class="tutorhelper-main-section__body"
			>

				<?php if ( empty( $registrations ) ) : ?>

					<p>
						<?php
						echo esc_html__(
							'There are no new registrations waiting for review.',
							'tutorhelper-pro'
						);
						?>
					</p>

				<?php else : ?>

					<div
						class="
							tutorhelper-student-table-wrap
						"
					>
						<table
							class="
								widefat
								striped
								tutorhelper-student-table
							"
						>
							<thead>
								<tr>
									<th scope="col">
										<?php
										echo esc_html__(
											'Student',
											'tutorhelper-pro'
										);
										?>
									</th>

									<th scope="col">
										<?php
										echo esc_html__(
											'Registered',
											'tutorhelper-pro'
										);
										?>
									</th>

									<th scope="col">
										<span
											class="screen-reader-text"
										>
											<?php
											echo esc_html__(
												'Actions',
												'tutorhelper-pro'
											);
											?>
										</span>
									</th>
								</tr>
							</thead>

							<tbody>
								<?php
								foreach (
									$registrations
									as $student
								) :
									?>
									<tr>
										<td>
											<strong>
												<?php
												echo esc_html(
													$student->
														display_name
												);
												?>
											</strong>

											<br />

											<a
												href="mailto:<?php
													echo esc_attr(
														$student->
															user_email
													);
												?>"
											>
												<?php
												echo esc_html(
													$student->
														user_email
												);
												?>
											</a>
										</td>

										<td>
											<?php
											echo esc_html(
												get_date_from_gmt(
													$student->
														user_registered,
													get_option(
														'date_format'
													)
													. ' '
													. get_option(
														'time_format'
													)
												)
											);
											?>
										</td>

										<td>
											<a
												href="<?php
													echo esc_url(
														self::get_registration_url(
                                                            array(
                                                                'registration_id' =>
                                                                    absint(
                                                                        $student->ID
                                                                    ),
                                                            )
                                                        )
													);
												?>"
												class="
													button
													tutorhelper-admin-button
												"
											>
												<?php
												echo esc_html__(
                                                    'Review Registration',
                                                    'tutorhelper-pro'
                                                );
												?>
											</a>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>

					<?php if ( $total > 10 ) : ?>
						<p class="description">
							<?php
							printf(
								/* translators: %d: Number of registrations not shown. */
								esc_html__(
									'%d more registrations are waiting for review.',
									'tutorhelper-pro'
								),
								absint(
									$total - 10
								)
							);
							?>
						</p>
					<?php endif; ?>

				<?php endif; ?>

			</div>
		</section>
		<?php
	}


	/**
	 * Render the waiting-list management panel.
	 *
	 * @return void
	 */
	private static function render_waiting_list_panel() {
		$registrations = self::get_waiting_list_registrations( 50 );
		$total = self::get_waiting_list_count();
		?>
		<section id="tutorhelper-waiting-list" class="tutorhelper-main-section tutorhelper-pro-new-registrations tutorhelper-pro-waiting-list-panel">
			<header class="tutorhelper-main-section__header">
				<div class="tutorhelper-main-section__header-content">
					<h2><?php esc_html_e( 'Waiting List', 'tutorhelper-pro' ); ?></h2>
					<p>
						<?php
						printf(
							esc_html( _n( '%d student is waiting for a place.', '%d students are waiting for a place.', $total, 'tutorhelper-pro' ) ),
							absint( $total )
						);
						?>
					</p>
				</div>
			</header>
			<div class="tutorhelper-main-section__body">
				<?php if ( empty( $registrations ) ) : ?>
					<p><?php esc_html_e( 'There are no students on the waiting list.', 'tutorhelper-pro' ); ?></p>
				<?php else : ?>
					<div class="tutorhelper-student-table-wrap">
						<table class="widefat striped tutorhelper-student-table">
							<thead>
								<tr>
									<th scope="col"><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Added to waiting list', 'tutorhelper-pro' ); ?></th>
									<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'tutorhelper-pro' ); ?></span></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $registrations as $student ) : ?>
									<tr>
										<td>
											<strong><?php echo esc_html( $student->display_name ); ?></strong><br />
											<a href="mailto:<?php echo esc_attr( $student->user_email ); ?>"><?php echo esc_html( $student->user_email ); ?></a>
										</td>
										<td><?php echo esc_html( self::format_registration_decision_date( $student->ID ) ); ?></td>
										<td>
											<div class="tutorhelper-pro-waiting-list-panel__actions">
												<a href="<?php echo esc_url( self::get_registration_url( array( 'registration_id' => absint( $student->ID ) ) ) ); ?>" class="button tutorhelper-admin-button"><?php esc_html_e( 'Review', 'tutorhelper-pro' ); ?></a>
												<?php self::render_registration_action_form(
													self::PROMOTE_REGISTRATION_ACTION,
													$student->ID,
													__( 'Make Live Student', 'tutorhelper-pro' ),
													true
												); ?>
											</div>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<?php if ( $total > 50 ) : ?>
						<p class="description">
							<?php
							printf(
								/* translators: %d: Number of waiting-list students not shown. */
								esc_html__( '%d more students are on the waiting list.', 'tutorhelper-pro' ),
								absint( $total - 50 )
							);
							?>
						</p>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}


	/**
	 * Format the recorded waiting-list decision date.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return string
	 */
	private static function format_registration_decision_date( $student_user_id ) {
		$date = get_user_meta(
			absint( $student_user_id ),
			'tutorhelper_registration_waitlisted_at',
			true
		);

		if ( ! $date ) {
			$date = get_user_meta(
				absint( $student_user_id ),
				'tutorhelper_registration_decided_at',
				true
			);
		}

		return $date
			? mysql2date( get_option( 'date_format' ), $date )
			: __( 'Date unavailable', 'tutorhelper-pro' );
	}


	/**
	 * Return a readable registration workflow status.
	 *
	 * @param string $status Stored status.
	 * @return string
	 */
	private static function get_registration_status_label( $status ) {
		$labels = array(
			self::STATUS_NEW          => __( 'Awaiting review', 'tutorhelper-pro' ),
			self::STATUS_WAITING_LIST => __( 'Waiting list', 'tutorhelper-pro' ),
			self::STATUS_APPROVED     => __( 'Live student', 'tutorhelper-pro' ),
		);

		$status = sanitize_key( $status );

		return isset( $labels[ $status ] )
			? $labels[ $status ]
			: __( 'Unknown', 'tutorhelper-pro' );
	}


	/**
	 * Render onboarding questions.
	 *
	 * @param array $questions All questions.
	 *
	 * @return void
	 */
	private static function render_question_list(
		$questions
	) {

		$system = array_filter(
            $questions,
            static function ( $question ) {
                return ! empty(
                    $question->is_system
                );
            }
        );

        $active = array_filter(
            $questions,
            static function ( $question ) {
                return
                    empty(
                        $question->is_system
                    )
                    && ! empty(
                        $question->is_active
                    );
            }
        );

        $archived = array_filter(
            $questions,
            static function ( $question ) {
                return
                    empty(
                        $question->is_system
                    )
                    && empty(
                        $question->is_active
                    );
            }
        );

		?>
		<section
			class="
				tutorhelper-main-section
				tutorhelper-pro-onboarding-questions
			"
		>
			<header
				class="tutorhelper-main-section__header"
			>
				<div
					class="
						tutorhelper-main-section__header-content
					"
				>
					<h2>
						<?php
						echo esc_html__(
							'Onboarding Questions',
							'tutorhelper-pro'
						);
						?>
					</h2>

					<p>
						<?php
						echo esc_html__(
							'Drag active questions to change the order shown during registration.',
							'tutorhelper-pro'
						);
						?>
					</p>
				</div>
			</header>

            <div class="tutorhelper-main-section__body">
            <div class="tutorhelper-pro-system-questions">

                <h3>
                    <?php
                    echo esc_html__(
                        'Required account questions',
                        'tutorhelper-pro'
                    );
                    ?>
                </h3>

                <p class="description">
                    <?php
                    echo esc_html__(
                        'These fields are used to create the student account. You can change their wording, but they cannot be removed or reordered.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

                <div
                    class="
                        tutorhelper-pro-onboarding-question-list
                        tutorhelper-pro-onboarding-question-list--system
                    "
                >
                    <?php
                    foreach (
                        $system
                        as $question
                    ) {
                        self::render_question_item(
                            $question,
                            false
                        );
                    }
                    ?>
                </div>

            </div>


            <div class="tutorhelper-pro-additional-questions">

                <h3>
                    <?php
                    echo esc_html__(
                        'Additional onboarding questions',
                        'tutorhelper-pro'
                    );
                    ?>
                </h3>

                <p class="description">
                    <?php
                    echo esc_html__(
                        'Drag active questions to change the order shown during registration.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

                <?php if ( empty( $active ) ) : ?>

                    <p>
                        <?php
                        echo esc_html__(
                            'No additional onboarding questions have been created yet.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                <?php else : ?>

                    <div
                        id="tutorhelper-pro-onboarding-question-list"
                        class="
                            tutorhelper-pro-onboarding-question-list
                            is-sortable
                        "
                    >
                        <?php
                        foreach (
                            $active
                            as $question
                        ) {
                            self::render_question_item(
                                $question,
                                true
                            );
                        }
                        ?>
                    </div>

                    <p
                        id="tutorhelper-pro-onboarding-order-status"
                        class="tutorhelper-pro-order-status"
                        aria-live="polite"
                    ></p>

                <?php endif; ?>

                </div>


				<?php if ( $archived ) : ?>

					<details
						class="
							tutorhelper-pro-archived-questions
						"
					>
						<summary>
							<?php
							printf(
								esc_html__(
									'Archived questions (%d)',
									'tutorhelper-pro'
								),
								count(
									$archived
								)
							);
							?>
						</summary>

						<div
							class="
								tutorhelper-pro-onboarding-question-list
								tutorhelper-pro-onboarding-question-list--archived
							"
						>
							<?php
							foreach (
								$archived
								as $question
							) {
								self::
									render_question_item(
										$question,
										false
									);
							}
							?>
						</div>
					</details>

				<?php endif; ?>
                

			</div>
		</section>
		<?php
	}


	/**
     * Render one onboarding question row.
     *
     * System questions are locked and cannot be reordered or
     * archived. Active custom questions may be reordered and
     * archived. Archived custom questions may be restored.
     *
     * @param object $question Question record.
     * @param bool   $sortable Whether the item can be dragged.
     *
     * @return void
     */
    private static function render_question_item(
        $question,
        $sortable = true
    ) {

        $is_system =
            ! empty(
                $question->is_system
            );

        $is_archived =
            ! $is_system
            && empty(
                $question->is_active
            );

        $is_sortable =
            ! $is_system
            && ! $is_archived
            && $sortable;

        $question_id =
            absint(
                $question->id
            );

        $question_types =
            TutorHelper_Pro_Onboarding::
                get_question_types();

        $data_categories =
            TutorHelper_Pro_Onboarding::
                get_data_categories();

        $type =
            sanitize_key(
                $question->question_type
            );

        $category =
            sanitize_key(
                $question->data_category
            );

        $type_label =
            isset(
                $question_types[
                    $type
                ]
            )
                ? $question_types[
                    $type
                ]
                : $type;

        $category_label =
            isset(
                $data_categories[
                    $category
                ]
            )
                ? $data_categories[
                    $category
                ]
                : $category;

        $edit_url =
            self::get_registration_url(
                array(
                    'question_id' =>
                        $question_id,
                )
            );

        /*
        * System questions never receive a status action.
        */
        $status_action = '';

        $status_label = '';

        if ( ! $is_system ) {

            $status_action =
                $is_archived
                    ? 'restore'
                    : 'archive';

            $status_label =
                $is_archived
                    ? __(
                        'Restore',
                        'tutorhelper-pro'
                    )
                    : __(
                        'Archive',
                        'tutorhelper-pro'
                    );
        }

        /*
        * Keep the three question states explicit.
        */
        if ( $is_system ) {

            $state_class =
                'is-system';

        } elseif ( $is_sortable ) {

            $state_class =
                'is-sortable';

        } else {

            $state_class =
                'is-archived';
        }

        ?>
        <article
            class="
                tutorhelper-pro-onboarding-question
                <?php
                echo esc_attr(
                    $state_class
                );
                ?>
            "
            data-question-id="<?php
                echo esc_attr(
                    $question_id
                );
            ?>"
        >

            <?php if ( $is_system ) : ?>

                <span
                    class="
                        tutorhelper-pro-onboarding-question__lock
                    "
                    title="<?php
                        echo esc_attr__(
                            'Required account field',
                            'tutorhelper-pro'
                        );
                    ?>"
                >
                    <span
                        class="
                            dashicons
                            dashicons-lock
                        "
                        aria-hidden="true"
                    ></span>
                </span>

            <?php elseif ( $is_sortable ) : ?>

                <?php
                /*
                * IMPORTANT:
                *
                * Do not make this a <button>.
                *
                * jQuery UI Sortable cancels mouse interactions
                * originating from buttons by default, which
                * prevents this element from acting as the
                * configured drag handle.
                */
                ?>
                <span
                    class="
                        tutorhelper-pro-onboarding-question__drag
                    "
                    title="<?php
                        echo esc_attr__(
                            'Drag to reorder',
                            'tutorhelper-pro'
                        );
                    ?>"
                    aria-hidden="true"
                >
                    <span
                        class="
                            dashicons
                            dashicons-move
                        "
                    ></span>
                </span>

            <?php else : ?>

                <span
                    class="
                        tutorhelper-pro-onboarding-question__lock
                        tutorhelper-pro-onboarding-question__lock--archived
                    "
                    title="<?php
                        echo esc_attr__(
                            'Archived question',
                            'tutorhelper-pro'
                        );
                    ?>"
                >
                    <span
                        class="
                            dashicons
                            dashicons-hidden
                        "
                        aria-hidden="true"
                    ></span>
                </span>

            <?php endif; ?>


            <div
                class="
                    tutorhelper-pro-onboarding-question__content
                "
            >

                <strong
                    class="
                        tutorhelper-pro-onboarding-question__text
                    "
                >
                    <?php
                    echo esc_html(
                        $question->
                            question_text
                    );
                    ?>
                </strong>


                <div
                    class="
                        tutorhelper-pro-onboarding-question__meta
                    "
                >

                    <span
                        class="
                            tutorhelper-pro-onboarding-badge
                        "
                    >
                        <?php
                        echo esc_html(
                            $type_label
                        );
                        ?>
                    </span>


                    <span
                        class="
                            tutorhelper-pro-onboarding-badge
                        "
                    >
                        <?php
                        echo esc_html(
                            ! empty(
                                $question->
                                    is_required
                            )
                                ? __(
                                    'Required',
                                    'tutorhelper-pro'
                                )
                                : __(
                                    'Optional',
                                    'tutorhelper-pro'
                                )
                        );
                        ?>
                    </span>


                    <span
                        class="
                            tutorhelper-pro-onboarding-badge
                            tutorhelper-pro-onboarding-badge--<?php
                                echo esc_attr(
                                    $category
                                );
                            ?>
                        "
                    >
                        <?php
                        echo esc_html(
                            $category_label
                        );
                        ?>
                    </span>


                    <?php if ( $is_system ) : ?>

                        <span
                            class="
                                tutorhelper-pro-onboarding-badge
                                tutorhelper-pro-onboarding-badge--system
                            "
                        >
                            <?php
                            echo esc_html__(
                                'Account field',
                                'tutorhelper-pro'
                            );
                            ?>
                        </span>

                    <?php endif; ?>

                </div>

            </div>


            <div
                class="
                    tutorhelper-pro-onboarding-question__actions
                "
            >

                <?php if (
                    $is_system
                    || $is_sortable
                ) :
                    ?>

                    <a
                        href="<?php
                            echo esc_url(
                                $edit_url
                            );
                        ?>"
                        class="
                            button
                            tutorhelper-admin-button
                        "
                    >
                        <?php
                        echo esc_html__(
                            'Edit',
                            'tutorhelper-pro'
                        );
                        ?>
                    </a>

                <?php endif; ?>


                <?php if ( ! $is_system ) : ?>

                    <form
                        method="post"
                        action="<?php
                            echo esc_url(
                                admin_url(
                                    'admin-post.php'
                                )
                            );
                        ?>"
                        class="
                            tutorhelper-pro-onboarding-question__status
                        "
                    >

                        <input
                            type="hidden"
                            name="action"
                            value="<?php
                                echo esc_attr(
                                    self::
                                        STATUS_QUESTION_ACTION
                                );
                            ?>"
                        />

                        <input
                            type="hidden"
                            name="question_id"
                            value="<?php
                                echo esc_attr(
                                    $question_id
                                );
                            ?>"
                        />

                        <input
                            type="hidden"
                            name="status_action"
                            value="<?php
                                echo esc_attr(
                                    $status_action
                                );
                            ?>"
                        />

                        <?php
                        wp_nonce_field(
                            self::
                                STATUS_QUESTION_ACTION
                        );
                        ?>

                        <button
                            type="submit"
                            class="
                                button
                                tutorhelper-admin-button
                            "
                        >
                            <?php
                            echo esc_html(
                                $status_label
                            );
                            ?>
                        </button>

                    </form>

                <?php endif; ?>

            </div>

        </article>
        <?php
    }


	/**
	 * Render Add/Edit question form.
	 *
	 * @param object|null $question Existing question.
	 *
	 * @return void
	 */
	private static function render_question_form(
		$question = null
	) {
        

		$is_editing =
			! empty(
				$question
			);
        
        $is_system =
            $is_editing
            && ! empty(
                $question->is_system
            );

		$question_id =
			$is_editing
				? absint(
					$question->id
				)
				: 0;

		$question_text =
			$is_editing
				? (string)
					$question->
						question_text
				: '';

		$question_type =
			$is_editing
				? sanitize_key(
					$question->
						question_type
				)
				: TutorHelper_Pro_Onboarding::
					TYPE_SHORT_TEXT;

		$question_options =
			$is_editing
				? (string)
					$question->
						question_options
				: '';

		$is_required =
			$is_editing
			&& ! empty(
				$question->
					is_required
			);

		$data_category =
			$is_editing
				? sanitize_key(
					$question->
						data_category
				)
				: TutorHelper_Pro_Onboarding::
					DATA_STANDARD;

		?>
		<section
			class="
				tutorhelper-main-section
				tutorhelper-pro-onboarding-editor
			"
		>

			<header
				class="tutorhelper-main-section__header"
			>
				<div
					class="
						tutorhelper-main-section__header-content
					"
				>
					<h2>
						<?php
						echo esc_html(
							$is_editing
								? __(
									'Edit Question',
									'tutorhelper-pro'
								)
								: __(
									'Add Question',
									'tutorhelper-pro'
								)
						);
						?>
					</h2>

					<p>
						<?php
						echo esc_html__(
							'Create questions for students or parents to answer during registration.',
							'tutorhelper-pro'
						);
						?>
					</p>
				</div>
			</header>

			<div
				class="tutorhelper-main-section__body"
			>

				<form
					method="post"
					action="<?php
						echo esc_url(
							admin_url(
								'admin-post.php'
							)
						);
					?>"
					class="
						tutorhelper-pro-onboarding-form
					"
				>

					<input
						type="hidden"
						name="action"
						value="<?php
							echo esc_attr(
								self::
									SAVE_QUESTION_ACTION
							);
						?>"
					/>

					<input
						type="hidden"
						name="question_id"
						value="<?php
							echo esc_attr(
								$question_id
							);
						?>"
					/>

					<?php
					wp_nonce_field(
						self::
							SAVE_QUESTION_ACTION
					);
					?>

					<div
						class="tutorhelper-input-field"
					>
						<label
							for="tutorhelper-pro-question-text"
						>
							<?php
							echo esc_html__(
								'Question',
								'tutorhelper-pro'
							);
							?>

							<span
								class="tutorhelper-required"
								aria-hidden="true"
							>
								*
							</span>
						</label>

						<input
							type="text"
							id="tutorhelper-pro-question-text"
							name="question_text"
							value="<?php
								echo esc_attr(
									$question_text
								);
							?>"
							class="regular-text"
							required
						/>
					</div>

                    <?php if ( $is_system ) : ?>

                    <div
                        class="
                            tutorhelper-pro-system-field-info
                        "
                    >
                        <span
                            class="
                                dashicons
                                dashicons-lock
                            "
                            aria-hidden="true"
                        ></span>

                        <div>
                            <strong>
                                <?php
                                echo esc_html__(
                                    'Required account field',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </strong>

                            <p>
                                <?php
                                echo esc_html__(
                                    'You can change the wording shown to students, but TutorHelper controls the field type and whether it is required.',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </p>
                        </div>
                    </div>

                    <?php else : ?>


					<div
						class="tutorhelper-input-field"
					>
						<label
							for="tutorhelper-pro-question-type"
						>
							<?php
							echo esc_html__(
								'Question type',
								'tutorhelper-pro'
							);
							?>
						</label>

						<select
							id="tutorhelper-pro-question-type"
							name="question_type"
						>
							<?php
							foreach (
								TutorHelper_Pro_Onboarding::
									get_question_types()
								as $value => $label
							) :
								?>
								<option
									value="<?php
										echo esc_attr(
											$value
										);
									?>"
									<?php
									selected(
										$question_type,
										$value
									);
									?>
								>
									<?php
									echo esc_html(
										$label
									);
									?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

					<div
						class="tutorhelper-input-field"
						data-onboarding-options
						<?php
						if (
							! in_array(
								$question_type,
								array(
									TutorHelper_Pro_Onboarding::
										TYPE_CHECKBOX,

									TutorHelper_Pro_Onboarding::
										TYPE_DROPDOWN,
								),
								true
							)
						) {
							echo ' hidden';
						}
						?>
					>
						<label
							for="tutorhelper-pro-question-options"
						>
							<?php
							echo esc_html__(
								'Options',
								'tutorhelper-pro'
							);
							?>
						</label>

						<textarea
							id="tutorhelper-pro-question-options"
							name="question_options"
							rows="6"
							class="large-text"
						><?php
							echo esc_textarea(
								$question_options
							);
						?></textarea>

						<p class="description">
							<?php
							echo esc_html__(
								'Enter one option per line. Used only for dropdown and checkbox questions.',
								'tutorhelper-pro'
							);
							?>
						</p>
					</div>

					<div
						class="tutorhelper-input-field"
					>
						<label class="tutorhelper-toggle-row">
                        <input
                            type="checkbox"
                            name="is_required"
                            value="1"
                            <?php checked( $is_required ); ?>
                        />

                        <span>
                            <strong>
                                <?php
                                echo esc_html__(
                                    'Require an answer',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </strong>

                            <small>
                                <?php
                                echo esc_html__(
                                    'Students cannot complete registration without answering this question.',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </small>
                        </span>
                    </label>

					</div>

					<div
						class="tutorhelper-input-field"
					>
						<div class="tutorhelper-pro-field-label">
                            <label for="tutorhelper-pro-data-category">
                                <?php
                                echo esc_html__(
                                    'Data category',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </label>

                            <span class="tutorhelper-pro-help">
                                <button
                                    type="button"
                                    class="tutorhelper-pro-help__button"
                                    aria-label="<?php
                                        echo esc_attr__(
                                            'About data categories',
                                            'tutorhelper-pro'
                                        );
                                    ?>"
                                >
                                    <span
                                        class="dashicons dashicons-editor-help"
                                        aria-hidden="true"
                                    ></span>
                                </button>

                                <span
                                    class="tutorhelper-pro-help__tooltip"
                                    role="tooltip"
                                >
                                    <strong>
                                        <?php
                                        echo esc_html__(
                                            'Why classify this question?',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </strong>

                                    <span>
                                        <?php
                                        echo esc_html__(
                                            'Standard: ordinary information such as exam board or year group.',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </span>

                                    <span>
                                        <?php
                                        echo esc_html__(
                                            'Sensitive: information such as family circumstances or detailed learning support needs.',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </span>

                                    <span>
                                        <?php
                                        echo esc_html__(
                                            'Special category: information such as health or disability data that may require additional UK GDPR safeguards.',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </span>
                                </span>
                            </span>
                        </div>
						<select
							id="tutorhelper-pro-data-category"
							name="data_category"
						>
							<?php
							foreach (
								TutorHelper_Pro_Onboarding::
									get_data_categories()
								as $value => $label
							) :
								?>
								<option
									value="<?php
										echo esc_attr(
											$value
										);
									?>"
									<?php
									selected(
										$data_category,
										$value
									);
									?>
								>
									<?php
									echo esc_html(
										$label
									);
									?>
								</option>
							<?php endforeach; ?>
						</select>

						<p class="description">
							<?php
							echo esc_html__(
								'Classify the type of personal information this question may collect.',
								'tutorhelper-pro'
							);
							?>
						</p>
					</div>

					<div
						class="
							tutorhelper-pro-data-guidance
							tutorhelper-pro-data-guidance--sensitive
						"
						data-category="sensitive"
						<?php
						if (
							TutorHelper_Pro_Onboarding::
								DATA_SENSITIVE
							!== $data_category
						) {
							echo ' hidden';
						}
						?>
					>
						<strong>
							<?php
							echo esc_html__(
								'Privacy reminder',
								'tutorhelper-pro'
							);
							?>
						</strong>

						<p>
							<?php
							echo esc_html__(
								'Only collect information you genuinely need to provide tuition or manage the student account.',
								'tutorhelper-pro'
							);
							?>
						</p>
					</div>

					<div
						class="
							tutorhelper-pro-data-guidance
							tutorhelper-pro-data-guidance--special
						"
						data-category="special_category"
						<?php
						if (
							TutorHelper_Pro_Onboarding::
								DATA_SPECIAL_CATEGORY
							!== $data_category
						) {
							echo ' hidden';
						}
						?>
					>
						<strong>
							<?php
							echo esc_html__(
								'Special-category personal data',
								'tutorhelper-pro'
							);
							?>
						</strong>

						<p>
							<?php
							echo esc_html__(
								'This question may collect special-category personal data. Only collect information you genuinely need and ensure that you have an appropriate lawful basis and UK GDPR Article 9 condition for processing it.',
								'tutorhelper-pro'
							);
							?>
						</p>
					</div>

                    <?php endif; ?>

					<div
						class="
							tutorhelper-pro-onboarding-form__actions
						"
					>
						<button
							type="submit"
							class="
								button
								tutorhelper-admin-button
								tutorhelper-admin-button--primary
							"
						>
							<?php
							echo esc_html(
								$is_editing
									? __(
										'Update Question',
										'tutorhelper-pro'
									)
									: __(
										'Add Question',
										'tutorhelper-pro'
									)
							);
							?>
						</button>

						<?php if ( $is_editing ) : ?>
							<a
								href="<?php
									echo esc_url(
										self::
											get_registration_url()
									);
								?>"
								class="
									button
									tutorhelper-admin-button
								"
							>
								<?php
								echo esc_html__(
									'Cancel',
									'tutorhelper-pro'
								);
								?>
							</a>
						<?php endif; ?>

					</div>

				</form>

			</div>
		</section>
		<?php
	}


	/**
	 * Process Add/Edit question submission.
	 *
	 * @return void
	 */
	public static function handle_save_question() {

		self::verify_admin_request();

		check_admin_referer(
			self::SAVE_QUESTION_ACTION
		);

		$question_id =
			isset(
				$_POST['question_id']
			)
				? absint(
					$_POST['question_id']
				)
				: 0;

		$data = array(
			'question_text' =>
				isset(
					$_POST['question_text']
				)
					? sanitize_text_field(
						wp_unslash(
							$_POST[
								'question_text'
							]
						)
					)
					: '',

			'question_type' =>
				isset(
					$_POST['question_type']
				)
					? sanitize_key(
						wp_unslash(
							$_POST[
								'question_type'
							]
						)
					)
					: TutorHelper_Pro_Onboarding::
						TYPE_SHORT_TEXT,

			'question_options' =>
				isset(
					$_POST['question_options']
				)
					? sanitize_textarea_field(
						wp_unslash(
							$_POST[
								'question_options'
							]
						)
					)
					: '',

			'is_required' =>
				isset(
					$_POST['is_required']
				)
					? 1
					: 0,

			'data_category' =>
				isset(
					$_POST['data_category']
				)
					? sanitize_key(
						wp_unslash(
							$_POST[
								'data_category'
							]
						)
					)
					: TutorHelper_Pro_Onboarding::
						DATA_STANDARD,

			/*
			 * New questions should be active. Existing
			 * question status is managed separately by
			 * archive/restore actions.
			 */
			'is_active' =>
				1,
		);

		if ( $question_id ) {

			$result =
				TutorHelper_Pro_Onboarding::
					update_question(
						$question_id,
						$data
					);

			$status =
				'updated';

		} else {

			$result =
				TutorHelper_Pro_Onboarding::
					create_question(
						$data
					);

			$status =
				'created';
		}

		if ( is_wp_error( $result ) ) {

			self::redirect_registration(
				'error',
				$result->
					get_error_code(),
				$question_id
			);
		}

		self::redirect_registration(
			$status
		);
	}


	/**
	 * Process archive/restore action.
	 *
	 * @return void
	 */
	public static function handle_question_status() {

		self::verify_admin_request();

		check_admin_referer(
			self::STATUS_QUESTION_ACTION
		);

		$question_id =
			isset(
				$_POST['question_id']
			)
				? absint(
					$_POST['question_id']
				)
				: 0;

		$status_action =
			isset(
				$_POST['status_action']
			)
				? sanitize_key(
					wp_unslash(
						$_POST[
							'status_action'
						]
					)
				)
				: '';

		if ( ! $question_id ) {
			self::redirect_registration(
				'error',
				'tutorhelper_onboarding_invalid_id'
			);
		}

		if (
			'archive'
			=== $status_action
		) {

			$result =
				TutorHelper_Pro_Onboarding::
					archive_question(
						$question_id
					);

			$status =
				'archived';

		} elseif (
			'restore'
			=== $status_action
		) {

			$result =
				TutorHelper_Pro_Onboarding::
					restore_question(
						$question_id
					);

			$status =
				'restored';

		} else {

			self::redirect_registration(
				'error',
				'tutorhelper_onboarding_invalid_status_action'
			);
		}

		if ( is_wp_error( $result ) ) {

            self::redirect_registration(
                'error',
                $result->
                    get_error_code(),
                $question_id
            );
        }

        if ( ! $result ) {

			self::redirect_registration(
				'error',
				'tutorhelper_onboarding_status_failed',
				$question_id
			);
		}

		self::redirect_registration(
			$status
		);
	}


	/**
	 * Save drag-and-drop question order.
	 *
	 * @return void
	 */
	public static function handle_reorder() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_send_json_error(
				array(
					'message' =>
						__(
							'You do not have permission to reorder onboarding questions.',
							'tutorhelper-pro'
						),
				),
				403
			);
		}

		check_ajax_referer(
			self::REORDER_ACTION,
			'nonce'
		);

		$question_ids =
			isset(
				$_POST['question_ids']
			)
			&& is_array(
				$_POST['question_ids']
			)
				? array_map(
					'absint',
					wp_unslash(
						$_POST[
							'question_ids'
						]
					)
				)
				: array();

		$result =
			TutorHelper_Pro_Onboarding::
				update_sort_order(
					$question_ids
				);

		if ( is_wp_error( $result ) ) {

			wp_send_json_error(
				array(
					'message' =>
						$result->
							get_error_message(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'message' =>
					__(
						'Question order saved.',
						'tutorhelper-pro'
					),
			)
		);
	}


	/**
	 * Verify a normal admin POST request.
	 *
	 * @return void
	 */
	private static function verify_admin_request() {

		if (
			current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		wp_die(
			esc_html__(
				'You do not have permission to manage student registrations.',
				'tutorhelper-pro'
			),
			esc_html__(
				'Permission denied',
				'tutorhelper-pro'
			),
			array(
				'response' =>
					403,
			)
		);
	}


	/**
	 * Redirect back to Registration Settings.
	 *
	 * @param string $status      Feedback status.
	 * @param string $error_code  Optional error code.
	 * @param int    $question_id Optional question to reopen.
	 *
	 * @return void
	 */
	private static function redirect_registration(
		$status,
		$error_code = '',
		$question_id = 0
	) {

		$args = array(
			'registration_status' =>
				sanitize_key(
					$status
				),
		);

		if ( $error_code ) {
			$args[
				'registration_error'
			] =
				sanitize_key(
					$error_code
				);
		}

		if (
			'error' === $status
			&& $question_id
		) {
			$args[
				'question_id'
			] =
				absint(
					$question_id
				);
		}

		wp_safe_redirect(
			self::get_registration_url(
				$args
			)
		);

		exit;
	}


    /**
     * Render registration and onboarding history
     * inside the Core Student detail screen.
     *
     * @param WP_User $student Student account.
     *
     * @return void
     */
    public static function render_student_registration_history(
        $student
    ) {

        if (
            ! $student instanceof WP_User
        ) {
            return;
        }

        $student_user_id =
            absint(
                $student->ID
            );

        $source =
            sanitize_key(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_registration_source',
                    true
                )
            );

        /*
        * Legacy/manually-created accounts may not have
        * TutorHelper registration history.
        */
        if (
            'student_registration'
            !== $source
        ) {
            ?>
            <section
                class="
                    tutorhelper-pro-student-registration
                "
            >
                <p>
                    <?php
                    echo esc_html__(
                        'No TutorHelper registration history is available for this student.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </section>
            <?php

            return;
        }

        $status =
            sanitize_key(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_registration_status',
                    true
                )
            );

        $type =
            sanitize_key(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_registration_type',
                    true
                )
            );

        $submitted_at =
            get_user_meta(
                $student_user_id,
                'tutorhelper_registration_submitted_at',
                true
            );

        $reviewed_at =
            get_user_meta(
                $student_user_id,
                'tutorhelper_registration_reviewed_at',
                true
            );

        $reviewed_by =
            absint(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_registration_reviewed_by',
                    true
                )
            );

        $reviewer =
            $reviewed_by
                ? get_userdata(
                    $reviewed_by
                )
                : null;

        $decision = sanitize_key(
            get_user_meta(
                $student_user_id,
                'tutorhelper_registration_decision',
                true
            )
        );

        $decided_at = get_user_meta(
            $student_user_id,
            'tutorhelper_registration_decided_at',
            true
        );

        $decided_by = absint(
            get_user_meta(
                $student_user_id,
                'tutorhelper_registration_decided_by',
                true
            )
        );

        $decision_reviewer = $decided_by ? get_userdata( $decided_by ) : null;

        $promoted_at = get_user_meta(
            $student_user_id,
            'tutorhelper_registration_promoted_at',
            true
        );

        $promoted_by = absint(
            get_user_meta(
                $student_user_id,
                'tutorhelper_registration_promoted_by',
                true
            )
        );

        $promotion_reviewer = $promoted_by ? get_userdata( $promoted_by ) : null;

        $privacy_at =
            get_user_meta(
                $student_user_id,
                'tutorhelper_privacy_acknowledged_at',
                true
            );

        $terms_at =
            get_user_meta(
                $student_user_id,
                'tutorhelper_terms_agreed_at',
                true
            );

        $marketing =
            1 === absint(
                get_user_meta(
                    $student_user_id,
                    'tutorhelper_marketing_opt_in',
                    true
                )
            );

        $answers =
            TutorHelper_Pro_Onboarding::
                get_answers_for_student(
                    $student_user_id
                );

        ?>
        <details
            class="
                tutorhelper-pro-student-registration
                tutorhelper-admin-disclosure
            "
        >
            <summary>
                <span
                    class="
                        dashicons
                        dashicons-id
                    "
                    aria-hidden="true"
                ></span>

                <span>
                    <strong>
                        <?php
                        echo esc_html__(
                            'Registration & Onboarding',
                            'tutorhelper-pro'
                        );
                        ?>
                    </strong>

                    <small>
                        <?php
                        echo esc_html__(
                            'View registration history and onboarding answers.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </small>
                </span>
            </summary>


            <div
                class="
                    tutorhelper-pro-student-registration__content
                "
            >

                <h4>
                    <?php
                    echo esc_html__(
                        'Registration',
                        'tutorhelper-pro'
                    );
                    ?>
                </h4>

                <dl
                    class="
                        tutorhelper-pro-student-registration__meta
                    "
                >
                    <div>
                        <dt>
                            <?php
                            echo esc_html__(
                                'Submitted',
                                'tutorhelper-pro'
                            );
                            ?>
                        </dt>

                        <dd>
                            <?php
                            echo esc_html(
                                $submitted_at
                                    ? $submitted_at
                                    : '—'
                            );
                            ?>
                        </dd>
                    </div>

                    <div>
                        <dt>
                            <?php
                            echo esc_html__(
                                'Type',
                                'tutorhelper-pro'
                            );
                            ?>
                        </dt>

                        <dd>
                            <?php
                            echo esc_html(
                                'waiting_list'
                                === $type
                                    ? __(
                                        'Waiting list',
                                        'tutorhelper-pro'
                                    )
                                    : __(
                                        'Student registration',
                                        'tutorhelper-pro'
                                    )
                            );
                            ?>
                        </dd>
                    </div>

                    <div>
                        <dt>
                            <?php
                            echo esc_html__(
                                'Status',
                                'tutorhelper-pro'
                            );
                            ?>
                        </dt>

                        <dd>
                            <?php
                            echo esc_html(
                                self::get_registration_status_label( $status )
                            );
                            ?>
                        </dd>
                    </div>

                    <div>
                        <dt>
                            <?php
                            echo esc_html__(
                                'Made Live',
                                'tutorhelper-pro'
                            );
                            ?>
                        </dt>

                        <dd>
                            <?php
                            echo esc_html(
                                $reviewed_at
                                    ? $reviewed_at
                                    : '—'
                            );
                            ?>
                        </dd>
                    </div>

                    <div>
                        <dt>
                            <?php
                            echo esc_html__(
                                'Made Live by',
                                'tutorhelper-pro'
                            );
                            ?>
                        </dt>

                        <dd>
                            <?php
                            echo esc_html(
                                $reviewer instanceof WP_User
                                    ? $reviewer->display_name
                                    : '—'
                            );
                            ?>
                        </dd>
                    </div>

                    <div>
                        <dt><?php esc_html_e( 'Initial decision', 'tutorhelper-pro' ); ?></dt>
                        <dd>
                            <?php
                            echo esc_html(
                                self::DECISION_WAITING_LIST === $decision
                                    ? __( 'Added to Waiting List', 'tutorhelper-pro' )
                                    : ( self::DECISION_LIVE === $decision ? __( 'Made Live', 'tutorhelper-pro' ) : '—' )
                            );
                            ?>
                        </dd>
                    </div>

                    <div>
                        <dt><?php esc_html_e( 'Decision recorded', 'tutorhelper-pro' ); ?></dt>
                        <dd><?php echo esc_html( $decided_at ? $decided_at : '—' ); ?></dd>
                    </div>

                    <div>
                        <dt><?php esc_html_e( 'Decision made by', 'tutorhelper-pro' ); ?></dt>
                        <dd><?php echo esc_html( $decision_reviewer instanceof WP_User ? $decision_reviewer->display_name : '—' ); ?></dd>
                    </div>

                    <?php if ( $promoted_at ) : ?>
                        <div>
                            <dt><?php esc_html_e( 'Promoted from waiting list', 'tutorhelper-pro' ); ?></dt>
                            <dd><?php echo esc_html( $promoted_at ); ?></dd>
                        </div>

                        <div>
                            <dt><?php esc_html_e( 'Promoted by', 'tutorhelper-pro' ); ?></dt>
                            <dd><?php echo esc_html( $promotion_reviewer instanceof WP_User ? $promotion_reviewer->display_name : '—' ); ?></dd>
                        </div>
                    <?php endif; ?>

                    <div>
                        <dt>
                            <?php
                            echo esc_html__(
                                'Marketing emails',
                                'tutorhelper-pro'
                            );
                            ?>
                        </dt>

                        <dd>
                            <?php
                            echo esc_html(
                                $marketing
                                    ? __(
                                        'Opted in',
                                        'tutorhelper-pro'
                                    )
                                    : __(
                                        'Not opted in',
                                        'tutorhelper-pro'
                                    )
                            );
                            ?>
                        </dd>
                    </div>
                </dl>


                <h4>
                    <?php
                    echo esc_html__(
                        'Onboarding answers',
                        'tutorhelper-pro'
                    );
                    ?>
                </h4>

                <?php if ( empty( $answers ) ) : ?>

                    <p>
                        <?php
                        echo esc_html__(
                            'No additional onboarding answers were submitted.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                <?php else : ?>

                    <dl
                        class="
                            tutorhelper-pro-student-registration__answers
                        "
                    >
                        <?php
                        foreach (
                            $answers
                            as $answer
                        ) :
                            ?>
                            <div>
                                <dt>
                                    <?php
                                    echo esc_html(
                                        $answer->
                                            question_text_snapshot
                                    );
                                    ?>
                                </dt>

                                <dd>
                                    <?php
                                    echo esc_html(
                                        $answer->answer
                                    );
                                    ?>
                                </dd>
                            </div>
                        <?php endforeach; ?>
                    </dl>

                <?php endif; ?>


                <h4>
                    <?php
                    echo esc_html__(
                        'Privacy & Terms',
                        'tutorhelper-pro'
                    );
                    ?>
                </h4>

                <dl
                    class="
                        tutorhelper-pro-student-registration__meta
                    "
                >
                    <div>
                        <dt>
                            <?php
                            echo esc_html__(
                                'Privacy acknowledged',
                                'tutorhelper-pro'
                            );
                            ?>
                        </dt>

                        <dd>
                            <?php
                            echo esc_html(
                                $privacy_at
                                    ? $privacy_at
                                    : '—'
                            );
                            ?>
                        </dd>
                    </div>

                    <div>
                        <dt>
                            <?php
                            echo esc_html__(
                                'Terms accepted',
                                'tutorhelper-pro'
                            );
                            ?>
                        </dt>

                        <dd>
                            <?php
                            echo esc_html(
                                $terms_at
                                    ? $terms_at
                                    : '—'
                            );
                            ?>
                        </dd>
                    </div>
                </dl>

            </div>
        </details>
        <?php
    }

    /**
     * Populate the Booking Hub registration summary.
     *
     * @param array $cards Booking Hub summary cards.
     *
     * @return array
     */
    public static function populate_booking_hub_summary(
        $cards
    ) {

        if (
            ! is_array( $cards )
            || ! isset(
                $cards[
                    'new_registrations'
                ]
            )
        ) {
            return $cards;
        }

        $count =
            self::get_new_registration_count();

        $cards[
            'new_registrations'
        ][
            'value'
        ] = $count;

        $cards[
            'new_registrations'
        ][
            'status'
        ] = 'available';

        $cards[
            'new_registrations'
        ][
            'description'
        ] = __(
            'Awaiting review',
            'tutorhelper-pro'
        );

        $cards[
            'new_registrations'
        ][
            'url'
        ] =
            self::get_registration_url();

        return $cards;
    }


}
