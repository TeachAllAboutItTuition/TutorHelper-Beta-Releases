<?php
/**
 * TutorHelper Pro public student registration form.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the public Student Registration shortcode.
 */
final class TutorHelper_Pro_Registration_Frontend {

	/**
	 * Registration shortcode.
	 *
	 * @var string
	 */
	const SHORTCODE =
		'tutorhelper_registration';

	/**
	 * Front-end stylesheet handle.
	 *
	 * @var string
	 */
	const STYLE_HANDLE =
		'tutorhelper-pro-registration';

    /**
     * Front-end script handle.
     *
     * @var string
     */
    const SCRIPT_HANDLE =
        'tutorhelper-pro-registration';

	/**
	 * Initialise public registration functionality.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'wp_enqueue_scripts',
			array(
				__CLASS__,
				'maybe_enqueue_assets',
			)
		);

		add_shortcode(
			self::SHORTCODE,
			array(
				__CLASS__,
				'render_shortcode',
			)
		);
	}


	/**
	 * Enqueue registration assets before the page header is printed.
	 *
	 * Shortcodes are normally rendered after wp_head(), which is too late for
	 * a newly enqueued stylesheet. Detect the configured shortcode in the
	 * queried page content so its assets are available in the document head.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_assets() {
		if ( ! is_singular() ) {
			return;
		}

		$page_id = get_queried_object_id();

		if ( ! $page_id ) {
			return;
		}

		$content = get_post_field(
			'post_content',
			$page_id
		);

		if (
			! is_string( $content )
			|| ! has_shortcode(
				$content,
				self::SHORTCODE
			)
		) {
			return;
		}

		self::enqueue_assets();
	}


	/**
	 * Render Student Registration shortcode.
	 *
	 * @return string
	 */
	public static function render_shortcode() {

		$status =
			TutorHelper_Pro_Registration_Settings::
				get_status();

		self::enqueue_assets();

		$privacy_url =
			TutorHelper_Settings::get_privacy_url();

		$terms_url = (string) apply_filters(
			'tutorhelper_registration_terms_url',
			TutorHelper_Settings::get_terms_url()
		);

		if ( ! $privacy_url || ! $terms_url ) {
			return '<div class="tutorhelper-pro-registration"><div class="tutorhelper-pro-registration__notice tutorhelper-pro-registration__notice--error" role="alert">'
				. esc_html__(
					'Registration is temporarily unavailable because the Privacy Policy and Terms and Conditions pages have not both been configured.',
					'tutorhelper-pro'
				)
				. '</div></div>';
		}

		ob_start();

		?>
		<div class="tutorhelper-pro-registration">

            <?php
            if (
                self::is_registration_complete()
            ) {

                self::render_success();

            } elseif (
                TutorHelper_Pro_Registration_Settings::
                    STATUS_CLOSED
                === $status
            ) {

                self::render_closed();

            } else {

                self::render_submission_notice();

                self::render_registration_form(
                    $status
                );
            }
            ?>

        </div>

        <?php
        self::render_submission_notice();
        ?>

		<?php

		return ob_get_clean();
	}


    /**
     * Determine whether a registration has just completed.
     *
     * @return bool
     */
    private static function is_registration_complete() {

        $status =
            isset(
                $_GET[
                    'tutorhelper_registration'
                ]
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_registration'
                        ]
                    )
                )
                : '';

        return 'created' === $status;
    }


    /**
     * Render successful registration confirmation.
     *
     * @return void
     */
    private static function render_success() {

        ?>
        <section
            class="
                tutorhelper-pro-registration__panel
                tutorhelper-pro-registration__success
            "
            role="status"
        >
            <div
                class="
                    tutorhelper-pro-registration__success-content
                "
            >
                <span
                    class="
                        tutorhelper-pro-registration__success-icon
                    "
                    aria-hidden="true"
                >
                    ✓
                </span>

                <h2>
                    <?php
                    echo esc_html__(
                        'Registration submitted',
                        'tutorhelper-pro'
                    );
                    ?>
                </h2>

                <p>
                    <?php
                    echo esc_html__(
                        'Your registration has been submitted successfully.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

                <p>
                    <?php
                    echo esc_html__(
                        'Please check your email for instructions to set up your student account password.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

                <p>
                    <?php
                    echo esc_html__(
                        'Your tutor will review your registration before lesson booking is enabled.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

                <p
                    class="
                        tutorhelper-pro-registration__success-help
                    "
                >
                    <?php
                    echo esc_html__(
                        'If the email does not arrive within a few minutes, please check your spam or junk folder.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </div>
        </section>
        <?php
    }



    /**
     * Render temporary registration submission feedback.
     *
     * @return void
     */
    private static function render_submission_notice() {

        $status =
            isset(
                $_GET[
                    'tutorhelper_registration'
                ]
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_registration'
                        ]
                    )
                )
                : '';

        if ( ! $status ) {
            return;
        }

        if ( 'created' === $status ) {

            ?>
            <div
                class="
                    tutorhelper-pro-registration__notice
                    tutorhelper-pro-registration__notice--success
                "
                role="status"
            >
                <?php
                echo esc_html__(
                    'Your registration has been submitted. Please check your email for instructions to set up your student account password. If an email does not reach you in a few minutes, please check your spam folder.',
                    'tutorhelper-pro'
                );
                ?>
            </div>
            <?php

            return;
        }

        if ( 'error' !== $status ) {
            return;
        }

        $error =
            isset(
                $_GET[
                    'tutorhelper_registration_error'
                ]
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_registration_error'
                        ]
                    )
                )
                : '';

        $messages = array(
            'invalid_request' =>
                __(
                    'The registration request could not be processed. Please reload the page and try again.',
                    'tutorhelper-pro'
                ),

            'invalid_nonce' =>
                __(
                    'This registration form has expired. Please reload the page and try again.',
                    'tutorhelper-pro'
                ),

            'registrations_closed' =>
                __(
                    'Student registrations are no longer available.',
                    'tutorhelper-pro'
                ),

            'rate_limited' =>
                __(
                    'Too many registration attempts have been made. Please wait before trying again.',
                    'tutorhelper-pro'
                ),

            'request_rejected' =>
                __(
                    'The registration could not be submitted. Please reload the page and try again.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_registration_required_field' =>
                __(
                    'Please complete all required account fields.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_registration_invalid_email' =>
                __(
                    'Please enter a valid student email address.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_registration_email_exists' =>
                __(
                    'An account already exists for this email address. Please use the existing account or contact your tutor.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_registration_invalid_dob' =>
                __(
                    'Please enter a valid date of birth.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_onboarding_required_answer' =>
                __(
                    'Please answer all required onboarding questions.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_onboarding_invalid_option' =>
                __(
                    'One of the submitted onboarding answers is no longer valid. Please reload the page and try again.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_registration_invalid_question' =>
                __(
                    'The registration questions have changed. Please reload the page and try again.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_registration_consent_required' =>
                __(
                    'Please review and accept the required privacy and tuition terms.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_registration_account_failed' =>
                __(
                    'The student account could not be created. Please try again or contact your tutor.',
                    'tutorhelper-pro'
                ),
        );

        $message =
            isset(
                $messages[
                    $error
                ]
            )
                ? $messages[
                    $error
                ]
                : __(
                    'The registration could not be submitted.',
                    'tutorhelper-pro'
                );

        ?>
        <div
            class="
                tutorhelper-pro-registration__notice
                tutorhelper-pro-registration__notice--error
            "
            role="alert"
        >
            <?php
            echo esc_html(
                $message
            );
            ?>
        </div>
        <?php
    }



    /**
     * Return the current front-end page URL.
     *
     * @return string
     */
    private static function get_current_page_url() {

        $page_id =
            get_queried_object_id();

        if ( $page_id ) {

            $url =
                get_permalink(
                    $page_id
                );

            if ( $url ) {
                return $url;
            }
        }

        return home_url(
            '/'
        );
    }


	/**
	 * Enqueue registration assets.
	 *
	 * @return void
	 */
	private static function enqueue_assets() {

		$style_path =
			TUTORHELPER_PRO_PATH
			. 'assets/css/'
			. 'tutorhelper-pro-registration.css';

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL
				. 'assets/css/'
				. 'tutorhelper-pro-registration.css',
			array(),
			file_exists( $style_path )
				? (string) filemtime(
					$style_path
				)
				: TUTORHELPER_PRO_VERSION
		);

		$branding =
			TutorHelper_Pro_Branding::get_all();

		if (
			! empty(
				$branding['registration_form_branding']
			)
		) {
			wp_add_inline_style(
				self::STYLE_HANDLE,
				TutorHelper_Pro_Booking_Branding::
					build_branding_css(
						$branding,
						'.tutorhelper-pro-registration'
					)
			);
		}

        $script_path =
            TUTORHELPER_PRO_PATH
            . 'assets/js/'
            . 'tutorhelper-pro-registration.js';

        wp_enqueue_script(
            self::SCRIPT_HANDLE,
            TUTORHELPER_PRO_URL
                . 'assets/js/'
                . 'tutorhelper-pro-registration.js',
            array(),
            file_exists( $script_path )
                ? (string) filemtime(
                    $script_path
                )
                : TUTORHELPER_PRO_VERSION,
            true
        );

	}


	/**
	 * Render registration-closed message.
	 *
	 * @return void
	 */
	private static function render_closed() {

		?>
		<section
			class="
				tutorhelper-pro-registration__message
				tutorhelper-pro-registration__message--closed
			"
		>
			<h2>
				<?php
				echo esc_html__(
					'Student registrations are currently closed',
					'tutorhelper-pro'
				);
				?>
			</h2>

			<p>
				<?php
				echo esc_html__(
					'New registrations and waiting-list applications are not currently being accepted.',
					'tutorhelper-pro'
				);
				?>
			</p>
		</section>
		<?php
	}


	/**
     * Render registration form.
     *
     * @param string $status Registration availability.
     *
     * @return void
     */
    private static function render_registration_form(
        $status
    ) {

        $questions =
            TutorHelper_Pro_Onboarding::
                get_questions(
                    true
                );

        $system_questions =
            array_filter(
                $questions,
                static function ( $question ) {
                    return ! empty(
                        $question->is_system
                    );
                }
            );

        $custom_questions =
            array_filter(
                $questions,
                static function ( $question ) {
                    return empty(
                        $question->is_system
                    );
                }
            );

        $is_waiting_list =
            TutorHelper_Pro_Registration_Settings::
                STATUS_WAITING_LIST
            === $status;

        $privacy_url =
            TutorHelper_Settings::get_privacy_url();

        /*
        * The Terms URL can be connected to a dedicated TutorHelper
        * setting later without changing the registration form.
        */
        $terms_url =
            apply_filters(
                'tutorhelper_registration_terms_url',
                TutorHelper_Settings::get_terms_url()
            );

        ?>

        <section
            class="
                tutorhelper-pro-registration__panel
            "
        >

            <header
                class="
                    tutorhelper-pro-registration__header
                "
            >
                <h2>
                    <?php
                    echo esc_html(
                        $is_waiting_list
                            ? __(
                                'Join the waiting list',
                                'tutorhelper-pro'
                            )
                            : __(
                                'Student registration',
                                'tutorhelper-pro'
                            )
                    );
                    ?>
                </h2>

                <p>
                    <?php
                    echo esc_html(
                        $is_waiting_list
                            ? __(
                                'Current tuition places are full, but you can complete this form to join the waiting list.',
                                'tutorhelper-pro'
                            )
                            : __(
                                'Complete the form below to create your student account.',
                                'tutorhelper-pro'
                            )
                    );
                    ?>
                </p>
            </header>


            <form
                class="
                    tutorhelper-pro-registration__form
                "
                method="post"
                action="<?php
                    echo esc_url(
                        admin_url(
                            'admin-post.php'
                        )
                    );
                ?>"
                data-registration-form
            >

                <input
                    type="hidden"
                    name="action"
                    value="<?php
                        echo esc_attr(
                            TutorHelper_Pro_Registration_Handler::
                                ACTION
                        );
                    ?>"
                />

                <?php
                wp_nonce_field(
                    TutorHelper_Pro_Registration_Handler::
                        NONCE_ACTION,
                    TutorHelper_Pro_Registration_Handler::
                        NONCE_NAME
                );
                ?>

                <input
                    type="hidden"
                    name="tutorhelper_return_url"
                    value="<?php
                        echo esc_url(
                            self::get_current_page_url()
                        );
                    ?>"
                />

                <input
                    type="hidden"
                    name="tutorhelper_registration_started"
                    value="<?php
                        echo esc_attr(
                            time()
                        );
                    ?>"
                />


                <div
                    class="
                        tutorhelper-pro-registration__honeypot
                    "
                    aria-hidden="true"
                >
                    <label
                        for="
                            tutorhelper-registration-website
                        "
                    >
                        <?php
                        echo esc_html__(
                            'Website',
                            'tutorhelper-pro'
                        );
                        ?>
                    </label>

                    <input
                        type="text"
                        id="
                            tutorhelper-registration-website
                        "
                        name="tutorhelper_website"
                        value=""
                        tabindex="-1"
                        autocomplete="off"
                    />
                </div>


                <nav
                    class="
                        tutorhelper-pro-registration__progress
                    "
                    aria-label="<?php
                        echo esc_attr__(
                            'Registration progress',
                            'tutorhelper-pro'
                        );
                    ?>"
                >
                    <ol>

                        <li
                            class="is-active"
                            data-step-indicator="1"
                            aria-current="step"
                        >
                            <span aria-hidden="true">
                                1
                            </span>

                            <?php
                            echo esc_html__(
                                'Account details',
                                'tutorhelper-pro'
                            );
                            ?>
                        </li>


                        <li
                            data-step-indicator="2"
                        >
                            <span aria-hidden="true">
                                2
                            </span>

                            <?php
                            echo esc_html__(
                                'About you',
                                'tutorhelper-pro'
                            );
                            ?>
                        </li>


                        <li
                            data-step-indicator="3"
                        >
                            <span aria-hidden="true">
                                3
                            </span>

                            <?php
                            echo esc_html__(
                                'Privacy',
                                'tutorhelper-pro'
                            );
                            ?>
                        </li>

                    </ol>
                </nav>


                <section
                    class="
                        tutorhelper-pro-registration__step
                        is-active
                    "
                    data-registration-step="1"
                >

                    <div
                        class="
                            tutorhelper-pro-registration__section
                        "
                    >
                        <h3>
                            <?php
                            echo esc_html__(
                                'Student account details',
                                'tutorhelper-pro'
                            );
                            ?>
                        </h3>

                        <p
                            class="
                                tutorhelper-pro-registration__section-intro
                            "
                        >
                            <?php
                            echo esc_html__(
                                'Enter the details that will be used to create the student account.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </p>

                        <div
                            class="
                                tutorhelper-pro-registration__fields
                            "
                        >
                            <?php
                            foreach (
                                $system_questions
                                as $question
                            ) {
                                self::render_system_field(
                                    $question
                                );
                            }
                            ?>
                        </div>
                    </div>


                    <div
                        class="
                            tutorhelper-pro-registration__step-actions
                        "
                    >
                        <button
                            type="button"
                            class="
                                tutorhelper-pro-registration__next
                            "
                            data-registration-next
                        >
                            <?php
                            echo esc_html__(
                                'Continue',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>
                    </div>

                </section>


                <section
                    class="
                        tutorhelper-pro-registration__step
                    "
                    data-registration-step="2"
                    hidden
                >

                    <div
                        class="
                            tutorhelper-pro-registration__section
                        "
                    >
                        <h3>
                            <?php
                            echo esc_html__(
                                'About the student',
                                'tutorhelper-pro'
                            );
                            ?>
                        </h3>

                        <p
                            class="
                                tutorhelper-pro-registration__section-intro
                            "
                        >
                            <?php
                            echo esc_html__(
                                'Please answer the following questions to help the tutor prepare for tuition.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </p>


                        <?php if (
                            ! empty(
                                $custom_questions
                            )
                        ) : ?>

                            <div
                                class="
                                    tutorhelper-pro-registration__fields
                                "
                            >
                                <?php
                                foreach (
                                    $custom_questions
                                    as $question
                                ) {
                                    self::render_custom_field(
                                        $question
                                    );
                                }
                                ?>
                            </div>

                        <?php else : ?>

                            <p>
                                <?php
                                echo esc_html__(
                                    'There are no additional questions to complete.',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </p>

                        <?php endif; ?>

                    </div>


                    <div
                        class="
                            tutorhelper-pro-registration__step-actions
                        "
                    >
                        <button
                            type="button"
                            class="
                                tutorhelper-pro-registration__back
                            "
                            data-registration-back
                        >
                            <?php
                            echo esc_html__(
                                'Back',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>

                        <button
                            type="button"
                            class="
                                tutorhelper-pro-registration__next
                            "
                            data-registration-next
                        >
                            <?php
                            echo esc_html__(
                                'Continue',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>
                    </div>

                </section>


                <section
                    class="
                        tutorhelper-pro-registration__step
                    "
                    data-registration-step="3"
                    hidden
                >

                    <div
                        class="
                            tutorhelper-pro-registration__section
                        "
                    >
                        <h3>
                            <?php
                            echo esc_html__(
                                'Privacy and communications',
                                'tutorhelper-pro'
                            );
                            ?>
                        </h3>

                        <p
                            class="
                                tutorhelper-pro-registration__section-intro
                            "
                        >
                            <?php
                            echo esc_html__(
                                'Please review how your information will be used before completing your registration.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </p>


                        <div
                            class="
                                tutorhelper-pro-registration__privacy-options
                            "
                        >

                            <label
                                class="
                                    tutorhelper-pro-registration__consent
                                "
                            >
                                <input
                                    type="checkbox"
                                    name="privacy_acknowledged"
                                    value="1"
                                    required
                                />

                                <span>
                                    <strong>
                                        <?php
                                        echo esc_html__(
                                            'Privacy notice',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </strong>

                                    <span>
                                        <?php
                                        echo esc_html__(
                                            'I have read and understood the privacy information explaining how my personal information will be used.',
                                            'tutorhelper-pro'
                                        );
                                        ?>

                                        <?php if (
                                            $privacy_url
                                        ) : ?>

                                            <a
                                                href="<?php
                                                    echo esc_url(
                                                        $privacy_url
                                                    );
                                                ?>"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                            >
                                                <?php
                                                echo esc_html__(
                                                    'View privacy policy',
                                                    'tutorhelper-pro'
                                                );
                                                ?>
                                            </a>

                                        <?php endif; ?>
                                    </span>
                                </span>
                            </label>


                            <label
                                class="
                                    tutorhelper-pro-registration__consent
                                "
                            >
                                <input
                                    type="checkbox"
                                    name="terms_agreed"
                                    value="1"
                                    required
                                />

                                <span>
                                    <strong>
                                        <?php
                                        echo esc_html__(
                                            'Terms of tuition',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </strong>

                                    <span>
                                        <?php
                                        echo esc_html__(
                                            'I agree to the terms and conditions that apply to tuition and use of the student account.',
                                            'tutorhelper-pro'
                                        );
                                        ?>

                                        <?php if (
                                            $terms_url
                                        ) : ?>

                                            <a
                                                href="<?php
                                                    echo esc_url(
                                                        $terms_url
                                                    );
                                                ?>"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                            >
                                                <?php
                                                echo esc_html__(
                                                    'View terms',
                                                    'tutorhelper-pro'
                                                );
                                                ?>
                                            </a>

                                        <?php endif; ?>
                                    </span>
                                </span>
                            </label>


                            <label
                                class="
                                    tutorhelper-pro-registration__consent
                                    tutorhelper-pro-registration__consent--optional
                                "
                            >
                                <input
                                    type="checkbox"
                                    name="marketing_opt_in"
                                    value="1"
                                />

                                <span>
                                    <strong>
                                        <?php
                                        echo esc_html__(
                                            'News and updates',
                                            'tutorhelper-pro'
                                        );
                                        ?>

                                        <span
                                            class="
                                                tutorhelper-pro-registration__optional
                                            "
                                        >
                                            <?php
                                            echo esc_html__(
                                                'Optional',
                                                'tutorhelper-pro'
                                            );
                                            ?>
                                        </span>
                                    </strong>

                                    <span>
                                        <?php
                                        echo esc_html__(
                                            'I would like to receive occasional news, updates and relevant information by email. I understand that I can unsubscribe at any time.',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </span>
                                </span>
                            </label>

                        </div>
                    </div>


                    <div
                        class="
                            tutorhelper-pro-registration__step-actions
                        "
                    >
                        <button
                            type="button"
                            class="
                                tutorhelper-pro-registration__back
                            "
                            data-registration-back
                        >
                            <?php
                            echo esc_html__(
                                'Back',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>


                        <button
                            type="submit"
                            class="
                                tutorhelper-pro-registration__submit
                            "
                            
                        >
                            <?php
                            echo esc_html(
                                $is_waiting_list
                                    ? __(
                                        'Join Waiting List',
                                        'tutorhelper-pro'
                                    )
                                    : __(
                                        'Complete Registration',
                                        'tutorhelper-pro'
                                    )
                            );
                            ?>
                        </button>
                    </div>



                </section>

            </form>

        </section>

        <?php
    }


    /**
     * Render a TutorHelper system registration field.
     *
     * @param object $question Question definition.
     *
     * @return void
     */
    private static function render_system_field(
        $question
    ) {

        $key =
            sanitize_key(
                $question->question_key
            );

        $type =
            sanitize_key(
                $question->question_type
            );

        $required =
            ! empty(
                $question->is_required
            );

        $field_class =
            'tutorhelper-pro-registration__field';

        $autocomplete = '';

        switch ( $key ) {

            case TutorHelper_Pro_Onboarding::
                QUESTION_STUDENT_FIRST_NAME:
                $autocomplete =
                    'given-name';
                break;

            case TutorHelper_Pro_Onboarding::
                QUESTION_STUDENT_LAST_NAME:
                $autocomplete =
                    'family-name';
                break;

            case TutorHelper_Pro_Onboarding::
                QUESTION_STUDENT_EMAIL:
                $autocomplete =
                    'email';
                break;

            case TutorHelper_Pro_Onboarding::
                QUESTION_ADDRESS_1:
                $autocomplete =
                    'address-line1';
                break;

            case TutorHelper_Pro_Onboarding::
                QUESTION_ADDRESS_2:
                $autocomplete =
                    'address-line2';
                break;

            case TutorHelper_Pro_Onboarding::
                QUESTION_CITY:
                $autocomplete =
                    'address-level2';
                break;

            case TutorHelper_Pro_Onboarding::
                QUESTION_COUNTY:
                $autocomplete =
                    'address-level1';
                break;

            case TutorHelper_Pro_Onboarding::
                QUESTION_POSTCODE:
                $autocomplete =
                    'postal-code';
                break;

            case TutorHelper_Pro_Onboarding::
                QUESTION_COUNTRY:
                $autocomplete =
                    'country-name';
                break;
        }

        /*
        * Give address line 1 and 2 full width.
        */
        if (
            in_array(
                $key,
                array(
                    TutorHelper_Pro_Onboarding::
                        QUESTION_ADDRESS_1,

                    TutorHelper_Pro_Onboarding::
                        QUESTION_ADDRESS_2,
                ),
                true
            )
        ) {
            $field_class .=
                ' is-full-width';
        }

        ?>
        <div class="<?php echo esc_attr( $field_class ); ?>">

            <label
                for="tutorhelper-registration-<?php
                    echo esc_attr(
                        $key
                    );
                ?>"
            >
                <?php
                echo esc_html(
                    $question->
                        question_text
                );
                ?>

                <?php if ( $required ) : ?>
                    <span
                        class="
                            tutorhelper-pro-registration__required
                        "
                        aria-hidden="true"
                    >*</span>
                <?php endif; ?>
            </label>

            <?php
            if (
                TutorHelper_Pro_Onboarding::
                    TYPE_DATE
                === $type
            ) :
                ?>

                <input
                    type="date"
                    id="tutorhelper-registration-<?php
                        echo esc_attr(
                            $key
                        );
                    ?>"
                    name="system_fields[<?php
                        echo esc_attr(
                            $key
                        );
                    ?>]"
                    <?php if ( $required ) : ?>
                        required
                    <?php endif; ?>
                />

            <?php elseif (
                TutorHelper_Pro_Onboarding::
                    TYPE_EMAIL
                === $type
            ) :
                ?>

                <input
                    type="email"
                    id="tutorhelper-registration-<?php
                        echo esc_attr(
                            $key
                        );
                    ?>"
                    name="system_fields[<?php
                        echo esc_attr(
                            $key
                        );
                    ?>]"
                    <?php if ( $autocomplete ) : ?>
                        autocomplete="<?php
                            echo esc_attr(
                                $autocomplete
                            );
                        ?>"
                    <?php endif; ?>
                    <?php if ( $required ) : ?>
                        required
                    <?php endif; ?>
                    ?>
                

            <?php else : ?>

                <input
                    type="text"
                    id="tutorhelper-registration-<?php
                        echo esc_attr(
                            $key
                        );
                    ?>"
                    <?php if ( $autocomplete ) : ?>
                        autocomplete="<?php
                            echo esc_attr(
                                $autocomplete
                            );
                        ?>"
                    <?php endif; ?>
                    name="system_fields[<?php
                        echo esc_attr(
                            $key
                        );
                    ?>]"
                    <?php if ( $required ) : ?>
                        required
                    <?php endif; ?>
                />

            <?php endif; ?>

        </div>
        <?php
    }



    /**
     * Render one tutor-created onboarding question.
     *
     * @param object $question Question definition.
     *
     * @return void
     */
    private static function render_custom_field(
        $question
    ) {

        $question_id =
            absint(
                $question->id
            );

        $type =
            sanitize_key(
                $question->question_type
            );

        $required =
            ! empty(
                $question->is_required
            );

        $options =
            TutorHelper_Pro_Onboarding::
                get_question_options(
                    $question
                );

        ?>
        <div
            class="
                tutorhelper-pro-registration__field
                <?php
                echo
                    TutorHelper_Pro_Onboarding::
                        TYPE_PARAGRAPH
                    === $type
                        ? 'is-full-width'
                        : '';
                ?>
            "
        >

            <label
                for="tutorhelper-registration-question-<?php
                    echo esc_attr(
                        $question_id
                    );
                ?>"
            >
                <?php
                echo esc_html(
                    $question->
                        question_text
                );
                ?>

                <?php if ( $required ) : ?>
                    <span
                        class="
                            tutorhelper-pro-registration__required
                        "
                        aria-hidden="true"
                    >*</span>
                <?php endif; ?>
            </label>


            <?php if (
                TutorHelper_Pro_Onboarding::
                    TYPE_PARAGRAPH
                === $type
            ) : ?>

                <textarea
                    id="tutorhelper-registration-question-<?php
                        echo esc_attr(
                            $question_id
                        );
                    ?>"
                    name="onboarding[<?php
                        echo esc_attr(
                            $question_id
                        );
                    ?>]"
                    rows="5"
                    <?php if ( $required ) : ?>
                        required
                    <?php endif; ?>
                ></textarea>


            <?php elseif (
                TutorHelper_Pro_Onboarding::
                    TYPE_DROPDOWN
                === $type
            ) : ?>

                <select
                    id="tutorhelper-registration-question-<?php
                        echo esc_attr(
                            $question_id
                        );
                    ?>"
                    name="onboarding[<?php
                        echo esc_attr(
                            $question_id
                        );
                    ?>]"
                    <?php if ( $required ) : ?>
                        required
                    <?php endif; ?>
                >
                    <option value="">
                        <?php
                        echo esc_html__(
                            'Please select...',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <?php foreach (
                        $options
                        as $option
                    ) :
                        ?>
                        <option
                            value="<?php
                                echo esc_attr(
                                    $option
                                );
                            ?>"
                        >
                            <?php
                            echo esc_html(
                                $option
                            );
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>


            <?php elseif (
                TutorHelper_Pro_Onboarding::
                    TYPE_CHECKBOX
                === $type
            ) : ?>

                <fieldset
                    class="
                        tutorhelper-pro-registration__checkbox-group
                    "
                >
                    <legend class="screen-reader-text">
                        <?php
                        echo esc_html(
                            $question->
                                question_text
                        );
                        ?>
                    </legend>

                    <?php foreach (
                        $options
                        as $index => $option
                    ) :
                        ?>

                        <label
                            for="tutorhelper-registration-question-<?php
                                echo esc_attr(
                                    $question_id
                                    . '-'
                                    . $index
                                );
                            ?>"
                        >
                            <input
                                type="checkbox"
                                id="tutorhelper-registration-question-<?php
                                    echo esc_attr(
                                        $question_id
                                        . '-'
                                        . $index
                                    );
                                ?>"
                                name="onboarding[<?php
                                    echo esc_attr(
                                        $question_id
                                    );
                                ?>][]"
                                value="<?php
                                    echo esc_attr(
                                        $option
                                    );
                                ?>"
                            />

                            <span>
                                <?php
                                echo esc_html(
                                    $option
                                );
                                ?>
                            </span>
                        </label>

                    <?php endforeach; ?>

                </fieldset>


            <?php else : ?>

                <input
                    type="text"
                    id="tutorhelper-registration-question-<?php
                        echo esc_attr(
                            $question_id
                        );
                    ?>"
                    name="onboarding[<?php
                        echo esc_attr(
                            $question_id
                        );
                    ?>]"
                    <?php if ( $required ) : ?>
                        required
                    <?php endif; ?>
                />

            <?php endif; ?>

        </div>
        <?php
    }

}
