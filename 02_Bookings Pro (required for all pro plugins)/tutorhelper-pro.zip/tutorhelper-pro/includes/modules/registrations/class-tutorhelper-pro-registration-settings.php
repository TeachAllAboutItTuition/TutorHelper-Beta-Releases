<?php
/**
 * TutorHelper Pro registration settings.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and validates Student Registration settings.
 */
final class TutorHelper_Pro_Registration_Settings {

	/**
	 * Registration status option.
	 *
	 * @var string
	 */
	const OPTION_STATUS =
		'tutorhelper_pro_registration_status';

	/**
	 * Registration status values.
	 */
	const STATUS_OPEN =
		'open';

	const STATUS_WAITING_LIST =
		'waiting_list';

	const STATUS_CLOSED =
		'closed';


	/**
	 * Return supported registration statuses.
	 *
	 * @return array
	 */
	public static function get_statuses() {

		return array(
			self::STATUS_OPEN =>
				array(
					'label' =>
						__(
							'Registrations are open',
							'tutorhelper-pro'
						),

					'description' =>
						__(
							'New students can complete the registration form and join your tuition service.',
							'tutorhelper-pro'
						),
				),

			self::STATUS_WAITING_LIST =>
				array(
					'label' =>
						__(
							'Waiting list only',
							'tutorhelper-pro'
						),

					'description' =>
						__(
							'Current classes are full, but students can still register to join your waiting list.',
							'tutorhelper-pro'
						),
				),

			self::STATUS_CLOSED =>
				array(
					'label' =>
						__(
							'Registrations are closed',
							'tutorhelper-pro'
						),

					'description' =>
						__(
							'New registrations and waiting-list applications are currently unavailable.',
							'tutorhelper-pro'
						),
				),
		);
	}


	/**
	 * Return the current registration status.
	 *
	 * @return string
	 */
	public static function get_status() {

		$status =
			sanitize_key(
				get_option(
					self::OPTION_STATUS,
					self::STATUS_OPEN
				)
			);

		if (
			! array_key_exists(
				$status,
				self::get_statuses()
			)
		) {
			return self::STATUS_OPEN;
		}

		return $status;
	}


	/**
	 * Save registration status.
	 *
	 * @param string $status Submitted status.
	 *
	 * @return true|WP_Error
	 */
	public static function update_status(
		$status
	) {

		$status =
			sanitize_key(
				$status
			);

		if (
			! array_key_exists(
				$status,
				self::get_statuses()
			)
		) {
			return new WP_Error(
				'tutorhelper_registration_invalid_status',
				__(
					'The registration status is invalid.',
					'tutorhelper-pro'
				)
			);
		}

		update_option(
			self::OPTION_STATUS,
			$status,
			false
		);

		return true;
	}
}
