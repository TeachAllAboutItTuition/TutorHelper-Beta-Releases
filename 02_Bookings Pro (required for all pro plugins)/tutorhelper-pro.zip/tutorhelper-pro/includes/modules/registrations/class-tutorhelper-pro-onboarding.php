<?php
/**
 * TutorHelper Pro onboarding questions and answers.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides configurable student onboarding questions.
 */
final class TutorHelper_Pro_Onboarding {

	/**
	 * Short text question.
	 *
	 * @var string
	 */
	const TYPE_SHORT_TEXT = 'short_text';

	/**
	 * Paragraph question.
	 *
	 * @var string
	 */
	const TYPE_PARAGRAPH = 'paragraph';

	/**
	 * Checkbox question.
	 *
	 * @var string
	 */
	const TYPE_CHECKBOX = 'checkbox';

	/**
	 * Dropdown question.
	 *
	 * @var string
	 */
	const TYPE_DROPDOWN = 'dropdown';

	/**
	 * Standard personal information.
	 *
	 * @var string
	 */
	const DATA_STANDARD = 'standard';

	/**
	 * Potentially sensitive personal information.
	 *
	 * @var string
	 */
	const DATA_SENSITIVE = 'sensitive';

	/**
	 * GDPR special-category information.
	 *
	 * @var string
	 */
	const DATA_SPECIAL_CATEGORY = 'special_category';

    /**
     * Email-address system field.
     *
     * @var string
     */
    const TYPE_EMAIL = 'email';

    /**
     * Date system field.
     *
     * @var string
     */
    const TYPE_DATE = 'date';


    /**
     * Locked system question keys.
     */
    const QUESTION_STUDENT_FIRST_NAME =
        'student_first_name';

    const QUESTION_STUDENT_LAST_NAME =
        'student_last_name';

    const QUESTION_STUDENT_EMAIL =
        'student_email';

    const QUESTION_DATE_OF_BIRTH =
        'student_date_of_birth';

    const QUESTION_ADDRESS_1 =
        'student_address_1';

    const QUESTION_ADDRESS_2 =
        'student_address_2';

    const QUESTION_CITY =
        'student_city';

    const QUESTION_COUNTY =
        'student_county';

    const QUESTION_POSTCODE =
        'student_postcode';

    const QUESTION_COUNTRY =
        'student_country';



	/**
	 * Return the questions table name.
	 *
	 * @return string
	 */
	public static function questions_table_name() {
		return TutorHelper_Pro_Database::get_table_name(
			'onboarding_questions'
		);
	}


	/**
	 * Return the answers table name.
	 *
	 * @return string
	 */
	public static function answers_table_name() {
		return TutorHelper_Pro_Database::get_table_name(
			'onboarding_answers'
		);
	}


	/**
	 * Return supported question types.
	 *
	 * @return array
	 */
	public static function get_question_types() {

        return array(
            self::TYPE_SHORT_TEXT =>
                __(
                    'Short answer',
                    'tutorhelper-pro'
                ),

            self::TYPE_PARAGRAPH =>
                __(
                    'Paragraph',
                    'tutorhelper-pro'
                ),

            self::TYPE_CHECKBOX =>
                __(
                    'Checkboxes',
                    'tutorhelper-pro'
                ),

            self::TYPE_DROPDOWN =>
                __(
                    'Dropdown',
                    'tutorhelper-pro'
                ),

            self::TYPE_EMAIL =>
                __(
                    'Email address',
                    'tutorhelper-pro'
                ),

            self::TYPE_DATE =>
                __(
                    'Date',
                    'tutorhelper-pro'
                ),
        );
    }


	/**
	 * Return supported data categories.
	 *
	 * @return array
	 */
	public static function get_data_categories() {
		return array(
			self::DATA_STANDARD =>
				'Standard information',

			self::DATA_SENSITIVE =>
				'Sensitive information',

			self::DATA_SPECIAL_CATEGORY =>
				'Special-category information',
		);
	}


	/**
	 * Retrieve onboarding questions.
	 *
	 * @param bool $active_only Whether only active questions
	 *                          should be returned.
	 *
	 * @return array
	 */
	public static function get_questions(
		$active_only = true
	) {
		global $wpdb;

		$table = self::questions_table_name();

		if ( empty( $table ) ) {
			return array();
		}

		if ( $active_only ) {
			return $wpdb->get_results(
				"SELECT *
				FROM {$table}
				WHERE is_active = 1
				ORDER BY sort_order ASC, id ASC"
			);
		}

		return $wpdb->get_results(
			"SELECT *
			FROM {$table}
			ORDER BY sort_order ASC, id ASC"
		);
	}


    /**
     * Return TutorHelper's built-in registration questions.
     *
     * Tutors may change the visible wording, but the underlying
     * account field, type and required status remain controlled
     * by TutorHelper.
     *
     * @return array
     */
    public static function get_system_question_definitions() {

        return array(
            self::QUESTION_STUDENT_FIRST_NAME =>
                array(
                    'question_text' =>
                        __(
                            'Student first name',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_SHORT_TEXT,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        1,

                    'sort_order' =>
                        10,
                ),

            self::QUESTION_STUDENT_LAST_NAME =>
                array(
                    'question_text' =>
                        __(
                            'Student last name',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_SHORT_TEXT,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        1,

                    'sort_order' =>
                        20,
                ),

            self::QUESTION_STUDENT_EMAIL =>
                array(
                    'question_text' =>
                        __(
                            'Student email address',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_EMAIL,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        1,

                    'sort_order' =>
                        30,
                ),

            self::QUESTION_DATE_OF_BIRTH =>
                array(
                    'question_text' =>
                        __(
                            'Student date of birth',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_DATE,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        1,

                    'sort_order' =>
                        40,
                ),

            self::QUESTION_ADDRESS_1 =>
                array(
                    'question_text' =>
                        __(
                            'Address line 1',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_SHORT_TEXT,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        1,

                    'sort_order' =>
                        50,
                ),

            self::QUESTION_ADDRESS_2 =>
                array(
                    'question_text' =>
                        __(
                            'Address line 2',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_SHORT_TEXT,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        0,

                    'sort_order' =>
                        60,
                ),

            self::QUESTION_CITY =>
                array(
                    'question_text' =>
                        __(
                            'Town / City',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_SHORT_TEXT,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        1,

                    'sort_order' =>
                        70,
                ),

            self::QUESTION_COUNTY =>
                array(
                    'question_text' =>
                        __(
                            'County',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_SHORT_TEXT,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        0,

                    'sort_order' =>
                        80,
                ),

            self::QUESTION_POSTCODE =>
                array(
                    'question_text' =>
                        __(
                            'Postcode',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_SHORT_TEXT,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        1,

                    'sort_order' =>
                        90,
                ),

            self::QUESTION_COUNTRY =>
                array(
                    'question_text' =>
                        __(
                            'Country',
                            'tutorhelper-pro'
                        ),

                    'question_type' =>
                        self::TYPE_SHORT_TEXT,

                    'data_category' =>
                        self::DATA_STANDARD,

                    'is_required' =>
                        1,

                    'sort_order' =>
                        100,
                ),
        );
    }


    /**
     * Ensure required system registration questions exist.
     *
     * Existing wording is deliberately preserved so tutors can
     * customise how questions are presented to their students.
     *
     * @return void
     */
    public static function ensure_system_questions() {

        global $wpdb;

        $table =
            self::questions_table_name();

        $definitions =
            self::get_system_question_definitions();

        $now =
            current_time(
                'mysql'
            );

        foreach (
            $definitions
            as $question_key => $definition
        ) {

            $existing =
                $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT *
                        FROM {$table}
                        WHERE question_key = %s
                        LIMIT 1",
                        $question_key
                    )
                );

            if ( $existing ) {

                /*
                * Enforce TutorHelper-controlled behaviour,
                * but do not overwrite customised wording.
                */
                $wpdb->update(
                    $table,
                    array(
                        'is_system' =>
                            1,

                        'question_type' =>
                            $definition[
                                'question_type'
                            ],

                        'is_required' =>
                            $definition[
                                'is_required'
                            ],

                        'data_category' =>
                            $definition[
                                'data_category'
                            ],

                        'is_active' =>
                            1,
                    ),
                    array(
                        'id' =>
                            absint(
                                $existing->id
                            ),
                    ),
                    array(
                        '%d',
                        '%s',
                        '%d',
                        '%s',
                        '%d',
                    ),
                    array(
                        '%d',
                    )
                );

                continue;
            }

            $wpdb->insert(
                $table,
                array(
                    'question_key' =>
                        $question_key,

                    'is_system' =>
                        1,

                    'question_text' =>
                        $definition[
                            'question_text'
                        ],

                    'question_type' =>
                        $definition[
                            'question_type'
                        ],

                    'question_options' =>
                        '',

                    'is_required' =>
                        $definition[
                            'is_required'
                        ],

                    'data_category' =>
                        $definition[
                            'data_category'
                        ],

                    'sort_order' =>
                        $definition[
                            'sort_order'
                        ],

                    'is_active' =>
                        1,

                    'created_at' =>
                        $now,

                    'updated_at' =>
                        $now,
                ),
                array(
                    '%s',
                    '%d',
                    '%s',
                    '%s',
                    '%s',
                    '%d',
                    '%s',
                    '%d',
                    '%d',
                    '%s',
                    '%s',
                )
            );
        }
    }


	/**
	 * Retrieve one onboarding question.
	 *
	 * @param int $question_id Question ID.
	 *
	 * @return object|null
	 */
	public static function get_question(
		$question_id
	) {
		global $wpdb;

		$question_id = absint( $question_id );

		if ( ! $question_id ) {
			return null;
		}

		$table = self::questions_table_name();

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT *
				FROM {$table}
				WHERE id = %d
				LIMIT 1",
				$question_id
			)
		);
	}


	/**
	 * Create an onboarding question.
	 *
	 * @param array $data Submitted question data.
	 *
	 * @return int|WP_Error
	 */
	public static function create_question(
		$data
	) {
		global $wpdb;

		$clean = self::sanitize_question_data(
			$data
		);

		$validation =
			self::validate_question_data(
				$clean
			);

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$now = current_time( 'mysql' );

		$result = $wpdb->insert(
			self::questions_table_name(),
			array(
				'question_text' =>
					$clean['question_text'],

				'question_type' =>
					$clean['question_type'],

				'question_options' =>
					$clean['question_options'],

				'is_required' =>
					$clean['is_required'],

				'data_category' =>
					$clean['data_category'],

				'sort_order' =>
					self::get_next_sort_order(),

				'is_active' =>
					$clean['is_active'],

				'created_at' => $now,
				'updated_at' => $now,
			),
			array(
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%d',
				'%d',
				'%s',
				'%s',
			)
		);

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_onboarding_create_failed',
				__(
					'The onboarding question could not be saved.',
					'tutorhelper-pro'
				)
			);
		}

		return absint( $wpdb->insert_id );
	}


    private static function get_next_sort_order() {
        global $wpdb;

        $table =
            self::questions_table_name();

        $maximum =
            $wpdb->get_var(
                "SELECT MAX(sort_order)
                FROM {$table}"
            );

        return absint( $maximum ) + 10;
    }


	/**
	 * Update an onboarding question.
	 *
	 * Historic answers retain their saved question snapshot.
	 *
	 * @param int   $question_id Question ID.
	 * @param array $data        Submitted data.
	 *
	 * @return true|WP_Error
	 */
	public static function update_question(
		$question_id,
		$data
	) {
		global $wpdb;

		$question_id = absint( $question_id );

		$existing = self::get_question(
			$question_id
		);

		if ( ! $existing ) {
			return new WP_Error(
				'tutorhelper_onboarding_not_found',
				__(
					'The onboarding question could not be found.',
					'tutorhelper-pro'
				)
			);
		}

        $is_system =
            ! empty(
                $existing->is_system
            );

		$clean = self::sanitize_question_data(
			$data
		);

        if ( $is_system ) {
            /*
            * Tutors may customise only the visible wording
            * of required account fields.
            */
            $clean['question_type'] =
                sanitize_key(
                    $existing->question_type
                );

            $clean['question_options'] =
                (string)
                    $existing->question_options;

            $clean['is_required'] =
                absint(
                    $existing->is_required
                );

            $clean['data_category'] =
                sanitize_key(
                    $existing->data_category
                );

            $clean['is_active'] =
                1;
        }

		$validation =
			self::validate_question_data(
				$clean
			);

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$result = $wpdb->update(
			self::questions_table_name(),
			array(
				'question_text' =>
					$clean['question_text'],

				'question_type' =>
					$clean['question_type'],

				'question_options' =>
					$clean['question_options'],

				'is_required' =>
					$clean['is_required'],

				'data_category' =>
					$clean['data_category'],

				'sort_order' =>
                    absint(
                        $existing->sort_order
                    ),

				'is_active' =>
					$clean['is_active'],

				'updated_at' =>
					current_time( 'mysql' ),
			),
			array(
				'id' => $question_id,
			),
			array(
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%d',
				'%d',
				'%s',
			),
			array(
				'%d',
			)
		);

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_onboarding_update_failed',
				__(
					'The onboarding question could not be updated.',
					'tutorhelper-pro'
				)
			);
		}

		return true;
	}


	/**
	 * Archive an onboarding question.
	 *
	 * Questions are never deleted automatically because
	 * historic registration answers may refer to them.
	 *
	 * @param int $question_id Question ID.
	 *
	 * @return bool|WP_Error
	 */
	public static function archive_question(
		$question_id
	) {
		global $wpdb;

		$question_id =
            absint(
                $question_id
            );

        if ( ! $question_id ) {
            return new WP_Error(
                'tutorhelper_onboarding_invalid_id',
                __(
                    'The onboarding question could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        $question =
            self::get_question(
                $question_id
            );

        if ( ! $question ) {
            return new WP_Error(
                'tutorhelper_onboarding_not_found',
                __(
                    'The onboarding question could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            ! empty(
                $question->is_system
            )
        ) {
            return new WP_Error(
                'tutorhelper_onboarding_system_question_locked',
                __(
                    'Required account questions cannot be archived.',
                    'tutorhelper-pro'
                )
            );
        }

		$result = $wpdb->update(
			self::questions_table_name(),
			array(
				'is_active' => 0,
				'updated_at' =>
					current_time( 'mysql' ),
			),
			array(
				'id' => $question_id,
			),
			array(
				'%d',
				'%s',
			),
			array(
				'%d',
			)
		);

		return false !== $result;
	}


	/**
	 * Restore an archived onboarding question.
	 *
	 * @param int $question_id Question ID.
	 *
	 * @return bool
	 */
	public static function restore_question(
		$question_id
	) {
		global $wpdb;

		$question_id = absint( $question_id );

		if ( ! $question_id ) {
			return false;
		}

		$result = $wpdb->update(
			self::questions_table_name(),
			array(
				'is_active' => 1,
				'updated_at' =>
					current_time( 'mysql' ),
			),
			array(
				'id' => $question_id,
			),
			array(
				'%d',
				'%s',
			),
			array(
				'%d',
			)
		);

		return false !== $result;
	}


	/**
	 * Sanitise question data.
	 *
	 * @param array $data Raw question data.
	 *
	 * @return array
	 */
	private static function sanitize_question_data(
		$data
	) {
		$question_type =
			isset( $data['question_type'] )
				? sanitize_key(
					$data['question_type']
				)
				: self::TYPE_SHORT_TEXT;

		if (
			! array_key_exists(
				$question_type,
				self::get_question_types()
			)
		) {
			$question_type =
				self::TYPE_SHORT_TEXT;
		}

		$data_category =
			isset( $data['data_category'] )
				? sanitize_key(
					$data['data_category']
				)
				: self::DATA_STANDARD;

		if (
			! array_key_exists(
				$data_category,
				self::get_data_categories()
			)
		) {
			$data_category =
				self::DATA_STANDARD;
		}

		return array(
			'question_text' =>
				isset( $data['question_text'] )
					? sanitize_text_field(
						$data['question_text']
					)
					: '',

			'question_type' =>
				$question_type,

			'question_options' =>
				isset( $data['question_options'] )
					? sanitize_textarea_field(
						$data['question_options']
					)
					: '',

			'is_required' =>
				! empty( $data['is_required'] )
					? 1
					: 0,

			'data_category' =>
				$data_category,

			'sort_order' =>
				isset( $data['sort_order'] )
					? absint(
						$data['sort_order']
					)
					: 0,

			'is_active' =>
				isset( $data['is_active'] )
					? absint(
						$data['is_active']
					)
					: 0,
		);
	}


	/**
	 * Validate sanitised question data.
	 *
	 * @param array $data Sanitised question data.
	 *
	 * @return true|WP_Error
	 */
	private static function validate_question_data(
		$data
	) {
		if ( '' === $data['question_text'] ) {
			return new WP_Error(
				'tutorhelper_onboarding_missing_question',
				__(
					'Please enter the question text.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			in_array(
				$data['question_type'],
				array(
					self::TYPE_CHECKBOX,
					self::TYPE_DROPDOWN,
				),
				true
			)
			&& ''
				=== trim(
					$data['question_options']
				)
		) {
			return new WP_Error(
				'tutorhelper_onboarding_options_required',
				__(
					'Checkbox and dropdown questions need at least one option.',
					'tutorhelper-pro'
				)
			);
		}

		return true;
	}


    /**
     * Validate answers submitted through the public registration form.
     *
     * Only active tutor-created onboarding questions are accepted here.
     * TutorHelper system/account fields are stored in their canonical
     * WordPress/Core locations instead.
     *
     * @param array $submitted_answers Submitted onboarding answers.
     *
     * @return array|WP_Error
     */
    public static function validate_registration_answers(
        $submitted_answers
    ) {

        $submitted_answers =
            is_array( $submitted_answers )
                ? $submitted_answers
                : array();

        $questions =
            self::get_questions(
                true
            );

        $custom_questions =
            array_filter(
                $questions,
                static function ( $question ) {

                    return empty(
                        $question->is_system
                    );
                }
            );

        $allowed_ids = array();

        foreach (
            $custom_questions
            as $question
        ) {
            $allowed_ids[] =
                absint(
                    $question->id
                );
        }

        /*
        * Reject IDs which were not part of the current active
        * custom-question set.
        */
        foreach (
            array_keys(
                $submitted_answers
            )
            as $submitted_id
        ) {

            $submitted_id =
                absint(
                    $submitted_id
                );

            if (
                ! $submitted_id
                || ! in_array(
                    $submitted_id,
                    $allowed_ids,
                    true
                )
            ) {
                return new WP_Error(
                    'tutorhelper_registration_invalid_question',
                    __(
                        'An invalid registration question was submitted.',
                        'tutorhelper-pro'
                    )
                );
            }
        }

        $validated = array();

        foreach (
            $custom_questions
            as $question
        ) {

            $question_id =
                absint(
                    $question->id
                );

            $answer =
                array_key_exists(
                    $question_id,
                    $submitted_answers
                )
                    ? $submitted_answers[
                        $question_id
                    ]
                    : (
                        self::TYPE_CHECKBOX
                        === sanitize_key(
                            $question->question_type
                        )
                            ? array()
                            : ''
                    );

            $answer =
                self::validate_answer(
                    $question,
                    $answer
                );

            if (
                is_wp_error(
                    $answer
                )
            ) {
                return $answer;
            }

            $validated[
                $question_id
            ] = $answer;
        }

        return $validated;
    }


    /**
     * Store validated custom registration answers.
     *
     * Empty optional answers are deliberately not stored.
     * System/account fields are never written to the
     * onboarding answers table.
     *
     * @param int   $student_user_id Student WordPress user ID.
     * @param array $answers         Validated custom answers.
     *
     * @return true|WP_Error
     */
    public static function save_registration_answers(
        $student_user_id,
        $answers
    ) {

        $student_user_id =
            absint(
                $student_user_id
            );

        if (
            ! $student_user_id
            || ! is_array(
                $answers
            )
        ) {
            return new WP_Error(
                'tutorhelper_registration_invalid_answers',
                __(
                    'The onboarding answers could not be saved.',
                    'tutorhelper-pro'
                )
            );
        }

        foreach (
            $answers
            as $question_id => $answer
        ) {

            /*
            * Data minimisation:
            * do not create rows for unanswered optional fields.
            */
            if (
                '' === $answer
                || (
                    is_array( $answer )
                    && empty( $answer )
                )
            ) {
                continue;
            }

            $question =
                self::get_question(
                    $question_id
                );

            if (
                ! $question
                || ! empty(
                    $question->is_system
                )
            ) {
                return new WP_Error(
                    'tutorhelper_registration_invalid_question',
                    __(
                        'An invalid registration question was submitted.',
                        'tutorhelper-pro'
                    )
                );
            }

            $result =
                self::save_answer(
                    $student_user_id,
                    $question_id,
                    $answer
                );

            if (
                is_wp_error(
                    $result
                )
            ) {
                return $result;
            }
        }

        return true;
    }


    /**
     * Delete onboarding answers belonging to a student.
     *
     * Used only to roll back a failed new registration.
     *
     * @param int $student_user_id Student user ID.
     *
     * @return void
     */
    public static function delete_answers_for_student(
        $student_user_id
    ) {

        global $wpdb;

        $student_user_id =
            absint(
                $student_user_id
            );

        if ( ! $student_user_id ) {
            return;
        }

        $wpdb->delete(
            self::answers_table_name(),
            array(
                'student_user_id' =>
                    $student_user_id,
            ),
            array(
                '%d',
            )
        );
    }



    /**
     * Save one onboarding answer for a student.
     *
     * The submitted question ID and answer are always validated
     * against the server-side question definition before storage.
     *
     * @param int   $student_user_id Student WordPress user ID.
     * @param int   $question_id     Onboarding question ID.
     * @param mixed $answer          Submitted answer.
     *
     * @return true|WP_Error
     */
    public static function save_answer(
        $student_user_id,
        $question_id,
        $answer
    ) {
        global $wpdb;

        $student_user_id =
            absint(
                $student_user_id
            );

        $question_id =
            absint(
                $question_id
            );

        if (
            ! $student_user_id
            || ! get_userdata(
                $student_user_id
            )
        ) {
            return new WP_Error(
                'tutorhelper_onboarding_invalid_student',
                __(
                    'The student account could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        $question =
            self::get_question(
                $question_id
            );

        if (
            ! $question
            || empty(
                $question->is_active
            )
        ) {
            return new WP_Error(
                'tutorhelper_onboarding_invalid_question',
                __(
                    'The onboarding question is no longer available.',
                    'tutorhelper-pro'
                )
            );
        }

        $validated_answer =
            self::validate_answer(
                $question,
                $answer
            );

        if (
            is_wp_error(
                $validated_answer
            )
        ) {
            return $validated_answer;
        }

        $stored_answer =
            self::prepare_answer_for_storage(
                $question,
                $validated_answer
            );

        $table =
            self::answers_table_name();

        $existing_id =
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id
                    FROM {$table}
                    WHERE student_user_id = %d
                    AND question_id = %d
                    LIMIT 1",
                    $student_user_id,
                    $question_id
                )
            );

        $now =
            current_time(
                'mysql'
            );

        $data = array(
            'student_user_id' =>
                $student_user_id,

            'question_id' =>
                $question_id,

            'question_text_snapshot' =>
                sanitize_text_field(
                    $question->question_text
                ),

            'question_type_snapshot' =>
                sanitize_key(
                    $question->question_type
                ),

            'data_category_snapshot' =>
                sanitize_key(
                    $question->data_category
                ),

            'answer' =>
                $stored_answer,

            'updated_at' =>
                $now,
        );

        if ( $existing_id ) {

            $result =
                $wpdb->update(
                    $table,
                    $data,
                    array(
                        'id' =>
                            absint(
                                $existing_id
                            ),
                    ),
                    array(
                        '%d',
                        '%d',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                    ),
                    array(
                        '%d',
                    )
                );

        } else {

            $data[
                'created_at'
            ] = $now;

            $result =
                $wpdb->insert(
                    $table,
                    $data,
                    array(
                        '%d',
                        '%d',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                    )
                );
        }

        if ( false === $result ) {
            return new WP_Error(
                'tutorhelper_onboarding_answer_save_failed',
                __(
                    'The onboarding answer could not be saved.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }


    /**
     * Validate and sanitise an answer against its question.
     *
     * @param object $question Question definition.
     * @param mixed  $answer   Submitted answer.
     *
     * @return string|array|WP_Error
     */
    private static function validate_answer(
        $question,
        $answer
    ) {

        $question_type =
            sanitize_key(
                $question->question_type
            );

        $required =
            ! empty(
                $question->is_required
            );

        switch ( $question_type ) {

            case self::TYPE_CHECKBOX:
                return self::validate_checkbox_answer(
                    $question,
                    $answer,
                    $required
                );

            case self::TYPE_DROPDOWN:
                return self::validate_dropdown_answer(
                    $question,
                    $answer,
                    $required
                );

            case self::TYPE_PARAGRAPH:
                $value =
                    is_scalar( $answer )
                        ? sanitize_textarea_field(
                            (string) $answer
                        )
                        : '';

                break;

            case self::TYPE_SHORT_TEXT:
            default:
                $value =
                    is_scalar( $answer )
                        ? sanitize_text_field(
                            (string) $answer
                        )
                        : '';

                break;
        }

        $value =
            trim(
                $value
            );

        if (
            $required
            && '' === $value
        ) {
            return new WP_Error(
                'tutorhelper_onboarding_required_answer',
                __(
                    'Please answer all required onboarding questions.',
                    'tutorhelper-pro'
                )
            );
        }

        return $value;
    }


    /**
     * Validate a checkbox answer.
     *
     * @param object $question Question definition.
     * @param mixed  $answer   Submitted answer.
     * @param bool   $required Whether an answer is required.
     *
     * @return array|WP_Error
     */
    private static function validate_checkbox_answer(
        $question,
        $answer,
        $required
    ) {

        $allowed =
            self::get_question_options(
                $question
            );

        if ( ! is_array( $answer ) ) {
            $answer =
                '' === $answer
                    ? array()
                    : array(
                        $answer,
                    );
        }

        $clean = array();

        foreach ( $answer as $value ) {

            if ( ! is_scalar( $value ) ) {
                continue;
            }

            $value =
                trim(
                    sanitize_text_field(
                        (string) $value
                    )
                );

            if ( '' === $value ) {
                continue;
            }

            /*
            * Only accept values actually configured for
            * this question.
            */
            if (
                ! in_array(
                    $value,
                    $allowed,
                    true
                )
            ) {
                return new WP_Error(
                    'tutorhelper_onboarding_invalid_option',
                    __(
                        'An invalid onboarding option was submitted.',
                        'tutorhelper-pro'
                    )
                );
            }

            $clean[] = $value;
        }

        $clean =
            array_values(
                array_unique(
                    $clean
                )
            );

        if (
            $required
            && empty( $clean )
        ) {
            return new WP_Error(
                'tutorhelper_onboarding_required_answer',
                __(
                    'Please answer all required onboarding questions.',
                    'tutorhelper-pro'
                )
            );
        }

        return $clean;
    }


    /**
     * Validate a dropdown answer.
     *
     * @param object $question Question definition.
     * @param mixed  $answer   Submitted answer.
     * @param bool   $required Whether an answer is required.
     *
     * @return string|WP_Error
     */
    private static function validate_dropdown_answer(
        $question,
        $answer,
        $required
    ) {

        $value =
            is_scalar( $answer )
                ? trim(
                    sanitize_text_field(
                        (string) $answer
                    )
                )
                : '';

        if ( '' === $value ) {

            if ( $required ) {
                return new WP_Error(
                    'tutorhelper_onboarding_required_answer',
                    __(
                        'Please answer all required onboarding questions.',
                        'tutorhelper-pro'
                    )
                );
            }

            return '';
        }

        $allowed =
            self::get_question_options(
                $question
            );

        if (
            ! in_array(
                $value,
                $allowed,
                true
            )
        ) {
            return new WP_Error(
                'tutorhelper_onboarding_invalid_option',
                __(
                    'An invalid onboarding option was submitted.',
                    'tutorhelper-pro'
                )
            );
        }

        return $value;
    }

    /**
     * Return the configured options for a question.
     *
     * @param object $question Question definition.
     *
     * @return array
     */
    public static function get_question_options(
        $question
    ) {

        if (
            ! $question
            || empty(
                $question->question_options
            )
        ) {
            return array();
        }

        $lines =
            preg_split(
                '/\r\n|\r|\n/',
                (string)
                    $question->question_options
            );

        $options = array();

        foreach ( $lines as $line ) {

            $line =
                trim(
                    sanitize_text_field(
                        $line
                    )
                );

            if ( '' === $line ) {
                continue;
            }

            $options[] =
                $line;
        }

        return array_values(
            array_unique(
                $options
            )
        );
    }


    /**
     * Prepare a validated answer for database storage.
     *
     * Checkbox answers are stored as JSON so their individual
     * values remain recoverable for display and export.
     *
     * @param object       $question Question definition.
     * @param string|array $answer   Validated answer.
     *
     * @return string
     */
    private static function prepare_answer_for_storage(
        $question,
        $answer
    ) {

        if (
            self::TYPE_CHECKBOX
            === sanitize_key(
                $question->question_type
            )
        ) {
            return wp_json_encode(
                (array) $answer
            );
        }

        return (string) $answer;
    }

    
    /**
     * Get all saved onboarding answers for a student.
     *
     * Historic question text and classifications are read from
     * the immutable answer snapshots rather than relying on the
     * current question definition.
     *
     * @param int $student_user_id Student WordPress user ID.
     *
     * @return array
     */
    public static function get_answers_for_student(
        $student_user_id
    ) {
        global $wpdb;

        $student_user_id =
            absint(
                $student_user_id
            );

        if ( ! $student_user_id ) {
            return array();
        }

        $answers_table =
            self::answers_table_name();

        $questions_table =
            self::questions_table_name();

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    a.id,
                    a.student_user_id,
                    a.question_id,
                    a.question_text_snapshot,
                    a.question_type_snapshot,
                    a.data_category_snapshot,
                    a.answer,
                    a.created_at,
                    a.updated_at,
                    COALESCE(
                        q.sort_order,
                        999999
                    ) AS sort_order
                FROM {$answers_table} a
                LEFT JOIN {$questions_table} q
                    ON q.id = a.question_id
                WHERE a.student_user_id = %d
                ORDER BY
                    sort_order ASC,
                    a.id ASC",
                $student_user_id
            )
        );
    }


    /**
     * Format an onboarding answer for display.
     *
     * @param object $answer Stored answer row.
     *
     * @return string
     */
    public static function format_answer_for_display(
        $answer
    ) {

        if (
            ! $answer
            || ! isset(
                $answer->answer
            )
        ) {
            return '';
        }

        $value =
            (string)
                $answer->answer;

        if (
            self::TYPE_CHECKBOX
            === sanitize_key(
                $answer->question_type_snapshot
            )
        ) {

            $decoded =
                json_decode(
                    $value,
                    true
                );

            if (
                JSON_ERROR_NONE
                === json_last_error()
                && is_array(
                    $decoded
                )
            ) {

                $clean = array();

                foreach ( $decoded as $item ) {

                    if (
                        ! is_scalar(
                            $item
                        )
                    ) {
                        continue;
                    }

                    $clean[] =
                        sanitize_text_field(
                            (string)
                                $item
                        );
                }

                return implode(
                    ', ',
                    $clean
                );
            }
        }

        return sanitize_textarea_field(
            $value
        );
    }




    /**
     * Determine whether a question may contain elevated-risk data.
     *
     * @param object $question Question definition.
     *
     * @return bool
     */
    public static function is_elevated_data_question(
        $question
    ) {

        if (
            ! $question
            || empty(
                $question->data_category
            )
        ) {
            return false;
        }

        return in_array(
            sanitize_key(
                $question->data_category
            ),
            array(
                self::DATA_SENSITIVE,
                self::DATA_SPECIAL_CATEGORY,
            ),
            true
        );
    }

    /**
     * Save the display order of active onboarding questions.
     *
     * The submitted IDs must exactly match the currently active
     * questions. This prevents forged or incomplete reorder
     * requests from silently changing unrelated records.
     *
     * @param array $ordered_ids Question IDs in display order.
     *
     * @return true|WP_Error
     */
    public static function update_sort_order(
        $ordered_ids
    ) {
        global $wpdb;

        if ( ! is_array( $ordered_ids ) ) {
            return new WP_Error(
                'tutorhelper_onboarding_invalid_order',
                __(
                    'The onboarding question order is invalid.',
                    'tutorhelper-pro'
                )
            );
        }

        $ordered_ids =
            array_values(
                array_unique(
                    array_filter(
                        array_map(
                            'absint',
                            $ordered_ids
                        )
                    )
                )
            );

        $active_questions =
            array_filter(
                self::get_questions(
                    true
                ),
                static function ( $question ) {
                    return empty(
                        $question->is_system
                    );
                }
            );

        $active_ids =
            array_map(
                static function ( $question ) {
                    return absint(
                        $question->id
                    );
                },
                $active_questions
            );

        $submitted_check =
            $ordered_ids;

        $active_check =
            $active_ids;

        sort( $submitted_check );
        sort( $active_check );

        if (
            $submitted_check
            !== $active_check
        ) {
            return new WP_Error(
                'tutorhelper_onboarding_order_mismatch',
                __(
                    'The onboarding question list changed. Refresh the page and try again.',
                    'tutorhelper-pro'
                )
            );
        }

        foreach (
            $ordered_ids
            as $position => $question_id
        ) {
            $result =
                $wpdb->update(
                    self::questions_table_name(),
                    array(
                        'sort_order' =>
                            ( $position + 1 ) * 10,

                        'updated_at' =>
                            current_time(
                                'mysql'
                            ),
                    ),
                    array(
                        'id' =>
                            $question_id,
                    ),
                    array(
                        '%d',
                        '%s',
                    ),
                    array(
                        '%d',
                    )
                );

            if ( false === $result ) {
                return new WP_Error(
                    'tutorhelper_onboarding_order_save_failed',
                    __(
                        'The onboarding question order could not be saved.',
                        'tutorhelper-pro'
                    )
                );
            }
        }

        return true;
    }



}
