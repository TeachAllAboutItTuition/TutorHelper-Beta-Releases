<?php
/**
 * Sortable student dashboard table view.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds an alternate table layout to the Core student dashboard.
 */
final class TutorHelper_Pro_Student_Dashboard_Table {

	const STYLE_HANDLE = 'tutorhelper-pro-student-dashboard-table';
	const SCRIPT_HANDLE = 'tutorhelper-pro-student-dashboard-table';

	/** @var int */
	private static $instance = 0;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'wp_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' ),
			30
		);

		add_action(
			'tutorhelper_student_dashboard_before_sections',
			array( __CLASS__, 'render' )
		);

		add_action(
			'tutorhelper_student_dashboard_section_before_content',
			array( __CLASS__, 'render_attendance_overview' ),
			10,
			2
		);

		add_action(
			'tutorhelper_student_dashboard_booking_details',
			array( __CLASS__, 'render_card_homework_indicators' ),
			5,
			2
		);
	}

	/**
	 * Render homework status icons in Core's student card layout.
	 *
	 * The table already exposes these icons in its Details column. This hook
	 * keeps Cards and Table layouts equivalent without duplicating homework
	 * state or changing the Core card renderer.
	 *
	 * @param array  $booking      Prepared Core booking.
	 * @param string $section_type Dashboard section key.
	 * @return void
	 */
	public static function render_card_homework_indicators(
		$booking,
		$section_type
	) {
		unset( $section_type );

		$booking_id = is_array( $booking ) && isset( $booking['id'] )
			? absint( $booking['id'] )
			: 0;

		if ( ! $booking_id ) {
			return;
		}

		ob_start();
		TutorHelper_Pro_Lesson_Follow_Up::render_homework_indicators(
			$booking_id
		);
		$indicators = trim( ob_get_clean() );

		if ( '' === $indicators ) {
			return;
		}
		?>
		<div class="tutorhelper-pro-dashboard-card-homework" aria-label="<?php esc_attr_e( 'Homework status', 'tutorhelper-pro' ); ?>">
			<span><?php esc_html_e( 'Homework', 'tutorhelper-pro' ); ?></span>
			<?php echo wp_kses_post( $indicators ); ?>
		</div>
		<?php
	}

	/**
	 * Render an accessible attendance chart and lesson log in Past lessons.
	 *
	 * @param string $section  Dashboard section key.
	 * @param array  $bookings Prepared Core bookings.
	 * @return void
	 */
	public static function render_attendance_overview( $section, $bookings ) {
		if ( 'past' !== sanitize_key( $section ) || empty( $bookings ) || ! is_array( $bookings ) ) {
			return;
		}

		$booking_ids = array_values(
			array_filter(
				array_map(
					static function ( $booking ) {
						return is_array( $booking ) && isset( $booking['id'] ) ? absint( $booking['id'] ) : 0;
					},
					$bookings
				)
			)
		);
		$records = TutorHelper_Pro_Booking_Attendance::get_for_booking_ids( $booking_ids );
		$labels  = TutorHelper_Pro_Booking_Attendance::get_statuses();
		$labels['cancelled'] = __( 'Cancelled', 'tutorhelper-pro' );
		$counts = array_fill_keys(
			array(
				TutorHelper_Pro_Booking_Attendance::STATUS_ATTENDED,
				TutorHelper_Pro_Booking_Attendance::STATUS_LATE,
				TutorHelper_Pro_Booking_Attendance::STATUS_MISSED,
				TutorHelper_Pro_Booking_Attendance::STATUS_INFO_ONLY,
				TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED,
				TutorHelper_Pro_Booking_Attendance::STATUS_NOT_APPLICABLE,
				'cancelled',
			),
			0
		);
		$rows = array();

		foreach ( $bookings as $booking ) {
			$booking_id = isset( $booking['id'] ) ? absint( $booking['id'] ) : 0;
			$status = TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking['status'] ?? '' )
				? 'cancelled'
				: ( isset( $records[ $booking_id ] )
					? sanitize_key( $records[ $booking_id ]->attendance_status )
					: TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED );

			if ( ! isset( $counts[ $status ] ) ) {
				$status = TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED;
			}

			++$counts[ $status ];
			$rows[] = array(
				'date'   => isset( $booking['start'] ) && $booking['start'] instanceof DateTimeInterface
					? wp_date( get_option( 'date_format' ), $booking['start']->getTimestamp(), $booking['start']->getTimezone() )
					: '',
				'lesson' => sanitize_text_field( $booking['title'] ?? __( 'Lesson', 'tutorhelper-pro' ) ),
				'status' => $status,
			);
		}

		$total = count( $rows );
		?>
		<details class="tutorhelper-pro-attendance-history">
			<summary>
				<span class="tutorhelper-pro-attendance-history__heading">
					<span><?php echo esc_html__( 'Attendance overview', 'tutorhelper-pro' ); ?></span>
					<span class="tutorhelper-pro-attendance-history__toggle" aria-hidden="true">⌄</span>
				</span>
				<small><?php echo esc_html( sprintf( _n( '%s past lesson', '%s past lessons', $total, 'tutorhelper-pro' ), number_format_i18n( $total ) ) ); ?></small>
			</summary>
			<div class="tutorhelper-pro-attendance-history__content">
				<div class="tutorhelper-pro-attendance-history__chart" aria-label="<?php echo esc_attr__( 'Attendance totals', 'tutorhelper-pro' ); ?>">
					<?php foreach ( $counts as $status => $count ) : ?>
						<?php
						if ( 0 === $count ) {
							continue;
						}
						?>
						<div class="tutorhelper-pro-attendance-history__bar tutorhelper-pro-attendance-history__bar--<?php echo esc_attr( $status ); ?>">
							<div><span><?php echo esc_html( $labels[ $status ] ?? ucfirst( str_replace( '_', ' ', $status ) ) ); ?></span><strong><?php echo esc_html( number_format_i18n( $count ) ); ?></strong></div>
							<progress value="<?php echo esc_attr( $count ); ?>" max="<?php echo esc_attr( $total ); ?>"><?php echo esc_html( $count . ' / ' . $total ); ?></progress>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="tutorhelper-pro-attendance-history__table-wrap" data-attendance-history data-page-size="10">
					<div class="tutorhelper-pro-attendance-history__table-scroll">
						<table>
							<caption class="screen-reader-text"><?php echo esc_html__( 'Past lesson attendance log', 'tutorhelper-pro' ); ?></caption>
							<thead><tr><th scope="col"><?php echo esc_html__( 'Date', 'tutorhelper-pro' ); ?></th><th scope="col"><?php echo esc_html__( 'Lesson', 'tutorhelper-pro' ); ?></th><th scope="col"><?php echo esc_html__( 'Attendance', 'tutorhelper-pro' ); ?></th></tr></thead>
							<tbody>
								<?php foreach ( $rows as $row ) : ?>
									<tr data-attendance-row><td><?php echo esc_html( $row['date'] ); ?></td><td><?php echo esc_html( $row['lesson'] ); ?></td><td><span class="tutorhelper-pro-attendance-status tutorhelper-pro-attendance-status--<?php echo esc_attr( $row['status'] ); ?>"><?php echo esc_html( $labels[ $row['status'] ] ?? ucfirst( str_replace( '_', ' ', $row['status'] ) ) ); ?></span></td></tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<nav class="tutorhelper-pro-attendance-history__pagination" data-attendance-pagination aria-label="<?php echo esc_attr__( 'Attendance history pages', 'tutorhelper-pro' ); ?>" hidden>
						<button type="button" data-attendance-previous><?php echo esc_html__( 'Previous', 'tutorhelper-pro' ); ?></button>
						<span data-attendance-page-status aria-live="polite"></span>
						<button type="button" data-attendance-next><?php echo esc_html__( 'Next', 'tutorhelper-pro' ); ?></button>
					</nav>
				</div>
			</div>
		</details>
		<?php
	}

	/**
	 * Render the view switcher and table.
	 *
	 * @param array $groups Prepared bookings grouped by dashboard section.
	 * @return void
	 */
	public static function render( $groups ) {
		$items = self::flatten( $groups );

		if ( empty( $items ) ) {
			return;
		}

		self::$instance++;
		$prefix = 'tutorhelper-pro-dashboard-' . self::$instance;
		$attendance = self::get_attendance_context( $items );
		?>
		<div
			class="tutorhelper-pro-dashboard-view"
			data-tutorhelper-pro-dashboard-view
			data-storage-key="tutorhelper_student_dashboard_view"
		>
			<div class="tutorhelper-pro-dashboard-view__switcher">
				<span><?php esc_html_e( 'View lessons as', 'tutorhelper-pro' ); ?></span>
				<div role="group" aria-label="<?php esc_attr_e( 'Choose lesson layout', 'tutorhelper-pro' ); ?>">
					<button type="button" class="is-active" data-dashboard-view-button="cards" aria-pressed="true">
						<?php esc_html_e( 'Cards', 'tutorhelper-pro' ); ?>
					</button>
					<button type="button" data-dashboard-view-button="table" aria-pressed="false">
						<?php esc_html_e( 'Table', 'tutorhelper-pro' ); ?>
					</button>
				</div>
			</div>

			<div class="tutorhelper-pro-dashboard-table" data-dashboard-table-view hidden>
				<?php self::render_filters( $items, $prefix, $attendance ); ?>
				<p data-dashboard-result-count aria-live="polite"></p>

				<div class="tutorhelper-pro-dashboard-table__scroll">
					<table>
						<caption class="screen-reader-text"><?php esc_html_e( 'Your lessons', 'tutorhelper-pro' ); ?></caption>
						<thead>
							<tr>
								<?php self::sort_heading( 'date', __( 'Date', 'tutorhelper-pro' ) ); ?>
								<?php self::sort_heading( 'time', __( 'Time', 'tutorhelper-pro' ) ); ?>
								<?php self::sort_heading( 'title', __( 'Lesson', 'tutorhelper-pro' ) ); ?>
								<?php self::sort_heading( 'location', __( 'Location', 'tutorhelper-pro' ) ); ?>
								<?php self::sort_heading( 'status', __( 'Status', 'tutorhelper-pro' ) ); ?>
								<th scope="col"><?php esc_html_e( 'Details', 'tutorhelper-pro' ); ?></th>
								<th scope="col"><?php esc_html_e( 'Actions', 'tutorhelper-pro' ); ?></th>
							</tr>
						</thead>
						<tbody data-dashboard-table-group="upcoming">
							<tr class="tutorhelper-pro-dashboard-table__section-heading" data-dashboard-table-group-heading>
								<th scope="rowgroup" colspan="7"><?php esc_html_e( 'Upcoming lessons', 'tutorhelper-pro' ); ?></th>
							</tr>
							<?php
							foreach ( $items as $item ) {
								if ( 'past' !== $item['section'] ) {
									self::render_row( $item['booking'], $item['section'], $attendance );
								}
							}
							?>
						</tbody>
						<tbody data-dashboard-table-group="past">
							<tr class="tutorhelper-pro-dashboard-table__section-heading" data-dashboard-table-group-heading>
								<th scope="rowgroup" colspan="7"><?php esc_html_e( 'Past lessons', 'tutorhelper-pro' ); ?></th>
							</tr>
							<?php
							foreach ( $items as $item ) {
								if ( 'past' === $item['section'] ) {
									self::render_row( $item['booking'], $item['section'], $attendance );
								}
							}
							?>
						</tbody>
						<tbody>
							<tr data-dashboard-no-results hidden>
								<td colspan="7"><?php esc_html_e( 'No lessons match these filters.', 'tutorhelper-pro' ); ?></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Flatten valid Core booking groups.
	 *
	 * @param array $groups Booking groups.
	 * @return array
	 */
	private static function flatten( $groups ) {
		$items = array();

		if ( ! is_array( $groups ) ) {
			return $items;
		}

		foreach ( array( 'pending', 'upcoming', 'past' ) as $section ) {
			if ( empty( $groups[ $section ] ) || ! is_array( $groups[ $section ] ) ) {
				continue;
			}

			foreach ( $groups[ $section ] as $booking ) {
				if (
					! is_array( $booking )
					|| empty( $booking['start'] )
					|| ! $booking['start'] instanceof DateTimeInterface
					|| empty( $booking['end'] )
					|| ! $booking['end'] instanceof DateTimeInterface
				) {
					continue;
				}

				$items[] = array(
					'section' => $section,
					'booking' => $booking,
				);
			}
		}

		return $items;
	}

	/**
	 * Enqueue view assets.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {
		$css = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-student-dashboard-table.css';
		$js  = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-student-dashboard-table.js';

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-student-dashboard-table.css',
			array( TutorHelper_Student_Dashboard_Frontend::STYLE_HANDLE ),
			file_exists( $css ) ? (string) filemtime( $css ) : TUTORHELPER_PRO_VERSION
		);

		wp_add_inline_style(
			self::STYLE_HANDLE,
			self::get_critical_styles()
		);

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-student-dashboard-table.js',
			array(),
			file_exists( $js ) ? (string) filemtime( $js ) : TUTORHELPER_PRO_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'TutorHelperProDashboardTable',
			array(
				'oneLesson'       => __( '1 lesson shown', 'tutorhelper-pro' ),
				'manyLessons'     => __( '%d lessons shown', 'tutorhelper-pro' ),
				'previousPage'    => __( 'Previous', 'tutorhelper-pro' ),
				'nextPage'        => __( 'Next', 'tutorhelper-pro' ),
				'cardPagesLabel'  => __( 'Lesson card pages', 'tutorhelper-pro' ),
				'cardPageStatus'  => __( 'Page %1$d of %2$d', 'tutorhelper-pro' ),
			)
		);
	}

	/**
	 * Return critical control styles that must not be lost to an asset cache.
	 *
	 * The linked stylesheet remains the source for the complete table layout.
	 * These rules are attached using the WordPress style API so the meeting and
	 * details controls remain usable when a host serves an older cached copy of
	 * the physical stylesheet.
	 *
	 * @return string
	 */
	private static function get_critical_styles() {
		return '
			.tutorhelper-student-dashboard .tutorhelper-pro-dashboard-table__details > summary {
				display: inline-flex !important;
				align-items: center !important;
				justify-content: center !important;
				min-height: 36px !important;
				box-sizing: border-box !important;
				padding: 7px 12px !important;
				border: 1px solid var(--tutorhelper-brand-primary, #133949) !important;
				border-radius: 7px !important;
				background: var(--tutorhelper-brand-primary, #133949) !important;
				color: var(--tutorhelper-brand-button-text, #fff) !important;
				font-weight: 800 !important;
				line-height: 1.3 !important;
				cursor: pointer !important;
				list-style: none !important;
			}
			.tutorhelper-student-dashboard .tutorhelper-pro-dashboard-table__details > summary::-webkit-details-marker {
				display: none !important;
			}
			.tutorhelper-student-dashboard .tutorhelper-pro-dashboard-table__details-label--open {
				display: none !important;
			}
			.tutorhelper-student-dashboard .tutorhelper-pro-dashboard-table__details[open] .tutorhelper-pro-dashboard-table__details-label--closed {
				display: none !important;
			}
			.tutorhelper-student-dashboard .tutorhelper-pro-dashboard-table__details[open] .tutorhelper-pro-dashboard-table__details-label--open {
				display: inline !important;
			}
			.tutorhelper-student-dashboard a.tutorhelper-pro-online-meeting-link {
				display: inline-flex !important;
				align-items: center !important;
				justify-content: center !important;
				box-sizing: border-box !important;
				padding: 9px 15px !important;
				border: 1px solid var(--tutorhelper-brand-primary, #133949) !important;
				border-radius: 8px !important;
				background: var(--tutorhelper-brand-primary, #133949) !important;
				color: var(--tutorhelper-brand-button-text, #fff) !important;
				font-weight: 800 !important;
				line-height: 1.3 !important;
				text-decoration: none !important;
			}
			.tutorhelper-student-dashboard a.tutorhelper-pro-online-meeting-link:hover,
			.tutorhelper-student-dashboard a.tutorhelper-pro-online-meeting-link:focus-visible {
				filter: brightness(1.08);
				text-decoration: none !important;
			}
			.tutorhelper-pro-attendance-history {
				margin: 18px 0 22px;
				border: 1px solid #d6e0e5;
				border-radius: 14px;
				background: #fff;
				overflow: hidden;
			}
			.tutorhelper-pro-attendance-history > summary {
				display: flex;
				justify-content: space-between;
				gap: 16px;
				padding: 16px 18px;
				background: var(--tutorhelper-brand-primary, #133949);
				color: #fff;
				font-weight: 800;
				cursor: pointer;
				list-style: none;
			}
			.tutorhelper-pro-attendance-history > summary::-webkit-details-marker { display: none; }
			.tutorhelper-pro-attendance-history__heading { display: inline-flex; align-items: center; gap: 9px; }
			.tutorhelper-pro-attendance-history__toggle { display: inline-block; font-size: 1.35em; line-height: 1; transition: transform 160ms ease; }
			.tutorhelper-pro-attendance-history[open] .tutorhelper-pro-attendance-history__toggle { transform: rotate(180deg); }
			.tutorhelper-pro-attendance-history > summary small { font-weight: 500; }
			.tutorhelper-pro-attendance-history__content { padding: 18px; }
			.tutorhelper-pro-attendance-history__chart { display: grid; gap: 12px; margin-bottom: 20px; }
			.tutorhelper-pro-attendance-history__bar > div { display: flex; justify-content: space-between; gap: 12px; }
			.tutorhelper-pro-attendance-history__bar progress { width: 100%; height: 12px; accent-color: var(--tutorhelper-brand-accent, #ff5c35); }
			.tutorhelper-pro-attendance-history__table-wrap { overflow: hidden; border: 1px solid #d8e1e5; border-radius: 10px; }
			.tutorhelper-pro-attendance-history__table-scroll { overflow-x: auto; }
			.tutorhelper-pro-attendance-history table { width: 100%; min-width: 620px; margin: 0; border: 0; border-collapse: collapse; }
			.tutorhelper-pro-attendance-history th { background: #f3f6f7; color: var(--tutorhelper-brand-heading, #133949); font-size: .78rem; text-transform: uppercase; }
			.tutorhelper-pro-attendance-history th,
			.tutorhelper-pro-attendance-history td { padding: 10px 12px; border-bottom: 1px solid #e2e8ea; text-align: left; }
			.tutorhelper-pro-attendance-history tbody tr:nth-child(even) { background: #f8fafb; }
			.tutorhelper-pro-attendance-history [data-attendance-row][hidden] { display: none !important; }
			.tutorhelper-pro-attendance-history__pagination { display: flex; align-items: center; justify-content: flex-end; gap: 10px; padding: 12px; background: #f8fafb; }
			.tutorhelper-pro-attendance-history__pagination[hidden] { display: none !important; }
			.tutorhelper-pro-attendance-history__pagination button { min-height: 34px; padding: 6px 12px; border: 1px solid var(--tutorhelper-brand-primary, #133949); border-radius: 999px; background: #fff; color: var(--tutorhelper-brand-primary, #133949); font: inherit; font-weight: 800; cursor: pointer; }
			.tutorhelper-pro-attendance-history__pagination button:disabled { opacity: .45; cursor: default; }
		';
	}

	/**
	 * Render filters.
	 *
	 * @param array  $items      Flattened bookings.
	 * @param string $prefix     Unique field prefix.
	 * @param array  $attendance Attendance records and labels.
	 * @return void
	 */
	private static function render_filters( $items, $prefix, $attendance ) {
		$types = array();
		$locations = array();
		$statuses = array();

		foreach ( $items as $item ) {
			$booking = $item['booking'];
			$title = sanitize_text_field( $booking['title'] ?? '' );
			$location = sanitize_key( $booking['location_type'] ?? '' );
			$location_label = sanitize_text_field( $booking['location_label'] ?? '' );
			$display_status = self::get_display_status( $booking, $item['section'], $attendance );
			$status = $display_status['key'];
			$status_label = $display_status['label'];

			if ( $title ) {
				$types[ self::filter_value( $title ) ] = $title;
			}
			if ( $location && $location_label ) {
				$locations[ $location ] = $location_label;
			}
			if ( $status && $status_label ) {
				$statuses[ $status ] = $status_label;
			}
		}

		if ( ! isset( $statuses[ TutorHelper_Booking_Records::STATUS_CONFIRMED ] ) ) {
			$statuses[ TutorHelper_Booking_Records::STATUS_CONFIRMED ] = __( 'Confirmed', 'tutorhelper-pro' );
		}

		natcasesort( $types );
		natcasesort( $locations );
		natcasesort( $statuses );
		?>
		<div class="tutorhelper-pro-dashboard-table__filters" aria-label="<?php esc_attr_e( 'Filter lessons', 'tutorhelper-pro' ); ?>">
			<?php
			self::select(
				$prefix . '-timeframe',
				'timeframe',
				__( 'Timeframe', 'tutorhelper-pro' ),
				array(
					''         => __( 'All lessons', 'tutorhelper-pro' ),
					'pending'  => __( 'Pending requests', 'tutorhelper-pro' ),
					'upcoming' => __( 'Upcoming lessons', 'tutorhelper-pro' ),
					'past'     => __( 'Past lessons', 'tutorhelper-pro' ),
				)
			);
			self::select(
				$prefix . '-status',
				'status',
				__( 'Status', 'tutorhelper-pro' ),
				array( '' => __( 'All statuses', 'tutorhelper-pro' ) ) + $statuses,
				TutorHelper_Booking_Records::STATUS_CONFIRMED
			);
			self::select(
				$prefix . '-type',
				'type',
				__( 'Lesson', 'tutorhelper-pro' ),
				array( '' => __( 'All lesson types', 'tutorhelper-pro' ) ) + $types
			);
			self::select(
				$prefix . '-location',
				'location',
				__( 'Location', 'tutorhelper-pro' ),
				array( '' => __( 'All locations', 'tutorhelper-pro' ) ) + $locations
			);
			?>
			<button type="button" class="tutorhelper-pro-dashboard-table__reset" data-dashboard-filter-reset>
				<?php esc_html_e( 'Reset filters', 'tutorhelper-pro' ); ?>
			</button>
		</div>
		<?php
	}

	/**
	 * Render one filter select.
	 *
	 * @param string $id      Field ID.
	 * @param string $key     Filter key.
	 * @param string $label   Label.
	 * @param array  $options  Options.
	 * @param string $selected Initially selected value.
	 * @return void
	 */
	private static function select( $id, $key, $label, $options, $selected = '' ) {
		?>
		<label for="<?php echo esc_attr( $id ); ?>">
			<span><?php echo esc_html( $label ); ?></span>
			<select id="<?php echo esc_attr( $id ); ?>" data-dashboard-filter="<?php echo esc_attr( $key ); ?>">
				<?php foreach ( $options as $value => $option ) : ?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected, $value ); ?>><?php echo esc_html( $option ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<?php
	}

	/**
	 * Render sortable heading.
	 *
	 * @param string $key   Sort key.
	 * @param string $label Label.
	 * @return void
	 */
	private static function sort_heading( $key, $label ) {
		?>
		<th scope="col" aria-sort="none">
			<button type="button" data-dashboard-sort="<?php echo esc_attr( $key ); ?>">
				<?php echo esc_html( $label ); ?>
				<span aria-hidden="true" data-dashboard-sort-indicator>↕</span>
			</button>
		</th>
		<?php
	}

	/**
	 * Render one booking row.
	 *
	 * @param array  $booking    Prepared booking.
	 * @param string $section    Dashboard section.
	 * @param array  $attendance Attendance records and labels.
	 * @return void
	 */
	private static function render_row( $booking, $section, $attendance ) {
		$start = $booking['start'];
		$end = $booking['end'];
		$title = sanitize_text_field( $booking['title'] ?? __( 'Lesson', 'tutorhelper-pro' ) );
		$booking_status = sanitize_key( $booking['status'] ?? '' );
		$display_status = self::get_display_status( $booking, $section, $attendance );
		$status = $display_status['key'];
		$status_label = $display_status['label'];
		$location = sanitize_key( $booking['location_type'] ?? '' );
		$location_label = sanitize_text_field( $booking['location_label'] ?? '' );
		$colour = sanitize_hex_color( $booking['colour'] ?? '' );

		if ( ! $colour ) {
			$colour = '#328bb8';
		}

		$date = wp_date( 'D j M Y', $start->getTimestamp(), $start->getTimezone() );
		$start_time = wp_date( get_option( 'time_format' ), $start->getTimestamp(), $start->getTimezone() );
		$end_time = wp_date( get_option( 'time_format' ), $end->getTimestamp(), $end->getTimezone() );
		?>
		<tr
			class="tutorhelper-pro-dashboard-table__row tutorhelper-pro-dashboard-table__row--<?php echo esc_attr( $booking_status ); ?>"
			style="--tutorhelper-booking-type-colour: <?php echo esc_attr( $colour ); ?>;"
			data-dashboard-table-row
			data-date="<?php echo esc_attr( $start->getTimestamp() ); ?>"
			data-time="<?php echo esc_attr( $start->format( 'Hi' ) ); ?>"
			data-title="<?php echo esc_attr( self::filter_value( $title ) ); ?>"
			data-location="<?php echo esc_attr( $location ); ?>"
			data-location-label="<?php echo esc_attr( self::filter_value( $location_label ) ); ?>"
			data-booking-status="<?php echo esc_attr( $booking_status ); ?>"
			data-status="<?php echo esc_attr( $status ); ?>"
			data-status-label="<?php echo esc_attr( self::filter_value( $status_label ) ); ?>"
			data-timeframe="<?php echo esc_attr( sanitize_key( $section ) ); ?>"
		>
			<td><i aria-hidden="true"></i><?php echo esc_html( $date ); ?></td>
			<td><?php echo esc_html( $start_time . '–' . $end_time ); ?></td>
			<td><strong><?php echo esc_html( $title ); ?></strong></td>
			<td><?php echo esc_html( $location_label ); ?></td>
			<td>
				<span class="tutorhelper-student-dashboard__status tutorhelper-student-dashboard__status--<?php echo esc_attr( $status ); ?>">
					<?php echo esc_html( $status_label ); ?>
				</span>
			</td>
			<td><?php self::render_details( $booking, $section ); ?></td>
			<td>
				<div class="tutorhelper-pro-dashboard-table__actions">
					<?php
					if ( TutorHelper_Booking_Records::STATUS_CONFIRMED === $booking_status ) {
						do_action(
							'tutorhelper_student_dashboard_booking_actions',
							$booking,
							'upcoming' === $section ? 'confirmed' : $section
						);
					}
					self::render_cancel( $booking );
					?>
				</div>
			</td>
		</tr>
		<?php
	}

	/**
	 * Load attendance once for all past rows in the table.
	 *
	 * @param array $items Flattened booking items.
	 * @return array
	 */
	private static function get_attendance_context( $items ) {
		$booking_ids = array();

		foreach ( $items as $item ) {
			if ( 'past' === ( $item['section'] ?? '' ) && ! empty( $item['booking']['id'] ) ) {
				$booking_ids[] = absint( $item['booking']['id'] );
			}
		}

		return array(
			'records' => empty( $booking_ids ) ? array() : TutorHelper_Pro_Booking_Attendance::get_for_booking_ids( $booking_ids ),
			'labels'  => TutorHelper_Pro_Booking_Attendance::get_statuses(),
		);
	}

	/**
	 * Use recorded attendance as the status of a past lesson.
	 *
	 * Cancelled lessons always remain cancelled and an unrecorded attendance
	 * value leaves the original booking status unchanged.
	 *
	 * @param array  $booking    Prepared booking.
	 * @param string $section    Dashboard section.
	 * @param array  $attendance Attendance records and labels.
	 * @return array
	 */
	private static function get_display_status( $booking, $section, $attendance ) {
		$status = sanitize_key( $booking['status'] ?? '' );
		$label = sanitize_text_field( $booking['status_label'] ?? '' );

		if ( TutorHelper_Booking_Records::STATUS_CANCELLED === $status || 'past' !== $section ) {
			return array( 'key' => $status, 'label' => $label );
		}

		$booking_id = absint( $booking['id'] ?? 0 );
		$record = $attendance['records'][ $booking_id ] ?? null;
		$attendance_status = $record ? sanitize_key( $record->attendance_status ) : '';

		if (
			'' !== $attendance_status
			&& TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED !== $attendance_status
			&& isset( $attendance['labels'][ $attendance_status ] )
		) {
			return array(
				'key'   => $attendance_status,
				'label' => sanitize_text_field( $attendance['labels'][ $attendance_status ] ),
			);
		}

		return array( 'key' => $status, 'label' => $label );
	}

	/**
	 * Render joining or cancellation details.
	 *
	 * @param array  $booking Prepared booking.
	 * @param string $section Dashboard section.
	 * @return void
	 */
	private static function render_details( $booking, $section ) {
		$status = sanitize_key( $booking['status'] ?? '' );
		$joining =
			'upcoming' === $section
			&& TutorHelper_Booking_Records::STATUS_CONFIRMED === $status
				? sanitize_textarea_field( $booking['location_details'] ?? '' )
				: '';
		$reason = sanitize_textarea_field( $booking['cancellation_reason'] ?? '' );
		ob_start();
		do_action( 'tutorhelper_student_dashboard_booking_details', $booking, $section );
		$extension_details = trim( ob_get_clean() );

		if ( ! $joining && ! $reason && '' === $extension_details ) {
			echo '<span aria-hidden="true">—</span>';
			return;
		}
		?>
		<details class="tutorhelper-pro-dashboard-table__details">
			<summary>
				<span class="tutorhelper-pro-dashboard-table__details-label--closed">
					<?php esc_html_e( 'View details', 'tutorhelper-pro' ); ?>
				</span>
				<span class="tutorhelper-pro-dashboard-table__details-label--open">
					<?php esc_html_e( 'Hide Details', 'tutorhelper-pro' ); ?>
				</span>
				<?php
				TutorHelper_Pro_Lesson_Follow_Up::render_homework_indicators(
					absint( $booking['id'] ?? 0 )
				);
				?>
			</summary>
			<div>
				<?php if ( $joining ) : ?>
					<strong><?php esc_html_e( 'Lesson Notes', 'tutorhelper-pro' ); ?></strong>
					<?php echo wp_kses_post( wpautop( make_clickable( esc_html( $joining ) ) ) ); ?>
				<?php endif; ?>
				<?php if ( $reason ) : ?>
					<strong>
						<?php
						echo esc_html(
							'tutor' === ( $booking['cancelled_by'] ?? '' )
								? __( 'Message from your tutor', 'tutorhelper-pro' )
								: __( 'Cancellation reason', 'tutorhelper-pro' )
						);
						?>
					</strong>
					<p><?php echo esc_html( $reason ); ?></p>
				<?php endif; ?>
				<?php echo $extension_details; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted HTML rendered and escaped by registered TutorHelper extensions. ?>
			</div>
		</details>
		<?php
	}

	/**
	 * Render a cancellation action.
	 *
	 * @param array $booking Prepared booking.
	 * @return void
	 */
	private static function render_cancel( $booking ) {
		if ( empty( $booking['cancellation']['can_cancel'] ) || empty( $booking['id'] ) ) {
			return;
		}

		$id = absint( $booking['id'] );
		?>
		<details class="tutorhelper-pro-dashboard-table__cancel">
			<summary><?php esc_html_e( 'Cancel lesson', 'tutorhelper-pro' ); ?></summary>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( TutorHelper_Student_Dashboard_Actions::CANCEL_ACTION ); ?>" />
				<input type="hidden" name="booking_id" value="<?php echo esc_attr( $id ); ?>" />
				<?php wp_nonce_field( TutorHelper_Student_Dashboard_Actions::CANCEL_ACTION . '_' . $id ); ?>
				<label for="tutorhelper-pro-cancel-<?php echo esc_attr( $id ); ?>">
					<?php esc_html_e( 'Why are you cancelling?', 'tutorhelper-pro' ); ?>
				</label>
				<textarea id="tutorhelper-pro-cancel-<?php echo esc_attr( $id ); ?>" name="cancellation_reason" rows="3" maxlength="500" required></textarea>
				<button type="submit"><?php esc_html_e( 'Confirm cancellation', 'tutorhelper-pro' ); ?></button>
			</form>
		</details>
		<?php
	}

	/**
	 * Normalise a filter value.
	 *
	 * @param string $value Value.
	 * @return string
	 */
	private static function filter_value( $value ) {
		return sanitize_title( remove_accents( (string) $value ) );
	}
}
