<?php
/**
 * TutorHelper Pro group services.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides CRUD-style services for TutorHelper Pro groups.
 *
 * Groups are archived rather than permanently deleted.
 */
final class TutorHelper_Pro_Groups {

	/**
	 * Create a group.
	 *
	 * @param array $data Group data.
	 *
	 * @return int|WP_Error New group ID or error.
	 */
	public static function create( $data ) {
		global $wpdb;

		$data = is_array( $data )
			? $data
			: array();

		$name = isset( $data['name'] )
			? sanitize_text_field(
				$data['name']
			)
			: '';

		$name = trim( $name );

		if ( '' === $name ) {
			return new WP_Error(
				'tutorhelper_pro_group_name_required',
				__(
					'Enter a group name.',
					'tutorhelper-pro'
				)
			);
		}

		$description = isset(
			$data['description']
		)
			? sanitize_textarea_field(
				$data['description']
			)
			: '';

		$slug = isset( $data['slug'] )
			? sanitize_title(
				$data['slug']
			)
			: '';

		if ( '' === $slug ) {
			$slug = sanitize_title(
				$name
			);
		}

		if ( '' === $slug ) {
			$slug = 'group';
		}

		$slug =
			self::get_unique_slug(
				$slug
			);

		$now = current_time(
			'mysql',
			true
		);

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'groups'
				);

		$result = $wpdb->insert(
			$table,
			array(
				'name'        =>
					$name,

				'slug'        =>
					$slug,

				'description' =>
					$description,

				'is_active'   =>
					1,

				'created_at'  =>
					$now,

				'updated_at'  =>
					$now,
			),
			array(
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
			)
		);

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_pro_group_create_failed',
				__(
					'The group could not be created.',
					'tutorhelper-pro'
				)
			);
		}

		return absint(
			$wpdb->insert_id
		);
	}

	/**
	 * Get one group by ID.
	 *
	 * @param int $group_id Group ID.
	 *
	 * @return object|null
	 */
	public static function get_by_id(
		$group_id
	) {
		global $wpdb;

		$group_id = absint(
			$group_id
		);

		if ( ! $group_id ) {
			return null;
		}

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'groups'
				);

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT *
				FROM {$table}
				WHERE id = %d
				LIMIT 1",
				$group_id
			)
		);
	}

	/**
	 * Get one group by slug.
	 *
	 * @param string $slug Group slug.
	 *
	 * @return object|null
	 */
	public static function get_by_slug(
		$slug
	) {
		global $wpdb;

		$slug = sanitize_title(
			$slug
		);

		if ( '' === $slug ) {
			return null;
		}

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'groups'
				);

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT *
				FROM {$table}
				WHERE slug = %s
				LIMIT 1",
				$slug
			)
		);
	}

	/**
	 * Get groups.
	 *
	 * @param array $args Query arguments.
	 *
	 * @return array
	 */
	public static function get_all(
		$args = array()
	) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'active_only' =>
					true,

				'order' =>
					'ASC',
			)
		);

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'groups'
				);

		$where = '';

		if ( ! empty(
			$args['active_only']
		) ) {
			$where =
				' WHERE is_active = 1';
		}

		$order =
			'DESC' === strtoupper(
				(string) $args['order']
			)
				? 'DESC'
				: 'ASC';

		/*
		 * Table name and ordering are internally controlled.
		 * No user-supplied SQL fragments are accepted here.
		 */
		return $wpdb->get_results(
			"SELECT *
			FROM {$table}
			{$where}
			ORDER BY name {$order}, id {$order}"
		);
	}

	/**
	 * Update a group.
	 *
	 * The slug deliberately remains stable when the
	 * visible group name changes.
	 *
	 * @param int   $group_id Group ID.
	 * @param array $data     Updated data.
	 *
	 * @return bool|WP_Error
	 */
	public static function update(
		$group_id,
		$data
	) {
		global $wpdb;

		$group_id = absint(
			$group_id
		);

		if ( ! $group_id ) {
			return new WP_Error(
				'tutorhelper_pro_group_missing',
				__(
					'The group could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$existing =
			self::get_by_id(
				$group_id
			);

		if ( ! $existing ) {
			return new WP_Error(
				'tutorhelper_pro_group_not_found',
				__(
					'The group could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$data = is_array( $data )
			? $data
			: array();

		$update_data =
			array();

		$formats =
			array();

		if (
			array_key_exists(
				'name',
				$data
			)
		) {
			$name =
				trim(
					sanitize_text_field(
						$data['name']
					)
				);

			if ( '' === $name ) {
				return new WP_Error(
					'tutorhelper_pro_group_name_required',
					__(
						'Enter a group name.',
						'tutorhelper-pro'
					)
				);
			}

			$update_data['name'] =
				$name;

			$formats[] = '%s';
		}

		if (
			array_key_exists(
				'description',
				$data
			)
		) {
			$update_data[
				'description'
			] =
				sanitize_textarea_field(
					$data[
						'description'
					]
				);

			$formats[] = '%s';
		}

		if (
			array_key_exists(
				'is_active',
				$data
			)
		) {
			$update_data[
				'is_active'
			] =
				empty(
					$data['is_active']
				)
					? 0
					: 1;

			$formats[] = '%d';
		}

		if ( empty( $update_data ) ) {
			return true;
		}

		$update_data['updated_at'] =
			current_time(
				'mysql',
				true
			);

		$formats[] = '%s';

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'groups'
				);

		$result = $wpdb->update(
			$table,
			$update_data,
			array(
				'id' =>
					$group_id,
			),
			$formats,
			array(
				'%d',
			)
		);

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_pro_group_update_failed',
				__(
					'The group could not be updated.',
					'tutorhelper-pro'
				)
			);
		}

		return true;
	}

	/**
	 * Archive a group.
	 *
	 * @param int $group_id Group ID.
	 *
	 * @return bool|WP_Error
	 */
	public static function archive(
		$group_id
	) {
		return self::update(
			$group_id,
			array(
				'is_active' => 0,
			)
		);
	}

	/**
	 * Restore an archived group.
	 *
	 * @param int $group_id Group ID.
	 *
	 * @return bool|WP_Error
	 */
	public static function restore(
		$group_id
	) {
		return self::update(
			$group_id,
			array(
				'is_active' => 1,
			)
		);
	}

	/**
	 * Generate a unique group slug.
	 *
	 * @param string $slug Requested slug.
	 *
	 * @return string
	 */
	private static function get_unique_slug(
		$slug
	) {
		$slug = sanitize_title(
			$slug
		);

		if ( '' === $slug ) {
			$slug = 'group';
		}

		$candidate =
			$slug;

		$suffix = 2;

		while (
			self::get_by_slug(
				$candidate
			)
		) {
			$candidate =
				$slug
				. '-'
				. $suffix;

			$suffix++;
		}

		return $candidate;
	}


    /**
     * Assign a student to a group.
     *
     * @param int $group_id        Group ID.
     * @param int $student_user_id Student WordPress user ID.
     *
     * @return bool|WP_Error
     */
    public static function assign_student(
        $group_id,
        $student_user_id
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        $student_user_id = absint(
            $student_user_id
        );

        $group = self::get_by_id(
            $group_id
        );

        if ( ! $group ) {
            return new WP_Error(
                'tutorhelper_pro_group_not_found',
                __(
                    'The group could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        $student =
            TutorHelper_Students::get_student(
                $student_user_id
            );

        if ( ! $student instanceof WP_User ) {
            return new WP_Error(
                'tutorhelper_pro_group_student_not_found',
                __(
                    'The student could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            self::student_is_in_group(
                $group_id,
                $student_user_id
            )
        ) {
            return true;
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'student_groups'
                );

        $result = $wpdb->insert(
            $table,
            array(
                'group_id' =>
                    $group_id,

                'student_user_id' =>
                    $student_user_id,

                'created_at' =>
                    current_time(
                        'mysql',
                        true
                    ),
            ),
            array(
                '%d',
                '%d',
                '%s',
            )
        );

        if ( false === $result ) {
            return new WP_Error(
                'tutorhelper_pro_group_assignment_failed',
                __(
                    'The student could not be added to the group.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }


    /**
     * Remove a student from a group.
     *
     * @param int $group_id        Group ID.
     * @param int $student_user_id Student WordPress user ID.
     *
     * @return bool|WP_Error
     */
    public static function remove_student(
        $group_id,
        $student_user_id
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        $student_user_id = absint(
            $student_user_id
        );

        if (
            ! $group_id
            || ! $student_user_id
        ) {
            return new WP_Error(
                'tutorhelper_pro_group_membership_invalid',
                __(
                    'The group membership is invalid.',
                    'tutorhelper-pro'
                )
            );
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'student_groups'
                );

        $result = $wpdb->delete(
            $table,
            array(
                'group_id' =>
                    $group_id,

                'student_user_id' =>
                    $student_user_id,
            ),
            array(
                '%d',
                '%d',
            )
        );

        if ( false === $result ) {
            return new WP_Error(
                'tutorhelper_pro_group_removal_failed',
                __(
                    'The student could not be removed from the group.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }



    /**
     * Check whether a student belongs to a group.
     *
     * @param int $group_id        Group ID.
     * @param int $student_user_id Student WordPress user ID.
     *
     * @return bool
     */
    public static function student_is_in_group(
        $group_id,
        $student_user_id
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        $student_user_id = absint(
            $student_user_id
        );

        if (
            ! $group_id
            || ! $student_user_id
        ) {
            return false;
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'student_groups'
                );

        $membership = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT group_id
                FROM {$table}
                WHERE group_id = %d
                    AND student_user_id = %d
                LIMIT 1",
                $group_id,
                $student_user_id
            )
        );

        return null !== $membership;
    }


    /**
     * Get groups assigned to a student.
     *
     * @param int  $student_user_id Student WordPress user ID.
     * @param bool $active_only     Whether to return active groups only.
     *
     * @return array
     */
    public static function get_student_groups(
        $student_user_id,
        $active_only = true
    ) {
        global $wpdb;

        $student_user_id = absint(
            $student_user_id
        );

        if ( ! $student_user_id ) {
            return array();
        }

        $groups_table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'groups'
                );

        $student_groups_table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'student_groups'
                );

        $active_sql = $active_only
            ? ' AND g.is_active = 1'
            : '';

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT g.*
                FROM {$groups_table} g
                INNER JOIN {$student_groups_table} sg
                    ON sg.group_id = g.id
                WHERE sg.student_user_id = %d
                {$active_sql}
                ORDER BY g.name ASC, g.id ASC",
                $student_user_id
            )
        );
    }

    /** Return LMS courses associated with a Group. */
    public static function get_group_courses( $group_id ) {
        global $wpdb;
        $group_id = absint( $group_id );
        if ( ! $group_id ) { return array(); }
        $table = TutorHelper_Pro_Database::get_table_name( 'group_courses' );
        return array_map( 'absint', (array) $wpdb->get_col( $wpdb->prepare( "SELECT course_id FROM {$table} WHERE group_id = %d ORDER BY course_id ASC", $group_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Reads explicit Group-to-course links.
    }

    /** Replace explicit LMS course links for one Group. */
    public static function replace_group_courses( $group_id, $course_ids ) {
        global $wpdb;
        $group_id = absint( $group_id );
        if ( ! self::get_by_id( $group_id ) ) { return new WP_Error( 'tutorhelper_pro_group_not_found', __( 'The group could not be found.', 'tutorhelper-pro' ) ); }
        $course_ids = array_values( array_unique( array_filter( array_map( 'absint', is_array( $course_ids ) ? $course_ids : array() ) ) ) );
        foreach ( $course_ids as $course_id ) { if ( 'tutorhelper_course' !== get_post_type( $course_id ) ) { return new WP_Error( 'tutorhelper_pro_invalid_course', __( 'Select valid LMS courses for this group.', 'tutorhelper-pro' ) ); } }
        $table = TutorHelper_Pro_Database::get_table_name( 'group_courses' );
        if ( false === $wpdb->delete( $table, array( 'group_id' => $group_id ), array( '%d' ) ) ) { return new WP_Error( 'tutorhelper_pro_group_courses_delete_failed', __( 'The group courses could not be saved.', 'tutorhelper-pro' ) ); } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Replaces only this Group's links.
        $now = current_time( 'mysql', true );
        foreach ( $course_ids as $course_id ) { if ( false === $wpdb->insert( $table, array( 'group_id' => $group_id, 'course_id' => $course_id, 'created_at' => $now ), array( '%d', '%d', '%s' ) ) ) { return new WP_Error( 'tutorhelper_pro_group_courses_insert_failed', __( 'The group courses could not be saved.', 'tutorhelper-pro' ) ); } } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Stores explicit Group-to-course links.
        return true;
    }

    /** Return deduplicated LMS courses available from a student's active Groups. */
    public static function get_student_group_courses( $student_user_id ) {
        $courses = array();
        foreach ( self::get_student_groups( $student_user_id, true ) as $group ) {
            $group_id = absint( $group->id );
            foreach ( self::get_group_courses( $group_id ) as $course_id ) {
                if ( 'tutorhelper_course' !== get_post_type( $course_id ) ) { continue; }
                if ( ! isset( $courses[ $course_id ] ) ) { $courses[ $course_id ] = array( 'course_id' => $course_id, 'source_group_ids' => array() ); }
                $courses[ $course_id ]['source_group_ids'][] = $group_id;
            }
        }
        foreach ( $courses as &$course ) { $course['source_group_ids'] = array_values( array_unique( array_map( 'absint', $course['source_group_ids'] ) ) ); }
        return array_values( $courses );
    }

    /**
     * Get TutorHelper students assigned to a group.
     *
     * @param int $group_id Group ID.
     *
     * @return array
     */
    public static function get_group_students(
        $group_id
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        if ( ! $group_id ) {
            return array();
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'student_groups'
                );

        $student_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT student_user_id
                FROM {$table}
                WHERE group_id = %d
                ORDER BY student_user_id ASC",
                $group_id
            )
        );

        if ( empty( $student_ids ) ) {
            return array();
        }

        $students = array();

        foreach ( $student_ids as $student_user_id ) {

            $student =
                TutorHelper_Students::
                    get_student(
                        $student_user_id
                    );

            if (
                $student instanceof WP_User
            ) {
                $students[] =
                    $student;
            }
        }

        usort(
            $students,
            function ( $student_a, $student_b ) {

                return strcasecmp(
                    $student_a->display_name,
                    $student_b->display_name
                );
            }
        );

        return $students;
    }

    /**
     * Count students assigned to a group.
     *
     * @param int $group_id Group ID.
     *
     * @return int
     */
    public static function get_group_student_count(
        $group_id
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        if ( ! $group_id ) {
            return 0;
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'student_groups'
                );

        return absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*)
                    FROM {$table}
                    WHERE group_id = %d",
                    $group_id
                )
            )
        );
    }

    /**
     * Assign a Booking Type to a group.
     *
     * @param int $group_id        Group ID.
     * @param int $booking_type_id Booking Type ID.
     *
     * @return bool|WP_Error
     */
    public static function assign_booking_type(
        $group_id,
        $booking_type_id
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        $booking_type_id = absint(
            $booking_type_id
        );

        $group = self::get_by_id(
            $group_id
        );

        if ( ! $group ) {
            return new WP_Error(
                'tutorhelper_pro_group_not_found',
                __(
                    'The group could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        $booking_type =
            TutorHelper_Booking_Types::get_by_id(
                $booking_type_id
            );

        if ( ! $booking_type ) {
            return new WP_Error(
                'tutorhelper_pro_group_booking_type_not_found',
                __(
                    'The Booking Type could not be found.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            self::booking_type_is_in_group(
                $group_id,
                $booking_type_id
            )
        ) {
            return true;
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'booking_type_groups'
                );

        $result = $wpdb->insert(
            $table,
            array(
                'group_id' =>
                    $group_id,

                'booking_type_id' =>
                    $booking_type_id,

                'created_at' =>
                    current_time(
                        'mysql',
                        true
                    ),
            ),
            array(
                '%d',
                '%d',
                '%s',
            )
        );

        if ( false === $result ) {
            return new WP_Error(
                'tutorhelper_pro_group_booking_type_assignment_failed',
                __(
                    'The Booking Type could not be added to the group.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }


    /**
     * Remove a Booking Type from a group.
     *
     * @param int $group_id        Group ID.
     * @param int $booking_type_id Booking Type ID.
     *
     * @return bool|WP_Error
     */
    public static function remove_booking_type(
        $group_id,
        $booking_type_id
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        $booking_type_id = absint(
            $booking_type_id
        );

        if (
            ! $group_id
            || ! $booking_type_id
        ) {
            return new WP_Error(
                'tutorhelper_pro_group_booking_type_invalid',
                __(
                    'The Booking Type relationship is invalid.',
                    'tutorhelper-pro'
                )
            );
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'booking_type_groups'
                );

        $result = $wpdb->delete(
            $table,
            array(
                'group_id' =>
                    $group_id,

                'booking_type_id' =>
                    $booking_type_id,
            ),
            array(
                '%d',
                '%d',
            )
        );

        if ( false === $result ) {
            return new WP_Error(
                'tutorhelper_pro_group_booking_type_removal_failed',
                __(
                    'The Booking Type could not be removed from the group.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }


    /**
     * Check whether a Booking Type is assigned to a group.
     *
     * @param int $group_id        Group ID.
     * @param int $booking_type_id Booking Type ID.
     *
     * @return bool
     */
    public static function booking_type_is_in_group(
        $group_id,
        $booking_type_id
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        $booking_type_id = absint(
            $booking_type_id
        );

        if (
            ! $group_id
            || ! $booking_type_id
        ) {
            return false;
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'booking_type_groups'
                );

        $relationship = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT group_id
                FROM {$table}
                WHERE group_id = %d
                    AND booking_type_id = %d
                LIMIT 1",
                $group_id,
                $booking_type_id
            )
        );

        return null !== $relationship;
    }


    /**
     * Get Booking Types assigned to a group.
     *
     * @param int  $group_id    Group ID.
     * @param bool $active_only Whether to return active Booking Types only.
     *
     * @return array
     */
    public static function get_group_booking_types(
        $group_id,
        $active_only = true
    ) {
        global $wpdb;

        $group_id = absint(
            $group_id
        );

        if ( ! $group_id ) {
            return array();
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'booking_type_groups'
                );

        $booking_type_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT booking_type_id
                FROM {$table}
                WHERE group_id = %d
                ORDER BY booking_type_id ASC",
                $group_id
            )
        );

        if ( empty( $booking_type_ids ) ) {
            return array();
        }

        $booking_types = array();

        foreach (
            $booking_type_ids as $booking_type_id
        ) {
            $booking_type =
                TutorHelper_Booking_Types::get_by_id(
                    $booking_type_id
                );

            if ( ! $booking_type ) {
                continue;
            }

            if (
                $active_only
                && 1 !== absint(
                    $booking_type->is_active
                )
            ) {
                continue;
            }

            $booking_types[] =
                $booking_type;
        }

        usort(
            $booking_types,
            function (
                $booking_type_a,
                $booking_type_b
            ) {
                $order_a = absint(
                    $booking_type_a->sort_order
                );

                $order_b = absint(
                    $booking_type_b->sort_order
                );

                if ( $order_a === $order_b ) {
                    return strcasecmp(
                        $booking_type_a->title,
                        $booking_type_b->title
                    );
                }

                return $order_a
                    <=> $order_b;
            }
        );

        return $booking_types;
    }


    /**
     * Get groups assigned to a Booking Type.
     *
     * @param int  $booking_type_id Booking Type ID.
     * @param bool $active_only     Whether to return active groups only.
     *
     * @return array
     */
    public static function get_booking_type_groups(
        $booking_type_id,
        $active_only = true
    ) {
        global $wpdb;

        $booking_type_id = absint(
            $booking_type_id
        );

        if ( ! $booking_type_id ) {
            return array();
        }

        $groups_table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'groups'
                );

        $relationship_table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'booking_type_groups'
                );

        $active_sql = $active_only
            ? ' AND g.is_active = 1'
            : '';

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT g.*
                FROM {$groups_table} g
                INNER JOIN {$relationship_table} btg
                    ON btg.group_id = g.id
                WHERE btg.booking_type_id = %d
                {$active_sql}
                ORDER BY g.name ASC, g.id ASC",
                $booking_type_id
            )
        );
    }


}
