<?php
/**
 * TutorHelper Pro Groups admin interface.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Integrates Pro Groups with the TutorHelper Booking Hub.
 */
final class TutorHelper_Pro_Groups_Admin {

	/**
	 * Booking Hub tab key.
	 *
	 * @var string
	 */
	const TAB_KEY = 'groups';

	/**
	 * Create/update group action.
	 *
	 * @var string
	 */
	const SAVE_ACTION =
		'tutorhelper_pro_save_group';

	/**
	 * Archive/restore group action.
	 *
	 * @var string
	 */
	const STATUS_ACTION =
		'tutorhelper_pro_group_status';

    /**
     * Group membership action.
     *
     * @var string
     */
    const MEMBERSHIP_ACTION =
        'tutorhelper_pro_group_membership';

    /**
     * Booking Type group relationship action.
     *
     * @var string
     */
    const BOOKING_TYPE_ACTION =
        'tutorhelper_pro_group_booking_type';



	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_booking_hub_tabs',
			array(
				__CLASS__,
				'register_tab',
			)
		);

		add_action(
			'tutorhelper_booking_hub_render_tab',
			array(
				__CLASS__,
				'render_hub_tab',
			),
			10,
			2
		);

		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array(
				__CLASS__,
				'handle_save_group',
			)
		);

		add_action(
			'admin_post_' . self::STATUS_ACTION,
			array(
				__CLASS__,
				'handle_group_status',
			)
		);

        add_action(
            'admin_enqueue_scripts',
            array(
                __CLASS__,
                'enqueue_assets',
            )
        );

        add_action(
            'admin_post_' . self::MEMBERSHIP_ACTION,
            array(
                __CLASS__,
                'handle_membership',
            )
        );

        add_action(
            'tutorhelper_students_render_account_sidebar',
            array(
                __CLASS__,
                'render_student_groups',
            )
        );

        add_filter(
            'tutorhelper_students_detail_additional_information_items',
            array(
                __CLASS__,
                'register_student_groups_information',
            )
        );

        add_action(
            'admin_post_' . self::BOOKING_TYPE_ACTION,
            array(
                __CLASS__,
                'handle_booking_type_relationship',
            )
        );
	}


    /**
     * Enqueue TutorHelper Pro admin assets.
     *
     * @param string $hook_suffix Current admin page hook.
     *
     * @return void
     */
    public static function enqueue_assets(
        $hook_suffix
    ) {
        if (
            'toplevel_page_'
                . TutorHelper_Admin::MENU_SLUG
            !== $hook_suffix
        ) {
            return;
        }

        $selected_tab = isset(
            $_GET['tab']
        )
            ? sanitize_key(
                wp_unslash(
                    $_GET['tab']
                )
            )
            : '';

        if (
            ! in_array(
                $selected_tab,
                array(
                    self::TAB_KEY,
                    TutorHelper_Students_Admin::
                        TAB_KEY,
                ),
                true
            )
        ) {
            return;
        }

        $css_path =
            TUTORHELPER_PRO_PATH
            . 'assets/css/tutorhelper-pro-admin.css';

        wp_enqueue_style(
            'tutorhelper-pro-admin',
            TUTORHELPER_PRO_URL
                . 'assets/css/tutorhelper-pro-admin.css',
            array(),
            file_exists( $css_path )
                ? (string) filemtime(
                    $css_path
                )
                : TUTORHELPER_PRO_VERSION
        );
    }



	/**
	 * Insert Groups immediately after Students.
	 *
	 * @param array $tabs Booking Hub tabs.
	 *
	 * @return array
	 */
	public static function register_tab(
		$tabs
	) {
		if ( ! is_array( $tabs ) ) {
			return $tabs;
		}

		$groups_tab = array(
			'label' => __(
				'Groups',
				'tutorhelper-pro'
			),

			'icon' =>
				'dashicons-networking',

			'status' =>
				'available',

			'description' => __(
				'Manage student groups and memberships.',
				'tutorhelper-pro'
			),
		);

		$updated_tabs = array();

		foreach (
			$tabs as $tab_key => $tab
		) {
			$updated_tabs[
				$tab_key
			] = $tab;

			if (
				TutorHelper_Students_Admin::
					TAB_KEY
				=== $tab_key
			) {
				$updated_tabs[
					self::TAB_KEY
				] = $groups_tab;
			}
		}

		/*
		 * Defensive fallback in case the Students
		 * tab is removed by another extension.
		 */
		if (
			! isset(
				$updated_tabs[
					self::TAB_KEY
				]
			)
		) {
			$updated_tabs[
				self::TAB_KEY
			] = $groups_tab;
		}

		return $updated_tabs;
	}

	/**
	 * Render the Groups Hub tab.
	 *
	 * @param string $selected_tab Selected tab key.
	 * @param array  $active_tab   Active tab definition.
	 *
	 * @return void
	 */
	public static function render_hub_tab(
		$selected_tab,
		$active_tab
	) {
		if (
			self::TAB_KEY
			!== $selected_tab
		) {
			return;
		}

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		self::render_workspace(
			$active_tab
		);
	}

	/**
	 * Render Groups workspace.
	 *
	 * @param array $active_tab Active tab definition.
	 *
	 * @return void
	 */
	private static function render_workspace(
		$active_tab
	) {
		$group_id = isset(
			$_GET['group_id']
		)
			? absint(
				wp_unslash(
					$_GET['group_id']
				)
			)
			: 0;

		$group = $group_id
			? TutorHelper_Pro_Groups::
				get_by_id(
					$group_id
				)
			: null;

		$show_archived = isset(
			$_GET['show_archived']
		)
			&& '1' === sanitize_text_field(
				wp_unslash(
					$_GET['show_archived']
				)
			);

		$groups =
			TutorHelper_Pro_Groups::
				get_all(
					array(
						'active_only' =>
							! $show_archived,
					)
				);

		?>
		<section class="tutorhelper-groups-workspace">

			<header class="tutorhelper-workspace__header">
				<div>
					<h2>
						<?php
						echo esc_html(
							isset(
								$active_tab[
									'label'
								]
							)
								? $active_tab[
									'label'
								]
								: __(
									'Groups',
									'tutorhelper-pro'
								)
						);
						?>
					</h2>

					<p>
						<?php
						echo esc_html__(
							'Manage student groups and memberships.',
							'tutorhelper-pro'
						);
						?>
					</p>
				</div>
			</header>

			<?php
			self::render_notice();
			?>

			<div class="tutorhelper-students-workspace__grid">

				<main class="tutorhelper-students-workspace__main">

					<?php
					self::render_groups_list(
						$groups,
						$show_archived
					);
					?>

				</main>

				<aside class="tutorhelper-students-workspace__sidebar">

					<?php
					self::render_group_form(
						$group
					);
                    if ( $group ) {
                        self::render_group_memberships(
                            $group
                        );
                    }
                    if ( $group ) {
                        self::render_group_booking_types(
                            $group
                        );
                    }
					?>

				</aside>

			</div>

		</section>
		<?php
	}


    /**
     * Render Booking Type relationships for a group.
     *
     * @param object $group Group record.
     *
     * @return void
     */
    private static function render_group_booking_types(
        $group
    ) {
        $group_id = absint(
            $group->id
        );

        $assigned_booking_types =
            TutorHelper_Pro_Groups::
                get_group_booking_types(
                    $group_id,
                    false
                );

        $all_booking_types =
            TutorHelper_Booking_Types::
                get_all();

        $available_booking_types =
            array();

        foreach (
            $all_booking_types
                as $booking_type
        ) {
            if (
                ! TutorHelper_Pro_Groups::
                    booking_type_is_in_group(
                        $group_id,
                        $booking_type->id
                    )
            ) {
                $available_booking_types[] =
                    $booking_type;
            }
        }

        ?>
        <section
            class="tutorhelper-main-section tutorhelper-pro-group-booking-types"
        >

            <header
                class="tutorhelper-main-section__header"
            >
                <div
                    class="tutorhelper-main-section__header-content"
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Booking Types',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        printf(
                            esc_html(
                                _n(
                                    '%d Booking Type',
                                    '%d Booking Types',
                                    count(
                                        $assigned_booking_types
                                    ),
                                    'tutorhelper-pro'
                                )
                            ),
                            absint(
                                count(
                                    $assigned_booking_types
                                )
                            )
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="tutorhelper-main-section__body"
            >

                <?php if (
                    empty(
                        $assigned_booking_types
                    )
                ) : ?>

                    <p
                        class="tutorhelper-student-muted"
                    >
                        <?php
                        echo esc_html__(
                            'No Booking Types are currently assigned to this group.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                <?php else : ?>

                    <ul
                        class="tutorhelper-pro-group-booking-types__list"
                    >

                        <?php foreach (
                            $assigned_booking_types
                                as $booking_type
                        ) : ?>

                            <li>

                                <span>
                                    <strong>
                                        <?php
                                        echo esc_html(
                                            $booking_type
                                                ->title
                                        );
                                        ?>
                                    </strong>

                                    <?php if (
                                        1 !== absint(
                                            $booking_type
                                                ->is_active
                                        )
                                    ) : ?>

                                        <small>
                                            <?php
                                            echo esc_html__(
                                                'Archived',
                                                'tutorhelper-pro'
                                            );
                                            ?>
                                        </small>

                                    <?php endif; ?>
                                </span>

                                <?php
                                $remove_url =
                                    wp_nonce_url(
                                        add_query_arg(
                                            array(
                                                'action' =>
                                                    self::
                                                        BOOKING_TYPE_ACTION,

                                                'group_id' =>
                                                    $group_id,

                                                'booking_type_id' =>
                                                    $booking_type
                                                        ->id,

                                                'relationship_action' =>
                                                    'remove',
                                            ),
                                            admin_url(
                                                'admin-post.php'
                                            )
                                        ),
                                        self::
                                            BOOKING_TYPE_ACTION
                                            . '_'
                                            . $group_id
                                    );
                                ?>

                                <a
                                    class="tutorhelper-hub-pill-button-small"
                                    href="<?php
                                    echo esc_url(
                                        $remove_url
                                    );
                                    ?>"
                                >
                                    <?php
                                    echo esc_html__(
                                        'Remove',
                                        'tutorhelper-pro'
                                    );
                                    ?>
                                </a>

                            </li>

                        <?php endforeach; ?>

                    </ul>

                <?php endif; ?>

                <?php if (
                    ! empty(
                        $available_booking_types
                    )
                ) : ?>

                    <form
                        method="post"
                        action="<?php
                        echo esc_url(
                            admin_url(
                                'admin-post.php'
                            )
                        );
                        ?>"
                        class="tutorhelper-pro-group-booking-types__add"
                    >

                        <input
                            type="hidden"
                            name="action"
                            value="<?php
                            echo esc_attr(
                                self::
                                    BOOKING_TYPE_ACTION
                            );
                            ?>"
                        />

                        <input
                            type="hidden"
                            name="relationship_action"
                            value="add"
                        />

                        <input
                            type="hidden"
                            name="group_id"
                            value="<?php
                            echo esc_attr(
                                $group_id
                            );
                            ?>"
                        />

                        <?php
                        wp_nonce_field(
                            self::
                                BOOKING_TYPE_ACTION
                                . '_'
                                . $group_id
                        );
                        ?>

                        <label
                            for="tutorhelper-pro-group-booking-type-<?php
                            echo esc_attr(
                                $group_id
                            );
                            ?>"
                        >
                            <strong>
                                <?php
                                echo esc_html__(
                                    'Add Booking Type',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </strong>
                        </label>

                        <select
                            id="tutorhelper-pro-group-booking-type-<?php
                            echo esc_attr(
                                $group_id
                            );
                            ?>"
                            name="booking_type_id"
                            required
                        >

                            <option value="">
                                <?php
                                echo esc_html__(
                                    'Select a Booking Type…',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </option>

                            <?php foreach (
                                $available_booking_types
                                    as $booking_type
                            ) : ?>

                                <option
                                    value="<?php
                                    echo esc_attr(
                                        $booking_type->id
                                    );
                                    ?>"
                                >
                                    <?php
                                    echo esc_html(
                                        $booking_type->title
                                    );
                                    ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <p
                            id="tutorhelper-pro-group-student-help-<?php
                            echo esc_attr(
                                $group_id
                            );
                            ?>"
                            class="description"
                        >
                            <?php
                            echo esc_html__(
                                'Select one or more students. Hold Ctrl (Windows) or Command (Mac) to select several.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </p>

                        <button
                            type="submit"
                            class="button button-primary tutorhelper-action-button"
                        >
                            <?php
                            echo esc_html__(
                                'Add Booking Type',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>

                    </form>

                <?php endif; ?>

            </div>

        </section>
        <?php
    }


    /**
     * Handle Booking Type group relationship changes.
     *
     * @return void
     */
    public static function handle_booking_type_relationship() {

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You are not allowed to manage group Booking Types.',
                    'tutorhelper-pro'
                )
            );
        }

        $group_id = isset(
            $_REQUEST['group_id']
        )
            ? absint(
                wp_unslash(
                    $_REQUEST['group_id']
                )
            )
            : 0;

        check_admin_referer(
            self::BOOKING_TYPE_ACTION
                . '_'
                . $group_id
        );

        $booking_type_id = isset(
            $_REQUEST['booking_type_id']
        )
            ? absint(
                wp_unslash(
                    $_REQUEST[
                        'booking_type_id'
                    ]
                )
            )
            : 0;

        $relationship_action = isset(
            $_REQUEST[
                'relationship_action'
            ]
        )
            ? sanitize_key(
                wp_unslash(
                    $_REQUEST[
                        'relationship_action'
                    ]
                )
            )
            : '';

        if (
            ! $group_id
            || ! $booking_type_id
            || ! in_array(
                $relationship_action,
                array(
                    'add',
                    'remove',
                ),
                true
            )
        ) {
            self::redirect_with_notice(
                'booking_type_relationship_invalid',
                'error',
                $group_id
            );
        }

        if (
            'add'
            === $relationship_action
        ) {
            $result =
                TutorHelper_Pro_Groups::
                    assign_booking_type(
                        $group_id,
                        $booking_type_id
                    );

            $notice =
                'booking_type_added';
        } else {
            $result =
                TutorHelper_Pro_Groups::
                    remove_booking_type(
                        $group_id,
                        $booking_type_id
                    );

            $notice =
                'booking_type_removed';
        }

        if ( is_wp_error( $result ) ) {
            self::redirect_with_notice(
                $result->get_error_code(),
                'error',
                $group_id
            );
        }

        self::redirect_with_notice(
            $notice,
            'success',
            $group_id
        );
    }


    /**
     * Handle student group membership changes.
     *
     * @return void
     */
    public static function handle_membership() {

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You are not allowed to manage group memberships.',
                    'tutorhelper-pro'
                )
            );
        }

        $group_id = isset(
            $_REQUEST['group_id']
        )
            ? absint(
                wp_unslash(
                    $_REQUEST['group_id']
                )
            )
            : 0;

        check_admin_referer(
            self::MEMBERSHIP_ACTION
                . '_'
                . $group_id
        );

        $membership_action = isset(
            $_REQUEST[
                'membership_action'
            ]
        )
            ? sanitize_key(
                wp_unslash(
                    $_REQUEST[
                        'membership_action'
                    ]
                )
            )
            : '';

        if (
            ! $group_id
            || ! in_array(
                $membership_action,
                array(
                    'add',
                    'remove',
                ),
                true
            )
        ) {
            self::redirect_with_notice(
                'membership_invalid',
                'error',
                $group_id
            );
        }

        if ( 'add' === $membership_action ) {
            $student_user_ids = isset(
                $_POST['student_user_ids']
            )
                ? array_map(
                    'absint',
                    (array) wp_unslash(
                        $_POST['student_user_ids']
                    )
                )
                : array();

            // Retain compatibility with the previous single-student form.
            if (
                empty( $student_user_ids )
                && isset( $_POST['student_user_id'] )
            ) {
                $student_user_ids[] = absint(
                    wp_unslash(
                        $_POST['student_user_id']
                    )
                );
            }

            $student_user_ids = array_values(
                array_filter(
                    array_unique(
                        $student_user_ids
                    )
                )
            );

            if ( empty( $student_user_ids ) ) {
                self::redirect_with_notice(
                    'membership_invalid',
                    'error',
                    $group_id
                );
            }

            foreach ( $student_user_ids as $student_user_id ) {
                $result =
                    TutorHelper_Pro_Groups::
                        assign_student(
                            $group_id,
                            $student_user_id
                        );

                if ( is_wp_error( $result ) ) {
                    self::redirect_with_notice(
                        $result->get_error_code(),
                        'error',
                        $group_id
                    );
                }
            }

            self::redirect_with_notice(
                1 < count( $student_user_ids )
                    ? 'students_added'
                    : 'student_added',
                'success',
                $group_id
            );
        }

        $student_user_id = isset(
            $_REQUEST['student_user_id']
        )
            ? absint(
                wp_unslash(
                    $_REQUEST[
                        'student_user_id'
                    ]
                )
            )
            : 0;

        if ( ! $student_user_id ) {
            self::redirect_with_notice(
                'membership_invalid',
                'error',
                $group_id
            );
        }

        $group = TutorHelper_Pro_Groups::get_by_id( $group_id );
        $group_course_ids = TutorHelper_Pro_Groups::get_group_courses( $group_id );
        $course_exit_status = isset( $_REQUEST['course_exit_status'] ) && ! is_array( $_REQUEST['course_exit_status'] )
            ? sanitize_key( wp_unslash( $_REQUEST['course_exit_status'] ) )
            : '';

        $result =
            TutorHelper_Pro_Groups::
                remove_student(
                    $group_id,
                    $student_user_id
                );

        if ( is_wp_error( $result ) ) {
            self::redirect_with_notice(
                $result->get_error_code(),
                'error',
                $group_id
            );
        }

        if ( $group_course_ids && in_array( $course_exit_status, array( 'completed', 'withdrawn' ), true ) ) {
            $remaining_courses = TutorHelper_Pro_Groups::get_student_group_courses( $student_user_id );
            $remaining_course_ids = array_map( 'absint', wp_list_pluck( $remaining_courses, 'course_id' ) );
            do_action( 'tutorhelper_lms_group_course_exit', $student_user_id, $group_id, $group ? $group->name : '', $group_course_ids, $course_exit_status, $remaining_course_ids );
        }

        self::redirect_with_notice(
            'student_removed',
            'success',
            $group_id
        );
    }


    /**
     * Render membership controls for a group.
     *
     * @param object $group Group record.
     *
     * @return void
     */
    private static function render_group_memberships(
        $group
    ) {
        $group_id = absint(
            $group->id
        );

        $group_course_ids = TutorHelper_Pro_Groups::get_group_courses( $group_id );
        $retain_group_course_history = ! empty( $group_course_ids )
            && class_exists( 'TutorHelper_LMS_Student_Academic_Context' );

        $members =
            TutorHelper_Pro_Groups::
                get_group_students(
                    $group_id
                );

        $student_result =
            TutorHelper_Students::
                get_students(
                    array(
                        'page'     => 1,
                        'per_page' => 100,
                        'orderby'  =>
                            'display_name',
                        'order'    =>
                            'ASC',
                    )
                );

        $available_students =
            array();

        if (
            is_array(
                $student_result
            )
            && ! empty(
                $student_result[
                    'students'
                ]
            )
        ) {
            foreach (
                $student_result[
                    'students'
                ] as $student
            ) {
                if (
                    ! TutorHelper_Pro_Groups::
                        student_is_in_group(
                            $group_id,
                            $student->ID
                        )
                ) {
                    $available_students[] =
                        $student;
                }
            }
        }

        ?>
        <section
            class="tutorhelper-main-section tutorhelper-pro-group-members"
        >

            <header
                class="tutorhelper-main-section__header"
            >
                <div
                    class="tutorhelper-main-section__header-content"
                >
                    <h2>
                        <?php
                        echo esc_html__(
                            'Group Members',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        printf(
                            esc_html(
                                _n(
                                    '%d student',
                                    '%d students',
                                    count(
                                        $members
                                    ),
                                    'tutorhelper-pro'
                                )
                            ),
                            absint(
                                count(
                                    $members
                                )
                            )
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div
                class="tutorhelper-main-section__body"
            >

                <?php if (
                    empty(
                        $members
                    )
                ) : ?>

                    <p
                        class="tutorhelper-student-muted"
                    >
                        <?php
                        echo esc_html__(
                            'No students are currently assigned to this group.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                <?php else : ?>

                    <ul
                        class="tutorhelper-pro-group-members__list"
                    >

                        <?php foreach (
                            $members as $student
                        ) : ?>

                            <li>
                                <span>
                                    <strong>
                                        <?php
                                        echo esc_html(
                                            $student
                                                ->display_name
                                        );
                                        ?>
                                    </strong>

                                    <small>
                                        <?php
                                        echo esc_html(
                                            $student
                                                ->user_email
                                        );
                                        ?>
                                    </small>
                                </span>

                                <?php
                                if ( $retain_group_course_history ) : ?>
                                    <details class="tutorhelper-pro-group-members__remove-confirmation">
                                        <summary class="tutorhelper-hub-pill-button-small"><?php esc_html_e( 'Remove', 'tutorhelper-pro' ); ?></summary>
                                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                            <input type="hidden" name="action" value="<?php echo esc_attr( self::MEMBERSHIP_ACTION ); ?>" />
                                            <input type="hidden" name="group_id" value="<?php echo esc_attr( $group_id ); ?>" />
                                            <input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student->ID ); ?>" />
                                            <input type="hidden" name="membership_action" value="remove" />
                                            <?php wp_nonce_field( self::MEMBERSHIP_ACTION . '_' . $group_id ); ?>
                                            <p><?php esc_html_e( 'This Group provides academic course links. Retain them as:', 'tutorhelper-pro' ); ?></p>
                                            <label><select name="course_exit_status"><option value="completed"><?php esc_html_e( 'Completed', 'tutorhelper-pro' ); ?></option><option value="withdrawn"><?php esc_html_e( 'Withdrawn', 'tutorhelper-pro' ); ?></option></select></label>
                                            <button type="submit" class="button button-primary"><?php esc_html_e( 'Confirm removal', 'tutorhelper-pro' ); ?></button>
                                        </form>
                                    </details>
                                <?php else :
                                $remove_url = wp_nonce_url( add_query_arg( array( 'action' => self::MEMBERSHIP_ACTION, 'group_id' => $group_id, 'student_user_id' => $student->ID, 'membership_action' => 'remove' ), admin_url( 'admin-post.php' ) ), self::MEMBERSHIP_ACTION . '_' . $group_id );
                                ?>
                                <a class="tutorhelper-hub-pill-button-small" href="<?php echo esc_url( $remove_url ); ?>"><?php esc_html_e( 'Remove', 'tutorhelper-pro' ); ?></a>
                                <?php endif; ?>
                            </li>

                        <?php endforeach; ?>

                    </ul>

                <?php endif; ?>

                <?php if (
                    ! empty(
                        $available_students
                    )
                ) : ?>

                    <form
                        method="post"
                        action="<?php
                        echo esc_url(
                            admin_url(
                                'admin-post.php'
                            )
                        );
                        ?>"
                        class="tutorhelper-pro-group-members__add"
                    >

                        <input
                            type="hidden"
                            name="action"
                            value="<?php
                            echo esc_attr(
                                self::
                                    MEMBERSHIP_ACTION
                            );
                            ?>"
                        />

                        <input
                            type="hidden"
                            name="membership_action"
                            value="add"
                        />

                        <input
                            type="hidden"
                            name="group_id"
                            value="<?php
                            echo esc_attr(
                                $group_id
                            );
                            ?>"
                        />

                        <?php
                        wp_nonce_field(
                            self::
                                MEMBERSHIP_ACTION
                                . '_'
                                . $group_id
                        );
                        ?>

                        <label
                            for="tutorhelper-pro-group-student-<?php
                            echo esc_attr(
                                $group_id
                            );
                            ?>"
                        >
                            <strong>
                                <?php
                                echo esc_html__(
                                    'Add students',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </strong>
                        </label>

                        <select
                            id="tutorhelper-pro-group-student-<?php
                            echo esc_attr(
                                $group_id
                            );
                            ?>"
                            name="student_user_ids[]"
                            multiple
                            size="<?php
                            echo esc_attr(
                                min(
                                    8,
                                    max(
                                        3,
                                        count(
                                            $available_students
                                        )
                                    )
                                )
                            );
                            ?>"
                            required
                            aria-describedby="tutorhelper-pro-group-student-help-<?php
                            echo esc_attr(
                                $group_id
                            );
                            ?>"
                        >

                            <?php foreach (
                                $available_students
                                    as $student
                            ) : ?>

                                <option
                                    value="<?php
                                    echo esc_attr(
                                        $student->ID
                                    );
                                    ?>"
                                >
                                    <?php
                                    echo esc_html(
                                        $student
                                            ->display_name
                                    );
                                    ?>
                                </option>

                            <?php endforeach; ?>
                        </select>

                        <button
                            type="submit"
                            class="button button-primary tutorhelper-action-button"
                        >
                            <?php
                            echo esc_html__(
                                'Add selected students',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>

                    </form>

                <?php elseif (
                    ! empty(
                        $members
                    )
                ) : ?>

                    <p
                        class="tutorhelper-student-muted"
                    >
                        <?php
                        echo esc_html__(
                            'All available students are already assigned to this group.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                <?php endif; ?>

            </div>

        </section>
        <?php
    }



	/**
	 * Render the groups list.
	 *
	 * @param array $groups        Group records.
	 * @param bool  $show_archived Whether archived groups are included.
	 *
	 * @return void
	 */
	private static function render_groups_list(
		$groups,
		$show_archived
	) {
		?>
		<section class="tutorhelper-main-section">

			<header class="tutorhelper-main-section__header">

				<div class="tutorhelper-main-section__header-content">
					<h2>
						<?php
						echo esc_html__(
							'Student Groups',
							'tutorhelper-pro'
						);
						?>
					</h2>

					<p>
						<?php
						printf(
							esc_html(
								_n(
									'%d group',
									'%d groups',
									count( $groups ),
									'tutorhelper-pro'
								)
							),
							absint(
								count( $groups )
							)
						);
						?>
					</p>
				</div>

				<a
					class="button tutorhelper-hub-pill-button"
					href="<?php
					echo esc_url(
						self::get_groups_url(
							array(
								'show_archived' =>
									$show_archived
										? 0
										: 1,
							)
						)
					);
					?>"
				>
					<?php
					echo esc_html(
						$show_archived
							? __(
								'Hide archived',
								'tutorhelper-pro'
							)
							: __(
								'Show archived',
								'tutorhelper-pro'
							)
					);
					?>
				</a>

			</header>

			<div class="tutorhelper-main-section__body">

				<?php if ( empty( $groups ) ) : ?>

					<div class="tutorhelper-students-empty">

						<span
							class="dashicons dashicons-networking"
							aria-hidden="true"
						></span>

						<h3>
							<?php
							echo esc_html__(
								'No groups yet',
								'tutorhelper-pro'
							);
							?>
						</h3>

						<p>
							<?php
							echo esc_html__(
								'Create a group to organise your students.',
								'tutorhelper-pro'
							);
							?>
						</p>

					</div>

				<?php else : ?>

					<div class="tutorhelper-student-table-wrap">

						<table class="widefat striped tutorhelper-student-table">

							<thead>
								<tr>
									<th scope="col">
										<?php
										echo esc_html__(
											'Group',
											'tutorhelper-pro'
										);
										?>
									</th>

									<th scope="col">
										<?php
										echo esc_html__(
											'Students',
											'tutorhelper-pro'
										);
										?>
									</th>

									<th scope="col">
										<?php
										echo esc_html__(
											'Status',
											'tutorhelper-pro'
										);
										?>
									</th>

									<th scope="col">
										<span class="screen-reader-text">
											<?php
											echo esc_html__(
												'Actions',
												'tutorhelper-pro'
											);
											?>
										</span>
									</th>
								</tr>
							</thead>

							<tbody>

								<?php foreach (
									$groups as $group
								) : ?>

									<?php
									self::render_group_row(
										$group
									);
									?>

								<?php endforeach; ?>

							</tbody>

						</table>

					</div>

				<?php endif; ?>

			</div>

		</section>
		<?php
	}

	/**
	 * Render one group list row.
	 *
	 * @param object $group Group record.
	 *
	 * @return void
	 */
	private static function render_group_row(
		$group
	) {
		$group_id =
			absint(
				$group->id
			);

		$student_count =
			TutorHelper_Pro_Groups::
				get_group_student_count(
					$group_id
				);

		$is_active =
			1 === absint(
				$group->is_active
			);

		$edit_url =
			self::get_groups_url(
				array(
					'group_id' =>
						$group_id,
				)
			);

		$status_url =
			wp_nonce_url(
				add_query_arg(
					array(
						'action' =>
							self::STATUS_ACTION,

						'group_id' =>
							$group_id,

						'group_status' =>
							$is_active
								? 'archive'
								: 'restore',
					),
					admin_url(
						'admin-post.php'
					)
				),
				self::STATUS_ACTION
					. '_'
					. $group_id
			);

		?>
		<tr>

			<td data-label="<?php
			echo esc_attr__(
				'Group',
				'tutorhelper-pro'
			);
			?>">

				<strong>
					<?php
					echo esc_html(
						$group->name
					);
					?>
				</strong>

				<?php if (
					! empty(
						$group->description
					)
				) : ?>

					<small
						class="tutorhelper-student-muted"
					>
						<?php
						echo esc_html(
							$group->description
						);
						?>
					</small>

				<?php endif; ?>

			</td>

			<td data-label="<?php
			echo esc_attr__(
				'Students',
				'tutorhelper-pro'
			);
			?>">

				<?php
				printf(
					esc_html(
						_n(
							'%d student',
							'%d students',
							$student_count,
							'tutorhelper-pro'
						)
					),
					absint(
						$student_count
					)
				);
				?>

			</td>

			<td data-label="<?php
			echo esc_attr__(
				'Status',
				'tutorhelper-pro'
			);
			?>">

				<span class="tutorhelper-student-status <?php
				echo $is_active
					? 'is-allowed'
					: 'is-blocked';
				?>">

					<?php
					echo esc_html(
						$is_active
							? __(
								'Active',
								'tutorhelper-pro'
							)
							: __(
								'Archived',
								'tutorhelper-pro'
							)
					);
					?>

				</span>

			</td>

			<td class="tutorhelper-student-table__actions">

				<a
					class="tutorhelper-hub-pill-button-small"
					href="<?php
					echo esc_url(
						$edit_url
					);
					?>"
				>
					<?php
					echo esc_html__(
						'Edit',
						'tutorhelper-pro'
					);
					?>
				</a>

				<a
					class="tutorhelper-hub-pill-button-small"
					href="<?php
					echo esc_url(
						$status_url
					);
					?>"
				>
					<?php
					echo esc_html(
						$is_active
							? __(
								'Archive',
								'tutorhelper-pro'
							)
							: __(
								'Restore',
								'tutorhelper-pro'
							)
					);
					?>
				</a>

			</td>

		</tr>
		<?php
	}

	/**
	 * Render add/edit form.
	 *
	 * @param object|null $group Existing group or null.
	 *
	 * @return void
	 */
	private static function render_group_form(
		$group
	) {
		$is_editing =
			is_object( $group );

		$group_id = $is_editing
			? absint(
				$group->id
			)
			: 0;

		?>
		<section class="tutorhelper-main-section">

			<header class="tutorhelper-main-section__header">

				<div class="tutorhelper-main-section__header-content">

					<h2>
						<?php
						echo esc_html(
							$is_editing
								? __(
									'Edit Group',
									'tutorhelper-pro'
								)
								: __(
									'Add Group',
									'tutorhelper-pro'
								)
						);
						?>
					</h2>

				</div>

			</header>

			<div class="tutorhelper-main-section__body">

				<form
					method="post"
					action="<?php
					echo esc_url(
						admin_url(
							'admin-post.php'
						)
					);
					?>"
				>

					<input
						type="hidden"
						name="action"
						value="<?php
						echo esc_attr(
							self::SAVE_ACTION
						);
						?>"
					/>

					<input
						type="hidden"
						name="group_id"
						value="<?php
						echo esc_attr(
							$group_id
						);
						?>"
					/>

					<?php
					wp_nonce_field(
						self::SAVE_ACTION
					);
					?>

					<p>
						<label
							for="tutorhelper-pro-group-name"
						>
							<strong>
								<?php
								echo esc_html__(
									'Group name',
									'tutorhelper-pro'
								);
								?>
							</strong>
						</label>
					</p>

					<p>
						<input
							type="text"
							id="tutorhelper-pro-group-name"
							name="group_name"
							class="regular-text"
							required
							value="<?php
							echo esc_attr(
								$is_editing
									? $group->name
									: ''
							);
							?>"
						/>
					</p>

					<p>
						<label
							for="tutorhelper-pro-group-description"
						>
							<strong>
								<?php
								echo esc_html__(
									'Description',
									'tutorhelper-pro'
								);
								?>
							</strong>
						</label>
					</p>

					<p>
						<textarea
							id="tutorhelper-pro-group-description"
							name="group_description"
							rows="4"
							class="large-text"
						><?php
						echo esc_textarea(
							$is_editing
								? $group->description
								: ''
						);
						?></textarea>
					</p>

					<?php if ( post_type_exists( 'tutorhelper_course' ) ) : ?>
						<?php
						$linked_courses = $group_id ? TutorHelper_Pro_Groups::get_group_courses( $group_id ) : array();
						$courses = get_posts( array( 'post_type' => 'tutorhelper_course', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
						?>
						<p>
							<label for="tutorhelper-pro-group-courses"><strong><?php esc_html_e( 'LMS courses', 'tutorhelper-pro' ); ?></strong></label><br />
							<select id="tutorhelper-pro-group-courses" name="lms_course_ids[]" class="regular-text" multiple size="6">
								<?php foreach ( $courses as $course ) : ?><option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( in_array( absint( $course->ID ), $linked_courses, true ) ); ?>><?php echo esc_html( $course->post_title ); ?></option><?php endforeach; ?>
							</select>
							<span class="description"><?php esc_html_e( 'Optional. Students in this Group can be given homework linked to these courses. This does not enrol them in course delivery.', 'tutorhelper-pro' ); ?></span>
						</p>
					<?php endif; ?>

					<p>
						<button
							type="submit"
							class="button button-primary tutorhelper-action-button"
						>
							<?php
							echo esc_html(
								$is_editing
									? __(
										'Save group',
										'tutorhelper-pro'
									)
									: __(
										'Create group',
										'tutorhelper-pro'
									)
							);
							?>
						</button>

						<?php if (
							$is_editing
						) : ?>

							<a
								class="button"
								href="<?php
								echo esc_url(
									self::get_groups_url()
								);
								?>"
							>
								<?php
								echo esc_html__(
									'Cancel',
									'tutorhelper-pro'
								);
								?>
							</a>

						<?php endif; ?>

					</p>

				</form>

			</div>

		</section>
		<?php
	}

	/**
	 * Handle create/update.
	 *
	 * @return void
	 */
	public static function handle_save_group() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_die(
				esc_html__(
					'You are not allowed to manage groups.',
					'tutorhelper-pro'
				)
			);
		}

		check_admin_referer(
			self::SAVE_ACTION
		);

		$group_id = isset(
			$_POST['group_id']
		)
			? absint(
				wp_unslash(
					$_POST['group_id']
				)
			)
			: 0;

		$name = isset(
			$_POST['group_name']
		)
			? sanitize_text_field(
				wp_unslash(
					$_POST['group_name']
				)
			)
			: '';

		$description = isset(
			$_POST[
				'group_description'
			]
		)
			? sanitize_textarea_field(
				wp_unslash(
					$_POST[
						'group_description'
					]
				)
			)
			: '';

		$course_ids = isset( $_POST['lms_course_ids'] ) && is_array( $_POST['lms_course_ids'] ) ? array_map( 'absint', wp_unslash( $_POST['lms_course_ids'] ) ) : array();

		if ( $group_id ) {

			$result =
				TutorHelper_Pro_Groups::
					update(
						$group_id,
						array(
							'name' =>
								$name,

							'description' =>
								$description,
						)
					);

			$success_notice =
				'group_updated';

		} else {

			$result =
				TutorHelper_Pro_Groups::
					create(
						array(
							'name' =>
								$name,

							'description' =>
								$description,
						)
					);

			$success_notice =
				'group_created';
		}

		if ( is_wp_error( $result ) ) {

			self::redirect_with_notice(
				$result->get_error_code(),
				'error',
				$group_id
			);
		}

		$saved_group_id = $group_id ? $group_id : absint( $result );
		if ( post_type_exists( 'tutorhelper_course' ) ) {
			$course_result = TutorHelper_Pro_Groups::replace_group_courses( $saved_group_id, $course_ids );
			if ( is_wp_error( $course_result ) ) {
				self::redirect_with_notice( $course_result->get_error_code(), 'error', $saved_group_id );
			}
		}

		self::redirect_with_notice(
			$success_notice,
			'success'
		);
	}

	/**
	 * Handle archive/restore.
	 *
	 * @return void
	 */
	public static function handle_group_status() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_die(
				esc_html__(
					'You are not allowed to manage groups.',
					'tutorhelper-pro'
				)
			);
		}

		$group_id = isset(
			$_GET['group_id']
		)
			? absint(
				wp_unslash(
					$_GET['group_id']
				)
			)
			: 0;

		check_admin_referer(
			self::STATUS_ACTION
				. '_'
				. $group_id
		);

		$status = isset(
			$_GET['group_status']
		)
			? sanitize_key(
				wp_unslash(
					$_GET['group_status']
				)
			)
			: '';

		if (
			! $group_id
			|| ! in_array(
				$status,
				array(
					'archive',
					'restore',
				),
				true
			)
		) {
			self::redirect_with_notice(
				'group_invalid',
				'error'
			);
		}

		$result =
			'archive' === $status
				? TutorHelper_Pro_Groups::
					archive(
						$group_id
					)
				: TutorHelper_Pro_Groups::
					restore(
						$group_id
					);

		if ( is_wp_error( $result ) ) {
			self::redirect_with_notice(
				$result->get_error_code(),
				'error'
			);
		}

		self::redirect_with_notice(
			'archive' === $status
				? 'group_archived'
				: 'group_restored',
			'success',
			0,
			'restore' === $status
		);
	}



    /**
     * List the student-group data supplied by this add-on.
     *
     * @param array $items Existing add-on data labels.
     *
     * @return array
     */
    public static function register_student_groups_information(
        $items
    ) {
        if ( ! is_array( $items ) ) {
            $items = array();
        }

        $items[] = __(
            'Student groups',
            'tutorhelper-pro'
        );

        return $items;
    }



    /**
     * Render a student's group memberships.
     *
     * @param WP_User $student Student user.
     *
     * @return void
     */
    public static function render_student_groups(
        $student
    ) {
        if (
            ! $student instanceof WP_User
        ) {
            return;
        }

        $groups =
            TutorHelper_Pro_Groups::
                get_student_groups(
                    $student->ID,
                    true
                );

        $groups_url =
                add_query_arg(
                    array(
                        'page' =>
                            TutorHelper_Booking_Hub::
                                PAGE_SLUG,

                        'tab' =>
                            self::TAB_KEY,
                    ),
                    admin_url(
                        'admin.php'
                    )
                );

        ?>
        <section
            class="tutorhelper-main-section tutorhelper-pro-student-groups"
        >

            <header
                class="tutorhelper-main-section__header"
            >
                <div
                    class="tutorhelper-main-section__header-content"
                >
                    <h2>
                        <span
                            class="dashicons dashicons-networking"
                            aria-hidden="true"
                        ></span>

                        <?php
                        echo esc_html__(
                            'Groups',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h2>
                </div>
            </header>

            <div
                class="tutorhelper-main-section__body"
            >

                <?php if (
                    empty(
                        $groups
                    )
                ) : ?>

                    <p
                        class="tutorhelper-student-muted"
                    >
                        <?php
                        echo esc_html__(
                            'This student is not currently assigned to any groups.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>

                <?php else : ?>

                    <div class="tutorhelper-student-table-wrap">

                        <table class="widefat striped tutorhelper-student-table">

                            <thead>
                                <tr>
                                    <th scope="col">
                                        <?php
                                        echo esc_html__(
                                            'Group',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </th>

                                    <th scope="col">
                                        <?php
                                        echo esc_html__(
                                            'Status',
                                            'tutorhelper-pro'
                                        );
                                        ?>
                                    </th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php foreach (
                                    $groups as $group
                                ) : ?>

                                    <tr>

                                        <td
                                            data-label="<?php
                                            echo esc_attr__(
                                                'Group',
                                                'tutorhelper-pro'
                                            );
                                            ?>"
                                        >
                                            <strong>
                                                <?php
                                                echo esc_html(
                                                    $group->name
                                                );
                                                ?>
                                            </strong>

                                            <?php if (
                                                ! empty(
                                                    $group->description
                                                )
                                            ) : ?>

                                                <small
                                                    class="tutorhelper-student-muted"
                                                >
                                                    <?php
                                                    echo esc_html(
                                                        $group->description
                                                    );
                                                    ?>
                                                </small>

                                            <?php endif; ?>

                                        </td>

                                        <td
                                            data-label="<?php
                                            echo esc_attr__(
                                                'Status',
                                                'tutorhelper-pro'
                                            );
                                            ?>"
                                        >
                                            <span
                                                class="tutorhelper-student-status is-allowed"
                                            >
                                                <?php
                                                echo esc_html__(
                                                    'Active',
                                                    'tutorhelper-pro'
                                                );
                                                ?>
                                            </span>
                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            </tbody>

                        </table>

                    </div>

                <?php endif; ?>

                <p>
                    <a
                        class="button tutorhelper-hub-pill-button"
                        href="<?php
                        echo esc_url(
                            $groups_url
                        );
                        ?>"
                    >
                        <?php
                        echo esc_html__(
                            'Manage groups',
                            'tutorhelper-pro'
                        );
                        ?>
                    </a>
                </p>

            </div>

        </section>
        <?php
    }



	/**
	 * Render Groups notices.
	 *
	 * @return void
	 */
	private static function render_notice() {

		$notice = isset(
			$_GET['groups_notice']
		)
			? sanitize_key(
				wp_unslash(
					$_GET[
						'groups_notice'
					]
				)
			)
			: '';

		if ( '' === $notice ) {
			return;
		}

		$type = isset(
			$_GET['groups_notice_type']
		)
			? sanitize_key(
				wp_unslash(
					$_GET[
						'groups_notice_type'
					]
				)
			)
			: 'success';

		$messages = array(
			'group_created' =>
				__(
					'Group created.',
					'tutorhelper-pro'
				),

			'group_updated' =>
				__(
					'Group updated.',
					'tutorhelper-pro'
				),

			'group_archived' =>
				__(
					'Group archived.',
					'tutorhelper-pro'
				),

			'group_restored' =>
				__(
					'Group restored.',
					'tutorhelper-pro'
				),

			'group_invalid' =>
				__(
					'The selected group action was invalid.',
					'tutorhelper-pro'
				),

			'tutorhelper_pro_group_name_required' =>
				__(
					'Enter a group name.',
					'tutorhelper-pro'
				),

			'tutorhelper_pro_group_not_found' =>
				__(
					'The group could not be found.',
					'tutorhelper-pro'
				),

			'tutorhelper_pro_group_create_failed' =>
				__(
					'The group could not be created.',
					'tutorhelper-pro'
				),

			'tutorhelper_pro_group_update_failed' =>
				__(
					'The group could not be updated.',
					'tutorhelper-pro'
				),
            'student_added' =>
                __(
                    'Student added to the group.',
                    'tutorhelper-pro'
                ),

            'student_removed' =>
                __(
                    'Student removed from the group.',
                    'tutorhelper-pro'
                ),

            'students_added' =>
                __(
                    'Selected students added to the group.',
                    'tutorhelper-pro'
                ),

            'membership_invalid' =>
                __(
                    'The selected group membership action was invalid.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_pro_group_student_not_found' =>
                __(
                    'The selected student could not be found.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_pro_group_assignment_failed' =>
                __(
                    'The student could not be added to the group.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_pro_group_removal_failed' =>
                __(
                    'The student could not be removed from the group.',
                    'tutorhelper-pro'
                ),
            
            'booking_type_added' =>
                __(
                    'Booking Type added to the group.',
                    'tutorhelper-pro'
                ),

            'booking_type_removed' =>
                __(
                    'Booking Type removed from the group.',
                    'tutorhelper-pro'
                ),

            'booking_type_relationship_invalid' =>
                __(
                    'The selected Booking Type relationship action was invalid.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_pro_group_booking_type_not_found' =>
                __(
                    'The selected Booking Type could not be found.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_pro_group_booking_type_assignment_failed' =>
                __(
                    'The Booking Type could not be added to the group.',
                    'tutorhelper-pro'
                ),

            'tutorhelper_pro_group_booking_type_removal_failed' =>
                __(
                    'The Booking Type could not be removed from the group.',
                    'tutorhelper-pro'
                ),
		);

		if (
			! isset(
				$messages[
					$notice
				]
			)
		) {
			return;
		}

		$classes = array(
			'notice',
			'error' === $type
				? 'notice-error'
				: 'notice-success',
			'is-dismissible',
		);

		?>
		<div class="<?php
		echo esc_attr(
			implode(
				' ',
				$classes
			)
		);
		?>">
			<p>
				<?php
				echo esc_html(
					$messages[
						$notice
					]
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Redirect back to Groups.
	 *
	 * @param string $notice        Notice code.
	 * @param string $type          Notice type.
	 * @param int    $group_id      Optional group ID.
	 * @param bool   $show_archived Whether archived groups should display.
	 *
	 * @return void
	 */
	private static function redirect_with_notice(
		$notice,
		$type = 'success',
		$group_id = 0,
		$show_archived = false
	) {
		$args = array(
			'groups_notice' =>
				sanitize_key(
					$notice
				),

			'groups_notice_type' =>
				'error' === $type
					? 'error'
					: 'success',
		);

		if ( $group_id ) {
			$args['group_id'] =
				absint(
					$group_id
				);
		}

		if ( $show_archived ) {
			$args['show_archived'] =
				1;
		}

		wp_safe_redirect(
			self::get_groups_url(
				$args
			)
		);

		exit;
	}

	/**
	 * Build Groups Hub URL.
	 *
	 * @param array $args Additional query arguments.
	 *
	 * @return string
	 */
	private static function get_groups_url(
		$args = array()
	) {
		return add_query_arg(
			array_merge(
				array(
					'page' =>
						TutorHelper_Booking_Hub::
							PAGE_SLUG,

					'tab' =>
						self::TAB_KEY,
				),
				is_array( $args )
					? $args
					: array()
			),
			admin_url(
				'admin.php'
			)
		);
	}
}
