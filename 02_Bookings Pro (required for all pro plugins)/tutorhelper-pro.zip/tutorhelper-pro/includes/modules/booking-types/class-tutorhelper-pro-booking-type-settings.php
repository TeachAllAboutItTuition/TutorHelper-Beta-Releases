<?php
/**
 * TutorHelper Pro Booking Type settings service.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and retrieves Pro-only Booking Type settings.
 */
final class TutorHelper_Pro_Booking_Type_Settings {

	/**
	 * No group restriction.
	 *
	 * @var string
	 */
	const GROUP_ACCESS_NONE = 'none';

	/**
	 * Only assigned groups can see and book.
	 *
	 * @var string
	 */
	const GROUP_ACCESS_VISIBLE_AND_BOOKABLE =
		'visible_and_bookable_by_groups';

	/**
	 * Everyone can see, but only assigned groups can book.
	 *
	 * @var string
	 */
	const GROUP_ACCESS_BOOKABLE_ONLY =
		'bookable_by_groups_only';

	/**
	 * Get all Pro settings for one Booking Type.
	 *
	 * @param int $booking_type_id Booking Type ID.
	 *
	 * @return array
	 */
	public static function get_settings(
		$booking_type_id
	) {
		global $wpdb;

		$booking_type_id = absint(
			$booking_type_id
		);

		$defaults = self::get_defaults();

		if ( ! $booking_type_id ) {
			return $defaults;
		}

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'booking_type_settings'
				);

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT *
				FROM {$table}
				WHERE booking_type_id = %d
				LIMIT 1",
				$booking_type_id
			),
			ARRAY_A
		);

		if ( ! is_array( $row ) ) {
			return $defaults;
		}

		return array(
			'group_access_mode' =>
				self::sanitize_group_access_mode(
					$row[
						'group_access_mode'
					]
				),

			'can_reschedule' =>
				! empty(
					$row[
						'can_reschedule'
					]
				),

			'reschedule_notice_hours' =>
				absint(
					$row[
						'reschedule_notice_hours'
					]
				),
		);
	}

	/**
	 * Save Pro settings for one Booking Type.
	 *
	 * @param int   $booking_type_id Booking Type ID.
	 * @param array $settings        Settings to save.
	 *
	 * @return bool|WP_Error
	 */
	public static function save_settings(
		$booking_type_id,
		$settings
	) {
		global $wpdb;

		$booking_type_id = absint(
			$booking_type_id
		);

		if ( ! $booking_type_id ) {
			return new WP_Error(
				'tutorhelper_pro_booking_type_settings_invalid_id',
				__(
					'The Booking Type ID is invalid.',
					'tutorhelper-pro'
				)
			);
		}

		$booking_type =
			TutorHelper_Booking_Types::
				get_by_id(
					$booking_type_id
				);

		if ( ! $booking_type ) {
			return new WP_Error(
				'tutorhelper_pro_booking_type_settings_not_found',
				__(
					'The Booking Type could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$settings = is_array( $settings )
			? $settings
			: array();

		$clean = array(
			'group_access_mode' =>
				self::sanitize_group_access_mode(
					isset(
						$settings[
							'group_access_mode'
						]
					)
						? $settings[
							'group_access_mode'
						]
						: self::GROUP_ACCESS_NONE
				),

			'can_reschedule' =>
				! empty(
					$settings[
						'can_reschedule'
					]
				)
					? 1
					: 0,

			'reschedule_notice_hours' =>
				isset(
					$settings[
						'reschedule_notice_hours'
					]
				)
					? absint(
						$settings[
							'reschedule_notice_hours'
						]
					)
					: 24,
		);

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'booking_type_settings'
				);

		$existing =
			self::row_exists(
				$booking_type_id
			);

		$now = current_time(
			'mysql',
			true
		);

		if ( $existing ) {
			$result = $wpdb->update(
				$table,
				array(
					'group_access_mode' =>
						$clean[
							'group_access_mode'
						],

					'can_reschedule' =>
						$clean[
							'can_reschedule'
						],

					'reschedule_notice_hours' =>
						$clean[
							'reschedule_notice_hours'
						],

					'updated_at' =>
						$now,
				),
				array(
					'booking_type_id' =>
						$booking_type_id,
				),
				array(
					'%s',
					'%d',
					'%d',
					'%s',
				),
				array(
					'%d',
				)
			);
		} else {
			$result = $wpdb->insert(
				$table,
				array(
					'booking_type_id' =>
						$booking_type_id,

					'group_access_mode' =>
						$clean[
							'group_access_mode'
						],

					'can_reschedule' =>
						$clean[
							'can_reschedule'
						],

					'reschedule_notice_hours' =>
						$clean[
							'reschedule_notice_hours'
						],

					'created_at' =>
						$now,

					'updated_at' =>
						$now,
				),
				array(
					'%d',
					'%s',
					'%d',
					'%d',
					'%s',
					'%s',
				)
			);
		}

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_pro_booking_type_settings_save_failed',
				__(
					'The Pro Booking Type settings could not be saved.',
					'tutorhelper-pro'
				)
			);
		}

		return true;
	}

	/**
	 * Get group access mode.
	 *
	 * @param int $booking_type_id Booking Type ID.
	 *
	 * @return string
	 */
	public static function get_group_access_mode(
		$booking_type_id
	) {
		$settings =
			self::get_settings(
				$booking_type_id
			);

		return $settings[
			'group_access_mode'
		];
	}

	/**
	 * Check whether student rescheduling is enabled.
	 *
	 * @param int $booking_type_id Booking Type ID.
	 *
	 * @return bool
	 */
	public static function can_reschedule(
		$booking_type_id
	) {
		$settings =
			self::get_settings(
				$booking_type_id
			);

		return (bool) $settings[
			'can_reschedule'
		];
	}

	/**
	 * Get minimum reschedule notice.
	 *
	 * @param int $booking_type_id Booking Type ID.
	 *
	 * @return int
	 */
	public static function get_reschedule_notice_hours(
		$booking_type_id
	) {
		$settings =
			self::get_settings(
				$booking_type_id
			);

		return absint(
			$settings[
				'reschedule_notice_hours'
			]
		);
	}

	/**
	 * Default Pro Booking Type settings.
	 *
	 * @return array
	 */
	private static function get_defaults() {
		return array(
			'group_access_mode' =>
				self::GROUP_ACCESS_NONE,

			'can_reschedule' =>
				false,

			'reschedule_notice_hours' =>
				24,
		);
	}

	/**
	 * Sanitise group access mode.
	 *
	 * @param string $mode Raw mode.
	 *
	 * @return string
	 */
	private static function sanitize_group_access_mode(
		$mode
	) {
		$mode = sanitize_key(
			$mode
		);

		$allowed = array(
			self::GROUP_ACCESS_NONE,
			self::
				GROUP_ACCESS_VISIBLE_AND_BOOKABLE,
			self::
				GROUP_ACCESS_BOOKABLE_ONLY,
		);

		return in_array(
			$mode,
			$allowed,
			true
		)
			? $mode
			: self::GROUP_ACCESS_NONE;
	}

	/**
	 * Check whether a settings row exists.
	 *
	 * @param int $booking_type_id Booking Type ID.
	 *
	 * @return bool
	 */
	private static function row_exists(
		$booking_type_id
	) {
		global $wpdb;

		$table =
			TutorHelper_Pro_Database::
				get_table_name(
					'booking_type_settings'
				);

		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT booking_type_id
				FROM {$table}
				WHERE booking_type_id = %d
				LIMIT 1",
				absint(
					$booking_type_id
				)
			)
		);

		return null !== $existing;
	}
}
