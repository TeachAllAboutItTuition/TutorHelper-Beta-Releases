<?php
/**
 * TutorHelper Pro Booking Type admin extensions.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Extends the Core Booking Type admin form.
 */
final class TutorHelper_Pro_Booking_Type_Admin {

	/**
	 * Register Booking Type admin extensions.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_booking_type_visibility_options',
			array(
				__CLASS__,
				'add_visibility_options',
			)
		);

		add_filter(
			'tutorhelper_booking_type_admin_visibility',
			array(
				__CLASS__,
				'filter_admin_visibility',
			),
			10,
			2
		);

		add_action(
			'tutorhelper_booking_type_render_admin_fields',
			array(
				__CLASS__,
				'render_admin_fields',
			),
			10,
			2
		);

		add_action(
			'tutorhelper_booking_type_admin_saved',
			array(
				__CLASS__,
				'handle_admin_saved',
			),
			10,
			2
		);
	}

	/**
	 * Add Pro visibility choices.
	 *
	 * @param array $labels Visibility labels.
	 *
	 * @return array
	 */
	public static function add_visibility_options(
		$labels
	) {
		if ( ! is_array( $labels ) ) {
			$labels = array();
		}

		$labels[
			TutorHelper_Pro_Booking_Type_Settings::
				GROUP_ACCESS_VISIBLE_AND_BOOKABLE
		] = __(
			'Visible & bookable by groups',
			'tutorhelper-pro'
		);

		$labels[
			TutorHelper_Pro_Booking_Type_Settings::
				GROUP_ACCESS_BOOKABLE_ONLY
		] = __(
			'Bookable by groups only',
			'tutorhelper-pro'
		);

		return $labels;
	}

	/**
	 * Display the stored Pro group visibility mode when editing.
	 *
	 * @param string      $visibility   Core visibility.
	 * @param object|null $booking_type Booking Type.
	 *
	 * @return string
	 */
	public static function filter_admin_visibility(
		$visibility,
		$booking_type
	) {
		if (
			! is_object( $booking_type )
			|| empty( $booking_type->id )
		) {
			return $visibility;
		}

		$mode =
			TutorHelper_Pro_Booking_Type_Settings::
				get_group_access_mode(
					$booking_type->id
				);

		if (
			TutorHelper_Pro_Booking_Type_Settings::
				GROUP_ACCESS_NONE
			=== $mode
		) {
			return $visibility;
		}

		return $mode;
	}

	/**
	 * Render Pro Booking Type fields.
	 *
	 * @param object|null $booking_type Booking Type.
	 * @param array       $values       Core form values.
	 *
	 * @return void
	 */
	public static function render_admin_fields(
		$booking_type,
		$values
	) {
		$booking_type_id =
			is_object( $booking_type )
				&& ! empty( $booking_type->id )
				? absint( $booking_type->id )
				: 0;

		$settings =
			TutorHelper_Pro_Booking_Type_Settings::
				get_settings(
					$booking_type_id
				);

		$groups =
			TutorHelper_Pro_Groups::get_all(
				array(
					'active_only' => true,
					'order'       => 'ASC',
				)
			);

		$assigned_group_ids = array();

		if ( $booking_type_id ) {
			$assigned_groups =
				TutorHelper_Pro_Groups::
					get_booking_type_groups(
						$booking_type_id,
						false
					);

			$assigned_group_ids = array_map(
				'absint',
				wp_list_pluck(
					$assigned_groups,
					'id'
				)
			);
		}

		?>
		<tr>
			<th scope="row">
				<?php
				echo esc_html__(
					'Allowed groups',
					'tutorhelper-pro'
				);
				?>
			</th>

			<td>
				<?php if ( empty( $groups ) ) : ?>

					<p class="description">
						<?php
						echo esc_html__(
							'No active groups are available. Create groups from the Groups tab first.',
							'tutorhelper-pro'
						);
						?>
					</p>

				<?php else : ?>

					<fieldset>

						<?php foreach ( $groups as $group ) : ?>

							<label
								style="display:block;margin-bottom:5px;"
							>
								<input
									type="checkbox"
									name="tutorhelper_pro_group_ids[]"
									value="<?php
									echo esc_attr(
										$group->id
									);
									?>"
									<?php
									checked(
										in_array(
											absint(
												$group->id
											),
											$assigned_group_ids,
											true
										)
									);
									?>
								/>

								<?php
								echo esc_html(
									$group->name
								);
								?>
							</label>

						<?php endforeach; ?>

					</fieldset>

					<p class="description">
						<?php
						echo esc_html__(
							'Selected groups are used when a group-based visibility option is chosen.',
							'tutorhelper-pro'
						);
						?>
					</p>

				<?php endif; ?>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<?php
				echo esc_html__(
					'Rescheduling',
					'tutorhelper-pro'
				);
				?>
			</th>

			<td>
				<label>
					<input
						type="checkbox"
						name="tutorhelper_pro_can_reschedule"
						value="1"
						<?php
						checked(
							! empty(
								$settings[
									'can_reschedule'
								]
							)
						);
						?>
					/>

					<?php
					echo esc_html__(
						'Allow students to reschedule this Booking Type',
						'tutorhelper-pro'
					);
					?>
				</label>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label
					for="tutorhelper-pro-reschedule-notice"
				>
					<?php
					echo esc_html__(
						'Minimum reschedule notice',
						'tutorhelper-pro'
					);
					?>
				</label>
			</th>

			<td>
				<input
					type="number"
					id="tutorhelper-pro-reschedule-notice"
					name="tutorhelper_pro_reschedule_notice_hours"
					min="0"
					step="1"
					value="<?php
					echo esc_attr(
						$settings[
							'reschedule_notice_hours'
						]
					);
					?>"
				/>

				<span>
					<?php
					echo esc_html__(
						'hours',
						'tutorhelper-pro'
					);
					?>
				</span>
			</td>
		</tr>
		<?php
	}

	/**
	 * Save Pro Booking Type settings after Core saves.
	 *
	 * @param int  $booking_type_id Booking Type ID.
	 * @param bool $is_update       Whether this was an update.
	 *
	 * @return void
	 */
	public static function handle_admin_saved(
		$booking_type_id,
		$is_update
	) {
		unset( $is_update );

		$booking_type_id =
			absint(
				$booking_type_id
			);

		if ( ! $booking_type_id ) {
			return;
		}

		$submitted_visibility =
			isset(
				$_POST[
					'online_booking_visibility'
				]
			)
				? sanitize_key(
					wp_unslash(
						$_POST[
							'online_booking_visibility'
						]
					)
				)
				: '';

		$group_access_mode =
			TutorHelper_Pro_Booking_Type_Settings::
				GROUP_ACCESS_NONE;

		if (
			in_array(
				$submitted_visibility,
				array(
					TutorHelper_Pro_Booking_Type_Settings::
						GROUP_ACCESS_VISIBLE_AND_BOOKABLE,

					TutorHelper_Pro_Booking_Type_Settings::
						GROUP_ACCESS_BOOKABLE_ONLY,
				),
				true
			)
		) {
			$group_access_mode =
				$submitted_visibility;
		}

		$settings_result =
			TutorHelper_Pro_Booking_Type_Settings::
				save_settings(
					$booking_type_id,
					array(
						'group_access_mode' =>
							$group_access_mode,

						'can_reschedule' =>
							isset(
								$_POST[
									'tutorhelper_pro_can_reschedule'
								]
							)
								? 1
								: 0,

						'reschedule_notice_hours' =>
							isset(
								$_POST[
									'tutorhelper_pro_reschedule_notice_hours'
								]
							)
								? absint(
									wp_unslash(
										$_POST[
											'tutorhelper_pro_reschedule_notice_hours'
										]
									)
								)
								: 24,
					)
				);

		if (
			is_wp_error(
				$settings_result
			)
		) {
			if (
				class_exists(
					'TutorHelper_Logger'
				)
			) {
				TutorHelper_Logger::warning(
					'Pro Booking Type settings could not be saved.',
					array(
						'booking_type_id' =>
							$booking_type_id,

						'error_code' =>
							$settings_result
								->get_error_code(),
					)
				);
			}

			return;
		}

		$submitted_group_ids =
			isset(
				$_POST[
					'tutorhelper_pro_group_ids'
				]
			)
			&& is_array(
				$_POST[
					'tutorhelper_pro_group_ids'
				]
			)
				? array_values(
					array_unique(
						array_filter(
							array_map(
								'absint',
								wp_unslash(
									$_POST[
										'tutorhelper_pro_group_ids'
									]
								)
							)
						)
					)
				)
				: array();

		self::sync_group_relationships(
			$booking_type_id,
			$submitted_group_ids
		);
	}

	/**
	 * Synchronise Booking Type group relationships.
	 *
	 * @param int   $booking_type_id Booking Type ID.
	 * @param array $submitted_ids   Submitted group IDs.
	 *
	 * @return void
	 */
	private static function sync_group_relationships(
		$booking_type_id,
		$submitted_ids
	) {
		$current_groups =
			TutorHelper_Pro_Groups::
				get_booking_type_groups(
					$booking_type_id,
					false
				);

		$current_ids = array_map(
			'absint',
			wp_list_pluck(
				$current_groups,
				'id'
			)
		);

		$to_add = array_diff(
			$submitted_ids,
			$current_ids
		);

		$to_remove = array_diff(
			$current_ids,
			$submitted_ids
		);

		foreach ( $to_add as $group_id ) {
			TutorHelper_Pro_Groups::
				assign_booking_type(
					$group_id,
					$booking_type_id
				);
		}

		foreach ( $to_remove as $group_id ) {
			TutorHelper_Pro_Groups::
				remove_booking_type(
					$group_id,
					$booking_type_id
				);
		}
	}
}
