<?php
/**
 * TutorHelper Pro Booking Type access rules.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies Pro group-based visibility and bookability rules.
 */
final class TutorHelper_Pro_Booking_Type_Access {

	/**
	 * Register Pro access filters.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_student_booking_type_can_view',
			array(
				__CLASS__,
				'filter_can_view',
			),
			10,
			3
		);

		add_filter(
			'tutorhelper_student_booking_type_can_book',
			array(
				__CLASS__,
				'filter_can_book',
			),
			10,
			3
		);

		add_filter(
			'tutorhelper_student_booking_type_unavailable_message',
			array(
				__CLASS__,
				'filter_unavailable_message',
			),
			10,
			3
		);
	}

	/**
	 * Filter whether a student may see a Booking Type.
	 *
	 * @param bool   $can_view        Core visibility result.
	 * @param object $booking_type    Booking Type record.
	 * @param int    $student_user_id Student user ID.
	 *
	 * @return bool
	 */
	public static function filter_can_view(
		$can_view,
		$booking_type,
		$student_user_id
	) {
		if (
			! is_object( $booking_type )
			|| empty( $booking_type->id )
		) {
			return false;
		}

		$booking_type_id =
			absint( $booking_type->id );

		$mode =
			TutorHelper_Pro_Booking_Type_Settings::
				get_group_access_mode(
					$booking_type_id
				);

		if (
			TutorHelper_Pro_Booking_Type_Settings::
				GROUP_ACCESS_NONE
			=== $mode
		) {
			return $can_view;
		}

		/*
		 * Every group-restricted Booking Type is hidden from students
		 * outside its assigned groups. Bookability is checked again by
		 * filter_can_book() so direct requests cannot bypass this rule.
		 */
		if (
			in_array(
				$mode,
				array(
					TutorHelper_Pro_Booking_Type_Settings::
						GROUP_ACCESS_VISIBLE_AND_BOOKABLE,

					TutorHelper_Pro_Booking_Type_Settings::
						GROUP_ACCESS_BOOKABLE_ONLY,
				),
				true
			)
		) {
			return self::student_has_access(
				$booking_type_id,
				$student_user_id
			);
		}

		return $can_view;
	}

	/**
	 * Filter whether a student may book a Booking Type.
	 *
	 * @param bool   $can_book        Core bookability result.
	 * @param object $booking_type    Booking Type record.
	 * @param int    $student_user_id Student user ID.
	 *
	 * @return bool
	 */
	public static function filter_can_book(
		$can_book,
		$booking_type,
		$student_user_id
	) {
		if (
			! is_object( $booking_type )
			|| empty( $booking_type->id )
		) {
			return false;
		}

		$booking_type_id =
			absint( $booking_type->id );

		$mode =
			TutorHelper_Pro_Booking_Type_Settings::
				get_group_access_mode(
					$booking_type_id
				);

		if (
			TutorHelper_Pro_Booking_Type_Settings::
				GROUP_ACCESS_NONE
			=== $mode
		) {
			return $can_book;
		}

		if (
			in_array(
				$mode,
				array(
					TutorHelper_Pro_Booking_Type_Settings::
						GROUP_ACCESS_VISIBLE_AND_BOOKABLE,

					TutorHelper_Pro_Booking_Type_Settings::
						GROUP_ACCESS_BOOKABLE_ONLY,
				),
				true
			)
		) {
			return self::student_has_access(
				$booking_type_id,
				$student_user_id
			);
		}

		return $can_book;
	}

	/**
	 * Provide a clearer message for group-limited Booking Types.
	 *
	 * @param string $message         Core message.
	 * @param object $booking_type    Booking Type record.
	 * @param int    $student_user_id Student user ID.
	 *
	 * @return string
	 */
	public static function filter_unavailable_message(
		$message,
		$booking_type,
		$student_user_id
	) {
		unset( $student_user_id );

		if (
			! is_object( $booking_type )
			|| empty( $booking_type->id )
		) {
			return $message;
		}

		$mode =
			TutorHelper_Pro_Booking_Type_Settings::
				get_group_access_mode(
					absint(
						$booking_type->id
					)
				);

		if (
			TutorHelper_Pro_Booking_Type_Settings::
				GROUP_ACCESS_BOOKABLE_ONLY
			=== $mode
		) {
			return __(
				'This lesson type is available to selected student groups only.',
				'tutorhelper-pro'
			);
		}

		return $message;
	}

	/**
	 * Check whether a student belongs to any group
	 * assigned to a Booking Type.
	 *
	 * @param int $booking_type_id Booking Type ID.
	 * @param int $student_user_id Student user ID.
	 *
	 * @return bool
	 */
	private static function student_has_access(
		$booking_type_id,
		$student_user_id
	) {
		$booking_type_id =
			absint( $booking_type_id );

		$student_user_id =
			absint( $student_user_id );

		if (
			! $booking_type_id
			|| ! $student_user_id
		) {
			return false;
		}

		$booking_groups =
			TutorHelper_Pro_Groups::
				get_booking_type_groups(
					$booking_type_id,
					true
				);

		if ( empty( $booking_groups ) ) {
			return false;
		}

		foreach ( $booking_groups as $group ) {

			if (
				empty( $group->id )
			) {
				continue;
			}

			if (
				TutorHelper_Pro_Groups::
					student_is_in_group(
						absint( $group->id ),
						$student_user_id
					)
			) {
				return true;
			}
		}

		return false;
	}
}
