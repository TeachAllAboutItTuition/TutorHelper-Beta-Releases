<?php
/**
 * TutorHelper Pro student-specific pricing.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and retrieves student-specific booking type prices.
 */
class TutorHelper_Pro_Student_Pricing {

	/**
	 * User-meta key containing student price overrides.
	 *
	 * Stored as:
	 *
	 * array(
	 *     booking_type_id => price_minor_units,
	 * )
	 */
	const META_KEY =
		'tutorhelper_pro_student_prices';

    /**
     * Register student-pricing hooks.
     *
     * @return void
     */
    public static function init() {

        add_filter(
            'tutorhelper_booking_resolved_pricing',
            array(
                __CLASS__,
                'filter_booking_pricing',
            ),
            10,
            4
        );
    }

	/**
	 * Get all price overrides for a student.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @return array
	 */
	public static function get_prices(
		$student_user_id
	) {

		$student_user_id =
			absint( $student_user_id );

		if ( ! $student_user_id ) {
			return array();
		}

		$prices = get_user_meta(
			$student_user_id,
			self::META_KEY,
			true
		);

		if ( ! is_array( $prices ) ) {
			return array();
		}

		$clean_prices = array();

		foreach (
			$prices
			as $booking_type_id => $price_minor_units
		) {

			$booking_type_id =
				absint( $booking_type_id );

			if ( ! $booking_type_id ) {
				continue;
			}

			if (
				! is_int( $price_minor_units )
				&& ! ctype_digit(
					(string) $price_minor_units
				)
			) {
				continue;
			}

			$clean_prices[ $booking_type_id ] =
				absint( $price_minor_units );
		}

		return $clean_prices;
	}

	/**
	 * Get a student's override for one booking type.
	 *
	 * Null means that the booking type's normal price
	 * should be used.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @param int $booking_type_id Booking type ID.
	 * @return int|null
	 */
	public static function get_price(
		$student_user_id,
		$booking_type_id
	) {

		$student_user_id =
			absint( $student_user_id );

		$booking_type_id =
			absint( $booking_type_id );

		if (
			! $student_user_id
			|| ! $booking_type_id
		) {
			return null;
		}

		$prices =
			self::get_prices(
				$student_user_id
			);

		if (
			! array_key_exists(
				$booking_type_id,
				$prices
			)
		) {
			return null;
		}

		return absint(
			$prices[ $booking_type_id ]
		);
	}

	/**
	 * Determine whether a student has a custom price.
	 *
	 * A zero-value override is valid because an individual
	 * student's booking may intentionally be free.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @param int $booking_type_id Booking type ID.
	 * @return bool
	 */
	public static function has_price(
		$student_user_id,
		$booking_type_id
	) {

		return null !== self::get_price(
			$student_user_id,
			$booking_type_id
		);
	}


    /**
	 * Apply a student's agreed personal Booking Type price proportionally.
	 *
	 * A personal price replaces the Booking Type's standard price for its
	 * standard duration. Longer or shorter booked lessons use the same
	 * half-up proportional calculation as Core, so an agreed £75 price for
	 * 55 minutes becomes £150 for a 110-minute booking.
	 *
	 * @param array $pricing          Core resolved pricing data.
	 * @param int   $student_user_id  Student WordPress user ID.
	 * @param int   $booking_type_id  Booking Type ID.
	 * @param int   $duration_minutes Actual booking duration.
	 * @return array
	 */
	public static function filter_booking_pricing(
		$pricing,
		$student_user_id,
		$booking_type_id,
		$duration_minutes
	) {
		if ( ! is_array( $pricing ) ) {
			return $pricing;
		}

		$student_user_id = absint( $student_user_id );
		$booking_type_id = absint( $booking_type_id );
		$duration_minutes = absint( $duration_minutes );
		if ( ! $student_user_id || ! $booking_type_id || ! $duration_minutes ) {
			return $pricing;
		}

		$personal_price = self::get_price( $student_user_id, $booking_type_id );
		$booking_type = TutorHelper_Booking_Types::get_by_id( $booking_type_id );
		$standard_duration = $booking_type ? absint( $booking_type->duration_minutes ) : 0;
		if ( null === $personal_price || ! $standard_duration ) {
			return $pricing;
		}

		$resolved_price = intdiv(
			absint( $personal_price ) * $duration_minutes + intdiv( $standard_duration, 2 ),
			$standard_duration
		);

		return array(
			'price_minor_units' => $resolved_price,
			'pricing_basis' => 'student_override',
		);
	}

	/**
	 * Set a student-specific price.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @param int $booking_type_id Booking type ID.
	 * @param int $price_minor_units Price in currency minor units.
	 * @return bool|WP_Error
	 */
	public static function set_price(
		$student_user_id,
		$booking_type_id,
		$price_minor_units
	) {

		$student_user_id =
			absint( $student_user_id );

		$booking_type_id =
			absint( $booking_type_id );

		if ( ! $student_user_id ) {
			return new WP_Error(
				'tutorhelper_pro_missing_student',
				__(
					'A student is required.',
					'tutorhelper-pro'
				)
			);
		}

		if ( ! $booking_type_id ) {
			return new WP_Error(
				'tutorhelper_pro_missing_booking_type',
				__(
					'A booking type is required.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! is_numeric(
				$price_minor_units
			)
			|| (float) $price_minor_units < 0
		) {
			return new WP_Error(
				'tutorhelper_pro_invalid_student_price',
				__(
					'The student price is not valid.',
					'tutorhelper-pro'
				)
			);
		}

		$price_minor_units =
			absint( $price_minor_units );

		$prices =
			self::get_prices(
				$student_user_id
			);

		$prices[ $booking_type_id ] =
			$price_minor_units;

		$result = update_user_meta(
			$student_user_id,
			self::META_KEY,
			$prices
		);

		/*
		 * update_user_meta() may return false when the stored
		 * value is already identical. That is not a failure.
		 */
		if (
			false === $result
			&& $prices
			!== self::get_prices(
				$student_user_id
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_student_price_save_failed',
				__(
					'The student price could not be saved.',
					'tutorhelper-pro'
				)
			);
		}

		return true;
	}

	/**
	 * Remove a student-specific price.
	 *
	 * Removing an override causes the normal booking type
	 * price to be used again.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @param int $booking_type_id Booking type ID.
	 * @return bool
	 */
	public static function delete_price(
		$student_user_id,
		$booking_type_id
	) {

		$student_user_id =
			absint( $student_user_id );

		$booking_type_id =
			absint( $booking_type_id );

		if (
			! $student_user_id
			|| ! $booking_type_id
		) {
			return false;
		}

		$prices =
			self::get_prices(
				$student_user_id
			);

		if (
			! array_key_exists(
				$booking_type_id,
				$prices
			)
		) {
			return true;
		}

		unset(
			$prices[ $booking_type_id ]
		);

		if ( empty( $prices ) ) {
			delete_user_meta(
				$student_user_id,
				self::META_KEY
			);

			return true;
		}

		return false !== update_user_meta(
			$student_user_id,
			self::META_KEY,
			$prices
		);
	}


    /**
     * Replace all stored price overrides for a student.
     *
     * Prices must be supplied in integer currency minor units.
     *
     * @param int   $student_user_id Student WordPress user ID.
     * @param array $prices          Prices keyed by Booking Type ID.
     * @return bool|WP_Error
     */
    public static function replace_prices(
        $student_user_id,
        $prices
    ) {

        $student_user_id =
            absint( $student_user_id );

        if ( ! $student_user_id ) {
            return new WP_Error(
                'tutorhelper_pro_missing_student',
                __(
                    'A student is required.',
                    'tutorhelper-pro'
                )
            );
        }

        if ( ! is_array( $prices ) ) {
            return new WP_Error(
                'tutorhelper_pro_invalid_student_prices',
                __(
                    'The student prices are not valid.',
                    'tutorhelper-pro'
                )
            );
        }

        $clean_prices = array();

        foreach (
            $prices
            as $booking_type_id => $price_minor_units
        ) {

            $booking_type_id =
                absint( $booking_type_id );

            if ( ! $booking_type_id ) {
                continue;
            }

            if (
                ! is_int( $price_minor_units )
                && ! ctype_digit(
                    (string) $price_minor_units
                )
            ) {
                return new WP_Error(
                    'tutorhelper_pro_invalid_student_price',
                    __(
                        'One or more student prices are not valid.',
                        'tutorhelper-pro'
                    )
                );
            }

            $clean_prices[ $booking_type_id ] =
                absint( $price_minor_units );
        }

        if ( empty( $clean_prices ) ) {
            delete_user_meta(
                $student_user_id,
                self::META_KEY
            );

            return true;
        }

        $result = update_user_meta(
            $student_user_id,
            self::META_KEY,
            $clean_prices
        );

        if (
            false === $result
            && $clean_prices
            !== self::get_prices(
                $student_user_id
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_student_prices_save_failed',
                __(
                    'The student prices could not be saved.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }

}
