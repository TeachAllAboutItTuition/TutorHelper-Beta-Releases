<?php
/**
 * TutorHelper Pro student pricing admin interface.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Integrates personal student pricing with Core Student Management.
 */
class TutorHelper_Pro_Student_Pricing_Admin {

	/**
	 * Admin POST action used to save student prices.
	 */
	const SAVE_ACTION =
		'tutorhelper_pro_save_student_prices';

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_students_show_pricing_placeholder',
			array(
				__CLASS__,
				'hide_core_placeholder',
			),
			10,
			2
		);

		add_action(
			'tutorhelper_students_detail_lesson_options_pricing',
			array(
				__CLASS__,
				'render',
			)
		);

		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array(
				__CLASS__,
				'handle_save',
			)
		);
	}

    /**
     * Hide the Core pricing placeholder when Pro pricing is available.
     *
     * @param bool    $show    Whether Core should show its placeholder.
     * @param WP_User $student Current student.
     * @return bool
     */
    public static function hide_core_placeholder(
        $show,
        $student
    ) {

        unset( $show, $student );

        return false;
    }


    /**
     * Render personal pricing controls for a student.
     *
     * @param WP_User $student Student WordPress user.
     * @return void
     */
    public static function render(
        $student
    ) {

        if ( ! $student instanceof WP_User ) {
            return;
        }

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            return;
        }

        $booking_types =
            TutorHelper_Booking_Types::get_active();

        $prices =
            TutorHelper_Pro_Student_Pricing::get_prices(
                $student->ID
            );

        $currency =
            TutorHelper_Currency::get_currency();

        $decimals =
            TutorHelper_Currency::get_decimal_places(
                $currency
            );

        $step = 0 === $decimals
            ? '1'
            : '0.'
                . str_repeat(
                    '0',
                    $decimals - 1
                )
                . '1';

        self::render_notice();
        ?>
        <section
            class="
                tutorhelper-student-detail__section
                tutorhelper-pro-student-pricing
            "
        >

            <h3>
                <?php
                echo esc_html__(
                    'Lesson Pricing',
                    'tutorhelper-pro'
                );
                ?>
            </h3>

            <p>
                <?php
                echo esc_html__(
                    'Set an optional personal price for this student. Leave a price blank to use the standard Booking Type price.',
                    'tutorhelper-pro'
                );
                ?>
            </p>

            <?php if ( empty( $booking_types ) ) : ?>

                <p>
                    <?php
                    echo esc_html__(
                        'There are no active Booking Types available.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>

            <?php else : ?>

                <form
                    method="post"
                    action="<?php echo esc_url(
                        admin_url( 'admin-post.php' )
                    ); ?>"
                >

                    <input
                        type="hidden"
                        name="action"
                        value="<?php echo esc_attr(
                            self::SAVE_ACTION
                        ); ?>"
                    />

                    <input
                        type="hidden"
                        name="student_id"
                        value="<?php echo esc_attr(
                            $student->ID
                        ); ?>"
                    />

                    <?php
                    wp_nonce_field(
                        self::SAVE_ACTION,
                        'tutorhelper_pro_student_pricing_nonce'
                    );
                    ?>

                    <table
                        class="
                            widefat
                            striped
                            tutorhelper-pro-student-pricing__table
                        "
                    >
                        <thead>
                            <tr>
                                <th scope="col">
                                    <?php
                                    echo esc_html__(
                                        'Booking Type',
                                        'tutorhelper-pro'
                                    );
                                    ?>
                                </th>

                                <th scope="col">
                                    <?php
                                    echo esc_html__(
                                        'Standard price',
                                        'tutorhelper-pro'
                                    );
                                    ?>
                                </th>

                                <th scope="col">
                                    <?php
                                    echo esc_html__(
                                        'Personal price',
                                        'tutorhelper-pro'
                                    );
                                    ?>
                                </th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            foreach (
                                $booking_types
                                as $booking_type
                            ) :
                                $booking_type_id =
                                    absint(
                                        $booking_type->id
                                    );

                                $standard_price =
                                    absint(
                                        $booking_type
                                            ->price_minor_units
                                    );

                                $has_override =
                                    array_key_exists(
                                        $booking_type_id,
                                        $prices
                                    );

                                $personal_price =
                                    $has_override
                                        ? TutorHelper_Currency::
                                            minor_to_major_units(
                                                $prices[
                                                    $booking_type_id
                                                ],
                                                $currency
                                            )
                                        : '';

                                $field_id =
                                    'tutorhelper-pro-price-'
                                    . $booking_type_id;
                                ?>

                                <tr>
                                    <td>
                                        <strong>
                                            <?php
                                            echo esc_html(
                                                $booking_type->title
                                            );
                                            ?>
                                        </strong>

                                        <br />

                                        <small>
                                            <?php
                                            printf(
                                                /* translators: %d: Booking Type duration in minutes. */
                                                esc_html__(
                                                    '%d minutes',
                                                    'tutorhelper-pro'
                                                ),
                                                absint(
                                                    $booking_type
                                                        ->duration_minutes
                                                )
                                            );
                                            ?>
                                        </small>
                                    </td>

                                    <td>
                                        <?php
                                        echo esc_html(
                                            TutorHelper_Currency::
                                                format_minor_units(
                                                    $standard_price,
                                                    $currency
                                                )
                                        );
                                        ?>
                                    </td>

                                    <td>
                                        <label
                                            class="screen-reader-text"
                                            for="<?php echo esc_attr(
                                                $field_id
                                            ); ?>"
                                        >
                                            <?php
                                            printf(
                                                /* translators: %s: Booking Type title. */
                                                esc_html__(
                                                    'Personal price for %s',
                                                    'tutorhelper-pro'
                                                ),
                                                esc_html(
                                                    $booking_type->title
                                                )
                                            );
                                            ?>
                                        </label>

                                        <input
                                            type="number"
                                            id="<?php echo esc_attr(
                                                $field_id
                                            ); ?>"
                                            name="student_prices[<?php
                                                echo esc_attr(
                                                    $booking_type_id
                                                );
                                            ?>]"
                                            value="<?php echo esc_attr(
                                                $personal_price
                                            ); ?>"
                                            min="0"
                                            step="<?php echo esc_attr(
                                                $step
                                            ); ?>"
                                            placeholder="<?php
                                                echo esc_attr(
                                                    TutorHelper_Currency::
                                                        minor_to_major_units(
                                                            $standard_price,
                                                            $currency
                                                        )
                                                );
                                            ?>"
                                        />

                                        <?php if ( $has_override ) : ?>
                                            <p class="description">
                                                <?php
                                                echo esc_html__(
                                                    'Personal price applied',
                                                    'tutorhelper-pro'
                                                );
                                                ?>
                                            </p>
                                        <?php else : ?>
                                            <p class="description">
                                                <?php
                                                echo esc_html__(
                                                    'Uses standard price',
                                                    'tutorhelper-pro'
                                                );
                                                ?>
                                            </p>
                                        <?php endif; ?>
                                    </td>
                                </tr>

                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <p>
                        <button
                            type="submit"
                            class="button tutorhelper-action-button"
                        >
                            <span
                                class="dashicons dashicons-saved"
                                aria-hidden="true"
                            ></span>

                            <?php
                            echo esc_html__(
                                'Save personal prices',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>
                    </p>

                </form>

            <?php endif; ?>

        </section>
        <?php
    }


    /**
     * Save personal student prices.
     *
     * @return void
     */
    public static function handle_save() {

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to manage student pricing.',
                    'tutorhelper-pro'
                ),
                esc_html__(
                    'Permission denied',
                    'tutorhelper-pro'
                ),
                array(
                    'response' => 403,
                )
            );
        }

        check_admin_referer(
            self::SAVE_ACTION,
            'tutorhelper_pro_student_pricing_nonce'
        );

        $student_user_id = isset(
            $_POST['student_id']
        )
            ? absint(
                wp_unslash(
                    $_POST['student_id']
                )
            )
            : 0;

        $student =
            TutorHelper_Students::get_student(
                $student_user_id
            );

        if ( ! $student instanceof WP_User ) {
            self::redirect(
                $student_user_id,
                'invalid_student'
            );
        }

        $submitted_prices = array();

        if (
            isset( $_POST['student_prices'] )
            && is_array(
                $_POST['student_prices']
            )
        ) {
            $submitted_prices =
                wp_unslash(
                    $_POST['student_prices']
                );
        }

        $currency =
            TutorHelper_Currency::get_currency();

        $decimals =
            TutorHelper_Currency::get_decimal_places(
                $currency
            );

        $booking_types =
            TutorHelper_Booking_Types::get_active();

        /*
        * Begin with existing prices so overrides belonging
        * to temporarily archived Booking Types are preserved.
        */
        $prices =
            TutorHelper_Pro_Student_Pricing::get_prices(
                $student_user_id
            );

        foreach (
            $booking_types
            as $booking_type
        ) {

            $booking_type_id =
                absint(
                    $booking_type->id
                );

            $raw_price = '';

            if (
                array_key_exists(
                    $booking_type_id,
                    $submitted_prices
                )
            ) {
                $raw_price =
                    trim(
                        sanitize_text_field(
                            $submitted_prices[
                                $booking_type_id
                            ]
                        )
                    );
            }

            /*
            * Blank means remove the personal override and
            * return to the Booking Type's standard price.
            */
            if ( '' === $raw_price ) {
                unset(
                    $prices[ $booking_type_id ]
                );

                continue;
            }

            $pattern = 0 === $decimals
                ? '/^\d+$/'
                : '/^\d+(?:\.\d{1,'
                    . $decimals
                    . '})?$/';

            if (
                1 !== preg_match(
                    $pattern,
                    $raw_price
                )
            ) {
                self::redirect(
                    $student_user_id,
                    'invalid_price'
                );
            }

            $prices[ $booking_type_id ] =
                TutorHelper_Currency::
                    major_to_minor_units(
                        $raw_price,
                        $currency
                    );
        }

        $result =
            TutorHelper_Pro_Student_Pricing::
                replace_prices(
                    $student_user_id,
                    $prices
                );

        if ( is_wp_error( $result ) ) {

            if ( class_exists( 'TutorHelper_Logger' ) ) {
                TutorHelper_Logger::error(
                    'TutorHelper Pro student pricing save failed.',
                    array(
                        'student_id' =>
                            $student_user_id,

                        'error_code' =>
                            $result->get_error_code(),
                    )
                );
            }

            self::redirect(
                $student_user_id,
                'save_failed'
            );
        }

        self::redirect(
            $student_user_id,
            'saved'
        );
    }


    /**
     * Redirect back to the student's details screen.
     *
     * @param int    $student_user_id Student WordPress user ID.
     * @param string $notice          Notice identifier.
     * @return void
     */
    private static function redirect(
        $student_user_id,
        $notice
    ) {

        $url = add_query_arg(
            array(
                'page' =>
                    TutorHelper_Booking_Hub::PAGE_SLUG,

                'tab' =>
                    TutorHelper_Students_Admin::TAB_KEY,

                'student_id' =>
                    absint( $student_user_id ),

                'tutorhelper_pro_pricing_notice' =>
                    sanitize_key( $notice ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    /**
     * Render personal pricing feedback.
     *
     * @return void
     */
    private static function render_notice() {

        $notice = isset(
            $_GET['tutorhelper_pro_pricing_notice']
        )
            ? sanitize_key(
                wp_unslash(
                    $_GET[
                        'tutorhelper_pro_pricing_notice'
                    ]
                )
            )
            : '';

        if ( '' === $notice ) {
            return;
        }

        $messages = array(
            'saved' => array(
                'type' => 'success',
                'text' => __(
                    'Personal lesson prices saved.',
                    'tutorhelper-pro'
                ),
            ),

            'invalid_price' => array(
                'type' => 'error',
                'text' => __(
                    'One or more personal prices were not valid.',
                    'tutorhelper-pro'
                ),
            ),

            'invalid_student' => array(
                'type' => 'error',
                'text' => __(
                    'The selected student could not be found.',
                    'tutorhelper-pro'
                ),
            ),

            'save_failed' => array(
                'type' => 'error',
                'text' => __(
                    'The personal prices could not be saved.',
                    'tutorhelper-pro'
                ),
            ),
        );

        if ( ! isset( $messages[ $notice ] ) ) {
            return;
        }

        $message =
            $messages[ $notice ];

        $class = 'success' === $message['type']
            ? 'notice notice-success inline'
            : 'notice notice-error inline';

        ?>
        <div class="<?php echo esc_attr(
            $class
        ); ?>">
            <p>
                <?php
                echo esc_html(
                    $message['text']
                );
                ?>
            </p>
        </div>
        <?php
    }

}
