<?php
/**
 * TutorHelper Pro reporting dashboard widgets.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds Pro reporting data to the Core dashboard extension API.
 */
final class TutorHelper_Pro_Dashboard_Reports {

	/** AJAX action for an on-demand attendance breakdown. */
	const BREAKDOWN_ACTION = 'tutorhelper_pro_dashboard_breakdown';

	/** AJAX action for recording a homework item as no longer due. */
	const HOMEWORK_NOT_DUE_ACTION = 'tutorhelper_pro_mark_homework_not_due';

	/** Register dashboard integrations. */
	public static function init() {
		add_action(
			'wp_ajax_' . self::BREAKDOWN_ACTION,
			array( __CLASS__, 'handle_breakdown_request' )
		);
		add_action(
			'wp_ajax_' . self::HOMEWORK_NOT_DUE_ACTION,
			array( __CLASS__, 'handle_homework_not_due_request' )
		);
		add_filter(
			'tutorhelper_students_parent_filter_ids',
			array( __CLASS__, 'filter_students_without_parent_ids' ),
			10,
			2
		);
		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' )
		);
		add_filter(
			'tutorhelper_dashboard_context',
			array( __CLASS__, 'filter_context_by_group' ),
			20
		);
		add_filter(
			'tutorhelper_dashboard_student_ids',
			array( __CLASS__, 'filter_student_ids_by_group' ),
			20,
			2
		);
		add_filter(
			'tutorhelper_dashboard_new_student_count',
			array( __CLASS__, 'filter_new_student_count_by_group' ),
			20,
			2
		);
		add_action(
			'tutorhelper_dashboard_filter_fields',
			array( __CLASS__, 'render_group_filter' )
		);
		add_filter(
			'tutorhelper_dashboard_widgets',
			array( __CLASS__, 'add_widgets' ),
			20,
			2
		);
	}

	/**
	 * Load dashboard report presentation on TutorHelper administration screens.
	 *
	 * @param string $hook_suffix Current administration hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix ) {
			return;
		}
		$path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-dashboard-reports.css';
		wp_enqueue_style(
			'tutorhelper-pro-dashboard-reports',
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-dashboard-reports.css',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_PRO_VERSION
		);

		$script_path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-dashboard-reports.js';
		wp_enqueue_script(
			'tutorhelper-pro-dashboard-reports',
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-dashboard-reports.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_PRO_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-pro-dashboard-reports',
			'tutorhelperProDashboardReports',
			array(
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'action'        => self::BREAKDOWN_ACTION,
				'nonce'         => wp_create_nonce( self::BREAKDOWN_ACTION ),
				'loadingText'   => __( 'Loading breakdown…', 'tutorhelper-pro' ),
				'errorText'     => __( 'The breakdown could not be loaded. Please try again.', 'tutorhelper-pro' ),
				'refreshingText'=> __( 'Refreshing…', 'tutorhelper-pro' ),
				'retryText'      => __( 'Retry', 'tutorhelper-pro' ),
				'homeworkNotDueAction'  => self::HOMEWORK_NOT_DUE_ACTION,
				'homeworkNotDueNonce'   => wp_create_nonce( self::HOMEWORK_NOT_DUE_ACTION ),
				'homeworkNotDueConfirm' => __( 'Mark this homework as no longer due? It will be removed from outstanding homework without being marked complete.', 'tutorhelper-pro' ),
				'homeworkNotDueError'   => __( 'The homework could not be updated. Please try again.', 'tutorhelper-pro' ),
			)
		);
	}


	/** Record one overdue homework item as no longer due without marking it complete. */
	public static function handle_homework_not_due_request() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to update homework.', 'tutorhelper-pro' ) ), 403 );
		}

		check_ajax_referer( self::HOMEWORK_NOT_DUE_ACTION, 'nonce' );
		$booking_id = isset( $_POST['booking_id'] ) ? absint( $_POST['booking_id'] ) : 0;
		$booking    = $booking_id ? TutorHelper_Booking_Records::get_by_id( $booking_id ) : null;
		if ( ! $booking ) {
			wp_send_json_error( array( 'message' => __( 'The homework due lesson could not be found.', 'tutorhelper-pro' ) ), 404 );
		}

		if ( absint( $booking->tutor_user_id ) !== get_current_user_id() && ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot update homework for another tutor.', 'tutorhelper-pro' ) ), 403 );
		}

		$state = TutorHelper_Pro_Lesson_Follow_Up::get_homework_state_for_booking( $booking_id );
		if ( empty( $state['due'] ) || ! empty( $state['completed'] ) || ! empty( $state['not_due'] ) ) {
			wp_send_json_error( array( 'message' => __( 'This homework is no longer outstanding.', 'tutorhelper-pro' ) ), 400 );
		}

		if ( ! TutorHelper_Pro_Lesson_Follow_Up::mark_homework_no_longer_due( $booking_id, get_current_user_id() ) ) {
			wp_send_json_error( array( 'message' => __( 'The homework could not be updated. Please try again.', 'tutorhelper-pro' ) ), 500 );
		}

		wp_send_json_success( array( 'message' => __( 'Homework marked as no longer due.', 'tutorhelper-pro' ) ) );
	}

	/**
	 * Add attendance, finance, communication, registration and rating cards.
	 *
	 * @param array $widgets Existing widget definitions.
	 * @param array $context Shared dashboard context.
	 * @return array
	 */
	public static function add_widgets( $widgets, $context ) {
		if ( ! is_array( $context ) || empty( $context['filters'] ) ) {
			return $widgets;
		}

		$attendance = self::get_attendance_summary( $context );
		$finance    = self::get_finance_summary( $context );
		$emails     = self::get_email_summary( $context );
		$ratings    = self::get_rating_summary( $context );
		$registrations = self::get_registration_summary( $context );
		$availability = self::get_remaining_availability( $context );
		$overdue_homework = self::get_overdue_homework( $context );

		$widgets['attendance_todo'] = array(
			'label'       => __( 'Attendance to record', 'tutorhelper-pro' ),
			'value'       => number_format_i18n( $attendance['todo'] ),
			'description' => __( 'Completed lessons awaiting attendance', 'tutorhelper-pro' ),
			'icon'        => 'clipboard',
			'tone'        => $attendance['todo'] ? 'orange' : 'green',
			'section'     => 'attendance',
			'priority'    => 10,
			'url'         => self::get_attendance_url( $context ),
		);
		$widgets['attendance_attended'] = self::attendance_widget( __( 'Attended', 'tutorhelper-pro' ), $attendance['attended'], __( 'Lessons marked attended', 'tutorhelper-pro' ), 'yes-alt', 'green', 20, 'attended', $context );
		$widgets['attendance_late'] = self::attendance_widget( __( 'Late', 'tutorhelper-pro' ), $attendance['late'], __( 'Lessons marked late', 'tutorhelper-pro' ), 'clock', 'orange', 30, 'late', $context );
		$widgets['attendance_missed'] = self::attendance_widget( __( 'Missed', 'tutorhelper-pro' ), $attendance['missed'], __( 'Lessons marked missed', 'tutorhelper-pro' ), 'dismiss', 'red', 40, 'missed', $context );
		$widgets['attendance_cancelled'] = self::attendance_widget( __( 'Cancelled', 'tutorhelper-pro' ), $attendance['cancelled'], __( 'Cancelled bookings in this period', 'tutorhelper-pro' ), 'calendar', 'muted', 50, 'cancelled', $context );

		$widgets['payments_received'] = array(
			'label'       => __( 'Paid lesson value', 'tutorhelper-pro' ),
			'value'       => TutorHelper_Currency::format_minor_units( $finance['paid'], $finance['currency'] ),
			'description' => __( 'Lessons in this period currently marked paid', 'tutorhelper-pro' ),
			'icon'        => 'money-alt',
			'tone'        => 'green',
			'section'     => 'finance',
			'priority'    => 10,
			'url'         => self::get_finance_url( $context, 'paid' ),
			'link_label'  => __( 'Open paid lessons in All Finance', 'tutorhelper-pro' ),
		);
		$widgets['payments_due'] = array(
			'label'       => __( 'Amount due', 'tutorhelper-pro' ),
			'value'       => TutorHelper_Currency::format_minor_units( $finance['due'], $finance['currency'] ),
			'description' => __( 'Outstanding value of lessons in this period', 'tutorhelper-pro' ),
			'icon'        => 'chart-line',
			'tone'        => $finance['due'] ? 'orange' : 'green',
			'section'     => 'finance',
			'priority'    => 20,
			'url'         => self::get_finance_url( $context, array( 'unpaid', 'partially_paid' ) ),
			'link_label'  => __( 'Open outstanding lessons in All Finance', 'tutorhelper-pro' ),
		);

		$widgets['new_registrations'] = self::metric_widget( __( 'New registrations', 'tutorhelper-pro' ), $registrations['new'], __( 'Registration forms submitted in this period', 'tutorhelper-pro' ), 'id-alt', 'blue', 'students', 5 );
		$widgets['new_registrations']['url'] = self::get_registrations_url();
		$widgets['new_registrations']['link_label'] = __( 'Review new registrations', 'tutorhelper-pro' );

		$missing_parent_ids = self::get_students_without_parent_ids();
		$widgets['students_without_parent'] = array(
			'label'       => __( 'Students without a linked parent', 'tutorhelper-pro' ),
			'value'       => number_format_i18n( count( $missing_parent_ids ) ),
			'description' => __( 'Active students under 18 without an active parent or guardian link', 'tutorhelper-pro' ),
			'icon'        => 'groups',
			'tone'        => $missing_parent_ids ? 'orange' : 'green',
			'section'     => 'students',
			'priority'    => 7,
			'url'         => self::get_students_without_parent_url(),
			'link_label'  => __( 'View students without a linked parent', 'tutorhelper-pro' ),
		);
		$widgets['waiting_list'] = array(
			'label'       => __( 'Waiting list', 'tutorhelper-pro' ),
			'value'       => number_format_i18n( $registrations['waiting'] ),
			'description' => __( 'Registrations in this period placed on the waiting list', 'tutorhelper-pro' ),
			'icon'        => 'list-view',
			'tone'        => 'purple',
			'section'     => 'students',
			'priority'    => 6,
			'url'         => self::get_registrations_url(),
		);

		$widgets['emails_sent'] = self::metric_widget( __( 'Emails sent', 'tutorhelper-pro' ), $emails['sent'], __( 'Successful email deliveries', 'tutorhelper-pro' ), 'email-alt', 'green', 'communications', 10 );
		$widgets['emails_failed'] = self::metric_widget( __( 'Emails failed', 'tutorhelper-pro' ), $emails['failed'], __( 'Email deliveries requiring attention', 'tutorhelper-pro' ), 'warning', $emails['failed'] ? 'red' : 'green', 'communications', 20 );
		$widgets['emails_sent']['url']   = self::get_emails_url();
		$widgets['emails_failed']['url'] = self::get_emails_url();
		$widgets['emails_sent']['link_label']   = __( 'Open Email delivery history', 'tutorhelper-pro' );
		$widgets['emails_failed']['link_label'] = __( 'Open Email delivery history', 'tutorhelper-pro' );

		$rating_value = $ratings['count']
			? sprintf( __( '%1$s / 5', 'tutorhelper-pro' ), number_format_i18n( $ratings['average'], 1 ) )
			: '—';
		$widgets['lesson_rating'] = array(
			'label'       => __( 'Average lesson rating', 'tutorhelper-pro' ),
			'value'       => $rating_value,
			'description' => sprintf(
				/* translators: %s: number of lesson ratings. */
				_n( '%s student response', '%s student responses', $ratings['count'], 'tutorhelper-pro' ),
				number_format_i18n( $ratings['count'] )
			),
			'icon'        => 'star-filled',
			'tone'        => 'purple',
			'section'     => 'feedback',
			'priority'    => 10,
			'panel_callback' => array( __CLASS__, 'render_rating_report' ),
			'panel_args' => $context,
		);
		$widgets['remaining_bookable_hours'] = array(
			'label'       => __( 'Remaining bookable hours', 'tutorhelper-pro' ),
			'value'       => number_format_i18n( $availability['seconds'] / HOUR_IN_SECONDS, 1 ),
			'description' => __( 'Unbooked availability in the selected date range', 'tutorhelper-pro' ),
			'icon'        => 'schedule',
			'tone'        => $availability['seconds'] ? 'green' : 'muted',
			'section'     => 'bookings',
			'priority'    => 40,
			'panel_callback' => array( __CLASS__, 'render_availability_report' ),
			'panel_args' => $context,
		);

		$widgets['outstanding_homework'] = array(
			'label'       => __( 'Outstanding homework', 'tutorhelper-pro' ),
			'value'       => number_format_i18n( count( $overdue_homework ) ),
			'description' => __( 'Homework due before today and not marked complete', 'tutorhelper-pro' ),
			'icon'        => 'welcome-write-blog',
			'tone'        => $overdue_homework ? 'orange' : 'green',
			'section'     => 'students',
			'priority'    => 8,
			'panel_callback' => array( __CLASS__, 'render_outstanding_homework_panel' ),
			'panel_args' => $overdue_homework,
		);

		return $widgets;
	}


	/**
	 * Return incomplete homework that is overdue, respecting non-date dashboard filters.
	 *
	 * The dashboard date period is intentionally not applied: a task remains outstanding
	 * until it is completed, even when its due lesson predates the selected reporting period.
	 *
	 * @param array $context Shared dashboard context.
	 * @return array<int,array<string,mixed>>
	 */
	private static function get_overdue_homework( $context ) {
		$filters = isset( $context['filters'] ) && is_array( $context['filters'] )
			? $context['filters']
			: array();
		$bookings = TutorHelper_Booking_Records::get_all(
			array(
				'student_user_id' => isset( $filters['student_id'] ) ? absint( $filters['student_id'] ) : 0,
				'tutor_user_id'   => isset( $filters['tutor_id'] ) ? absint( $filters['tutor_id'] ) : 0,
				'booking_type_id' => isset( $filters['booking_type_id'] ) ? absint( $filters['booking_type_id'] ) : 0,
				'status'          => isset( $filters['status'] ) ? sanitize_key( $filters['status'] ) : '',
				'end_on_or_before' => current_time( 'mysql', true ),
				'limit'           => 1000,
			)
		);

		$group_student_ids = ! empty( $filters['group_id'] )
			? self::get_group_student_ids( absint( $filters['group_id'] ) )
			: array();
		$rows = array();

		foreach ( $bookings as $booking ) {
			if (
				'cancelled' === sanitize_key( $booking->status )
				|| ( $group_student_ids && ! in_array( absint( $booking->student_user_id ), $group_student_ids, true ) )
			) {
				continue;
			}

			$state = TutorHelper_Pro_Lesson_Follow_Up::get_homework_state_for_booking( absint( $booking->id ) );
			if ( empty( $state['due'] ) || ! empty( $state['completed'] ) || ! empty( $state['not_due'] ) ) {
				continue;
			}

			$student = get_userdata( absint( $booking->student_user_id ) );
			$homework = TutorHelper_Pro_Lesson_Follow_Up::get_reminder_homework_placeholders( absint( $booking->id ) );
			$rows[] = array(
				'booking_id'   => absint( $booking->id ),
				'student_id'   => absint( $booking->student_user_id ),
				'student_name' => $student ? $student->display_name : __( 'Unknown student', 'tutorhelper-pro' ),
				'due_at'       => (string) $booking->booking_end,
				'booking_type' => self::booking_type_label( $booking ),
				'homework'     => isset( $homework['{homework_due}'] ) ? (string) $homework['{homework_due}'] : '',
			);
		}

		usort(
			$rows,
			static function ( $left, $right ) {
				return strcmp( $left['due_at'], $right['due_at'] );
			}
		);

		return $rows;
	}

	/** Render the expandable outstanding-homework table. */
	public static function render_outstanding_homework_panel( $rows ) {
		$rows = is_array( $rows ) ? $rows : array();
		$students = array();
		$booking_types = array();
		foreach ( $rows as $row ) {
			$students[ absint( $row['student_id'] ) ] = (string) $row['student_name'];
			$booking_types[ (string) $row['booking_type'] ] = (string) $row['booking_type'];
		}
		asort( $students, SORT_NATURAL | SORT_FLAG_CASE );
		ksort( $booking_types, SORT_NATURAL | SORT_FLAG_CASE );
		?>
		<div class="tutorhelper-pro-outstanding-homework" data-outstanding-homework>
			<p><?php esc_html_e( 'These students have homework due from a past lesson that is not marked complete.', 'tutorhelper-pro' ); ?></p>
			<?php if ( empty( $rows ) ) : ?>
				<p class="tutorhelper-pro-outstanding-homework__empty"><?php esc_html_e( 'No outstanding homework matches the current student, tutor, booking type or group filters.', 'tutorhelper-pro' ); ?></p>
			<?php else : ?>
				<div class="tutorhelper-pro-outstanding-homework__controls" aria-label="<?php esc_attr_e( 'Outstanding homework table controls', 'tutorhelper-pro' ); ?>">
					<label><span><?php esc_html_e( 'Find', 'tutorhelper-pro' ); ?></span><input type="search" data-outstanding-homework-search placeholder="<?php esc_attr_e( 'Student or homework', 'tutorhelper-pro' ); ?>" /></label>
					<label><span><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></span><select data-outstanding-homework-student><option value=""><?php esc_html_e( 'All students', 'tutorhelper-pro' ); ?></option><?php foreach ( $students as $student_id => $student_name ) : ?><option value="<?php echo esc_attr( $student_id ); ?>"><?php echo esc_html( $student_name ); ?></option><?php endforeach; ?></select></label>
					<label><span><?php esc_html_e( 'Booking type', 'tutorhelper-pro' ); ?></span><select data-outstanding-homework-booking-type><option value=""><?php esc_html_e( 'All booking types', 'tutorhelper-pro' ); ?></option><?php foreach ( $booking_types as $booking_type ) : ?><option value="<?php echo esc_attr( $booking_type ); ?>"><?php echo esc_html( $booking_type ); ?></option><?php endforeach; ?></select></label>
					<label><span><?php esc_html_e( 'Order by', 'tutorhelper-pro' ); ?></span><select data-outstanding-homework-order><option value="due-asc"><?php esc_html_e( 'Due date: oldest first', 'tutorhelper-pro' ); ?></option><option value="due-desc"><?php esc_html_e( 'Due date: newest first', 'tutorhelper-pro' ); ?></option><option value="student-asc"><?php esc_html_e( 'Student: A–Z', 'tutorhelper-pro' ); ?></option><option value="student-desc"><?php esc_html_e( 'Student: Z–A', 'tutorhelper-pro' ); ?></option></select></label>
				</div>
				<div class="tutorhelper-pro-outstanding-homework__table-wrap">
					<table class="widefat striped">
						<thead><tr><th scope="col"><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Homework due lesson', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Booking type', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Homework', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Reminders sent', 'tutorhelper-pro' ); ?></th><th scope="col"><?php esc_html_e( 'Actions', 'tutorhelper-pro' ); ?></th></tr></thead>
						<tbody>
							<?php foreach ( $rows as $row ) : ?>
								<?php $reminder_dates = TutorHelper_Pro_Student_Email::get_homework_reminder_dates( absint( $row['booking_id'] ) ); ?>
								<tr data-outstanding-homework-row data-student-id="<?php echo esc_attr( absint( $row['student_id'] ) ); ?>" data-student-name="<?php echo esc_attr( strtolower( (string) $row['student_name'] ) ); ?>" data-booking-type="<?php echo esc_attr( strtolower( (string) $row['booking_type'] ) ); ?>" data-due-at="<?php echo esc_attr( (string) $row['due_at'] ); ?>" data-homework="<?php echo esc_attr( strtolower( wp_strip_all_tags( (string) $row['homework'] ) ) ); ?>">
									<td><?php echo esc_html( $row['student_name'] ); ?></td><td><?php echo esc_html( self::format_dashboard_datetime( $row['due_at'] ) ); ?></td><td><?php echo esc_html( $row['booking_type'] ); ?></td><td><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $row['homework'] ), 18 ) ); ?></td>
									<td class="tutorhelper-pro-outstanding-homework__reminders"><?php if ( empty( $reminder_dates ) ) : ?><span class="description"><?php esc_html_e( 'None sent', 'tutorhelper-pro' ); ?></span><?php else : ?><ul><?php foreach ( $reminder_dates as $reminder_date ) : ?><li><?php echo esc_html( $reminder_date ); ?></li><?php endforeach; ?></ul><?php endif; ?></td>
									<td class="tutorhelper-pro-outstanding-homework__actions"><?php TutorHelper_Pro_Student_Email::render_homework_reminder_button( absint( $row['student_id'] ), absint( $row['booking_id'] ) ); ?><button type="button" class="button tutorhelper-ui-button tutorhelper-ui-button--secondary" data-homework-not-due data-booking-id="<?php echo esc_attr( absint( $row['booking_id'] ) ); ?>"><?php esc_html_e( 'No longer due', 'tutorhelper-pro' ); ?></button></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<p class="tutorhelper-pro-outstanding-homework__empty-filter" data-outstanding-homework-empty hidden><?php esc_html_e( 'No outstanding homework matches these table filters.', 'tutorhelper-pro' ); ?></p>
				<?php TutorHelper_Pro_Student_Email::render_homework_reminder_composer(); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/** Return a readable booking type label. */
	private static function booking_type_label( $booking ) {
		$type = TutorHelper_Booking_Types::get_by_id( absint( $booking->booking_type_id ) );
		return $type && ! empty( $type->title )
			? sanitize_text_field( $type->title )
			: __( 'Lesson', 'tutorhelper-pro' );
	}

	/** Format a UTC booking date for the dashboard. */
	private static function format_dashboard_datetime( $date ) {
		$timestamp = strtotime( (string) $date . ' UTC' );
		return $timestamp
			? wp_date( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), $timestamp, wp_timezone() )
			: __( 'Past lesson', 'tutorhelper-pro' );
	}

	/**
	 * Restrict the shared dashboard context to students assigned to one Pro group.
	 *
	 * @param array $context Core dashboard context.
	 * @return array
	 */
	public static function filter_context_by_group( $context ) {
		if ( ! is_array( $context ) ) {
			return $context;
		}

		$group_id = isset( $_GET['dashboard_group'] ) && ! is_array( $_GET['dashboard_group'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
			? absint( wp_unslash( $_GET['dashboard_group'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: 0;
		$group = $group_id ? TutorHelper_Pro_Groups::get_by_id( $group_id ) : null;

		if ( ! $group || empty( $group->is_active ) ) {
			$group_id = 0;
		}

		$context['filters']['group_id']  = $group_id;
		$context['defaults']['group_id'] = 0;

		if ( ! $group_id ) {
			return $context;
		}

		$student_ids = self::get_group_student_ids( $group_id );
		$context['bookings'] = array_values(
			array_filter(
				isset( $context['bookings'] ) ? (array) $context['bookings'] : array(),
				static function ( $booking ) use ( $student_ids ) {
					return is_object( $booking )
						&& isset( $booking->student_user_id )
						&& in_array( absint( $booking->student_user_id ), $student_ids, true );
				}
			)
		);
		$context['booking_ids'] = array_values(
			array_filter( array_map( 'absint', wp_list_pluck( $context['bookings'], 'id' ) ) )
		);

		return $context;
	}

	/**
	 * Keep Core student totals within the selected Pro group.
	 *
	 * @param array $student_ids Core student IDs.
	 * @param array $context     Dashboard context.
	 * @return array
	 */
	public static function filter_student_ids_by_group( $student_ids, $context ) {
		$group_id = isset( $context['filters']['group_id'] )
			? absint( $context['filters']['group_id'] )
			: 0;

		if ( ! $group_id ) {
			return $student_ids;
		}

		return array_values(
			array_intersect(
				array_map( 'absint', (array) $student_ids ),
				self::get_group_student_ids( $group_id )
			)
		);
	}

	/** Return the selected group's newly registered student count. */
	public static function filter_new_student_count_by_group( $count, $context ) {
		$group_id = isset( $context['filters']['group_id'] )
			? absint( $context['filters']['group_id'] )
			: 0;

		if ( ! $group_id ) {
			return $count;
		}

		$student_ids = self::get_group_student_ids( $group_id );
		if ( ! empty( $context['filters']['student_id'] ) ) {
			$student_ids = array_values(
				array_intersect(
					$student_ids,
					array( absint( $context['filters']['student_id'] ) )
				)
			);
		}
		if ( empty( $student_ids ) ) {
			return 0;
		}

		return count(
			get_users(
				array(
					'role'       => TutorHelper_Students::STUDENT_ROLE,
					'fields'     => 'ids',
					'include'    => $student_ids,
					'date_query' => array(
						array(
							'after'     => $context['start_local']->format( 'Y-m-d 00:00:00' ),
							'before'    => $context['end_local']->format( 'Y-m-d 23:59:59' ),
							'inclusive' => true,
						),
					),
				)
			)
		);
	}

	/** Render the Pro group selector in Core's shared filter form. */
	public static function render_group_filter( $context ) {
		$selected = isset( $context['filters']['group_id'] )
			? absint( $context['filters']['group_id'] )
			: 0;
		$groups = TutorHelper_Pro_Groups::get_all();
		?>
		<label>
			<span><?php echo esc_html__( 'Group', 'tutorhelper-pro' ); ?></span>
			<select name="dashboard_group">
				<option value="0"><?php echo esc_html__( 'All groups', 'tutorhelper-pro' ); ?></option>
				<?php foreach ( (array) $groups as $group ) : ?>
					<option value="<?php echo esc_attr( absint( $group->id ) ); ?>" <?php selected( $selected, absint( $group->id ) ); ?>>
						<?php echo esc_html( $group->name ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</label>
		<?php
	}

	/** Return student user IDs assigned to a Pro group. */
	private static function get_group_student_ids( $group_id ) {
		return array_values(
			array_filter(
				array_map(
					static function ( $student ) {
						return $student instanceof WP_User ? absint( $student->ID ) : 0;
					},
					TutorHelper_Pro_Groups::get_group_students( absint( $group_id ) )
				)
			)
		);
	}

	/** Build a standard numeric widget. */
	private static function metric_widget( $label, $value, $description, $icon, $tone, $section, $priority ) {
		return array(
			'label'       => $label,
			'value'       => number_format_i18n( $value ),
			'description' => $description,
			'icon'        => $icon,
			'tone'        => $tone,
			'section'     => $section,
			'priority'    => $priority,
		);
	}

	/** Build an expandable attendance metric widget. */
	private static function attendance_widget( $label, $value, $description, $icon, $tone, $priority, $breakdown, $context ) {
		$widget = self::metric_widget( $label, $value, $description, $icon, $tone, 'attendance', $priority );
		$widget['panel_callback'] = array( __CLASS__, 'render_attendance_breakdown_shell' );
		$widget['panel_args'] = array(
			'breakdown' => sanitize_key( $breakdown ),
			'filters'   => isset( $context['filters'] ) ? $context['filters'] : array(),
		);
		return $widget;
	}

	/** Render the lightweight container populated when an attendance card is opened. */
	public static function render_attendance_breakdown_shell( $args ) {
		$filters = isset( $args['filters'] ) && is_array( $args['filters'] ) ? $args['filters'] : array();
		?>
		<div class="tutorhelper-pro-attendance-breakdown" data-breakdown="<?php echo esc_attr( sanitize_key( $args['breakdown'] ) ); ?>" data-filters="<?php echo esc_attr( wp_json_encode( $filters ) ); ?>">
			<p class="tutorhelper-pro-attendance-breakdown__status" role="status"><?php esc_html_e( 'Open this card to load its breakdown.', 'tutorhelper-pro' ); ?></p>
		</div>
		<?php
	}

	/** Handle an authenticated request for one attendance breakdown. */
	public static function handle_breakdown_request() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to view this report.', 'tutorhelper-pro' ) ), 403 );
		}
		check_ajax_referer( self::BREAKDOWN_ACTION, 'nonce' );

		$breakdown = isset( $_POST['breakdown'] ) && ! is_array( $_POST['breakdown'] ) ? sanitize_key( wp_unslash( $_POST['breakdown'] ) ) : '';
		if ( ! in_array( $breakdown, array( 'attended', 'late', 'missed', 'cancelled' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Select a valid attendance breakdown.', 'tutorhelper-pro' ) ), 400 );
		}

		$filters = self::sanitize_breakdown_filters();
		if ( is_wp_error( $filters ) ) {
			wp_send_json_error( array( 'message' => $filters->get_error_message() ), 400 );
		}

		$rows = self::get_attendance_breakdown_rows( $breakdown, $filters );
		ob_start();
		self::render_attendance_breakdown( $breakdown, $rows );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/** Sanitize and validate dashboard filters sent by the report shell. */
	private static function sanitize_breakdown_filters() {
		$raw = isset( $_POST['filters'] ) && is_array( $_POST['filters'] ) ? wp_unslash( $_POST['filters'] ) : array();
		$from = isset( $raw['from'] ) ? sanitize_text_field( $raw['from'] ) : '';
		$to   = isset( $raw['to'] ) ? sanitize_text_field( $raw['to'] ) : '';
		$from_date = DateTimeImmutable::createFromFormat( '!Y-m-d', $from, wp_timezone() );
		$to_date   = DateTimeImmutable::createFromFormat( '!Y-m-d', $to, wp_timezone() );
		if ( ! $from_date || ! $to_date || $from_date->format( 'Y-m-d' ) !== $from || $to_date->format( 'Y-m-d' ) !== $to || $from_date > $to_date ) {
			return new WP_Error( 'tutorhelper_pro_invalid_report_dates', __( 'The dashboard date range is invalid.', 'tutorhelper-pro' ) );
		}
		return array(
			'from'            => $from,
			'to'              => $to,
			'student_id'      => isset( $raw['student_id'] ) ? absint( $raw['student_id'] ) : 0,
			'tutor_id'        => isset( $raw['tutor_id'] ) ? absint( $raw['tutor_id'] ) : 0,
			'booking_type_id' => isset( $raw['booking_type_id'] ) ? absint( $raw['booking_type_id'] ) : 0,
			'group_id'        => isset( $raw['group_id'] ) ? absint( $raw['group_id'] ) : 0,
			'status'          => isset( $raw['status'] ) ? sanitize_key( $raw['status'] ) : '',
		);
	}

	/** Return booking rows for an attendance status using one bounded booking query. */
	private static function get_attendance_breakdown_rows( $breakdown, $filters ) {
		$timezone = wp_timezone();
		$start = new DateTimeImmutable( $filters['from'] . ' 00:00:00', $timezone );
		$end   = ( new DateTimeImmutable( $filters['to'] . ' 00:00:00', $timezone ) )->modify( '+1 day' );
		$query = array(
			'date_from' => $start->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
			'date_to'   => $end->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
			'limit'     => 1000,
		);
		foreach ( array( 'student_id' => 'student_user_id', 'tutor_id' => 'tutor_user_id', 'booking_type_id' => 'booking_type_id', 'status' => 'status' ) as $filter => $argument ) {
			if ( ! empty( $filters[ $filter ] ) ) {
				$query[ $argument ] = $filters[ $filter ];
			}
		}
		$bookings = TutorHelper_Booking_Records::get_all( $query );
		if ( $filters['group_id'] ) {
			$student_ids = self::get_group_student_ids( $filters['group_id'] );
			$bookings = array_values( array_filter( $bookings, static function ( $booking ) use ( $student_ids ) {
				return in_array( absint( $booking->student_user_id ), $student_ids, true );
			} ) );
		}
		$records = TutorHelper_Pro_Booking_Attendance::get_for_booking_ids( array_map( 'absint', wp_list_pluck( $bookings, 'id' ) ) );
		return array_values( array_filter( $bookings, static function ( $booking ) use ( $breakdown, $records ) {
			if ( 'cancelled' === $breakdown ) {
				return TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status );
			}
			if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
				return false;
			}
			$id = absint( $booking->id );
			$status = isset( $records[ $id ] ) ? sanitize_key( $records[ $id ]->attendance_status ) : TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED;
			return $breakdown === $status;
		} ) );
	}

	/** Render student, lesson-type and popular scheduling summaries. */
	private static function render_attendance_breakdown( $breakdown, $bookings ) {
		$students = array();
		$types = array();
		$days = array();
		$times = array();
		$type_map = array();
		foreach ( (array) TutorHelper_Booking_Types::get_all() as $type ) {
			$type_map[ absint( $type->id ) ] = $type->title;
		}
		foreach ( $bookings as $booking ) {
			$student = $booking->student_name ? $booking->student_name : __( 'Unknown student', 'tutorhelper-pro' );
			$type = isset( $type_map[ absint( $booking->booking_type_id ) ] ) ? $type_map[ absint( $booking->booking_type_id ) ] : __( 'Lesson', 'tutorhelper-pro' );
			$timestamp = strtotime( $booking->booking_start . ' UTC' );
			$day = wp_date( 'l', $timestamp, wp_timezone() );
			$time = wp_date( get_option( 'time_format' ), $timestamp, wp_timezone() );
			$students[ $student ] = isset( $students[ $student ] ) ? $students[ $student ] + 1 : 1;
			$types[ $type ] = isset( $types[ $type ] ) ? $types[ $type ] + 1 : 1;
			$days[ $day ] = isset( $days[ $day ] ) ? $days[ $day ] + 1 : 1;
			$times[ $time ] = isset( $times[ $time ] ) ? $times[ $time ] + 1 : 1;
		}
		foreach ( array( &$students, &$types, &$days, &$times ) as &$items ) {
			arsort( $items );
		}
		unset( $items );
		$labels = array(
			'attended'  => __( 'Attended', 'tutorhelper-pro' ),
			'late'      => __( 'Late', 'tutorhelper-pro' ),
			'missed'    => __( 'Missed', 'tutorhelper-pro' ),
			'cancelled' => __( 'Cancelled', 'tutorhelper-pro' ),
		);
		?>
		<section class="tutorhelper-pro-dashboard-report tutorhelper-pro-attendance-report">
			<header class="tutorhelper-pro-attendance-report__header">
				<div>
					<h2>
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: Attendance status. */
								__( '%s breakdown', 'tutorhelper-pro' ),
								$labels[ $breakdown ]
							)
						);
						?>
					</h2>
					<p>
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: Number of matching lessons. */
								_n( '%s matching lesson', '%s matching lessons', count( $bookings ), 'tutorhelper-pro' ),
								number_format_i18n( count( $bookings ) )
							)
						);
						?>
					</p>
				</div>
				<button type="button" class="button tutorhelper-ui-button tutorhelper-ui-button--primary tutorhelper-pro-attendance-breakdown__refresh"><?php esc_html_e( 'Refresh breakdown', 'tutorhelper-pro' ); ?></button>
			</header>
			<?php if ( empty( $bookings ) ) : ?><p><?php esc_html_e( 'No lessons match this status and the current dashboard filters.', 'tutorhelper-pro' ); ?></p><?php else : ?>
			<div class="tutorhelper-pro-attendance-report__grid">
				<?php self::render_breakdown_list( __( 'Students', 'tutorhelper-pro' ), $students ); ?>
				<?php self::render_breakdown_list( __( 'Lesson types', 'tutorhelper-pro' ), $types ); ?>
				<?php self::render_breakdown_list( __( 'Top days', 'tutorhelper-pro' ), $days ); ?>
				<?php self::render_breakdown_list( __( 'Top times', 'tutorhelper-pro' ), $times ); ?>
			</div><?php endif; ?>
		</section>
		<?php
	}

	/** Render one ranked breakdown list with an optional full-data disclosure. */
	private static function render_breakdown_list( $heading, $items ) {
		$items = is_array( $items ) ? $items : array();
		$top_items = array_slice( $items, 0, 5, true );
		$remaining_items = array_slice( $items, 5, null, true );
		?>
		<section>
			<h3><?php echo esc_html( $heading ); ?></h3>
			<ol>
				<?php foreach ( $top_items as $label => $count ) : ?>
					<li><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( number_format_i18n( $count ) ); ?></strong></li>
				<?php endforeach; ?>
			</ol>
			<?php if ( ! empty( $remaining_items ) ) : ?>
				<details class="tutorhelper-pro-attendance-report__all-items">
					<summary>
						<?php
						echo esc_html(
							sprintf(
								/* translators: %d: Number of additional report rows. */
								_n( 'Show %d more', 'Show %d more', count( $remaining_items ), 'tutorhelper-pro' ),
								count( $remaining_items )
							)
						);
						?>
					</summary>
					<ol start="6">
						<?php foreach ( $remaining_items as $label => $count ) : ?>
							<li><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( number_format_i18n( $count ) ); ?></strong></li>
						<?php endforeach; ?>
					</ol>
				</details>
			<?php endif; ?>
		</section>
		<?php
	}

	/** Supply Core's parent-link filter with the eligible missing-parent IDs. */
	public static function filter_students_without_parent_ids( $student_ids, $filter ) {
		return 'missing' === $filter ? self::get_students_without_parent_ids() : $student_ids;
	}

	/** Return active under-18 student accounts with no active parent link. */
	private static function get_students_without_parent_ids() {
		global $wpdb;
		$students = get_users( array( 'role' => TutorHelper_Students::STUDENT_ROLE, 'fields' => 'all_with_meta' ) );
		if ( empty( $students ) || ! TutorHelper_Student_Parent_Links::table_exists() ) {
			return array();
		}
		$ids = array_map( 'absint', wp_list_pluck( $students, 'ID' ) );
		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
		$args = array_merge( array( TutorHelper_Student_Parent_Links::get_table_name(), TutorHelper_Student_Parent_Links::STATUS_ACTIVE ), $ids );
		$linked = array_map( 'absint', $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT student_user_id FROM %i WHERE status = %s AND student_user_id IN ({$placeholders})", $args ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- One current, bounded relationship lookup avoids per-student queries.
		$today = new DateTimeImmutable( 'today', wp_timezone() );
		$missing = array();
		foreach ( $students as $student ) {
			$id = absint( $student->ID );
			$status = sanitize_key( get_user_meta( $id, 'tutorhelper_registration_status', true ) );
			if ( in_array( $id, $linked, true ) || 1 === absint( get_user_meta( $id, TutorHelper_Students::META_BOOKING_BLOCKED, true ) ) || in_array( $status, array( TutorHelper_Pro_Registration_Admin::STATUS_NEW, TutorHelper_Pro_Registration_Admin::STATUS_WAITING_LIST ), true ) ) {
				continue;
			}
			$dob = sanitize_text_field( get_user_meta( $id, TutorHelper_Students::META_DATE_OF_BIRTH, true ) );
			$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $dob, wp_timezone() );
			if ( ! $date || $date->format( 'Y-m-d' ) !== $dob || $date > $today || 18 <= $date->diff( $today )->y ) {
				continue;
			}
			$missing[] = $id;
		}
		return array_values( array_unique( array_map( 'absint', apply_filters( 'tutorhelper_pro_students_without_parent_ids', $missing ) ) ) );
	}

	/**
	 * Return unbooked availability and its day-by-day timetable.
	 *
	 * @param array $context Shared dashboard context.
	 * @return array
	 */
	private static function get_remaining_availability( $context ) {
		$result = array( 'seconds' => 0, 'days' => array() );
		if ( ! class_exists( 'TutorHelper_Booking_Availability' ) ) {
			return $result;
		}

		$rules = TutorHelper_Booking_Availability::get_all(
			array( 'active_only' => true )
		);
		$tutor_ids = array_values(
			array_unique( array_filter( array_map( 'absint', wp_list_pluck( $rules, 'tutor_user_id' ) ) ) )
		);
		if ( ! empty( $context['filters']['tutor_id'] ) ) {
			$tutor_ids = array_values(
				array_intersect( $tutor_ids, array( absint( $context['filters']['tutor_id'] ) ) )
			);
		}

		foreach ( $tutor_ids as $tutor_id ) {
			$occurrences = TutorHelper_Booking_Availability::get_occurrences(
				$tutor_id,
				$context['start_local']->format( 'Y-m-d' ),
				$context['end_local']->format( 'Y-m-d' )
			);
			if ( is_wp_error( $occurrences ) ) {
				continue;
		}

			$bookings = TutorHelper_Booking_Records::get_all(
				array(
					'tutor_user_id' => $tutor_id,
					'end_after' => $context['start_utc']->format( 'Y-m-d H:i:s' ),
					'date_to' => $context['end_utc_exclusive']->format( 'Y-m-d H:i:s' ),
					'limit' => 1000,
				)
			);
			$busy = array();
			foreach ( $bookings as $booking ) {
				$payment_status = isset( $booking->payment_status )
					? sanitize_key( $booking->payment_status )
					: '';
				if (
					TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status )
					|| in_array(
						$payment_status,
						array(
							TutorHelper_Booking_Records::PAYMENT_STATUS_FAILED,
							TutorHelper_Booking_Records::PAYMENT_STATUS_EXPIRED,
						),
						true
					)
				) {
					continue;
				}
				$start = strtotime( $booking->booking_start . ' UTC' );
				$end = strtotime( $booking->booking_end . ' UTC' );
				if ( false !== $start && false !== $end && $end > $start ) {
					$busy[] = array( $start, $end );
				}
			}

			foreach ( $occurrences as $occurrence ) {
				$date = sanitize_text_field( $occurrence['date'] );
				try {
					$start = new DateTimeImmutable( $date . ' ' . $occurrence['start_time'], $context['timezone'] );
					$end = new DateTimeImmutable( $date . ' ' . $occurrence['end_time'], $context['timezone'] );
				} catch ( Exception $exception ) {
					continue;
				}
				if ( $end <= $start ) {
					continue;
				}
				if ( ! isset( $result['days'][ $date ] ) ) {
					$result['days'][ $date ] = array();
				}
				$result['days'][ $date ][] = array( $start->getTimestamp(), $end->getTimestamp(), $tutor_id );
			}
			$result['days'] = self::subtract_bookings_from_days( $result['days'], $busy, $tutor_id );
		}

		ksort( $result['days'] );
		foreach ( $result['days'] as $ranges ) {
			foreach ( $ranges as $range ) {
				$result['seconds'] += max( 0, $range[1] - $range[0] );
			}
		}
		return $result;
	}

	/** Subtract one tutor's occupied intervals from their availability. */
	private static function subtract_bookings_from_days( $days, $busy, $tutor_id ) {
		foreach ( $days as $date => $ranges ) {
			$other = array();
			$mine = array();
			foreach ( $ranges as $range ) {
				if ( absint( $range[2] ) === absint( $tutor_id ) ) {
					$mine[] = array( $range[0], $range[1] );
				} else {
					$other[] = $range;
				}
			}
			$mine = self::merge_time_ranges( $mine );
			foreach ( $busy as $occupied ) {
				$next = array();
				foreach ( $mine as $available ) {
					if ( $occupied[1] <= $available[0] || $occupied[0] >= $available[1] ) {
						$next[] = $available;
						continue;
					}
					if ( $occupied[0] > $available[0] ) {
						$next[] = array( $available[0], min( $occupied[0], $available[1] ) );
					}
					if ( $occupied[1] < $available[1] ) {
						$next[] = array( max( $occupied[1], $available[0] ), $available[1] );
					}
				}
				$mine = $next;
			}
			foreach ( $mine as $range ) {
				$other[] = array( $range[0], $range[1], $tutor_id );
			}
			$days[ $date ] = $other;
		}
		return $days;
	}

	/** Merge overlapping timestamp ranges. */
	private static function merge_time_ranges( $ranges ) {
		usort(
			$ranges,
			static function ( $left, $right ) {
				return $left[0] - $right[0];
			}
		);
		$merged = array();
		foreach ( $ranges as $range ) {
			$last = count( $merged ) - 1;
			if ( $last >= 0 && $range[0] <= $merged[ $last ][1] ) {
				$merged[ $last ][1] = max( $merged[ $last ][1], $range[1] );
			} else {
				$merged[] = $range;
			}
		}
		return $merged;
	}

	/**
	 * Render an expandable weekly timetable of unbooked availability.
	 *
	 * @param array $context Shared dashboard context.
	 * @return void
	 */
	public static function render_availability_report( $context ) {
		if ( empty( $context ) ) {
			return;
		}
		$availability = self::get_remaining_availability( $context );
		$weeks = array();
		foreach ( $availability['days'] as $date => $ranges ) {
			$day = new DateTimeImmutable( $date, $context['timezone'] );
			$monday = $day->modify( 'monday this week' )->format( 'Y-m-d' );
			$weeks[ $monday ][ $date ] = $ranges;
		}
		?>
		<section class="tutorhelper-pro-dashboard-report tutorhelper-pro-availability-report" id="tutorhelper-availability-report">
			<header>
				<h2><?php esc_html_e( 'Remaining bookable hours', 'tutorhelper-pro' ); ?></h2>
				<p><?php esc_html_e( 'Unbooked availability after confirmed and pending lessons have been removed.', 'tutorhelper-pro' ); ?></p>
			</header>
			<?php if ( empty( $weeks ) ) : ?>
				<p><?php esc_html_e( 'There are no remaining available times in the selected period.', 'tutorhelper-pro' ); ?></p>
			<?php else : ?>
				<?php foreach ( $weeks as $monday => $days ) : ?>
					<div class="tutorhelper-pro-availability-week">
						<h3><?php echo esc_html( sprintf( __( 'Week beginning %s', 'tutorhelper-pro' ), wp_date( get_option( 'date_format' ), strtotime( $monday . ' 00:00:00' ), $context['timezone'] ) ) ); ?></h3>
						<div class="tutorhelper-pro-availability-grid">
							<?php for ( $offset = 0; $offset < 7; $offset++ ) : ?>
								<?php $date = ( new DateTimeImmutable( $monday, $context['timezone'] ) )->modify( '+' . $offset . ' days' )->format( 'Y-m-d' ); ?>
								<section>
									<h4><?php echo esc_html( wp_date( 'D j M', strtotime( $date . ' 00:00:00' ), $context['timezone'] ) ); ?></h4>
									<?php if ( empty( $days[ $date ] ) ) : ?>
										<span class="tutorhelper-pro-availability-empty">—</span>
									<?php else : ?>
										<?php foreach ( $days[ $date ] as $range ) : ?>
											<span class="tutorhelper-pro-availability-slot"><?php echo esc_html( wp_date( get_option( 'time_format' ), $range[0], $context['timezone'] ) . '–' . wp_date( get_option( 'time_format' ), $range[1], $context['timezone'] ) ); ?></span>
										<?php endforeach; ?>
									<?php endif; ?>
								</section>
							<?php endfor; ?>
						</div>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>
		</section>
		<?php
	}

	/** Return attendance counts for filtered bookings. */
	private static function get_attendance_summary( $context ) {
		$summary = array(
			'todo'      => 0,
			'attended'  => 0,
			'late'      => 0,
			'missed'    => 0,
			'cancelled' => 0,
		);
		$records = TutorHelper_Pro_Booking_Attendance::get_for_booking_ids( $context['booking_ids'] );
		$now     = current_time( 'timestamp', true );

		foreach ( $context['bookings'] as $booking ) {
			$booking_id = absint( $booking->id );
			if ( TutorHelper_Booking_Records::STATUS_CANCELLED === $booking->status ) {
				++$summary['cancelled'];
				continue;
			}

			$status = isset( $records[ $booking_id ] )
				? sanitize_key( $records[ $booking_id ]->attendance_status )
				: TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED;

			if ( isset( $summary[ $status ] ) ) {
				++$summary[ $status ];
			}

			$end = strtotime( $booking->booking_end . ' UTC' );
			if (
				TutorHelper_Booking_Records::STATUS_CONFIRMED === $booking->status
				&& false !== $end
				&& $end <= $now
				&& TutorHelper_Pro_Booking_Attendance::STATUS_NOT_RECORDED === $status
			) {
				++$summary['todo'];
			}
		}

		return $summary;
	}

	/** Return Finance-tab paid and outstanding totals. */
	private static function get_finance_summary( $context ) {
		$currency = TutorHelper_Currency::get_currency();
		$totals   = TutorHelper_Pro_Finance_Admin::get_summary_for_booking_ids(
			isset( $context['booking_ids'] ) ? $context['booking_ids'] : array()
		);

		return array(
			'paid'     => max( 0, intval( $totals['paid_minor_units'] ) ),
			'due'      => max( 0, intval( $totals['upcoming_minor_units'] ) + intval( $totals['overdue_minor_units'] ) ),
			'currency' => $currency,
		);
	}

	/** Return email delivery counts within the report context. */
	private static function get_email_summary( $context ) {
		global $wpdb;

		$summary = array( 'sent' => 0, 'failed' => 0 );
		$table   = TutorHelper_Pro_Database::get_table_name( 'email_deliveries' );
		$where   = array( 'created_at >= %s', 'created_at < %s' );
		$args    = array(
			$table,
			$context['start_utc']->format( 'Y-m-d H:i:s' ),
			$context['end_utc_exclusive']->format( 'Y-m-d H:i:s' ),
		);
		$filters = $context['filters'];
		$scoped  = $filters['student_id'] || $filters['tutor_id'] || $filters['booking_type_id'] || $filters['status'] || ! empty( $filters['group_id'] );

		if ( $scoped ) {
			if ( empty( $context['booking_ids'] ) ) {
				return $summary;
			}
			$placeholders = implode( ', ', array_fill( 0, count( $context['booking_ids'] ), '%d' ) );
			$where[] = "related_object_type = 'booking'";
			$where[] = "related_object_id IN ({$placeholders})";
			$args    = array_merge( $args, $context['booking_ids'] );
		}

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current delivery reporting data is required.
			$wpdb->prepare( 'SELECT status, COUNT(*) AS total FROM %i WHERE ' . implode( ' AND ', $where ) . ' GROUP BY status', $args ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Fixed fragments and prepared values.
		);
		foreach ( $rows as $row ) {
			$status = sanitize_key( $row->status );
			if ( isset( $summary[ $status ] ) ) {
				$summary[ $status ] = absint( $row->total );
			}
		}
		return $summary;
	}

	/** Return new and waiting-list registration counts. */
	private static function get_registration_summary( $context ) {
		$base = array(
			'role'       => TutorHelper_Students::STUDENT_ROLE,
			'fields'     => 'ids',
			'date_query' => array(
				array(
					'after'     => $context['start_local']->format( 'Y-m-d 00:00:00' ),
					'before'    => $context['end_local']->format( 'Y-m-d 23:59:59' ),
					'inclusive' => true,
				),
			),
		);
		if ( $context['filters']['student_id'] ) {
			$base['include'] = array( $context['filters']['student_id'] );
		}
		if ( ! empty( $context['filters']['group_id'] ) ) {
			$group_student_ids = self::get_group_student_ids( $context['filters']['group_id'] );
			$base['include'] = isset( $base['include'] )
				? array_values( array_intersect( $base['include'], $group_student_ids ) )
				: $group_student_ids;
			if ( empty( $base['include'] ) ) {
				return array( 'new' => 0, 'waiting' => 0 );
			}
		}

		$result = array( 'new' => 0, 'waiting' => 0 );
		foreach ( array( 'new' => TutorHelper_Pro_Registration_Admin::STATUS_NEW, 'waiting' => TutorHelper_Pro_Registration_Admin::STATUS_WAITING_LIST ) as $key => $status ) {
			$args = $base;
			$args['meta_query'] = array(
				array( 'key' => 'tutorhelper_registration_source', 'value' => 'student_registration' ),
				array( 'key' => 'tutorhelper_registration_status', 'value' => $status ),
			);
			$result[ $key ] = count( get_users( $args ) );
		}
		return $result;
	}

	/** Return average and response count for lesson ratings. */
	private static function get_rating_summary( $context ) {
		global $wpdb;

		$result = array( 'count' => 0, 'average' => 0 );
		if ( empty( $context['booking_ids'] ) ) {
			return $result;
		}

		$table        = TutorHelper_Pro_Database::get_table_name( 'lesson_ratings' );
		$placeholders = implode( ', ', array_fill( 0, count( $context['booking_ids'] ), '%d' ) );
		$args         = array_merge( array( $table ), $context['booking_ids'] );
		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current student rating data is required.
			$wpdb->prepare(
				"SELECT COUNT(*) AS total, AVG(rating) AS average FROM %i WHERE booking_id IN ({$placeholders})",
				$args
			)
		);
		if ( $row ) {
			$result['count']   = absint( $row->total );
			$result['average'] = (float) $row->average;
		}
		return $result;
	}

	/**
	 * Render the expandable, filtered ratings report.
	 *
	 * @param array $context Shared dashboard context.
	 * @return void
	 */
	public static function render_rating_report( $context ) {
		if ( empty( $context['booking_ids'] ) ) {
			return;
		}

		$rows = array();
		foreach ( $context['booking_ids'] as $booking_id ) {
			$rating = TutorHelper_Pro_Lesson_Follow_Up::get_rating_for_booking(
				absint( $booking_id )
			);
			$booking = $rating
				? TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) )
				: null;
			if ( ! $rating || ! $booking ) {
				continue;
			}
			$rows[] = array(
				'rating'  => $rating,
				'booking' => $booking,
				'student' => get_userdata( absint( $booking->student_user_id ) ),
				'type'    => TutorHelper_Booking_Types::get_by_id( absint( $booking->booking_type_id ) ),
			);
		}
		?>
		<section class="tutorhelper-pro-dashboard-report" id="tutorhelper-ratings-report">
			<header>
				<h2><?php esc_html_e( 'Lesson ratings and comments', 'tutorhelper-pro' ); ?></h2>
				<p><?php esc_html_e( 'Ratings matching the dashboard filters and date range.', 'tutorhelper-pro' ); ?></p>
			</header>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></th>
					<th><?php esc_html_e( 'Lesson Type', 'tutorhelper-pro' ); ?></th>
					<th><?php esc_html_e( 'Date / Time', 'tutorhelper-pro' ); ?></th>
					<th><?php esc_html_e( 'Rating', 'tutorhelper-pro' ); ?></th>
					<th><?php esc_html_e( 'Comment', 'tutorhelper-pro' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="5"><?php esc_html_e( 'No ratings match the current filters.', 'tutorhelper-pro' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<td><?php echo esc_html( $row['student'] ? $row['student']->display_name : $row['booking']->student_name ); ?></td>
							<td><?php echo esc_html( $row['type'] ? $row['type']->title : __( 'Lesson', 'tutorhelper-pro' ) ); ?></td>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $row['booking']->booking_start . ' UTC' ), wp_timezone() ) ); ?></td>
							<td><?php echo esc_html( absint( $row['rating']->rating ) . ' / 5' ); ?></td>
							<td><?php echo esc_html( $row['rating']->comment ? $row['rating']->comment : '—' ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>
		</section>
		<?php
	}

	/** Return a filtered Student Bookings attendance URL. */
	private static function get_attendance_url( $context ) {
		$args = array(
			'page'                        => TutorHelper_Booking_Hub::PAGE_SLUG,
			'tab'                         => 'student-bookings',
			'student_bookings_date_from'  => $context['filters']['from'],
			'student_bookings_date_to'    => $context['filters']['to'],
			'student_bookings_time_scope' => 'past',
			'student_bookings_status'     => TutorHelper_Booking_Records::STATUS_CONFIRMED,
		);
		if ( $context['filters']['booking_type_id'] ) {
			$args['student_bookings_booking_type_id'] = $context['filters']['booking_type_id'];
		}
		if ( $context['filters']['student_id'] ) {
			$user = get_userdata( $context['filters']['student_id'] );
			if ( $user ) {
				$args['student_bookings_student_search'] = $user->display_name;
			}
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/** Return Finance tab URL for the dashboard lesson-date range. */
	private static function get_finance_url( $context, $payment_statuses = array() ) {
		$payment_statuses = is_array( $payment_statuses )
			? $payment_statuses
			: array( $payment_statuses );
		$payment_statuses = array_values( array_filter( array_map( 'sanitize_key', $payment_statuses ) ) );
		return add_query_arg(
			array(
				'page'                     => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab'                      => 'finance',
				'finance_view'             => 'all',
				'finance_payment_status'   => $payment_statuses,
				'finance_lesson_date_from' => $context['filters']['from'],
				'finance_lesson_date_to'   => $context['filters']['to'],
			),
			admin_url( 'admin.php' )
		);
	}

	/** Return Email tab URL. */
	private static function get_emails_url() {
		return add_query_arg( array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => 'emails' ), admin_url( 'admin.php' ) ) . '#tutorhelper-pro-email-delivery-history';
	}

	/** Return Registration workspace URL. */
	private static function get_registrations_url() {
		return add_query_arg(
			array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => TutorHelper_Students_Admin::TAB_KEY, 'student_view' => TutorHelper_Pro_Registration_Admin::VIEW_KEY ),
			admin_url( 'admin.php' )
		);
	}

	/** Return the Core Students view filtered to missing active parent links. */
	private static function get_students_without_parent_url() {
		return add_query_arg(
			array(
				'page'                => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab'                 => TutorHelper_Students_Admin::TAB_KEY,
				'student_parent_link' => 'missing',
			),
			admin_url( 'admin.php' )
		);
	}
}
