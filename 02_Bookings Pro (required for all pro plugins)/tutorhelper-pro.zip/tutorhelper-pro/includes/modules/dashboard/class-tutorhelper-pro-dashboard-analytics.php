<?php
/**
 * Pro dashboard analytics extensions.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds conversion reporting to the Core analytics dashboard.
 */
final class TutorHelper_Pro_Dashboard_Analytics {

	/** Register dashboard hooks. */
	public static function init() {
		add_filter( 'tutorhelper_dashboard_widgets', array( __CLASS__, 'add_conversion_widget' ), 30, 2 );
	}

	/**
	 * Add a booking-page conversion card when the selected filters are valid.
	 *
	 * Visitor totals are daily aggregates and cannot be attributed to an
	 * individual student, tutor, Booking Type or booking status. Hiding the
	 * conversion card for those filtered views avoids presenting a misleading
	 * percentage.
	 *
	 * @param array $widgets Existing widgets.
	 * @param array $context Shared dashboard context.
	 * @return array
	 */
	public static function add_conversion_widget( $widgets, $context ) {
		if (
			! class_exists( 'TutorHelper_Booking_Page_Analytics' )
			|| ! TutorHelper_Booking_Page_Analytics::is_enabled()
			|| ! empty( $context['filters']['student_id'] )
			|| ! empty( $context['filters']['tutor_id'] )
			|| ! empty( $context['filters']['booking_type_id'] )
			|| ! empty( $context['filters']['status'] )
		) {
			return $widgets;
		}

		$views = TutorHelper_Booking_Page_Analytics::get_total(
			$context['start_local']->format( 'Y-m-d' ),
			$context['end_local']->format( 'Y-m-d' )
		);
		$student_bookings = self::count_student_requests( $context );

		$widgets['booking_page_conversion'] = array(
			'label'       => __( 'Booking-page conversion', 'tutorhelper-pro' ),
			'value'       => $views
				? number_format_i18n( ( $student_bookings / $views ) * 100, 1 ) . '%'
				: '—',
			'description' => sprintf(
				/* translators: 1: student-created bookings, 2: booking-page views. */
				__( '%1$s student requests from %2$s aggregate page views. Repeat views count separately.', 'tutorhelper-pro' ),
				number_format_i18n( $student_bookings ),
				number_format_i18n( $views )
			),
			'icon'        => 'chart-pie',
			'tone'        => 'success',
			'section'     => 'analytics',
			'priority'    => 30,
		);

		return $widgets;
	}

	/**
	 * Count requests created in the selected period.
	 *
	 * The creation timestamp, rather than the scheduled lesson date, keeps the
	 * numerator aligned with booking-page views from the same period.
	 *
	 * @param array $context Shared dashboard context.
	 * @return int
	 */
	private static function count_student_requests( $context ) {
		global $wpdb;
		$table = TutorHelper_Booking_Records::get_table_name();
		return absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Dashboard reporting requires a current aggregate.
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i WHERE source = %s AND created_at >= %s AND created_at < %s',
					$table,
					TutorHelper_Booking_Records::SOURCE_STUDENT,
					$context['start_utc']->format( 'Y-m-d H:i:s' ),
					$context['end_utc_exclusive']->format( 'Y-m-d H:i:s' )
				)
			)
		);
	}
}
