<?php
/**
 * Row-based refund and credit controls for TutorHelper Pro Finance.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Makes finance adjustments available directly from Finance table rows.
 */
final class TutorHelper_Pro_Finance_Adjustment_UI {

	const SCRIPT_HANDLE = 'tutorhelper-pro-finance-adjustment-ui';
	const STYLE_HANDLE = 'tutorhelper-pro-finance-adjustment-ui';

	/** Register admin assets. */
	public static function init() {
		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' ),
			50
		);
	}

	/**
	 * Load the row controls on Finance > All Finance Data only.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] )
			? sanitize_key( wp_unslash( $_GET['tab'] ) )
			: '';
		$view = isset( $_GET['finance_view'] ) && ! is_array( $_GET['finance_view'] )
			? sanitize_key( wp_unslash( $_GET['finance_view'] ) )
			: '';

		if (
			TutorHelper_Pro_Finance_Admin::TAB_KEY !== $tab
			|| TutorHelper_Pro_Finance_Admin::VIEW_ALL !== $view
		) {
			return;
		}

		$script_path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-finance-adjustment-ui.js';
		$style_path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-finance-adjustment-ui.css';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-finance-adjustment-ui.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_PRO_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperProFinanceAdjustmentUI',
			array(
				'actionUrl' => admin_url( 'admin-post.php' ),
				'action' => TutorHelper_Pro_Finance_Adjustments::ACTION,
				'nonce' => wp_create_nonce( TutorHelper_Pro_Finance_Adjustments::NONCE_ACTION ),
				'bookings' => self::prepare_booking_summaries(),
				'labels' => array(
					'button' => __( 'Refund / credit', 'tutorhelper-pro' ),
					'heading' => __( 'Refund or issue account credit', 'tutorhelper-pro' ),
					'action' => __( 'Action', 'tutorhelper-pro' ),
					'credit' => __( 'Issue account credit', 'tutorhelper-pro' ),
					'externalRefund' => __( 'Record refund (processed externally)', 'tutorhelper-pro' ),
					'stripeRefund' => __( 'Refund through Stripe', 'tutorhelper-pro' ),
					'amount' => __( 'Amount', 'tutorhelper-pro' ),
					'notes' => __( 'Notes', 'tutorhelper-pro' ),
					'save' => __( 'Record finance adjustment', 'tutorhelper-pro' ),
					'refundable' => __( 'Available to refund or credit', 'tutorhelper-pro' ),
					'stripeUnavailable' => __( 'No refundable Stripe payment is available for this lesson.', 'tutorhelper-pro' ),
					'close' => __( 'Cancel', 'tutorhelper-pro' ),
					'creditHelp' => __( 'This converts part or all of the refundable balance into reusable account credit for the student.', 'tutorhelper-pro' ),
					'externalRefundHelp' => __( 'Use this only when the money has already been returned outside TutorHelper. No Stripe refund is created.', 'tutorhelper-pro' ),
					'stripeRefundHelp' => __( 'This sends a real refund request to Stripe first. TutorHelper records the refund only after Stripe accepts it.', 'tutorhelper-pro' ),
				)
			)
		);

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-finance-adjustment-ui.css',
			array( 'tutorhelper-pro-finance', 'tutorhelper-pro-finance-payments' ),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_PRO_VERSION
		);
	}

	/**
	 * Prepare current refundable balances for Finance table rows.
	 *
	 * @return array
	 */
	private static function prepare_booking_summaries() {
		global $wpdb;

		$table = TutorHelper_Booking_Records::get_table_name();
		$bookings = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin finance controls require current balances.
			"SELECT * FROM {$table} ORDER BY booking_start DESC LIMIT 1000"
		);

		$prepared = array();
		foreach ( $bookings as $booking ) {
			$totals = TutorHelper_Pro_Finance_Adjustments::get_booking_totals( $booking->id );
			$refundable = absint( $totals['refundable_minor_units'] );

			if ( 0 === $refundable ) {
				continue;
			}

			$currency = ! empty( $booking->currency )
				? strtoupper( sanitize_text_field( $booking->currency ) )
				: TutorHelper_Currency::get_currency();
			$stripe_refundable = self::get_stripe_refundable_amount( $booking->id );

			$prepared[ absint( $booking->id ) ] = array(
				'bookingId' => absint( $booking->id ),
				'studentName' => sanitize_text_field( $booking->student_name ),
				'lessonLabel' => self::format_lesson_label( $booking ),
				'refundableMinorUnits' => $refundable,
				'refundableLabel' => TutorHelper_Currency::format_minor_units( $refundable, $currency ),
				'stripeRefundableMinorUnits' => $stripe_refundable,
				'canStripeRefund' => 0 < $stripe_refundable,
				'currency' => $currency,
			);
		}

		return $prepared;
	}

	/**
	 * Return the remaining amount actually refundable through Stripe.
	 *
	 * @param int $booking_id Booking ID.
	 * @return int
	 */
	private static function get_stripe_refundable_amount( $booking_id ) {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$payments = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Stripe refund availability must be current.
			$wpdb->prepare(
				'SELECT provider_reference, amount_minor_units FROM %i WHERE booking_id = %d AND payment_provider = %s AND transaction_type IN (%s, %s) ORDER BY id DESC',
				$table,
				absint( $booking_id ),
				TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
				TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
				TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT
			)
		);

		$total = 0;
		foreach ( $payments as $payment ) {
			$payment_intent = sanitize_text_field( $payment->provider_reference );
			if ( 0 !== strpos( $payment_intent, 'pi_' ) ) {
				continue;
			}

			$refunded = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Stripe refund availability must be current.
				$wpdb->prepare(
					'SELECT COALESCE(SUM(amount_minor_units), 0) FROM %i WHERE booking_id = %d AND transaction_type = %s AND payment_provider = %s AND provider_reference = %s',
					$table,
					absint( $booking_id ),
					TutorHelper_Pro_Payment_Ledger::TYPE_REFUND,
					TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					$payment_intent
				)
			);

			$total += max( 0, absint( $payment->amount_minor_units ) - $refunded );
		}

		return $total;
	}

	/**
	 * Format the lesson date/time shown in the adjustment modal.
	 *
	 * @param object $booking Booking record.
	 * @return string
	 */
	private static function format_lesson_label( $booking ) {
		try {
			$value = new DateTimeImmutable(
				sanitize_text_field( $booking->booking_start ),
				new DateTimeZone( 'UTC' )
			);
			$value = $value->setTimezone( wp_timezone() );

			return wp_date(
				get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
				$value->getTimestamp(),
				wp_timezone()
			);
		} catch ( Exception $exception ) {
			return sprintf(
				/* translators: %d: booking ID. */
				__( 'Booking #%d', 'tutorhelper-pro' ),
				absint( $booking->id )
			);
		}
	}
}
