<?php
/**
 * Tutor-controlled account-credit allocations for existing lessons.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies a student's existing account credit to unpaid Finance lessons.
 *
 * Credit remains an immutable ledger asset: every allocation creates a
 * credit_used record and never creates an external payment record.
 */
final class TutorHelper_Pro_Finance_Credit_Allocations {

	const PREVIEW_ACTION = 'tutorhelper_pro_preview_finance_credit_allocation';
	const APPLY_ACTION   = 'tutorhelper_pro_apply_finance_credit_allocation';
	const NONCE_ACTION   = 'tutorhelper_pro_finance_credit_allocation';
	const SCRIPT_HANDLE  = 'tutorhelper-pro-finance-credit-allocation';
	const STYLE_HANDLE   = 'tutorhelper-pro-finance-credit-allocation';

	/**
	 * Register Finance hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'wp_ajax_' . self::PREVIEW_ACTION,
			array( __CLASS__, 'handle_preview' )
		);
		add_action(
			'wp_ajax_' . self::APPLY_ACTION,
			array( __CLASS__, 'handle_apply' )
		);
		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' ),
			45
		);
	}

	/**
	 * Load the Finance allocation controls on the All Data view only.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] )
			? sanitize_key( wp_unslash( $_GET['tab'] ) )
			: '';
		$view = isset( $_GET['finance_view'] ) && ! is_array( $_GET['finance_view'] )
			? sanitize_key( wp_unslash( $_GET['finance_view'] ) )
			: '';

		if (
			TutorHelper_Pro_Finance_Admin::TAB_KEY !== $tab
			|| TutorHelper_Pro_Finance_Admin::VIEW_ALL !== $view
		) {
			return;
		}

		$script_path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-finance-credit-allocation.js';
		$style_path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-finance-credit-allocation.css';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-finance-credit-allocation.js',
			array( 'tutorhelper-pro-finance-payments' ),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_PRO_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperProFinanceCreditAllocation',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( self::NONCE_ACTION ),
				'previewAction' => self::PREVIEW_ACTION,
				'applyAction' => self::APPLY_ACTION,
				'labels' => array(
					'applyCredit' => __( 'Apply account credit', 'tutorhelper-pro' ),
					'applySelected' => __( 'Apply account credit to selected lessons', 'tutorhelper-pro' ),
					'heading' => __( 'Apply account credit', 'tutorhelper-pro' ),
					'studentCredit' => __( 'Available account credit', 'tutorhelper-pro' ),
					'remainingCredit' => __( 'Credit remaining after allocation', 'tutorhelper-pro' ),
					'originalPrice' => __( 'Original lesson price', 'tutorhelper-pro' ),
					'alreadyPaid' => __( 'Amount already paid', 'tutorhelper-pro' ),
					'outstanding' => __( 'Outstanding balance', 'tutorhelper-pro' ),
					'creditToApply' => __( 'Credit to apply', 'tutorhelper-pro' ),
					'remaining' => __( 'Remaining after allocation', 'tutorhelper-pro' ),
					'confirm' => __( 'Confirm allocation', 'tutorhelper-pro' ),
					'cancel' => __( 'Cancel', 'tutorhelper-pro' ),
					'loading' => __( 'Preparing credit allocation…', 'tutorhelper-pro' ),
					'applying' => __( 'Applying account credit…', 'tutorhelper-pro' ),
					'refreshing' => __( 'Refreshing finance data…', 'tutorhelper-pro' ),
					'failed' => __( 'The account credit could not be applied.', 'tutorhelper-pro' ),
					'sameStudent' => __( 'Select lessons for one student and currency at a time.', 'tutorhelper-pro' ),
					'noCredit' => __( 'This student has no available account credit in the lesson currency.', 'tutorhelper-pro' ),
				),
			)
		);

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-finance-credit-allocation.css',
			array( 'tutorhelper-pro-finance-payments' ),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_PRO_VERSION
		);
	}

	/**
	 * Return a server-calculated allocation preview.
	 *
	 * @return void
	 */
	public static function handle_preview() {
		self::authorize_request();

		$booking_ids = self::request_booking_ids();
		$allocations = self::request_allocations();

		$preview = self::build_preview( $booking_ids, $allocations );
		if ( is_wp_error( $preview ) ) {
			wp_send_json_error(
				array( 'message' => $preview->get_error_message() ),
				self::error_status( $preview )
			);
		}

		wp_send_json_success( $preview );
	}

	/**
	 * Atomically apply the reviewed allocations.
	 *
	 * @return void
	 */
	public static function handle_apply() {
		self::authorize_request();

		$booking_ids = self::request_booking_ids();
		$allocations = self::request_allocations();
		$operation_id = self::request_operation_id();

		if ( '' === $operation_id ) {
			wp_send_json_error(
				array( 'message' => __( 'The credit allocation reference was invalid.', 'tutorhelper-pro' ) ),
				400
			);
		}

		$preview = self::build_preview( $booking_ids, $allocations );
		if ( is_wp_error( $preview ) ) {
			wp_send_json_error(
				array( 'message' => $preview->get_error_message() ),
				self::error_status( $preview )
			);
		}

		$positive_allocations = array_filter(
			$preview['allocations'],
			static function ( $allocation ) {
				return 0 < absint( $allocation['amountMinorUnits'] );
			}
		);

		if ( empty( $positive_allocations ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Enter an account-credit amount greater than zero.', 'tutorhelper-pro' ) ),
				400
			);
		}

		$student_id = absint( $preview['studentUserId'] );
		$currency = $preview['currency'];
		$lock_name = self::credit_lock_name( $student_id, $currency );

		if ( ! self::acquire_lock( $lock_name ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Another credit allocation is being processed for this student. Please refresh Finance and try again.', 'tutorhelper-pro' ) ),
				409
			);
		}

		$transaction_started = false;

		try {
			global $wpdb;
			$started = $wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared -- A credit allocation must make its ledger and booking updates atomic.
			if ( false === $started ) {
				throw new Exception( __( 'The account-credit allocation could not start safely. Please try again.', 'tutorhelper-pro' ) );
			}
			$transaction_started = true;

			/*
			 * Check inside the serialised transaction. A retry which waited for
			 * an earlier request must return its original outcome, never consume
			 * the student's credit for a second time.
			 */
			$idempotent_result = self::get_existing_operation(
				$operation_id,
				array_keys( $positive_allocations )
			);

			if ( is_wp_error( $idempotent_result ) ) {
				throw new Exception( $idempotent_result->get_error_message() );
			}

			if ( ! empty( $idempotent_result ) ) {
				$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared -- Closes the read-only idempotency transaction before returning.
				$transaction_started = false;
				self::release_lock( $lock_name );
				wp_send_json_success(
					array(
						'message' => __( 'This account-credit allocation was already recorded.', 'tutorhelper-pro' ),
						'alreadyApplied' => true,
						'transactions' => $idempotent_result,
					)
				);
			}

			/*
			 * Recalculate after acquiring the advisory lock and transaction. The
			 * Finance table preview is intentionally never trusted for money.
			 */
			self::lock_student_ledger_rows( $student_id, $currency );
			$fresh_preview = self::build_preview( $booking_ids, $allocations );
			if ( is_wp_error( $fresh_preview ) ) {
				throw new Exception( $fresh_preview->get_error_message() );
			}

			$fresh_positive = array_filter(
				$fresh_preview['allocations'],
				static function ( $allocation ) {
					return 0 < absint( $allocation['amountMinorUnits'] );
				}
			);

			if ( count( $positive_allocations ) !== count( $fresh_positive ) ) {
				throw new Exception( __( 'The selected lesson balances changed. Please review the updated Finance data before applying credit.', 'tutorhelper-pro' ) );
			}

			$transactions = array();
			foreach ( $fresh_positive as $booking_id => $allocation ) {
				$booking = TutorHelper_Booking_Records::get_by_id( absint( $booking_id ) );
				if ( ! $booking ) {
					throw new Exception( __( 'One of the selected lessons no longer exists.', 'tutorhelper-pro' ) );
				}

				$amount = absint( $allocation['amountMinorUnits'] );
				$reference = self::operation_reference( $operation_id );

				$transaction_id = TutorHelper_Pro_Payment_Ledger::record(
					array(
						'booking_id' => absint( $booking->id ),
						'student_user_id' => $student_id,
						'tutor_user_id' => absint( $booking->tutor_user_id ),
						'transaction_type' => TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
						'amount_minor_units' => $amount,
						'currency' => $currency,
						'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
						'provider_reference' => $reference,
						'description' => sprintf(
							/* translators: 1: formatted account-credit amount, 2: booking ID. */
							__( 'Account credit applied: %1$s to booking #%2$d.', 'tutorhelper-pro' ),
							TutorHelper_Currency::format_minor_units( $amount, $currency ),
							absint( $booking->id )
						),
						'created_by_user_id' => get_current_user_id(),
					)
				);

				if ( is_wp_error( $transaction_id ) ) {
					throw new Exception( $transaction_id->get_error_message() );
				}

				$after = self::get_booking_financials( $booking );
				if ( is_wp_error( $after ) ) {
					throw new Exception( $after->get_error_message() );
				}

				if ( 0 === $after['outstandingMinorUnits'] ) {
					$update = self::mark_booking_paid( $booking, $reference, $amount );
					if ( is_wp_error( $update ) ) {
						throw new Exception( $update->get_error_message() );
					}
				}

				$transactions[] = array(
					'bookingId' => absint( $booking->id ),
					'transactionId' => absint( $transaction_id ),
					'amountMinorUnits' => $amount,
					'outstandingMinorUnits' => $after['outstandingMinorUnits'],
				);
			}

			$committed = $wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared -- Completes the transaction opened for this account-credit allocation.
			if ( false === $committed ) {
				throw new Exception( __( 'The account-credit allocation could not be saved safely. Please try again.', 'tutorhelper-pro' ) );
			}
			$transaction_started = false;

			/*
			 * Existing payment-request links must become stale before they can
			 * collect a pre-credit balance. This intentionally uses a dedicated
			 * action: account credit is not a new external payment and must not
			 * trigger the paid-booking email workflow.
			 */
			foreach ( $transactions as $transaction ) {
				do_action(
					'tutorhelper_pro_finance_credit_allocation_recorded',
					absint( $transaction['bookingId'] )
				);
			}

			TutorHelper_Logger::success(
				'Finance account credit allocation recorded.',
				array(
					'student_user_id' => $student_id,
					'currency' => $currency,
					'operation_id' => $operation_id,
					'booking_count' => count( $transactions ),
					'created_by_user_id' => get_current_user_id(),
				)
			);

			self::release_lock( $lock_name );
			wp_send_json_success(
				array(
					'message' => __( 'Account credit has been applied to the selected lessons.', 'tutorhelper-pro' ),
					'transactions' => $transactions,
					'remainingCreditMinorUnits' => TutorHelper_Pro_Student_Credits::get_balance( $student_id, $currency ),
				)
			);
		} catch ( Exception $exception ) {
			if ( $transaction_started ) {
				global $wpdb;
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared -- Rolls back the current credit allocation on any failure.
			}

			TutorHelper_Logger::error(
				'Finance account credit allocation failed.',
				array(
					'student_user_id' => $student_id,
					'currency' => $currency,
					'operation_id' => $operation_id,
					'error' => $exception->getMessage(),
				)
			);

			self::release_lock( $lock_name );
			wp_send_json_error(
				array( 'message' => $exception->getMessage() ),
				409
			);
		} finally {
			self::release_lock( $lock_name );
		}
	}

	/**
	 * Validate the authenticated tutor request.
	 *
	 * @return void
	 */
	private static function authorize_request() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to apply account credit.', 'tutorhelper-pro' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
	}

	/**
	 * Read booking identifiers from a validated request array.
	 *
	 * @return array
	 */
	private static function request_booking_ids() {
		$raw_ids = isset( $_POST['booking_ids'] ) && is_array( $_POST['booking_ids'] )
			? wp_unslash( $_POST['booking_ids'] )
			: array();

		$booking_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'absint', $raw_ids )
				)
			)
		);

		if ( empty( $booking_ids ) || 100 < count( $booking_ids ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Select between one and 100 lessons.', 'tutorhelper-pro' ) ),
				400
			);
		}

		return $booking_ids;
	}

	/**
	 * Read submitted allocation values in integer minor units.
	 *
	 * @return array
	 */
	private static function request_allocations() {
		$raw = isset( $_POST['allocations'] ) && is_array( $_POST['allocations'] )
			? wp_unslash( $_POST['allocations'] )
			: array();

		$allocations = array();
		foreach ( $raw as $booking_id => $amount ) {
			if ( is_array( $amount ) || ! is_scalar( $amount ) ) {
				continue;
			}

			$booking_id = absint( $booking_id );
			$amount = filter_var( $amount, FILTER_VALIDATE_INT );

			if ( ! $booking_id || false === $amount || 0 > $amount ) {
				continue;
			}

			$allocations[ $booking_id ] = (int) $amount;
		}

		return $allocations;
	}

	/**
	 * Return the client-generated idempotency identifier.
	 *
	 * @return string
	 */
	private static function request_operation_id() {
		$operation_id = isset( $_POST['operation_id'] ) && ! is_array( $_POST['operation_id'] )
			? sanitize_key( wp_unslash( $_POST['operation_id'] ) )
			: '';

		return 1 === preg_match( '/^[a-z0-9-]{16,64}$/', $operation_id )
			? $operation_id
			: '';
	}

	/**
	 * Calculate a safe allocation preview from the current ledger.
	 *
	 * @param array $booking_ids Requested booking IDs.
	 * @param array $submitted_allocations Values in minor units.
	 * @return array|WP_Error
	 */
	private static function build_preview( $booking_ids, $submitted_allocations ) {
		$details = array();

		foreach ( $booking_ids as $booking_id ) {
			$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
			if ( ! $booking ) {
				return new WP_Error(
					'tutorhelper_pro_credit_booking_not_found',
					__( 'One of the selected lessons could not be found.', 'tutorhelper-pro' )
				);
			}

			$financials = self::get_booking_financials( $booking );
			if ( is_wp_error( $financials ) ) {
				return $financials;
			}

			if ( ! self::booking_is_eligible( $booking, $financials ) ) {
				return new WP_Error(
					'tutorhelper_pro_credit_booking_ineligible',
					__( 'Account credit can only be applied to active lessons with an outstanding balance.', 'tutorhelper-pro' )
				);
			}

			$details[] = array(
				'booking' => $booking,
				'financials' => $financials,
			);
		}

		usort(
			$details,
			static function ( $first, $second ) {
				return strcmp(
					(string) $first['booking']->booking_start,
					(string) $second['booking']->booking_start
				);
			}
		);

		$student_id = absint( $details[0]['booking']->student_user_id );
		$currency = $details[0]['financials']['currency'];

		foreach ( $details as $detail ) {
			if (
				$student_id !== absint( $detail['booking']->student_user_id )
				|| $currency !== $detail['financials']['currency']
			) {
				return new WP_Error(
					'tutorhelper_pro_credit_mixed_selection',
					__( 'Account credit can only be allocated across lessons for one student and currency at a time.', 'tutorhelper-pro' )
				);
			}
		}

		$available = TutorHelper_Pro_Student_Credits::get_balance(
			$student_id,
			$currency
		);
		$remaining_credit = $available;
		$allocations = array();

		foreach ( $details as $detail ) {
			$booking_id = absint( $detail['booking']->id );
			$outstanding = $detail['financials']['outstandingMinorUnits'];
			$requested = array_key_exists( $booking_id, $submitted_allocations )
				? (int) $submitted_allocations[ $booking_id ]
				: min( $remaining_credit, $outstanding );

			if ( 0 > $requested || $requested > $outstanding ) {
				return new WP_Error(
					'tutorhelper_pro_credit_invalid_amount',
					__( 'A credit allocation cannot exceed the lesson outstanding balance.', 'tutorhelper-pro' )
				);
			}

			if ( $requested > $remaining_credit ) {
				return new WP_Error(
					'tutorhelper_pro_credit_insufficient_balance',
					__( 'The requested allocations exceed the student’s available account credit.', 'tutorhelper-pro' )
				);
			}

			$remaining_credit -= $requested;
			$allocations[ $booking_id ] = array(
				'bookingId' => $booking_id,
				'lessonLabel' => self::lesson_label( $detail['booking'] ),
				'originalPriceMinorUnits' => $detail['financials']['priceMinorUnits'],
				'settledMinorUnits' => $detail['financials']['settledMinorUnits'],
				'outstandingMinorUnits' => $outstanding,
				'amountMinorUnits' => $requested,
				'remainingOutstandingMinorUnits' => $outstanding - $requested,
			);
		}

		return array(
			'studentUserId' => $student_id,
			'studentName' => self::student_name( $student_id ),
			'currency' => $currency,
			'availableCreditMinorUnits' => $available,
			'remainingCreditMinorUnits' => $remaining_credit,
			'allocations' => $allocations,
		);
	}

	/**
	 * Return ledger-derived values for one booking.
	 *
	 * @param object $booking Booking record.
	 * @return array|WP_Error
	 */
	private static function get_booking_financials( $booking ) {
		global $wpdb;

		$booking_id = isset( $booking->id ) ? absint( $booking->id ) : 0;
		$price = isset( $booking->price_minor_units )
			? absint( $booking->price_minor_units )
			: 0;
		$currency = ! empty( $booking->currency )
			? strtoupper( sanitize_text_field( $booking->currency ) )
			: TutorHelper_Currency::get_currency();

		if ( ! $booking_id || ! $currency ) {
			return new WP_Error(
				'tutorhelper_pro_credit_invalid_booking',
				__( 'The lesson does not contain valid Finance details.', 'tutorhelper-pro' )
			);
		}

		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$settled = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- An allocation must use the current immutable lesson ledger.
			$wpdb->prepare(
				'SELECT COALESCE(SUM(amount_minor_units), 0)
				FROM %i
				WHERE booking_id = %d
				AND transaction_type IN (%s, %s, %s)',
				$table,
				$booking_id,
				TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
				TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED
			)
		);

		return array(
			'priceMinorUnits' => $price,
			'settledMinorUnits' => max( 0, $settled ),
			'outstandingMinorUnits' => max( 0, $price - $settled ),
			'currency' => $currency,
		);
	}

	/**
	 * Keep cancellations and refunds outside the allocation route.
	 *
	 * @param object $booking Booking record.
	 * @param array  $financials Ledger financials.
	 * @return bool
	 */
	private static function booking_is_eligible( $booking, $financials ) {
		$booking_status = isset( $booking->status )
			? sanitize_key( $booking->status )
			: '';
		$payment_status = isset( $booking->payment_status )
			? sanitize_key( $booking->payment_status )
			: '';

		return (
			0 < absint( $financials['outstandingMinorUnits'] )
			&& TutorHelper_Booking_Records::STATUS_CANCELLED !== $booking_status
			&& 'refunded' !== $payment_status
		);
	}

	/**
	 * Change an active booking to paid only when its ledger has no balance.
	 *
	 * @param object $booking Booking record.
	 * @param string $reference Idempotency reference.
	 * @param int    $amount Latest allocation amount.
	 * @return true|WP_Error
	 */
	private static function mark_booking_paid( $booking, $reference, $amount ) {
		$previous_payment_status = isset( $booking->payment_status )
			? sanitize_key( $booking->payment_status )
			: TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING;
		$previous_booking_status = isset( $booking->status )
			? sanitize_key( $booking->status )
			: '';

		$new_booking_status = TutorHelper_Booking_Records::STATUS_UNCONFIRMED === $previous_booking_status
			? TutorHelper_Booking_Records::STATUS_CONFIRMED
			: $previous_booking_status;

		$updated = TutorHelper_Booking_Records::update_payment_details(
			absint( $booking->id ),
			array(
				'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
				'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
				'payment_provider' => '',
				'payment_reference' => $reference,
				'booking_status' => $new_booking_status,
			),
			$previous_payment_status
		);

		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		$history = TutorHelper_Pro_Payment_History::record(
			array(
				'booking_id' => absint( $booking->id ),
				'student_user_id' => absint( $booking->student_user_id ),
				'previous_payment_status' => $previous_payment_status,
				'new_payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
				'previous_booking_status' => $previous_booking_status,
				'new_booking_status' => $new_booking_status,
				'amount_minor_units' => absint( $amount ),
				'currency' => strtoupper( sanitize_text_field( $booking->currency ) ),
				'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
				'payment_provider' => '',
				'provider_reference' => $reference,
				'change_source' => TutorHelper_Pro_Payment_History::SOURCE_ADMIN,
				'changed_by_user_id' => get_current_user_id(),
				'notes' => __( 'Account credit allocation completed the lesson balance.', 'tutorhelper-pro' ),
			)
		);

		if ( is_wp_error( $history ) ) {
			TutorHelper_Logger::warning(
				'Account credit allocation completed but payment history could not be written.',
				array(
					'booking_id' => absint( $booking->id ),
					'error' => $history->get_error_message(),
				)
			);
		}

		return true;
	}

	/**
	 * Look for a prior completed or partial operation before writing again.
	 *
	 * @param string $operation_id Client idempotency ID.
	 * @param array  $booking_ids Booking IDs with a positive allocation.
	 * @return array|WP_Error
	 */
	private static function get_existing_operation( $operation_id, $booking_ids ) {
		global $wpdb;

		$booking_ids = array_values( array_filter( array_map( 'absint', $booking_ids ) ) );
		if ( empty( $booking_ids ) ) {
			return array();
		}

		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$placeholders = implode( ',', array_fill( 0, count( $booking_ids ), '%d' ) );
		$query = $wpdb->prepare(
			"SELECT booking_id, id, amount_minor_units
			FROM %i
			WHERE booking_id IN ({$placeholders})
			AND transaction_type = %s
			AND provider_reference = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- The interpolated fragment contains generated integer placeholders only.
			array_merge(
				array(
					$table,
				),
				$booking_ids,
				array(
					TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
					self::operation_reference( $operation_id ),
				)
			)
		);

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Idempotency checks require current immutable ledger state.
			$query,
			ARRAY_A
		);

		if ( empty( $rows ) ) {
			return array();
		}

		if ( count( $rows ) !== count( $booking_ids ) ) {
			return new WP_Error(
				'tutorhelper_pro_credit_operation_partial',
				__( 'A previous allocation request completed only partly. Refresh Finance before trying another allocation.', 'tutorhelper-pro' )
			);
		}

		return $rows;
	}

	/**
	 * Serialise concurrent allocations for a student and currency.
	 *
	 * @param int    $student_id Student user ID.
	 * @param string $currency Currency code.
	 * @return string
	 */
	private static function credit_lock_name( $student_id, $currency ) {
		return 'th_credit_' . absint( $student_id ) . '_' . sanitize_key( $currency );
	}

	/**
	 * Acquire the short-lived MySQL advisory lock.
	 *
	 * @param string $lock_name Lock name.
	 * @return bool
	 */
	private static function acquire_lock( $lock_name ) {
		global $wpdb;

		return 1 === (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Prevents concurrent account-credit consumption for the same student and currency.
			$wpdb->prepare( 'SELECT GET_LOCK( %s, 10 )', $lock_name )
		);
	}

	/**
	 * Release a previously acquired MySQL advisory lock.
	 *
	 * @param string $lock_name Lock name.
	 * @return void
	 */
	private static function release_lock( $lock_name ) {
		global $wpdb;

		$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Releases the request-scoped allocation lock.
			$wpdb->prepare( 'SELECT RELEASE_LOCK( %s )', $lock_name )
		);
	}

	/**
	 * Lock existing ledger rows while recalculating the current balance.
	 *
	 * @param int    $student_id Student user ID.
	 * @param string $currency Currency code.
	 * @return void
	 */
	private static function lock_student_ledger_rows( $student_id, $currency ) {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Ledger rows are locked only during the atomic allocation transaction.
			$wpdb->prepare(
				'SELECT id
				FROM %i
				WHERE student_user_id = %d
				AND currency = %s
				FOR UPDATE',
				$table,
				absint( $student_id ),
				$currency
			)
		);
	}

	/**
	 * Return the stable ledger reference for an allocation operation.
	 *
	 * @param string $operation_id Client idempotency ID.
	 * @return string
	 */
	private static function operation_reference( $operation_id ) {
		return 'credit_allocation:' . $operation_id;
	}

	/**
	 * Return a readable lesson label.
	 *
	 * @param object $booking Booking record.
	 * @return string
	 */
	private static function lesson_label( $booking ) {
		$start = ! empty( $booking->booking_start )
			? strtotime( $booking->booking_start . ' UTC' )
			: false;
		$date = $start
			? wp_date( get_option( 'date_format' ), $start, wp_timezone() )
			: __( 'Undated lesson', 'tutorhelper-pro' );

		$type = TutorHelper_Booking_Types::get_by_id(
			isset( $booking->booking_type_id )
				? absint( $booking->booking_type_id )
				: 0
		);
		$type_label = $type && ! empty( $type->title )
			? sanitize_text_field( $type->title )
			: __( 'Lesson', 'tutorhelper-pro' );

		return sprintf(
			/* translators: 1: lesson date, 2: booking type, 3: booking ID. */
			__( '%1$s — %2$s #%3$d', 'tutorhelper-pro' ),
			$date,
			$type_label,
			absint( $booking->id )
		);
	}

	/**
	 * Return a student's safe display name.
	 *
	 * @param int $student_id Student ID.
	 * @return string
	 */
	private static function student_name( $student_id ) {
		$student = get_userdata( absint( $student_id ) );
		return $student instanceof WP_User
			? $student->display_name
			: __( 'Student', 'tutorhelper-pro' );
	}

	/**
	 * Map validation errors to a useful HTTP status.
	 *
	 * @param WP_Error $error Validation error.
	 * @return int
	 */
	private static function error_status( $error ) {
		$code = $error->get_error_code();

		return in_array(
			$code,
			array(
				'tutorhelper_pro_credit_booking_not_found',
			),
			true
		)
			? 404
			: 409;
	}
}
