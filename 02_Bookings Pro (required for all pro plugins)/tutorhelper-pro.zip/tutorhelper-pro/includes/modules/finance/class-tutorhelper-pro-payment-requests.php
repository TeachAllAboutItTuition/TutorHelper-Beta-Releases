<?php
/**
 * Tutor-created payment requests from the Finance report.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Builds one account statement and optional combined Stripe Checkout. */
final class TutorHelper_Pro_Payment_Requests {

	const TEMPLATE_KEY = 'finance_payment_request';
	const COMPOSER_TEMPLATE_KEY = 'finance_payment_request_composed';
	const CONFIRMATION_TEMPLATE_KEY = 'finance_payment_received';
	const PREPARE_ACTION = 'tutorhelper_pro_prepare_payment_request';
	const PREPARE_AJAX_ACTION = 'tutorhelper_pro_prepare_payment_request_ajax';
	const PREVIEW_AJAX_ACTION = 'tutorhelper_pro_preview_payment_request_email';
	const PREVIEW_NONCE_ACTION = 'tutorhelper_pro_preview_payment_request_email';
	const SEND_ACTION = 'tutorhelper_pro_send_payment_request';
	const TOKEN_PREFIX = 'tutorhelper_pro_payment_request_';
	const PUBLIC_REQUEST_ARG = 'thpr';
	const PUBLIC_TOKEN_ARG = 'thpk';
	const LEGACY_PUBLIC_REQUEST_ARG = 'tutorhelper_payment_request';
	const LEGACY_PUBLIC_TOKEN_ARG = 'tutorhelper_payment_token';

	/** Register the Finance workflow. */
	public static function init() {
		self::register_template();
		self::handle_payment_link();
		add_action( 'tutorhelper_pro_finance_table_actions', array( __CLASS__, 'render_finance_action' ) );
		add_action( 'admin_post_' . self::PREPARE_ACTION, array( __CLASS__, 'handle_prepare' ) );
		add_action( 'wp_ajax_' . self::PREPARE_AJAX_ACTION, array( __CLASS__, 'handle_prepare_ajax' ) );
		add_action( 'wp_ajax_' . self::PREVIEW_AJAX_ACTION, array( __CLASS__, 'handle_email_preview_ajax' ) );
		add_action( 'admin_post_' . self::SEND_ACTION, array( __CLASS__, 'handle_send' ) );
		add_filter( 'tutorhelper_pro_stripe_webhook_extension_result', array( __CLASS__, 'handle_stripe_webhook' ), 20, 3 );
		add_action( 'tutorhelper_pro_finance_adjustment_recorded', array( __CLASS__, 'invalidate_for_booking' ), 30, 1 );
		add_action( 'tutorhelper_pro_finance_credit_allocation_recorded', array( __CLASS__, 'invalidate_for_booking' ), 30, 1 );
		add_action( 'tutorhelper_pro_booking_payment_received', array( __CLASS__, 'invalidate_for_booking' ), 30, 1 );
	}

	/** Add the selection submit button and, when prepared, its options panel. */
	public static function render_finance_action( $page_bookings ) {
		unset( $page_bookings );
		?><div data-payment-request-region><?php
		$error = isset( $_GET['payment_request_error'] ) && ! is_array( $_GET['payment_request_error'] )
			? sanitize_key( wp_unslash( $_GET['payment_request_error'] ) )
			: ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only result code.
		$sent = isset( $_GET['payment_request_sent'] ) ? absint( $_GET['payment_request_sent'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only result ID.
		if ( $error ) {
			self::render_notice( self::error_message( $error ), 'error' );
		} elseif ( $sent ) {
			self::render_notice( __( 'The payment request was sent and its exact email copy was saved in Sent Emails.', 'tutorhelper-pro' ), 'success' );
		}
		?>
		<form id="tutorhelper-pro-payment-request-selection" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-pro-payment-request__selection">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::PREPARE_ACTION ); ?>" />
			<?php wp_nonce_field( self::PREPARE_ACTION ); ?>
			<button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary"><?php esc_html_e( 'Send payment request for selected lessons', 'tutorhelper-pro' ); ?></button>
			<p class="description"><?php esc_html_e( 'Select one or more lessons for the same student. Every selected lesson must have a payment due date.', 'tutorhelper-pro' ); ?></p>
		</form>
		<?php

		$token = isset( $_GET['payment_request_token'] ) && ! is_array( $_GET['payment_request_token'] )
			? sanitize_key( wp_unslash( $_GET['payment_request_token'] ) )
			: ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Opaque user-bound transient token.
		$data = $token ? get_transient( self::TOKEN_PREFIX . get_current_user_id() . '_' . $token ) : false;
		if ( ! is_array( $data ) || empty( $data['booking_ids'] ) ) {
			?></div><?php
			return;
		}
		$selection = self::validate_selection( $data['booking_ids'] );
		if ( is_wp_error( $selection ) ) {
			self::render_notice( $selection->get_error_message(), 'error' );
			?></div><?php
			return;
		}
		$template = TutorHelper_Email_Templates::get( self::TEMPLATE_KEY );
		$default_subject = is_array( $template ) ? sanitize_text_field( $template['subject'] ) : '';
		$default_body = is_array( $template ) ? wp_kses_post( $template['body'] ) : '';
		?>
		<section class="tutorhelper-main-section tutorhelper-pro-payment-request">
			<div class="tutorhelper-main-section__header">
				<h3><?php esc_html_e( 'Prepare payment request', 'tutorhelper-pro' ); ?></h3>
				<p><?php echo esc_html( sprintf( __( '%1$d lessons selected for %2$s — %3$s outstanding.', 'tutorhelper-pro' ), count( $selection['items'] ), $selection['student']->display_name, self::money( $selection['total'], $selection['currency'] ) ) ); ?></p>
			</div>
			<div class="tutorhelper-main-section__body">
				<form
					method="post"
					action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					class="tutorhelper-pro-payment-request__form"
				>
					<input type="hidden" name="action" value="<?php echo esc_attr( self::SEND_ACTION ); ?>" />
					<input type="hidden" name="payment_request_token" value="<?php echo esc_attr( $token ); ?>" />
					<?php wp_nonce_field( self::SEND_ACTION . '_' . $token ); ?>

					<div class="tutorhelper-pro-payment-request__options">
						<fieldset class="tutorhelper-pro-payment-request__fieldset">
							<legend><?php esc_html_e( 'Payment methods to include', 'tutorhelper-pro' ); ?></legend>

							<?php if ( TutorHelper_Pro_Payment_Settings::stripe_is_configured() ) : ?>
								<label class="tutorhelper-pro-payment-request__choice">
									<input type="checkbox" name="payment_methods[]" value="stripe" checked />
									<span><?php esc_html_e( 'Stripe card payment', 'tutorhelper-pro' ); ?></span>
								</label>
							<?php endif; ?>

							<?php if ( TutorHelper_Pro_Bank_Details::is_configured() ) : ?>
								<label class="tutorhelper-pro-payment-request__choice">
									<input type="checkbox" name="payment_methods[]" value="bank_transfer" />
									<span><?php esc_html_e( 'Bank transfer', 'tutorhelper-pro' ); ?></span>
								</label>
							<?php endif; ?>

							<label class="tutorhelper-pro-payment-request__choice">
								<input type="checkbox" name="payment_methods[]" value="contact_tutor" />
								<span><?php esc_html_e( 'Contact the tutor to arrange payment', 'tutorhelper-pro' ); ?></span>
							</label>
						</fieldset>

						<fieldset class="tutorhelper-pro-payment-request__fieldset">
							<legend><?php esc_html_e( 'Send to', 'tutorhelper-pro' ); ?></legend>

							<label class="tutorhelper-pro-payment-request__choice">
								<input type="checkbox" name="recipients[]" value="student" checked />
								<span><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></span>
							</label>

							<label class="tutorhelper-pro-payment-request__choice">
								<input type="checkbox" name="recipients[]" value="parent" />
								<span><?php esc_html_e( 'Linked parent', 'tutorhelper-pro' ); ?></span>
							</label>

							<label class="tutorhelper-pro-payment-request__choice">
								<input type="checkbox" name="recipients[]" value="tutor" />
								<span><?php esc_html_e( 'Tutor copy', 'tutorhelper-pro' ); ?></span>
							</label>
						</fieldset>
					</div>

					<div class="tutorhelper-pro-payment-request__submit">
						<button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary">
							<?php esc_html_e( 'Preview payment request email', 'tutorhelper-pro' ); ?>
						</button>
					</div>

					<div class="tutorhelper-admin-modal tutorhelper-pro-payment-request-email__modal" data-payment-request-email-modal hidden>
						<div class="tutorhelper-admin-modal__backdrop" data-payment-request-email-close></div>
						<div class="tutorhelper-admin-modal__dialog tutorhelper-pro-payment-request-email__dialog" role="dialog" aria-modal="true" aria-labelledby="tutorhelper-payment-request-email-title">
							<header class="tutorhelper-admin-modal__header">
								<div>
									<h3 id="tutorhelper-payment-request-email-title"><?php esc_html_e( 'Preview payment request email', 'tutorhelper-pro' ); ?></h3>
									<p><?php echo esc_html( $selection['student']->display_name ); ?></p>
								</div>
								<button type="button" class="tutorhelper-admin-modal__close" data-payment-request-email-close aria-label="<?php esc_attr_e( 'Close', 'tutorhelper-pro' ); ?>">&times;</button>
							</header>

							<div class="tutorhelper-admin-modal__body tutorhelper-pro-payment-request-email__body">
								<div class="tutorhelper-pro-payment-request-email__compose">
									<label><span><?php esc_html_e( 'Subject', 'tutorhelper-pro' ); ?></span><input type="text" class="widefat" name="email_subject" maxlength="200" value="<?php echo esc_attr( $default_subject ); ?>" data-payment-request-email-subject /></label>
									<label><span><?php esc_html_e( 'Personal message', 'tutorhelper-pro' ); ?></span><textarea name="personal_message" rows="5" data-payment-request-email-personal-message placeholder="<?php esc_attr_e( 'Optional message shown before the payment request details.', 'tutorhelper-pro' ); ?>"></textarea></label>
									<label><span><?php esc_html_e( 'Email body', 'tutorhelper-pro' ); ?></span><textarea name="email_body" rows="14" data-payment-request-email-body><?php echo esc_textarea( $default_body ); ?></textarea></label>
									<details class="tutorhelper-pro-payment-request-email__placeholders">
										<summary><?php esc_html_e( 'Available personalisation', 'tutorhelper-pro' ); ?></summary>
										<p><?php esc_html_e( 'Keep these placeholders where their live values should appear:', 'tutorhelper-pro' ); ?></p>
										<code>{student_name}</code> <code>{statement}</code> <code>{total_due}</code> <code>{payment_methods}</code> <code>{tutor_name}</code> <code>{site_name}</code>
									</details>
								</div>
								<section class="tutorhelper-pro-payment-request-email__preview" aria-labelledby="tutorhelper-payment-request-preview-title">
									<div class="tutorhelper-pro-payment-request-email__preview-heading"><h4 id="tutorhelper-payment-request-preview-title"><?php esc_html_e( 'Preview', 'tutorhelper-pro' ); ?></h4><button type="button" class="button" data-payment-request-email-refresh><?php esc_html_e( 'Refresh preview', 'tutorhelper-pro' ); ?></button></div>
									<iframe title="<?php esc_attr_e( 'Branded payment request email preview', 'tutorhelper-pro' ); ?>" sandbox="" data-payment-request-email-preview-frame></iframe>
								</section>
							</div>
							<div class="tutorhelper-pro-payment-request-email__status" role="status" aria-live="polite" data-payment-request-email-status></div>
							<footer class="tutorhelper-admin-modal__footer">
								<button type="button" class="button tutorhelper-admin-button" data-payment-request-email-close><?php esc_html_e( 'Cancel', 'tutorhelper-pro' ); ?></button>
								<button type="button" class="button tutorhelper-admin-button tutorhelper-admin-button--primary" data-payment-request-email-send><?php esc_html_e( 'Create and send payment request', 'tutorhelper-pro' ); ?></button>
							</footer>
						</div>
					</div>
				</form>
			</div>
		</section>
		</div>
		<?php
	}

	/** Prepare the payment-request options without reloading the Finance page. */
	public static function handle_prepare_ajax() {
		self::require_tutor();
		check_ajax_referer( self::PREPARE_AJAX_ACTION, 'nonce' );
		$ids = isset( $_POST['booking_ids'] ) && is_array( $_POST['booking_ids'] )
			? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['booking_ids'] ) ) ) ) )
			: array();
		$selection = self::validate_selection( $ids );
		if ( is_wp_error( $selection ) ) {
			wp_send_json_error( array( 'message' => $selection->get_error_message() ), 400 );
		}
		$token = wp_generate_password( 20, false, false );
		set_transient( self::TOKEN_PREFIX . get_current_user_id() . '_' . $token, array( 'booking_ids' => $ids ), 30 * MINUTE_IN_SECONDS );
		$_GET['payment_request_token'] = $token;
		ob_start();
		self::render_finance_action( array() );
		$html = ob_get_clean();
		wp_send_json_success( array( 'html' => $html ) );
	}

	/** Render the exact branded email before a payment request is persisted. */
	public static function handle_email_preview_ajax() {
		self::require_tutor();
		check_ajax_referer( self::PREVIEW_NONCE_ACTION, 'nonce' );
		$token = isset( $_POST['payment_request_token'] ) && ! is_array( $_POST['payment_request_token'] )
			? sanitize_key( wp_unslash( $_POST['payment_request_token'] ) )
			: '';
		$data = get_transient( self::TOKEN_PREFIX . get_current_user_id() . '_' . $token );
		$selection = is_array( $data )
			? self::validate_selection( $data['booking_ids'] ?? array() )
			: new WP_Error( 'selection_expired', __( 'The payment-request selection expired. Select the lessons again.', 'tutorhelper-pro' ) );
		if ( is_wp_error( $selection ) ) {
			wp_send_json_error( array( 'message' => $selection->get_error_message() ), 400 );
		}
		$methods = self::posted_methods();
		$recipient_types = self::posted_recipient_types();
		$content = self::posted_email_content();
		if ( is_wp_error( $content ) ) {
			wp_send_json_error( array( 'message' => $content->get_error_message() ), 400 );
		}
		if ( empty( $methods ) || empty( $recipient_types ) ) {
			wp_send_json_error( array( 'message' => self::error_message( 'methods_or_recipients_missing' ) ), 400 );
		}
		$rendered = self::render_composed_email( $selection, $methods, '#', $content );
		if ( is_wp_error( $rendered ) ) {
			wp_send_json_error( array( 'message' => $rendered->get_error_message() ), 400 );
		}
		wp_send_json_success( array( 'html' => $rendered['html'] ) );
	}

	/** Validate selected rows and open the delivery-options panel. */
	public static function handle_prepare() {
		self::require_tutor();
		check_admin_referer( self::PREPARE_ACTION );
		$ids = isset( $_POST['booking_ids'] ) && is_array( $_POST['booking_ids'] )
			? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['booking_ids'] ) ) ) ) )
			: array();
		$selection = self::validate_selection( $ids );
		if ( is_wp_error( $selection ) ) {
			self::redirect_finance( array( 'payment_request_error' => $selection->get_error_code() ) );
		}
		$token = wp_generate_password( 20, false, false );
		set_transient( self::TOKEN_PREFIX . get_current_user_id() . '_' . $token, array( 'booking_ids' => $ids ), 30 * MINUTE_IN_SECONDS );
		self::redirect_finance( array( 'payment_request_token' => $token ) );
	}

	/** Persist the request and send an editable email with a durable payment link. */
	public static function handle_send() {
		self::require_tutor();
		$token = isset( $_POST['payment_request_token'] ) && ! is_array( $_POST['payment_request_token'] ) ? sanitize_key( wp_unslash( $_POST['payment_request_token'] ) ) : '';
		check_admin_referer( self::SEND_ACTION . '_' . $token );
		$data = get_transient( self::TOKEN_PREFIX . get_current_user_id() . '_' . $token );
		$selection = is_array( $data ) ? self::validate_selection( $data['booking_ids'] ?? array() ) : new WP_Error( 'selection_expired', __( 'The payment-request selection expired. Select the lessons again.', 'tutorhelper-pro' ) );
		if ( is_wp_error( $selection ) ) {
			self::redirect_finance( array( 'payment_request_error' => $selection->get_error_code() ) );
		}

		$methods = self::posted_methods();
		$recipient_types = self::posted_recipient_types();
		$content = self::posted_email_content();
		if ( is_wp_error( $content ) ) {
			self::redirect_finance( array( 'payment_request_error' => $content->get_error_code() ) );
		}
		if ( empty( $methods ) || empty( $recipient_types ) ) {
			self::redirect_finance( array( 'payment_request_error' => 'methods_or_recipients_missing' ) );
		}
		if ( in_array( 'stripe', $methods, true ) && ! TutorHelper_Pro_Payment_Settings::stripe_is_configured() ) {
			self::redirect_finance( array( 'payment_request_error' => 'stripe_unavailable' ) );
		}

		global $wpdb;
		$now = current_time( 'mysql', true );
		$allocations = array();
		foreach ( $selection['items'] as $item ) {
			$allocations[] = array( 'booking_id' => absint( $item['booking']->id ), 'amount_minor_units' => absint( $item['outstanding'] ) );
		}
		$wpdb->insert(
			TutorHelper_Pro_Database::get_table_name( 'payment_requests' ),
			array(
				'student_user_id' => $selection['student']->ID,
				'tutor_user_id' => absint( $selection['items'][0]['booking']->tutor_user_id ),
				'booking_ids' => wp_json_encode( wp_list_pluck( $allocations, 'booking_id' ) ),
				'allocations' => wp_json_encode( $allocations ),
				'amount_minor_units' => $selection['total'],
				'currency' => $selection['currency'],
				'payment_methods' => wp_json_encode( $methods ),
				'recipients' => wp_json_encode( $recipient_types ),
				'status' => 'prepared',
				'created_by_user_id' => get_current_user_id(),
				'created_at' => $now,
				'updated_at' => $now,
			),
			array( '%d', '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Pro owns the persistent payment-request audit record.
		$request_id = absint( $wpdb->insert_id );
		if ( ! $request_id ) {
			self::redirect_finance( array( 'payment_request_error' => 'save_failed' ) );
		}

		$stripe_url = in_array( 'stripe', $methods, true ) ? self::payment_link_url( $request_id ) : '';
		$rendered = self::render_composed_email( $selection, $methods, $stripe_url, $content );
		if ( is_wp_error( $rendered ) ) {
			self::update_request_status( $request_id, 'failed' );
			self::redirect_finance( array( 'payment_request_error' => 'email_render_failed' ) );
		}
		$recipients = self::resolve_recipients( $recipient_types, $selection['student'], $selection['items'][0]['booking'] );
		$sent = 0;
		foreach ( $recipients as $type => $email ) {
			$result = TutorHelper_Email_Sender::send(
				self::COMPOSER_TEMPLATE_KEY,
				$email,
				$rendered['transport_placeholders'],
				array(
					'context' => array(
						'email_type'          => 'payment_request',
						'recipient_type'      => $type,
						'student_user_id'     => absint( $selection['student']->ID ),
						'related_object_type' => 'student',
						'related_object_id'   => absint( $selection['student']->ID ),
						'payment_request_id'  => $request_id,
					),
				)
			);
			if ( true === $result ) {
				++$sent;
			}
		}
		$wpdb->update( TutorHelper_Pro_Database::get_table_name( 'payment_requests' ), array( 'status' => $sent ? 'sent' : 'failed', 'sent_at' => $sent ? $now : null, 'updated_at' => $now ), array( 'id' => $request_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		delete_transient( self::TOKEN_PREFIX . get_current_user_id() . '_' . $token );
		self::redirect_finance( array( 'payment_request_sent' => $request_id ) );
	}


	/**
	 * Exchange a signed, durable email link for a fresh Stripe Checkout Session.
	 *
	 * Stripe Checkout Sessions deliberately remain short-lived. The link sent by
	 * TutorHelper stays valid until the request is paid or its balances change.
	 */
	public static function handle_payment_link() {
		$request_arg = isset( $_GET[ self::PUBLIC_REQUEST_ARG ] )
			? self::PUBLIC_REQUEST_ARG
			: ( isset( $_GET[ self::LEGACY_PUBLIC_REQUEST_ARG ] ) ? self::LEGACY_PUBLIC_REQUEST_ARG : '' );
		if ( ! $request_arg ) {
			return;
		}
		$token_arg = self::PUBLIC_REQUEST_ARG === $request_arg
			? self::PUBLIC_TOKEN_ARG
			: self::LEGACY_PUBLIC_TOKEN_ARG;

		$request_id = ! is_array( $_GET[ $request_arg ] )
			? absint( wp_unslash( $_GET[ $request_arg ] ) )
			: 0;
		$provided_token = isset( $_GET[ $token_arg ] ) && ! is_array( $_GET[ $token_arg ] )
			? sanitize_key( wp_unslash( $_GET[ $token_arg ] ) )
			: '';

		if ( ! $request_id || ! hash_equals( self::payment_link_token( $request_id ), $provided_token ) ) {
			self::payment_link_error( __( 'This payment link is invalid. Please ask your tutor for a new payment request.', 'tutorhelper-pro' ), 400 );
		}

		$request = self::get_request( $request_id );
		if ( ! $request ) {
			self::payment_link_error( __( 'This payment request could not be found. Please ask your tutor for a new link.', 'tutorhelper-pro' ), 404 );
		}

		$status = sanitize_key( $request->status );
		if ( 'paid' === $status ) {
			self::payment_link_error( __( 'Thank you — this payment has already been received.', 'tutorhelper-pro' ), 200 );
		}
		if ( in_array( $status, array( 'stale', 'failed', 'processing' ), true ) ) {
			self::payment_link_error( __( 'This payment request is no longer available. Please ask your tutor for an updated request.', 'tutorhelper-pro' ), 410 );
		}

		$methods = json_decode( $request->payment_methods, true );
		if ( ! is_array( $methods ) || ! in_array( 'stripe', $methods, true ) || ! TutorHelper_Pro_Payment_Settings::stripe_is_configured() ) {
			self::payment_link_error( __( 'Stripe is not currently available for this payment request. Please contact your tutor.', 'tutorhelper-pro' ), 503 );
		}

		$booking_ids = json_decode( $request->booking_ids, true );
		$selection = self::validate_selection( is_array( $booking_ids ) ? $booking_ids : array() );
		if (
			is_wp_error( $selection )
			|| absint( $request->amount_minor_units ) !== absint( $selection['total'] ?? 0 )
			|| strtoupper( sanitize_text_field( $request->currency ) ) !== strtoupper( sanitize_text_field( $selection['currency'] ?? '' ) )
		) {
			self::update_request_status( $request_id, 'stale' );
			self::payment_link_error( __( 'The balance for this payment request has changed. Please ask your tutor for an updated request.', 'tutorhelper-pro' ), 410 );
		}

		if ( ! empty( $request->stripe_checkout_session_id ) ) {
			TutorHelper_Pro_Stripe::expire_checkout_session( sanitize_text_field( $request->stripe_checkout_session_id ) );
		}

		$checkout = TutorHelper_Pro_Stripe::create_extension_checkout_session(
			array(
				'amount_minor_units' => $selection['total'],
				'currency' => $selection['currency'],
				'product_name' => sprintf( __( 'Lesson payment request #%d', 'tutorhelper-pro' ), $request_id ),
				'description' => sprintf( _n( '%d selected lesson', '%d selected lessons', count( $selection['items'] ), 'tutorhelper-pro' ), count( $selection['items'] ) ),
				'customer_email' => $selection['student']->user_email,
				'client_reference_id' => 'payment_request_' . $request_id,
				'success_url' => add_query_arg( 'payment_request', 'success', home_url( '/' ) ),
				'cancel_url' => add_query_arg( 'payment_request', 'cancelled', home_url( '/' ) ),
				'metadata' => array( 'tutorhelper_context' => 'payment_request', 'payment_request_id' => $request_id ),
			)
		);
		if ( is_wp_error( $checkout ) ) {
			self::update_request_status( $request_id, 'sent' );
			self::payment_link_error( __( 'Stripe could not start checkout. Please try this link again shortly or contact your tutor.', 'tutorhelper-pro' ), 503 );
		}

		global $wpdb;
		$wpdb->update(
			TutorHelper_Pro_Database::get_table_name( 'payment_requests' ),
			array(
				'stripe_checkout_session_id' => sanitize_text_field( $checkout['id'] ),
				'stripe_checkout_url' => esc_url_raw( $checkout['url'] ),
				'status' => 'ready',
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $request_id )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Stores the fresh Checkout identity for webhook verification.

		wp_redirect( esc_url_raw( $checkout['url'] ), 303, 'TutorHelper Pro' ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Stripe URL is returned by the authenticated Stripe API.
		exit;
	}

	/** Claim completed/expired Checkout events belonging to payment requests. */
	public static function handle_stripe_webhook( $result, $event, $event_type ) {
		$session = isset( $event['data']['object'] ) && is_array( $event['data']['object'] ) ? $event['data']['object'] : array();
		$metadata = isset( $session['metadata'] ) && is_array( $session['metadata'] ) ? $session['metadata'] : array();
		if ( 'payment_request' !== ( $metadata['tutorhelper_context'] ?? '' ) ) {
			return $result;
		}
		$request_id = absint( $metadata['payment_request_id'] ?? 0 );
		$request = self::get_request( $request_id );
		if ( ! $request ) {
			return new WP_Error( 'payment_request_not_found', __( 'The Stripe payment request could not be verified.', 'tutorhelper-pro' ), array( 'status' => 404 ) );
		}
		if ( sanitize_text_field( $request->stripe_checkout_session_id ) !== sanitize_text_field( $session['id'] ?? '' ) ) {
			// A newer click may already have replaced and expired this Session.
			return 'checkout.session.expired' === $event_type
				? true
				: new WP_Error( 'payment_request_not_found', __( 'The Stripe payment request could not be verified.', 'tutorhelper-pro' ), array( 'status' => 404 ) );
		}
		if ( 'checkout.session.expired' === $event_type ) {
			self::update_request_status( $request_id, 'expired' );
			return true;
		}
		if ( 'checkout.session.completed' !== $event_type ) {
			return true;
		}
		if ( 'paid' === sanitize_key( $request->status ) ) {
			return true;
		}
		if ( absint( $session['amount_total'] ?? 0 ) !== absint( $request->amount_minor_units ) || strtoupper( sanitize_text_field( $session['currency'] ?? '' ) ) !== strtoupper( sanitize_text_field( $request->currency ) ) ) {
			return new WP_Error( 'payment_request_amount_mismatch', __( 'The Stripe payment request amount did not match.', 'tutorhelper-pro' ), array( 'status' => 409 ) );
		}
		$allocations = json_decode( $request->allocations, true );
		$allocations = is_array( $allocations ) ? $allocations : array();
		$event_id = sanitize_text_field( $event['id'] ?? '' );
		$reference = sanitize_text_field( $session['payment_intent'] ?? ( $session['id'] ?? '' ) );
		$combined_payment = 1 < count( $allocations );
		$paid_bookings = array();

		self::update_request_status( $request_id, 'processing' );

		if ( $combined_payment ) {
			add_filter( 'tutorhelper_booking_send_student_confirmation', '__return_false', 999 );
			add_filter( 'tutorhelper_pro_send_paid_booking_email', '__return_false', 999 );
		}

		foreach ( $allocations as $allocation ) {
			$booking = TutorHelper_Booking_Records::get_by_id( absint( $allocation['booking_id'] ?? 0 ) );
			if ( ! $booking ) {
				self::remove_combined_email_suppression( $combined_payment );
				return new WP_Error( 'payment_request_booking_missing', __( 'A lesson in the payment request no longer exists.', 'tutorhelper-pro' ), array( 'status' => 409 ) );
			}
			$ledger = TutorHelper_Pro_Payment_Ledger::record(
				array(
					'booking_id' => $booking->id,
					'student_user_id' => $booking->student_user_id,
					'tutor_user_id' => $booking->tutor_user_id,
					'transaction_type' => TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
					'amount_minor_units' => absint( $allocation['amount_minor_units'] ?? 0 ),
					'currency' => $request->currency,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
					'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					'provider_reference' => $reference,
					'provider_event_id' => $event_id . '-' . absint( $booking->id ),
					'description' => sprintf( __( 'Stripe payment request #%d', 'tutorhelper-pro' ), $request_id ),
					'transaction_date' => ! empty( $event['created'] ) ? gmdate( 'Y-m-d H:i:s', absint( $event['created'] ) ) : current_time( 'mysql', true ),
				)
			);
			if ( is_wp_error( $ledger ) ) {
				self::remove_combined_email_suppression( $combined_payment );
				return $ledger;
			}

			$updated_booking = self::refresh_booking( $booking, $session['id'] ?? '' );
			if ( is_wp_error( $updated_booking ) ) {
				self::remove_combined_email_suppression( $combined_payment );
				return $updated_booking;
			}
			if ( $updated_booking ) {
				$paid_bookings[ absint( $booking->id ) ] = $updated_booking;
			}
		}

		self::remove_combined_email_suppression( $combined_payment );
		self::update_request_status( $request_id, 'paid', true );

		if ( $combined_payment ) {
			$email_result = self::send_combined_payment_confirmation(
				$request_id,
				$request,
				$paid_bookings,
				$allocations
			);

			if ( is_wp_error( $email_result ) && class_exists( 'TutorHelper_Logger' ) ) {
				TutorHelper_Logger::warning(
					'Combined payment confirmation email was not sent.',
					array(
						'payment_request_id' => $request_id,
						'error_code' => $email_result->get_error_code(),
					)
				);
			}
		}

		return true;
	}


	/** Restore normal per-booking email handling after a combined payment. */
	private static function remove_combined_email_suppression( $combined_payment ) {
		if ( ! $combined_payment ) {
			return;
		}

		remove_filter( 'tutorhelper_booking_send_student_confirmation', '__return_false', 999 );
		remove_filter( 'tutorhelper_pro_send_paid_booking_email', '__return_false', 999 );
	}

	/** Send one confirmation for a payment covering multiple lessons. */
	private static function send_combined_payment_confirmation( $request_id, $request, $bookings, $allocations ) {
		if ( empty( $bookings ) ) {
			return new WP_Error( 'combined_payment_bookings_missing', __( 'The paid lessons could not be prepared for email.', 'tutorhelper-pro' ) );
		}

		$first_booking = reset( $bookings );
		$student = get_user_by( 'id', absint( $request->student_user_id ) );
		$tutor = get_user_by( 'id', absint( $request->tutor_user_id ) );
		if ( ! $student instanceof WP_User || ! $tutor instanceof WP_User ) {
			return new WP_Error( 'combined_payment_recipient_missing', __( 'The payment confirmation recipient could not be found.', 'tutorhelper-pro' ) );
		}

		$amounts = array();
		foreach ( $allocations as $allocation ) {
			$amounts[ absint( $allocation['booking_id'] ?? 0 ) ] = absint( $allocation['amount_minor_units'] ?? 0 );
		}

		$statement = '<table role="presentation" width="100%" cellpadding="6" cellspacing="0" style="border-collapse:collapse"><thead><tr><th align="left">' . esc_html__( 'Lesson', 'tutorhelper-pro' ) . '</th><th align="right">' . esc_html__( 'Amount paid', 'tutorhelper-pro' ) . '</th></tr></thead><tbody>';
		foreach ( $bookings as $booking_id => $booking ) {
			$date = get_date_from_gmt( $booking->booking_start, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
			$statement .= '<tr><td style="border-top:1px solid #ddd">' . esc_html( $date ) . '</td><td align="right" style="border-top:1px solid #ddd">' . esc_html( self::money( $amounts[ $booking_id ] ?? 0, $request->currency ) ) . '</td></tr>';
		}
		$statement .= '</tbody></table>';

		$placeholders = array(
			'{student_name}' => sanitize_text_field( $student->display_name ),
			'{statement}' => $statement,
			'{total_paid}' => self::money( $request->amount_minor_units, $request->currency ),
			'{tutor_name}' => sanitize_text_field( $tutor->display_name ),
			'{site_name}' => get_bloginfo( 'name' ),
		);

		$recipient_types = json_decode( $request->recipients, true );
		$recipients = self::resolve_recipients(
			is_array( $recipient_types ) ? $recipient_types : array( 'student' ),
			$student,
			$first_booking
		);

		$sent = 0;
		$last_error = null;
		foreach ( $recipients as $type => $email ) {
			$result = TutorHelper_Email_Sender::send(
				self::CONFIRMATION_TEMPLATE_KEY,
				$email,
				$placeholders,
				array(
					'context' => array(
						'email_type' => 'combined_payment_received',
						'recipient_type' => $type,
						'student_user_id' => $student->ID,
						'related_object_type' => 'student',
						'related_object_id' => absint( $student->ID ),
						'payment_request_id' => absint( $request_id ),
					),
				)
			);
			if ( true === $result ) {
				++$sent;
			} elseif ( is_wp_error( $result ) ) {
				$last_error = $result;
			}
		}

		if ( 0 === $sent ) {
			return $last_error instanceof WP_Error
				? $last_error
				: new WP_Error( 'combined_payment_recipient_invalid', __( 'No valid payment confirmation recipient was available.', 'tutorhelper-pro' ) );
		}

		return true;
	}

	/** Expire open combined Checkouts when any selected balance changes. */
	public static function invalidate_for_booking( $booking_id ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE status IN (%s,%s,%s)',
				TutorHelper_Pro_Database::get_table_name( 'payment_requests' ),
				'ready',
				'sent',
				'expired'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Open payment links must reflect current finance state.
		foreach ( $rows as $request ) {
			$ids = json_decode( $request->booking_ids, true );
			if ( ! is_array( $ids ) || ! in_array( absint( $booking_id ), array_map( 'absint', $ids ), true ) ) {
				continue;
			}
			if ( ! empty( $request->stripe_checkout_session_id ) ) {
				TutorHelper_Pro_Stripe::expire_checkout_session( sanitize_text_field( $request->stripe_checkout_session_id ) );
			}
			self::update_request_status( $request->id, 'stale' );
		}
	}

	/** Validate selection invariants and calculate current outstanding amounts. */
	private static function validate_selection( $ids ) {
		if ( empty( $ids ) ) {
			return new WP_Error( 'no_lessons_selected', __( 'Select at least one lesson.', 'tutorhelper-pro' ) );
		}
		global $wpdb;
		$student_id = 0;
		$currency = '';
		$items = array();
		$total = 0;
		foreach ( $ids as $id ) {
			$booking = TutorHelper_Booking_Records::get_by_id( absint( $id ) );
			if ( ! $booking || TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
				return new WP_Error( 'invalid_lesson', __( 'A selected lesson is missing or cancelled.', 'tutorhelper-pro' ) );
			}
			if ( $student_id && $student_id !== absint( $booking->student_user_id ) ) {
				return new WP_Error( 'mixed_students', __( 'Select lessons for one student at a time.', 'tutorhelper-pro' ) );
			}
			$student_id = absint( $booking->student_user_id );
			$item_currency = strtoupper( sanitize_text_field( $booking->currency ) );
			if ( $currency && $currency !== $item_currency ) {
				return new WP_Error( 'mixed_currencies', __( 'Selected lessons must use the same currency.', 'tutorhelper-pro' ) );
			}
			$currency = $item_currency;
			$due = $wpdb->get_var( $wpdb->prepare( 'SELECT payment_due_date FROM %i WHERE booking_id=%d', TutorHelper_Pro_Database::get_table_name( 'booking_finance' ), $booking->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			if ( empty( $due ) ) {
				return new WP_Error( 'due_date_missing', __( 'Every selected lesson must have a payment due date.', 'tutorhelper-pro' ) );
			}
			$totals = TutorHelper_Pro_Finance_Adjustments::get_booking_totals( $booking->id );
			$outstanding = max( 0, absint( $booking->price_minor_units ) - absint( $totals['net_paid_minor_units'] ) );
			if ( 0 === $outstanding ) {
				return new WP_Error( 'nothing_due', __( 'A selected lesson has no outstanding balance.', 'tutorhelper-pro' ) );
			}
			$items[] = array( 'booking' => $booking, 'due_date' => sanitize_text_field( $due ), 'outstanding' => $outstanding );
			$total += $outstanding;
		}
		$student = get_user_by( 'id', $student_id );
		return $student ? array( 'student' => $student, 'currency' => $currency, 'items' => $items, 'total' => $total ) : new WP_Error( 'student_missing', __( 'The selected student account could not be found.', 'tutorhelper-pro' ) );
	}

	/** Editable payment request template. */
	private static function register_template() {
		TutorHelper_Email_Templates::register(
			self::TEMPLATE_KEY,
			array(
				'module' => 'finance',
				'label' => __( 'Payment request — Student/parent', 'tutorhelper-pro' ),
				'description' => __( 'Sent manually from selected rows in Finance → View all.', 'tutorhelper-pro' ),
				'heading' => __( 'Payment request', 'tutorhelper-pro' ),
				'recipient' => 'student',
				'enabled' => true,
				'subject' => __( 'Payment request from {tutor_name}: {total_due}', 'tutorhelper-pro' ),
				'body' => __( "Hello {student_name},\n\nPlease find the selected lesson statement below.\n\n{statement}\n\nTotal due: <strong>{total_due}</strong>\n\n{payment_methods}\n\nBest wishes,\n{tutor_name}", 'tutorhelper-pro' ),
				'placeholders' => array( '{student_name}', '{statement}', '{total_due}', '{payment_methods}', '{tutor_name}', '{site_name}' ),
			)
		);

		TutorHelper_Email_Templates::register(
			self::COMPOSER_TEMPLATE_KEY,
			array(
				'module' => 'payment_request_composer',
				'label' => __( 'Composed payment request', 'tutorhelper-pro' ),
				'description' => __( 'Private transport template for a payment request edited immediately before sending.', 'tutorhelper-pro' ),
				'heading' => __( 'Payment request', 'tutorhelper-pro' ),
				'recipient' => 'selected',
				'enabled' => true,
				'subject' => '{payment_request_subject}',
				'body' => '{payment_request_body}',
				'placeholders' => array( '{payment_request_subject}', '{payment_request_body}' ),
			)
		);

		TutorHelper_Email_Templates::register(
			self::CONFIRMATION_TEMPLATE_KEY,
			array(
				'module' => 'finance',
				'label' => __( 'Combined payment received — Student/parent/tutor', 'tutorhelper-pro' ),
				'description' => __( 'Sent once when one Stripe payment settles multiple selected lessons.', 'tutorhelper-pro' ),
				'heading' => __( 'Payment received', 'tutorhelper-pro' ),
				'recipient' => 'student',
				'enabled' => true,
				'subject' => __( 'Payment received: {total_paid}', 'tutorhelper-pro' ),
				'body' => __( "Hello {student_name},\n\nYour payment has been received and the following lessons have been confirmed.\n\n{statement}\n\nTotal paid: <strong>{total_paid}</strong>\n\nBest wishes,\n{tutor_name}", 'tutorhelper-pro' ),
				'placeholders' => array( '{student_name}', '{statement}', '{total_paid}', '{tutor_name}', '{site_name}' ),
			)
		);
	}

	/** Build a compact statement table. */
	private static function statement_html( $selection ) {
		$html = '<table role="presentation" width="100%" cellpadding="6" cellspacing="0" style="border-collapse:collapse"><thead><tr><th align="left">' . esc_html__( 'Lesson', 'tutorhelper-pro' ) . '</th><th align="left">' . esc_html__( 'Due date', 'tutorhelper-pro' ) . '</th><th align="right">' . esc_html__( 'Amount', 'tutorhelper-pro' ) . '</th></tr></thead><tbody>';
		foreach ( $selection['items'] as $item ) {
			$booking = $item['booking'];
			$date = get_date_from_gmt( $booking->booking_start, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
			$html .= '<tr><td style="border-top:1px solid #ddd">' . esc_html( $date ) . '</td><td style="border-top:1px solid #ddd">' . esc_html( wp_date( get_option( 'date_format' ), strtotime( $item['due_date'] . ' UTC' ), new DateTimeZone( 'UTC' ) ) ) . '</td><td align="right" style="border-top:1px solid #ddd">' . esc_html( self::money( $item['outstanding'], $selection['currency'] ) ) . '</td></tr>';
		}
		return $html . '</tbody></table>';
	}

	/** Describe only the methods chosen by the tutor. */
	private static function payment_methods_html( $methods, $stripe_url ) {
		$parts = array();
		if ( in_array( 'stripe', $methods, true ) && $stripe_url ) {
			$parts[] = '<a href="' . esc_url( $stripe_url ) . '" style="display:inline-block;padding:10px 16px;background:#635bff;color:#fff;text-decoration:none;border-radius:4px">' . esc_html__( 'Pay securely with Stripe', 'tutorhelper-pro' ) . '</a>';
		}
		if ( in_array( 'bank_transfer', $methods, true ) ) {
			$details = TutorHelper_Pro_Bank_Details::get_details();
			$parts[] = '<strong>' . esc_html__( 'Bank transfer', 'tutorhelper-pro' ) . '</strong><br>' . esc_html( implode( ' · ', array_filter( array( $details['account_name'], $details['sort_code'], $details['account_number'], $details['iban'], $details['reference_instructions'] ) ) ) );
		}
		if ( in_array( 'contact_tutor', $methods, true ) ) {
			$parts[] = esc_html__( 'Please contact your tutor to arrange another payment method.', 'tutorhelper-pro' );
		}
		return implode( '<br><br>', $parts );
	}

	/** Return the permitted payment methods submitted by the tutor. */
	private static function posted_methods() {
		return isset( $_POST['payment_methods'] ) && is_array( $_POST['payment_methods'] )
			? array_values( array_intersect( array_map( 'sanitize_key', wp_unslash( $_POST['payment_methods'] ) ), array( 'stripe', 'bank_transfer', 'contact_tutor' ) ) )
			: array();
	}

	/** Return the permitted payment-request recipient roles. */
	private static function posted_recipient_types() {
		return isset( $_POST['recipients'] ) && is_array( $_POST['recipients'] )
			? array_values( array_intersect( array_map( 'sanitize_key', wp_unslash( $_POST['recipients'] ) ), array( 'student', 'parent', 'tutor' ) ) )
			: array();
	}

	/** Validate the tutor's one-off subject, body and optional personal message. */
	private static function posted_email_content() {
		$subject = isset( $_POST['email_subject'] ) && ! is_array( $_POST['email_subject'] )
			? sanitize_text_field( wp_unslash( $_POST['email_subject'] ) )
			: '';
		$body = isset( $_POST['email_body'] ) && ! is_array( $_POST['email_body'] )
			? wp_kses_post( wp_unslash( $_POST['email_body'] ) )
			: '';
		$personal_message = isset( $_POST['personal_message'] ) && ! is_array( $_POST['personal_message'] )
			? wp_kses_post( wp_unslash( $_POST['personal_message'] ) )
			: '';
		if ( '' === trim( $subject ) ) {
			return new WP_Error( 'email_subject_missing', __( 'Add an email subject before sending the payment request.', 'tutorhelper-pro' ) );
		}
		if ( '' === trim( wp_strip_all_tags( $body ) ) ) {
			return new WP_Error( 'email_body_missing', __( 'Add an email body before sending the payment request.', 'tutorhelper-pro' ) );
		}
		return array(
			'subject' => function_exists( 'mb_substr' ) ? mb_substr( $subject, 0, 200 ) : substr( $subject, 0, 200 ),
			'body' => $body,
			'personal_message' => $personal_message,
		);
	}

	/** Render the tutor's edited message inside the shared branded email wrapper. */
	private static function render_composed_email( $selection, $methods, $stripe_url, $content ) {
		$values = array(
			'{student_name}' => sanitize_text_field( $selection['student']->display_name ),
			'{statement}' => self::statement_html( $selection ),
			'{total_due}' => self::money( $selection['total'], $selection['currency'] ),
			'{payment_methods}' => self::payment_methods_html( $methods, $stripe_url ),
			'{tutor_name}' => sanitize_text_field( wp_get_current_user()->display_name ),
			'{site_name}' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
		$allowed = array_keys( $values );
		$subject = TutorHelper_Email_Placeholders::replace( $content['subject'], $values, $allowed );
		$body = TutorHelper_Email_Placeholders::replace( $content['body'], $values, $allowed );
		if ( '' !== trim( wp_strip_all_tags( $content['personal_message'] ) ) ) {
			$body = '<div class="tutorhelper-payment-request-personal-message">' . wpautop( $content['personal_message'] ) . '</div>' . $body;
		}
		$transport = array(
			'{payment_request_subject}' => $subject,
			'{payment_request_body}' => $body,
		);
		$rendered = TutorHelper_Email_Renderer::render( self::COMPOSER_TEMPLATE_KEY, $transport );
		if ( is_wp_error( $rendered ) ) {
			return $rendered;
		}
		$rendered['transport_placeholders'] = $transport;
		return $rendered;
	}

	/** Resolve selected recipient roles without guessing addresses. */
	private static function resolve_recipients( $types, $student, $booking ) {
		$recipients = array();
		if ( in_array( 'student', $types, true ) && is_email( $student->user_email ) ) {
			$recipients['student'] = sanitize_email( $student->user_email );
		}
		if ( in_array( 'parent', $types, true ) && method_exists( 'TutorHelper_Students', 'get_parent_details' ) ) {
			$parent = TutorHelper_Students::get_parent_details( $student->ID );
			$email = is_array( $parent ) ? ( $parent['parent_email'] ?? ( $parent['email'] ?? '' ) ) : ( is_object( $parent ) ? ( $parent->parent_email ?? ( $parent->email ?? '' ) ) : '' );
			if ( is_email( $email ) ) {
				$recipients['parent'] = sanitize_email( $email );
			}
		}
		if ( in_array( 'tutor', $types, true ) ) {
			$tutor = get_user_by( 'id', absint( $booking->tutor_user_id ) );
			if ( $tutor && is_email( $tutor->user_email ) ) {
				$recipients['tutor'] = sanitize_email( $tutor->user_email );
			}
		}
		return $recipients;
	}

	/** Synchronise Core's simple state after an allocated Stripe payment. */
	private static function refresh_booking( $booking, $session_id ) {
		$totals = TutorHelper_Pro_Finance_Adjustments::get_booking_totals( $booking->id );
		$status = $totals['net_paid_minor_units'] >= absint( $booking->price_minor_units ) ? TutorHelper_Booking_Records::PAYMENT_STATUS_PAID : TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING;
		$booking_status = TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ? TutorHelper_Booking_Records::STATUS_CANCELLED : TutorHelper_Booking_Records::STATUS_CONFIRMED;
		$updated = TutorHelper_Booking_Records::update_payment_details(
			$booking->id,
			array( 'payment_status' => $status, 'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE, 'payment_provider' => TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE, 'payment_reference' => sanitize_text_field( $session_id ), 'booking_status' => $booking_status ),
			sanitize_key( $booking->payment_status )
		);
		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		$updated_booking = TutorHelper_Booking_Records::get_by_id( $booking->id );
		do_action( 'tutorhelper_pro_booking_payment_received', absint( $booking->id ), $updated_booking, $booking );

		return $updated_booking;
	}


	/** Build the signed public URL included in payment-request emails. */
	private static function payment_link_url( $request_id ) {
		return add_query_arg(
			array(
				self::PUBLIC_REQUEST_ARG => absint( $request_id ),
				self::PUBLIC_TOKEN_ARG => self::payment_link_token( $request_id ),
			),
			home_url( '/' )
		);
	}

	/** Sign a request ID with this WordPress installation's authentication salt. */
	private static function payment_link_token( $request_id ) {
		return hash_hmac( 'sha256', 'payment_request|' . absint( $request_id ), wp_salt( 'auth' ) );
	}

	/** Render a small public response without exposing finance details. */
	private static function payment_link_error( $message, $status ) {
		wp_die(
			esc_html( $message ),
			esc_html__( 'Payment request', 'tutorhelper-pro' ),
			array(
				'response' => absint( $status ),
				'link_url' => home_url( '/' ),
				'link_text' => __( 'Return to the website', 'tutorhelper-pro' ),
			)
		);
	}

	/** Load one persistent request. */
	private static function get_request( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id=%d', TutorHelper_Pro_Database::get_table_name( 'payment_requests' ), absint( $id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** Update lifecycle state. */
	private static function update_request_status( $id, $status, $paid = false ) {
		global $wpdb;
		$data = array( 'status' => sanitize_key( $status ), 'updated_at' => current_time( 'mysql', true ) );
		if ( $paid ) {
			$data['paid_at'] = current_time( 'mysql', true );
		}
		$wpdb->update( TutorHelper_Pro_Database::get_table_name( 'payment_requests' ), $data, array( 'id' => absint( $id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
	}

	/** Require normal TutorHelper administration permission. */
	private static function require_tutor() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to send payment requests.', 'tutorhelper-pro' ) );
		}
	}

	/** Return to the Finance report. */
	private static function redirect_finance( $args ) {
		wp_safe_redirect( add_query_arg( array_merge( array( 'page' => TutorHelper_Admin::MENU_SLUG, 'tab' => TutorHelper_Pro_Finance_Admin::TAB_KEY, 'finance_view' => TutorHelper_Pro_Finance_Admin::VIEW_ALL ), $args ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Admin notice helper. */
	private static function render_notice( $message, $type ) {
		echo '<div class="notice notice-' . esc_attr( $type ) . ' inline"><p>' . esc_html( $message ) . '</p></div>';
	}

	/** Convert safe redirect codes into useful tutor-facing messages. */
	private static function error_message( $code ) {
		$messages = array(
			'no_lessons_selected' => __( 'Select at least one lesson.', 'tutorhelper-pro' ),
			'mixed_students' => __( 'Select lessons for one student at a time.', 'tutorhelper-pro' ),
			'mixed_currencies' => __( 'Selected lessons must use the same currency.', 'tutorhelper-pro' ),
			'due_date_missing' => __( 'Every selected lesson must have a payment due date.', 'tutorhelper-pro' ),
			'nothing_due' => __( 'A selected lesson has no outstanding balance.', 'tutorhelper-pro' ),
			'methods_or_recipients_missing' => __( 'Choose at least one payment method and one recipient.', 'tutorhelper-pro' ),
			'selection_expired' => __( 'The selection expired. Select the lessons again.', 'tutorhelper-pro' ),
			'stripe_unavailable' => __( 'Stripe is not currently configured.', 'tutorhelper-pro' ),
			'email_subject_missing' => __( 'Add an email subject before sending the payment request.', 'tutorhelper-pro' ),
			'email_body_missing' => __( 'Add an email body before sending the payment request.', 'tutorhelper-pro' ),
			'email_render_failed' => __( 'The edited payment-request email could not be prepared.', 'tutorhelper-pro' ),
		);
		return $messages[ $code ] ?? __( 'The payment request could not be prepared.', 'tutorhelper-pro' );
	}

	/** Format a monetary amount. */
	private static function money( $amount, $currency ) {
		return TutorHelper_Currency::format_minor_units( absint( $amount ), strtoupper( sanitize_text_field( $currency ) ) );
	}
}
