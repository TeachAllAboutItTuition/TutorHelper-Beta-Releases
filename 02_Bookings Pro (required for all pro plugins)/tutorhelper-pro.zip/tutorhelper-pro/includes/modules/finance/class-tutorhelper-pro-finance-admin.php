<?php
/**
 * TutorHelper Pro Finance administration.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides the Pro Finance Booking Hub tab.
 */
final class TutorHelper_Pro_Finance_Admin {

	/**
	 * Booking Hub tab key.
	 *
	 * @var string
	 */
	const TAB_KEY =
		'finance';

	/**
	 * Dashboard view.
	 *
	 * @var string
	 */
	const VIEW_DASHBOARD =
		'dashboard';

	/**
	 * All finance data view.
	 *
	 * @var string
	 */
	const VIEW_ALL =
		'all';

    /**
     * AJAX action used to save a booking due date.
     *
     * @var string
     */
    const SAVE_DUE_DATE_ACTION =
        'tutorhelper_pro_save_finance_due_date';


    /**
     * Nonce action used to save booking due dates.
     *
     * @var string
     */
    const SAVE_DUE_DATE_NONCE =
        'tutorhelper_pro_save_finance_due_date';

    /** AJAX action for applying one due date to selected lessons. */
    const BULK_DUE_DATE_ACTION = 'tutorhelper_pro_bulk_finance_due_date';

    /** Nonce action for bulk due-date changes. */
    const BULK_DUE_DATE_NONCE = 'tutorhelper_pro_bulk_finance_due_date';

    /** Finance export action. */
    const EXPORT_ACTION = 'tutorhelper_pro_export_finance';

    /** Finance export nonce action. */
    const EXPORT_NONCE = 'tutorhelper_pro_export_finance';

	/**
	 * Register Finance administration hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_booking_hub_tabs',
			array(
				__CLASS__,
				'register_tab',
			)
		);

		add_action(
			'tutorhelper_booking_hub_render_tab',
			array(
				__CLASS__,
				'render_tab',
			),
			10,
			2
		);

		add_action(
			'admin_enqueue_scripts',
			array(
				__CLASS__,
				'enqueue_assets',
			)
		);

        add_action(
            'wp_ajax_'
                . self::SAVE_DUE_DATE_ACTION,
            array(
                __CLASS__,
                'handle_save_due_date',
            )
        );

		add_action(
			'wp_ajax_' . self::BULK_DUE_DATE_ACTION,
			array( __CLASS__, 'handle_bulk_due_date' )
		);

        add_action(
            'admin_post_' . self::EXPORT_ACTION,
            array( __CLASS__, 'handle_export' )
        );

		add_filter(
			'tutorhelper_booking_hub_summary_cards',
			array(
				__CLASS__,
				'filter_booking_hub_summary_cards',
			)
		);

		add_filter(
			'tutorhelper_calendar_booking_records_prepared',
			array(
				__CLASS__,
				'add_calendar_payment_status_labels',
			)
		);

	}


	/**
	 * Add Pro Finance payment labels to prepared calendar bookings.
	 *
	 * Core leaves this detail empty, so payment information is only shown
	 * while TutorHelper Pro is active.
	 *
	 * @param array $records Prepared calendar booking records.
	 *
	 * @return array
	 */
	public static function add_calendar_payment_status_labels(
		$records
	) {
		if ( ! is_array( $records ) ) {
			return array();
		}

		foreach ( $records as $index => $record ) {
			if ( ! is_array( $record ) ) {
				continue;
			}

			$payment_status = isset(
				$record['payment_status']
			)
				? sanitize_key(
					$record['payment_status']
				)
				: '';

			if ( '' === $payment_status ) {
				continue;
			}

			$records[ $index ]['payment_status_label'] =
				self::get_financial_payment_label(
					isset( $record['id'] ) ? absint( $record['id'] ) : 0,
					isset( $record['status'] ) ? $record['status'] : '',
					$payment_status
				);
		}

		return $records;
	}


    /**
     * Enable the Core Finance Pro tab.
     *
     * Core supplies the Finance tab definition. Pro only marks it
     * available while the licensed Finance module is active.
     *
     * @param array $tabs Booking Hub tabs.
     *
     * @return array
     */
    public static function register_tab(
        $tabs
    ) {

        if (
            isset(
                $tabs[
                    self::TAB_KEY
                ]
            )
        ) {
            $tabs[
                self::TAB_KEY
            ]['status'] =
                'available';
        }

        return $tabs;
    }


    /**
     * Return the selected Finance view.
     *
     * @return string
     */
    private static function get_selected_view() {

        $view =
            isset(
                $_GET['finance_view']
            )
            && ! is_array(
                $_GET['finance_view']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET[
                            'finance_view'
                        ]
                    )
                )
                : self::VIEW_DASHBOARD;

        if (
            ! in_array(
                $view,
                array(
                    self::VIEW_DASHBOARD,
                    self::VIEW_ALL,
                ),
                true
            )
        ) {
            return self::VIEW_DASHBOARD;
        }

        return $view;
    }


    /**
     * Build a Finance Booking Hub URL.
     *
     * @param string $view Finance view.
     * @param array  $args Additional query arguments.
     *
     * @return string
     */
    private static function get_view_url(
        $view,
        $args = array()
    ) {

        $query_args =
            array_merge(
                array(
                    'page' =>
                        TutorHelper_Admin::
                            MENU_SLUG,

                    'tab' =>
                        self::TAB_KEY,

                    'finance_view' =>
                        sanitize_key(
                            $view
                        ),
                ),
                is_array( $args )
                    ? $args
                    : array()
            );

        return add_query_arg(
            $query_args,
            admin_url(
                'admin.php'
            )
        );
    }


    /**
     * Render the Finance Booking Hub tab.
     *
     * @param string $selected_tab Selected tab.
     * @param array  $active_tab   Active tab definition.
     *
     * @return void
     */
    public static function render_tab(
        $selected_tab,
        $active_tab
    ) {

        unset( $active_tab );

        if (
            self::TAB_KEY
            !== $selected_tab
        ) {
            return;
        }

        if (
            ! current_user_can(
                TutorHelper_Admin::
                    CAPABILITY
            )
        ) {
            return;
        }

        $view =
            self::get_selected_view();

        if (
            self::VIEW_ALL
            === $view
        ) {
            self::render_all_data();

            return;
        }

        self::render_dashboard();
    }



    /**
     * Render the Finance dashboard.
     *
     * @return void
     */
    private static function render_dashboard() {

        $summary =
            self::query_finance_report(
                self::get_current_month_filters()
            );

        $currency =
            TutorHelper_Currency::
                get_currency();

        $cards = array(
            array(
                'label' => __( 'Paid', 'tutorhelper-pro' ),
                'icon' => 'dashicons-chart-line',
                'description' => __( 'Payments received', 'tutorhelper-pro' ),
                'value' => (int) $summary['paid_minor_units'],
            ),
            array(
                'label' => __( 'Upcoming', 'tutorhelper-pro' ),
                'icon' => 'dashicons-calendar-alt',
                'description' => __( 'Not yet due, including lessons without a due date', 'tutorhelper-pro' ),
                'value' => (int) $summary['upcoming_minor_units'],
            ),
            array(
                'label' => __( 'Overdue', 'tutorhelper-pro' ),
                'icon' => 'dashicons-warning',
                'description' => __( 'Due today or earlier', 'tutorhelper-pro' ),
                'value' => (int) $summary['overdue_minor_units'],
            ),
            array(
                'label' => __( 'Credited', 'tutorhelper-pro' ),
                'icon' => 'dashicons-tickets-alt',
                'description' => __( 'Account credit issued', 'tutorhelper-pro' ),
                'value' => (int) $summary['credited_minor_units'],
            ),
            array(
                'label' => __( 'Refunded', 'tutorhelper-pro' ),
                'icon' => 'dashicons-undo',
                'description' => __( 'Money returned to students', 'tutorhelper-pro' ),
                'value' => (int) $summary['refunded_minor_units'],
            ),
        );
        ?>
        <section class="tutorhelper-pro-finance-intro">
            <h2><?php esc_html_e( 'Finance', 'tutorhelper-pro' ); ?></h2>
            <p>
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: %s: current month and year. */
                        __( 'Summary for %s.', 'tutorhelper-pro' ),
                        wp_date( 'F Y', null, wp_timezone() )
                    )
                );
                ?>
            </p>
        </section>

        <div class="tutorhelper-main-section__body">
            <div class="tutorhelper-pro-finance-dashboard">
                <?php foreach ( $cards as $card ) : ?>
                    <section class="tutorhelper-pro-finance-summary-card">
                        <div class="tutorhelper-pro-finance-summary-card__header">
                            <div class="tutorhelper-pro-finance-summary-card__title-row">
                                <span class="dashicons <?php echo esc_attr( $card['icon'] ); ?>" aria-hidden="true"></span>
                                <h3><?php echo esc_html( $card['label'] ); ?></h3>
                            </div>
                            <p><?php echo esc_html( $card['description'] ); ?></p>
                        </div>
                        <div class="tutorhelper-pro-finance-summary-card__body">
                            <strong class="tutorhelper-pro-finance-summary-card__value">
                                <?php
                                echo esc_html(
                                    TutorHelper_Currency::format_minor_units(
                                        $card['value'],
                                        $currency
                                    )
                                );
                                ?>
                            </strong>
                        </div>
                    </section>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="tutorhelper-main-section">
            <div class="tutorhelper-main-section__header">
                <h3><?php esc_html_e( 'Recent finance activity', 'tutorhelper-pro' ); ?></h3>
                <p><?php esc_html_e( 'Recent payment and finance activity will appear here.', 'tutorhelper-pro' ); ?></p>
            </div>
            <div class="tutorhelper-main-section__body">
                <div class="tutorhelper-pro-finance__placeholder">
                    <p><?php esc_html_e( 'Finance activity summaries will be added as reporting features are introduced.', 'tutorhelper-pro' ); ?></p>
                </div>
            </div>
        </div>

        <div class="tutorhelper-pro-finance__actions">
            <a
                class="button tutorhelper-admin-button tutorhelper-admin-button--primary"
                href="<?php echo esc_url( self::get_view_url( self::VIEW_ALL ) ); ?>"
            >
                <span class="dashicons dashicons-list-view" aria-hidden="true"></span>
                <?php esc_html_e( 'View all finance data', 'tutorhelper-pro' ); ?>
            </a>
        </div>
        <?php
    }

    /**
     * Render the Finance All Data view.
     *
     * @return void
     */
    private static function render_all_data() {

        $filters =
            self::get_report_filters();

        $booking_query =
            self::query_finance_report(
                $filters
            );

        $bookings =
            isset(
                $booking_query[
                    'bookings'
                ]
            )
            && is_array(
                $booking_query[
                    'bookings'
                ]
            )
                ? $booking_query[
                    'bookings'
                ]
                : array();

        $booking_types =
            TutorHelper_Booking_Types::
                get_all(
                    array(
                        'active_only' =>
                            false,
                    )
                );

        $booking_type_map =
            self::build_booking_type_map(
                $booking_types
            );

        ?>
        <section
            class="tutorhelper-pro-finance"
        >
            <section
                class="tutorhelper-pro-finance-intro"
            >
                <div
                    class="tutorhelper-pro-finance-intro__content"
                >
                    <div>
                        <h2>
                            <?php
                            echo esc_html__(
                                'All Finance Data',
                                'tutorhelper-pro'
                            );
                            ?>
                        </h2>

                        <p>
                            <?php
                            echo esc_html__(
                                'Review lesson prices, payment information and payment due dates.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </p>
                    </div>

                    <a
                        class="button tutorhelper-admin-button"
                        href="<?php
                            echo esc_url(
                                self::get_view_url(
                                    self::VIEW_DASHBOARD
                                )
                            );
                        ?>"
                    >
                        <?php
                        echo esc_html__(
                            'Back to Finance',
                            'tutorhelper-pro'
                        );
                        ?>
                    </a>

                    <div class="tutorhelper-pro-finance-filters__heading">
                        <strong>
                            <?php
                            echo esc_html__(
                                'Filter finance data',
                                'tutorhelper-pro'
                            );
                            ?>
                        </strong>

                        <span>
                            <?php
                            echo esc_html__(
                                'Narrow the report by lesson date, payment due date or payment status.',
                                'tutorhelper-pro'
                            );
                            ?>
                        </span>
                    </div>

                    <?php
                    self::render_report_filters(
                        $filters
                    );
                    ?>

                </div>

            </section>

            <?php
            self::render_report_summary(
                $booking_query
            );
            ?>

            <section class="tutorhelper-pro-finance-bulk-due-date" aria-labelledby="tutorhelper-finance-bulk-due-date-title">
                <div>
                    <h3 id="tutorhelper-finance-bulk-due-date-title"><?php esc_html_e( 'Set due date for selected lessons', 'tutorhelper-pro' ); ?></h3>
                    <p><?php esc_html_e( 'Use the lesson checkboxes below, choose one date, then apply it to every selected lesson.', 'tutorhelper-pro' ); ?></p>
                </div>
                <label>
                    <span class="screen-reader-text"><?php esc_html_e( 'Payment due date', 'tutorhelper-pro' ); ?></span>
                    <input type="date" class="tutorhelper-admin-control" data-finance-bulk-due-date />
                </label>
                <button type="button" class="button tutorhelper-admin-button tutorhelper-admin-button--primary" data-finance-bulk-due-date-save>
                    <?php esc_html_e( 'Apply due date', 'tutorhelper-pro' ); ?>
                </button>
                <span role="status" aria-live="polite" data-finance-bulk-due-date-status></span>
            </section>

            <div
                class="tutorhelper-main-section"
            >
                <div
                    class="tutorhelper-main-section__header"
                >
                    <h3>
                        <?php
                        echo esc_html__(
                            'Finance report',
                            'tutorhelper-pro'
                        );
                        ?>
                    </h3>

                    <p>
                        <?php
                        echo esc_html__(
                            'Payment status colours highlight lessons that need attention.',
                            'tutorhelper-pro'
                        );
                        ?>
                    </p>
                    
                </div>

                <div
                    class="tutorhelper-main-section__body"
                >
                    <?php
                    self::render_finance_table(
                        $bookings,
                        $booking_type_map,
                        $filters,
                        $booking_query
                    );

                    self::render_pagination(
                        $booking_query,
                        $filters
                    );
                    ?>
                </div>
            </div>
        </section>
        <?php
    }


    /**
     * Return the complete filtered Finance dataset for statement exports.
     *
     * This keeps statement PDFs aligned with the filters and booking selection
     * used by the Finance All Data report.
     *
     * @param array $request Request values containing Finance filters.
     * @return array
     */
    public static function get_statement_export_data( $request ) {
        $filters = self::get_report_filters( $request );

        return array(
            'filters' => $filters,
            'bookings' => self::get_export_bookings( $filters ),
            'booking_types' => self::build_booking_type_map(
                TutorHelper_Booking_Types::get_all(
                    array(
                        'active_only' => false,
                    )
                )
            ),
        );
    }



    /**
     * Export all Finance rows matching the submitted filters.
     *
     * @return void
     */
    public static function handle_export() {
        if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
            wp_die( esc_html__( 'You do not have permission to export Finance data.', 'tutorhelper-pro' ) );
        }

        check_admin_referer( self::EXPORT_NONCE, '_tutorhelper_finance_export_nonce' );

        $format = isset( $_GET['tutorhelper_finance_export_format'] ) && ! is_array( $_GET['tutorhelper_finance_export_format'] )
            ? sanitize_key( wp_unslash( $_GET['tutorhelper_finance_export_format'] ) )
            : '';

        if ( ! in_array( $format, array( 'csv', 'pdf' ), true ) ) {
            wp_die( esc_html__( 'The requested Finance export format is not available.', 'tutorhelper-pro' ) );
        }

        $filters = self::get_report_filters( $_GET );
        $bookings = self::get_export_bookings( $filters );

        try {
            if ( 'csv' === $format ) {
                self::stream_csv_export( $bookings, $filters );
            }

            self::stream_pdf_export( $bookings, $filters );
        } catch ( Throwable $exception ) {
            TutorHelper_Logger::error(
                'Finance export failed.',
                array(
                    'format' => $format,
                    'message' => $exception->getMessage(),
                    'user_id' => get_current_user_id(),
                )
            );

            wp_die( esc_html__( 'The Finance export could not be generated. Please review TutorHelper diagnostics and try again.', 'tutorhelper-pro' ) );
        }
    }

    /**
     * Return every Finance booking matching filters in export-safe batches.
     *
     * @param array $filters Finance report filters.
     * @return array
     */
    private static function get_export_bookings( $filters ) {
        $bookings = array();
        $page = 1;

        do {
            $batch_filters = $filters;
            $batch_filters['page'] = $page;
            $batch = self::query_finance_report( $batch_filters );
            $rows = isset( $batch['bookings'] ) && is_array( $batch['bookings'] )
                ? $batch['bookings']
                : array();

            $bookings = array_merge( $bookings, $rows );
            $total_pages = isset( $batch['total_pages'] ) ? absint( $batch['total_pages'] ) : 0;
            ++$page;
        } while ( ! empty( $rows ) && $page <= $total_pages );

        return $bookings;
    }

    /**
     * Send the filtered Finance report as CSV.
     *
     * @param array $bookings Finance bookings.
     * @param array $filters  Applied filters.
     * @return void
     */
    private static function stream_csv_export( $bookings, $filters ) {
        unset( $filters );

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="tutorhelper-finance-' . esc_attr( wp_date( 'Y-m-d', null, wp_timezone() ) ) . '.csv"' );

        $output = fopen( 'php://output', 'w' );
        if ( false === $output ) {
            throw new RuntimeException( 'Finance CSV output could not be opened.' );
        }

        fputcsv(
            $output,
            array(
                __( 'Student', 'tutorhelper-pro' ),
                __( 'Lesson type', 'tutorhelper-pro' ),
                __( 'Lesson date', 'tutorhelper-pro' ),
                __( 'Lesson time', 'tutorhelper-pro' ),
                __( 'Duration', 'tutorhelper-pro' ),
                __( 'Price', 'tutorhelper-pro' ),
                __( 'Payment due date', 'tutorhelper-pro' ),
                __( 'Payment status', 'tutorhelper-pro' ),
                __( 'Payment method', 'tutorhelper-pro' ),
                __( 'Manual payment type', 'tutorhelper-pro' ),
            )
        );

        $booking_types = self::build_booking_type_map( TutorHelper_Booking_Types::get_all( array( 'active_only' => false ) ) );
        foreach ( $bookings as $booking ) {
            $details = self::get_lesson_details( $booking );
            $currency = ! empty( $booking->currency ) ? sanitize_key( $booking->currency ) : TutorHelper_Currency::get_currency();
            $manual_type = isset( $booking->manual_payment_type ) ? sanitize_key( $booking->manual_payment_type ) : '';

            fputcsv(
                $output,
                array(
                    isset( $booking->student_name ) ? $booking->student_name : '',
                    isset( $booking_types[ absint( $booking->booking_type_id ) ]->title ) ? $booking_types[ absint( $booking->booking_type_id ) ]->title : __( 'Unknown Booking Type', 'tutorhelper-pro' ),
                    $details['date'],
                    $details['time'],
                    $details['duration'],
                    TutorHelper_Currency::format_minor_units( absint( $booking->price_minor_units ), $currency ),
                    self::format_due_date( ! empty( $booking->payment_due_date ) ? $booking->payment_due_date : '' ),
                    self::get_status_label( isset( $booking->payment_status ) ? $booking->payment_status : '' ),
                    self::get_payment_method_label( isset( $booking->payment_method ) ? $booking->payment_method : '' ),
                    '' !== $manual_type ? TutorHelper_Pro_Payment_Ledger::get_manual_payment_type_label( $manual_type ) : '',
                )
            );
        }

        fclose( $output );
        exit;
    }

    /**
     * Send the filtered Finance report as PDF.
     *
     * @param array $bookings Finance bookings.
     * @param array $filters  Applied filters.
     * @return void
     */
    private static function stream_pdf_export( $bookings, $filters ) {
        if ( ! class_exists( '\\Dompdf\\Dompdf' ) && defined( 'TUTORHELPER_BOOKINGS_PATH' ) ) {
            $autoload = TUTORHELPER_BOOKINGS_PATH . 'vendor/dompdf/autoload.inc.php';
            if ( file_exists( $autoload ) ) {
                require_once $autoload;
            }
        }

        if ( ! class_exists( '\\Dompdf\\Dompdf' ) ) {
            throw new RuntimeException( 'Core Dompdf is unavailable.' );
        }

        $types = self::build_booking_type_map( TutorHelper_Booking_Types::get_all( array( 'active_only' => false ) ) );
        ob_start();
        ?>
        <!doctype html>
        <html><head><meta charset="utf-8">
        <style>
            @page { margin: 24px; }
            body { color: #133949; font-family: DejaVu Sans, sans-serif; font-size: 9px; }
            h1 { font-size: 20px; margin: 0; }
            p { color: #60727d; margin: 5px 0 14px; }
            table { border-collapse: collapse; width: 100%; }
            thead { display: table-header-group; }
            th { background: #133949; color: #fff; font-size: 8px; padding: 6px; text-align: left; }
            td { border-bottom: 1px solid #d3dfe4; padding: 6px; vertical-align: top; }
            .money { text-align: right; white-space: nowrap; }
        </style></head><body>
        <h1><?php esc_html_e( 'Finance report', 'tutorhelper-pro' ); ?></h1>
        <p><?php echo esc_html( sprintf( __( 'Exported %1$s · %2$d lessons', 'tutorhelper-pro' ), wp_date( get_option( 'date_format' ), null, wp_timezone() ), count( $bookings ) ) ); ?></p>
        <table><thead><tr>
            <th><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></th>
            <th><?php esc_html_e( 'Lesson', 'tutorhelper-pro' ); ?></th>
            <th><?php esc_html_e( 'Date and time', 'tutorhelper-pro' ); ?></th>
            <th><?php esc_html_e( 'Price', 'tutorhelper-pro' ); ?></th>
            <th><?php esc_html_e( 'Due', 'tutorhelper-pro' ); ?></th>
            <th><?php esc_html_e( 'Status', 'tutorhelper-pro' ); ?></th>
            <th><?php esc_html_e( 'Payment type', 'tutorhelper-pro' ); ?></th>
        </tr></thead><tbody>
        <?php foreach ( $bookings as $booking ) : ?>
            <?php
            $details = self::get_lesson_details( $booking );
            $currency = ! empty( $booking->currency ) ? sanitize_key( $booking->currency ) : TutorHelper_Currency::get_currency();
            $manual_type = isset( $booking->manual_payment_type ) ? sanitize_key( $booking->manual_payment_type ) : '';
            ?>
            <tr>
                <td><?php echo esc_html( isset( $booking->student_name ) ? $booking->student_name : '' ); ?></td>
                <td><?php echo esc_html( isset( $types[ absint( $booking->booking_type_id ) ]->title ) ? $types[ absint( $booking->booking_type_id ) ]->title : __( 'Unknown Booking Type', 'tutorhelper-pro' ) ); ?></td>
                <td><?php echo esc_html( $details['date'] . ' ' . $details['time'] ); ?></td>
                <td class="money"><?php echo esc_html( TutorHelper_Currency::format_minor_units( absint( $booking->price_minor_units ), $currency ) ); ?></td>
                <td><?php echo esc_html( self::format_due_date( ! empty( $booking->payment_due_date ) ? $booking->payment_due_date : '' ) ); ?></td>
                <?php $payment_display = self::get_document_payment_status( $booking ); ?>
                <td>
                    <strong><?php echo esc_html( $payment_display['label'] ); ?></strong>
                    <?php if ( '' !== $payment_display['note'] ) : ?>
                        <br />
                        <small><?php echo esc_html( $payment_display['note'] ); ?></small>
                    <?php endif; ?>
                </td>
                <td><?php echo esc_html( '' !== $manual_type ? TutorHelper_Pro_Payment_Ledger::get_manual_payment_type_label( $manual_type ) : self::get_payment_method_label( isset( $booking->payment_method ) ? $booking->payment_method : '' ) ); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody></table></body></html>
        <?php
        $html = ob_get_clean();

        $pdf = new \Dompdf\Dompdf( array( 'isRemoteEnabled' => false ) );
        $pdf->loadHtml( $html, 'UTF-8' );
        $pdf->setPaper( 'A4', 'landscape' );
        $pdf->render();
        $pdf->stream( 'tutorhelper-finance-' . wp_date( 'Y-m-d', null, wp_timezone() ) . '.pdf', array( 'Attachment' => true ) );
        exit;
    }


    /**
     * Render Finance report filters.
     *
     * @param array $filters Current filters.
     *
     * @return void
     */
    private static function render_report_filters(
        $filters
    ) {

        $reset_url =
            self::get_view_url(
                self::VIEW_ALL
            );

        ?>
        <form
            method="get"
            class="tutorhelper-pro-finance-filters"
        >
            <input
                type="hidden"
                name="page"
                value="<?php
                    echo esc_attr(
                        TutorHelper_Admin::
                            MENU_SLUG
                    );
                ?>"
            />

            <input
                type="hidden"
                name="tab"
                value="<?php
                    echo esc_attr(
                        self::TAB_KEY
                    );
                ?>"
            />

            <input
                type="hidden"
                name="finance_view"
                value="<?php
                    echo esc_attr(
                        self::VIEW_ALL
                    );
                ?>"
            />

            <input
                type="hidden"
                name="action"
                value="<?php echo esc_attr( self::EXPORT_ACTION ); ?>"
            />

            <?php wp_nonce_field( self::EXPORT_NONCE, '_tutorhelper_finance_export_nonce' ); ?>

            <label class="tutorhelper-pro-finance-filters__field tutorhelper-pro-finance-filters__field--search">
                <span><?php echo esc_html__( 'Student or parent', 'tutorhelper-pro' ); ?></span>
                <input
                    type="search"
                    name="finance_name_search"
                    value="<?php echo esc_attr( $filters['name_search'] ); ?>"
                    class="tutorhelper-admin-control"
                    placeholder="<?php echo esc_attr__( 'Search by name or email', 'tutorhelper-pro' ); ?>"
                />
            </label>

            <div
                class="tutorhelper-pro-finance-filters__group"
            >
                <span
                    class="tutorhelper-pro-finance-filters__label"
                >
                    <?php
                    echo esc_html__(
                        'Lesson date',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <label>
                    <span
                        class="screen-reader-text"
                    >
                        <?php
                        echo esc_html__(
                            'Lesson date from',
                            'tutorhelper-pro'
                        );
                        ?>
                    </span>

                    <input
                        type="date"
                        name="finance_lesson_date_from"
                        value="<?php
                            echo esc_attr(
                                $filters[
                                    'lesson_date_from'
                                ]
                            );
                        ?>"
                        class="tutorhelper-admin-control"
                    />
                </label>

                <span aria-hidden="true">–</span>

                <label>
                    <span
                        class="screen-reader-text"
                    >
                        <?php
                        echo esc_html__(
                            'Lesson date to',
                            'tutorhelper-pro'
                        );
                        ?>
                    </span>

                    <input
                        type="date"
                        name="finance_lesson_date_to"
                        value="<?php
                            echo esc_attr(
                                $filters[
                                    'lesson_date_to'
                                ]
                            );
                        ?>"
                        class="tutorhelper-admin-control"
                    />
                </label>
            </div>

            <div
                class="tutorhelper-pro-finance-filters__group"
            >
                <span
                    class="tutorhelper-pro-finance-filters__label"
                >
                    <?php
                    echo esc_html__(
                        'Due date',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <input
                    type="date"
                    name="finance_due_date_from"
                    value="<?php
                        echo esc_attr(
                            $filters[
                                'due_date_from'
                            ]
                        );
                    ?>"
                    class="tutorhelper-admin-control"
                />

                <span aria-hidden="true">–</span>

                <input
                    type="date"
                    name="finance_due_date_to"
                    value="<?php
                        echo esc_attr(
                            $filters[
                                'due_date_to'
                            ]
                        );
                    ?>"
                    class="tutorhelper-admin-control"
                />
            </div>

            <fieldset class="tutorhelper-pro-finance-filters__field tutorhelper-pro-finance-filters__field--choices">
                <legend><?php esc_html_e( 'Payment status', 'tutorhelper-pro' ); ?></legend>
                <div class="tutorhelper-pro-finance-filters__choices">
                    <?php foreach ( self::get_payment_status_filter_options() as $status_key => $status_label ) : ?>
                        <label>
                            <input type="checkbox" name="finance_payment_status[]" value="<?php echo esc_attr( $status_key ); ?>" <?php checked( in_array( $status_key, $filters['payment_statuses'], true ) ); ?> />
                            <span><?php echo esc_html( $status_label ); ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </fieldset>

            <fieldset class="tutorhelper-pro-finance-filters__field tutorhelper-pro-finance-filters__field--choices">
                <legend><?php esc_html_e( 'Booking records', 'tutorhelper-pro' ); ?></legend>
                <div class="tutorhelper-pro-finance-filters__choices">
                    <label>
                        <input
                            type="checkbox"
                            name="finance_exclude_void"
                            value="1"
                            <?php checked( ! empty( $filters['exclude_void'] ) ); ?>
                        />
                        <span>
                            <?php
                            echo esc_html__(
                                'Hide void bookings',
                                'tutorhelper-pro'
                            );
                            ?>
                        </span>
                    </label>
                </div>
                <p class="description">
                    <?php
                    echo esc_html__(
                        'A void booking is cancelled while its payment remains pending.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </fieldset>

            <fieldset class="tutorhelper-pro-finance-filters__field tutorhelper-pro-finance-filters__field--choices">
                <legend><?php esc_html_e( 'Manual payment type', 'tutorhelper-pro' ); ?></legend>
                <div class="tutorhelper-pro-finance-filters__choices">
                    <?php foreach ( TutorHelper_Pro_Payment_Ledger::get_manual_payment_types() as $payment_type ) : ?>
                        <label>
                            <input type="checkbox" name="finance_payment_type[]" value="<?php echo esc_attr( $payment_type ); ?>" <?php checked( in_array( $payment_type, $filters['payment_types'], true ) ); ?> />
                            <span><?php echo esc_html( TutorHelper_Pro_Payment_Ledger::get_manual_payment_type_label( $payment_type ) ); ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </fieldset>

			<label
				class="tutorhelper-pro-finance-filters__field"
			>
                <span>
                    <?php
                    echo esc_html__(
                        'Due status',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <select
                    name="finance_due_scope"
                    class="tutorhelper-admin-control"
                >
                    <option
                        value="all"
                        <?php
                        selected(
                            $filters[
                                'due_scope'
                            ],
                            'all'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Show all',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="past_due"
                        <?php
                        selected(
                            $filters[
                                'due_scope'
                            ],
                            'past_due'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Past due',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="not_yet_due"
                        <?php
                        selected(
                            $filters[
                                'due_scope'
                            ],
                            'not_yet_due'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Not yet due',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="no_due_date"
                        <?php
                        selected(
                            $filters[
                                'due_scope'
                            ],
                            'no_due_date'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'No due date set',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>
                </select>
            </label>

            <label
                class="tutorhelper-pro-finance-filters__field"
            >
                <span>
                    <?php
                    echo esc_html__(
                        'Sort by',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <select
                    name="finance_sort"
                    class="tutorhelper-admin-control"
                >
                    <option
                        value="lesson_desc"
                        <?php
                        selected(
                            $filters['sort'],
                            'lesson_desc'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Lesson date – newest first',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="lesson_asc"
                        <?php
                        selected(
                            $filters['sort'],
                            'lesson_asc'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Lesson date – oldest first',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="due_asc"
                        <?php
                        selected(
                            $filters['sort'],
                            'due_asc'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Due date – earliest first',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="due_desc"
                        <?php
                        selected(
                            $filters['sort'],
                            'due_desc'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Due date – latest first',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>
                </select>
            </label>

            <label
                class="tutorhelper-pro-finance-filters__field"
            >
                <span>
                    <?php
                    echo esc_html__(
                        'Group by',
                        'tutorhelper-pro'
                    );
                    ?>
                </span>

                <select
                    name="finance_group"
                    class="tutorhelper-admin-control"
                >
                    <option
                        value="none"
                        <?php
                        selected(
                            $filters['group'],
                            'none'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'No grouping',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="student"
                        <?php
                        selected(
                            $filters['group'],
                            'student'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Student',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="due_date"
                        <?php
                        selected(
                            $filters['group'],
                            'due_date'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Due date',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>

                    <option
                        value="payment_type"
                        <?php
                        selected(
                            $filters['group'],
                            'payment_type'
                        );
                        ?>
                    >
                        <?php
                        echo esc_html__(
                            'Manual payment type',
                            'tutorhelper-pro'
                        );
                        ?>
                    </option>
                </select>
            </label>

            <div
                class="tutorhelper-pro-finance-filters__actions"
            >
                <button
                    type="submit"
                    class="button tutorhelper-admin-button tutorhelper-admin-button--primary"
                >
                    <?php
                    echo esc_html__(
                        'Apply filters',
                        'tutorhelper-pro'
                    );
                    ?>
                </button>

                <a
                    href="<?php
                        echo esc_url(
                            $reset_url
                        );
                    ?>"
                    class="button tutorhelper-admin-button"
                >
                    <?php
                    echo esc_html__(
                        'Reset',
                        'tutorhelper-pro'
                    );
                    ?>
                </a>

                <button
                    type="submit"
                    name="tutorhelper_finance_export_format"
                    value="csv"
                    formaction="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                    class="button tutorhelper-admin-button"
                >
                    <?php esc_html_e( 'Export CSV', 'tutorhelper-pro' ); ?>
                </button>

                <button
                    type="submit"
                    name="action"
                    value="tutorhelper_pro_export_finance_statements"
                    formaction="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                    class="button tutorhelper-admin-button"
                >
                    <?php esc_html_e( 'Export statements PDF', 'tutorhelper-pro' ); ?>
                </button>

                <button
                    type="submit"
                    name="tutorhelper_finance_export_format"
                    value="pdf"
                    formaction="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                    class="button tutorhelper-admin-button"
                >
                    <?php esc_html_e( 'Export PDF', 'tutorhelper-pro' ); ?>
                </button>
            </div>
        </form>
        <?php
    }


    /**
     * Load Finance admin styling.
     *
     * @param string $hook_suffix Current admin hook.
     *
     * @return void
     */
    public static function enqueue_assets(
        $hook_suffix
    ) {

        if (
            'toplevel_page_'
                . TutorHelper_Admin::
                    MENU_SLUG
            !== $hook_suffix
        ) {
            return;
        }

        $selected_tab =
            isset(
                $_GET['tab']
            )
            && ! is_array(
                $_GET['tab']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_GET['tab']
                    )
                )
                : '';

        if (
            self::TAB_KEY
            !== $selected_tab
        ) {
            return;
        }

        $js_path =
            TUTORHELPER_PRO_PATH
            . 'assets/js/tutorhelper-pro-finance.js';

        wp_enqueue_script(
            'tutorhelper-pro-finance',
            TUTORHELPER_PRO_URL
                . 'assets/js/tutorhelper-pro-finance.js',
            array(),
            file_exists(
                $js_path
            )
                ? (string) filemtime(
                    $js_path
                )
                : TUTORHELPER_PRO_VERSION,
            true
        );

        wp_localize_script(
            'tutorhelper-pro-finance',
            'tutorhelperProFinance',
            array(
                'ajaxUrl' =>
                    admin_url(
                        'admin-ajax.php'
                    ),

                'saveDueDateAction' =>
                    self::SAVE_DUE_DATE_ACTION,

                'saveDueDateNonce' =>
                    wp_create_nonce(
                        self::SAVE_DUE_DATE_NONCE
                    ),

                'bulkDueDateAction' =>
                    self::BULK_DUE_DATE_ACTION,

                'bulkDueDateNonce' =>
                    wp_create_nonce( self::BULK_DUE_DATE_NONCE ),

				'preparePaymentRequestAction' => TutorHelper_Pro_Payment_Requests::PREPARE_AJAX_ACTION,

				'preparePaymentRequestNonce' => wp_create_nonce( TutorHelper_Pro_Payment_Requests::PREPARE_AJAX_ACTION ),

				'previewPaymentRequestAction' => TutorHelper_Pro_Payment_Requests::PREVIEW_AJAX_ACTION,

				'previewPaymentRequestNonce' => wp_create_nonce( TutorHelper_Pro_Payment_Requests::PREVIEW_NONCE_ACTION ),

				'paymentRequestPreviewingLabel' => __( 'Preparing preview…', 'tutorhelper-pro' ),

				'paymentRequestSendingLabel' => __( 'Creating and sending…', 'tutorhelper-pro' ),

				'paymentRequestPreviewError' => __( 'The payment-request email preview could not be prepared.', 'tutorhelper-pro' ),

				'paymentRequestFieldsError' => __( 'Add a subject and email body before continuing.', 'tutorhelper-pro' ),

				'paymentRequestOptionsError' => __( 'Choose at least one payment method and one recipient before previewing.', 'tutorhelper-pro' ),

                'bulkSuccessLabel' =>
                    __( 'The due date was applied to the selected lessons.', 'tutorhelper-pro' ),

                'selectLessonsLabel' =>
                    __( 'Select at least one lesson first.', 'tutorhelper-pro' ),

                'savingLabel' =>
                    __(
                        'Saving…',
                        'tutorhelper-pro'
                    ),

                'saveFailedLabel' =>
                    __(
                        'The payment due date could not be saved.',
                        'tutorhelper-pro'
                    ),
            )
        );

        $admin_css_path =
            TUTORHELPER_PRO_PATH
            . 'assets/css/tutorhelper-pro-admin.css';

        wp_enqueue_style(
            'tutorhelper-pro-admin',
            TUTORHELPER_PRO_URL
                . 'assets/css/tutorhelper-pro-admin.css',
            array(
                'tutorhelper-booking-hub',
            ),
            file_exists(
                $admin_css_path
            )
                ? (string) filemtime(
                    $admin_css_path
                )
                : TUTORHELPER_PRO_VERSION
        );

        $finance_css_path =
            TUTORHELPER_PRO_PATH
            . 'assets/css/tutorhelper-pro-finance.css';

        wp_enqueue_style(
            'tutorhelper-pro-finance',
            TUTORHELPER_PRO_URL
                . 'assets/css/tutorhelper-pro-finance.css',
            array(
                'tutorhelper-booking-hub',
                'tutorhelper-pro-admin',
            ),
            file_exists(
                $finance_css_path
            )
                ? (string) filemtime(
                    $finance_css_path
                )
                : TUTORHELPER_PRO_VERSION
        );
    }



    /**
     * Build a Booking Type lookup keyed by ID.
     *
     * @param array $booking_types Booking Type records.
     *
     * @return array
     */
    private static function build_booking_type_map(
        $booking_types
    ) {

        $map = array();

        if ( ! is_array( $booking_types ) ) {
            return $map;
        }

        foreach (
            $booking_types
            as $booking_type
        ) {

            if (
                ! is_object(
                    $booking_type
                )
                || empty(
                    $booking_type->id
                )
            ) {
                continue;
            }

            $map[
                absint(
                    $booking_type->id
                )
            ] =
                $booking_type;
        }

        return $map;
    }


    /**
     * Return Finance due dates keyed by booking ID.
     *
     * @param array $bookings Core booking records.
     *
     * @return array
     */
    private static function get_due_dates(
        $bookings
    ) {

        global $wpdb;

        if ( empty( $bookings ) ) {
            return array();
        }

        $booking_ids = array();

        foreach (
            $bookings
            as $booking
        ) {

            if (
                isset(
                    $booking->id
                )
            ) {
                $booking_id =
                    absint(
                        $booking->id
                    );

                if ( $booking_id ) {
                    $booking_ids[] =
                        $booking_id;
                }
            }
        }

        if ( empty( $booking_ids ) ) {
            return array();
        }

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'booking_finance'
                );

        if ( '' === $table ) {
            return array();
        }

        $placeholders =
            implode(
                ',',
                array_fill(
                    0,
                    count( $booking_ids ),
                    '%d'
                )
            );

        $sql =
            $wpdb->prepare(
                "SELECT booking_id, payment_due_date
                FROM %i
                WHERE booking_id IN ({$placeholders})",
                array_merge(
                    array( $table ),
                    $booking_ids
                )
            );

        $results =
            $wpdb->get_results(
                $sql
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance data must reflect current due dates.

        $due_dates = array();

        foreach (
            $results
            as $result
        ) {
            $due_dates[
                absint(
                    $result->booking_id
                )
            ] =
                (string)
                $result->payment_due_date;
        }

        return $due_dates;
    }


    /**
     * Determine the Finance display state for a booking.
     *
     * Only pending payments participate in due-date urgency.
     *
     * @param object $booking  Core booking.
     * @param string $due_date Payment due date.
     *
     * @return string
     */
    private static function get_finance_state(
        $booking,
        $due_date
    ) {

        $booking_status =
            isset( $booking->status )
                ? sanitize_key(
                    $booking->status
                )
                : '';

        $payment_status =
            isset(
                $booking->payment_status
            )
                ? sanitize_key(
                    $booking->payment_status
                )
                : '';

        /*
        * Cancelled bookings are informational only,
        * regardless of their historic payment state.
        */
        if (
            TutorHelper_Booking_Records::
                STATUS_CANCELLED
            === $booking_status
        ) {
            return 'informational';
        }

        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PAID
            === $payment_status
        ) {
            return 'paid';
        }

        /*
        * Pending is the only state treated as unpaid.
        */
        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PENDING
            !== $payment_status
        ) {
            return 'informational';
        }

        if ( '' === $due_date ) {
            return 'no-due-date';
        }

        try {
            $timezone =
                wp_timezone();

            $today =
                new DateTimeImmutable(
                    'today',
                    $timezone
                );

            $due =
                DateTimeImmutable::
                    createFromFormat(
                        '!Y-m-d',
                        $due_date,
                        $timezone
                    );

            if ( ! $due ) {
                return 'no-due-date';
            }

            if ( $due <= $today ) {
                return 'overdue';
            }

            $seven_days =
                $today->modify(
                    '+7 days'
                );

            if ( $due <= $seven_days ) {
                return 'due-soon';
            }

            return 'future';

        } catch ( Exception $exception ) {
            return 'no-due-date';
        }
    }


    /**
     * Render filtered finance totals above the report.
     *
     * @param array $booking_query Finance report query result.
     *
     * @return void
     */
    private static function render_report_summary(
        $booking_query
    ) {
        $currency =
            TutorHelper_Currency::
                get_currency();

        $cards = array(
            array(
                'label' => __( 'Paid', 'tutorhelper-pro' ),
                'value' => (int) $booking_query['paid_minor_units'],
                'class' => 'is-paid',
            ),
            array(
                'label' => __( 'Upcoming', 'tutorhelper-pro' ),
                'value' => (int) $booking_query['upcoming_minor_units'],
                'class' => 'is-upcoming',
            ),
            array(
                'label' => __( 'Overdue', 'tutorhelper-pro' ),
                'value' => (int) $booking_query['overdue_minor_units'],
                'class' => 'is-overdue',
            ),
            array(
                'label' => __( 'Credited', 'tutorhelper-pro' ),
                'value' => (int) $booking_query['credited_minor_units'],
                'class' => 'is-credited',
            ),
            array(
                'label' => __( 'Refunded', 'tutorhelper-pro' ),
                'value' => (int) $booking_query['refunded_minor_units'],
                'class' => 'is-refunded',
            ),
        );
        ?>
        <div
            class="tutorhelper-pro-finance-report-summary"
            aria-label="<?php echo esc_attr__( 'Filtered finance totals', 'tutorhelper-pro' ); ?>"
        >
            <?php foreach ( $cards as $card ) : ?>
                <section class="tutorhelper-pro-finance-report-total <?php echo esc_attr( $card['class'] ); ?>">
                    <span><?php echo esc_html( $card['label'] ); ?></span>
                    <strong>
                        <?php
                        echo esc_html(
                            TutorHelper_Currency::format_minor_units(
                                $card['value'],
                                $currency
                            )
                        );
                        ?>
                    </strong>
                </section>
            <?php endforeach; ?>
        </div>
        <?php
    }

    /**
     * Render the Finance booking table.
     *
     * @param array $bookings         Booking records.
     * @param array $booking_type_map Booking Types keyed by ID.
     * @param array $due_dates        Due dates keyed by booking ID.
     *
     * @return void
     */
    private static function render_finance_table(
        $bookings,
        $booking_type_map,
        $filters,
        $booking_query
    ) {

        if ( empty( $bookings ) ) {
            ?>
            <div
                class="tutorhelper-pro-finance-empty"
            >
                <p>
                    <?php
                    echo esc_html__(
                        'No booking finance data was found.',
                        'tutorhelper-pro'
                    );
                    ?>
                </p>
            </div>
            <?php

            return;
        }

        $attendance_records =
            TutorHelper_Pro_Booking_Attendance::
                get_for_booking_ids(
                    wp_list_pluck(
                        $bookings,
                        'id'
                    )
                );

        $group_summaries =
            isset( $booking_query['group_summaries'] )
            && is_array( $booking_query['group_summaries'] )
                ? $booking_query['group_summaries']
                : array();

        ?>
        <?php do_action( 'tutorhelper_pro_finance_table_actions', $bookings ); ?>
        <div
            class="tutorhelper-pro-finance-table-wrap"
        >
            <table
                class="widefat tutorhelper-pro-finance-table"
            >
                <thead>
                    <tr>
                        <th
                            class="tutorhelper-pro-finance-table__indicator"
                            aria-hidden="true"
                        ></th>

                        <th scope="col">
                            <span class="screen-reader-text"><?php esc_html_e( 'Select for payment request', 'tutorhelper-pro' ); ?></span>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Student',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Booking Type',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Lesson',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Price',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Due Date',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Payment Method',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Payment Status',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Attendance',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>

                        <th scope="col">
                            <?php
                            echo esc_html__(
                                'Booking Status',
                                'tutorhelper-pro'
                            );
                            ?>
                        </th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $previous_group = null;

                    foreach (
                        $bookings
                        as $booking
                    ) {

                        $group =
                            self::get_booking_group(
                                $booking,
                                $filters['group']
                            );

                        if (
                            'none'
                            !== $filters['group']
                            && $group['key']
                                !== $previous_group
                        ) {
                            self::render_group_heading(
                                $group['label'],
                                isset( $group_summaries[ $group['key'] ] )
                                    ? $group_summaries[ $group['key'] ]
                                    : array()
                            );

                            $previous_group =
                                $group['key'];
                        }

                        self::render_finance_row(
                            $booking,
                            $booking_type_map,
                            isset(
                                $attendance_records[
                                    absint( $booking->id )
                                ]
                            )
                                ? $attendance_records[
                                    absint( $booking->id )
                                ]
                                : null
                        );
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Render Finance report totals.
     *
     * Totals represent all records matching the current filters,
     * rather than only the current pagination page.
     *
     * @param array $booking_query Finance report query result.
     *
     * @return void
     */
    private static function render_finance_totals(
        $booking_query
    ) {

        $total_minutes =
            isset(
                $booking_query[
                    'total_minutes'
                ]
            )
                ? absint(
                    $booking_query[
                        'total_minutes'
                    ]
                )
                : 0;

        $total_price =
            isset(
                $booking_query[
                    'total_price_minor_units'
                ]
            )
                ? (int) $booking_query[
                    'total_price_minor_units'
                ]
                : 0;

        $currency =
            TutorHelper_Currency::
                get_currency();

        $formatted_price =
            TutorHelper_Currency::
                format_minor_units(
                    $total_price,
                    $currency
                );

        $formatted_duration =
            self::format_total_duration(
                $total_minutes
            );

        ?>
        <tr
            class="tutorhelper-pro-finance-total-row"
        >
            <td
                class="tutorhelper-pro-finance-table__indicator"
                aria-hidden="true"
            ></td>

            <td aria-hidden="true"></td>

            <th
                scope="row"
                colspan="2"
            >
                <?php
                echo esc_html__(
                    'Filtered total',
                    'tutorhelper-pro'
                );
                ?>
            </th>

            <td>
                <strong>
                    <?php
                    echo esc_html(
                        $formatted_duration
                    );
                    ?>
                </strong>
            </td>

            <td>
                <strong>
                    <?php
                    echo esc_html(
                        $formatted_price
                    );
                    ?>
                </strong>
            </td>

            <td colspan="4"></td>
        </tr>
        <?php
    }


    /**
     * Render one Finance booking row.
     *
     * @param object $booking          Booking record.
     * @param array  $booking_type_map Booking Types keyed by ID.
     * @param object|null $attendance_record Attendance record.
     *
     * @return void
     */
    private static function render_finance_row(
        $booking,
        $booking_type_map,
        $attendance_record = null
    ) {

        $booking_id =
            absint(
                $booking->id
            );

        $booking_type_id =
            absint(
                $booking->booking_type_id
            );

        $booking_type =
            isset(
                $booking_type_map[
                    $booking_type_id
                ]
            )
                ? $booking_type_map[
                    $booking_type_id
                ]
                : null;

        $booking_type_name =
            $booking_type
            && isset(
                $booking_type->title
            )
                ? $booking_type->title
                : __(
                    'Unknown Booking Type',
                    'tutorhelper-pro'
                );

        $due_date =
            ! empty(
                $booking->payment_due_date
            )
                ? sanitize_text_field(
                    $booking->
                        payment_due_date
                )
                : '';

        $finance_state =
            self::get_finance_state(
                $booking,
                $due_date
            );

        $lesson_details =
            self::get_lesson_details(
                $booking
            );

        $currency =
            ! empty(
                $booking->currency
            )
                ? sanitize_key(
                    $booking->currency
                )
                : TutorHelper_Currency::
                    get_currency();

        $price =
            TutorHelper_Currency::
                format_minor_units(
                    absint(
                        $booking->
                            price_minor_units
                    ),
                    $currency
                );

        ?>
        <tr
            class="tutorhelper-pro-finance-row tutorhelper-pro-finance-row--<?php
                echo esc_attr(
                    $finance_state
                );
            ?>"
        >
            <td
                class="tutorhelper-pro-finance-table__indicator"
                aria-hidden="true"
            ></td>

            <td>
                <?php if (
                    TutorHelper_Booking_Records::STATUS_CANCELLED !== sanitize_key( $booking->status )
                    && TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING === sanitize_key( $booking->payment_status )
                ) : ?>
                    <input type="checkbox" name="booking_ids[]" value="<?php echo esc_attr( $booking_id ); ?>" form="tutorhelper-pro-payment-request-selection" data-finance-payment-select="<?php echo esc_attr( $booking_id ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Select lesson for %s', 'tutorhelper-pro' ), $booking->student_name ) ); ?>" />
                <?php else : ?>
                    <span aria-hidden="true">—</span>
                    <span class="screen-reader-text"><?php esc_html_e( 'Not available for a payment request', 'tutorhelper-pro' ); ?></span>
                <?php endif; ?>
            </td>

            <td>
                <strong>
                    <?php
                    echo esc_html(
                        $booking->student_name
                    );
                    ?>
                </strong>
            </td>

            <td>
                <?php
                echo esc_html(
                    $booking_type_name
                );
                ?>
            </td>

            <td>
                <strong>
                    <?php
                    echo esc_html(
                        $lesson_details[
                            'date'
                        ]
                    );
                    ?>
                </strong>

                <br />

                <span>
                    <?php
                    echo esc_html(
                        $lesson_details[
                            'time'
                        ]
                    );
                    ?>
                </span>

                <br />

                <small>
                    <?php
                    echo esc_html(
                        $lesson_details[
                            'duration'
                        ]
                    );
                    ?>
                </small>
            </td>

            <td>
                <strong>
                    <?php
                    echo esc_html(
                        $price
                    );
                    ?>
                </strong>
            </td>

            <td
                class="tutorhelper-pro-finance-due-date"
                data-finance-due-date
                data-booking-id="<?php
                    echo esc_attr(
                        $booking_id
                    );
                ?>"
            >
                <div
                    class="tutorhelper-pro-finance-due-date__display"
                >
                    <span
                        data-finance-due-date-label
                    >
                        <?php
                        echo esc_html(
                            self::format_due_date(
                                $due_date
                            )
                        );
                        ?>
                    </span>

                    <button
                        type="button"
                        class="
                            button-link
                            tutorhelper-pro-finance-due-date__edit
                        "
                        data-finance-due-date-edit
                        aria-label="<?php
                            echo esc_attr(
                                '' !== $due_date
                                    ? __(
                                        'Edit payment due date',
                                        'tutorhelper-pro'
                                    )
                                    : __(
                                        'Set payment due date',
                                        'tutorhelper-pro'
                                    )
                            );
                        ?>"
                        title="<?php
                            echo esc_attr(
                                '' !== $due_date
                                    ? __(
                                        'Edit due date',
                                        'tutorhelper-pro'
                                    )
                                    : __(
                                        'Set due date',
                                        'tutorhelper-pro'
                                    )
                            );
                        ?>"
                    >
                        <span
                            class="dashicons <?php
                                echo esc_attr(
                                    '' !== $due_date
                                        ? 'dashicons-edit'
                                        : 'dashicons-plus-alt2'
                                );
                            ?>"
                            aria-hidden="true"
                        ></span>
                    </button>
                </div>

                <div
                    class="tutorhelper-pro-finance-due-date__editor"
                    data-finance-due-date-editor
                    hidden
                >
                    <input
                        type="date"
                        class="tutorhelper-admin-control"
                        value="<?php
                            echo esc_attr(
                                $due_date
                            );
                        ?>"
                        data-finance-due-date-input
                    />

                    <div
                        class="tutorhelper-pro-finance-due-date__actions"
                    >
                        <button
                            type="button"
                            class="
                                button
                                tutorhelper-admin-button
                                tutorhelper-admin-button--primary
                            "
                            data-finance-due-date-save
                        >
                            <?php
                            echo esc_html__(
                                'Save',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>

                        <?php if ( '' !== $due_date ) : ?>
                            <button
                                type="button"
                                class="
                                    button
                                    tutorhelper-admin-button
                                "
                                data-finance-due-date-clear
                            >
                                <?php
                                echo esc_html__(
                                    'Clear',
                                    'tutorhelper-pro'
                                );
                                ?>
                            </button>
                        <?php endif; ?>

                        <button
                            type="button"
                            class="button-link"
                            data-finance-due-date-cancel
                        >
                            <?php
                            echo esc_html__(
                                'Cancel',
                                'tutorhelper-pro'
                            );
                            ?>
                        </button>
                    </div>

                    <span
                        class="tutorhelper-pro-finance-due-date__message"
                        data-finance-due-date-message
                        hidden
                    ></span>
                </div>
            </td>

            <td>
                <?php
                echo esc_html(
                    self::get_payment_method_label(
                        $booking->
                            payment_method
                    )
                );
                $manual_payment_type = isset( $booking->manual_payment_type )
                    ? TutorHelper_Pro_Payment_Ledger::get_manual_payment_type_label(
                        $booking->manual_payment_type
                    )
                    : '';
                if (
                    TutorHelper_Booking_Records::PAYMENT_STATUS_PAID === sanitize_key( $booking->payment_status )
                    && '' !== $manual_payment_type
                ) :
                    ?>
                    <br />
                    <small><?php echo esc_html( $manual_payment_type ); ?></small>
                    <?php
                endif;
                ?>
            </td>

            <td>
                <?php
                $payment_label =
                    self::get_financial_payment_label(
                        $booking_id,
                        $booking->status,
                        $booking->payment_status
                    );

                echo esc_html( $payment_label );
                ?>
            </td>

            <td>
                <?php
                $attendance_status =
                    $attendance_record
                    && ! empty(
                        $attendance_record->
                            attendance_status
                    )
                        ? sanitize_key(
                            $attendance_record->
                                attendance_status
                        )
                        : TutorHelper_Pro_Booking_Attendance::
                            STATUS_NOT_RECORDED;

                if (
                    TutorHelper_Booking_Records::
                        STATUS_CANCELLED
                    === sanitize_key(
                        $booking->status
                    )
                ) {
                    $attendance_status =
                        TutorHelper_Pro_Booking_Attendance::
                            STATUS_NOT_APPLICABLE;
                }

                echo esc_html(
                    TutorHelper_Pro_Booking_Attendance::
                        get_status_label(
                            $attendance_status
                        )
                );
                ?>
            </td>

            <td>
                <?php
                echo esc_html(
                    self::get_status_label(
                        $booking->status
                    )
                );
                ?>
            </td>
        </tr>
        <?php
    }


    /**
     * Return grouping information for a booking.
     *
     * @param object $booking Booking row.
     * @param string $group   Group type.
     *
     * @return array
     */
    private static function get_booking_group(
        $booking,
        $group
    ) {

        if ( 'student' === $group ) {

            $name =
                ! empty(
                    $booking->student_name
                )
                    ? $booking->student_name
                    : __(
                        'Unknown student',
                        'tutorhelper-pro'
                    );

            return array(
                'key' =>
                    'student-'
                    . absint(
                        $booking->
                            student_user_id
                    ),

                'label' =>
                    $name,
            );
        }

        if ( 'payment_type' === $group ) {
            $payment_type = isset( $booking->manual_payment_type )
                ? TutorHelper_Pro_Payment_Ledger::get_manual_payment_type_label(
                    $booking->manual_payment_type
                )
                : '';

            return array(
                'key' => '' !== $payment_type
                    ? 'payment-type-' . sanitize_key( $booking->manual_payment_type )
                    : 'payment-type-unknown',
                'label' => '' !== $payment_type
                    ? $payment_type
                    : __( 'No manual payment type', 'tutorhelper-pro' ),
            );
        }

        if ( 'due_date' === $group ) {

            $due_date =
                ! empty(
                    $booking->
                        payment_due_date
                )
                    ? sanitize_text_field(
                        $booking->
                            payment_due_date
                    )
                    : '';

            return array(
                'key' =>
                    '' !== $due_date
                        ? $due_date
                        : 'no-due-date',

                'label' =>
                    '' !== $due_date
                        ? self::format_due_date(
                            $due_date
                        )
                        : __(
                            'No due date',
                            'tutorhelper-pro'
                        ),
            );
        }

        return array(
            'key' =>
                'none',

            'label' =>
                '',
        );
    }


    /**
     * Render a Finance report group heading.
     *
     * @param string $label Group label.
     *
     * @return void
     */
    private static function render_group_heading(
        $label,
        $summary = array()
    ) {
        $currency = TutorHelper_Currency::get_currency();
        $totals = array(
            __( 'Paid', 'tutorhelper-pro' ) => isset( $summary['paid_minor_units'] ) ? (int) $summary['paid_minor_units'] : 0,
            __( 'Upcoming', 'tutorhelper-pro' ) => isset( $summary['upcoming_minor_units'] ) ? (int) $summary['upcoming_minor_units'] : 0,
            __( 'Overdue', 'tutorhelper-pro' ) => isset( $summary['overdue_minor_units'] ) ? (int) $summary['overdue_minor_units'] : 0,
            __( 'Credited', 'tutorhelper-pro' ) => isset( $summary['credited_minor_units'] ) ? (int) $summary['credited_minor_units'] : 0,
            __( 'Refunded', 'tutorhelper-pro' ) => isset( $summary['refunded_minor_units'] ) ? (int) $summary['refunded_minor_units'] : 0,
        );
        ?>
        <tr class="tutorhelper-pro-finance-group-row">
            <th colspan="11" scope="rowgroup">
                <div class="tutorhelper-pro-finance-group-row__content">
                    <span class="tutorhelper-pro-finance-group-row__label"><?php echo esc_html( $label ); ?></span>
                    <?php if ( ! empty( $summary ) ) : ?>
                        <span class="tutorhelper-pro-finance-group-row__totals">
                            <?php foreach ( $totals as $total_label => $amount ) : ?>
                                <span>
                                    <?php echo esc_html( $total_label ); ?>:
                                    <strong><?php echo esc_html( TutorHelper_Currency::format_minor_units( $amount, $currency ) ); ?></strong>
                                </span>
                            <?php endforeach; ?>
                        </span>
                    <?php endif; ?>
                </div>
            </th>
        </tr>
        <?php
    }

    /**
     * Format a Finance due date for display.
     *
     * @param string $due_date Due date in Y-m-d format.
     *
     * @return string
     */
    private static function format_due_date(
        $due_date
    ) {

        if ( '' === $due_date ) {
            return __(
                'Not set',
                'tutorhelper-pro'
            );
        }

        try {
            $date =
                new DateTimeImmutable(
                    $due_date,
                    wp_timezone()
                );

            return wp_date(
                get_option(
                    'date_format'
                ),
                $date->getTimestamp(),
                wp_timezone()
            );

        } catch ( Exception $exception ) {
            return __(
                'Not set',
                'tutorhelper-pro'
            );
        }
    }


    /**
     * Save or clear the payment due date for a booking.
     *
     * @return void
     */
    public static function handle_save_due_date() {

        if (
            ! current_user_can(
                TutorHelper_Admin::
                    CAPABILITY
            )
        ) {
            wp_send_json_error(
                array(
                    'message' =>
                        __(
                            'You do not have permission to update finance data.',
                            'tutorhelper-pro'
                        ),
                ),
                403
            );
        }

        check_ajax_referer(
            self::SAVE_DUE_DATE_NONCE,
            'nonce'
        );

        $booking_id =
            isset(
                $_POST['booking_id']
            )
            && ! is_array(
                $_POST['booking_id']
            )
                ? absint(
                    $_POST['booking_id']
                )
                : 0;

        $due_date =
            isset(
                $_POST['due_date']
            )
            && ! is_array(
                $_POST['due_date']
            )
                ? sanitize_text_field(
                    wp_unslash(
                        $_POST['due_date']
                    )
                )
                : '';

        if ( ! $booking_id ) {
            wp_send_json_error(
                array(
                    'message' =>
                        __(
                            'The booking could not be found.',
                            'tutorhelper-pro'
                        ),
                ),
                400
            );
        }

        $booking =
            TutorHelper_Booking_Records::
                get_by_id(
                    $booking_id
                );

        if ( ! $booking ) {
            wp_send_json_error(
                array(
                    'message' =>
                        __(
                            'The booking could not be found.',
                            'tutorhelper-pro'
                        ),
                ),
                404
            );
        }

        if (
            '' !== $due_date
            && ! self::is_valid_due_date(
                $due_date
            )
        ) {
            wp_send_json_error(
                array(
                    'message' =>
                        __(
                            'Enter a valid payment due date.',
                            'tutorhelper-pro'
                        ),
                ),
                400
            );
        }

        $result =
            self::save_due_date(
                $booking_id,
                $due_date
            );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error(
                array(
                    'message' =>
                        $result->
                            get_error_message(),
                ),
                500
            );
        }

        $finance_state =
            self::get_finance_state(
                $booking,
                $due_date
            );

        wp_send_json_success(
            array(
                'bookingId' =>
                    $booking_id,

                'dueDate' =>
                    $due_date,

                'dueDateLabel' =>
                    self::format_due_date(
                        $due_date
                    ),

                'financeState' =>
                    $finance_state,

                'hasDueDate' =>
                    '' !== $due_date,
            )
        );
    }


    /**
     * Apply a payment due date to selected bookings.
     *
     * @return void
     */
    public static function handle_bulk_due_date() {
        if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to update finance data.', 'tutorhelper-pro' ) ), 403 );
        }

        check_ajax_referer( self::BULK_DUE_DATE_NONCE, 'nonce' );

        $booking_ids = isset( $_POST['booking_ids'] ) && is_array( $_POST['booking_ids'] )
            ? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['booking_ids'] ) ) ) ) )
            : array();
        $due_date = isset( $_POST['due_date'] ) && ! is_array( $_POST['due_date'] )
            ? sanitize_text_field( wp_unslash( $_POST['due_date'] ) )
            : '';

        if ( empty( $booking_ids ) || ! self::is_valid_due_date( $due_date ) ) {
			TutorHelper_Logger::warning( 'Bulk Finance due-date request was invalid.', array( 'booking_count' => count( $booking_ids ), 'due_date' => $due_date ) );
            wp_send_json_error( array( 'message' => __( 'Select lessons and enter a valid payment due date.', 'tutorhelper-pro' ) ), 400 );
        }

        $updated = array();
		$errors = array();
        foreach ( $booking_ids as $booking_id ) {
            $booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
            if ( ! $booking || TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
                continue;
            }
            $result = self::save_due_date( $booking_id, $due_date );
            if ( ! is_wp_error( $result ) ) {
                $updated[] = $booking_id;
			} else {
				$errors[] = array( 'booking_id' => $booking_id, 'code' => $result->get_error_code(), 'message' => $result->get_error_message() );
            }
        }

        if ( empty( $updated ) ) {
			TutorHelper_Logger::error( 'Bulk Finance due-date update failed.', array( 'due_date' => $due_date, 'errors' => $errors ) );
            wp_send_json_error( array( 'message' => __( 'No lesson due dates were updated.', 'tutorhelper-pro' ) ), 409 );
        }
		if ( $errors ) {
			TutorHelper_Logger::warning( 'Bulk Finance due-date update was only partially successful.', array( 'due_date' => $due_date, 'updated_count' => count( $updated ), 'errors' => $errors ) );
		}

        wp_send_json_success(
            array(
                'bookingIds' => $updated,
                'dueDate' => $due_date,
                'dueDateLabel' => self::format_due_date( $due_date ),
                'message' => __( 'The due date was applied to the selected lessons.', 'tutorhelper-pro' ),
            )
        );
    }


    /**
     * Validate a Y-m-d due date.
     *
     * @param string $due_date Due date.
     *
     * @return bool
     */
    private static function is_valid_due_date(
        $due_date
    ) {

        $date =
            DateTimeImmutable::
                createFromFormat(
                    '!Y-m-d',
                    $due_date,
                    wp_timezone()
                );

        return false !== $date
            && $date->format(
                'Y-m-d'
            )
            === $due_date;
    }



    /**
     * Save or clear Finance due-date metadata.
     *
     * @param int    $booking_id Booking ID.
     * @param string $due_date   Due date or blank to clear.
     *
     * @return true|WP_Error
     */
    private static function save_due_date(
        $booking_id,
        $due_date
    ) {

        global $wpdb;

        $table =
            TutorHelper_Pro_Database::
                get_table_name(
                    'booking_finance'
                );

        if ( '' === $table ) {
			TutorHelper_Logger::error( 'Finance due date could not be saved because the table name was unavailable.', array( 'booking_id' => absint( $booking_id ) ) );
            return new WP_Error(
                'tutorhelper_pro_finance_table_missing',
                __(
                    'Finance data could not be saved.',
                    'tutorhelper-pro'
                )
            );
        }

        $booking_id =
            absint(
                $booking_id
            );

        $now =
            current_time(
                'mysql',
                true
            );

        /*
        * Clearing the due date removes the metadata row entirely.
        */
        if ( '' === $due_date ) {

            $deleted =
                $wpdb->delete(
                    $table,
                    array(
                        'booking_id' =>
                            $booking_id,
                    ),
                    array(
                        '%d',
                    )
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance metadata must be updated immediately.

            if ( false === $deleted ) {
                return new WP_Error(
                    'tutorhelper_pro_finance_due_date_clear_failed',
                    __(
                        'The payment due date could not be cleared.',
                        'tutorhelper-pro'
                    )
                );
            }

            return true;
        }

        $existing =
            $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT booking_id
                    FROM %i
                    WHERE booking_id = %d',
                    $table,
                    $booking_id
                )
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current metadata state is required before update.

        if ( $existing ) {

            $updated =
                $wpdb->update(
                    $table,
                    array(
                        'payment_due_date' =>
                            $due_date,

                        'updated_at' =>
                            $now,
                    ),
                    array(
                        'booking_id' =>
                            $booking_id,
                    ),
                    array(
                        '%s',
                        '%s',
                    ),
                    array(
                        '%d',
                    )
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance metadata must be updated immediately.

            if ( false === $updated ) {
				TutorHelper_Logger::error( 'Finance due-date database update failed.', array( 'booking_id' => $booking_id, 'database_error' => $wpdb->last_error ) );
                return new WP_Error(
                    'tutorhelper_pro_finance_due_date_update_failed',
                    __(
                        'The payment due date could not be saved.',
                        'tutorhelper-pro'
                    )
                );
            }

            return true;
        }

        $inserted =
            $wpdb->insert(
                $table,
                array(
                    'booking_id' =>
                        $booking_id,

                    'payment_due_date' =>
                        $due_date,

                    'created_at' =>
                        $now,

                    'updated_at' =>
                        $now,
                ),
                array(
                    '%d',
                    '%s',
                    '%s',
                    '%s',
                )
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance metadata must be created immediately.

        if ( false === $inserted ) {
			TutorHelper_Logger::error( 'Finance due-date database insert failed.', array( 'booking_id' => $booking_id, 'database_error' => $wpdb->last_error ) );
            return new WP_Error(
                'tutorhelper_pro_finance_due_date_insert_failed',
                __(
                    'The payment due date could not be saved.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }



    /**
     * Format lesson date, time and duration.
     *
     * @param object $booking Booking record.
     *
     * @return array
     */
    private static function get_lesson_details(
        $booking
    ) {

        try {
            $utc =
                new DateTimeZone(
                    'UTC'
                );

            $site_timezone =
                wp_timezone();

            $start =
                new DateTimeImmutable(
                    $booking->booking_start,
                    $utc
                );

            $end =
                new DateTimeImmutable(
                    $booking->booking_end,
                    $utc
                );

            $duration =
                max(
                    0,
                    (int) round(
                        (
                            $end->getTimestamp()
                            - $start->getTimestamp()
                        )
                        / 60
                    )
                );

            $start =
                $start->setTimezone(
                    $site_timezone
                );

            return array(
                'date' =>
                    wp_date(
                        get_option(
                            'date_format'
                        ),
                        $start->getTimestamp(),
                        $site_timezone
                    ),

                'time' =>
                    wp_date(
                        get_option(
                            'time_format'
                        ),
                        $start->getTimestamp(),
                        $site_timezone
                    ),

                'duration' =>
                    sprintf(
                        /* translators: %d: lesson duration in minutes. */
                        __(
                            '%d minutes',
                            'tutorhelper-pro'
                        ),
                        $duration
                    ),
            );

        } catch ( Exception $exception ) {

            return array(
                'date' => '—',
                'time' => '—',
                'duration' => '—',
            );
        }
    }



    /**
     * Return a readable status label.
     *
     * @param string $status Status key.
     *
     * @return string
     */
    private static function get_status_label(
        $status
    ) {

        $status =
            sanitize_key(
                $status
            );

        if ( '' === $status ) {
            return '—';
        }

        return ucwords(
            str_replace(
                '_',
                ' ',
                $status
            )
        );
    }


    /**
     * Return the parent-facing payment display for document exports.
     *
     * A cancelled paid lesson that has become account credit is not a debt.
     * The Core booking row is intentionally pending after cancellation, but
     * Finance documents must retain the payment and show the credit outcome.
     *
     * @param object $booking Booking row.
     * @return array{label:string,note:string}
     */
    private static function get_document_payment_status( $booking ) {
        $booking_id = isset( $booking->id ) ? absint( $booking->id ) : 0;
        $currency = ! empty( $booking->currency )
            ? sanitize_key( $booking->currency )
            : TutorHelper_Currency::get_currency();

        if ( $booking_id && class_exists( 'TutorHelper_Pro_Finance_Adjustments' ) ) {
            $totals = TutorHelper_Pro_Finance_Adjustments::get_booking_totals( $booking_id );
            $credit = isset( $totals['active_credit_minor_units'] )
                ? absint( $totals['active_credit_minor_units'] )
                : 0;

            if ( 0 < $credit ) {
                return array(
                    'label' => __( 'Paid', 'tutorhelper-pro' ),
                    'note' => sprintf(
                        /* translators: %s: account-credit amount. */
                        __( 'Account credit issued: %s', 'tutorhelper-pro' ),
                        TutorHelper_Currency::format_minor_units( $credit, $currency )
                    ),
                );
            }
        }

        return array(
            'label' => self::get_financial_payment_label(
                $booking_id,
                isset( $booking->status ) ? $booking->status : '',
                isset( $booking->payment_status ) ? $booking->payment_status : ''
            ),
            'note' => '',
        );
    }



    /**
     * Return the financial payment label while preserving the booking status.
     *
     * A cancelled lesson can still have a completed refund, so "Refunded"
     * must take precedence over the generic cancelled/void display.
     *
     * @param int    $booking_id     Booking ID.
     * @param string $booking_status Booking status.
     * @param string $payment_status Payment status.
     * @return string
     */
    private static function get_financial_payment_label(
        $booking_id,
        $booking_status,
        $payment_status
    ) {
        $booking_id = absint( $booking_id );
        $payment_status = sanitize_key( $payment_status );

        if (
            $booking_id
            && class_exists( 'TutorHelper_Pro_Finance_Adjustments' )
        ) {
            $totals =
                TutorHelper_Pro_Finance_Adjustments::
                    get_booking_totals( $booking_id );

            $refunded = isset( $totals['refunded_minor_units'] )
                ? absint( $totals['refunded_minor_units'] )
                : 0;
            $paid = isset( $totals['paid_minor_units'] )
                ? absint( $totals['paid_minor_units'] )
                : 0;

            if ( 0 < $refunded ) {
                return $paid > $refunded
                    ? __( 'Partially refunded', 'tutorhelper-pro' )
                    : __( 'Refunded', 'tutorhelper-pro' );
            }
        }

        if (
            TutorHelper_Booking_Records::STATUS_CANCELLED
            === sanitize_key( $booking_status )
            && TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING
            === $payment_status
        ) {
            return __( 'Void', 'tutorhelper-pro' );
        }

        return self::get_status_label( $payment_status );
    }


    /**
     * Return a readable payment method label.
     *
     * @param string $method Payment method.
     *
     * @return string
     */
    private static function get_payment_method_label(
        $method
    ) {

        $method =
            sanitize_key(
                $method
            );

        $labels = array(
            'stripe' =>
                __(
                    'Stripe',
                    'tutorhelper-pro'
                ),

            'manual' =>
                __(
                    'Invoice / bank transfer',
                    'tutorhelper-pro'
                ),

            'free' =>
                __(
                    'Free',
                    'tutorhelper-pro'
                ),
        );

        return isset(
            $labels[ $method ]
        )
            ? $labels[ $method ]
            : self::get_status_label(
                $method
            );
    }


    /**
     * Render Finance report pagination.
     *
     * @param array $booking_query Core query result.
     *
     * @return void
     */
    private static function render_pagination(
        $booking_query,
        $filters
    ) {

        $total_pages =
            isset(
                $booking_query[
                    'total_pages'
                ]
            )
                ? absint(
                    $booking_query[
                        'total_pages'
                    ]
                )
                : 0;

        if ( $total_pages <= 1 ) {
            return;
        }

        $current_page =
            isset(
                $booking_query['page']
            )
                ? max(
                    1,
                    absint(
                        $booking_query[
                            'page'
                        ]
                    )
                )
                : 1;

        $base_url =
            self::get_view_url(
                self::VIEW_ALL,
                array(
                    'finance_lesson_date_from' =>
                        $filters[
                            'lesson_date_from'
                        ],

                    'finance_lesson_date_to' =>
                        $filters[
                            'lesson_date_to'
                        ],

                    'finance_due_date_from' =>
                        $filters[
                            'due_date_from'
                        ],

                    'finance_due_date_to' =>
                        $filters[
                            'due_date_to'
                        ],

                    'finance_due_scope' =>
                        $filters[
                            'due_scope'
                        ],

                    'finance_payment_status' =>
                        $filters['payment_statuses'],

                    'finance_payment_type' =>
                        $filters['payment_types'],

                    'finance_exclude_void' =>
                        ! empty( $filters['exclude_void'] )
                            ? '1'
                            : '',

                    'finance_sort' =>
                        $filters['sort'],

                    'finance_group' =>
                        $filters['group'],
                )
            );


        ?>
        <div
            class="tutorhelper-pro-finance-pagination"
        >
            <?php
            echo wp_kses_post(
                paginate_links(
                    array(
                        'base' =>
                            add_query_arg(
                                'finance_page',
                                '%#%',
                                $base_url
                            ),

                        'format' =>
                            '',

                        'current' =>
                            $current_page,

                        'total' =>
                            $total_pages,

                        'prev_text' =>
                            __(
                                '← Previous',
                                'tutorhelper-pro'
                            ),

                        'next_text' =>
                            __(
                                'Next →',
                                'tutorhelper-pro'
                            ),
                    )
                )
            );
            ?>
        </div>
        <?php
    }


    /**
     * Return Finance-tab totals for an explicit set of Core bookings.
     *
     * Dashboard reports use this method so the Paid, Upcoming, Overdue,
     * Credited and Refunded definitions remain identical in both screens.
     *
     * @param array $booking_ids Core booking IDs.
     *
     * @return array
     */
    public static function get_summary_for_booking_ids(
        $booking_ids
    ) {
        global $wpdb;

        $keys = array(
            'total_minutes',
            'total_price_minor_units',
            'paid_minor_units',
            'upcoming_minor_units',
            'overdue_minor_units',
            'outstanding_minor_units',
            'credited_minor_units',
            'refunded_minor_units',
        );
        $empty = array_fill_keys( $keys, 0 );
        $booking_ids = array_values(
            array_unique(
                array_filter(
                    array_map( 'absint', (array) $booking_ids )
                )
            )
        );

        if ( empty( $booking_ids ) ) {
            return $empty;
        }

        $bookings_table = TutorHelper_Booking_Records::get_table_name();
        $finance_table  = TutorHelper_Pro_Database::get_table_name( 'booking_finance' );
        $ledger_table   = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );

        if ( '' === $bookings_table || '' === $finance_table || '' === $ledger_table ) {
            return $empty;
        }

        $placeholders = implode( ', ', array_fill( 0, count( $booking_ids ), '%d' ) );
        $today        = wp_date( 'Y-m-d', null, wp_timezone() );
        $summary_sql  = 'SELECT ' . self::get_finance_summary_select_sql()
            . " FROM %i b LEFT JOIN %i f ON f.booking_id = b.id WHERE b.id IN ({$placeholders})";
        $summary_args = array_merge(
            self::get_finance_summary_arguments( $ledger_table, $today ),
            array( $bookings_table, $finance_table ),
            $booking_ids
        );
        $summary = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Dashboard finance must use the current Finance ledger state.
            $wpdb->prepare( $summary_sql, $summary_args ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Fixed SQL and prepared ID placeholders.
        );

        return array_merge( $empty, self::normalise_finance_summary( $summary ) );
    }


    /**
     * Read and sanitise Finance report filters.
     *
     * @param array|null $request Request data.
     *
     * @return array
     */
    private static function get_report_filters(
        $request = null
    ) {

        if ( null === $request ) {
            $request = $_GET;
        }

        $request =
            is_array( $request )
                ? $request
                : array();

        $name_search =
            isset( $request['finance_name_search'] ) && ! is_array( $request['finance_name_search'] )
                ? sanitize_text_field( wp_unslash( $request['finance_name_search'] ) )
                : '';

        $lesson_date_from =
            isset(
                $request['finance_lesson_date_from']
            )
                ? self::sanitize_report_date(
                    $request[
                        'finance_lesson_date_from'
                    ]
                )
                : '';

        $lesson_date_to =
            isset(
                $request['finance_lesson_date_to']
            )
                ? self::sanitize_report_date(
                    $request[
                        'finance_lesson_date_to'
                    ]
                )
                : '';

        $due_date_from =
            isset(
                $request['finance_due_date_from']
            )
                ? self::sanitize_report_date(
                    $request[
                        'finance_due_date_from'
                    ]
                )
                : '';

        $due_date_to =
            isset(
                $request['finance_due_date_to']
            )
                ? self::sanitize_report_date(
                    $request[
                        'finance_due_date_to'
                    ]
                )
                : '';

        $due_scope =
            isset(
                $request['finance_due_scope']
            )
                ? sanitize_key(
                    wp_unslash(
                        $request[
                            'finance_due_scope'
                        ]
                    )
                )
                : 'all';

        if (
            ! in_array(
                $due_scope,
                array(
                    'all',
                    'past_due',
                    'not_yet_due',
                    'no_due_date',
                ),
                true
            )
        ) {
            $due_scope = 'all';
        }

		$payment_statuses = self::sanitize_filter_keys(
			isset( $request['finance_payment_status'] )
				? $request['finance_payment_status']
				: array(),
			array_keys( self::get_payment_status_filter_options() )
		);
		$payment_types = self::sanitize_filter_keys(
			isset( $request['finance_payment_type'] )
				? $request['finance_payment_type']
				: array(),
			TutorHelper_Pro_Payment_Ledger::get_manual_payment_types()
		);

		$exclude_void = ! empty( $request['finance_exclude_void'] )
			&& ! is_array( $request['finance_exclude_void'] );

        $sort =
            isset(
                $request['finance_sort']
            )
                ? sanitize_key(
                    wp_unslash(
                        $request[
                            'finance_sort'
                        ]
                    )
                )
                : 'lesson_desc';

        if (
            ! in_array(
                $sort,
                array(
                    'lesson_asc',
                    'lesson_desc',
                    'due_asc',
                    'due_desc',
                ),
                true
            )
        ) {
            $sort = 'lesson_desc';
        }

        $group =
            isset(
                $request['finance_group']
            )
                ? sanitize_key(
                    wp_unslash(
                        $request[
                            'finance_group'
                        ]
                    )
                )
                : 'none';

        if (
            ! in_array(
                $group,
                array(
                    'none',
                    'student',
                    'due_date',
                    'payment_type',
                ),
                true
            )
        ) {
            $group = 'none';
        }

        $page =
            isset(
                $request['finance_page']
            )
                ? max(
                    1,
                    absint(
                        $request[
                            'finance_page'
                        ]
                    )
                )
                : 1;

        return array(
            'name_search' =>
                $name_search,

            'lesson_date_from' =>
                $lesson_date_from,

            'lesson_date_to' =>
                $lesson_date_to,

            'due_date_from' =>
                $due_date_from,

            'due_date_to' =>
                $due_date_to,

            'due_scope' =>
                $due_scope,

			'payment_statuses' =>
				$payment_statuses,

			'payment_types' =>
				$payment_types,

			'exclude_void' =>
				$exclude_void,

            'sort' =>
                $sort,

            'group' =>
                $group,

            'page' =>
                $page,
        );
    }


	/**
	 * Sanitise one or more read-only Finance filter keys.
	 *
	 * @param mixed $value   Submitted filter value.
	 * @param array $allowed Allowed filter values.
	 * @return array
	 */
	private static function sanitize_filter_keys( $value, $allowed ) {
		$values = is_array( $value ) ? wp_unslash( $value ) : array( wp_unslash( $value ) );
		$values = array_values( array_unique( array_map( 'sanitize_key', $values ) ) );
		return array_values( array_intersect( $values, $allowed ) );
	}

	/**
	 * Return selectable payment-status filters, including ledger-aware states.
	 *
	 * @return array
	 */
	private static function get_payment_status_filter_options() {
		return array(
			'not_required' => __( 'Free / not required', 'tutorhelper-pro' ),
			'unpaid'       => __( 'Unpaid', 'tutorhelper-pro' ),
			'partially_paid' => __( 'Partially paid', 'tutorhelper-pro' ),
			'paid'         => __( 'Paid', 'tutorhelper-pro' ),
			'credited'     => __( 'Credited', 'tutorhelper-pro' ),
			'failed'       => __( 'Failed', 'tutorhelper-pro' ),
			'refunded'     => __( 'Refunded', 'tutorhelper-pro' ),
			'expired'      => __( 'Expired', 'tutorhelper-pro' ),
		);
	}


    /**
     * Sanitise a Finance report date.
     *
     * @param mixed $value Raw date.
     *
     * @return string
     */
    private static function sanitize_report_date(
        $value
    ) {

        if ( is_array( $value ) ) {
            return '';
        }

        $value =
            sanitize_text_field(
                wp_unslash(
                    $value
                )
            );

        if (
            ! self::is_valid_due_date(
                $value
            )
        ) {
            return '';
        }

        return $value;
    }


    /**
     * Convert a site-local report date to UTC.
     *
     * @param string $date        Local Y-m-d date.
     * @param bool   $end_of_day  Whether to return the next day's boundary.
     *
     * @return string
     */
    private static function report_date_to_utc(
        $date,
        $end_of_day = false
    ) {

        try {
            $local =
                new DateTimeImmutable(
                    $date . ' 00:00:00',
                    wp_timezone()
                );

            if ( $end_of_day ) {
                $local =
                    $local->modify(
                        '+1 day'
                    );
            }

            return $local
                ->setTimezone(
                    new DateTimeZone(
                        'UTC'
                    )
                )
                ->format(
                    'Y-m-d H:i:s'
                );

        } catch ( Exception $exception ) {
            return '';
        }
    }


    /**
     * Query Core bookings with Pro Finance metadata.
     *
     * @param array $filters Finance report filters.
     *
     * @return array
     */
    private static function query_finance_report(
        $filters
    ) {
        global $wpdb;

        $bookings_table = TutorHelper_Booking_Records::get_table_name();
        $finance_table = TutorHelper_Pro_Database::get_table_name( 'booking_finance' );
        $ledger_table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );

        $empty = array(
            'bookings' => array(),
            'total' => 0,
            'total_pages' => 0,
            'page' => 1,
            'per_page' => 25,
            'total_minutes' => 0,
            'total_price_minor_units' => 0,
            'paid_minor_units' => 0,
            'upcoming_minor_units' => 0,
            'overdue_minor_units' => 0,
            'outstanding_minor_units' => 0,
            'credited_minor_units' => 0,
            'refunded_minor_units' => 0,
            'group_summaries' => array(),
        );

        if ( '' === $bookings_table || '' === $finance_table || '' === $ledger_table ) {
            return $empty;
        }

        $where = array( '1 = 1' );
        $params = array();

        if ( '' !== $filters['name_search'] ) {
            $like = '%' . $wpdb->esc_like( $filters['name_search'] ) . '%';
            $parent_student_ids = apply_filters(
                'tutorhelper_pro_finance_parent_student_ids_for_search',
                array(),
                $filters['name_search']
            );
            $parent_student_ids = array_values( array_filter( array_map( 'absint', (array) $parent_student_ids ) ) );

            $name_conditions = array(
                'b.student_user_id IN ( SELECT ID FROM %i WHERE display_name LIKE %s OR user_email LIKE %s )',
            );
            $params[] = $wpdb->users;
            $params[] = $like;
            $params[] = $like;

            if ( $parent_student_ids ) {
                $name_conditions[] = 'b.student_user_id IN (' . implode( ',', array_fill( 0, count( $parent_student_ids ), '%d' ) ) . ')';
                $params = array_merge( $params, $parent_student_ids );
            }

            $where[] = '( ' . implode( ' OR ', $name_conditions ) . ' )';
        }

        if ( '' !== $filters['lesson_date_from'] ) {
            $where[] = 'b.booking_start >= %s';
            $params[] = self::report_date_to_utc( $filters['lesson_date_from'] );
        }

        if ( '' !== $filters['lesson_date_to'] ) {
            $where[] = 'b.booking_start < %s';
            $params[] = self::report_date_to_utc( $filters['lesson_date_to'], true );
        }

        $today = wp_date( 'Y-m-d', null, wp_timezone() );

		self::append_payment_status_filters(
			$where,
			$params,
			$filters['payment_statuses'],
			$ledger_table
		);
		self::append_payment_type_filters(
			$where,
			$params,
			$filters['payment_types'],
			$ledger_table
		);

		if ( ! empty( $filters['exclude_void'] ) ) {
			$where[] = 'NOT ( b.status = %s AND b.payment_status = %s )';
			$params[] = TutorHelper_Booking_Records::STATUS_CANCELLED;
			$params[] = TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING;
		}

        if ( 'past_due' === $filters['due_scope'] ) {
            $where[] = 'b.payment_status = %s';
            $params[] = TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING;
            $where[] = 'f.payment_due_date IS NOT NULL';
            $where[] = 'f.payment_due_date <= %s';
            $params[] = $today;
        } elseif ( 'not_yet_due' === $filters['due_scope'] ) {
            $where[] = 'b.payment_status = %s';
            $params[] = TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING;
            $where[] = 'f.payment_due_date IS NOT NULL';
            $where[] = 'f.payment_due_date > %s';
            $params[] = $today;
        } elseif ( 'no_due_date' === $filters['due_scope'] ) {
            $where[] = 'b.payment_status = %s';
            $params[] = TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING;
            $where[] = 'f.payment_due_date IS NULL';
        }

        if ( 'no_due_date' !== $filters['due_scope'] ) {
            if ( '' !== $filters['due_date_from'] ) {
                $where[] = 'f.payment_due_date >= %s';
                $params[] = $filters['due_date_from'];
            }

            if ( '' !== $filters['due_date_to'] ) {
                $where[] = 'f.payment_due_date <= %s';
                $params[] = $filters['due_date_to'];
            }
        }

        $where_sql = implode( ' AND ', $where );
        $order_sql = self::get_report_order_sql( $filters );
        $per_page = 25;

        $count_sql = "SELECT COUNT(*)
            FROM %i b
            LEFT JOIN %i f ON f.booking_id = b.id
            WHERE {$where_sql}";

        $total = absint(
            $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance reports must reflect current booking and due-date state.
                $wpdb->prepare(
                    $count_sql,
                    array_merge( array( $bookings_table, $finance_table ), $params )
                )
            )
        );

        $summary_select = self::get_finance_summary_select_sql();
        $summary_sql = "SELECT {$summary_select}
            FROM %i b
            LEFT JOIN %i f ON f.booking_id = b.id
            WHERE {$where_sql}";

        $summary_args = array_merge(
            self::get_finance_summary_arguments( $ledger_table, $today ),
            array( $bookings_table, $finance_table ),
            $params
        );

        $summary = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance summary must reflect the currently filtered booking data.
            $wpdb->prepare( $summary_sql, $summary_args )
        );

        $total_pages = 0 < $total ? (int) ceil( $total / $per_page ) : 0;
        $page = max( 1, absint( $filters['page'] ) );

        if ( 0 < $total_pages && $page > $total_pages ) {
            $page = $total_pages;
        }

        $offset = ( $page - 1 ) * $per_page;
        $query_sql = "SELECT b.*, f.payment_due_date,
            (
                SELECT ft_display.manual_payment_type
                FROM %i ft_display
                WHERE ft_display.booking_id = b.id
                AND ft_display.manual_payment_type <> ''
                ORDER BY ft_display.transaction_date DESC, ft_display.id DESC
                LIMIT 1
            ) AS manual_payment_type
            FROM %i b
            LEFT JOIN %i f ON f.booking_id = b.id
            WHERE {$where_sql}
            ORDER BY {$order_sql}
            LIMIT %d
            OFFSET %d";

        $query_args = array_merge(
            array( $ledger_table, $bookings_table, $finance_table ),
            $params,
            array( $per_page, $offset )
        );

        $results = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance reports must reflect current booking and due-date state.
            $wpdb->prepare( $query_sql, $query_args )
        );

        $values = self::normalise_finance_summary( $summary );

        return array_merge(
            $empty,
            array(
                'bookings' => is_array( $results ) ? $results : array(),
                'total' => $total,
                'total_pages' => $total_pages,
                'page' => $page,
                'per_page' => $per_page,
                'group_summaries' => self::query_group_summaries(
                    $filters,
                    $where_sql,
                    $params,
                    $bookings_table,
                    $finance_table,
                    $ledger_table,
                    $today
                ),
            ),
            $values
        );
    }

	/**
	 * Add ledger-aware payment status conditions to a Finance report query.
	 *
	 * @param array  $where        SQL conditions.
	 * @param array  $params       Prepared query arguments.
	 * @param array  $statuses     Selected status keys.
	 * @param string $ledger_table Finance ledger table.
	 * @return void
	 */
	private static function append_payment_status_filters( &$where, &$params, $statuses, $ledger_table ) {
		if ( empty( $statuses ) ) {
			return;
		}

		$conditions = array();
		foreach ( $statuses as $status ) {
			switch ( $status ) {
				case 'unpaid':
					$conditions[] = '( b.payment_status = %s AND NOT EXISTS ( SELECT 1 FROM %i ft_unpaid WHERE ft_unpaid.booking_id = b.id AND ft_unpaid.transaction_type IN (%s, %s, %s) ) )';
					$params = array_merge( $params, array( TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING, $ledger_table, TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT, TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT, TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED ) );
					break;
				case 'partially_paid':
					$conditions[] = '( b.payment_status = %s AND EXISTS ( SELECT 1 FROM %i ft_partial WHERE ft_partial.booking_id = b.id AND ft_partial.transaction_type IN (%s, %s, %s) ) )';
					$params = array_merge( $params, array( TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING, $ledger_table, TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT, TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT, TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED ) );
					break;
				case 'credited':
					/*
					 * Credit use is a payment source, not a Core payment status.
					 * Restrict it to completed bookings so this option cannot
					 * leak a pending booking into a completed-payment filter.
					 */
					$conditions[] = '( b.payment_status = %s AND EXISTS ( SELECT 1 FROM %i ft_credit WHERE ft_credit.booking_id = b.id AND ft_credit.transaction_type = %s ) )';
					$params = array_merge( $params, array( TutorHelper_Booking_Records::PAYMENT_STATUS_PAID, $ledger_table, TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED ) );
					break;
				case 'not_required':
				case 'paid':
				case 'failed':
				case 'refunded':
				case 'expired':
					$conditions[] = 'b.payment_status = %s';
					$params[] = $status;
					break;
			}
		}

		if ( ! empty( $conditions ) ) {
			$where[] = '( ' . implode( ' OR ', $conditions ) . ' )';
		}
	}

	/**
	 * Add selected manual payment type conditions to a Finance report query.
	 *
	 * @param array  $where         SQL conditions.
	 * @param array  $params        Prepared query arguments.
	 * @param array  $payment_types Selected payment types.
	 * @param string $ledger_table  Finance ledger table.
	 * @return void
	 */
	private static function append_payment_type_filters( &$where, &$params, $payment_types, $ledger_table ) {
		if ( empty( $payment_types ) ) {
			return;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $payment_types ), '%s' ) );
		$where[] = 'EXISTS ( SELECT 1 FROM %i ft_type WHERE ft_type.booking_id = b.id AND ft_type.manual_payment_type IN (' . $placeholders . ') )';
		$params = array_merge( $params, array( $ledger_table ), $payment_types );
	}


    /**
     * Return the reusable aggregate columns for Finance summaries.
     *
     * @return string
     */
    private static function get_finance_summary_select_sql() {
        $balance_sql = self::get_outstanding_balance_sql();

        return "COALESCE(SUM(CASE WHEN b.status <> %s THEN TIMESTAMPDIFF(MINUTE, b.booking_start, b.booking_end) ELSE 0 END), 0) AS total_minutes,
            COALESCE(SUM(CASE WHEN b.status <> %s THEN b.price_minor_units ELSE 0 END), 0) AS total_price_minor_units,
            COALESCE(SUM(CASE WHEN b.status <> %s AND b.payment_status = %s THEN b.price_minor_units ELSE 0 END), 0) AS paid_minor_units,
            COALESCE(SUM(CASE WHEN b.status <> %s AND b.payment_status = %s AND (f.payment_due_date IS NULL OR f.payment_due_date > %s) THEN {$balance_sql} ELSE 0 END), 0) AS upcoming_minor_units,
            COALESCE(SUM(CASE WHEN b.status <> %s AND b.payment_status = %s AND f.payment_due_date IS NOT NULL AND f.payment_due_date <= %s THEN {$balance_sql} ELSE 0 END), 0) AS overdue_minor_units,
            COALESCE(SUM((SELECT COALESCE(SUM(ft.amount_minor_units), 0) FROM %i ft WHERE ft.booking_id = b.id AND ft.transaction_type = %s)), 0) AS refunded_minor_units,
            COALESCE(SUM((SELECT COALESCE(SUM(ft.amount_minor_units), 0) FROM %i ft WHERE ft.booking_id = b.id AND ft.transaction_type = %s)), 0) AS credited_minor_units";
    }

    /**
     * Return SQL that calculates the unsettled balance for one booking.
     *
     * @return string
     */
    private static function get_outstanding_balance_sql() {
        return "GREATEST(
            0,
            b.price_minor_units - COALESCE(
                (
                    SELECT SUM(
                        CASE
                            WHEN ftb.transaction_type IN ( %s, %s, %s )
                            THEN ftb.amount_minor_units
                            WHEN ftb.transaction_type IN ( %s, %s )
                            THEN -ftb.amount_minor_units
                            ELSE 0
                        END
                    )
                    FROM %i ftb
                    WHERE ftb.booking_id = b.id
                ),
                0
            )
        )";
    }

    /**
     * Return arguments matching one outstanding-balance expression.
     *
     * @param string $ledger_table Finance ledger table.
     *
     * @return array
     */
    private static function get_outstanding_balance_arguments(
        $ledger_table
    ) {
        return array(
            TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
            TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT,
            TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
            TutorHelper_Pro_Payment_Ledger::TYPE_REFUND,
            TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED,
            $ledger_table,
        );
    }

    /**
     * Return arguments matching the reusable Finance aggregate columns.
     *
     * @param string $ledger_table Finance ledger table.
     * @param string $today        Site-local date.
     *
     * @return array
     */
    private static function get_finance_summary_arguments(
        $ledger_table,
        $today
    ) {
        return array_merge(
            array(
                TutorHelper_Booking_Records::STATUS_CANCELLED,
                TutorHelper_Booking_Records::STATUS_CANCELLED,
                TutorHelper_Booking_Records::STATUS_CANCELLED,
                TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
                TutorHelper_Booking_Records::STATUS_CANCELLED,
                TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING,
                $today,
            ),
            self::get_outstanding_balance_arguments( $ledger_table ),
            array(
                TutorHelper_Booking_Records::STATUS_CANCELLED,
                TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING,
                $today,
            ),
            self::get_outstanding_balance_arguments( $ledger_table ),
            array(
                $ledger_table,
                TutorHelper_Pro_Payment_Ledger::TYPE_REFUND,
                $ledger_table,
                TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED,
            )
        );
    }

    /**
     * Convert a summary row into consistently named integer values.
     *
     * @param object|null $summary Database summary row.
     *
     * @return array
     */
    private static function normalise_finance_summary(
        $summary
    ) {
        $keys = array(
            'total_minutes',
            'total_price_minor_units',
            'paid_minor_units',
            'upcoming_minor_units',
            'overdue_minor_units',
            'refunded_minor_units',
            'credited_minor_units',
        );
        $values = array();

        foreach ( $keys as $key ) {
            $values[ $key ] = isset( $summary->$key ) ? (int) $summary->$key : 0;
        }

        $values['outstanding_minor_units'] =
            $values['upcoming_minor_units']
            + $values['overdue_minor_units'];

        return $values;
    }

    /**
     * Calculate full filtered subtotals for grouped reports.
     *
     * @return array
     */
    private static function query_group_summaries(
        $filters,
        $where_sql,
        $params,
        $bookings_table,
        $finance_table,
        $ledger_table,
        $today
    ) {
        global $wpdb;

        if ( 'student' === $filters['group'] ) {
            $group_select = "CONCAT('student-', b.student_user_id)";
        } elseif ( 'due_date' === $filters['group'] ) {
            $group_select = "COALESCE(f.payment_due_date, 'no-due-date')";
        } elseif ( 'payment_type' === $filters['group'] ) {
            return array();
        } else {
            return array();
        }

        $summary_select = self::get_finance_summary_select_sql();
        $sql = "SELECT {$group_select} AS group_key, {$summary_select}
            FROM %i b
            LEFT JOIN %i f ON f.booking_id = b.id
            WHERE {$where_sql}
            GROUP BY group_key";

        $args = array_merge(
            self::get_finance_summary_arguments( $ledger_table, $today ),
            array( $bookings_table, $finance_table ),
            $params
        );

        $rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Group headings must reflect the complete filtered group, not only the current page.
            $wpdb->prepare( $sql, $args )
        );
        $groups = array();

        foreach ( $rows as $row ) {
            $groups[ sanitize_text_field( $row->group_key ) ] =
                self::normalise_finance_summary( $row );
        }

        return $groups;
    }

    /**
     * Build the current calendar month's lesson-date filters.
     *
     * @return array
     */
    private static function get_current_month_filters() {
        return self::get_report_filters(
            array(
                'finance_lesson_date_from' => wp_date( 'Y-m-01', null, wp_timezone() ),
                'finance_lesson_date_to' => wp_date( 'Y-m-t', null, wp_timezone() ),
            )
        );
    }

    /**
     * Populate Pro Finance cards in the Core Booking Hub.
     *
     * @param array $cards Core summary cards.
     *
     * @return array
     */
    public static function filter_booking_hub_summary_cards(
        $cards
    ) {
        if ( ! isset( $cards['awaiting_payment'], $cards['financial_actions'] ) ) {
            return $cards;
        }

        $currency = TutorHelper_Currency::get_currency();
        $today = new DateTimeImmutable( 'today', wp_timezone() );
        $end = $today->modify( '+30 days' );
        $finance_url = self::get_view_url(
            self::VIEW_ALL,
            array(
                'finance_due_date_from' => $today->format( 'Y-m-d' ),
                'finance_due_date_to' => $end->format( 'Y-m-d' ),
                'finance_sort' => 'due_asc',
            )
        );

        $cards['awaiting_payment'] = array(
            'label' => __( 'Awaiting payment', 'tutorhelper-pro' ),
            'icon' => 'dashicons-money-alt',
            'value' => TutorHelper_Currency::format_minor_units(
                self::get_awaiting_payment_total( $today, $end ),
                $currency
            ),
            'status' => 'available',
            'description' => __( 'Unpaid and due in the next 30 days', 'tutorhelper-pro' ),
            'url' => $finance_url,
        );

        $cards['financial_actions'] = array(
            'label' => __( 'Financial actions', 'tutorhelper-pro' ),
            'icon' => 'dashicons-chart-line',
            'value' => self::get_pending_refund_request_count(),
            'status' => 'available',
            'description' => __( 'Refund requests awaiting action', 'tutorhelper-pro' ),
            'url' => self::get_view_url( self::VIEW_ALL ),
        );

        return $cards;
    }

    /**
     * Return the unpaid value due from today through the next 30 days.
     *
     * @return int
     */
    private static function get_awaiting_payment_total(
        $today,
        $end
    ) {
        global $wpdb;

        $bookings_table = TutorHelper_Booking_Records::get_table_name();
        $finance_table = TutorHelper_Pro_Database::get_table_name( 'booking_finance' );
        $ledger_table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );

        if ( '' === $bookings_table || '' === $finance_table || '' === $ledger_table ) {
            return 0;
        }

        $balance_sql = self::get_outstanding_balance_sql();
        $sql = "SELECT COALESCE(SUM({$balance_sql}), 0)
            FROM %i b
            INNER JOIN %i f ON f.booking_id = b.id
            WHERE b.status <> %s
            AND b.payment_status = %s
            AND f.payment_due_date >= %s
            AND f.payment_due_date <= %s";
        $args = array_merge(
            self::get_outstanding_balance_arguments( $ledger_table ),
            array(
                $bookings_table,
                $finance_table,
                TutorHelper_Booking_Records::STATUS_CANCELLED,
                TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING,
                $today->format( 'Y-m-d' ),
                $end->format( 'Y-m-d' ),
            )
        );

        return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Booking Hub finance cards must reflect current payment state.
            $wpdb->prepare( $sql, $args )
        );
    }

    /**
     * Count refund requests that still require tutor action.
     *
     * @return int
     */
    private static function get_pending_refund_request_count() {
        global $wpdb;

        $table = TutorHelper_Pro_Database::get_table_name( 'credit_refund_requests' );
        if ( '' === $table ) {
            return 0;
        }

        return absint(
            $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Booking Hub action counts must reflect current requests.
                $wpdb->prepare(
                    'SELECT COUNT(*) FROM %i WHERE status = %s',
                    $table,
                    'pending'
                )
            )
        );
    }

    /**
     * Format a total duration in hours and minutes.
     *
     * @param int $minutes Total minutes.
     *
     * @return string
     */
    private static function format_total_duration(
        $minutes
    ) {

        $minutes =
            max(
                0,
                absint(
                    $minutes
                )
            );

        $hours =
            (int) floor(
                $minutes / 60
            );

        $remaining_minutes =
            $minutes % 60;

        if (
            0 < $hours
            && 0 < $remaining_minutes
        ) {
            return sprintf(
                /* translators: 1: hours, 2: minutes. */
                __(
                    '%1$d hr %2$d min',
                    'tutorhelper-pro'
                ),
                $hours,
                $remaining_minutes
            );
        }

        if ( 0 < $hours ) {
            return sprintf(
                /* translators: %d: hours. */
                _n(
                    '%d hour',
                    '%d hours',
                    $hours,
                    'tutorhelper-pro'
                ),
                $hours
            );
        }

        return sprintf(
            /* translators: %d: minutes. */
            _n(
                '%d minute',
                '%d minutes',
                $remaining_minutes,
                'tutorhelper-pro'
            ),
            $remaining_minutes
        );
    }


    /**
     * Return the Finance report ORDER BY clause.
     *
     * Values are selected only from hard-coded SQL fragments.
     *
     * @param array $filters Finance report filters.
     *
     * @return string
     */
    private static function get_report_order_sql(
        $filters
    ) {

        $sort_sql = '';

        switch (
            $filters['sort']
        ) {
            case 'lesson_asc':
                $sort_sql =
                    'b.booking_start ASC';
                break;

            case 'due_asc':
                $sort_sql =
                    'CASE
                        WHEN f.payment_due_date IS NULL
                            THEN 1
                        ELSE 0
                    END ASC,
                    f.payment_due_date ASC,
                    b.booking_start ASC';
                break;

            case 'due_desc':
                $sort_sql =
                    'CASE
                        WHEN f.payment_due_date IS NULL
                            THEN 1
                        ELSE 0
                    END ASC,
                    f.payment_due_date DESC,
                    b.booking_start DESC';
                break;

            case 'lesson_desc':
            default:
                $sort_sql =
                    'b.booking_start DESC';
                break;
        }

        if (
            'student'
            ===
            $filters['group']
        ) {
            return
                'b.student_name ASC, '
                . $sort_sql;
        }

        if (
            'due_date'
            ===
            $filters['group']
        ) {
            return
                'CASE
                    WHEN f.payment_due_date IS NULL
                        THEN 1
                    ELSE 0
                END ASC,
                f.payment_due_date ASC, '
                . $sort_sql;
        }

        return $sort_sql;
    }



}