<?php
/**
 * Tutor-facing Finance statement PDF export.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates a filtered statement of account for each student.
 */
final class TutorHelper_Pro_Finance_Statements {

	/**
	 * Admin-post action.
	 *
	 * @var string
	 */
	const EXPORT_ACTION = 'tutorhelper_pro_export_finance_statements';

	/**
	 * Register statement exports.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'admin_post_' . self::EXPORT_ACTION,
			array( __CLASS__, 'handle_export' )
		);
	}

	/**
	 * Authorise and generate the statement PDF.
	 *
	 * @return void
	 */
	public static function handle_export() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to export Finance statements.', 'tutorhelper-pro' ) );
		}

		check_admin_referer(
			TutorHelper_Pro_Finance_Admin::EXPORT_NONCE,
			'_tutorhelper_finance_export_nonce'
		);

		try {
			$report = TutorHelper_Pro_Finance_Admin::get_statement_export_data( $_GET );
			$bookings = isset( $report['bookings'] ) && is_array( $report['bookings'] )
				? $report['bookings']
				: array();
			$booking_types = isset( $report['booking_types'] ) && is_array( $report['booking_types'] )
				? $report['booking_types']
				: array();

			self::stream_pdf( $bookings, $booking_types );
		} catch ( Throwable $exception ) {
			TutorHelper_Logger::error(
				'Finance statement export failed.',
				array(
					'message' => $exception->getMessage(),
					'user_id' => get_current_user_id(),
				)
			);

			wp_die(
				esc_html__(
					'The Finance statement could not be generated. Please review TutorHelper diagnostics and try again.',
					'tutorhelper-pro'
				)
			);
		}
	}

	/**
	 * Render the filtered Finance data as a per-student statement PDF.
	 *
	 * @param array $bookings      Filtered booking rows.
	 * @param array $booking_types Booking types keyed by ID.
	 * @return void
	 */
	private static function stream_pdf( $bookings, $booking_types ) {
		self::load_dompdf();

		if ( ! class_exists( '\\Dompdf\\Dompdf' ) ) {
			throw new RuntimeException( 'Core Dompdf is unavailable.' );
		}

		$statements = self::build_statements( $bookings, $booking_types );
		$branding = class_exists( 'TutorHelper_Pro_Branding' )
			? TutorHelper_Pro_Branding::get_all()
			: array();
		$banner = self::branding_image_data_uri( 'email_banner_attachment_id' );

		ob_start();
		?>
		<!doctype html>
		<html>
		<head>
			<meta charset="utf-8">
			<style>
				@page { margin: 16mm 14mm 22mm; }
				body {
					color: <?php echo esc_html( self::brand_colour( $branding, 'text_color', '#1d2327' ) ); ?>;
					font-family: DejaVu Sans, sans-serif;
					font-size: 9.5pt;
					line-height: 1.35;
				}
				.tutorhelper-statement { page-break-after: always; }
				.tutorhelper-statement.is-last { page-break-after: auto; }
				.report-header {
					background: <?php echo esc_html( self::brand_colour( $branding, 'primary_color', '#143f4d' ) ); ?>;
					color: #fff;
					margin: -16mm -14mm 18px;
				}
				.report-header img { display: block; height: auto; width: 100%; }
				.report-header__brand { font-size: 20pt; font-weight: bold; padding: 24px 30px; }
				.report-header__title {
					border-top: 4px solid <?php echo esc_html( self::brand_colour( $branding, 'accent_color', '#f46b3b' ) ); ?>;
					padding: 14px 30px;
				}
				.report-header h1 { color: #fff; font-size: 22pt; margin: 0; }
				.report-header p { margin: 4px 0 0; }
				.statement-student {
					background: #f5f7f8;
					border-left: 5px solid <?php echo esc_html( self::brand_colour( $branding, 'accent_color', '#f46b3b' ) ); ?>;
					margin: 0 0 14px;
					padding: 12px;
				}
				table { border-collapse: collapse; margin: 8px 0 16px; width: 100%; }
				thead { display: table-header-group; }
				tr { page-break-inside: avoid; }
				th {
					background: <?php echo esc_html( self::brand_colour( $branding, 'primary_color', '#143f4d' ) ); ?>;
					color: #fff;
					font-size: 8.5pt;
					padding: 7px;
					text-align: left;
				}
				td {
					border: 1px solid #c8d6dc;
					padding: 7px;
					vertical-align: top;
				}
				tr:nth-child(even) td { background: #f7f2e9; }
				.money { text-align: right; white-space: nowrap; }
				.balance-row td {
					border-top: 2px solid <?php echo esc_html( self::brand_colour( $branding, 'primary_color', '#143f4d' ) ); ?>;
					font-weight: bold;
					padding-top: 8px;
				}
				.empty {
					background: #fff3df;
					padding: 12px;
				}
			</style>
		</head>
		<body>
		<?php if ( empty( $statements ) ) : ?>
			<section class="tutorhelper-statement is-last">
				<?php self::render_pdf_header( $branding, $banner ); ?>
				<p class="empty"><?php esc_html_e( 'No finance records match the selected filters.', 'tutorhelper-pro' ); ?></p>
			</section>
		<?php endif; ?>

		<?php foreach ( $statements as $index => $statement ) : ?>
			<section class="tutorhelper-statement<?php echo esc_attr( $index === count( $statements ) - 1 ? ' is-last' : '' ); ?>">
				<?php self::render_pdf_header( $branding, $banner ); ?>

				<div class="statement-student">
					<strong><?php esc_html_e( 'Student:', 'tutorhelper-pro' ); ?></strong>
					<?php echo esc_html( $statement['student_name'] ); ?>
				</div>

				<table>
					<thead>
						<tr>
							<th><?php esc_html_e( 'Date', 'tutorhelper-pro' ); ?></th>
							<th><?php esc_html_e( 'Description', 'tutorhelper-pro' ); ?></th>
							<th><?php esc_html_e( 'Reference', 'tutorhelper-pro' ); ?></th>
							<th class="money"><?php esc_html_e( 'Charge', 'tutorhelper-pro' ); ?></th>
							<th class="money"><?php esc_html_e( 'Payment / credit', 'tutorhelper-pro' ); ?></th>
							<th class="money"><?php esc_html_e( 'Balance', 'tutorhelper-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $statement['rows'] as $row ) : ?>
							<tr>
								<td><?php echo esc_html( $row['date'] ); ?></td>
								<td><?php echo esc_html( $row['description'] ); ?></td>
								<td><?php echo esc_html( $row['reference'] ); ?></td>
								<td class="money"><?php echo esc_html( self::format_amount( $row['charge'], $statement['currency'] ) ); ?></td>
								<td class="money"><?php echo esc_html( self::format_amount( $row['credit'], $statement['currency'] ) ); ?></td>
								<td class="money"><?php echo esc_html( self::format_amount( $row['balance'], $statement['currency'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
						<tr class="balance-row">
							<td colspan="3"><?php esc_html_e( 'Statement total', 'tutorhelper-pro' ); ?></td>
							<td class="money"><?php echo esc_html( self::format_amount( $statement['charges'], $statement['currency'] ) ); ?></td>
							<td class="money"><?php echo esc_html( self::format_amount( $statement['credits'], $statement['currency'] ) ); ?></td>
							<td class="money"><?php echo esc_html( self::format_amount( $statement['balance'], $statement['currency'] ) ); ?></td>
						</tr>
					</tbody>
				</table>
			</section>
		<?php endforeach; ?>
		</body>
		</html>
		<?php
		$html = ob_get_clean();

		$pdf = new \Dompdf\Dompdf( array( 'isRemoteEnabled' => false ) );
		$pdf->loadHtml( $html, 'UTF-8' );
		$pdf->setPaper( 'A4', 'portrait' );
		$pdf->render();
		$font = $pdf->getFontMetrics()->get_font( 'DejaVu Sans', 'normal' );
		$pdf->getCanvas()->page_text(
			36,
			806,
			self::business_name( $branding ) . '  ·  ' . __( 'Page {PAGE_NUM} of {PAGE_COUNT}', 'tutorhelper-pro' ),
			$font,
			8,
			array( 0.25, 0.25, 0.25 )
		);
		$pdf->stream(
			'tutorhelper-statements-' . wp_date( 'Y-m-d', null, wp_timezone() ) . '.pdf',
			array( 'Attachment' => true )
		);
		exit;
	}

	/**
	 * Build student-grouped statement rows.
	 *
	 * @param array $bookings      Filtered booking rows.
	 * @param array $booking_types Booking type map.
	 * @return array
	 */
	private static function build_statements( $bookings, $booking_types ) {
		$by_student = array();
		$booking_ids = array();

		foreach ( $bookings as $booking ) {
			if ( ! is_object( $booking ) || empty( $booking->id ) ) {
				continue;
			}

			$student_id = absint( $booking->student_user_id );
			$key = $student_id ? (string) $student_id : 'unknown-' . absint( $booking->id );
			if ( ! isset( $by_student[ $key ] ) ) {
				$by_student[ $key ] = array(
					'student_name' => ! empty( $booking->student_name )
						? sanitize_text_field( $booking->student_name )
						: __( 'Unknown student', 'tutorhelper-pro' ),
					'bookings' => array(),
				);
			}

			$by_student[ $key ]['bookings'][] = $booking;
			$booking_ids[] = absint( $booking->id );
		}

		if ( empty( $by_student ) ) {
			return array();
		}

		uasort(
			$by_student,
			static function ( $a, $b ) {
				return strcasecmp( $a['student_name'], $b['student_name'] );
			}
		);

		$transactions = self::get_transactions_by_booking( $booking_ids );
		$statements = array();

		foreach ( $by_student as $student ) {
			$entries = array();
			$currency = '';
			foreach ( $student['bookings'] as $booking ) {
				$booking_id = absint( $booking->id );
				$currency = $currency ?: self::booking_currency( $booking );
				$entries[] = self::booking_entry( $booking, $booking_types );

				if ( isset( $transactions[ $booking_id ] ) ) {
					foreach ( $transactions[ $booking_id ] as $transaction ) {
						$entries[] = self::transaction_entry( $transaction );
					}
				}
			}

			usort(
				$entries,
				static function ( $a, $b ) {
					if ( $a['timestamp'] === $b['timestamp'] ) {
						return $a['sequence'] <=> $b['sequence'];
					}
					return $a['timestamp'] <=> $b['timestamp'];
				}
			);

			$running_balance = 0;
			$charges = 0;
			$credits = 0;
			$rows = array();
			foreach ( $entries as $entry ) {
				$charge = (int) $entry['charge'];
				$credit = (int) $entry['credit'];
				$running_balance += $charge - $credit;
				$charges += $charge;
				$credits += $credit;
				$rows[] = array(
					'date' => $entry['date'],
					'description' => $entry['description'],
					'reference' => $entry['reference'],
					'charge' => $charge,
					'credit' => $credit,
					'balance' => $running_balance,
				);
			}

			$statements[] = array(
				'student_name' => $student['student_name'],
				'rows' => $rows,
				'currency' => $currency ?: TutorHelper_Currency::get_currency(),
				'charges' => $charges,
				'credits' => $credits,
				'balance' => $running_balance,
			);
		}

		return $statements;
	}

	/**
	 * Return ledger transactions keyed by booking ID.
	 *
	 * @param array $booking_ids Booking IDs.
	 * @return array
	 */
	private static function get_transactions_by_booking( $booking_ids ) {
		global $wpdb;

		$booking_ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $booking_ids ) ) ) );
		if ( empty( $booking_ids ) ) {
			return array();
		}

		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		if ( '' === $table ) {
			return array();
		}

		$transactions = array();
		foreach ( array_chunk( $booking_ids, 500 ) as $ids ) {
			$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
			$sql = 'SELECT id, booking_id, transaction_type, amount_minor_units, currency, description, provider_reference, manual_payment_type, transaction_date
				FROM %i
				WHERE transaction_type <> %s
				AND booking_id IN (' . $placeholders . ')
				ORDER BY transaction_date ASC, id ASC';

			$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Statements must show the current immutable ledger.
				$wpdb->prepare(
					$sql,
					array_merge(
						array( $table, TutorHelper_Pro_Payment_Ledger::TYPE_BOOKING_CHARGE ),
						$ids
					)
				)
			);

			foreach ( (array) $rows as $row ) {
				$booking_id = absint( $row->booking_id );
				if ( ! isset( $transactions[ $booking_id ] ) ) {
					$transactions[ $booking_id ] = array();
				}
				$transactions[ $booking_id ][] = $row;
			}
		}

		return $transactions;
	}

	/**
	 * Format a booking as a statement charge.
	 *
	 * @param object $booking       Booking record.
	 * @param array  $booking_types Booking type map.
	 * @return array
	 */
	private static function booking_entry( $booking, $booking_types ) {
		$type_id = absint( $booking->booking_type_id );
		$type = isset( $booking_types[ $type_id ] ) ? $booking_types[ $type_id ] : null;
		$title = $type && ! empty( $type->title )
			? sanitize_text_field( $type->title )
			: __( 'Lesson', 'tutorhelper-pro' );

		return array(
			'timestamp' => self::utc_timestamp( $booking->booking_start ),
			'sequence' => 0,
			'date' => self::format_datetime( $booking->booking_start ),
			'description' => sprintf( __( 'Lesson charge: %s', 'tutorhelper-pro' ), $title ),
			'reference' => sprintf( __( 'Lesson #%d', 'tutorhelper-pro' ), absint( $booking->id ) ),
			'charge' => absint( $booking->price_minor_units ),
			'credit' => 0,
		);
	}

	/**
	 * Format a ledger transaction as a statement entry.
	 *
	 * @param object $transaction Ledger transaction.
	 * @return array
	 */
	private static function transaction_entry( $transaction ) {
		$type = sanitize_key( $transaction->transaction_type );
		$amount = (int) $transaction->amount_minor_units;
		$labels = array(
			TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT => __( 'Payment received', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT => __( 'Deposit received', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_REFUND => __( 'Refund issued', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED => __( 'Account credit issued', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED => __( 'Account credit used', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_REVERSED => __( 'Account credit reversed', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_ADJUSTMENT => __( 'Account adjustment', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_BOOKING_CHARGE => __( 'Lesson charge adjustment', 'tutorhelper-pro' ),
		);

		$credit_types = array(
			TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
			TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT,
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
		);

		$charge = 0;
		$credit = 0;
		if ( in_array( $type, $credit_types, true ) ) {
			$credit = abs( $amount );
		} else {
			$charge = abs( $amount );
		}

		$description = ! empty( $transaction->description )
			? sanitize_text_field( $transaction->description )
			: ( isset( $labels[ $type ] ) ? $labels[ $type ] : self::readable_key( $type ) );
		$reference = ! empty( $transaction->provider_reference )
			? sanitize_text_field( $transaction->provider_reference )
			: sprintf( __( 'Transaction #%d', 'tutorhelper-pro' ), absint( $transaction->id ) );

		return array(
			'timestamp' => self::utc_timestamp( $transaction->transaction_date ),
			'sequence' => 1,
			'date' => self::format_datetime( $transaction->transaction_date ),
			'description' => $description,
			'reference' => $reference,
			'charge' => $charge,
			'credit' => $credit,
		);
	}


	/**
	 * Render the same branded banner treatment used by Student Reports.
	 *
	 * @param array  $branding Branding settings.
	 * @param string $banner   Local banner image data URI.
	 * @return void
	 */
	private static function render_pdf_header( $branding, $banner ) {
		?>
		<header class="report-header">
			<?php if ( '' !== $banner ) : ?>
				<img src="<?php echo esc_attr( $banner ); ?>" alt="" />
			<?php else : ?>
				<div class="report-header__brand"><?php echo esc_html( self::business_name( $branding ) ); ?></div>
			<?php endif; ?>
			<div class="report-header__title">
				<h1><?php esc_html_e( 'Statement of account', 'tutorhelper-pro' ); ?></h1>
				<p>
					<?php
					echo esc_html(
						sprintf(
							__( 'Prepared %s', 'tutorhelper-pro' ),
							wp_date( get_option( 'date_format' ), null, wp_timezone() )
						)
					);
					?>
				</p>
			</div>
		</header>
		<?php
	}

	/**
	 * Convert a branding image from the Media Library into a Dompdf-safe URI.
	 *
	 * @param string $key Branding option key.
	 * @return string
	 */
	private static function branding_image_data_uri( $key ) {
		$attachment_id = class_exists( 'TutorHelper_Pro_Branding' )
			? absint( TutorHelper_Pro_Branding::get( $key ) )
			: 0;

		return self::attachment_data_uri( $attachment_id );
	}

	/**
	 * Read a local Media Library image as a data URI.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return string
	 */
	private static function attachment_data_uri( $attachment_id ) {
		$attachment_id = absint( $attachment_id );
		$path = $attachment_id ? get_attached_file( $attachment_id ) : '';

		if ( ! $path || ! file_exists( $path ) ) {
			return '';
		}

		global $wp_filesystem;
		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( ! WP_Filesystem() || ! $wp_filesystem ) {
			return '';
		}

		$contents = $wp_filesystem->get_contents( $path );
		$mime = get_post_mime_type( $attachment_id );

		return $contents && $mime
			? 'data:' . sanitize_mime_type( $mime ) . ';base64,' . base64_encode( $contents )
			: '';
	}


	/**
	 * Include Dompdf bundled with TutorHelper Bookings.
	 *
	 * @return void
	 */
	private static function load_dompdf() {
		if ( class_exists( '\\Dompdf\\Dompdf' ) || ! defined( 'TUTORHELPER_BOOKINGS_PATH' ) ) {
			return;
		}

		$autoload = TUTORHELPER_BOOKINGS_PATH . 'vendor/dompdf/autoload.inc.php';
		if ( file_exists( $autoload ) ) {
			require_once $autoload;
		}
	}

	/**
	 * Return one booking's currency.
	 *
	 * @param object $booking Booking record.
	 * @return string
	 */
	private static function booking_currency( $booking ) {
		return ! empty( $booking->currency )
			? strtoupper( sanitize_text_field( $booking->currency ) )
			: TutorHelper_Currency::get_currency();
	}

	/**
	 * Format a stored UTC date/time for the statement.
	 *
	 * @param string $value Stored date/time.
	 * @return string
	 */
	private static function format_datetime( $value ) {
		$timestamp = self::utc_timestamp( $value );
		if ( ! $timestamp ) {
			return '—';
		}

		return wp_date(
			get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
			$timestamp,
			wp_timezone()
		);
	}

	/**
	 * Convert a stored UTC date/time to a timestamp.
	 *
	 * @param string $value Stored date/time.
	 * @return int
	 */
	private static function utc_timestamp( $value ) {
		try {
			$date = new DateTimeImmutable( $value, new DateTimeZone( 'UTC' ) );
			return $date->getTimestamp();
		} catch ( Exception $exception ) {
			return 0;
		}
	}

	/**
	 * Format a non-zero amount.
	 *
	 * @param int    $amount   Amount in minor units.
	 * @param string $currency Currency code.
	 * @return string
	 */
	private static function format_amount( $amount, $currency ) {
		return 0 === (int) $amount
			? '—'
			: TutorHelper_Currency::format_minor_units( abs( (int) $amount ), $currency );
	}

	/**
	 * Return a usable branded colour.
	 *
	 * @param array  $branding Branding settings.
	 * @param string $key      Setting key.
	 * @param string $fallback Fallback colour.
	 * @return string
	 */
	private static function brand_colour( $branding, $key, $fallback ) {
		$colour = isset( $branding[ $key ] ) ? sanitize_hex_color( $branding[ $key ] ) : '';
		return $colour ? $colour : $fallback;
	}

	/**
	 * Return a sanitised text branding setting.
	 *
	 * @param array  $branding Branding settings.
	 * @param string $key      Setting key.
	 * @return string
	 */
	private static function branding_text( $branding, $key ) {
		return isset( $branding[ $key ] )
			? sanitize_text_field( $branding[ $key ] )
			: '';
	}

	/**
	 * Return the statement business name.
	 *
	 * @param array $branding Branding settings.
	 * @return string
	 */
	private static function business_name( $branding ) {
		$name = self::branding_text( $branding, 'business_name' );
		return '' !== $name ? $name : get_bloginfo( 'name' );
	}

	/**
	 * Convert a key into a fallback display label.
	 *
	 * @param string $key Internal key.
	 * @return string
	 */
	private static function readable_key( $key ) {
		return ucwords( str_replace( '_', ' ', sanitize_key( $key ) ) );
	}
}
