<?php
/**
 * Tutor-entered booking payments for TutorHelper Pro Finance.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records full payments, partial payments and deposits against bookings.
 */
final class TutorHelper_Pro_Finance_Payments {

	const AJAX_ACTION = 'tutorhelper_pro_record_finance_payment';
	const NONCE_ACTION = 'tutorhelper_pro_record_finance_payment';
	const SCRIPT_HANDLE = 'tutorhelper-pro-finance-payments';
	const STYLE_HANDLE = 'tutorhelper-pro-finance-payments';

	public static function init() {
		add_action(
			'wp_ajax_' . self::AJAX_ACTION,
			array( __CLASS__, 'handle_record_payment' )
		);

		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' ),
			40
		);
	}

	public static function enqueue_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] )
			? sanitize_key( wp_unslash( $_GET['tab'] ) )
			: '';
		$view = isset( $_GET['finance_view'] ) && ! is_array( $_GET['finance_view'] )
			? sanitize_key( wp_unslash( $_GET['finance_view'] ) )
			: '';

		if (
			TutorHelper_Pro_Finance_Admin::TAB_KEY !== $tab
			|| TutorHelper_Pro_Finance_Admin::VIEW_ALL !== $view
		) {
			return;
		}

		$script_path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-finance-payments.js';
		$style_path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-finance-payments.css';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-finance-payments.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_PRO_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperProFinancePayments',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action' => self::AJAX_ACTION,
				'nonce' => wp_create_nonce( self::NONCE_ACTION ),
				'today' => wp_date( 'Y-m-d', null, wp_timezone() ),
				'bookings' => self::prepare_booking_summaries(),
				'labels' => array(
					'recordPayment' => __( 'Record payment', 'tutorhelper-pro' ),
					'recordSelected' => __( 'Record selected payment', 'tutorhelper-pro' ),
					'heading' => __( 'Record lesson payment', 'tutorhelper-pro' ),
					'groupHeading' => __( 'Record payment across selected lessons', 'tutorhelper-pro' ),
					'amount' => __( 'Amount received', 'tutorhelper-pro' ),
					'allocation' => __( 'Allocate to lessons', 'tutorhelper-pro' ),
					'total' => __( 'Total payment', 'tutorhelper-pro' ),
					'date' => __( 'Payment date', 'tutorhelper-pro' ),
					'entryType' => __( 'Payment entry', 'tutorhelper-pro' ),
					'manualPaymentType' => __( 'Manual payment type', 'tutorhelper-pro' ),
					'payment' => __( 'Payment', 'tutorhelper-pro' ),
					'deposit' => __( 'Deposit', 'tutorhelper-pro' ),
					'cash' => __( 'Cash', 'tutorhelper-pro' ),
					'bankTransfer' => __( 'Bank transfer', 'tutorhelper-pro' ),
					'externalCard' => __( 'Card (not TutorHelper)', 'tutorhelper-pro' ),
					'other' => __( 'Other', 'tutorhelper-pro' ),
					'notes' => __( 'Notes (optional)', 'tutorhelper-pro' ),
					'save' => __( 'Record payment', 'tutorhelper-pro' ),
					'cancel' => __( 'Cancel', 'tutorhelper-pro' ),
					'saving' => __( 'Recording…', 'tutorhelper-pro' ),
					'refreshing' => __( 'Refreshing finance data…', 'tutorhelper-pro' ),
					'failed' => __( 'The payment could not be recorded.', 'tutorhelper-pro' ),
					'paidInFull' => __( 'Paid in full', 'tutorhelper-pro' ),
					'remaining' => __( 'remaining', 'tutorhelper-pro' ),
					'selectedCount' => __( 'lessons selected', 'tutorhelper-pro' ),
					'sameStudent' => __( 'Select lessons for one student at a time.', 'tutorhelper-pro' ),
				)
			)
		);

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-finance-payments.css',
			array( 'tutorhelper-pro-finance' ),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_PRO_VERSION
		);
	}

	public static function handle_record_payment() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected.',
				array( 'reason' => 'permission_denied' )
			);

			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to record payments.', 'tutorhelper-pro' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$booking_id = isset( $_POST['booking_id'] ) ? absint( wp_unslash( $_POST['booking_id'] ) ) : 0;
		$amount_raw = isset( $_POST['amount'] ) && ! is_array( $_POST['amount'] )
			? sanitize_text_field( wp_unslash( $_POST['amount'] ) )
			: '';
		$payment_date = isset( $_POST['payment_date'] ) && ! is_array( $_POST['payment_date'] )
			? sanitize_text_field( wp_unslash( $_POST['payment_date'] ) )
			: '';
		$payment_type = isset( $_POST['payment_type'] ) && ! is_array( $_POST['payment_type'] )
			? sanitize_key( wp_unslash( $_POST['payment_type'] ) )
			: TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT;
		$manual_payment_type = isset( $_POST['manual_payment_type'] ) && ! is_array( $_POST['manual_payment_type'] )
			? sanitize_key( wp_unslash( $_POST['manual_payment_type'] ) )
			: TutorHelper_Pro_Payment_Ledger::MANUAL_PAYMENT_BANK_TRANSFER;
		$notes = isset( $_POST['notes'] ) && ! is_array( $_POST['notes'] )
			? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) )
			: '';
		$batch_reference = isset( $_POST['batch_reference'] ) && ! is_array( $_POST['batch_reference'] )
			? sanitize_text_field( wp_unslash( $_POST['batch_reference'] ) )
			: '';

		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		if ( ! $booking ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected.',
				array(
					'booking_id' => $booking_id,
					'reason' => 'booking_not_found',
					'batch_reference' => $batch_reference,
				)
			);
			wp_send_json_error( array( 'message' => __( 'The booking could not be found.', 'tutorhelper-pro' ) ), 404 );
		}

		if ( TutorHelper_Booking_Records::STATUS_CANCELLED === sanitize_key( $booking->status ) ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected.',
				array(
					'booking_id' => $booking_id,
					'reason' => 'booking_cancelled',
					'batch_reference' => $batch_reference,
				)
			);
			wp_send_json_error( array( 'message' => __( 'Payments cannot be added to a cancelled booking.', 'tutorhelper-pro' ) ), 409 );
		}

		$stripe_payment = TutorHelper_Pro_Payment_Ledger::
			get_verified_stripe_checkout_payment( $booking_id );

		if ( $stripe_payment ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected to preserve a Stripe Checkout transaction.',
				array(
					'booking_id' => $booking_id,
					'reason' => 'verified_stripe_checkout_payment_exists',
					'stripe_transaction_id' => absint( $stripe_payment->id ),
				)
			);

			wp_send_json_error(
				array(
					'message' => __(
						'This booking already has a verified TutorHelper Stripe payment. Use an adjustment or refund workflow instead of recording a manual payment.',
						'tutorhelper-pro'
					),
				),
				409
			);
		}

		if ( ! in_array( $payment_type, array( TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT, TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT ), true ) ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected.',
				array(
					'booking_id' => $booking_id,
					'reason' => 'invalid_payment_type',
					'payment_type' => $payment_type,
					'batch_reference' => $batch_reference,
				)
			);
			wp_send_json_error( array( 'message' => __( 'The payment type was invalid.', 'tutorhelper-pro' ) ), 400 );
		}

		if ( ! in_array( $manual_payment_type, TutorHelper_Pro_Payment_Ledger::get_manual_payment_types(), true ) ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected.',
				array(
					'booking_id'          => $booking_id,
					'reason'              => 'invalid_manual_payment_type',
					'manual_payment_type' => $manual_payment_type,
					'batch_reference'     => $batch_reference,
				)
			);
			wp_send_json_error( array( 'message' => __( 'Select a valid manual payment type.', 'tutorhelper-pro' ) ), 400 );
		}

		$currency = ! empty( $booking->currency )
			? strtoupper( sanitize_text_field( $booking->currency ) )
			: TutorHelper_Currency::get_currency();

		$amount = TutorHelper_Currency::major_to_minor_units( $amount_raw, $currency );
		if ( 0 >= (int) $amount ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected.',
				array(
					'booking_id' => $booking_id,
					'reason' => 'invalid_amount',
					'amount_submitted' => $amount_raw,
					'currency' => $currency,
					'batch_reference' => $batch_reference,
				)
			);
			wp_send_json_error( array( 'message' => __( 'Enter a payment amount greater than zero.', 'tutorhelper-pro' ) ), 400 );
		}
		$amount = (int) $amount;

		$date_utc = self::normalise_payment_date( $payment_date );
		if ( is_wp_error( $date_utc ) ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected.',
				array(
					'booking_id' => $booking_id,
					'reason' => $date_utc->get_error_code(),
					'payment_date' => $payment_date,
					'batch_reference' => $batch_reference,
				)
			);
			wp_send_json_error( array( 'message' => $date_utc->get_error_message() ), 400 );
		}

		$summary_before = self::get_booking_summary( $booking );
		if ( $amount > $summary_before['outstandingMinorUnits'] ) {
			TutorHelper_Logger::warning(
				'Finance payment recording rejected.',
				array(
					'booking_id' => $booking_id,
					'reason' => 'amount_exceeds_outstanding',
					'amount_minor_units' => $amount,
					'outstanding_minor_units' => $summary_before['outstandingMinorUnits'],
					'currency' => $currency,
					'batch_reference' => $batch_reference,
				)
			);
			wp_send_json_error(
				array(
					'message' => sprintf(
						__( 'This is more than the outstanding balance of %s.', 'tutorhelper-pro' ),
						$summary_before['outstandingLabel']
					),
				),
				400
			);
		}

		TutorHelper_Logger::info(
			'Finance payment recording started.',
			array(
				'booking_id' => $booking_id,
				'student_user_id' => absint( $booking->student_user_id ),
				'payment_type' => $payment_type,
				'manual_payment_type' => $manual_payment_type,
				'amount_minor_units' => $amount,
				'currency' => $currency,
				'payment_date' => $payment_date,
				'outstanding_before_minor_units' => $summary_before['outstandingMinorUnits'],
				'batch_reference' => $batch_reference,
			)
		);

		$description = TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT === $payment_type
			? __( 'Deposit recorded by tutor.', 'tutorhelper-pro' )
			: __( 'Payment recorded by tutor.', 'tutorhelper-pro' );

		$description .= ' ' . sprintf(
			/* translators: %s: Manual payment type. */
			__( 'Recorded as %s.', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::get_manual_payment_type_label( $manual_payment_type )
		);

		if ( '' !== $batch_reference ) {
			$description .= ' ' . sprintf(
				__( 'Combined payment reference: %s.', 'tutorhelper-pro' ),
				$batch_reference
			);
		}

		if ( '' !== trim( $notes ) ) {
			$description .= ' ' . trim( $notes );
		}

		$ledger_result = TutorHelper_Pro_Payment_Ledger::record(
			array(
				'booking_id' => $booking_id,
				'student_user_id' => absint( $booking->student_user_id ),
				'tutor_user_id' => absint( $booking->tutor_user_id ),
				'transaction_type' => $payment_type,
				'amount_minor_units' => $amount,
				'currency' => $currency,
				'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
				'manual_payment_type' => $manual_payment_type,
				'payment_provider' => '',
				'provider_reference' => $batch_reference,
				'description' => $description,
				'transaction_date' => $date_utc,
				'created_by_user_id' => get_current_user_id(),
			)
		);

		if ( is_wp_error( $ledger_result ) ) {
			TutorHelper_Logger::error(
				'Finance payment ledger write failed.',
				array(
					'booking_id' => $booking_id,
					'payment_type' => $payment_type,
					'amount_minor_units' => $amount,
					'currency' => $currency,
					'batch_reference' => $batch_reference,
					'error' => $ledger_result->get_error_message(),
				)
			);
			wp_send_json_error( array( 'message' => $ledger_result->get_error_message() ), 500 );
		}

		$summary_after = self::get_booking_summary( $booking );
		$now_fully_paid = 0 === $summary_after['outstandingMinorUnits'];
		$previous_payment_status = sanitize_key( $booking->payment_status );
		$previous_booking_status = sanitize_key( $booking->status );

		if ( $now_fully_paid ) {
			$new_booking_status = TutorHelper_Booking_Records::STATUS_UNCONFIRMED === $previous_booking_status
				? TutorHelper_Booking_Records::STATUS_CONFIRMED
				: $previous_booking_status;

			$update = TutorHelper_Booking_Records::update_payment_details(
				$booking_id,
				array(
					'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
					'payment_provider' => '',
					'payment_reference' => $batch_reference,
					'booking_status' => $new_booking_status,
				),
				$previous_payment_status
			);

			if ( is_wp_error( $update ) ) {
				TutorHelper_Logger::error(
					'Finance payment recorded but booking payment status update failed.',
					array(
						'booking_id' => $booking_id,
						'ledger_transaction_id' => absint( $ledger_result ),
						'batch_reference' => $batch_reference,
						'error' => $update->get_error_message(),
					)
				);
				wp_send_json_error( array( 'message' => $update->get_error_message() ), 500 );
			}

			self::save_paid_in_full_date( $booking_id, $payment_date );

			$history_result = TutorHelper_Pro_Payment_History::record(
				array(
					'booking_id' => $booking_id,
					'student_user_id' => absint( $booking->student_user_id ),
					'previous_payment_status' => $previous_payment_status,
					'new_payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
					'previous_booking_status' => $previous_booking_status,
					'new_booking_status' => $new_booking_status,
					'amount_minor_units' => $amount,
					'currency' => $currency,
					'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
					'payment_provider' => '',
					'provider_reference' => $batch_reference,
					'change_source' => TutorHelper_Pro_Payment_History::SOURCE_ADMIN,
					'changed_by_user_id' => get_current_user_id(),
					'notes' => $description,
				)
			);

			if ( is_wp_error( $history_result ) ) {
				TutorHelper_Logger::warning(
					'Finance payment was recorded but payment history could not be written.',
					array(
						'booking_id' => $booking_id,
						'ledger_transaction_id' => absint( $ledger_result ),
						'batch_reference' => $batch_reference,
						'error' => $history_result->get_error_message(),
					)
				);
			}
		}

		$fresh_booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		$response = self::get_booking_summary( $fresh_booking ? $fresh_booking : $booking );
		$response['message'] = $now_fully_paid
			? __( 'Payment recorded. This lesson is now paid in full.', 'tutorhelper-pro' )
			: __( 'Partial payment recorded. The remaining balance is still outstanding.', 'tutorhelper-pro' );
		$response['batchReference'] = $batch_reference;

		TutorHelper_Logger::success(
			'Finance payment recorded.',
			array(
				'booking_id' => $booking_id,
				'student_user_id' => absint( $booking->student_user_id ),
				'ledger_transaction_id' => absint( $ledger_result ),
				'payment_type' => $payment_type,
				'amount_minor_units' => $amount,
				'currency' => $currency,
				'payment_date' => $payment_date,
				'outstanding_after_minor_units' => $response['outstandingMinorUnits'],
				'paid_in_full' => $now_fully_paid,
				'batch_reference' => $batch_reference,
			)
		);

		wp_send_json_success( $response );
	}

	private static function prepare_booking_summaries() {
		global $wpdb;

		$table = TutorHelper_Booking_Records::get_table_name();
		$bookings = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin finance controls need current booking balances.
			"SELECT * FROM {$table} ORDER BY booking_start DESC LIMIT 1000"
		);

		$prepared = array();
		foreach ( $bookings as $booking ) {
			$prepared[ absint( $booking->id ) ] = self::get_booking_summary( $booking );
		}

		return $prepared;
	}

	private static function get_booking_summary( $booking ) {
		global $wpdb;

		$booking_id = absint( $booking->id );
		$currency = ! empty( $booking->currency )
			? strtoupper( sanitize_text_field( $booking->currency ) )
			: TutorHelper_Currency::get_currency();
		$price = absint( $booking->price_minor_units );
		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );

		$transactions = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance balances must reflect the current immutable ledger.
			$wpdb->prepare(
				'SELECT id, transaction_type, manual_payment_type, amount_minor_units, description, transaction_date
				FROM %i
				WHERE booking_id = %d
				AND transaction_type IN (%s, %s, %s)
				ORDER BY transaction_date ASC, id ASC',
				$table,
				$booking_id,
				TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
				TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED
			),
			ARRAY_A
		);

		$settled = 0;
		$prepared_transactions = array();
		foreach ( $transactions as $transaction ) {
			$transaction_amount = absint( $transaction['amount_minor_units'] );
			$settled += $transaction_amount;
			$type = sanitize_key( $transaction['transaction_type'] );
			$prepared_transactions[] = array(
				'id' => absint( $transaction['id'] ),
				'type' => $type,
				'label' => self::get_transaction_label(
					$type,
					isset( $transaction['manual_payment_type'] ) ? $transaction['manual_payment_type'] : ''
				),
				'amount' => TutorHelper_Currency::format_minor_units( $transaction_amount, $currency ),
				'date' => self::format_transaction_date( $transaction['transaction_date'] ),
				'description' => sanitize_text_field( $transaction['description'] ),
			);
		}

		$settled = min( $price, $settled );
		$outstanding = max( 0, $price - $settled );
		$lesson_label = self::format_lesson_label( $booking );

		return array(
			'bookingId' => $booking_id,
			'studentUserId' => absint( $booking->student_user_id ),
			'studentName' => sanitize_text_field( $booking->student_name ),
			'lessonLabel' => $lesson_label,
			'priceMinorUnits' => $price,
			'settledMinorUnits' => $settled,
			'outstandingMinorUnits' => $outstanding,
			'priceLabel' => TutorHelper_Currency::format_minor_units( $price, $currency ),
			'settledLabel' => TutorHelper_Currency::format_minor_units( $settled, $currency ),
			'outstandingLabel' => TutorHelper_Currency::format_minor_units( $outstanding, $currency ),
			'currency' => $currency,
			'paymentStatus' => sanitize_key( $booking->payment_status ),
			'bookingStatus' => sanitize_key( $booking->status ),
			'canRecordPayment' => 0 < $outstanding && TutorHelper_Booking_Records::STATUS_CANCELLED !== sanitize_key( $booking->status ),
			'transactions' => $prepared_transactions,
		);
	}

	private static function normalise_payment_date( $payment_date ) {
		$date = DateTimeImmutable::createFromFormat(
			'!Y-m-d',
			$payment_date,
			wp_timezone()
		);

		$errors = DateTimeImmutable::getLastErrors();
		if (
			! $date
			|| ( is_array( $errors ) && ( 0 < $errors['warning_count'] || 0 < $errors['error_count'] ) )
			|| $date->format( 'Y-m-d' ) !== $payment_date
		) {
			return new WP_Error( 'tutorhelper_pro_payment_date_invalid', __( 'Enter a valid payment date.', 'tutorhelper-pro' ) );
		}

		$today = new DateTimeImmutable( 'today', wp_timezone() );
		if ( $date > $today ) {
			return new WP_Error( 'tutorhelper_pro_payment_date_future', __( 'The payment date cannot be in the future.', 'tutorhelper-pro' ) );
		}

		return $date->setTime( 12, 0 )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	}

	private static function save_paid_in_full_date( $booking_id, $payment_date ) {
		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'booking_finance' );
		$now = current_time( 'mysql', true );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Upsert of TutorHelper Pro finance metadata.
			$wpdb->prepare(
				'INSERT INTO %i (booking_id, payment_date, created_at, updated_at)
				VALUES (%d, %s, %s, %s)
				ON DUPLICATE KEY UPDATE payment_date = VALUES(payment_date), updated_at = VALUES(updated_at)',
				$table,
				absint( $booking_id ),
				$payment_date,
				$now,
				$now
			)
		);
	}

	private static function get_transaction_label( $type, $manual_payment_type = '' ) {
		if ( TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT === $type ) {
			return __( 'Deposit', 'tutorhelper-pro' );
		}
		if ( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED === $type ) {
			return __( 'Account credit applied', 'tutorhelper-pro' );
		}
		$manual_label = TutorHelper_Pro_Payment_Ledger::get_manual_payment_type_label( $manual_payment_type );
		return $manual_label
			? sprintf(
				/* translators: %s: Manual payment type. */
				__( 'Payment (%s)', 'tutorhelper-pro' ),
				$manual_label
			)
			: __( 'Payment', 'tutorhelper-pro' );
	}

	private static function format_transaction_date( $date ) {
		try {
			$value = new DateTimeImmutable( sanitize_text_field( $date ), new DateTimeZone( 'UTC' ) );
			$value = $value->setTimezone( wp_timezone() );
			return wp_date( get_option( 'date_format' ), $value->getTimestamp(), wp_timezone() );
		} catch ( Exception $exception ) {
			return '';
		}
	}

	private static function format_lesson_label( $booking ) {
		try {
			$value = new DateTimeImmutable(
				sanitize_text_field( $booking->booking_start ),
				new DateTimeZone( 'UTC' )
			);
			$value = $value->setTimezone( wp_timezone() );
			return wp_date(
				get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
				$value->getTimestamp(),
				wp_timezone()
			);
		} catch ( Exception $exception ) {
			return sprintf( __( 'Booking #%d', 'tutorhelper-pro' ), absint( $booking->id ) );
		}
	}
}
