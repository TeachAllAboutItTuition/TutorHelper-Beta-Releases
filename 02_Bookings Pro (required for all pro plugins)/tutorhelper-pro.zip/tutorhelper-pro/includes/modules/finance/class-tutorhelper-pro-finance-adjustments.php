<?php
/**
 * Tutor-facing refund and account-credit workflow.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records finance reversals without mutating the immutable Pro ledger.
 */
final class TutorHelper_Pro_Finance_Adjustments {

	const ACTION = 'tutorhelper_pro_finance_adjustment';
	const NONCE_ACTION = 'tutorhelper_pro_finance_adjustment';

	const ADJUSTMENT_CREDIT = 'credit';
	const ADJUSTMENT_REFUND_EXTERNAL = 'refund_external';
	const ADJUSTMENT_REFUND_STRIPE = 'refund_stripe';

	/** Register hooks. */
	public static function init() {
		add_action(
			'admin_post_' . self::ACTION,
			array( __CLASS__, 'handle_adjustment' )
		);

		add_action(
			'tutorhelper_booking_hub_render_tab',
			array( __CLASS__, 'render_finance_panel' ),
			30,
			2
		);
	}

	/**
	 * Render the refund/credit controls below the Pro Finance view.
	 *
	 * @param string $selected_tab Selected Booking Hub tab.
	 * @param array  $active_tab Active tab data.
	 * @return void
	 */
	public static function render_finance_panel( $selected_tab, $active_tab ) {
		unset( $active_tab );

		if (
			TutorHelper_Pro_Finance_Admin::TAB_KEY !== $selected_tab
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$notice = isset( $_GET['finance_adjustment_notice'] ) && ! is_array( $_GET['finance_adjustment_notice'] )
			? sanitize_key( wp_unslash( $_GET['finance_adjustment_notice'] ) )
			: '';
		$message = isset( $_GET['finance_adjustment_message'] ) && ! is_array( $_GET['finance_adjustment_message'] )
			? sanitize_text_field( wp_unslash( $_GET['finance_adjustment_message'] ) )
			: '';

		?>
		<section class="tutorhelper-main-section tutorhelper-pro-finance-adjustments">
			<div class="tutorhelper-main-section__header">
				<h3><?php echo esc_html__( 'Refunds & account credit', 'tutorhelper-pro' ); ?></h3>
				<p><?php echo esc_html__( 'Review the refund and account-credit history recorded from booking payment actions.', 'tutorhelper-pro' ); ?></p>
			</div>
			<div class="tutorhelper-main-section__body">
				<?php if ( '' !== $message ) : ?>
					<div class="notice inline <?php echo 'success' === $notice ? 'notice-success' : 'notice-error'; ?>">
						<p><?php echo esc_html( $message ); ?></p>
					</div>
				<?php endif; ?>

				<?php self::render_recent_history(); ?>
			</div>
		</section>
		<?php
	}

	/** Process a tutor-entered adjustment. */
	public static function handle_adjustment() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to update finance data.', 'tutorhelper-pro' ) );
		}

		check_admin_referer( self::NONCE_ACTION );

		$booking_id = isset( $_POST['booking_id'] ) && ! is_array( $_POST['booking_id'] )
			? absint( wp_unslash( $_POST['booking_id'] ) )
			: 0;
		$type = isset( $_POST['adjustment_type'] ) && ! is_array( $_POST['adjustment_type'] )
			? sanitize_key( wp_unslash( $_POST['adjustment_type'] ) )
			: '';
		$amount_input = isset( $_POST['amount'] ) && ! is_array( $_POST['amount'] )
			? sanitize_text_field( wp_unslash( $_POST['amount'] ) )
			: '';
		$notes = isset( $_POST['notes'] ) && ! is_array( $_POST['notes'] )
			? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) )
			: '';

		$amount = self::major_to_minor_units( $amount_input );
		$result = self::record_adjustment( $booking_id, $type, $amount, $notes );

		if ( is_wp_error( $result ) ) {
			self::redirect_with_notice( 'error', $result->get_error_message() );
		}

		self::redirect_with_notice(
			'success',
			__( 'The finance adjustment was recorded and downstream payment state was reconciled.', 'tutorhelper-pro' )
		);
	}

	/**
	 * Record one adjustment after validating the current refundable balance.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param string $type Adjustment type.
	 * @param int    $amount Amount in minor units.
	 * @param string $notes Tutor notes.
	 * @return int|WP_Error Ledger transaction ID.
	 */
	public static function record_adjustment( $booking_id, $type, $amount, $notes = '' ) {
		global $wpdb;

		$booking_id = absint( $booking_id );
		$type = sanitize_key( $type );
		$amount = absint( $amount );

		if (
			! in_array(
				$type,
				array( self::ADJUSTMENT_CREDIT, self::ADJUSTMENT_REFUND_EXTERNAL, self::ADJUSTMENT_REFUND_STRIPE ),
				true
			)
		) {
			return new WP_Error( 'tutorhelper_pro_finance_adjustment_invalid_type', __( 'Choose a valid finance action.', 'tutorhelper-pro' ) );
		}

		if ( 0 === $amount ) {
			return new WP_Error( 'tutorhelper_pro_finance_adjustment_invalid_amount', __( 'Enter an amount greater than zero.', 'tutorhelper-pro' ) );
		}

		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		if ( ! $booking ) {
			return new WP_Error( 'tutorhelper_pro_finance_adjustment_booking_missing', __( 'The booking could not be found.', 'tutorhelper-pro' ) );
		}

		$totals = self::get_booking_totals( $booking_id );
		$maximum = self::ADJUSTMENT_CREDIT === $type
			? $totals['credit_available_minor_units']
			: $totals['refund_available_minor_units'];

		if ( $amount > $maximum ) {
			return new WP_Error(
				'tutorhelper_pro_finance_adjustment_exceeds_balance',
				sprintf(
					/* translators: %s: available amount. */
					__( 'That adjustment exceeds the available amount of %s.', 'tutorhelper-pro' ),
					TutorHelper_Currency::format_minor_units( $maximum, $booking->currency )
				)
			);
		}

		$provider_reference = sanitize_text_field( isset( $booking->payment_reference ) ? $booking->payment_reference : '' );
		$provider_event_id = null;
		$payment_provider = sanitize_key( isset( $booking->payment_provider ) ? $booking->payment_provider : '' );
		$payment_method = sanitize_key( isset( $booking->payment_method ) ? $booking->payment_method : '' );
		$transaction_type = TutorHelper_Pro_Payment_Ledger::TYPE_REFUND;
		$description = '';
		$credit_reversal = 0;

		if ( self::ADJUSTMENT_CREDIT === $type ) {
			$transaction_type = TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED;
			$payment_provider = '';
			$provider_reference = '';
			$description = __( 'Tutor-issued account credit', 'tutorhelper-pro' );
		} elseif ( self::ADJUSTMENT_REFUND_EXTERNAL === $type ) {
			$payment_provider = '';
			$provider_reference = '';
			$description = __( 'Refund processed externally and recorded by tutor', 'tutorhelper-pro' );
			$credit_reversal = min( $amount, $totals['active_credit_minor_units'] );
		} else {
			$stripe_source = self::get_stripe_refund_source( $booking_id );
			if ( is_wp_error( $stripe_source ) ) {
				return $stripe_source;
			}
			if ( $amount > $stripe_source['refundable_minor_units'] ) {
				return new WP_Error(
					'tutorhelper_pro_finance_stripe_refund_exceeds_balance',
					__( 'The amount exceeds the refundable Stripe payment balance for this booking.', 'tutorhelper-pro' )
				);
			}

			$stripe_refund = self::create_stripe_refund(
				$stripe_source['payment_intent'],
				$amount,
				$booking_id,
				sprintf(
					'tutorhelper-pro-refund-%d-%s-%d-%d',
					$booking_id,
					$stripe_source['payment_intent'],
					$amount,
					absint( $totals['refunded_minor_units'] )
				)
			);
			if ( is_wp_error( $stripe_refund ) ) {
				return $stripe_refund;
			}

			$payment_provider = TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE;
			$payment_method = TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE;
			$provider_reference = $stripe_source['payment_intent'];
			$provider_event_id = sanitize_text_field( $stripe_refund['id'] );
			$description = __( 'Refund processed through Stripe', 'tutorhelper-pro' );
			$credit_reversal = min( $amount, $totals['active_credit_minor_units'] );
		}

		if ( '' !== trim( $notes ) ) {
			$description .= ': ' . trim( $notes );
		}

		/*
		 * A provider refund has already succeeded at this point. Keep the
		 * linked credit reversal and refund row together locally so the
		 * account balance cannot be left doubled if one insert fails.
		 */
		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Local immutable ledger writes require an atomic pair.

		if ( 0 < $credit_reversal ) {
			$reversal = TutorHelper_Pro_Payment_Ledger::record(
				array(
					'booking_id' => $booking_id,
					'student_user_id' => absint( $booking->student_user_id ),
					'tutor_user_id' => absint( $booking->tutor_user_id ),
					'transaction_type' => TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_REVERSED,
					'amount_minor_units' => $credit_reversal,
					'currency' => strtoupper( sanitize_text_field( $booking->currency ) ),
					'payment_method' => $payment_method,
					'payment_provider' => $payment_provider,
					'provider_reference' => $provider_reference,
					'description' => __( 'Account credit reversed because the cancelled lesson was refunded.', 'tutorhelper-pro' ),
					'created_by_user_id' => get_current_user_id(),
				)
			);

			if ( is_wp_error( $reversal ) ) {
				$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- See transaction above.
				TutorHelper_Logger::error(
					'Finance refund completed but its account-credit reversal could not be recorded.',
					array(
						'booking_id' => $booking_id,
						'error_code' => $reversal->get_error_code(),
						'provider_event_id' => $provider_event_id,
					)
				);
				return $reversal;
			}
		}

		$ledger_id = TutorHelper_Pro_Payment_Ledger::record(
			array(
				'booking_id' => $booking_id,
				'student_user_id' => absint( $booking->student_user_id ),
				'tutor_user_id' => absint( $booking->tutor_user_id ),
				'transaction_type' => $transaction_type,
				'amount_minor_units' => $amount,
				'currency' => strtoupper( sanitize_text_field( $booking->currency ) ),
				'payment_method' => $payment_method,
				'payment_provider' => $payment_provider,
				'provider_reference' => $provider_reference,
				'provider_event_id' => $provider_event_id,
				'description' => $description,
				'created_by_user_id' => get_current_user_id(),
			)
		);

		if ( is_wp_error( $ledger_id ) ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- See transaction above.
			TutorHelper_Logger::error(
				'Finance refund or credit could not be recorded after provider processing.',
				array(
					'booking_id' => $booking_id,
					'error_code' => $ledger_id->get_error_code(),
					'provider_event_id' => $provider_event_id,
				)
			);
			return $ledger_id;
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- See transaction above.

		self::sync_booking_payment_state( $booking );

		do_action(
			'tutorhelper_pro_finance_adjustment_recorded',
			$booking_id,
			absint( $ledger_id ),
			$transaction_type
		);

		return absint( $ledger_id );
	}
	/** Return cumulative finance totals for a booking. */
	public static function get_booking_totals( $booking_id ) {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance state must reflect the immutable ledger immediately.
			$wpdb->prepare(
				'SELECT transaction_type, COALESCE(SUM(amount_minor_units), 0) AS amount FROM %i WHERE booking_id = %d GROUP BY transaction_type',
				$table,
				absint( $booking_id )
			),
			OBJECT_K
		);

		$amount_for = static function ( $type ) use ( $rows ) {
			return isset( $rows[ $type ] ) ? absint( $rows[ $type ]->amount ) : 0;
		};

		$money_paid = $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT )
			+ $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT );
		$credit_paid = $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED );
		$paid = $money_paid + $credit_paid;
		$refunded = $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_REFUND );
		$issued_credit = $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED );
		$reversed_credit = $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_REVERSED );
		$active_credit = max( 0, $issued_credit - $reversed_credit );
		$returned = $refunded + $active_credit;

		return array(
			'paid_minor_units' => $paid,
			'refunded_minor_units' => $refunded,
			'credited_minor_units' => $active_credit,
			'active_credit_minor_units' => $active_credit,
			'net_paid_minor_units' => max( 0, $paid - $returned ),
			/*
			 * A refund may replace cancellation credit. It is limited by the
			 * original money payment, rather than by the temporary credit row.
			 */
			'refund_available_minor_units' => max( 0, $money_paid - $refunded ),
			'credit_available_minor_units' => max( 0, $paid - $refunded - $active_credit ),
			'refundable_minor_units' => max( 0, $money_paid - $refunded ),
		);
	}
	/** Keep Core's simple paid/pending state aligned to the net ledger amount. */
	private static function sync_booking_payment_state( $booking ) {
		$fresh = TutorHelper_Booking_Records::get_by_id( $booking->id );
		if ( ! $fresh ) {
			return;
		}

		$totals = self::get_booking_totals( $fresh->id );
		$price = absint( $fresh->price_minor_units );
		$target = $totals['net_paid_minor_units'] >= $price
			? TutorHelper_Booking_Records::PAYMENT_STATUS_PAID
			: TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING;
		$current = sanitize_key( $fresh->payment_status );

		if ( $target === $current ) {
			return;
		}

		$updated = TutorHelper_Booking_Records::update_payment_details(
			$fresh->id,
			array(
				'payment_status' => $target,
				'payment_method' => sanitize_key( $fresh->payment_method ),
				'payment_provider' => sanitize_key( $fresh->payment_provider ),
				'payment_reference' => sanitize_text_field( $fresh->payment_reference ),
				'booking_status' => sanitize_key( $fresh->status ),
			),
			$current
		);

		if ( is_wp_error( $updated ) ) {
			TutorHelper_Logger::error(
				'Finance adjustment ledger was recorded but Core payment state could not be refreshed.',
				array( 'booking_id' => absint( $fresh->id ), 'error' => $updated->get_error_message() )
			);
			return;
		}

		TutorHelper_Pro_Payment_History::record(
			array(
				'booking_id' => absint( $fresh->id ),
				'student_user_id' => absint( $fresh->student_user_id ),
				'previous_payment_status' => $current,
				'new_payment_status' => $target,
				'previous_booking_status' => sanitize_key( $fresh->status ),
				'new_booking_status' => sanitize_key( $fresh->status ),
				'amount_minor_units' => $totals['net_paid_minor_units'],
				'currency' => strtoupper( sanitize_text_field( $fresh->currency ) ),
				'payment_method' => sanitize_key( $fresh->payment_method ),
				'payment_provider' => sanitize_key( $fresh->payment_provider ),
				'provider_reference' => sanitize_text_field( $fresh->payment_reference ),
				'change_source' => TutorHelper_Pro_Payment_History::SOURCE_SYSTEM,
				'changed_by_user_id' => get_current_user_id(),
				'notes' => __( 'Payment status recalculated after refund or credit.', 'tutorhelper-pro' ),
			)
		);
	}

	/** Find a Stripe payment intent with a remaining refundable amount. */
	private static function get_stripe_refund_source( $booking_id ) {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$payments = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Stripe refund validation requires current ledger data.
			$wpdb->prepare(
				'SELECT provider_reference, amount_minor_units FROM %i WHERE booking_id = %d AND payment_provider = %s AND transaction_type IN (%s, %s) ORDER BY id DESC',
				$table,
				absint( $booking_id ),
				TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
				TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT,
				TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT
			)
		);

		foreach ( $payments as $payment ) {
			$payment_intent = sanitize_text_field( $payment->provider_reference );
			if ( 0 !== strpos( $payment_intent, 'pi_' ) ) {
				continue;
			}

			$refunded = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Stripe refund validation requires current ledger data.
				$wpdb->prepare(
					'SELECT COALESCE(SUM(amount_minor_units), 0) FROM %i WHERE booking_id = %d AND transaction_type = %s AND payment_provider = %s AND provider_reference = %s',
					$table,
					absint( $booking_id ),
					TutorHelper_Pro_Payment_Ledger::TYPE_REFUND,
					TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE,
					$payment_intent
				)
			);

			$remaining = max( 0, absint( $payment->amount_minor_units ) - $refunded );
			if ( $remaining > 0 ) {
				return array( 'payment_intent' => $payment_intent, 'refundable_minor_units' => $remaining );
			}
		}

		return new WP_Error( 'tutorhelper_pro_finance_stripe_payment_missing', __( 'No refundable Stripe payment was found for this booking.', 'tutorhelper-pro' ) );
	}

	/** Send a refund to Stripe. The ledger is written only after success. */
	private static function create_stripe_refund( $payment_intent, $amount, $booking_id, $idempotency_key = '' ) {
		$secret = TutorHelper_Pro_Payment_Settings::get_stripe_secret_key();
		if ( '' === $secret ) {
			return new WP_Error( 'tutorhelper_pro_finance_stripe_not_configured', __( 'Stripe is not configured.', 'tutorhelper-pro' ) );
		}

		$response = wp_remote_post(
			TutorHelper_Pro_Stripe::API_BASE . '/refunds',
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Bearer ' . $secret,
					'Stripe-Version' => TutorHelper_Pro_Stripe::API_VERSION,
					'Idempotency-Key' => sanitize_text_field( $idempotency_key ),
				),
				'body' => array(
					'payment_intent' => sanitize_text_field( $payment_intent ),
					'amount' => absint( $amount ),
					'metadata[booking_id]' => absint( $booking_id ),
					'metadata[source]' => 'tutorhelper_pro_finance',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $body ) || empty( $body['id'] ) ) {
			$message = is_array( $body ) && ! empty( $body['error']['message'] )
				? sanitize_text_field( $body['error']['message'] )
				: __( 'Stripe could not process the refund.', 'tutorhelper-pro' );
			return new WP_Error( 'tutorhelper_pro_finance_stripe_refund_failed', $message );
		}

		return $body;
	}

	/** Render recent refund/credit transactions and current student credit. */
	private static function render_recent_history() {
		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance history must be current.
			$wpdb->prepare(
				'SELECT id, booking_id, student_user_id, transaction_type, amount_minor_units, currency, payment_provider, provider_event_id, description, transaction_date FROM %i WHERE transaction_type IN (%s, %s, %s) ORDER BY id DESC LIMIT 50',
				$table,
				TutorHelper_Pro_Payment_Ledger::TYPE_REFUND,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED
			)
		);

		?>
		<h4><?php echo esc_html__( 'Refund & credit history', 'tutorhelper-pro' ); ?></h4>
		<?php if ( empty( $rows ) ) : ?>
			<p><?php echo esc_html__( 'No refund or credit activity has been recorded yet.', 'tutorhelper-pro' ); ?></p>
			<?php return; ?>
		<?php endif; ?>
		<div class="tutorhelper-pro-finance-table-wrap">
			<table class="widefat striped">
				<thead><tr>
					<th><?php echo esc_html__( 'Date', 'tutorhelper-pro' ); ?></th>
					<th><?php echo esc_html__( 'Booking', 'tutorhelper-pro' ); ?></th>
					<th><?php echo esc_html__( 'Student', 'tutorhelper-pro' ); ?></th>
					<th><?php echo esc_html__( 'Type', 'tutorhelper-pro' ); ?></th>
					<th><?php echo esc_html__( 'Amount', 'tutorhelper-pro' ); ?></th>
					<th><?php echo esc_html__( 'Available credit', 'tutorhelper-pro' ); ?></th>
					<th><?php echo esc_html__( 'Provider', 'tutorhelper-pro' ); ?></th>
					<th><?php echo esc_html__( 'Details', 'tutorhelper-pro' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $rows as $row ) :
					$user = get_user_by( 'id', absint( $row->student_user_id ) );
					$currency = strtoupper( sanitize_text_field( $row->currency ) );
					$balance = TutorHelper_Pro_Student_Credits::get_balance( absint( $row->student_user_id ), $currency );
				?>
				<tr>
					<td><?php echo esc_html( get_date_from_gmt( $row->transaction_date, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ); ?></td>
					<td>#<?php echo esc_html( absint( $row->booking_id ) ); ?></td>
					<td><?php echo esc_html( $user ? $user->display_name : '#' . absint( $row->student_user_id ) ); ?></td>
					<td><?php echo esc_html( ucwords( str_replace( '_', ' ', sanitize_key( $row->transaction_type ) ) ) ); ?></td>
					<td><?php echo esc_html( TutorHelper_Currency::format_minor_units( absint( $row->amount_minor_units ), $currency ) ); ?></td>
					<td><?php echo esc_html( TutorHelper_Currency::format_minor_units( $balance, $currency ) ); ?></td>
					<td><?php echo esc_html( $row->payment_provider ? ucfirst( sanitize_key( $row->payment_provider ) ) : __( 'Recorded only', 'tutorhelper-pro' ) ); ?></td>
					<td><?php echo esc_html( sanitize_text_field( $row->description ) ); ?></td>
				</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/** Convert a decimal major-unit amount to two-decimal minor units. */
	private static function major_to_minor_units( $value ) {
		if ( ! is_numeric( $value ) ) {
			return 0;
		}
		return max( 0, (int) round( (float) $value * 100 ) );
	}

	/** Redirect back to Finance with a result notice. */
	private static function redirect_with_notice( $type, $message ) {
		$url = add_query_arg(
			array(
				'page' => TutorHelper_Admin::MENU_SLUG,
				'tab' => TutorHelper_Pro_Finance_Admin::TAB_KEY,
				'finance_view' => TutorHelper_Pro_Finance_Admin::VIEW_ALL,
				'finance_adjustment_notice' => sanitize_key( $type ),
				'finance_adjustment_message' => sanitize_text_field( $message ),
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}
}
