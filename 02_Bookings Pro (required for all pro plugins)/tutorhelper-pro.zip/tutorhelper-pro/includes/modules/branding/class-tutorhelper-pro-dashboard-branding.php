<?php
/**
 * TutorHelper Pro student dashboard branding.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies TutorHelper Pro branding to the Core student dashboard.
 */
final class TutorHelper_Pro_Dashboard_Branding {

	/**
	 * Dashboard branding stylesheet handle.
	 *
	 * @var string
	 */
	const STYLE_HANDLE =
		'tutorhelper-pro-dashboard-branding';


	/**
	 * Register front-end hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'wp_enqueue_scripts',
			array(
				__CLASS__,
				'enqueue_assets',
			),
			20
		);
	}


	/**
	 * Load student dashboard branding when enabled.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {

		if (
			! TutorHelper_Pro_License::
				is_active()
		) {
			return;
		}

		$branding =
			TutorHelper_Pro_Branding::
				get_all();

		$current_user =
			wp_get_current_user();

		$is_parent =
			in_array(
				TutorHelper_Students::PARENT_ROLE,
				(array) $current_user->roles,
				true
			);

		$setting_key =
			$is_parent
				? 'parent_dashboard_branding'
				: 'student_dashboard_branding';

		if ( empty( $branding[ $setting_key ] ) ) {
			return;
		}

		$style_path =
			TUTORHELPER_PRO_PATH
			. 'assets/css/'
			. 'tutorhelper-pro-dashboard-branding.css';

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL
				. 'assets/css/'
				. 'tutorhelper-pro-dashboard-branding.css',
			array(),
			file_exists(
				$style_path
			)
				? (string) filemtime(
					$style_path
				)
				: TUTORHELPER_PRO_VERSION
		);

		wp_add_inline_style(
			self::STYLE_HANDLE,
			self::build_branding_css(
				$branding
			)
		);
	}


	/**
	 * Build site-specific dashboard branding variables.
	 *
	 * @param array $branding Branding settings.
	 *
	 * @return string
	 */
	private static function build_branding_css(
		$branding
	) {

		$defaults =
			TutorHelper_Pro_Branding::
				get_defaults();

		$primary =
			self::get_color(
				$branding,
				'primary_color',
				$defaults[
					'primary_color'
				]
			);

		$accent =
			self::get_color(
				$branding,
				'accent_color',
				$defaults[
					'accent_color'
				]
			);

		$text =
			self::get_color(
				$branding,
				'text_color',
				$defaults[
					'text_color'
				]
			);

		$heading =
			self::get_color(
				$branding,
				'heading_color',
				$defaults[
					'heading_color'
				]
			);

		$dashboard_background =
			self::get_color(
				$branding,
				'form_background_color',
				$defaults[
					'form_background_color'
				]
			);

		$dashboard_box =
			self::get_color(
				$branding,
				'form_box_color',
				$defaults[
					'form_box_color'
				]
			);

		$button_text =
			self::get_color(
				$branding,
				'button_text_color',
				$defaults[
					'button_text_color'
				]
			);

		$text_font =
			self::get_font(
				$branding[
					'text_font'
				]
				?? '',
				$defaults[
					'text_font'
				]
			);

		$heading_font =
			self::get_font(
				$branding[
					'heading_font'
				]
				?? '',
				$defaults[
					'heading_font'
				]
			);

		return sprintf(
			'.tutorhelper-student-dashboard,
			.tutorhelper-pro-credit-balance {
				--tutorhelper-brand-primary: %1$s;
				--tutorhelper-brand-accent: %2$s;
				--tutorhelper-brand-text: %3$s;
				--tutorhelper-brand-heading: %4$s;
				--tutorhelper-brand-dashboard-background: %5$s;
				--tutorhelper-brand-dashboard-box: %6$s;
				--tutorhelper-brand-button-text: %7$s;
				--tutorhelper-brand-text-font: %8$s;
				--tutorhelper-brand-heading-font: %9$s;
			}',
			$primary,
			$accent,
			$text,
			$heading,
			$dashboard_background,
			$dashboard_box,
			$button_text,
			$text_font,
			$heading_font
		);
	}


	/**
	 * Read and validate a stored colour.
	 *
	 * @param array  $branding Branding settings.
	 * @param string $key      Setting key.
	 * @param string $fallback Default colour.
	 *
	 * @return string
	 */
	private static function get_color(
		$branding,
		$key,
		$fallback
	) {

		$value =
			isset(
				$branding[ $key ]
			)
				? sanitize_hex_color(
					$branding[
						$key
					]
				)
				: '';

		return $value
			? $value
			: $fallback;
	}


	/**
	 * Return an approved branding font stack.
	 *
	 * @param string $font     Requested font.
	 * @param string $fallback Fallback font.
	 *
	 * @return string
	 */
	private static function get_font(
		$font,
		$fallback
	) {

		$options =
			TutorHelper_Pro_Branding::
				get_font_options();

		return isset(
			$options[ $font ]
		)
			? $font
			: $fallback;
	}
}
