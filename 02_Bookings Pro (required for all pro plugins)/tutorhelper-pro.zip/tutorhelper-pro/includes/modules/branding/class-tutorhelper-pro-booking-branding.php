<?php
/**
 * TutorHelper Pro student booking branding.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies TutorHelper Pro branding to the Core student booking form.
 */
final class TutorHelper_Pro_Booking_Branding {

	/**
	 * Pro booking branding stylesheet handle.
	 *
	 * @var string
	 */
	const STYLE_HANDLE =
		'tutorhelper-pro-booking-branding';


	/**
	 * Register front-end branding hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'wp_enqueue_scripts',
			array(
				__CLASS__,
				'enqueue_assets',
			),
			20
		);
	}


	/**
	 * Load booking-form branding when enabled.
	 *
	 * The stylesheet is fully scoped to the TutorHelper booking
	 * form, so loading it on the front end has no effect on
	 * unrelated site content.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {

		if (
			! TutorHelper_Pro_License::
				is_active()
		) {
			return;
		}

		$branding =
			TutorHelper_Pro_Branding::
				get_all();

		if (
			empty(
				$branding[
					'booking_form_branding'
				]
			)
		) {
			return;
		}

		$style_path =
			TUTORHELPER_PRO_PATH
			. 'assets/css/'
			. 'tutorhelper-pro-booking-branding.css';

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL
				. 'assets/css/'
				. 'tutorhelper-pro-booking-branding.css',
			array(),
			file_exists(
				$style_path
			)
				? (string) filemtime(
					$style_path
				)
				: TUTORHELPER_PRO_VERSION
		);

		wp_add_inline_style(
			self::STYLE_HANDLE,
			self::build_branding_css(
				$branding
			)
		);
	}


	/**
	 * Build the site-specific CSS variables.
	 *
	 * @param array  $branding Branding settings.
	 * @param string $selector Allowed TutorHelper form selector.
	 *
	 * @return string
	 */
	public static function build_branding_css(
		$branding,
		$selector = '.tutorhelper-student-booking'
	) {
		$allowed_selectors = array(
			'.tutorhelper-student-booking',
			'.tutorhelper-pro-registration',
		);

		if ( ! in_array( $selector, $allowed_selectors, true ) ) {
			$selector =
				'.tutorhelper-student-booking';
		}

		$defaults =
			TutorHelper_Pro_Branding::
				get_defaults();

		$primary =
			self::get_color(
				$branding,
				'primary_color',
				$defaults[
					'primary_color'
				]
			);

		$accent =
			self::get_color(
				$branding,
				'accent_color',
				$defaults[
					'accent_color'
				]
			);

		$text =
			self::get_color(
				$branding,
				'text_color',
				$defaults[
					'text_color'
				]
			);

		$heading =
			self::get_color(
				$branding,
				'heading_color',
				$defaults[
					'heading_color'
				]
			);

		$background =
			self::get_color(
				$branding,
				'background_color',
				$defaults[
					'background_color'
				]
			);

        $form_background =
            self::get_color(
                $branding,
                'form_background_color',
                $defaults[
                    'form_background_color'
                ]
            );

        $form_box =
            self::get_color(
                $branding,
                'form_box_color',
                $defaults[
                    'form_box_color'
                ]
            );

        $calendar =
            self::get_color(
                $branding,
                'calendar_color',
                $defaults[
                    'calendar_color'
                ]
            );

        $button_text =
            self::get_color(
                $branding,
                'button_text_color',
                $defaults[
                    'button_text_color'
                ]
            );

		$text_font =
			self::get_font(
				$branding[
					'text_font'
				]
				?? '',
				$defaults[
					'text_font'
				]
			);

		$heading_font =
			self::get_font(
				$branding[
					'heading_font'
				]
				?? '',
				$defaults[
					'heading_font'
				]
			);

		return sprintf(
			'%1$s {
				--tutorhelper-brand-primary: %2$s;
				--tutorhelper-brand-accent: %3$s;
				--tutorhelper-brand-text: %4$s;
				--tutorhelper-brand-heading: %5$s;
				--tutorhelper-brand-form-background: %6$s;
				--tutorhelper-brand-form-box: %7$s;
				--tutorhelper-brand-calendar: %8$s;
				--tutorhelper-brand-button-text: %9$s;
				--tutorhelper-brand-text-font: %10$s;
				--tutorhelper-brand-heading-font: %11$s;
			}',
			$selector,
			$primary,
			$accent,
			$text,
			$heading,
			$form_background,
			$form_box,
			$calendar,
			$button_text,
			$text_font,
			$heading_font
		);
	}


	/**
	 * Read and validate a stored colour.
	 *
	 * @param array  $branding Branding settings.
	 * @param string $key      Setting key.
	 * @param string $fallback Default colour.
	 *
	 * @return string
	 */
	private static function get_color(
		$branding,
		$key,
		$fallback
	) {

		$value =
			isset(
				$branding[ $key ]
			)
				? sanitize_hex_color(
					$branding[
						$key
					]
				)
				: '';

		return $value
			? $value
			: $fallback;
	}


	/**
	 * Return an approved branding font stack.
	 *
	 * @param string $font     Requested font.
	 * @param string $fallback Fallback font.
	 *
	 * @return string
	 */
	private static function get_font(
		$font,
		$fallback
	) {

		$options =
			TutorHelper_Pro_Branding::
				get_font_options();

		return isset(
			$options[ $font ]
		)
			? $font
			: $fallback;
	}
}
