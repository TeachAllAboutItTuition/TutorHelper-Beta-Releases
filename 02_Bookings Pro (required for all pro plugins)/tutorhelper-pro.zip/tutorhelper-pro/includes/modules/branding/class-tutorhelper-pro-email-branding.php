<?php
/**
 * TutorHelper Pro branded email layout.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies TutorHelper Pro branding to shared Core emails.
 */
final class TutorHelper_Pro_Email_Branding {

	/**
	 * Register email branding hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_email_rendered_html',
			array(
				__CLASS__,
				'render_branded_email',
			),
			10,
			4
		);
	}


	/**
	 * Replace the Core email wrapper with the Pro branded layout.
	 *
	 * @param string $html         Existing Core HTML.
	 * @param string $body_html    Rendered email body.
	 * @param array  $template     Email template definition.
	 * @param array  $placeholders Placeholder values.
	 *
	 * @return string
	 */
	public static function render_branded_email(
		$html,
		$body_html,
		$template,
		$placeholders
	) {

		if (
			! TutorHelper_Pro_License::
				is_active()
		) {
			return $html;
		}

		$branding =
			TutorHelper_Pro_Branding::
				get_all();

		return self::build_email(
			$body_html,
			$template,
			$placeholders,
			$branding
		);
	}


	/**
	 * Build the branded email.
	 *
	 * @param string $body_html    Rendered message body.
	 * @param array  $template     Template definition.
	 * @param array  $placeholders Placeholder values.
	 * @param array  $branding     Branding settings.
	 *
	 * @return string
	 */
	private static function build_email(
		$body_html,
		$template,
		$placeholders,
		$branding
	) {

		$business_name =
			! empty(
				$branding[
					'business_name'
				]
			)
				? sanitize_text_field(
					$branding[
						'business_name'
					]
				)
				: get_bloginfo(
					'name'
				);

		$tagline =
			! empty(
				$branding[
					'tagline'
				]
			)
				? sanitize_text_field(
					$branding[
						'tagline'
					]
				)
				: '';

		$website_url =
			! empty(
				$branding[
					'website_url'
				]
			)
				? esc_url(
					$branding[
						'website_url'
					]
				)
				: home_url(
					'/'
				);

		$footer_url =
			! empty(
				$branding[
					'email_footer_url'
				]
			)
				? esc_url(
					$branding[
						'email_footer_url'
					]
				)
				: $website_url;

		$footer_text =
			! empty(
				$branding[
					'email_footer_text'
				]
			)
				? sanitize_textarea_field(
					$branding[
						'email_footer_text'
					]
				)
				: '';

		$banner_url =
			TutorHelper_Pro_Branding::
				get_image_url(
					'email_banner_attachment_id',
					'full'
				);

		$logo_url =
			TutorHelper_Pro_Branding::
				get_image_url(
					'logo_attachment_id',
					'medium'
				);

		$primary_color =
			sanitize_hex_color(
				$branding[
					'primary_color'
				]
			);

		if ( ! $primary_color ) {
			$primary_color =
				'#143f4d';
		}

		$accent_color =
			sanitize_hex_color(
				$branding[
					'accent_color'
				]
			);

		if ( ! $accent_color ) {
			$accent_color =
				'#f46b3b';
		}

		$text_color =
			sanitize_hex_color(
				$branding[
					'text_color'
				]
			);

		if ( ! $text_color ) {
			$text_color =
				'#1d2327';
		}

		$heading_color =
			sanitize_hex_color(
				$branding[
					'heading_color'
				]
			);

		if ( ! $heading_color ) {
			$heading_color =
				$primary_color;
		}

		$background_color =
			sanitize_hex_color(
				$branding[
					'background_color'
				]
			);

		if ( ! $background_color ) {
			$background_color =
				'#ffffff';
		}

		$text_font =
			self::get_safe_font(
				$branding[
					'text_font'
				]
				?? ''
			);

		$heading_font =
			self::get_safe_font(
				$branding[
					'heading_font'
				]
				?? ''
			);

		$heading =
			! empty(
				$template[
					'heading'
				]
			)
				? sanitize_text_field(
					$template[
						'heading'
					]
				)
				: $business_name;

		$email_settings =
			TutorHelper_Email_Settings::
				get_all();

		$contact_email =
			! empty(
				$email_settings[
					'contact_email'
				]
			)
				? sanitize_email(
					$email_settings[
						'contact_email'
					]
				)
				: '';

		$privacy_policy_url =
			! empty(
				$email_settings[
					'privacy_policy_url'
				]
			)
				? esc_url(
					$email_settings[
						'privacy_policy_url'
					]
				)
				: '';

		ob_start();
		?>
		<!doctype html>

		<html>
		<head>
			<meta charset="UTF-8">

			<meta
				name="viewport"
				content="width=device-width, initial-scale=1"
			>

			<title>
				<?php
				echo esc_html(
					$heading
				);
				?>
			</title>
		</head>

		<body
			style="
				margin:0;
				padding:0;
				background:<?php
                    echo esc_attr(
                        $background_color
                    );
                ?>;
				color:<?php
					echo esc_attr(
						$text_color
					);
				?>;
				font-family:<?php
					echo esc_attr(
						$text_font
					);
				?>;
			"
		>

			<table
				role="presentation"
				width="100%"
				cellspacing="0"
				cellpadding="0"
				border="0"
				style="
					width:100%;
					background:<?php
                        echo esc_attr(
                            $background_color
                        );
                    ?>;
					padding:24px 12px;
				"
			>
				<tr>
					<td align="center">

						<table
							role="presentation"
							width="640"
							cellspacing="0"
							cellpadding="0"
							border="0"
							style="
								width:100%;
								max-width:640px;
								background:<?php
									echo esc_attr(
										$background_color
									);
								?>;
								border:1px solid #dcdcde;
								border-radius:12px;
								overflow:hidden;
							"
						>

							<?php
							if (
								! empty(
									$branding[
										'email_show_banner'
									]
								)
								&& $banner_url
							) :
								?>
								<tr>
									<td
										style="
											padding:0;
											margin:0;
											line-height:0;
										"
									>
										<img
											src="<?php
												echo esc_url(
													$banner_url
												);
											?>"
											alt="<?php
												echo esc_attr(
													$business_name
												);
											?>"
											width="640"
											style="
												display:block;
												width:100%;
												max-width:640px;
												height:auto;
												border:0;
												margin:0;
											"
										>
									</td>
								</tr>
							<?php endif; ?>

							<tr>
								<td
									style="
										padding:30px 32px;
										color:<?php
											echo esc_attr(
												$text_color
											);
										?>;
										font-family:<?php
											echo esc_attr(
												$text_font
											);
										?>;
										font-size:16px;
										line-height:1.6;
									"
								>

									<div
										style="
											width:46px;
											height:5px;
											margin:0 0 18px;
											background:<?php
												echo esc_attr(
													$accent_color
												);
											?>;
											border-radius:999px;
										"
									></div>

									<h1
										style="
											margin:0 0 18px;
											color:<?php
												echo esc_attr(
													$heading_color
												);
											?>;
											font-family:<?php
												echo esc_attr(
													$heading_font
												);
											?>;
											font-size:24px;
											line-height:1.3;
										"
									>
										<?php
										echo esc_html(
											$heading
										);
										?>
									</h1>

									<div
										style="
											color:<?php
												echo esc_attr(
													$text_color
												);
											?>;
											font-family:<?php
												echo esc_attr(
													$text_font
												);
											?>;
										"
									>
										<?php
										echo wp_kses_post(
											$body_html
										);
										?>
									</div>

								</td>
							</tr>

							<tr>
								<td
									style="
										padding:20px 32px;
										background:#f6f7f7;
										border-top:1px solid #dcdcde;
										color:<?php
											echo esc_attr(
												$text_color
											);
										?>;
										font-family:<?php
											echo esc_attr(
												$text_font
											);
										?>;
										font-size:12px;
										line-height:1.5;
									"
								>

									<table
										role="presentation"
										width="100%"
										cellspacing="0"
										cellpadding="0"
										border="0"
									>
										<tr>

											<?php
											if (
												! empty(
													$branding[
														'email_show_logo_footer'
													]
												)
												&& $logo_url
											) :
												?>
												<td
													width="90"
													valign="top"
													style="
														width:90px;
														padding:0 14px 0 0;
													"
												>
													<img
														src="<?php
															echo esc_url(
																$logo_url
															);
														?>"
														alt="<?php
															echo esc_attr(
																$business_name
															);
														?>"
														style="
															display:block;
															width:auto;
															max-width:80px;
															max-height:60px;
															height:auto;
															border:0;
														"
													>
												</td>
											<?php endif; ?>

											<td valign="top">

												<?php
												if (
													! empty(
														$branding[
															'email_show_business_name'
														]
													)
												) :
													?>
													<strong
														style="
															display:block;
															margin:0 0 3px;
															color:<?php
																echo esc_attr(
																	$heading_color
																);
															?>;
															font-family:<?php
																echo esc_attr(
																	$heading_font
																);
															?>;
															font-size:14px;
														"
													>
														<?php
														echo esc_html(
															$business_name
														);
														?>
													</strong>
												<?php endif; ?>

												<?php
												if ( $tagline ) :
													?>
													<div
														style="
															margin:0 0 8px;
														"
													>
														<?php
														echo esc_html(
															$tagline
														);
														?>
													</div>
												<?php endif; ?>

												<?php
												if ( $footer_text ) :
													?>
													<div
														style="
															margin:0 0 8px;
														"
													>
														<?php
														echo nl2br(
															esc_html(
																$footer_text
															)
														);
														?>
													</div>
												<?php endif; ?>

												<?php
												if ( $footer_url ) :
													?>
													<div
														style="
															margin:0 0 8px;
														"
													>
														<a
															href="<?php
																echo esc_url(
																	$footer_url
																);
															?>"
															style="
																color:<?php
																	echo esc_attr(
																		$primary_color
																	);
																?>;
															"
														>
															<?php
															echo esc_html(
																$footer_url
															);
															?>
														</a>
													</div>
												<?php endif; ?>

												<?php
												if ( $contact_email ) :
													?>
													<div
														style="
															margin:0 0 6px;
														"
													>
														<?php
														echo esc_html__(
															'Contact:',
															'tutorhelper-pro'
														);
														?>

														<a
															href="mailto:<?php
																echo esc_attr(
																	$contact_email
																);
															?>"
															style="
																color:<?php
																	echo esc_attr(
																		$primary_color
																	);
																?>;
															"
														>
															<?php
															echo esc_html(
																$contact_email
															);
															?>
														</a>
													</div>
												<?php endif; ?>

												<?php
												if ( $privacy_policy_url ) :
													?>
													<div>
														<a
															href="<?php
																echo esc_url(
																	$privacy_policy_url
																);
															?>"
															style="
																color:<?php
																	echo esc_attr(
																		$primary_color
																	);
																?>;
															"
														>
															<?php
															echo esc_html__(
																'Privacy Policy',
																'tutorhelper-pro'
															);
															?>
														</a>
													</div>
												<?php endif; ?>

											</td>
										</tr>
									</table>

								</td>
							</tr>

						</table>

					</td>
				</tr>
			</table>

		</body>
		</html>
		<?php

		return wp_kses_post(
			ob_get_clean()
		);
	}


	/**
	 * Return a supported email-safe font stack.
	 *
	 * @param string $font Requested font stack.
	 *
	 * @return string
	 */
	private static function get_safe_font(
		$font
	) {

		$options =
			TutorHelper_Pro_Branding::
				get_font_options();

		return isset(
			$options[ $font ]
		)
			? $font
			: 'Arial, Helvetica, sans-serif';
	}
}
