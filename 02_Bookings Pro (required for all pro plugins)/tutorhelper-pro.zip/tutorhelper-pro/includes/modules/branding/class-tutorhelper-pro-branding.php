<?php
/**
 * TutorHelper Pro branding settings.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and exposes shared TutorHelper Pro branding.
 */
final class TutorHelper_Pro_Branding {

	/**
	 * Branding option key.
	 *
	 * @var string
	 */
	const OPTION_NAME =
		'tutorhelper_pro_branding';


	/**
	 * Return default branding settings.
	 *
	 * @return array
	 */
	public static function get_defaults() {

		return array(
			'business_name' =>
				get_bloginfo(
					'name'
				),

			'logo_attachment_id' =>
				0,

			'email_banner_attachment_id' =>
				0,

			'tagline' =>
				get_bloginfo(
					'description'
				),

			'website_url' =>
				home_url(
					'/'
				),

			'primary_color' =>
				'#143f4d',

			'accent_color' =>
				'#f46b3b',

			'text_color' =>
				'#1d2327',

			'text_font' =>
				'Arial, Helvetica, sans-serif',

			'heading_color' =>
				'#143f4d',

			'heading_font' =>
				'Arial, Helvetica, sans-serif',

			/*
            * Email page background.
            */
            'background_color' =>
                '#f6f7f7',

            /*
            * Student-facing form colours.
            */
            'form_background_color' =>
                '#faf1eb',

            'form_box_color' =>
                '#ffffff',

            'calendar_color' =>
                '#f8eee8',

            'button_text_color' =>
                '#ffffff',

			'email_show_banner' =>
				1,

			'email_show_logo_footer' =>
				1,

			'email_show_business_name' =>
				1,

			'email_footer_text' =>
				'',

			'email_footer_url' =>
				'',

			'booking_form_branding' =>
				1,

			'registration_form_branding' =>
				1,

			'student_dashboard_branding' =>
				1,

			'parent_dashboard_branding' =>
				1,
		);
	}


	/**
	 * Return all saved branding settings.
	 *
	 * @return array
	 */
	public static function get_all() {

		$saved =
			get_option(
				self::OPTION_NAME,
				array()
			);

		return wp_parse_args(
			is_array( $saved )
				? $saved
				: array(),
			self::get_defaults()
		);
	}


	/**
	 * Return one branding value.
	 *
	 * @param string $key Setting key.
	 *
	 * @return mixed
	 */
	public static function get(
		$key
	) {

		$settings =
			self::get_all();

		return array_key_exists(
			$key,
			$settings
		)
			? $settings[ $key ]
			: null;
	}


    	/**
	 * Return supported branding font stacks.
	 *
	 * System fonts are intentionally used so the same branding
	 * remains suitable for both web pages and HTML email.
	 *
	 * @return array
	 */
	public static function get_font_options() {

		return array(
			'Arial, Helvetica, sans-serif' =>
				'Arial',

			'Verdana, Geneva, sans-serif' =>
				'Verdana',

			'Tahoma, Geneva, sans-serif' =>
				'Tahoma',

			'"Trebuchet MS", Helvetica, sans-serif' =>
				'Trebuchet MS',

			'Georgia, "Times New Roman", serif' =>
				'Georgia',

			'"Times New Roman", Times, serif' =>
				'Times New Roman',

			'"Courier New", Courier, monospace' =>
				'Courier New',
		);
	}



    /**
     * Reset colour and typography settings to defaults.
     *
     * Business identity, email content and feature toggles
     * are deliberately preserved.
     *
     * @return bool
     */
    public static function reset_colours() {

        $settings =
            self::get_all();

        $defaults =
            self::get_defaults();

        $reset_keys = array(
            'primary_color',
            'accent_color',
            'text_color',
            'text_font',
            'heading_color',
            'heading_font',
            'background_color',
            'form_background_color',
            'form_box_color',
            'calendar_color',
            'button_text_color',
        );

        foreach (
            $reset_keys
            as $key
        ) {
            $settings[ $key ] =
                $defaults[ $key ];
        }

        return update_option(
            self::OPTION_NAME,
            $settings,
            false
        );
    }

    /**
	 * Save branding settings.
	 *
	 * @param array $data Raw submitted settings.
	 *
	 * @return true
	 */
	public static function save(
		$data
	) {

		$data =
			is_array( $data )
				? $data
				: array();

		$defaults =
			self::get_defaults();

		$settings =
			array(
				'business_name' =>
					self::sanitize_text(
						$data,
						'business_name'
					),

				'logo_attachment_id' =>
					self::sanitize_image_attachment(
						$data[
							'logo_attachment_id'
						]
						?? 0
					),

				'email_banner_attachment_id' =>
					self::sanitize_image_attachment(
						$data[
							'email_banner_attachment_id'
						]
						?? 0
					),

				'tagline' =>
					self::sanitize_text(
						$data,
						'tagline'
					),

				'website_url' =>
					self::sanitize_url(
						$data,
						'website_url'
					),

				'primary_color' =>
					self::sanitize_color(
						$data[
							'primary_color'
						]
						?? '',
						$defaults[
							'primary_color'
						]
					),

				'accent_color' =>
					self::sanitize_color(
						$data[
							'accent_color'
						]
						?? '',
						$defaults[
							'accent_color'
						]
					),

				'text_color' =>
					self::sanitize_color(
						$data[
							'text_color'
						]
						?? '',
						$defaults[
							'text_color'
						]
					),

				'text_font' =>
					self::sanitize_font(
						$data[
							'text_font'
						]
						?? '',
						$defaults[
							'text_font'
						]
					),

				'heading_color' =>
					self::sanitize_color(
						$data[
							'heading_color'
						]
						?? '',
						$defaults[
							'heading_color'
						]
					),

				'heading_font' =>
					self::sanitize_font(
						$data[
							'heading_font'
						]
						?? '',
						$defaults[
							'heading_font'
						]
					),

				'background_color' =>
					self::sanitize_color(
						$data[
							'background_color'
						]
						?? '',
						$defaults[
							'background_color'
						]
					),

                'form_background_color' =>
                    self::sanitize_color(
                        $data[
                            'form_background_color'
                        ]
                            ?? '',
                        $defaults[
                            'form_background_color'
                        ]
                    ),

                'form_box_color' =>
                    self::sanitize_color(
                        $data[
                            'form_box_color'
                        ]
                            ?? '',
                        $defaults[
                            'form_box_color'
                        ]
                    ),

                'calendar_color' =>
                    self::sanitize_color(
                        $data[
                            'calendar_color'
                        ]
                            ?? '',
                        $defaults[
                            'calendar_color'
                        ]
                    ),

                'button_text_color' =>
                    self::sanitize_color(
                        $data[
                            'button_text_color'
                        ]
                            ?? '',
                        $defaults[
                            'button_text_color'
                        ]
                    ),

				'email_show_banner' =>
					! empty(
						$data[
							'email_show_banner'
						]
					)
						? 1
						: 0,

				'email_show_logo_footer' =>
					! empty(
						$data[
							'email_show_logo_footer'
						]
					)
						? 1
						: 0,

				'email_show_business_name' =>
					! empty(
						$data[
							'email_show_business_name'
						]
					)
						? 1
						: 0,

				'email_footer_text' =>
					isset(
						$data[
							'email_footer_text'
						]
					)
						? sanitize_textarea_field(
							wp_unslash(
								$data[
									'email_footer_text'
								]
							)
						)
						: '',

				'email_footer_url' =>
					self::sanitize_url(
						$data,
						'email_footer_url'
					),

				'booking_form_branding' =>
					! empty(
						$data[
							'booking_form_branding'
						]
					)
						? 1
						: 0,

				'registration_form_branding' =>
					! empty(
						$data[
							'registration_form_branding'
						]
					)
						? 1
						: 0,

				'student_dashboard_branding' =>
					! empty(
						$data[
							'student_dashboard_branding'
						]
					)
						? 1
						: 0,

				'parent_dashboard_branding' =>
					! empty(
						$data[
							'parent_dashboard_branding'
						]
					)
						? 1
						: 0,
			);

		update_option(
			self::OPTION_NAME,
			$settings,
			false
		);

		return true;
	}


    	/**
	 * Sanitise a text field from submitted data.
	 *
	 * @param array  $data Submitted data.
	 * @param string $key  Field key.
	 *
	 * @return string
	 */
	private static function sanitize_text(
		$data,
		$key
	) {

		if (
			! isset(
				$data[ $key ]
			)
			|| is_array(
				$data[ $key ]
			)
		) {
			return '';
		}

		return sanitize_text_field(
			wp_unslash(
				$data[ $key ]
			)
		);
	}


	/**
	 * Sanitise a URL field.
	 *
	 * @param array  $data Submitted data.
	 * @param string $key  Field key.
	 *
	 * @return string
	 */
	private static function sanitize_url(
		$data,
		$key
	) {

		if (
			! isset(
				$data[ $key ]
			)
			|| is_array(
				$data[ $key ]
			)
		) {
			return '';
		}

		return esc_url_raw(
			wp_unslash(
				$data[ $key ]
			)
		);
	}


	/**
	 * Sanitise a hexadecimal colour.
	 *
	 * @param string $value    Submitted colour.
	 * @param string $fallback Default colour.
	 *
	 * @return string
	 */
	private static function sanitize_color(
		$value,
		$fallback
	) {

		$value =
			sanitize_hex_color(
				$value
			);

		return $value
			? $value
			: $fallback;
	}


	/**
	 * Sanitise a selected font stack.
	 *
	 * @param string $value    Submitted font stack.
	 * @param string $fallback Default font stack.
	 *
	 * @return string
	 */
	private static function sanitize_font(
		$value,
		$fallback
	) {

		$value =
			is_array( $value )
				? ''
				: wp_unslash(
					$value
				);

		$options =
			self::get_font_options();

		return array_key_exists(
			$value,
			$options
		)
			? $value
			: $fallback;
	}


	/**
	 * Validate an uploaded image attachment.
	 *
	 * @param int $attachment_id Attachment ID.
	 *
	 * @return int
	 */
	private static function sanitize_image_attachment(
		$attachment_id
	) {

		$attachment_id =
			absint(
				$attachment_id
			);

		if (
			! $attachment_id
			|| ! wp_attachment_is_image(
				$attachment_id
			)
		) {
			return 0;
		}

		return $attachment_id;
	}


    	/**
	 * Return a configured image URL.
	 *
	 * @param string $setting_key Attachment setting key.
	 * @param string $size        WordPress image size.
	 *
	 * @return string
	 */
	public static function get_image_url(
		$setting_key,
		$size = 'large'
	) {

		$attachment_id =
			absint(
				self::get(
					$setting_key
				)
			);

		if ( ! $attachment_id ) {
			return '';
		}

		$url =
			wp_get_attachment_image_url(
				$attachment_id,
				$size
			);

		return $url
			? esc_url_raw(
				$url
			)
			: '';
	}

}
