<?php
/**
 * Student account credits for TutorHelper Pro.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Issues and applies account credit created by paid student cancellations.
 */
final class TutorHelper_Pro_Student_Credits {

	const SCRIPT_HANDLE = 'tutorhelper-pro-finance-credits';
	const STYLE_HANDLE = 'tutorhelper-pro-finance-credits';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'tutorhelper_student_booking_cancelled',
			array( __CLASS__, 'issue_cancellation_credit' ),
			30,
			3
		);

		/*
		 * Run after the normal Pro payment-method filters so a full account
		 * credit can replace Card/Bank/Invoice for this one booking.
		 */
		add_filter(
			'tutorhelper_student_booking_payment_args',
			array( __CLASS__, 'configure_full_credit_payment' ),
			100,
			2
		);

		/*
		 * Run before Stripe Checkout is prepared (priority 10).
		 */
		add_filter(
			'tutorhelper_student_booking_submission_result',
			array( __CLASS__, 'finish_full_credit_booking' ),
			5,
			3
		);

		add_filter(
			'tutorhelper_booking_send_request_emails',
			array( __CLASS__, 'filter_request_emails' ),
			100,
			3
		);

		add_action(
			'tutorhelper_students_detail_lesson_options_pricing',
			array( __CLASS__, 'render_student_credit_balance' ),
			60,
			1
		);

		add_action(
			'tutorhelper_student_booking_form_extensions',
			array( __CLASS__, 'render_student_booking_balance' ),
			5,
			1
		);

		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_finance_assets' )
		);
	}

	/**
	 * Issue account credit when a student cancels a paid lesson.
	 *
	 * Only money already recorded as paid can become account credit. A
	 * pending invoice/bank-transfer booking creates no financial value to
	 * return; cancelling it simply removes the outstanding lesson.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param int    $student_id Student user ID.
	 * @param string $reason     Cancellation reason.
	 * @return void
	 */
	public static function issue_cancellation_credit(
		$booking_id,
		$student_id,
		$reason
	) {
		$booking_id = absint( $booking_id );
		$student_id = absint( $student_id );
		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );

		if (
			! $booking
			|| ! $student_id
			|| $student_id !== absint( $booking->student_user_id )
			|| self::booking_has_credit_issued( $booking_id )
		) {
			return;
		}

		/*
		 * Cancellation updates Core's visible payment status before this hook
		 * runs. The immutable ledger is therefore the only reliable source of
		 * the settled amount that should become account credit.
		 */
		$amount = self::get_cancellation_credit_amount( $booking_id );
		if ( 0 === $amount ) {
			return;
		}

		$currency = strtoupper(
			sanitize_text_field( $booking->currency )
		);

		$result = TutorHelper_Pro_Payment_Ledger::record(
			array(
				'booking_id' => $booking_id,
				'student_user_id' => $student_id,
				'tutor_user_id' => absint( $booking->tutor_user_id ),
				'transaction_type' => TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED,
				'amount_minor_units' => $amount,
				'currency' => $currency,
				'payment_method' => sanitize_key( $booking->payment_method ),
				'payment_provider' => sanitize_key( $booking->payment_provider ),
				'provider_reference' => sanitize_text_field( $booking->payment_reference ),
				'description' => sprintf(
					/* translators: 1: booking ID, 2: cancellation reason. */
					__( 'Account credit issued for cancelled booking #%1$d. Reason: %2$s', 'tutorhelper-pro' ),
					$booking_id,
					trim( sanitize_textarea_field( $reason ) )
				),
				'created_by_user_id' => $student_id,
			)
		);

		if ( is_wp_error( $result ) ) {
			TutorHelper_Logger::error(
				'Cancellation credit could not be recorded.',
				array(
					'booking_id' => $booking_id,
					'error_code' => $result->get_error_code(),
				)
			);
		}
	}

	/**
	 * Return the settled amount that remains eligible for cancellation credit.
	 *
	 * @param int $booking_id Booking ID.
	 * @return int
	 */
	private static function get_cancellation_credit_amount( $booking_id ) {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name(
			'finance_transactions'
		);

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Cancellation credit must use the current immutable ledger.
			$wpdb->prepare(
				'SELECT transaction_type, COALESCE(SUM(amount_minor_units), 0) AS amount
				FROM %i
				WHERE booking_id = %d
				GROUP BY transaction_type',
				$table,
				absint( $booking_id )
			),
			OBJECT_K
		);

		$amount_for = static function ( $type ) use ( $rows ) {
			return isset( $rows[ $type ] )
				? absint( $rows[ $type ]->amount )
				: 0;
		};

		$settled = $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_PAYMENT )
			+ $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_DEPOSIT )
			+ $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED );
		$returned = $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_REFUND )
			+ $amount_for( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED );

		return max( 0, $settled - $returned );
	}
	/**
	 * Replace the normal payment route when available credit covers the
	 * complete lesson price.
	 *
	 * Partial credit is deliberately left on the account for now rather than
	 * changing Core's immutable booking price or creating a split provider
	 * payment without an explicit reservation model.
	 *
	 * @param array|WP_Error $payment_args Current payment args.
	 * @param array          $context      Booking context.
	 * @return array|WP_Error
	 */
	public static function configure_full_credit_payment(
		$payment_args,
		$context
	) {
		if ( ! is_array( $context ) ) {
			return $payment_args;
		}

		$student_id = isset( $context['student_user_id'] )
			? absint( $context['student_user_id'] )
			: 0;

		$pricing = self::resolve_context_pricing( $context );
		if ( is_wp_error( $pricing ) ) {
			return $payment_args;
		}

		$price = absint( $pricing['price_minor_units'] );
		$currency = self::pricing_currency( $pricing );

		if (
			0 === $price
			|| self::get_balance( $student_id, $currency ) < $price
		) {
			return $payment_args;
		}

		return array(
			'skip_payment' => false,
			'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
			'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING,
		);
	}

	/**
	 * Consume a full-price account credit and confirm the booking before
	 * external checkout handlers run.
	 *
	 * @param array  $result          Core submission result.
	 * @param int    $student_user_id Student ID.
	 * @param string $return_url      Booking return URL.
	 * @return array|WP_Error
	 */
	public static function finish_full_credit_booking(
		$result,
		$student_user_id,
		$return_url
	) {
		unset( $return_url );

		if ( ! is_array( $result ) || empty( $result['booking_id'] ) ) {
			return $result;
		}

		$booking_id = absint( $result['booking_id'] );
		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );

		if (
			! $booking
			|| absint( $booking->student_user_id ) !== absint( $student_user_id )
			|| TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING
			!== sanitize_key( $booking->payment_status )
			|| TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL
			!== sanitize_key( $booking->payment_method )
		) {
			return $result;
		}

		$price = absint( $booking->price_minor_units );
		$currency = strtoupper( sanitize_text_field( $booking->currency ) );

		if (
			0 === $price
			|| self::get_balance( $student_user_id, $currency ) < $price
			|| self::booking_has_credit_used( $booking_id )
		) {
			return $result;
		}

		$ledger_result = TutorHelper_Pro_Payment_Ledger::record(
			array(
				'booking_id' => $booking_id,
				'student_user_id' => absint( $student_user_id ),
				'tutor_user_id' => absint( $booking->tutor_user_id ),
				'transaction_type' => TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
				'amount_minor_units' => $price,
				'currency' => $currency,
				'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
				'description' => sprintf(
					/* translators: %d: booking ID. */
					__( 'Account credit applied to booking #%d.', 'tutorhelper-pro' ),
					$booking_id
				),
				'created_by_user_id' => absint( $student_user_id ),
			)
		);

		if ( is_wp_error( $ledger_result ) ) {
			return $result;
		}

		$updated = TutorHelper_Booking_Records::update_payment_details(
			$booking_id,
			array(
				'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
				'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PAID,
				'payment_provider' => '',
				'payment_reference' => 'account_credit',
				'booking_status' => TutorHelper_Booking_Records::STATUS_CONFIRMED,
			),
			TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING
		);

		if ( is_wp_error( $updated ) ) {
			self::restore_failed_credit_use(
				$booking,
				$price,
				$currency
			);
			return $updated;
		}

		$result['status'] = TutorHelper_Booking_Records::STATUS_CONFIRMED;
		$result['message'] = sprintf(
			/* translators: %s: formatted account credit amount. */
			__( 'Your lesson is confirmed. %s account credit was applied to this booking.', 'tutorhelper-pro' ),
			TutorHelper_Currency::format_minor_units( $price, $currency )
		);
		unset( $result['redirect_url'] );

		return $result;
	}

	/**
	 * Prevent Core's temporary request emails for bookings that will be
	 * confirmed immediately using full account credit.
	 *
	 * @param bool  $send        Current decision.
	 * @param int   $booking_id  Booking ID.
	 * @param array $insert_data Insert data.
	 * @return bool
	 */
	public static function filter_request_emails(
		$send,
		$booking_id,
		$insert_data
	) {
		if ( ! is_array( $insert_data ) ) {
			return $send;
		}

		$student_id = isset( $insert_data['student_user_id'] )
			? absint( $insert_data['student_user_id'] )
			: 0;
		$price = isset( $insert_data['price_minor_units'] )
			? absint( $insert_data['price_minor_units'] )
			: 0;
		$currency = isset( $insert_data['currency'] )
			? strtoupper( sanitize_text_field( $insert_data['currency'] ) )
			: TutorHelper_Currency::get_currency();

		if (
			$student_id
			&& $price
			&& TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL
			=== sanitize_key(
				isset( $insert_data['payment_method'] )
					? $insert_data['payment_method']
					: ''
			)
			&& self::get_balance( $student_id, $currency ) >= $price
		) {
			return false;
		}

		unset( $booking_id );
		return $send;
	}

	/**
	 * Return a student's available account credit in one currency.
	 *
	 * @param int    $student_id Student ID.
	 * @param string $currency   Currency code.
	 * @return int Minor units.
	 */
	public static function get_balance( $student_id, $currency = '' ) {
		global $wpdb;

		$student_id = absint( $student_id );
		$currency = $currency
			? strtoupper( sanitize_text_field( $currency ) )
			: TutorHelper_Currency::get_currency();

		if ( ! $student_id ) {
			return 0;
		}

		$table = TutorHelper_Pro_Database::get_table_name(
			'finance_transactions'
		);

		$issued = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Account credit must reflect the current immutable ledger.
			$wpdb->prepare(
				'SELECT COALESCE(SUM(amount_minor_units), 0)
				FROM %i
				WHERE student_user_id = %d
				AND currency = %s
				AND transaction_type = %s',
				$table,
				$student_id,
				$currency,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED
			)
		);

		$used = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Account credit must reflect the current immutable ledger.
			$wpdb->prepare(
				'SELECT COALESCE(SUM(amount_minor_units), 0)
				FROM %i
				WHERE student_user_id = %d
				AND currency = %s
				AND transaction_type IN (%s, %s)',
				$table,
				$student_id,
				$currency,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_REVERSED
			)
		);

		return max( 0, $issued - $used );
	}

	/**
	 * Return credit transactions for Finance display.
	 *
	 * @return array
	 */
	public static function get_finance_credit_transactions() {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name(
			'finance_transactions'
		);

		$types = array(
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED,
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED,
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_REVERSED,
			TutorHelper_Pro_Payment_Ledger::TYPE_REFUND,
		);

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance reporting must use current immutable ledger rows.
			$wpdb->prepare(
				'SELECT id, booking_id, student_user_id, transaction_type,
				amount_minor_units, currency, payment_provider, provider_reference,
				provider_event_id, description, transaction_date, created_by_user_id
				FROM %i
				WHERE transaction_type IN (%s, %s, %s, %s)
				ORDER BY transaction_date ASC, id ASC',
				$table,
				$types[0],
				$types[1],
				$types[2],
				$types[3]
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}
	/**
	 * Show the current balance on the tutor's Student details screen.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render_student_credit_balance( $student ) {
		if (
			! $student instanceof WP_User
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$currency = TutorHelper_Currency::get_currency();
		$balance = self::get_balance( $student->ID, $currency );
		?>
		<section class="tutorhelper-student-detail__section tutorhelper-pro-student-credit-balance">
			<h3><?php esc_html_e( 'Account Credit', 'tutorhelper-pro' ); ?></h3>
			<p>
				<?php esc_html_e( 'Credit created by eligible paid cancellations is kept on the student account for future lessons.', 'tutorhelper-pro' ); ?>
			</p>
			<p>
				<strong><?php esc_html_e( 'Available credit:', 'tutorhelper-pro' ); ?></strong>
				<?php
				echo esc_html(
					TutorHelper_Currency::format_minor_units(
						$balance,
						$currency
					)
				);
				?>
			</p>
		</section>
		<?php
	}

	/**
	 * Show students their current credit balance on the booking form.
	 *
	 * @param int $student_user_id Student ID.
	 * @return void
	 */
	public static function render_student_booking_balance( $student_user_id ) {
		$student_user_id = absint( $student_user_id );
		$currency = TutorHelper_Currency::get_currency();
		$balance = self::get_balance( $student_user_id, $currency );

		if ( 0 >= $balance ) {
			return;
		}
		?>
		<div class="tutorhelper-pro-student-credit-notice">
			<strong><?php esc_html_e( 'Account credit available', 'tutorhelper-pro' ); ?></strong>
			<p>
				<?php
				printf(
					/* translators: %s: formatted credit balance. */
					esc_html__( 'You have %s credit on your account. It will be used automatically when it can cover the full price of your next lesson.', 'tutorhelper-pro' ),
					esc_html(
						TutorHelper_Currency::format_minor_units(
							$balance,
							$currency
						)
					)
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Add credit rows beneath their related booking in the Finance table.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public static function enqueue_finance_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] )
			? sanitize_key( wp_unslash( $_GET['tab'] ) )
			: '';

		$view = isset( $_GET['finance_view'] ) && ! is_array( $_GET['finance_view'] )
			? sanitize_key( wp_unslash( $_GET['finance_view'] ) )
			: '';

		if ( 'finance' !== $tab || 'all' !== $view ) {
			return;
		}

		$script_path = TUTORHELPER_PRO_PATH . 'assets/js/tutorhelper-pro-finance-credits.js';
		$style_path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-finance-credits.css';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/js/tutorhelper-pro-finance-credits.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_PRO_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperProFinanceCredits',
			array(
				'transactions' => self::prepare_transactions_for_browser(),
			)
		);

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-finance-credits.css',
			array( 'tutorhelper-pro-finance' ),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : TUTORHELPER_PRO_VERSION
		);
	}

	/**
	 * Prepare finance credit data for the admin-only table enhancer.
	 *
	 * @return array
	 */
	private static function prepare_transactions_for_browser() {
		$prepared = array();

		$labels = array(
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED =>
				__( 'Account credit issued', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED =>
				__( 'Account credit applied', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_REVERSED =>
				__( 'Account credit reversed for refund', 'tutorhelper-pro' ),
			TutorHelper_Pro_Payment_Ledger::TYPE_REFUND =>
				__( 'Refund recorded', 'tutorhelper-pro' ),
		);

		foreach ( self::get_finance_credit_transactions() as $row ) {
			$booking_id = absint( $row['booking_id'] );
			if ( ! $booking_id ) {
				continue;
			}

			$currency = strtoupper( sanitize_text_field( $row['currency'] ) );
			$amount = absint( $row['amount_minor_units'] );
			$type = sanitize_key( $row['transaction_type'] );
			$actor = get_user_by( 'id', absint( $row['created_by_user_id'] ) );
			$actor_name = $actor instanceof WP_User
				? sanitize_text_field( $actor->display_name )
				: '';

			$prepared[] = array(
				'id' => absint( $row['id'] ),
				'bookingId' => $booking_id,
				'type' => $type,
				'label' => isset( $labels[ $type ] )
					? $labels[ $type ]
					: __( 'Finance transaction', 'tutorhelper-pro' ),
				'amount' => TutorHelper_Currency::format_minor_units( $amount, $currency ),
				'description' => sanitize_text_field( $row['description'] ),
				'date' => self::format_transaction_date( $row['transaction_date'] ),
				'actor' => $actor_name,
				'paymentProvider' => sanitize_key( $row['payment_provider'] ),
				'providerReference' => sanitize_text_field( $row['provider_reference'] ),
				'providerEventId' => sanitize_text_field( $row['provider_event_id'] ),
			);
		}

		return $prepared;
	}
	/**
	 * Resolve authoritative pricing for a booking request context.
	 *
	 * @param array $context Booking context.
	 * @return array|WP_Error
	 */
	private static function resolve_context_pricing( $context ) {
		try {
			$timezone = new DateTimeZone(
				sanitize_text_field(
					isset( $context['timezone'] ) ? $context['timezone'] : ''
				)
			);
			$start = new DateTimeImmutable(
				sanitize_text_field(
					isset( $context['booking_start'] ) ? $context['booking_start'] : ''
				),
				$timezone
			);
			$end = new DateTimeImmutable(
				sanitize_text_field(
					isset( $context['booking_end'] ) ? $context['booking_end'] : ''
				),
				$timezone
			);
		} catch ( Exception $exception ) {
			return new WP_Error(
				'tutorhelper_pro_credit_booking_time_invalid',
				__( 'The lesson time could not be prepared for account credit.', 'tutorhelper-pro' )
			);
		}

		$seconds = $end->getTimestamp() - $start->getTimestamp();
		if ( 0 >= $seconds || 0 !== $seconds % MINUTE_IN_SECONDS ) {
			return new WP_Error(
				'tutorhelper_pro_credit_duration_invalid',
				__( 'The lesson duration could not be prepared for account credit.', 'tutorhelper-pro' )
			);
		}

		return TutorHelper_Booking_Records::resolve_pricing(
			absint( isset( $context['student_user_id'] ) ? $context['student_user_id'] : 0 ),
			absint( isset( $context['booking_type_id'] ) ? $context['booking_type_id'] : 0 ),
			(int) ( $seconds / MINUTE_IN_SECONDS )
		);
	}

	/**
	 * Return pricing currency with a Core fallback.
	 *
	 * @param array $pricing Pricing result.
	 * @return string
	 */
	private static function pricing_currency( $pricing ) {
		return ! empty( $pricing['currency'] )
			? strtoupper( sanitize_text_field( $pricing['currency'] ) )
			: TutorHelper_Currency::get_currency();
	}

	/**
	 * Check whether the cancellation credit already exists.
	 *
	 * @param int $booking_id Booking ID.
	 * @return bool
	 */
	private static function booking_has_credit_issued( $booking_id ) {
		return self::booking_has_transaction_type(
			$booking_id,
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED
		);
	}

	/**
	 * Check whether a credit-use entry already exists.
	 *
	 * @param int $booking_id Booking ID.
	 * @return bool
	 */
	private static function booking_has_credit_used( $booking_id ) {
		return self::booking_has_transaction_type(
			$booking_id,
			TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED
		);
	}

	/**
	 * Query one booking/transaction type for idempotency.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param string $type       Ledger type.
	 * @return bool
	 */
	private static function booking_has_transaction_type( $booking_id, $type ) {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name(
			'finance_transactions'
		);

		$count = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Idempotency must use the current immutable ledger.
			$wpdb->prepare(
				'SELECT COUNT(*)
				FROM %i
				WHERE booking_id = %d
				AND transaction_type = %s',
				$table,
				absint( $booking_id ),
				sanitize_key( $type )
			)
		);

		return 0 < $count;
	}

	/**
	 * Restore credit if the booking could not be moved into Paid/Confirmed
	 * after the immutable credit-use transaction was recorded.
	 *
	 * @param object $booking  Booking record.
	 * @param int    $amount   Minor units.
	 * @param string $currency Currency.
	 * @return void
	 */
	private static function restore_failed_credit_use( $booking, $amount, $currency ) {
		TutorHelper_Pro_Payment_Ledger::record(
			array(
				'booking_id' => absint( $booking->id ),
				'student_user_id' => absint( $booking->student_user_id ),
				'tutor_user_id' => absint( $booking->tutor_user_id ),
				'transaction_type' => TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED,
				'amount_minor_units' => absint( $amount ),
				'currency' => strtoupper( sanitize_text_field( $currency ) ),
				'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
				'description' => __( 'Account credit restored because the credited booking could not be confirmed.', 'tutorhelper-pro' ),
			)
		);
	}

	/**
	 * Friendly transaction date.
	 *
	 * @param string $date UTC transaction date.
	 * @return string
	 */
	private static function format_transaction_date( $date ) {
		try {
			$utc = new DateTimeZone( 'UTC' );
			$value = new DateTimeImmutable(
				sanitize_text_field( $date ),
				$utc
			);
			$value = $value->setTimezone( wp_timezone() );

			return wp_date(
				get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
				$value->getTimestamp(),
				wp_timezone()
			);
		} catch ( Exception $exception ) {
			return '';
		}
	}
}
