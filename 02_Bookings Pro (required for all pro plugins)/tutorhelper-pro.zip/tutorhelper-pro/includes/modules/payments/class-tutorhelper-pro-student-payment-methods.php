<?php
/**
 * TutorHelper Pro student payment methods.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Splits student payment permissions into Card, Bank Transfer and Invoice.
 */
final class TutorHelper_Pro_Student_Payment_Methods {

	const META_ALLOW_CARD = 'tutorhelper_pro_allow_card_payment';
	const META_ALLOW_BANK = 'tutorhelper_pro_allow_bank_transfer';
	const META_ALLOW_INVOICE = 'tutorhelper_pro_allow_invoice';
	const LEGACY_META_ALLOW_MANUAL = 'tutorhelper_pro_allow_manual_payment';

	const SAVE_ACTION = 'tutorhelper_pro_save_student_payment_methods';
	const SCRIPT_HANDLE = 'tutorhelper-pro-student-payment-methods';
	const STYLE_HANDLE = 'tutorhelper-pro-student-payment-choice';
	const SCHEMA_OPTION = 'tutorhelper_pro_manual_payment_schema';
	const SCHEMA_VERSION = '1.0.0';

	const TYPE_BANK_TRANSFER = 'bank_transfer';
	const TYPE_INVOICE = 'invoice';

	const TEMPLATE_BANK_STUDENT = 'bank_transfer_instructions_student';
	const TEMPLATE_BANK_TUTOR = 'bank_transfer_booking_tutor';
	const TEMPLATE_INVOICE_STUDENT = 'invoice_booking_student';
	const TEMPLATE_INVOICE_TUTOR = 'invoice_booking_tutor';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		self::ensure_finance_columns();
		self::register_templates();

		add_action(
			'tutorhelper_students_detail_lesson_options_pricing',
			array( __CLASS__, 'render_student_settings' ),
			20,
			1
		);

		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array( __CLASS__, 'handle_save' )
		);

		add_filter(
			'tutorhelper_student_booking_payment_args',
			array( __CLASS__, 'configure_payment' ),
			30,
			2
		);

		add_filter(
			'tutorhelper_student_booking_submission_result',
			array( __CLASS__, 'finish_manual_booking' ),
			30,
			3
		);

		add_filter(
			'tutorhelper_booking_send_request_emails',
			array( __CLASS__, 'filter_request_emails' ),
			30,
			3
		);

		add_action(
			'wp_enqueue_scripts',
			array( __CLASS__, 'register_frontend_assets' ),
			30
		);

		add_action(
			'wp_footer',
			array( __CLASS__, 'enqueue_frontend_script' ),
			5
		);

		add_action(
			'tutorhelper_student_booking_after_cancellation_policy',
			array( __CLASS__, 'render_booking_payment_data' ),
			20,
			2
		);

		add_filter(
			'tutorhelper_student_data_export',
			array( __CLASS__, 'add_privacy_export_data' ),
			30,
			2
		);

		add_action(
			'tutorhelper_before_student_data_delete',
			array( __CLASS__, 'delete_privacy_data' ),
			30,
			3
		);
	}

	/**
	 * Card is the default for students unless the tutor explicitly disables it.
	 *
	 * @param int $student_id Student user ID.
	 * @return bool
	 */
	public static function card_is_allowed( $student_id ) {
		$value = get_user_meta(
			absint( $student_id ),
			self::META_ALLOW_CARD,
			true
		);

		return '' === $value || '1' === (string) $value;
	}

	/**
	 * @param int $student_id Student user ID.
	 * @return bool
	 */
	public static function bank_is_allowed( $student_id ) {
		$value = get_user_meta(
			absint( $student_id ),
			self::META_ALLOW_BANK,
			true
		);

		if ( '1' === (string) $value ) {
			return true;
		}

		return '' === $value
			&& '1' === (string) get_user_meta(
				absint( $student_id ),
				self::LEGACY_META_ALLOW_MANUAL,
				true
			);
	}

	/**
	 * @param int $student_id Student user ID.
	 * @return bool
	 */
	public static function invoice_is_allowed( $student_id ) {
		$value = get_user_meta(
			absint( $student_id ),
			self::META_ALLOW_INVOICE,
			true
		);

		if ( '1' === (string) $value ) {
			return true;
		}

		return '' === $value
			&& '1' === (string) get_user_meta(
				absint( $student_id ),
				self::LEGACY_META_ALLOW_MANUAL,
				true
			);
	}

	/**
	 * Render student-specific payment permissions.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render_student_settings( $student ) {
		if (
			! $student instanceof WP_User
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$student_id = absint( $student->ID );
		self::render_notice();
		?>
		<section class="tutorhelper-student-detail__section tutorhelper-pro-student-payment-settings">
			<h3><?php esc_html_e( 'Payment Options', 'tutorhelper-pro' ); ?></h3>
			<p><?php esc_html_e( 'Choose which payment methods this student may use for paid lessons. Card is enabled by default for new students.', 'tutorhelper-pro' ); ?></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
				<input type="hidden" name="student_id" value="<?php echo esc_attr( $student_id ); ?>" />
				<?php wp_nonce_field( self::SAVE_ACTION, 'tutorhelper_pro_student_payment_methods_nonce' ); ?>

				<?php
				self::render_toggle(
					'allow_card_payment',
					__( 'Allow card payment', 'tutorhelper-pro' ),
					__( 'Use secure online card payment when Stripe is configured. If card payment is unavailable, TutorHelper falls back to the normal lesson-request workflow.', 'tutorhelper-pro' ),
					self::card_is_allowed( $student_id )
				);

				self::render_toggle(
					'allow_bank_transfer',
					__( 'Allow bank transfer', 'tutorhelper-pro' ),
					__( 'The lesson is held while payment is pending. The student receives bank details by email and the lesson is confirmed when payment is recorded.', 'tutorhelper-pro' ),
					self::bank_is_allowed( $student_id )
				);

				self::render_toggle(
					'allow_invoice',
					__( 'Allow invoice', 'tutorhelper-pro' ),
					__( 'The lesson is confirmed immediately and the student is told that the tutor will add it to their next invoice.', 'tutorhelper-pro' ),
					self::invoice_is_allowed( $student_id )
				);
				?>

				<p>
					<button type="submit" class="button tutorhelper-admin-button tutorhelper-admin-button--primary">
						<?php esc_html_e( 'Save payment options', 'tutorhelper-pro' ); ?>
					</button>
				</p>
			</form>
		</section>
		<?php
	}

	private static function render_toggle( $name, $label, $description, $checked_value ) {
		?>
		<label class="tutorhelper-toggle-row">
			<input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $checked_value ); ?> />
			<span>
				<strong><?php echo esc_html( $label ); ?></strong><br />
				<small><?php echo esc_html( $description ); ?></small>
			</span>
		</label>
		<?php
	}

	/**
	 * Save payment permissions.
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die(
				esc_html__( 'You do not have permission to manage student payment options.', 'tutorhelper-pro' ),
				esc_html__( 'Permission denied', 'tutorhelper-pro' ),
				array( 'response' => 403 )
			);
		}

		check_admin_referer(
			self::SAVE_ACTION,
			'tutorhelper_pro_student_payment_methods_nonce'
		);

		$student_id = isset( $_POST['student_id'] )
			? absint( wp_unslash( $_POST['student_id'] ) )
			: 0;

		if ( ! TutorHelper_Students::get_student( $student_id ) instanceof WP_User ) {
			self::redirect( $student_id, 'invalid_student' );
		}

		self::save_boolean_meta(
			$student_id,
			self::META_ALLOW_CARD,
			isset( $_POST['allow_card_payment'] )
		);
		self::save_boolean_meta(
			$student_id,
			self::META_ALLOW_BANK,
			isset( $_POST['allow_bank_transfer'] )
		);
		self::save_boolean_meta(
			$student_id,
			self::META_ALLOW_INVOICE,
			isset( $_POST['allow_invoice'] )
		);

		delete_user_meta(
			$student_id,
			self::LEGACY_META_ALLOW_MANUAL
		);

		self::redirect( $student_id, 'saved' );
	}

	private static function save_boolean_meta( $student_id, $meta_key, $enabled ) {
		update_user_meta(
			absint( $student_id ),
			$meta_key,
			$enabled ? '1' : '0'
		);
	}

	/**
	 * Configure the selected payment route.
	 *
	 * @param array|WP_Error $payment_args Current payment args.
	 * @param array          $context      Booking context.
	 * @return array|WP_Error
	 */
	public static function configure_payment( $payment_args, $context ) {
		if ( ! is_array( $context ) ) {
			return $payment_args;
		}

		$student_id = isset( $context['student_user_id'] )
			? absint( $context['student_user_id'] )
			: 0;
		$method = self::get_requested_method();

		$duration = self::calculate_duration_minutes(
			isset( $context['booking_start'] ) ? $context['booking_start'] : '',
			isset( $context['booking_end'] ) ? $context['booking_end'] : '',
			isset( $context['timezone'] ) ? $context['timezone'] : ''
		);

		if ( is_wp_error( $duration ) ) {
			return $duration;
		}

		$pricing = TutorHelper_Booking_Records::resolve_pricing(
			$student_id,
			absint( isset( $context['booking_type_id'] ) ? $context['booking_type_id'] : 0 ),
			$duration
		);

		if ( is_wp_error( $pricing ) ) {
			return $pricing;
		}

		if ( 0 === absint( $pricing['price_minor_units'] ) ) {
			return is_array( $payment_args )
				? $payment_args
				: self::core_request_args();
		}

		$available_methods = self::get_available_methods( $student_id );

		if ( ! $method && 1 === count( $available_methods ) ) {
			$method = $available_methods[0];
		}

		if ( ! $method && 1 < count( $available_methods ) ) {
			return new WP_Error(
				'tutorhelper_pro_payment_method_required',
				__( 'Please choose a payment method before booking this lesson.', 'tutorhelper-pro' )
			);
		}

		if ( $method && ! in_array( $method, $available_methods, true ) ) {
			return new WP_Error(
				'tutorhelper_pro_payment_method_not_allowed',
				__( 'The selected payment method is not available for this account.', 'tutorhelper-pro' )
			);
		}

		if ( 'stripe' === $method ) {
			if ( ! self::card_is_allowed( $student_id ) ) {
				return new WP_Error(
					'tutorhelper_pro_card_not_allowed',
					__( 'Card payment is not available for this account.', 'tutorhelper-pro' )
				);
			}

			if ( ! TutorHelper_Pro_Payment_Settings::stripe_is_configured() ) {
				return self::core_request_args();
			}

			return $payment_args;
		}

		if ( self::TYPE_BANK_TRANSFER === $method ) {
			if ( ! self::bank_is_allowed( $student_id ) ) {
				return new WP_Error(
					'tutorhelper_pro_bank_transfer_not_allowed',
					__( 'Bank transfer is not available for this account.', 'tutorhelper-pro' )
				);
			}

			if ( ! TutorHelper_Pro_Bank_Details::is_configured() ) {
				return new WP_Error(
					'tutorhelper_pro_bank_transfer_unavailable',
					__( 'Bank transfer is temporarily unavailable. Please choose another payment method or contact your tutor.', 'tutorhelper-pro' )
				);
			}

			return self::manual_payment_args();
		}

		if ( self::TYPE_INVOICE === $method ) {
			if ( ! self::invoice_is_allowed( $student_id ) ) {
				return new WP_Error(
					'tutorhelper_pro_invoice_not_allowed',
					__( 'Invoice payment is not available for this account.', 'tutorhelper-pro' )
				);
			}

			return self::manual_payment_args();
		}

		return self::core_request_args();
	}

	private static function core_request_args() {
		return array(
			'skip_payment' => true,
			'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_FREE,
			'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_NOT_REQUIRED,
		);
	}

	private static function manual_payment_args() {
		return array(
			'skip_payment' => false,
			'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
			'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING,
		);
	}

	/**
	 * Finish a Bank Transfer or Invoice booking after Core creates it.
	 *
	 * @param array  $result          Core submission result.
	 * @param int    $student_user_id Student ID.
	 * @param string $return_url      Return URL.
	 * @return array|WP_Error
	 */
	public static function finish_manual_booking( $result, $student_user_id, $return_url ) {
		unset( $return_url );

		if ( ! is_array( $result ) || empty( $result['booking_id'] ) ) {
			return $result;
		}

		$method = self::get_requested_method();
		if (
			self::TYPE_BANK_TRANSFER !== $method
			&& self::TYPE_INVOICE !== $method
		) {
			return $result;
		}

		$booking_id = absint( $result['booking_id'] );
		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );

		if (
			! $booking
			|| absint( $booking->student_user_id ) !== absint( $student_user_id )
			|| TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL
			!== sanitize_key( $booking->payment_method )
			|| TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING
			!== sanitize_key( $booking->payment_status )
		) {
			return $result;
		}

		self::save_manual_payment_type(
			$booking_id,
			$method
		);

		if ( self::TYPE_BANK_TRANSFER === $method ) {
			self::send_template( self::TEMPLATE_BANK_STUDENT, $booking_id, 'student' );
			self::send_template( self::TEMPLATE_BANK_TUTOR, $booking_id, 'tutor' );

			$result['message'] = __(
				'Your lesson is being held while we wait for your bank transfer. Please check your email for payment details.',
				'tutorhelper-pro'
			);
			unset( $result['redirect_url'] );
			return $result;
		}

		/*
		 * Invoice bookings are confirmed immediately but remain unpaid.
		 */
		$updated = TutorHelper_Booking_Records::update_payment_details(
			$booking_id,
			array(
				'payment_method' => TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
				'payment_status' => TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING,
				'payment_provider' => '',
				'payment_reference' => '',
				'booking_status' => TutorHelper_Booking_Records::STATUS_CONFIRMED,
			),
			TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING
		);

		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		self::send_template( self::TEMPLATE_INVOICE_STUDENT, $booking_id, 'student' );
		self::send_template( self::TEMPLATE_INVOICE_TUTOR, $booking_id, 'tutor' );

		$result['status'] = TutorHelper_Booking_Records::STATUS_CONFIRMED;
		$result['message'] = __(
			'Your lesson is confirmed. Your tutor will add this lesson to your next invoice.',
			'tutorhelper-pro'
		);
		unset( $result['redirect_url'] );

		return $result;
	}

	/**
	 * Suppress Core request emails only for the two manual workflows.
	 *
	 * @param bool  $send        Existing decision.
	 * @param int   $booking_id  Booking ID.
	 * @param array $insert_data Insert data.
	 * @return bool
	 */
	public static function filter_request_emails( $send, $booking_id, $insert_data ) {
		unset( $booking_id );

		if ( ! is_array( $insert_data ) ) {
			return $send;
		}

		$method = self::get_requested_method();
		if (
			in_array(
				$method,
				array( self::TYPE_BANK_TRANSFER, self::TYPE_INVOICE ),
				true
			)
			&& TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL
			=== sanitize_key(
				isset( $insert_data['payment_method'] )
					? $insert_data['payment_method']
					: ''
			)
		) {
			return false;
		}

		return $send;
	}

	/**
	 * Register and localise the student payment UI.
	 *
	 * @return void
	 */
	public static function register_frontend_assets() {
		$student_id = self::get_booking_context_student_id();

		if ( ! $student_id || empty( self::get_available_methods( $student_id ) ) ) {
			return;
		}

		$script_path = TUTORHELPER_PRO_PATH
			. 'assets/js/student-payment-methods.js';
		$style_path = TUTORHELPER_PRO_PATH
			. 'assets/css/student-payment-choice.css';

		wp_register_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/js/student-payment-methods.js',
			array( 'tutorhelper-student-booking-extensions' ),
			file_exists( $script_path )
				? (string) filemtime( $script_path )
				: TUTORHELPER_PRO_VERSION,
			true
		);

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/css/student-payment-choice.css',
			array(),
			file_exists( $style_path )
				? (string) filemtime( $style_path )
				: TUTORHELPER_PRO_VERSION
		);

		$methods = self::get_available_methods( $student_id );
		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperProPaymentMethods',
			array(
				'methods' => $methods,
				'labels'  => array(
					'card' => __( 'Pay by card', 'tutorhelper-pro' ),
					'bank' => __( 'Bank transfer', 'tutorhelper-pro' ),
					'invoice' => __( 'Invoice', 'tutorhelper-pro' ),
					'bankNote' => __( 'Your lesson will be confirmed once payment is received. Details of how to pay will be sent to you by email.', 'tutorhelper-pro' ),
					'invoiceNote' => __( 'Your lesson cost will be added to your next tuition invoice.', 'tutorhelper-pro' ),
					'requestLesson' => __( 'Request lesson', 'tutorhelper-pro' ),
					'bookAndPay' => __( 'Book & Pay', 'tutorhelper-pro' ),
					'bookAndInvoice' => __( 'Book & Add To Invoice', 'tutorhelper-pro' ),
					'paymentMethod' => __( 'Payment method', 'tutorhelper-pro' ),
					'choosePaymentMethod' => __( 'Choose how you would like to pay for this lesson.', 'tutorhelper-pro' ),
				),
			)
		);
	}


	/**
	 * Attach payment choices to the individual booking form instance.
	 *
	 * This keeps a Parent Dashboard partial refresh tied to the selected child.
	 *
	 * @param int    $student_id Student user ID.
	 * @param string $booking_mode Student or parent booking mode.
	 * @return void
	 */
	public static function render_booking_payment_data( $student_id, $booking_mode ) {
		if ( 'preview' === sanitize_key( $booking_mode ) ) {
			return;
		}

		$methods = self::get_available_methods( absint( $student_id ) );

		if ( empty( $methods ) ) {
			return;
		}

		$config = array(
			'methods' => $methods,
			'labels'  => array(
				'card' => __( 'Pay by card', 'tutorhelper-pro' ),
				'bank' => __( 'Bank transfer', 'tutorhelper-pro' ),
				'invoice' => __( 'Invoice', 'tutorhelper-pro' ),
				'bankNote' => __( 'Your lesson will be confirmed once payment is received. Details of how to pay will be sent to you by email.', 'tutorhelper-pro' ),
				'invoiceNote' => __( 'Your lesson cost will be added to your next tuition invoice.', 'tutorhelper-pro' ),
				'requestLesson' => __( 'Request lesson', 'tutorhelper-pro' ),
				'bookAndPay' => __( 'Book & Pay', 'tutorhelper-pro' ),
				'bookAndInvoice' => __( 'Book & Add To Invoice', 'tutorhelper-pro' ),
				'paymentMethod' => __( 'Payment method', 'tutorhelper-pro' ),
				'choosePaymentMethod' => __( 'Choose how you would like to pay for this lesson.', 'tutorhelper-pro' ),
			),
		);
		?>
		<div
			hidden
			data-tutorhelper-payment-methods
			data-payment-methods="<?php echo esc_attr( wp_json_encode( $config ) ); ?>"
		></div>
		<?php
	}

	public static function enqueue_frontend_script() {
		if (
			! self::current_student_has_payment_choices()
			|| ! wp_script_is( 'tutorhelper-student-booking', 'enqueued' )
		) {
			return;
		}

		if ( ! wp_script_is( self::SCRIPT_HANDLE, 'registered' ) ) {
			self::register_frontend_assets();
		}

		wp_enqueue_script( self::SCRIPT_HANDLE );
	}

	/**
	 * Return only payment routes that are both allowed for the student and usable.
	 *
	 * @param int $student_id Student user ID.
	 * @return string[]
	 */
	private static function get_available_methods( $student_id ) {
		$methods = array();

		if (
			self::card_is_allowed( $student_id )
			&& TutorHelper_Pro_Payment_Settings::stripe_is_configured()
		) {
			$methods[] = 'stripe';
		}

		if (
			self::bank_is_allowed( $student_id )
			&& TutorHelper_Pro_Bank_Details::is_configured()
		) {
			$methods[] = self::TYPE_BANK_TRANSFER;
		}

		if ( self::invoice_is_allowed( $student_id ) ) {
			$methods[] = self::TYPE_INVOICE;
		}

		return $methods;
	}

	/**
	 * Resolve the student whose payment permissions apply to this form.
	 *
	 * @return int
	 */
	private static function get_booking_context_student_id() {
		if ( ! is_user_logged_in() ) {
			return 0;
		}

		if ( class_exists( 'TutorHelper_Student_Booking_Context' ) ) {
			$context = TutorHelper_Student_Booking_Context::resolve();

			/*
			 * A successful Core resolver result has already verified ownership
			 * or delegated parent access. The returned normalised context does
			 * not retain the internal is_authorised marker.
			 */
			if (
				is_array( $context )
				&& ! empty( $context['student_user_id'] )
			) {
				return absint( $context['student_user_id'] );
			}
		}

		return absint( get_current_user_id() );
	}

	private static function current_student_has_payment_choices() {
		$student_id = self::get_booking_context_student_id();

		return $student_id
			&& TutorHelper_Students::get_student( $student_id ) instanceof WP_User
			&& ! empty( self::get_available_methods( $student_id ) );
	}

	/**
	 * Add payment permissions to privacy exports.
	 *
	 * @param array   $data Export data.
	 * @param WP_User $student Student.
	 * @return array
	 */
	public static function add_privacy_export_data( $data, $student ) {
		if ( ! is_array( $data ) || ! $student instanceof WP_User ) {
			return $data;
		}

		if ( ! isset( $data['pro'] ) || ! is_array( $data['pro'] ) ) {
			$data['pro'] = array();
		}
		if ( ! isset( $data['pro']['user_meta'] ) || ! is_array( $data['pro']['user_meta'] ) ) {
			$data['pro']['user_meta'] = array();
		}

		$student_id = absint( $student->ID );
		$data['pro']['user_meta'][ self::META_ALLOW_CARD ] = self::card_is_allowed( $student_id ) ? '1' : '0';
		$data['pro']['user_meta'][ self::META_ALLOW_BANK ] = self::bank_is_allowed( $student_id ) ? '1' : '0';
		$data['pro']['user_meta'][ self::META_ALLOW_INVOICE ] = self::invoice_is_allowed( $student_id ) ? '1' : '0';

		return $data;
	}

	public static function delete_privacy_data( $student_id, $student, $mode ) {
		unset( $student, $mode );

		foreach (
			array(
				self::META_ALLOW_CARD,
				self::META_ALLOW_BANK,
				self::META_ALLOW_INVOICE,
				self::LEGACY_META_ALLOW_MANUAL,
			)
			as $meta_key
		) {
			delete_user_meta( absint( $student_id ), $meta_key );
		}
	}

	/**
	 * Register editable Pro system email templates.
	 *
	 * @return void
	 */
	private static function register_templates() {
		$templates = array(
			self::TEMPLATE_BANK_STUDENT => array(
				'label' => __( 'Bank transfer instructions — Student', 'tutorhelper-pro' ),
				'description' => __( 'Sent after a student chooses bank transfer. Includes the tutor bank details and explains that the lesson is held until payment is recorded.', 'tutorhelper-pro' ),
				'heading' => __( 'Bank Transfer Required', 'tutorhelper-pro' ),
				'recipient' => 'student',
				'subject' => __( 'Bank transfer details for your lesson', 'tutorhelper-pro' ),
				'body' => __( "Hello {student_name},\n\nWe've held your selected lesson while we wait for your bank transfer.\n\nLesson: {booking_type}\nDate: {lesson_date}\nTime: {lesson_time}\nAmount: {payment_amount}\n\nAccount name: {bank_account_name}\nBank: {bank_name}\nSort code: {bank_sort_code}\nAccount number: {bank_account_number}\nIBAN: {bank_iban}\nBIC / SWIFT: {bank_bic}\n\nPayment reference: {bank_reference_instructions}\n\n{bank_additional_instructions}\n\nYour lesson will be confirmed once your tutor records the payment.", 'tutorhelper-pro' ),
			),
			self::TEMPLATE_BANK_TUTOR => array(
				'label' => __( 'Bank transfer booking — Tutor', 'tutorhelper-pro' ),
				'description' => __( 'Sent to the tutor when a student chooses bank transfer.', 'tutorhelper-pro' ),
				'heading' => __( 'Bank Transfer Awaiting Payment', 'tutorhelper-pro' ),
				'recipient' => 'tutor',
				'subject' => __( 'Bank transfer booking from {student_name}', 'tutorhelper-pro' ),
				'body' => __( "Hello {tutor_name},\n\n{student_name} has selected Bank transfer for a new lesson.\n\nLesson: {booking_type}\nDate: {lesson_date}\nTime: {lesson_time}\nAmount: {payment_amount}\n\nThe lesson is being held but is not yet confirmed. Record the payment in Finance when it arrives.", 'tutorhelper-pro' ),
			),
			self::TEMPLATE_INVOICE_STUDENT => array(
				'label' => __( 'Invoice booking — Student', 'tutorhelper-pro' ),
				'description' => __( 'Sent to a student who books using the Invoice option.', 'tutorhelper-pro' ),
				'heading' => __( 'Invoice Booking Confirmed', 'tutorhelper-pro' ),
				'recipient' => 'student',
				'subject' => __( 'Invoice payment for your confirmed lesson', 'tutorhelper-pro' ),
				'body' => __( "Hello {student_name},\n\nYour lesson is confirmed.\n\nLesson: {booking_type}\nDate: {lesson_date}\nTime: {lesson_time}\nAmount: {payment_amount}\n\nYour tutor will add this lesson to your next invoice. No payment is required through the booking form.", 'tutorhelper-pro' ),
			),
			self::TEMPLATE_INVOICE_TUTOR => array(
				'label' => __( 'Invoice booking — Tutor', 'tutorhelper-pro' ),
				'description' => __( 'Sent to the tutor when a student books using Invoice.', 'tutorhelper-pro' ),
				'heading' => __( 'New Invoiced Booking', 'tutorhelper-pro' ),
				'recipient' => 'tutor',
				'subject' => __( 'New invoiced booking from {student_name}', 'tutorhelper-pro' ),
				'body' => __( "Hello {tutor_name},\n\n{student_name} has booked a lesson using Invoice.\n\nLesson: {booking_type}\nDate: {lesson_date}\nTime: {lesson_time}\nAmount: {payment_amount}\n\nThe lesson has been confirmed. Add it to the student's next invoice.", 'tutorhelper-pro' ),
			),
		);

		foreach ( $templates as $key => $template ) {
			$template['module'] = 'bookings';
			$template['enabled'] = true;
			$template['placeholders'] = array(
				'{student_name}',
				'{student_email}',
				'{booking_type}',
				'{lesson_date}',
				'{lesson_time}',
				'{location_type}',
				'{tutor_name}',
				'{site_name}',
				'{calendar_url}',
				'{payment_amount}',
				'{bank_account_name}',
				'{bank_name}',
				'{bank_sort_code}',
				'{bank_account_number}',
				'{bank_iban}',
				'{bank_bic}',
				'{bank_reference_instructions}',
				'{bank_additional_instructions}',
			);
			TutorHelper_Email_Templates::register( $key, $template );
		}
	}

	/**
	 * Send one manual-payment system email.
	 *
	 * @param string $template_key Template key.
	 * @param int    $booking_id   Booking ID.
	 * @param string $recipient    student|tutor.
	 * @return void
	 */
	private static function send_template( $template_key, $booking_id, $recipient ) {
		if ( ! TutorHelper_Email_Templates::is_enabled( $template_key ) ) {
			return;
		}

		$context = TutorHelper_Booking_Email_Context::build( $booking_id );
		if ( is_wp_error( $context ) ) {
			return;
		}

		$booking = isset( $context['booking'] ) && is_object( $context['booking'] )
			? $context['booking']
			: null;
		if ( ! $booking ) {
			return;
		}

		$placeholders = $context['placeholders'];
		$placeholders['{payment_amount}'] = TutorHelper_Currency::format_minor_units(
			absint( $booking->price_minor_units ),
			! empty( $booking->currency )
				? strtoupper( sanitize_text_field( $booking->currency ) )
				: TutorHelper_Currency::get_currency()
		);

		$bank = TutorHelper_Pro_Bank_Details::get_details();
		$placeholders['{bank_account_name}'] = $bank['account_name'];
		$placeholders['{bank_name}'] = $bank['bank_name'];
		$placeholders['{bank_sort_code}'] = $bank['sort_code'];
		$placeholders['{bank_account_number}'] = $bank['account_number'];
		$placeholders['{bank_iban}'] = $bank['iban'];
		$placeholders['{bank_bic}'] = $bank['bic'];
		$placeholders['{bank_reference_instructions}'] = $bank['reference_instructions'];
		$placeholders['{bank_additional_instructions}'] = $bank['additional_instructions'];

		$email = 'tutor' === $recipient
			? $context['tutor_email']
			: $context['student_email'];

		$result = TutorHelper_Email_Sender::send(
			$template_key,
			$email,
			$placeholders,
			array(
				'related_object_type' => 'booking',
				'related_object_id' => absint( $booking_id ),
				'recipient_type' => $recipient,
			)
		);

		if ( is_wp_error( $result ) && class_exists( 'TutorHelper_Logger' ) ) {
			TutorHelper_Logger::warning(
				'Manual payment email could not be sent.',
				array(
					'booking_id' => absint( $booking_id ),
					'template_key' => $template_key,
					'error_code' => $result->get_error_code(),
				)
			);
		}
	}

	/**
	 * Persist the Pro manual-payment subtype against Finance metadata.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param string $type       bank_transfer|invoice.
	 * @return void
	 */
	private static function save_manual_payment_type( $booking_id, $type ) {
		global $wpdb;

		$table = TutorHelper_Pro_Database::get_table_name( 'booking_finance' );
		if ( '' === $table ) {
			return;
		}

		$now = current_time( 'mysql' );
		$sql = $wpdb->prepare(
			'INSERT INTO %i (booking_id, manual_payment_type, created_at, updated_at)
			VALUES (%d, %s, %s, %s)
			ON DUPLICATE KEY UPDATE manual_payment_type = VALUES(manual_payment_type), updated_at = VALUES(updated_at)',
			$table,
			absint( $booking_id ),
			sanitize_key( $type ),
			$now,
			$now
		);

		$wpdb->query( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance metadata must be persisted immediately for the booking workflow.
	}

	/**
	 * Add manual_payment_type and payment_date to the existing Finance table.
	 * This runs once for this compatibility migration; the next consolidated
	 * schema version can absorb these columns into the main installer.
	 *
	 * @return void
	 */
	private static function ensure_finance_columns() {
		if ( self::SCHEMA_VERSION === get_option( self::SCHEMA_OPTION, '' ) ) {
			return;
		}

		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'booking_finance' );
		if ( '' === $table ) {
			return;
		}

		$manual_column = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time schema compatibility check.
			$wpdb->prepare(
				'SHOW COLUMNS FROM %i LIKE %s',
				$table,
				'manual_payment_type'
			)
		);

		if ( ! $manual_column ) {
			$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time schema migration.
				$wpdb->prepare(
					'ALTER TABLE %i ADD manual_payment_type varchar(30) DEFAULT NULL AFTER payment_due_date',
					$table
				)
			);
		}

		$payment_date_column = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time schema compatibility check.
			$wpdb->prepare(
				'SHOW COLUMNS FROM %i LIKE %s',
				$table,
				'payment_date'
			)
		);

		if ( ! $payment_date_column ) {
			$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time schema migration.
				$wpdb->prepare(
					'ALTER TABLE %i ADD payment_date date DEFAULT NULL AFTER manual_payment_type',
					$table
				)
			);
		}

		update_option( self::SCHEMA_OPTION, self::SCHEMA_VERSION, false );
	}

	private static function get_requested_method() {
		if (
			! isset( $_REQUEST['tutorhelper_payment_method'] )
			|| is_array( $_REQUEST['tutorhelper_payment_method'] )
		) {
			return '';
		}

		return sanitize_key(
			wp_unslash( $_REQUEST['tutorhelper_payment_method'] )
		);
	}

	private static function calculate_duration_minutes( $start, $end, $timezone ) {
		try {
			$zone = new DateTimeZone( sanitize_text_field( $timezone ) );
			$start_date = new DateTimeImmutable( sanitize_text_field( $start ), $zone );
			$end_date = new DateTimeImmutable( sanitize_text_field( $end ), $zone );
		} catch ( Exception $exception ) {
			return new WP_Error(
				'tutorhelper_pro_payment_date_invalid',
				__( 'The lesson time could not be prepared for payment.', 'tutorhelper-pro' )
			);
		}

		$seconds = $end_date->getTimestamp() - $start_date->getTimestamp();
		if ( 0 >= $seconds || 0 !== $seconds % MINUTE_IN_SECONDS ) {
			return new WP_Error(
				'tutorhelper_pro_payment_duration_invalid',
				__( 'The lesson duration could not be prepared for payment.', 'tutorhelper-pro' )
			);
		}

		return (int) ( $seconds / MINUTE_IN_SECONDS );
	}

	private static function redirect( $student_id, $notice ) {
		$url = add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Students_Admin::TAB_KEY,
				'student_id' => absint( $student_id ),
				'tutorhelper_pro_payment_methods_notice' => sanitize_key( $notice ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	private static function render_notice() {
		$notice = isset( $_GET['tutorhelper_pro_payment_methods_notice'] )
			? sanitize_key( wp_unslash( $_GET['tutorhelper_pro_payment_methods_notice'] ) )
			: '';

		if ( 'saved' === $notice ) {
			?>
			<div class="notice notice-success inline"><p><?php esc_html_e( 'Student payment options saved.', 'tutorhelper-pro' ); ?></p></div>
			<?php
		} elseif ( 'invalid_student' === $notice ) {
			?>
			<div class="notice notice-error inline"><p><?php esc_html_e( 'The selected student could not be found.', 'tutorhelper-pro' ); ?></p></div>
			<?php
		}
	}
}
