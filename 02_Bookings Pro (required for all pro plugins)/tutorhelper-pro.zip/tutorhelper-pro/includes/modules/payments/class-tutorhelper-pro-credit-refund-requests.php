<?php
/**
 * Student account-credit refund requests.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shows student credit balances and lets tutors resolve refund requests.
 */
final class TutorHelper_Pro_Credit_Refund_Requests {

	const REQUEST_ACTION = 'tutorhelper_pro_request_credit_refund';
	const RESOLVE_ACTION = 'tutorhelper_pro_resolve_credit_refund';
	const STYLE_HANDLE = 'tutorhelper-pro-student-credit';

	/** Register hooks. */
	public static function init() {
		add_filter( 'do_shortcode_tag', array( __CLASS__, 'filter_dashboard' ), 60, 4 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 30 );
		add_action( 'admin_post_' . self::REQUEST_ACTION, array( __CLASS__, 'handle_request' ) );
		add_action( 'admin_post_' . self::RESOLVE_ACTION, array( __CLASS__, 'handle_resolution' ) );
		add_action( 'tutorhelper_booking_hub_render_tab', array( __CLASS__, 'render_finance_requests' ), 25, 2 );
	}

	/** Load the student account-credit interface styles. */
	public static function enqueue_assets() {
		if (
			is_admin()
			|| ! is_user_logged_in()
			|| ! class_exists( 'TutorHelper_Students' )
			|| ! TutorHelper_Students::get_student( get_current_user_id() )
			|| ! TutorHelper_Pro_Student_Finance_Visibility::student_can_view_finance( get_current_user_id() )
		) {
			return;
		}

		$style_path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-finance-credits.css';

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-finance-credits.css',
			array(),
			file_exists( $style_path )
				? (string) filemtime( $style_path )
				: TUTORHELPER_PRO_VERSION
		);
	}

	/** Append account-credit information to the student dashboard. */
	public static function filter_dashboard( $output, $tag, $attr, $match ) {
		unset( $attr, $match );

		if (
			! class_exists( 'TutorHelper_Student_Dashboard_Shortcode' )
			|| TutorHelper_Student_Dashboard_Shortcode::SHORTCODE !== $tag
			|| ! is_user_logged_in()
			|| ! TutorHelper_Students::get_student( get_current_user_id() )
			|| ! TutorHelper_Pro_Student_Finance_Visibility::student_can_view_finance( get_current_user_id() )
		) {
			return $output;
		}

		$student_id = get_current_user_id();
		$balances = self::get_balances( $student_id );
		$requests = self::get_student_requests( $student_id );
		if ( empty( $balances ) && empty( $requests ) ) {
			return $output;
		}

		ob_start();
		?>
		<section class="tutorhelper-pro-credit-balance" aria-labelledby="tutorhelper-pro-credit-heading">
			<h2 id="tutorhelper-pro-credit-heading"><?php esc_html_e( 'Account credit', 'tutorhelper-pro' ); ?></h2>
			<?php if ( empty( $balances ) ) : ?>
				<p><?php esc_html_e( 'You do not currently have account credit available.', 'tutorhelper-pro' ); ?></p>
			<?php else : ?>
				<?php foreach ( $balances as $currency => $balance ) : ?>
					<div class="tutorhelper-pro-credit-balance__currency">
						<p>
							<strong><?php echo esc_html( TutorHelper_Currency::format_minor_units( $balance, $currency ) ); ?></strong>
							<?php esc_html_e( 'available', 'tutorhelper-pro' ); ?>
						</p>
						<p><?php esc_html_e( 'Credit will be offset against your next lesson booking / invoice. If you have no further lessons to book, you can request a refund here.', 'tutorhelper-pro' ); ?></p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="<?php echo esc_attr( self::REQUEST_ACTION ); ?>" />
							<input type="hidden" name="currency" value="<?php echo esc_attr( $currency ); ?>" />
							<label>
								<span><?php esc_html_e( 'Refund amount', 'tutorhelper-pro' ); ?></span>
								<input type="number" name="amount" min="0.01" step="0.01" max="<?php echo esc_attr( number_format( $balance / 100, 2, '.', '' ) ); ?>" value="<?php echo esc_attr( number_format( $balance / 100, 2, '.', '' ) ); ?>" required />
							</label>
							<label>
								<span><?php esc_html_e( 'Message for your tutor (optional)', 'tutorhelper-pro' ); ?></span>
								<textarea name="student_note" rows="2"></textarea>
							</label>
							<?php wp_nonce_field( self::REQUEST_ACTION . '_' . $currency ); ?>
							<button type="submit"><?php esc_html_e( 'Request refund', 'tutorhelper-pro' ); ?></button>
						</form>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>

			<?php if ( ! empty( $requests ) ) : ?>
				<h3><?php esc_html_e( 'Refund requests', 'tutorhelper-pro' ); ?></h3>
				<ul>
					<?php foreach ( $requests as $request ) : ?>
						<li><?php echo esc_html( sprintf( '%1$s — %2$s', TutorHelper_Currency::format_minor_units( absint( $request->amount_minor_units ), $request->currency ), ucfirst( sanitize_key( $request->status ) ) ) ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</section>
		<?php
		return $output . ob_get_clean();
	}

	/**
	 * Create a pending request without changing the immutable ledger.
	 *
	 * A linked add-on may supply a student ID for an authorised parent or
	 * guardian. The filter remains false by default, so the normal student
	 * dashboard behaviour is unchanged.
	 *
	 * @return void
	 */
	public static function handle_request() {
		$requester_id = get_current_user_id();
		$student_id = isset( $_POST['student_id'] ) && ! is_array( $_POST['student_id'] )
			? absint( wp_unslash( $_POST['student_id'] ) )
			: $requester_id;
		$currency = isset( $_POST['currency'] ) && ! is_array( $_POST['currency'] )
			? strtoupper( sanitize_text_field( wp_unslash( $_POST['currency'] ) ) )
			: '';
		check_admin_referer( self::REQUEST_ACTION . '_' . $currency );

		$amount = isset( $_POST['amount'] ) && ! is_array( $_POST['amount'] )
			? self::major_to_minor( wp_unslash( $_POST['amount'] ) )
			: 0;
		$note = isset( $_POST['student_note'] ) && ! is_array( $_POST['student_note'] )
			? sanitize_textarea_field( wp_unslash( $_POST['student_note'] ) )
			: '';

		$result = self::submit_request( $student_id, $requester_id, $currency, $amount, $note );
		self::redirect_back( is_wp_error( $result ) ? 'credit_refund=invalid' : 'credit_refund=requested' );
	}

	/**
	 * Create a pending request for a student's available account credit.
	 *
	 * Extensions must opt in through the authorisation filter before they can
	 * request on behalf of another user.
	 *
	 * @param int    $student_id   Student whose credit is being requested.
	 * @param int    $requester_id Logged-in user making the request.
	 * @param string $currency     Currency code.
	 * @param int    $amount       Amount in minor units.
	 * @param string $note         Optional message for the tutor.
	 * @return true|WP_Error
	 */
	public static function submit_request( $student_id, $requester_id, $currency, $amount, $note = '' ) {
		$student_id = absint( $student_id );
		$requester_id = absint( $requester_id );
		$currency = strtoupper( sanitize_text_field( $currency ) );
		$amount = absint( $amount );
		$note = sanitize_textarea_field( $note );

		$registered_student = class_exists( 'TutorHelper_Students' )
			&& TutorHelper_Students::get_student( $student_id );
		$student_request = $requester_id === $student_id && $registered_student;
		$authorised = apply_filters(
			'tutorhelper_pro_credit_refund_request_authorised',
			(bool) $student_request,
			$requester_id,
			$student_id
		);
		if ( ! $student_id || ! $requester_id || ! $registered_student || ! $authorised ) {
			return new WP_Error(
				'tutorhelper_pro_credit_refund_not_authorised',
				__( 'You do not have permission to request this credit refund.', 'tutorhelper-pro' )
			);
		}

		$available = self::get_requestable_balance( $student_id, $currency );
		if ( ! $amount || $amount > $available ) {
			return new WP_Error(
				'tutorhelper_pro_credit_refund_invalid_amount',
				__( 'The requested refund exceeds the available account credit.', 'tutorhelper-pro' )
			);
		}

		global $wpdb;
		$result = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Pro owns this request table.
			TutorHelper_Pro_Database::get_table_name( 'credit_refund_requests' ),
			array(
				'student_user_id' => $student_id,
				'amount_minor_units' => $amount,
				'currency' => $currency,
				'status' => 'pending',
				'student_note' => $note,
				'requested_at' => current_time( 'mysql', true ),
				'updated_at' => current_time( 'mysql', true ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%s' )
		);

		return false === $result
			? new WP_Error( 'tutorhelper_pro_credit_refund_insert_failed', __( 'The refund request could not be saved. Please try again.', 'tutorhelper-pro' ) )
			: true;
	}

	/** Render pending requests above the normal Finance adjustment history. */
	public static function render_finance_requests( $selected_tab, $active_tab ) {
		unset( $active_tab );
		if (
			! class_exists( 'TutorHelper_Pro_Finance_Admin' )
			|| TutorHelper_Pro_Finance_Admin::TAB_KEY !== $selected_tab
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Finance requests must be current.
			'SELECT * FROM ' . TutorHelper_Pro_Database::get_table_name( 'credit_refund_requests' ) . ' ORDER BY requested_at DESC LIMIT 100' // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Trusted internal table name.
		);
		?>
		<section class="tutorhelper-main-section tutorhelper-pro-credit-refund-requests">
			<div class="tutorhelper-main-section__header">
				<h3><?php esc_html_e( 'Account-credit refund requests', 'tutorhelper-pro' ); ?></h3>
				<p><?php esc_html_e( 'A request is not a refund. Confirm only after returning the money outside TutorHelper; rejecting it leaves the student credit untouched.', 'tutorhelper-pro' ); ?></p>
			</div>
			<div class="tutorhelper-main-section__body">
				<?php if ( empty( $rows ) ) : ?>
					<p><?php esc_html_e( 'No account-credit refund requests have been submitted.', 'tutorhelper-pro' ); ?></p>
				<?php else : ?>
					<table class="widefat striped">
						<thead><tr><th><?php esc_html_e( 'Requested', 'tutorhelper-pro' ); ?></th><th><?php esc_html_e( 'Student', 'tutorhelper-pro' ); ?></th><th><?php esc_html_e( 'Amount', 'tutorhelper-pro' ); ?></th><th><?php esc_html_e( 'Status', 'tutorhelper-pro' ); ?></th><th><?php esc_html_e( 'Message', 'tutorhelper-pro' ); ?></th><th><?php esc_html_e( 'Action', 'tutorhelper-pro' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( $rows as $request ) : $student = get_user_by( 'id', absint( $request->student_user_id ) ); ?>
							<tr>
								<td><?php echo esc_html( get_date_from_gmt( $request->requested_at, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ); ?></td>
								<td><?php echo esc_html( $student ? $student->display_name : '#' . absint( $request->student_user_id ) ); ?></td>
								<td><?php echo esc_html( TutorHelper_Currency::format_minor_units( absint( $request->amount_minor_units ), $request->currency ) ); ?></td>
								<td><?php echo esc_html( ucfirst( sanitize_key( $request->status ) ) ); ?></td>
								<td><?php echo esc_html( $request->student_note ); ?></td>
								<td>
								<?php if ( 'pending' === $request->status ) : ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
										<input type="hidden" name="action" value="<?php echo esc_attr( self::RESOLVE_ACTION ); ?>" />
										<input type="hidden" name="request_id" value="<?php echo esc_attr( $request->id ); ?>" />
										<input type="hidden" name="resolution" value="completed" />
										<?php wp_nonce_field( self::RESOLVE_ACTION . '_' . absint( $request->id ) ); ?>
										<button type="submit" class="button button-primary"><?php esc_html_e( 'Record external refund paid', 'tutorhelper-pro' ); ?></button>
									</form>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
										<input type="hidden" name="action" value="<?php echo esc_attr( self::RESOLVE_ACTION ); ?>" />
										<input type="hidden" name="request_id" value="<?php echo esc_attr( $request->id ); ?>" />
										<input type="hidden" name="resolution" value="rejected" />
										<?php wp_nonce_field( self::RESOLVE_ACTION . '_' . absint( $request->id ) ); ?>
										<button type="submit" class="button"><?php esc_html_e( 'Decline (keep credit)', 'tutorhelper-pro' ); ?></button>
									</form>
								<?php else : ?>
									—
								<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	/** Resolve a request, atomically converting credit to an external refund. */
	public static function handle_resolution() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to resolve refund requests.', 'tutorhelper-pro' ) );
		}

		$request_id = isset( $_POST['request_id'] ) && ! is_array( $_POST['request_id'] ) ? absint( wp_unslash( $_POST['request_id'] ) ) : 0;
		check_admin_referer( self::RESOLVE_ACTION . '_' . $request_id );
		$resolution = isset( $_POST['resolution'] ) && ! is_array( $_POST['resolution'] ) ? sanitize_key( wp_unslash( $_POST['resolution'] ) ) : '';

		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'credit_refund_requests' );
		$request = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d AND status = %s', $table, $request_id, 'pending' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( ! $request ) {
			self::redirect_finance();
		}

		if ( 'rejected' === $resolution ) {
			$wpdb->update( $table, array( 'status' => 'rejected', 'resolved_at' => current_time( 'mysql', true ), 'resolved_by_user_id' => get_current_user_id(), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $request_id, 'status' => 'pending' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			self::redirect_finance();
		}

		if ( 'completed' !== $resolution ) {
			self::redirect_finance();
		}

		$result = self::record_external_refund( $request );
		if ( is_wp_error( $result ) ) {
			TutorHelper_Logger::error( 'Account-credit refund request could not be completed.', array( 'request_id' => $request_id, 'error' => $result->get_error_message() ) );
			self::redirect_finance( $result->get_error_message() );
		}
		self::redirect_finance();
	}

	/** Convert available credit into matched credit-used and external-refund ledger entries. */
	private static function record_external_refund( $request ) {
		global $wpdb;

		$amount = absint( $request->amount_minor_units );
		$balance = TutorHelper_Pro_Student_Credits::get_balance( absint( $request->student_user_id ), $request->currency );
		if ( ! $amount || $amount > $balance ) {
			return new WP_Error( 'tutorhelper_pro_credit_refund_balance_changed', __( 'The student no longer has enough available credit for this request.', 'tutorhelper-pro' ) );
		}

		$ledger_table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$sources = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT booking_id, tutor_user_id, SUM(amount_minor_units) AS issued FROM %i WHERE student_user_id = %d AND currency = %s AND transaction_type = %s AND booking_id IS NOT NULL GROUP BY booking_id, tutor_user_id ORDER BY MIN(id) ASC',
				$ledger_table,
				absint( $request->student_user_id ),
				sanitize_text_field( $request->currency ),
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_ISSUED
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$used = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COALESCE(SUM(amount_minor_units),0) FROM %i WHERE student_user_id = %d AND currency = %s AND transaction_type = %s',
				$ledger_table,
				absint( $request->student_user_id ),
				sanitize_text_field( $request->currency ),
				TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

		$allocations = array();
		$remaining = $amount;
		foreach ( $sources as $source ) {
			$source_available = max( 0, absint( $source->issued ) - min( absint( $source->issued ), $used ) );
			$used = max( 0, $used - absint( $source->issued ) );
			if ( ! $source_available ) {
				continue;
			}
			$allocation = min( $remaining, $source_available );
			$allocations[] = array( 'booking_id' => absint( $source->booking_id ), 'tutor_user_id' => absint( $source->tutor_user_id ), 'amount' => $allocation );
			$remaining -= $allocation;
			if ( 0 === $remaining ) {
				break;
			}
		}
		if ( $remaining > 0 ) {
			return new WP_Error( 'tutorhelper_pro_credit_refund_sources_missing', __( 'The source credit transactions could not cover this request.', 'tutorhelper-pro' ) );
		}

		$request_table = TutorHelper_Pro_Database::get_table_name( 'credit_refund_requests' );
		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared
		foreach ( $allocations as $allocation ) {
			foreach ( array( TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED, TutorHelper_Pro_Payment_Ledger::TYPE_REFUND ) as $type ) {
				$description = TutorHelper_Pro_Payment_Ledger::TYPE_CREDIT_USED === $type
					? sprintf( __( 'Account credit consumed for refund request #%d', 'tutorhelper-pro' ), absint( $request->id ) )
					: sprintf( __( 'External refund paid for account-credit request #%d', 'tutorhelper-pro' ), absint( $request->id ) );
				$ledger_id = TutorHelper_Pro_Payment_Ledger::record(
					array(
						'booking_id' => $allocation['booking_id'],
						'student_user_id' => absint( $request->student_user_id ),
						'tutor_user_id' => $allocation['tutor_user_id'],
						'transaction_type' => $type,
						'amount_minor_units' => $allocation['amount'],
						'currency' => strtoupper( sanitize_text_field( $request->currency ) ),
						'payment_method' => 'manual',
						'payment_provider' => '',
						'provider_reference' => '',
						'description' => $description,
						'created_by_user_id' => get_current_user_id(),
					)
				);
				if ( is_wp_error( $ledger_id ) ) {
					$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared
					return $ledger_id;
				}
				do_action( 'tutorhelper_pro_finance_adjustment_recorded', $allocation['booking_id'], absint( $ledger_id ), $type );
			}
		}

		$updated = $wpdb->update(
			$request_table,
			array( 'status' => 'completed', 'resolved_at' => current_time( 'mysql', true ), 'resolved_by_user_id' => get_current_user_id(), 'updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => absint( $request->id ), 'status' => 'pending' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		if ( 1 !== $updated ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared
			return new WP_Error( 'tutorhelper_pro_credit_refund_race', __( 'This refund request was already changed. No duplicate refund was recorded.', 'tutorhelper-pro' ) );
		}
		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared
		return true;
	}

	/** Return positive balances by supported currency. */
	private static function get_balances( $student_id ) {
		global $wpdb;
		$table = TutorHelper_Pro_Database::get_table_name( 'finance_transactions' );
		$currencies = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT currency FROM %i WHERE student_user_id = %d', $table, absint( $student_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$balances = array();
		foreach ( $currencies as $currency ) {
			$balance = TutorHelper_Pro_Student_Credits::get_balance( $student_id, $currency );
			if ( $balance > 0 ) {
				$balances[ strtoupper( sanitize_text_field( $currency ) ) ] = $balance;
			}
		}
		return $balances;
	}

	/** Return requests belonging to one student. */
	public static function get_student_requests( $student_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE student_user_id = %d ORDER BY requested_at DESC LIMIT 20', TutorHelper_Pro_Database::get_table_name( 'credit_refund_requests' ), absint( $student_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Return account credit which remains eligible for a new refund request.
	 *
	 * @param int    $student_id Student user ID.
	 * @param string $currency   Currency code.
	 * @return int
	 */
	public static function get_requestable_balance( $student_id, $currency ) {
		return max(
			0,
			TutorHelper_Pro_Student_Credits::get_balance( absint( $student_id ), $currency )
			- self::get_pending_total( $student_id, $currency )
		);
	}

	/** Return credit already reserved by pending refund requests. */
	private static function get_pending_total( $student_id, $currency ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(amount_minor_units),0) FROM %i WHERE student_user_id = %d AND currency = %s AND status = %s', TutorHelper_Pro_Database::get_table_name( 'credit_refund_requests' ), absint( $student_id ), sanitize_text_field( $currency ), 'pending' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** Convert a decimal amount to minor units. */
	private static function major_to_minor( $value ) {
		return is_numeric( $value ) ? max( 0, (int) round( (float) $value * 100 ) ) : 0;
	}

	/** Redirect to the referring dashboard. */
	private static function redirect_back( $query ) {
		$url = wp_get_referer() ? wp_get_referer() : home_url( '/' );
		wp_safe_redirect( $query ? add_query_arg( explode( '=', $query )[0], explode( '=', $query )[1], $url ) : $url );
		exit;
	}

	/** Redirect to Finance. */
	private static function redirect_finance( $error = '' ) {
		$args = array( 'page' => TutorHelper_Admin::MENU_SLUG, 'tab' => TutorHelper_Pro_Finance_Admin::TAB_KEY, 'finance_view' => TutorHelper_Pro_Finance_Admin::VIEW_ALL );
		if ( $error ) {
			$args['finance_adjustment_notice'] = 'error';
			$args['finance_adjustment_message'] = sanitize_text_field( $error );
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}
}
