<?php
/**
 * Immutable finance ledger for TutorHelper Pro.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records financial transactions associated with TutorHelper bookings.
 */
final class TutorHelper_Pro_Payment_Ledger {

	const TYPE_BOOKING_CHARGE = 'booking_charge';
	const TYPE_PAYMENT        = 'payment';
	const TYPE_DEPOSIT        = 'deposit';
	const TYPE_REFUND         = 'refund';
	const TYPE_CREDIT_ISSUED  = 'credit_issued';
	const TYPE_CREDIT_USED    = 'credit_used';
	const TYPE_CREDIT_REVERSED = 'credit_reversed';
	const TYPE_ADJUSTMENT     = 'adjustment';
	const MANUAL_PAYMENT_CASH          = 'cash';
	const MANUAL_PAYMENT_BANK_TRANSFER = 'bank_transfer';
	const MANUAL_PAYMENT_EXTERNAL_CARD = 'external_card';
	const MANUAL_PAYMENT_OTHER         = 'other';

	/**
	 * Return supported tutor-recorded manual payment types.
	 *
	 * @return array
	 */
	public static function get_manual_payment_types() {
		return array(
			self::MANUAL_PAYMENT_CASH,
			self::MANUAL_PAYMENT_BANK_TRANSFER,
			self::MANUAL_PAYMENT_EXTERNAL_CARD,
			self::MANUAL_PAYMENT_OTHER,
		);
	}

	/**
	 * Return a readable manual payment type label.
	 *
	 * @param string $type Manual payment type.
	 * @return string
	 */
	public static function get_manual_payment_type_label( $type ) {
		$labels = array(
			self::MANUAL_PAYMENT_CASH          => __( 'Cash', 'tutorhelper-pro' ),
			self::MANUAL_PAYMENT_BANK_TRANSFER => __( 'Bank transfer', 'tutorhelper-pro' ),
			self::MANUAL_PAYMENT_EXTERNAL_CARD => __( 'Card (not TutorHelper)', 'tutorhelper-pro' ),
			self::MANUAL_PAYMENT_OTHER         => __( 'Other', 'tutorhelper-pro' ),
		);
		$type = sanitize_key( $type );
		return isset( $labels[ $type ] ) ? $labels[ $type ] : '';
	}

	/**
	 * Return supported ledger transaction types.
	 *
	 * @return array
	 */
	public static function get_transaction_types() {
		return array(
			self::TYPE_BOOKING_CHARGE,
			self::TYPE_PAYMENT,
			self::TYPE_DEPOSIT,
			self::TYPE_REFUND,
			self::TYPE_CREDIT_ISSUED,
			self::TYPE_CREDIT_USED,
			self::TYPE_CREDIT_REVERSED,
			self::TYPE_ADJUSTMENT,
		);
	}

	/**
	 * Record an immutable finance transaction.
	 *
	 * @param array $transaction Transaction data.
	 *
	 * @return int|WP_Error
	 */
	public static function record(
		$transaction
	) {
		global $wpdb;

		if ( ! is_array( $transaction ) ) {
			return new WP_Error(
				'tutorhelper_pro_payment_invalid_transaction',
				__(
					'The payment transaction data was invalid.',
					'tutorhelper-pro'
				)
			);
		}

		$transaction_type = isset(
			$transaction['transaction_type']
		)
			? sanitize_key(
				$transaction['transaction_type']
			)
			: '';

		if (
			! in_array(
				$transaction_type,
				self::get_transaction_types(),
				true
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_payment_invalid_transaction_type',
				__(
					'The payment transaction type was invalid.',
					'tutorhelper-pro'
				)
			);
		}

		$student_user_id = isset(
			$transaction['student_user_id']
		)
			? absint(
				$transaction['student_user_id']
			)
			: 0;

		$tutor_user_id = isset(
			$transaction['tutor_user_id']
		)
			? absint(
				$transaction['tutor_user_id']
			)
			: 0;

		if ( ! $student_user_id ) {
			return new WP_Error(
				'tutorhelper_pro_payment_missing_student',
				__(
					'A student is required for the payment transaction.',
					'tutorhelper-pro'
				)
			);
		}

		if ( ! $tutor_user_id ) {
			return new WP_Error(
				'tutorhelper_pro_payment_missing_tutor',
				__(
					'A tutor is required for the payment transaction.',
					'tutorhelper-pro'
				)
			);
		}

		$currency = isset(
			$transaction['currency']
		)
			? strtoupper(
				sanitize_text_field(
					$transaction['currency']
				)
			)
			: '';

		if ( ! self::is_valid_currency( $currency ) ) {
			return new WP_Error(
				'tutorhelper_pro_payment_invalid_currency',
				__(
					'The payment currency was invalid.',
					'tutorhelper-pro'
				)
			);
		}

		$payment_provider = isset(
			$transaction['payment_provider']
		)
			? sanitize_key(
				$transaction['payment_provider']
			)
			: '';

		$manual_payment_type = isset( $transaction['manual_payment_type'] )
			? sanitize_key( $transaction['manual_payment_type'] )
			: '';
		if (
			'' !== $manual_payment_type
			&& ! in_array( $manual_payment_type, self::get_manual_payment_types(), true )
		) {
			return new WP_Error(
				'tutorhelper_pro_payment_invalid_manual_payment_type',
				__( 'The manual payment type was invalid.', 'tutorhelper-pro' )
			);
		}

		if (
			'' !== $payment_provider
			&& ! TutorHelper_Pro_Payment_Settings::is_known_provider(
				$payment_provider
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_payment_unknown_provider',
				__(
					'The payment provider was not recognised.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			'' !== $payment_provider
			&& ! empty( $transaction['provider_event_id'] )
		) {
			$existing = self::get_by_provider_event(
				$payment_provider,
				$transaction['provider_event_id']
			);

			if ( $existing ) {
				return absint( $existing->id );
			}
		}

		$data = array(
			'booking_id' => isset( $transaction['booking_id'] )
				? absint( $transaction['booking_id'] )
				: null,
			'student_user_id' => $student_user_id,
			'tutor_user_id' => $tutor_user_id,
			'transaction_type' => $transaction_type,
			'amount_minor_units' => isset( $transaction['amount_minor_units'] )
				? intval( $transaction['amount_minor_units'] )
				: 0,
			'currency' => $currency,
			'payment_method' => isset( $transaction['payment_method'] )
				? sanitize_key( $transaction['payment_method'] )
				: '',
			'manual_payment_type' => $manual_payment_type,
			'payment_provider' => $payment_provider,
			'provider_reference' => isset( $transaction['provider_reference'] )
				? sanitize_text_field( $transaction['provider_reference'] )
				: '',
			'provider_event_id' => ! empty( $transaction['provider_event_id'] )
				? sanitize_text_field( $transaction['provider_event_id'] )
				: null,
			'description' => isset( $transaction['description'] )
				? sanitize_textarea_field( $transaction['description'] )
				: null,
			'transaction_date' => ! empty( $transaction['transaction_date'] )
				? sanitize_text_field( $transaction['transaction_date'] )
				: current_time( 'mysql', true ),
			'created_by_user_id' => ! empty( $transaction['created_by_user_id'] )
				? absint( $transaction['created_by_user_id'] )
				: null,
			'created_at' => current_time( 'mysql', true ),
		);

		$table_name = TutorHelper_Pro_Database::get_table_name(
			'finance_transactions'
		);

		$result = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- TutorHelper Pro stores finance transactions in its own immutable custom table.
			$table_name,
			$data
		);

		if ( false === $result ) {
			if (
				'' !== $payment_provider
				&& ! empty( $transaction['provider_event_id'] )
			) {
				$existing = self::get_by_provider_event(
					$payment_provider,
					$transaction['provider_event_id']
				);

				if ( $existing ) {
					return absint( $existing->id );
				}
			}

			return new WP_Error(
				'tutorhelper_pro_payment_transaction_insert_failed',
				$wpdb->last_error
					? $wpdb->last_error
					: __( 'The payment transaction could not be recorded.', 'tutorhelper-pro' )
			);
		}

		return absint( $wpdb->insert_id );
	}

	/**
	 * Retrieve one transaction by provider event ID.
	 *
	 * @param string $provider Provider key.
	 * @param string $event_id Provider event ID.
	 *
	 * @return object|null
	 */
	public static function get_by_provider_event(
		$provider,
		$event_id
	) {
		global $wpdb;

		$provider = sanitize_key( $provider );
		$event_id = sanitize_text_field( $event_id );

		if ( '' === $provider || '' === $event_id ) {
			return null;
		}

		$table_name = TutorHelper_Pro_Database::get_table_name(
			'finance_transactions'
		);

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Provider-event idempotency requires current transaction state.
			$wpdb->prepare(
				'SELECT *
				FROM %i
				WHERE payment_provider = %s
				AND provider_event_id = %s
				LIMIT 1',
				$table_name,
				$provider,
				$event_id
			)
		);
	}


	/**
	 * Retrieve a provider payment by its stable reference and booking.
	 *
	 * Stripe can send distinct event IDs for the same Checkout payment. This
	 * lookup prevents a later event from recording a second ledger amount.
	 *
	 * @param string $provider         Provider key.
	 * @param string $provider_reference Provider transaction reference.
	 * @param int    $booking_id       Booking ID.
	 * @param string $transaction_type Ledger transaction type.
	 * @return object|null
	 */
	public static function get_by_provider_reference(
		$provider,
		$provider_reference,
		$booking_id,
		$transaction_type
	) {
		global $wpdb;

		$provider = sanitize_key( $provider );
		$provider_reference = sanitize_text_field( $provider_reference );
		$booking_id = absint( $booking_id );
		$transaction_type = sanitize_key( $transaction_type );

		if (
			'' === $provider
			|| '' === $provider_reference
			|| ! $booking_id
			|| ! in_array( $transaction_type, self::get_transaction_types(), true )
		) {
			return null;
		}

		$table_name = TutorHelper_Pro_Database::get_table_name(
			'finance_transactions'
		);

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Provider-reference idempotency must use current finance data.
			$wpdb->prepare(
				'SELECT *
				FROM %i
				WHERE payment_provider = %s
				AND provider_reference = %s
				AND booking_id = %d
				AND transaction_type = %s
				LIMIT 1',
				$table_name,
				$provider,
				$provider_reference,
				$booking_id,
				$transaction_type
			)
		);
	}

	/**
	 * Return an existing TutorHelper-managed Stripe Checkout payment.
	 *
	 * Manual payments remain valid where no such verified transaction exists.
	 *
	 * @param int $booking_id Booking ID.
	 * @return object|null
	 */
	public static function get_verified_stripe_checkout_payment( $booking_id ) {
		global $wpdb;

		$booking_id = absint( $booking_id );

		if ( ! $booking_id ) {
			return null;
		}

		$table_name = TutorHelper_Pro_Database::get_table_name(
			'finance_transactions'
		);

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Manual-payment protection must inspect current immutable finance records.
			$wpdb->prepare(
				'SELECT *
				FROM %i
				WHERE booking_id = %d
				AND transaction_type = %s
				AND payment_method = %s
				AND payment_provider = %s
				LIMIT 1',
				$table_name,
				$booking_id,
				self::TYPE_PAYMENT,
				TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE,
				TutorHelper_Pro_Payment_Settings::PROVIDER_STRIPE
			)
		);
	}

	/**
	 * Validate a currency against TutorHelper Core.
	 *
	 * @param string $currency ISO currency code.
	 *
	 * @return bool
	 */
	private static function is_valid_currency(
		$currency
	) {
		if ( class_exists( 'TutorHelper_Currency' ) ) {
			$currencies = TutorHelper_Currency::get_supported_currencies();
			return isset( $currencies[ $currency ] );
		}

		return 1 === preg_match( '/^[A-Z]{3}$/', $currency );
	}
}
