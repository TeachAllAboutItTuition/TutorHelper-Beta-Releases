<?php
/**
 * Stripe payment provider for TutorHelper Pro.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates Stripe Checkout Sessions for TutorHelper bookings.
 */
final class TutorHelper_Pro_Stripe {

	/**
	 * Stripe API base URL.
	 *
	 * @var string
	 */
	const API_BASE =
		'https://api.stripe.com/v1';

	/**
	 * Checkout Session endpoint.
	 *
	 * @var string
	 */
	const CHECKOUT_SESSION_ENDPOINT =
		'/checkout/sessions';

	/**
	 * Stripe API version used by TutorHelper Pro.
	 *
	 * @var string
	 */
	const API_VERSION =
		'2025-08-27.basil';

	/**
	 * Create a hosted Stripe Checkout Session.
	 *
	 * The booking record is loaded from Core so the browser cannot
	 * control the amount, currency, student or booking metadata.
	 *
	 * @param int   $booking_id Booking ID.
	 * @param array $args       Optional return URL configuration.
	 *
	 * @return array|WP_Error
	 */
	public static function create_checkout_session(
		$booking_id,
		$args = array()
	) {

		$booking_id =
			absint(
				$booking_id
			);

		if ( ! $booking_id ) {
			return new WP_Error(
				'tutorhelper_pro_stripe_invalid_booking',
				__(
					'The booking could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! class_exists(
				'TutorHelper_Booking_Records'
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_stripe_core_unavailable',
				__(
					'TutorHelper booking services are unavailable.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! TutorHelper_Pro_Payment_Settings::
				stripe_is_configured()
		) {
			return new WP_Error(
				'tutorhelper_pro_stripe_not_configured',
				__(
					'Stripe is not fully configured.',
					'tutorhelper-pro'
				)
			);
		}

		$booking =
			TutorHelper_Booking_Records::
				get_by_id(
					$booking_id
				);

		if ( ! $booking ) {
			return new WP_Error(
				'tutorhelper_pro_stripe_booking_not_found',
				__(
					'The booking could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$validation =
			self::validate_booking(
				$booking
			);

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

        /* prevent multiple live checkout sessions */

        $existing_session =
            self::get_reusable_checkout_session(
                $booking
            );

        if ( is_wp_error( $existing_session ) ) {
            return $existing_session;
        }

        if ( is_array( $existing_session ) ) {
            return $existing_session;
        }


		$booking_type =
			TutorHelper_Booking_Types::
				get_by_id(
					absint(
						$booking
							->booking_type_id
					)
				);

		if ( ! $booking_type ) {
			return new WP_Error(
				'tutorhelper_pro_stripe_booking_type_missing',
				__(
					'The booking type could not be found.',
					'tutorhelper-pro'
				)
			);
		}

		$args = wp_parse_args(
			$args,
			array(
				'success_url' =>
					self::get_default_success_url(
						$booking_id
					),

				'cancel_url' =>
					self::get_default_cancel_url(
						$booking_id
					),
			)
		);

		$body =
			self::build_checkout_body(
				$booking,
				$booking_type,
				$args
			);

		if ( is_wp_error( $body ) ) {
			return $body;
		}

		$response =
			self::request(
				'POST',
				self::CHECKOUT_SESSION_ENDPOINT,
				$body
			);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if (
			empty( $response['id'] )
			|| empty( $response['url'] )
		) {
			return new WP_Error(
				'tutorhelper_pro_stripe_invalid_session',
				__(
					'Stripe returned an incomplete Checkout Session.',
					'tutorhelper-pro'
				)
			);
		}

        $session_id =
            sanitize_text_field(
                $response['id']
            );

        $payment_update =
            TutorHelper_Booking_Records::
                update_payment_details(
                    $booking_id,
                    array(
                        'payment_status' =>
                            sanitize_key(
                                $booking
                                    ->payment_status
                            ),

                        'payment_method' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_METHOD_STRIPE,

                        'payment_provider' =>
                            TutorHelper_Pro_Payment_Settings::
                                PROVIDER_STRIPE,

                        'payment_reference' =>
                            $session_id,

                        'booking_status' =>
                            sanitize_key(
                                $booking
                                    ->status
                            ),
                    ),
                    sanitize_key(
                        $booking
                            ->payment_status
                    )
                );

        if ( is_wp_error( $payment_update ) ) {

            TutorHelper_Logger::error(
                'Stripe Checkout Session could not be attached to booking.',
                array(
                    'booking_id' =>
                        $booking_id,

                    'error' =>
                        $payment_update
                            ->get_error_message(),
                )
            );

            return $payment_update;
        }

		return array(
			'id' =>
	            $session_id,

			'url' =>
				esc_url_raw(
					$response['url']
				),

			'mode' =>
				TutorHelper_Pro_Payment_Settings::
					get_stripe_mode(),
		);
	}



	/**
	 * Create a hosted Checkout Session for an authenticated Pro extension.
	 *
	 * The caller remains responsible for storing its context and handling the
	 * signed webhook event. Credentials and Stripe transport stay inside Pro.
	 *
	 * @param array $args Validated Checkout context.
	 * @return array|WP_Error
	 */
	public static function create_extension_checkout_session( $args ) {
		if ( ! TutorHelper_Pro_Payment_Settings::stripe_is_configured() ) {
			return new WP_Error(
				'tutorhelper_pro_stripe_not_configured',
				__( 'Stripe is not fully configured.', 'tutorhelper-pro' )
			);
		}

		$args = wp_parse_args(
			is_array( $args ) ? $args : array(),
			array(
				'amount_minor_units' => 0,
				'currency' => '',
				'product_name' => '',
				'description' => '',
				'customer_email' => '',
				'client_reference_id' => '',
				'success_url' => '',
				'cancel_url' => '',
				'metadata' => array(),
			)
		);

		$amount = absint( $args['amount_minor_units'] );
		$currency = strtolower( sanitize_text_field( $args['currency'] ) );
		$product_name = sanitize_text_field( $args['product_name'] );
		$success_url = esc_url_raw( $args['success_url'] );
		$cancel_url = esc_url_raw( $args['cancel_url'] );

		if ( 0 === $amount || ! preg_match( '/^[a-z]{3}$/', $currency ) ) {
			return new WP_Error(
				'tutorhelper_pro_stripe_extension_amount_invalid',
				__( 'The Checkout amount or currency is invalid.', 'tutorhelper-pro' )
			);
		}

		if ( '' === $product_name || '' === $success_url || '' === $cancel_url ) {
			return new WP_Error(
				'tutorhelper_pro_stripe_extension_context_invalid',
				__( 'The Checkout description or return URLs are missing.', 'tutorhelper-pro' )
			);
		}

		$body = array(
			'mode' => 'payment',
			'expires_at' => time() + ( 30 * MINUTE_IN_SECONDS ),
			'payment_method_types[0]' => 'card',
			'success_url' => $success_url,
			'cancel_url' => $cancel_url,
			'client_reference_id' => sanitize_text_field( $args['client_reference_id'] ),
			'line_items[0][quantity]' => 1,
			'line_items[0][price_data][currency]' => $currency,
			'line_items[0][price_data][unit_amount]' => $amount,
			'line_items[0][price_data][product_data][name]' => $product_name,
		);

		$description = sanitize_text_field( $args['description'] );
		if ( '' !== $description ) {
			$body['line_items[0][price_data][product_data][description]'] = $description;
		}

		$email = sanitize_email( $args['customer_email'] );
		if ( '' !== $email ) {
			$body['customer_email'] = $email;
		}

		$metadata = is_array( $args['metadata'] ) ? $args['metadata'] : array();
		foreach ( $metadata as $key => $value ) {
			$key = sanitize_key( $key );
			if ( '' === $key || is_array( $value ) || is_object( $value ) ) {
				continue;
			}
			$body[ 'metadata[' . $key . ']' ] = sanitize_text_field( (string) $value );
		}

		$response = self::request(
			'POST',
			self::CHECKOUT_SESSION_ENDPOINT,
			$body
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( empty( $response['id'] ) || empty( $response['url'] ) ) {
			return new WP_Error(
				'tutorhelper_pro_stripe_invalid_session',
				__( 'Stripe returned an incomplete Checkout Session.', 'tutorhelper-pro' )
			);
		}

		return array(
			'id' => sanitize_text_field( $response['id'] ),
			'url' => esc_url_raw( $response['url'] ),
			'mode' => TutorHelper_Pro_Payment_Settings::get_stripe_mode(),
		);
	}


    /**
     * Reuse an existing open Checkout Session.
     *
     * @param object $booking Booking record.
     *
     * @return array|null|WP_Error
     */
    private static function get_reusable_checkout_session(
        $booking
    ) {

        $session_id =
            ! empty(
                $booking->payment_reference
            )
                ? sanitize_text_field(
                    $booking
                        ->payment_reference
                )
                : '';

        if (
            '' === $session_id
            || 0 !== strpos(
                $session_id,
                'cs_'
            )
        ) {
            return null;
        }

        $session =
            self::request(
                'GET',
                self::CHECKOUT_SESSION_ENDPOINT
                . '/'
                . rawurlencode(
                    $session_id
                )
            );

        if ( is_wp_error( $session ) ) {
            /*
            * Do not create a second Session when we cannot establish
            * the state of the existing one.
            */
            return $session;
        }

        $status =
            ! empty(
                $session['status']
            )
                ? sanitize_key(
                    $session['status']
                )
                : '';

        if (
            'open' === $status
            && ! empty(
                $session['url']
            )
        ) {
            return array(
                'id' =>
                    $session_id,

                'url' =>
                    esc_url_raw(
                        $session['url']
                    ),

                'mode' =>
                    TutorHelper_Pro_Payment_Settings::
                        get_stripe_mode(),
            );
        }

        if ( 'expired' === $status ) {
            return null;
        }

        if ( 'complete' === $status ) {
            return new WP_Error(
                'tutorhelper_pro_stripe_session_complete',
                __(
                    'This payment session has already completed.',
                    'tutorhelper-pro'
                )
            );
        }

        return new WP_Error(
            'tutorhelper_pro_stripe_session_state_unknown',
            __(
                'The existing payment session could not be reused.',
                'tutorhelper-pro'
            )
        );
    }

    
    /**
     * Expire an open Stripe Checkout Session.
     *
     * @param string $session_id Checkout Session ID.
     *
     * @return array|WP_Error
     */
    public static function expire_checkout_session(
        $session_id
    ) {

        $session_id =
            sanitize_text_field(
                $session_id
            );

        if (
            '' === $session_id
            || 0 !== strpos(
                $session_id,
                'cs_'
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_stripe_session_invalid',
                __(
                    'The payment session is invalid.',
                    'tutorhelper-pro'
                )
            );
        }

        return self::request(
            'POST',
            self::CHECKOUT_SESSION_ENDPOINT
            . '/'
            . rawurlencode(
                $session_id
            )
            . '/expire'
        );
    }



    /**
     * Validate a booking for Stripe Checkout.
     *
     * @param object $booking Core booking record.
     *
     * @return true|WP_Error
     */
    private static function validate_booking(
        $booking
    ) {

        $price_minor_units =
            isset(
                $booking->price_minor_units
            )
                ? absint(
                    $booking->price_minor_units
                )
                : 0;

        if ( 0 >= $price_minor_units ) {
            return new WP_Error(
                'tutorhelper_pro_stripe_free_booking',
                __(
                    'This booking does not require payment.',
                    'tutorhelper-pro'
                )
            );
        }

        $currency =
            isset( $booking->currency )
                ? strtoupper(
                    sanitize_text_field(
                        $booking->currency
                    )
                )
                : '';

        if ( '' === $currency ) {
            return new WP_Error(
                'tutorhelper_pro_stripe_currency_missing',
                __(
                    'The booking currency is missing.',
                    'tutorhelper-pro'
                )
            );
        }

        if (
            class_exists(
                'TutorHelper_Currency'
            )
        ) {
            $currencies =
                TutorHelper_Currency::
                    get_supported_currencies();

            if (
                ! isset(
                    $currencies[
                        $currency
                    ]
                )
            ) {
                return new WP_Error(
                    'tutorhelper_pro_stripe_currency_invalid',
                    __(
                        'The booking currency is not supported.',
                        'tutorhelper-pro'
                    )
                );
            }
        }

        if (
            ! empty(
                $booking->payment_method
            )
            && TutorHelper_Booking_Records::
                PAYMENT_METHOD_STRIPE
                !== sanitize_key(
                    $booking->payment_method
                )
        ) {
            return new WP_Error(
                'tutorhelper_pro_stripe_wrong_payment_method',
                __(
                    'This booking is not configured for Stripe payment.',
                    'tutorhelper-pro'
                )
            );
        }

        return true;
    }


    /**
     * Build the Stripe Checkout Session request.
     *
     * @param object $booking      Core booking.
     * @param object $booking_type Booking type.
     * @param array  $args         Session URLs.
     *
     * @return array|WP_Error
     */
    private static function build_checkout_body(
        $booking,
        $booking_type,
        $args
    ) {

        $amount_minor_units =
            absint(
                $booking
                    ->price_minor_units
            );

        $currency =
            strtolower(
                sanitize_text_field(
                    $booking->currency
                )
            );

        $success_url =
            isset(
                $args['success_url']
            )
                ? (string)
                    $args['success_url']
                : '';

        $cancel_url =
            isset(
                $args['cancel_url']
            )
                ? esc_url_raw(
                    $args['cancel_url']
                )
                : '';

        if (
            '' === $success_url
            || '' === $cancel_url
        ) {
            return new WP_Error(
                'tutorhelper_pro_stripe_return_url_missing',
                __(
                    'Stripe return URLs could not be created.',
                    'tutorhelper-pro'
                )
            );
        }

        $product_name =
            ! empty(
                $booking_type->title
            )
                ? sanitize_text_field(
                    $booking_type->title
                )
                : __(
                    'Tutor booking',
                    'tutorhelper-pro'
                );

        $description =
            self::build_description(
                $booking
            );

        $body = array(
            'mode' =>
                'payment',

            'expires_at' =>
                time()
                + (
                    30
                    * MINUTE_IN_SECONDS
                ),

            'payment_method_types[0]' =>
	            'card',

            'success_url' =>
                $success_url,

            'cancel_url' =>
                $cancel_url,

            'client_reference_id' =>
                (string)
                    absint(
                        $booking->id
                    ),

            'line_items[0][quantity]' =>
                1,

            'line_items[0][price_data][currency]' =>
                $currency,

            'line_items[0][price_data][unit_amount]' =>
                $amount_minor_units,

            'line_items[0][price_data][product_data][name]' =>
                $product_name,

            'metadata[booking_id]' =>
                (string)
                    absint(
                        $booking->id
                    ),

            'metadata[student_user_id]' =>
                (string)
                    absint(
                        $booking
                            ->student_user_id
                    ),

            'metadata[tutor_user_id]' =>
                (string)
                    absint(
                        $booking
                            ->tutor_user_id
                    ),

            'metadata[booking_type_id]' =>
                (string)
                    absint(
                        $booking
                            ->booking_type_id
                    ),
        );

        if (
            ! empty(
                $booking->student_email
            )
        ) {
            $body['customer_email'] =
                sanitize_email(
                    $booking
                        ->student_email
                );
        }

        if ( '' !== $description ) {
            $body[
                'line_items[0][price_data][product_data][description]'
            ] =
                $description;
        }

        return $body;
    }


    /**
     * Build the Checkout line-item description.
     *
     * @param object $booking Core booking.
     *
     * @return string
     */
    private static function build_description(
        $booking
    ) {

        $parts = array();

        if (
            ! empty(
                $booking->booking_start
            )
        ) {
            try {
                $start =
                    new DateTimeImmutable(
                        $booking
                            ->booking_start,
                        new DateTimeZone(
                            'UTC'
                        )
                    );

                $local_start =
                    $start->setTimezone(
                        wp_timezone()
                    );

                $parts[] =
                    wp_date(
                        'D j M Y, H:i',
                        $local_start
                            ->getTimestamp(),
                        wp_timezone()
                    );
            } catch ( Exception $exception ) {
                /*
                * A description is optional. Do not prevent checkout
                * if legacy date data cannot be formatted.
                */
            }
        }

        if (
            ! empty(
                $booking->student_name
            )
        ) {
            $parts[] =
                sprintf(
                    /* translators: %s: student name. */
                    __(
                        'Student: %s',
                        'tutorhelper-pro'
                    ),
                    sanitize_text_field(
                        $booking
                            ->student_name
                    )
                );
        }

        return sanitize_text_field(
            implode(
                ' · ',
                $parts
            )
        );
    }


    /**
     * Return the default successful Checkout return URL.
     *
     * Stripe replaces {CHECKOUT_SESSION_ID} after payment.
     *
     * @param int $booking_id Booking ID.
     *
     * @return string
     */
    private static function get_default_success_url(
        $booking_id
    ) {

        $base_url =
            home_url( '/' );

        $url =
            add_query_arg(
                array(
                    'tutorhelper_payment' =>
                        'success',

                    'booking_id' =>
                        absint(
                            $booking_id
                        ),
                ),
                $base_url
            );

        /*
        * Stripe requires this placeholder exactly as written.
        * Add it after URL sanitisation so the braces are retained.
        */
        return esc_url_raw(
            $url
        )
            . '&session_id={CHECKOUT_SESSION_ID}';
    }

    /**
     * Return the default cancelled Checkout return URL.
     *
     * @param int $booking_id Booking ID.
     *
     * @return string
     */
    private static function get_default_cancel_url(
        $booking_id
    ) {

        return add_query_arg(
            array(
                'tutorhelper_payment' =>
                    'cancelled',

                'booking_id' =>
                    absint(
                        $booking_id
                    ),
            ),
            home_url( '/' )
        );
    }


    /**
     * Send a request to the Stripe API.
     *
     * @param string $method   HTTP method.
     * @param string $endpoint Stripe API endpoint.
     * @param array  $body     Request body.
     *
     * @return array|WP_Error
     */
    private static function request(
        $method,
        $endpoint,
        $body = array()
    ) {

        $secret_key =
            TutorHelper_Pro_Payment_Settings::
                get_stripe_secret_key();

        if ( '' === $secret_key ) {
            return new WP_Error(
                'tutorhelper_pro_stripe_secret_missing',
                __(
                    'The active Stripe secret key is missing.',
                    'tutorhelper-pro'
                )
            );
        }

        $url =
            self::API_BASE
            . '/'
            . ltrim(
                $endpoint,
                '/'
            );

        $response =
            wp_remote_request(
                $url,
                array(
                    'method' =>
                        strtoupper(
                            sanitize_key(
                                $method
                            )
                        ),

                    'timeout' =>
                        30,

                    'headers' =>
                        array(
                            'Authorization' =>
                                'Bearer '
                                . $secret_key,

                            'Stripe-Version' =>
                                self::API_VERSION,
                        ),

                    'body' =>
                        $body,
                )
            );

        if (
            is_wp_error(
                $response
            )
        ) {
            TutorHelper_Logger::error(
                'Stripe API request failed.',
                array(
                    'endpoint' =>
                        $endpoint,

                    'error' =>
                        $response
                            ->get_error_message(),
                )
            );

            return new WP_Error(
                'tutorhelper_pro_stripe_request_failed',
                __(
                    'Stripe could not be contacted. Please try again.',
                    'tutorhelper-pro'
                )
            );
        }

        $status_code =
            wp_remote_retrieve_response_code(
                $response
            );

        $raw_body =
            wp_remote_retrieve_body(
                $response
            );

        $data =
            json_decode(
                $raw_body,
                true
            );

        if (
            $status_code < 200
            || $status_code >= 300
        ) {

            $stripe_message =
                is_array( $data )
                && ! empty(
                    $data['error']['message']
                )
                    ? sanitize_text_field(
                        $data['error']['message']
                    )
                    : __(
                        'Stripe rejected the payment request.',
                        'tutorhelper-pro'
                    );

            TutorHelper_Logger::error(
                'Stripe API request rejected.',
                array(
                    'endpoint' =>
                        $endpoint,

                    'status_code' =>
                        $status_code,

                    'stripe_message' =>
                        $stripe_message,
                )
            );

            return new WP_Error(
                'tutorhelper_pro_stripe_api_error',
                $stripe_message
            );
        }

        if ( ! is_array( $data ) ) {
            return new WP_Error(
                'tutorhelper_pro_stripe_invalid_response',
                __(
                    'Stripe returned an invalid response.',
                    'tutorhelper-pro'
                )
            );
        }

        return $data;
    }
}
