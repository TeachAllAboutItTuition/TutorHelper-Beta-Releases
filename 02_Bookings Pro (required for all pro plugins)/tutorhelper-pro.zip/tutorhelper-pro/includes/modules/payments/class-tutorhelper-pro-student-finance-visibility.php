<?php
/**
 * Per-student finance visibility.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Controls whether financial details appear on a student's dashboard.
 */
final class TutorHelper_Pro_Student_Finance_Visibility {

	const META_VISIBILITY = 'tutorhelper_pro_student_finance_visibility';
	const VISIBILITY_STUDENT = 'student';
	const VISIBILITY_PARENT_ONLY = 'parent_only';
	const SAVE_ACTION = 'tutorhelper_pro_save_student_finance_visibility';

	/** Register admin and privacy hooks. */
	public static function init() {
		add_action(
			'tutorhelper_students_detail_lesson_options_pricing',
			array( __CLASS__, 'render_setting' ),
			15
		);
		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array( __CLASS__, 'handle_save' )
		);
		add_filter(
			'tutorhelper_student_privacy_export_data',
			array( __CLASS__, 'add_privacy_export_data' ),
			10,
			2
		);
		add_action(
			'tutorhelper_student_privacy_delete_data',
			array( __CLASS__, 'delete_privacy_data' ),
			10,
			3
		);
	}

	/**
	 * Return the saved visibility. Existing students default to student access.
	 *
	 * @param int $student_id Student user ID.
	 * @return string
	 */
	public static function get_visibility( $student_id ) {
		$value = sanitize_key(
			(string) get_user_meta(
				absint( $student_id ),
				self::META_VISIBILITY,
				true
			)
		);

		return self::VISIBILITY_PARENT_ONLY === $value
			? self::VISIBILITY_PARENT_ONLY
			: self::VISIBILITY_STUDENT;
	}

	/**
	 * Whether this student's own dashboard may expose financial details.
	 *
	 * @param int $student_id Student user ID.
	 * @return bool
	 */
	public static function student_can_view_finance( $student_id ) {
		$visible = self::VISIBILITY_PARENT_ONLY !== self::get_visibility( $student_id );

		return (bool) apply_filters(
			'tutorhelper_pro_student_finance_visible',
			$visible,
			absint( $student_id )
		);
	}

	/** Render the control alongside personal pricing. */
	public static function render_setting( $student ) {
		if (
			! $student instanceof WP_User
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$student_id = absint( $student->ID );
		$value = self::get_visibility( $student_id );
		$notice = isset( $_GET['tutorhelper_pro_finance_visibility_notice'] ) && ! is_array( $_GET['tutorhelper_pro_finance_visibility_notice'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only action feedback.
			? sanitize_key( wp_unslash( $_GET['tutorhelper_pro_finance_visibility_notice'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only action feedback.
			: '';
		?>
		<?php if ( 'saved' === $notice ) : ?><div class="notice notice-success inline"><p><?php esc_html_e( 'Dashboard finance visibility saved.', 'tutorhelper-pro' ); ?></p></div><?php endif; ?>
		<section class="tutorhelper-student-detail__section tutorhelper-pro-finance-visibility">
			<h3><?php esc_html_e( 'Dashboard price visibility', 'tutorhelper-pro' ); ?></h3>
			<p><?php esc_html_e( 'Choose who can see payment, credit and refund details in account dashboards. Booking-form prices and payment choices are not changed.', 'tutorhelper-pro' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
				<input type="hidden" name="student_id" value="<?php echo esc_attr( $student_id ); ?>" />
				<?php wp_nonce_field( self::SAVE_ACTION, 'tutorhelper_pro_finance_visibility_nonce' ); ?>
				<fieldset>
					<legend class="screen-reader-text"><?php esc_html_e( 'Who can see finance details?', 'tutorhelper-pro' ); ?></legend>
					<label class="tutorhelper-toggle-row">
						<input type="radio" name="finance_visibility" value="<?php echo esc_attr( self::VISIBILITY_STUDENT ); ?>" <?php checked( self::VISIBILITY_STUDENT, $value ); ?> />
						<span><strong><?php esc_html_e( 'Student and linked accounts', 'tutorhelper-pro' ); ?></strong><small><?php esc_html_e( 'Show finance details to the student and linked parent or guardian accounts.', 'tutorhelper-pro' ); ?></small></span>
					</label>
					<label class="tutorhelper-toggle-row">
						<input type="radio" name="finance_visibility" value="<?php echo esc_attr( self::VISIBILITY_PARENT_ONLY ); ?>" <?php checked( self::VISIBILITY_PARENT_ONLY, $value ); ?> />
						<span><strong><?php esc_html_e( 'Parent/Guardian only', 'tutorhelper-pro' ); ?></strong><small><?php esc_html_e( 'Hide payment history, refunds and account credit from the student dashboard. Linked accounts can still view finance.', 'tutorhelper-pro' ); ?></small></span>
					</label>
				</fieldset>
				<p><button type="submit" class="button tutorhelper-action-button"><?php esc_html_e( 'Save dashboard visibility', 'tutorhelper-pro' ); ?></button></p>
			</form>
		</section>
		<?php
	}

	/** Save the selected visibility. */
	public static function handle_save() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die(
				esc_html__( 'You do not have permission to manage finance visibility.', 'tutorhelper-pro' ),
				esc_html__( 'Permission denied', 'tutorhelper-pro' ),
				array( 'response' => 403 )
			);
		}

		check_admin_referer(
			self::SAVE_ACTION,
			'tutorhelper_pro_finance_visibility_nonce'
		);

		$student_id = isset( $_POST['student_id'] )
			? absint( wp_unslash( $_POST['student_id'] ) )
			: 0;
		$student = TutorHelper_Students::get_student( $student_id );

		if ( ! $student instanceof WP_User ) {
			wp_die( esc_html__( 'The selected student could not be found.', 'tutorhelper-pro' ) );
		}

		$value = isset( $_POST['finance_visibility'] ) && ! is_array( $_POST['finance_visibility'] )
			? sanitize_key( wp_unslash( $_POST['finance_visibility'] ) )
			: self::VISIBILITY_STUDENT;

		if ( self::VISIBILITY_PARENT_ONLY !== $value ) {
			$value = self::VISIBILITY_STUDENT;
		}

		update_user_meta( $student_id, self::META_VISIBILITY, $value );

		$url = add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Students_Admin::TAB_KEY,
				'student_id' => $student_id,
				'tutorhelper_pro_finance_visibility_notice' => 'saved',
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	/** Include visibility in the student privacy export. */
	public static function add_privacy_export_data( $data, $student ) {
		if ( is_array( $data ) && $student instanceof WP_User ) {
			$data['pro']['user_meta'][ self::META_VISIBILITY ] =
				get_user_meta( absint( $student->ID ), self::META_VISIBILITY, true );
		}
		return $data;
	}

	/** Delete visibility metadata during student erasure. */
	public static function delete_privacy_data( $student_id, $student, $mode ) {
		unset( $student, $mode );
		delete_user_meta( absint( $student_id ), self::META_VISIBILITY );
	}
}
