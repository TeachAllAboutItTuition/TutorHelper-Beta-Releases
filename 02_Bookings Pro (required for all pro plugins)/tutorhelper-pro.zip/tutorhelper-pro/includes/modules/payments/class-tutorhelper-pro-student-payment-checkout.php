<?php
/**
 * Student payment checkout integration.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Connects Core student bookings to Pro payment providers.
 */
final class TutorHelper_Pro_Student_Payment_Checkout {

	/**
	 * Return-page notice.
	 *
	 * @var array
	 */
	private static $return_notice =
		array();

	/**
	 * Register integration hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_filter(
			'tutorhelper_student_booking_payment_args',
			array(
				__CLASS__,
				'configure_payment',
			),
			10,
			2
		);

		add_filter(
			'tutorhelper_student_booking_submission_result',
			array(
				__CLASS__,
				'prepare_checkout',
			),
			10,
			3
		);

		add_filter(
			'tutorhelper_booking_send_request_emails',
			array(
				__CLASS__,
				'filter_request_emails',
			),
			10,
			3
		);

		add_action(
			'template_redirect',
			array(
				__CLASS__,
				'handle_payment_return',
			)
		);

		add_filter(
			'the_content',
			array(
				__CLASS__,
				'prepend_return_notice',
			)
		);
	}


    /**
     * Configure payment for a student booking.
     *
     * @param array $payment_args Core defaults.
     * @param array $context      Booking context.
     *
     * @return array|WP_Error
     */
    public static function configure_payment(
        $payment_args,
        $context
    ) {

        if (
            ! is_array( $payment_args )
            || ! is_array( $context )
        ) {
            return $payment_args;
        }

        $duration =
            self::calculate_duration_minutes(
                isset(
                    $context['booking_start']
                )
                    ? $context['booking_start']
                    : '',
                isset(
                    $context['booking_end']
                )
                    ? $context['booking_end']
                    : '',
                isset(
                    $context['timezone']
                )
                    ? $context['timezone']
                    : ''
            );

        if ( is_wp_error( $duration ) ) {
            return $duration;
        }

        $pricing =
            TutorHelper_Booking_Records::
                resolve_pricing(
                    absint(
                        $context[
                            'student_user_id'
                        ]
                    ),
                    absint(
                        $context[
                            'booking_type_id'
                        ]
                    ),
                    $duration
                );

        if ( is_wp_error( $pricing ) ) {
            return $pricing;
        }

        $price_minor_units =
            absint(
                $pricing[
                    'price_minor_units'
                ]
            );

        /*
        * Free bookings continue through Core's normal free workflow.
        */
        if ( 0 === $price_minor_units ) {
            return $payment_args;
        }

        if (
            ! TutorHelper_Pro_Payment_Settings::
                stripe_is_configured()
        ) {
            return new WP_Error(
                'tutorhelper_pro_payment_unavailable',
                __(
                    'Online payment is currently unavailable. Please contact your tutor.',
                    'tutorhelper-pro'
                )
            );
        }

        $payment_args[
            'skip_payment'
        ] = false;

        $payment_args[
            'payment_method'
        ] =
            TutorHelper_Booking_Records::
                PAYMENT_METHOD_STRIPE;

        $payment_args[
            'payment_status'
        ] =
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PENDING;

        return $payment_args;
    }



    /**
     * Calculate booking duration.
     *
     * @param string $start    Local start.
     * @param string $end      Local end.
     * @param string $timezone Timezone.
     *
     * @return int|WP_Error
     */
    private static function calculate_duration_minutes(
        $start,
        $end,
        $timezone
    ) {

        try {
            $zone =
                new DateTimeZone(
                    sanitize_text_field(
                        $timezone
                    )
                );

            $start_date =
                new DateTimeImmutable(
                    sanitize_text_field(
                        $start
                    ),
                    $zone
                );

            $end_date =
                new DateTimeImmutable(
                    sanitize_text_field(
                        $end
                    ),
                    $zone
                );

        } catch ( Exception $exception ) {
            return new WP_Error(
                'tutorhelper_pro_payment_date_invalid',
                __(
                    'The lesson time could not be prepared for payment.',
                    'tutorhelper-pro'
                )
            );
        }

        $seconds =
            $end_date->getTimestamp()
            - $start_date->getTimestamp();

        if (
            0 >= $seconds
            || 0 !== $seconds
                % MINUTE_IN_SECONDS
        ) {
            return new WP_Error(
                'tutorhelper_pro_payment_duration_invalid',
                __(
                    'The lesson duration could not be prepared for payment.',
                    'tutorhelper-pro'
                )
            );
        }

        return (int) (
            $seconds
            / MINUTE_IN_SECONDS
        );
    }

    /**
     * Create the external Checkout Session.
     *
     * @param array  $result          Core booking result.
     * @param int    $student_user_id Student user ID.
     * @param string $return_url      Booking page URL.
     *
     * @return array|WP_Error
     */
    public static function prepare_checkout(
        $result,
        $student_user_id,
        $return_url
    ) {

        if (
            ! is_array( $result )
            || empty(
                $result['booking_id']
            )
        ) {
            return $result;
        }

        $booking_id =
            absint(
                $result['booking_id']
            );

        $booking =
            TutorHelper_Booking_Records::
                get_by_id(
                    $booking_id
                );

        if ( ! $booking ) {
            return $result;
        }

        if (
            absint(
                $booking->student_user_id
            )
            !== absint(
                $student_user_id
            )
        ) {
            return new WP_Error(
                'tutorhelper_pro_payment_student_mismatch',
                __(
                    'The booking could not be prepared for payment.',
                    'tutorhelper-pro'
                )
            );
        }

        /*
        * Free bookings never leave Core.
        */
        if (
            0 >= absint(
                $booking->price_minor_units
            )
        ) {
            return $result;
        }

        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PENDING
            !== sanitize_key(
                $booking->payment_status
            )
            || TutorHelper_Booking_Records::
                PAYMENT_METHOD_STRIPE
            !== sanitize_key(
                $booking->payment_method
            )
        ) {
            return $result;
        }

        $urls =
            self::build_return_urls(
                $booking_id,
                $return_url
            );

        $checkout =
            TutorHelper_Pro_Stripe::
                create_checkout_session(
                    $booking_id,
                    $urls
                );

        if ( is_wp_error( $checkout ) ) {

            self::fail_checkout(
                $booking
            );

            return new WP_Error(
                'tutorhelper_pro_checkout_unavailable',
                __(
                    'Secure payment could not be started. Your lesson has not been booked. Please try again.',
                    'tutorhelper-pro'
                )
            );
        }

        $result['redirect_url'] =
            esc_url_raw(
                $checkout['url']
            );

        $result['message'] =
            __(
                'Taking you to secure payment…',
                'tutorhelper-pro'
            );

        return $result;
    }


    /**
     * Build Stripe success and cancellation URLs.
     *
     * @param int    $booking_id Booking ID.
     * @param string $return_url Original booking page.
     *
     * @return array
     */
    private static function build_return_urls(
        $booking_id,
        $return_url
    ) {

        $return_url =
            wp_validate_redirect(
                $return_url,
                home_url( '/' )
            );

        $return_url =
            remove_query_arg(
                array(
                    'tutorhelper_payment',
                    'tutorhelper_booking_id',
                    'tutorhelper_payment_nonce',
                    'session_id',
                ),
                $return_url
            );

        $nonce =
            wp_create_nonce(
                'tutorhelper_pro_payment_return_'
                . absint(
                    $booking_id
                )
            );

        $success_url =
            add_query_arg(
                array(
                    'tutorhelper_payment' =>
                        'success',

                    'tutorhelper_booking_id' =>
                        absint(
                            $booking_id
                        ),

                    'tutorhelper_payment_nonce' =>
                        $nonce,
                ),
                $return_url
            );

        /*
        * Stripe replaces this literal placeholder.
        */
        $success_url =
            esc_url_raw(
                $success_url
            )
            . '&session_id={CHECKOUT_SESSION_ID}';

        $cancel_url =
            add_query_arg(
                array(
                    'tutorhelper_payment' =>
                        'cancelled',

                    'tutorhelper_booking_id' =>
                        absint(
                            $booking_id
                        ),

                    'tutorhelper_payment_nonce' =>
                        $nonce,
                ),
                $return_url
            );

        return array(
            'success_url' =>
                $success_url,

            'cancel_url' =>
                esc_url_raw(
                    $cancel_url
                ),
        );
    }

    /**
     * Mark a checkout-start failure and release the slot.
     *
     * @param object $booking Booking record.
     *
     * @return void
     */
    private static function fail_checkout(
        $booking
    ) {

        $result =
            TutorHelper_Booking_Records::
                update_payment_details(
                    absint(
                        $booking->id
                    ),
                    array(
                        'payment_status' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_STATUS_FAILED,

                        'payment_method' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_METHOD_STRIPE,

                        'payment_provider' =>
                            TutorHelper_Pro_Payment_Settings::
                                PROVIDER_STRIPE,

                        'payment_reference' =>
                            '',

                        'booking_status' =>
                            TutorHelper_Booking_Records::
                                STATUS_CANCELLED,
                    ),
                    TutorHelper_Booking_Records::
                        PAYMENT_STATUS_PENDING
                );

        if ( is_wp_error( $result ) ) {
            TutorHelper_Logger::error(
                'Failed payment checkout booking could not be released.',
                array(
                    'booking_id' =>
                        absint(
                            $booking->id
                        ),
                )
            );

            return;
        }

        TutorHelper_Pro_Payment_History::
            record(
                array(
                    'booking_id' =>
                        absint(
                            $booking->id
                        ),

                    'student_user_id' =>
                        absint(
                            $booking
                                ->student_user_id
                        ),

                    'previous_payment_status' =>
                        TutorHelper_Booking_Records::
                            PAYMENT_STATUS_PENDING,

                    'new_payment_status' =>
                        TutorHelper_Booking_Records::
                            PAYMENT_STATUS_FAILED,

                    'previous_booking_status' =>
                        sanitize_key(
                            $booking->status
                        ),

                    'new_booking_status' =>
                        TutorHelper_Booking_Records::
                            STATUS_CANCELLED,

                    'amount_minor_units' =>
                        absint(
                            $booking
                                ->price_minor_units
                        ),

                    'currency' =>
                        strtoupper(
                            sanitize_text_field(
                                $booking
                                    ->currency
                            )
                        ),

                    'payment_method' =>
                        TutorHelper_Booking_Records::
                            PAYMENT_METHOD_STRIPE,

                    'payment_provider' =>
                        TutorHelper_Pro_Payment_Settings::
                            PROVIDER_STRIPE,

                    'change_source' =>
                        TutorHelper_Pro_Payment_History::
                            SOURCE_STUDENT_CHECKOUT,

                    'notes' =>
                        __(
                            'Stripe Checkout could not be started.',
                            'tutorhelper-pro'
                        ),
                )
            );
    }


    /**
     * Defer request emails while Stripe payment is pending.
     *
     * @param bool  $send        Current decision.
     * @param int   $booking_id  Booking ID.
     * @param array $insert_data Booking data.
     *
     * @return bool
     */
    public static function filter_request_emails(
        $send,
        $booking_id,
        $insert_data
    ) {

        unset( $booking_id );

        if ( ! is_array( $insert_data ) ) {
            return $send;
        }

        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PENDING
            === sanitize_key(
                isset(
                    $insert_data[
                        'payment_status'
                    ]
                )
                    ? $insert_data[
                        'payment_status'
                    ]
                    : ''
            )
            && TutorHelper_Booking_Records::
                PAYMENT_METHOD_STRIPE
            === sanitize_key(
                isset(
                    $insert_data[
                        'payment_method'
                    ]
                )
                    ? $insert_data[
                        'payment_method'
                    ]
                    : ''
            )
        ) {
            return false;
        }

        return $send;
    }



    /**
     * Handle Stripe return URLs.
     *
     * @return void
     */
    public static function handle_payment_return() {

        if (
            empty(
                $_GET[
                    'tutorhelper_payment'
                ]
            )
        ) {
            return;
        }

        $action =
            sanitize_key(
                wp_unslash(
                    $_GET[
                        'tutorhelper_payment'
                    ]
                )
            );

        if (
            ! in_array(
                $action,
                array(
                    'success',
                    'cancelled',
                ),
                true
            )
        ) {
            return;
        }

        if ( ! is_user_logged_in() ) {
            return;
        }

        $booking_id =
            isset(
                $_GET[
                    'tutorhelper_booking_id'
                ]
            )
                ? absint(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_booking_id'
                        ]
                    )
                )
                : 0;

        $nonce =
            isset(
                $_GET[
                    'tutorhelper_payment_nonce'
                ]
            )
                ? sanitize_text_field(
                    wp_unslash(
                        $_GET[
                            'tutorhelper_payment_nonce'
                        ]
                    )
                )
                : '';

        if (
            ! $booking_id
            || ! wp_verify_nonce(
                $nonce,
                'tutorhelper_pro_payment_return_'
                . $booking_id
            )
        ) {
            return;
        }

        $booking =
            TutorHelper_Booking_Records::
                get_by_id(
                    $booking_id
                );

        if ( ! $booking ) {
            return;
        }

        $return_authorised =
            get_current_user_id()
            === absint( $booking->student_user_id );

        /**
         * Allow compatible delegated booking contexts, such as an authorised
         * Parent Account, to process their own signed Stripe return.
         *
         * @param bool   $return_authorised Whether the viewer may handle the return.
         * @param object $booking           Booking record.
         * @param int    $viewer_user_id    Current WordPress user ID.
         */
        $return_authorised = (bool) apply_filters(
            'tutorhelper_pro_student_payment_return_authorised',
            $return_authorised,
            $booking,
            absint( get_current_user_id() )
        );

        if ( ! $return_authorised ) {
            return;
        }

        if ( 'success' === $action ) {

            if (
                TutorHelper_Booking_Records::
                    PAYMENT_STATUS_PAID
                === sanitize_key(
                    $booking
                        ->payment_status
                )
            ) {
                self::$return_notice =
                    array(
                        'type' =>
                            'success',

                        'message' =>
                            __(
                                'Payment received. Your lesson is confirmed.',
                                'tutorhelper-pro'
                            ),
                    );
            } else {
                self::$return_notice =
                    array(
                        'type' =>
                            'success',

                        'message' =>
                            __(
                                'Your payment has been submitted. TutorHelper is waiting for Stripe to confirm your booking.',
                                'tutorhelper-pro'
                            ),
                    );
            }

            return;
        }

        self::cancel_pending_checkout(
            $booking
        );
    }


    /**
     * Cancel an unfinished student Checkout.
     *
     * @param object $booking Booking record.
     *
     * @return void
     */
    private static function cancel_pending_checkout(
        $booking
    ) {

        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PAID
            === sanitize_key(
                $booking
                    ->payment_status
            )
        ) {
            self::$return_notice =
                array(
                    'type' =>
                        'success',

                    'message' =>
                        __(
                            'Your payment has already been received.',
                            'tutorhelper-pro'
                        ),
                );

            return;
        }

        if (
            TutorHelper_Booking_Records::
                STATUS_CANCELLED
            === sanitize_key(
                $booking->status
            )
        ) {
            self::$return_notice =
                array(
                    'type' =>
                        'success',

                    'message' =>
                        __(
                            'Payment was cancelled and the lesson slot has been released.',
                            'tutorhelper-pro'
                        ),
                );

            return;
        }

        $expire_result =
            TutorHelper_Pro_Stripe::
                expire_checkout_session(
                    sanitize_text_field(
                        $booking
                            ->payment_reference
                    )
                );

        if ( is_wp_error( $expire_result ) ) {

            self::$return_notice =
                array(
                    'type' =>
                        'error',

                    'message' =>
                        __(
                            'The payment session could not be cancelled automatically. Please contact your tutor.',
                            'tutorhelper-pro'
                        ),
                );

            return;
        }

        /*
         * An unpaid, unconfirmed request has no financial settlement to
         * preserve. Remove it as soon as Stripe has confirmed the Checkout
         * Session is expired so that a browser Back action cannot leave an
         * orphan lesson request behind.
         */
        if (
            TutorHelper_Booking_Records::STATUS_UNCONFIRMED
            === sanitize_key( $booking->status )
        ) {
            $deleted = TutorHelper_Booking_Records::delete_unconfirmed(
                absint( $booking->id )
            );

            if ( ! is_wp_error( $deleted ) ) {
                self::$return_notice =
                    array(
                        'type' =>
                            'success',

                        'message' =>
                            __(
                                'Payment was cancelled and the lesson request has been removed.',
                                'tutorhelper-pro'
                            ),
                    );

                return;
            }
        }

        $update =
            TutorHelper_Booking_Records::
                update_payment_details(
                    absint(
                        $booking->id
                    ),
                    array(
                        'payment_status' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_STATUS_EXPIRED,

                        'payment_method' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_METHOD_STRIPE,

                        'payment_provider' =>
                            TutorHelper_Pro_Payment_Settings::
                                PROVIDER_STRIPE,

                        'payment_reference' =>
                            sanitize_text_field(
                                $booking
                                    ->payment_reference
                            ),

                        'booking_status' =>
                            TutorHelper_Booking_Records::
                                STATUS_CANCELLED,
                    ),
                    TutorHelper_Booking_Records::
                        PAYMENT_STATUS_PENDING
                );

        if ( is_wp_error( $update ) ) {
            self::$return_notice =
                array(
                    'type' =>
                        'error',

                    'message' =>
                        __(
                            'The lesson could not be released automatically. Please contact your tutor.',
                            'tutorhelper-pro'
                        ),
                );

            return;
        }

        TutorHelper_Pro_Payment_History::
            record(
                array(
                    'booking_id' =>
                        absint(
                            $booking->id
                        ),

                    'student_user_id' =>
                        absint(
                            $booking
                                ->student_user_id
                        ),

                    'previous_payment_status' =>
                        TutorHelper_Booking_Records::
                            PAYMENT_STATUS_PENDING,

                    'new_payment_status' =>
                        TutorHelper_Booking_Records::
                            PAYMENT_STATUS_EXPIRED,

                    'previous_booking_status' =>
                        sanitize_key(
                            $booking->status
                        ),

                    'new_booking_status' =>
                        TutorHelper_Booking_Records::
                            STATUS_CANCELLED,

                    'amount_minor_units' =>
                        absint(
                            $booking
                                ->price_minor_units
                        ),

                    'currency' =>
                        strtoupper(
                            sanitize_text_field(
                                $booking
                                    ->currency
                            )
                        ),

                    'payment_method' =>
                        TutorHelper_Booking_Records::
                            PAYMENT_METHOD_STRIPE,

                    'payment_provider' =>
                        TutorHelper_Pro_Payment_Settings::
                            PROVIDER_STRIPE,

                    'provider_reference' =>
                        sanitize_text_field(
                            $booking
                                ->payment_reference
                        ),

                    'change_source' =>
                        TutorHelper_Pro_Payment_History::
                            SOURCE_STUDENT_CHECKOUT,

                    'notes' =>
                        __(
                            'Student cancelled Stripe Checkout.',
                            'tutorhelper-pro'
                        ),
                )
            );

        self::$return_notice =
            array(
                'type' =>
                    'success',

                'message' =>
                    __(
                        'Payment was cancelled and the lesson slot has been released.',
                        'tutorhelper-pro'
                    ),
            );
    }


    /**
     * Display the payment return notice.
     *
     * @param string $content Page content.
     *
     * @return string
     */
    public static function prepend_return_notice(
        $content
    ) {

        if (
            empty(
                self::$return_notice[
                    'message'
                ]
            )
            || ! in_the_loop()
            || ! is_main_query()
        ) {
            return $content;
        }

        $type =
            'error'
            === self::$return_notice[
                'type'
            ]
                ? 'error'
                : 'success';

        $notice =
            sprintf(
                '<div class="tutorhelper-student-booking__message is-%1$s" role="status"><p>%2$s</p></div>',
                esc_attr(
                    $type
                ),
                esc_html(
                    self::$return_notice[
                        'message'
                    ]
                )
            );

        return $notice
            . $content;
    }


}
