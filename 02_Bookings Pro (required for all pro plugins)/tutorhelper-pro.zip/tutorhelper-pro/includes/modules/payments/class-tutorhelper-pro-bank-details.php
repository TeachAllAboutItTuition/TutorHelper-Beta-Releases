<?php
/**
 * TutorHelper Pro bank transfer settings.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores and renders tutor bank transfer details.
 */
final class TutorHelper_Pro_Bank_Details {

	const OPTION_KEY = 'tutorhelper_pro_bank_details';
	const SAVE_ACTION = 'tutorhelper_pro_save_bank_details';
	const ADMIN_SCRIPT_HANDLE = 'tutorhelper-pro-bank-details-admin';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array( __CLASS__, 'handle_save' )
		);

		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_admin_assets' )
		);

		add_action(
			'admin_footer',
			array( __CLASS__, 'render_booking_settings_panel' )
		);
	}

	/**
	 * Return all stored bank details.
	 *
	 * @return array
	 */
	public static function get_details() {
		$defaults = array(
			'account_name' => '',
			'bank_name' => '',
			'sort_code' => '',
			'account_number' => '',
			'iban' => '',
			'bic' => '',
			'reference_instructions' => '',
			'additional_instructions' => '',
		);

		$stored = get_option(
			self::OPTION_KEY,
			array()
		);

		return wp_parse_args(
			is_array( $stored ) ? $stored : array(),
			$defaults
		);
	}

	/**
	 * Bank transfer must have enough information to make a payment.
	 *
	 * @return bool
	 */
	public static function is_configured() {
		$details = self::get_details();

		return '' !== trim( $details['account_name'] )
			&& (
				(
					'' !== trim( $details['sort_code'] )
					&& '' !== trim( $details['account_number'] )
				)
				|| '' !== trim( $details['iban'] )
			);
	}

	/**
	 * Enqueue the small admin helper used to place the Pro panel
	 * underneath Core Booking settings.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public static function enqueue_admin_assets( $hook_suffix ) {
		if (
			'tutorhelper_page_' . TutorHelper_Settings::PAGE_SLUG
			!== $hook_suffix
			|| 'booking' !== self::get_selected_settings_tab()
		) {
			return;
		}

		$path = TUTORHELPER_PRO_PATH
			. 'assets/js/bank-details-admin.js';

		wp_enqueue_script(
			self::ADMIN_SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL
				. 'assets/js/bank-details-admin.js',
			array(),
			file_exists( $path )
				? (string) filemtime( $path )
				: TUTORHELPER_PRO_VERSION,
			true
		);
	}

	/**
	 * Render the Pro bank details section. The external admin script
	 * moves this section immediately below Core Booking settings.
	 *
	 * @return void
	 */
	public static function render_booking_settings_panel() {
		if (
			! current_user_can( TutorHelper_Admin::CAPABILITY )
			|| 'booking' !== self::get_selected_settings_tab()
			|| ! isset( $_GET['page'] )
			|| TutorHelper_Settings::PAGE_SLUG
			!== sanitize_key( wp_unslash( $_GET['page'] ) )
		) {
			return;
		}

		$details = self::get_details();
		$notice = isset( $_GET['tutorhelper_pro_bank_notice'] )
			? sanitize_key(
				wp_unslash( $_GET['tutorhelper_pro_bank_notice'] )
			)
			: '';
		?>
		<div
			id="tutorhelper-pro-bank-details-panel"
			class="tutorhelper-pro-booking-settings-extension"
			hidden
		>
			<?php if ( 'saved' === $notice ) : ?>
				<div class="notice notice-success inline">
					<p><?php esc_html_e( 'Bank transfer details saved.', 'tutorhelper-pro' ); ?></p>
				</div>
			<?php endif; ?>

			<form
				method="post"
				action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
				class="tutorhelper-settings-form"
			>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
				<?php wp_nonce_field( self::SAVE_ACTION, 'tutorhelper_pro_bank_details_nonce' ); ?>

				<section class="tutorhelper-main-section">
					<header class="tutorhelper-main-section__header is-compact">
						<div class="tutorhelper-main-section__header-content">
							<h2><?php esc_html_e( 'Bank transfer details', 'tutorhelper-pro' ); ?></h2>
							<p><?php esc_html_e( 'These details are emailed only to students who choose Bank transfer. They are never exposed on the public booking form.', 'tutorhelper-pro' ); ?></p>
						</div>
					</header>

					<div class="tutorhelper-main-section__body tutorhelper-settings-section__body">
						<div class="tutorhelper-input-fields">
							<?php
							self::render_text_field( 'account_name', __( 'Account name', 'tutorhelper-pro' ), $details['account_name'] );
							self::render_text_field( 'bank_name', __( 'Bank name', 'tutorhelper-pro' ), $details['bank_name'] );
							self::render_text_field( 'sort_code', __( 'Sort code', 'tutorhelper-pro' ), $details['sort_code'] );
							self::render_text_field( 'account_number', __( 'Account number', 'tutorhelper-pro' ), $details['account_number'] );
							self::render_text_field( 'iban', __( 'IBAN', 'tutorhelper-pro' ), $details['iban'] );
							self::render_text_field( 'bic', __( 'BIC / SWIFT', 'tutorhelper-pro' ), $details['bic'] );
							self::render_textarea_field( 'reference_instructions', __( 'Payment reference instructions', 'tutorhelper-pro' ), $details['reference_instructions'] );
							self::render_textarea_field( 'additional_instructions', __( 'Additional payment instructions', 'tutorhelper-pro' ), $details['additional_instructions'] );
							?>
						</div>

						<div class="tutorhelper-settings-form__actions">
							<?php
							submit_button(
								__( 'Save bank details', 'tutorhelper-pro' ),
								'primary tutorhelper-action-button',
								'submit',
								false
							);
							?>
						</div>
					</div>
				</section>
			</form>
		</div>
		<?php
	}

	/**
	 * Save bank details without autoloading them on normal requests.
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die(
				esc_html__( 'You do not have permission to manage bank details.', 'tutorhelper-pro' ),
				esc_html__( 'Permission denied', 'tutorhelper-pro' ),
				array( 'response' => 403 )
			);
		}

		check_admin_referer(
			self::SAVE_ACTION,
			'tutorhelper_pro_bank_details_nonce'
		);

		$fields = array(
			'account_name',
			'bank_name',
			'sort_code',
			'account_number',
			'iban',
			'bic',
		);

		$details = array();
		foreach ( $fields as $field ) {
			$details[ $field ] = isset( $_POST[ $field ] )
				&& ! is_array( $_POST[ $field ] )
					? sanitize_text_field(
						wp_unslash( $_POST[ $field ] )
					)
					: '';
		}

		$details['reference_instructions'] = isset( $_POST['reference_instructions'] )
			&& ! is_array( $_POST['reference_instructions'] )
				? sanitize_textarea_field(
					wp_unslash( $_POST['reference_instructions'] )
				)
				: '';

		$details['additional_instructions'] = isset( $_POST['additional_instructions'] )
			&& ! is_array( $_POST['additional_instructions'] )
				? sanitize_textarea_field(
					wp_unslash( $_POST['additional_instructions'] )
				)
				: '';

		update_option(
			self::OPTION_KEY,
			$details,
			false
		);

		$url = add_query_arg(
			array(
				'page' => TutorHelper_Settings::PAGE_SLUG,
				'tab' => 'booking',
				'tutorhelper_pro_bank_notice' => 'saved',
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	private static function render_text_field( $name, $label, $value ) {
		?>
		<div class="tutorhelper-input-field">
			<label for="<?php echo esc_attr( 'tutorhelper-pro-' . $name ); ?>"><?php echo esc_html( $label ); ?></label>
			<input
				type="text"
				id="<?php echo esc_attr( 'tutorhelper-pro-' . $name ); ?>"
				name="<?php echo esc_attr( $name ); ?>"
				value="<?php echo esc_attr( $value ); ?>"
				class="tutorhelper-admin-control"
			/>
		</div>
		<?php
	}

	private static function render_textarea_field( $name, $label, $value ) {
		?>
		<div class="tutorhelper-input-field is-full-width">
			<label for="<?php echo esc_attr( 'tutorhelper-pro-' . $name ); ?>"><?php echo esc_html( $label ); ?></label>
			<textarea
				id="<?php echo esc_attr( 'tutorhelper-pro-' . $name ); ?>"
				name="<?php echo esc_attr( $name ); ?>"
				rows="3"
				class="tutorhelper-admin-control"
			><?php echo esc_textarea( $value ); ?></textarea>
		</div>
		<?php
	}

	private static function get_selected_settings_tab() {
		return isset( $_GET['tab'] )
			&& ! is_array( $_GET['tab'] )
				? sanitize_key( wp_unslash( $_GET['tab'] ) )
				: TutorHelper_Settings::DEFAULT_TAB;
	}
}
