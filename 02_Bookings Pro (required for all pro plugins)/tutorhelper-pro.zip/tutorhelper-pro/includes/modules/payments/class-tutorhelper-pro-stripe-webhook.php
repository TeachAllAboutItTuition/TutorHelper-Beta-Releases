<?php
/**
 * Stripe webhook processing for TutorHelper Pro.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Verifies and processes Stripe webhook events.
 */
final class TutorHelper_Pro_Stripe_Webhook {

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	const REST_NAMESPACE =
		'tutorhelper-pro/v1';

	/**
	 * Webhook route.
	 *
	 * @var string
	 */
	const REST_ROUTE =
		'/stripe/webhook';

	/**
	 * Maximum webhook signature age.
	 *
	 * @var int
	 */
	const SIGNATURE_TOLERANCE =
		300;

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'rest_api_init',
			array(
				__CLASS__,
				'register_routes',
			)
		);

		add_filter(
			'tutorhelper_stripe_diagnostics_enabled',
			array( __CLASS__, 'stripe_diagnostics_enabled' )
		);
	}


	/**
	 * Expose the Core Stripe diagnostics panel only for an active, configured
	 * TutorHelper Pro Stripe integration.
	 *
	 * @param bool $enabled Existing integration result.
	 * @return bool
	 */
	public static function stripe_diagnostics_enabled( $enabled ) {
		if ( $enabled ) {
			return true;
		}

		return class_exists( 'TutorHelper_Pro_License' )
			&& TutorHelper_Pro_License::is_active()
			&& TutorHelper_Pro_Payment_Settings::stripe_is_configured();
	}

	/**
	 * Register the Stripe webhook route.
	 *
	 * @return void
	 */
	public static function register_routes() {

		register_rest_route(
			self::REST_NAMESPACE,
			self::REST_ROUTE,
			array(
				'methods' =>
					WP_REST_Server::CREATABLE,

				'callback' =>
					array(
						__CLASS__,
						'handle_request',
					),

				/*
				 * Stripe authentication is performed using the signed
				 * Stripe-Signature header.
				 */
				'permission_callback' =>
					'__return_true',
			)
		);
	}

	/**
	 * Process one webhook request.
	 *
	 * @param WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public static function handle_request(
		WP_REST_Request $request
	) {
		$payload = $request->get_body();
		$signature = $request->get_header( 'stripe-signature' );
		$secret = TutorHelper_Pro_Payment_Settings::get_stripe_webhook_secret();

		if ( '' === $secret ) {
			TutorHelper_Logger::error(
				'Stripe webhook rejected because no signing secret is configured.'
			);

			return self::error_response(
				'webhook_not_configured',
				503,
				array(
					'outcome'        => 'rejected',
					'interpretation' => __( 'Stripe webhook signing is not configured.', 'tutorhelper-pro' ),
				)
			);
		}

		if ( ! self::verify_signature( $payload, $signature, $secret ) ) {
			TutorHelper_Logger::error(
				'Stripe webhook signature verification failed.'
			);

			return self::error_response(
				'invalid_signature',
				400,
				array(
					'outcome'        => 'rejected',
					'interpretation' => __( 'The Stripe webhook signature could not be verified.', 'tutorhelper-pro' ),
				)
			);
		}

		$event = json_decode( $payload, true );

		if (
			! is_array( $event )
			|| empty( $event['id'] )
			|| empty( $event['type'] )
		) {
			return self::error_response(
				'invalid_event',
				400,
				array(
					'outcome'        => 'rejected',
					'interpretation' => __( 'The verified Stripe request did not contain a usable event.', 'tutorhelper-pro' ),
				)
			);
		}

		$event_type = sanitize_text_field( $event['type'] );
		$log_context = self::get_event_log_context( $event, $event_type );

		/*
		 * Let authenticated Pro extensions claim their own Checkout events
		 * after signature verification but before booking-specific handling.
		 */
		$result = apply_filters(
			'tutorhelper_pro_stripe_webhook_extension_result',
			null,
			$event,
			$event_type
		);

		if ( null === $result ) {
			if (
				in_array(
					$event_type,
					array(
						'checkout.session.completed',
						'checkout.session.async_payment_succeeded',
					),
					true
				)
			) {
				$result = self::handle_checkout_completed( $event );
			} elseif ( 'checkout.session.async_payment_failed' === $event_type ) {
				$result = self::handle_checkout_async_payment_failed( $event );
			} elseif ( 'checkout.session.expired' === $event_type ) {
				$result = self::handle_checkout_expired( $event );
			} else {
				return self::success_response(
					false,
					$log_context,
					'ignored',
					__( 'The verified Stripe event is not used by TutorHelper.', 'tutorhelper-pro' )
				);
			}
		}

		if ( is_wp_error( $result ) ) {
			$error_data = $result->get_error_data();
			$status = is_array( $error_data ) && ! empty( $error_data['status'] )
				? absint( $error_data['status'] )
				: 500;

			TutorHelper_Logger::error(
				'Stripe webhook processing failed.',
				array(
					'event_id' => sanitize_text_field( $event['id'] ),
					'error'    => $result->get_error_message(),
				)
			);

			$log_context['outcome'] = 400 <= $status && 500 > $status
				? 'rejected'
				: 'failed';
			$log_context['interpretation'] = __( 'TutorHelper could not apply this Stripe payment event.', 'tutorhelper-pro' );
			$log_context['error'] = $result->get_error_message();

			return self::error_response(
				$result->get_error_code(),
				$status,
				$log_context
			);
		}

		$processing = self::normalise_processing_result( $result );

		return self::success_response(
			$processing['processed'],
			$log_context,
			$processing['outcome'],
			$processing['interpretation']
		);
	}

	/**
	 * Build the safe diagnostic context for one verified Stripe event.
	 *
	 * @param array  $event      Verified Stripe event.
	 * @param string $event_type Verified Stripe event type.
	 * @return array
	 */
	private static function get_event_log_context( $event, $event_type ) {
		$session = isset( $event['data']['object'] ) && is_array( $event['data']['object'] )
			? $event['data']['object']
			: array();
		$metadata = isset( $session['metadata'] ) && is_array( $session['metadata'] )
			? $session['metadata']
			: array();

		return array(
			'event_type' => sanitize_text_field( $event_type ),
			'event_id'   => isset( $event['id'] ) ? sanitize_text_field( $event['id'] ) : '',
			'booking_id' => isset( $metadata['booking_id'] ) ? absint( $metadata['booking_id'] ) : 0,
		);
	}

	/**
	 * Normalise an internal handler result for the webhook response and log.
	 *
	 * @param mixed $result Payment handler result.
	 * @return array
	 */
	private static function normalise_processing_result( $result ) {
		if ( is_array( $result ) && isset( $result['outcome'] ) ) {
			$outcome = sanitize_key( $result['outcome'] );
			$allowed = array( 'success', 'pending', 'ignored', 'duplicate' );

			if ( in_array( $outcome, $allowed, true ) ) {
				return array(
					'processed'      => 'pending' !== $outcome && 'ignored' !== $outcome,
					'outcome'        => $outcome,
					'interpretation' => isset( $result['interpretation'] )
						? sanitize_text_field( $result['interpretation'] )
						: __( 'Stripe event was acknowledged.', 'tutorhelper-pro' ),
				);
			}
		}

		return array(
			'processed'      => true,
			'outcome'        => 'success',
			'interpretation' => __( 'Stripe event was processed.', 'tutorhelper-pro' ),
		);
	}

	/**
	 * Return a logged successful webhook response.
	 *
	 * @param bool   $processed      Whether a booking or extension was processed.
	 * @param array  $log_context    Safe diagnostic context.
	 * @param string $outcome        Processing outcome.
	 * @param string $interpretation Human-readable explanation.
	 * @return WP_REST_Response
	 */
	private static function success_response( $processed, $log_context, $outcome, $interpretation ) {
		$log_context['outcome'] = sanitize_key( $outcome );
		$log_context['interpretation'] = sanitize_text_field( $interpretation );
		$log_context['http_status'] = 200;
		self::record_webhook_result( $log_context );

		return new WP_REST_Response(
			array(
				'received'  => true,
				'processed' => (bool) $processed,
			),
			200
		);
	}

	/**
	 * Record a Stripe webhook outcome without allowing diagnostics to interrupt
	 * payment processing.
	 *
	 * @param array $context Safe Stripe diagnostic context.
	 * @return void
	 */
	private static function record_webhook_result( $context ) {
		if (
			! class_exists( 'TutorHelper_Stripe_Log' )
			|| ! method_exists( 'TutorHelper_Stripe_Log', 'record' )
		) {
			return;
		}

		try {
			TutorHelper_Stripe_Log::record( $context );
		} catch ( Throwable $exception ) {
			/*
			 * A diagnostic failure must never alter Stripe's acknowledgement or
			 * the booking/finance processing outcome.
			 */
		}
	}


    /**
     * Verify the Stripe-Signature header.
     *
     * @param string $payload Raw request body.
     * @param string $header  Stripe-Signature header.
     * @param string $secret  Stripe webhook secret.
     *
     * @return bool
     */
    private static function verify_signature(
        $payload,
        $header,
        $secret
    ) {

        if (
            '' === (string) $payload
            || '' === (string) $header
            || '' === (string) $secret
        ) {
            return false;
        }

        $timestamp =
            0;

        $signatures =
            array();

        foreach (
            explode(
                ',',
                $header
            )
            as $part
        ) {

            $pair =
                explode(
                    '=',
                    trim( $part ),
                    2
                );

            if ( 2 !== count( $pair ) ) {
                continue;
            }

            if ( 't' === $pair[0] ) {
                $timestamp =
                    absint(
                        $pair[1]
                    );
            }

            if ( 'v1' === $pair[0] ) {
                $signatures[] =
                    trim(
                        $pair[1]
                    );
            }
        }

        if (
            ! $timestamp
            || empty( $signatures )
        ) {
            return false;
        }

        if (
            abs(
                time()
                - $timestamp
            )
            > self::SIGNATURE_TOLERANCE
        ) {
            return false;
        }

        $signed_payload =
            $timestamp
            . '.'
            . $payload;

        $expected =
            hash_hmac(
                'sha256',
                $signed_payload,
                $secret
            );

        foreach (
            $signatures
            as $signature
        ) {

            if (
                hash_equals(
                    $expected,
                    $signature
                )
            ) {
                return true;
            }
        }

        return false;
    }


    /**
     * Process a completed Stripe Checkout Session.
     *
     * @param array $event Stripe event.
     *
     * @return array|WP_Error
     */
    private static function handle_checkout_completed(
        $event
    ) {

        $session =
            isset(
                $event['data']['object']
            )
            && is_array(
                $event['data']['object']
            )
                ? $event['data']['object']
                : array();

        if ( empty( $session ) ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_session_missing',
                'Stripe Checkout Session data is missing.',
                400
            );
        }

        $event_id =
            sanitize_text_field(
                $event['id']
            );

        $session_id =
            ! empty(
                $session['id']
            )
                ? sanitize_text_field(
                    $session['id']
                )
                : '';

        $metadata =
            isset(
                $session['metadata']
            )
            && is_array(
                $session['metadata']
            )
                ? $session['metadata']
                : array();

        $booking_id =
            isset(
                $metadata['booking_id']
            )
                ? absint(
                    $metadata['booking_id']
                )
                : 0;

        if (
            ! $booking_id
            || '' === $session_id
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_booking_metadata_missing',
                'Stripe booking metadata is missing.',
                400
            );
        }

        if (
            isset(
                $session[
                    'client_reference_id'
                ]
            )
            && $booking_id
                !== absint(
                    $session[
                        'client_reference_id'
                    ]
                )
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_booking_reference_mismatch',
                'Stripe booking references do not match.',
                400
            );
        }

        $booking =
            TutorHelper_Booking_Records::
                get_by_id(
                    $booking_id
                );

        if ( ! $booking ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_booking_not_found',
                'The Stripe booking could not be found.',
                400
            );
        }

        if (
            TutorHelper_Booking_Records::
                PAYMENT_METHOD_STRIPE
            !== sanitize_key(
                $booking
                    ->payment_method
            )
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_payment_method_mismatch',
                'The booking is not awaiting a Stripe payment.',
                409
            );
        }

        if (
            TutorHelper_Pro_Payment_Settings::
                PROVIDER_STRIPE
            !== sanitize_key(
                $booking
                    ->payment_provider
            )
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_provider_mismatch',
                'The booking payment provider does not match Stripe.',
                409
            );
        }

        if (
            $session_id
            !== sanitize_text_field(
                $booking
                    ->payment_reference
            )
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_session_mismatch',
                'The Stripe Checkout Session does not match the booking.',
                409
            );
        }

        $stripe_payment_status =
            isset(
                $session[
                    'payment_status'
                ]
            )
                ? sanitize_key(
                    $session[
                        'payment_status'
                    ]
                )
                : '';

        if (
            'paid'
            !== $stripe_payment_status
        ) {
            return array(
                'outcome'        => 'pending',
                'interpretation' => __( 'Stripe Checkout is complete but payment is still pending.', 'tutorhelper-pro' ),
            );
        }

        $amount_total =
            isset(
                $session['amount_total']
            )
            && is_numeric(
                $session['amount_total']
            )
                ? intval(
                    $session['amount_total']
                )
                : -1;

        if (
            intval(
                $booking
                    ->price_minor_units
            )
            !== $amount_total
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_amount_mismatch',
                'The Stripe payment amount does not match the booking.',
                409
            );
        }

        $currency =
            isset(
                $session['currency']
            )
                ? strtoupper(
                    sanitize_text_field(
                        $session['currency']
                    )
                )
                : '';

        if (
            strtoupper(
                sanitize_text_field(
                    $booking->currency
                )
            )
            !== $currency
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_currency_mismatch',
                'The Stripe payment currency does not match the booking.',
                409
            );
        }

        if (
            isset(
                $metadata[
                    'student_user_id'
                ]
            )
            && absint(
                $metadata[
                    'student_user_id'
                ]
            )
            !== absint(
                $booking
                    ->student_user_id
            )
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_student_mismatch',
                'The Stripe student reference does not match the booking.',
                409
            );
        }

        if (
            isset(
                $metadata[
                    'tutor_user_id'
                ]
            )
            && absint(
                $metadata[
                    'tutor_user_id'
                ]
            )
            !== absint(
                $booking
                    ->tutor_user_id
            )
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_tutor_mismatch',
                'The Stripe tutor reference does not match the booking.',
                409
            );
        }

        $provider_reference =
            ! empty(
                $session[
                    'payment_intent'
                ]
            )
                ? sanitize_text_field(
                    $session[
                        'payment_intent'
                    ]
                )
                : $session_id;

        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PAID
            === sanitize_key( $booking->payment_status )
        ) {
            return array(
                'outcome'        => 'duplicate',
                'interpretation' => __( 'This Stripe payment was already applied to the booking.', 'tutorhelper-pro' ),
            );
        }

        $existing_reference =
            TutorHelper_Pro_Payment_Ledger::
                get_by_provider_reference(
                    TutorHelper_Pro_Payment_Settings::
                        PROVIDER_STRIPE,
                    $provider_reference,
                    $booking_id,
                    TutorHelper_Pro_Payment_Ledger::
                        TYPE_PAYMENT
                );

        $transaction_date =
            ! empty(
                $event['created']
            )
                ? gmdate(
                    'Y-m-d H:i:s',
                    absint(
                        $event[
                            'created'
                        ]
                    )
                )
                : current_time(
                    'mysql',
                    true
                );
        $ledger_result = $existing_reference
            ? absint( $existing_reference->id )
            : TutorHelper_Pro_Payment_Ledger::
                record(
                    array(
                        'booking_id' =>
                            $booking_id,

                        'student_user_id' =>
                            absint(
                                $booking
                                    ->student_user_id
                            ),

                        'tutor_user_id' =>
                            absint(
                                $booking
                                    ->tutor_user_id
                            ),

                        'transaction_type' =>
                            TutorHelper_Pro_Payment_Ledger::
                                TYPE_PAYMENT,

                        'amount_minor_units' =>
                            $amount_total,

                        'currency' =>
                            $currency,

                        'payment_method' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_METHOD_STRIPE,

                        'payment_provider' =>
                            TutorHelper_Pro_Payment_Settings::
                                PROVIDER_STRIPE,

                        'provider_reference' =>
                            $provider_reference,

                        'provider_event_id' =>
                            $event_id,

                        'description' =>
                            __(
                                'Stripe Checkout payment',
                                'tutorhelper-pro'
                            ),

                        'transaction_date' =>
                            $transaction_date,
                    )
                );

        if ( is_wp_error( $ledger_result ) ) {
                return $ledger_result;
            }

            $current_payment_status =
            sanitize_key(
                $booking
                    ->payment_status
            );

            $current_booking_status =
                sanitize_key(
                    $booking->status
                );

            $target_booking_status =
                TutorHelper_Booking_Records::
                    STATUS_CANCELLED
                === $current_booking_status
                    ? TutorHelper_Booking_Records::
                        STATUS_CANCELLED
                    : TutorHelper_Booking_Records::
                        STATUS_CONFIRMED;

        if (
            ! in_array(
                $current_payment_status,
                array(
                    TutorHelper_Booking_Records::
                        PAYMENT_STATUS_PENDING,

                    TutorHelper_Booking_Records::
                        PAYMENT_STATUS_PAID,
                ),
                true
            )
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_payment_state_conflict',
                'The booking payment state cannot be confirmed automatically.',
                409
            );
        }


        $update_result =
            TutorHelper_Booking_Records::
                update_payment_details(
                    $booking_id,
                    array(
                        'payment_status' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_STATUS_PAID,

                        'payment_method' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_METHOD_STRIPE,

                        'payment_provider' =>
                            TutorHelper_Pro_Payment_Settings::
                                PROVIDER_STRIPE,

                        /*
                        * Core stores the provider's generic booking
                        * reference. Pro understands that this value is
                        * a Stripe Checkout Session.
                        */
                        'payment_reference' =>
                            $session_id,

                        'booking_status' =>
	                        $target_booking_status,
                    ),
                    $current_payment_status
                );

        if ( is_wp_error( $update_result ) ) {
            return $update_result;
        }

        $updated_booking =
            TutorHelper_Booking_Records::
                get_by_id(
                    $booking_id
                );

        if ( ! $updated_booking ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_updated_booking_missing',
                'The updated booking could not be loaded after payment.',
                500
            );
        }

        do_action(
            'tutorhelper_pro_booking_payment_received',
            $booking_id,
            $updated_booking,
            $booking
        );

        $history_result =
            TutorHelper_Pro_Payment_History::
                record(
                    array(
                        'booking_id' =>
                            $booking_id,

                        'student_user_id' =>
                            absint(
                                $booking
                                    ->student_user_id
                            ),

                        'previous_payment_status' =>
                            $current_payment_status,

                        'new_payment_status' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_STATUS_PAID,

                        'previous_booking_status' =>
                            sanitize_key(
                                $booking->status
                            ),

                        'new_booking_status' =>
                            $target_booking_status,

                        'amount_minor_units' =>
                            $amount_total,

                        'currency' =>
                            $currency,

                        'payment_method' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_METHOD_STRIPE,

                        'payment_provider' =>
                            TutorHelper_Pro_Payment_Settings::
                                PROVIDER_STRIPE,

                        'provider_reference' =>
                            $session_id,

                        'provider_event_id' =>
                            $event_id,

                        'change_source' =>
                            TutorHelper_Pro_Payment_History::
                                SOURCE_PROVIDER_WEBHOOK,

                        'notes' =>
                            __(
                                'Payment confirmed by Stripe webhook.',
                                'tutorhelper-pro'
                            ),
                    )
                );

        if ( is_wp_error( $history_result ) ) {
            return $history_result;
        }

    

        TutorHelper_Logger::success(
            'Stripe booking payment confirmed.',
            array(
                'booking_id' =>
                    $booking_id,

                'stripe_event_id' =>
                    $event_id,

                'stripe_session_id' =>
                    $session_id,
            )
        );

        if (
            TutorHelper_Booking_Records::
                STATUS_CANCELLED
            === $current_booking_status
        ) {
            TutorHelper_Logger::error(
                'Stripe payment received for a cancelled booking. Manual review is required.',
                array(
                    'booking_id' =>
                        $booking_id,

                    'stripe_event_id' =>
                        $event_id,

                    'stripe_session_id' =>
                        $session_id,
                )
            );
        }

        return array(
            'outcome'        => 'success',
            'interpretation' => __( 'Stripe confirmed the Checkout payment and the booking was updated.', 'tutorhelper-pro' ),
        );
    }


    /**
     * Handle a delayed Checkout payment that Stripe has explicitly failed.
     *
     * @param array $event Stripe event.
     * @return array|WP_Error
     */
    private static function handle_checkout_async_payment_failed(
        $event
    ) {
        return self::handle_checkout_expired(
            $event,
            TutorHelper_Booking_Records::PAYMENT_STATUS_FAILED,
            __( 'Stripe confirmed that the delayed Checkout payment failed.', 'tutorhelper-pro' )
        );
    }

    /**
     * Release a booking when Stripe Checkout expires.
     *
     * @param array $event Stripe event.
     *
     * @return array|WP_Error
     */
    private static function handle_checkout_expired(
        $event,
        $payment_status = TutorHelper_Booking_Records::PAYMENT_STATUS_EXPIRED,
        $history_note = ''
    ) {
        $payment_status = sanitize_key( $payment_status );
        if ( ! in_array( $payment_status, array( TutorHelper_Booking_Records::PAYMENT_STATUS_EXPIRED, TutorHelper_Booking_Records::PAYMENT_STATUS_FAILED ), true ) ) {
            $payment_status = TutorHelper_Booking_Records::PAYMENT_STATUS_EXPIRED;
        }
        if ( '' === $history_note ) {
            $history_note = __( 'Stripe Checkout Session expired before payment.', 'tutorhelper-pro' );
        }

        $session =
            isset(
                $event['data']['object']
            )
            && is_array(
                $event['data']['object']
            )
                ? $event['data']['object']
                : array();

        $metadata =
            isset(
                $session['metadata']
            )
            && is_array(
                $session['metadata']
            )
                ? $session['metadata']
                : array();

        $booking_id =
            isset(
                $metadata['booking_id']
            )
                ? absint(
                    $metadata[
                        'booking_id'
                    ]
                )
                : 0;

        $session_id =
            ! empty(
                $session['id']
            )
                ? sanitize_text_field(
                    $session['id']
                )
                : '';

        if (
            ! $booking_id
            || '' === $session_id
        ) {
            return self::payment_error(
                'tutorhelper_pro_stripe_expired_metadata_missing',
                'Expired Stripe Checkout metadata is missing.',
                400
            );
        }

        $booking =
            TutorHelper_Booking_Records::
                get_by_id(
                    $booking_id
                );

        if ( ! $booking ) {
            return array(
                'outcome'        => 'ignored',
                'interpretation' => __( 'The related booking no longer exists.', 'tutorhelper-pro' ),
            );
        }

        /*
        * Ignore an expiry from an older Session if a newer Session
        * has since become authoritative for this booking.
        */
        if (
            $session_id
            !== sanitize_text_field(
                $booking
                    ->payment_reference
            )
        ) {
            return array(
                'outcome'        => 'ignored',
                'interpretation' => __( 'The Stripe event belongs to an older Checkout Session.', 'tutorhelper-pro' ),
            );
        }

        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PAID
            === sanitize_key(
                $booking
                    ->payment_status
            )
        ) {
            return array(
                'outcome'        => 'duplicate',
                'interpretation' => __( 'The booking is already paid, so this unsuccessful Stripe event was ignored.', 'tutorhelper-pro' ),
            );
        }

        if (
            $payment_status
            === sanitize_key(
                $booking
                    ->payment_status
            )
            && TutorHelper_Booking_Records::
                STATUS_CANCELLED
            === sanitize_key(
                $booking->status
            )
        ) {
            return array(
                'outcome'        => 'duplicate',
                'interpretation' => __( 'This unsuccessful Stripe event was already applied.', 'tutorhelper-pro' ),
            );
        }

        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PENDING
            !== sanitize_key(
                $booking
                    ->payment_status
            )
        ) {
            return array(
                'outcome'        => 'ignored',
                'interpretation' => __( 'The booking is no longer awaiting this Stripe payment.', 'tutorhelper-pro' ),
            );
        }

        $previous_status =
            sanitize_key(
                $booking->status
            );

        $update =
            TutorHelper_Booking_Records::
                update_payment_details(
                    $booking_id,
                    array(
                        'payment_status' =>
                            $payment_status,

                        'payment_method' =>
                            TutorHelper_Booking_Records::
                                PAYMENT_METHOD_STRIPE,

                        'payment_provider' =>
                            TutorHelper_Pro_Payment_Settings::
                                PROVIDER_STRIPE,

                        'payment_reference' =>
                            $session_id,

                        'booking_status' =>
                            TutorHelper_Booking_Records::
                                STATUS_CANCELLED,
                    ),
                    TutorHelper_Booking_Records::
                        PAYMENT_STATUS_PENDING
                );

        if ( is_wp_error( $update ) ) {
            return $update;
        }

        TutorHelper_Pro_Payment_History::
            record(
                array(
                    'booking_id' =>
                        $booking_id,

                    'student_user_id' =>
                        absint(
                            $booking
                                ->student_user_id
                        ),

                    'previous_payment_status' =>
                        TutorHelper_Booking_Records::
                            PAYMENT_STATUS_PENDING,

                    'new_payment_status' =>
                        $payment_status,

                    'previous_booking_status' =>
                        $previous_status,

                    'new_booking_status' =>
                        TutorHelper_Booking_Records::
                            STATUS_CANCELLED,

                    'amount_minor_units' =>
                        absint(
                            $booking
                                ->price_minor_units
                        ),

                    'currency' =>
                        strtoupper(
                            sanitize_text_field(
                                $booking
                                    ->currency
                            )
                        ),

                    'payment_method' =>
                        TutorHelper_Booking_Records::
                            PAYMENT_METHOD_STRIPE,

                    'payment_provider' =>
                        TutorHelper_Pro_Payment_Settings::
                            PROVIDER_STRIPE,

                    'provider_reference' =>
                        $session_id,

                    'provider_event_id' =>
                        sanitize_text_field(
                            $event['id']
                        ),

                    'change_source' =>
                        TutorHelper_Pro_Payment_History::
                            SOURCE_PROVIDER_WEBHOOK,

                    'notes' => $history_note,
                )
            );

        TutorHelper_Logger::success(
            'Expired Stripe Checkout booking released.',
            array(
                'booking_id' =>
                    $booking_id,

                'stripe_session_id' =>
                    $session_id,
            )
        );

        return array(
            'outcome'        => 'success',
            'interpretation' => $payment_status === TutorHelper_Booking_Records::PAYMENT_STATUS_FAILED
                ? __( 'Stripe confirmed that the delayed Checkout payment failed.', 'tutorhelper-pro' )
                : __( 'Expired Stripe Checkout Session released the booking.', 'tutorhelper-pro' ),
        );
    }


    /**
     * Create an internal webhook processing error.
     *
     * @param string $code    Error code.
     * @param string $message Error message.
     * @param int    $status  HTTP status.
     *
     * @return WP_Error
     */
    private static function payment_error(
        $code,
        $message,
        $status
    ) {

        return new WP_Error(
            sanitize_key(
                $code
            ),
            $message,
            array(
                'status' =>
                    absint(
                        $status
                    ),
            )
        );
    }

    /**
     * Create a minimal public webhook error response.
     *
     * @param string $code   Error code.
     * @param int    $status      HTTP status.
     * @param array  $log_context Safe Stripe diagnostic context.
     *
     * @return WP_REST_Response
     */
    private static function error_response(
        $code,
        $status,
        $log_context = array()
    ) {
        $status = absint( $status );
        $log_context = is_array( $log_context ) ? $log_context : array();
        $log_context['http_status'] = $status;
        $log_context['outcome'] = isset( $log_context['outcome'] )
            ? sanitize_key( $log_context['outcome'] )
            : ( 400 <= $status && 500 > $status ? 'rejected' : 'failed' );
        $log_context['interpretation'] = isset( $log_context['interpretation'] )
            ? sanitize_text_field( $log_context['interpretation'] )
            : __( 'TutorHelper could not acknowledge the Stripe webhook.', 'tutorhelper-pro' );
        self::record_webhook_result( $log_context );

        return new WP_REST_Response(
            array(
                'received' => false,
                'code'     => sanitize_key( $code ),
            ),
            $status
        );
    }
}
