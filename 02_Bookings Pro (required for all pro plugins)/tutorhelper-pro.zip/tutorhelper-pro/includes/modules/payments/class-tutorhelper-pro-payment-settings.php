<?php
/**
 * Payment provider configuration for TutorHelper Pro.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides payment-provider configuration and availability information.
 */
final class TutorHelper_Pro_Payment_Settings {

	/**
	 * Stripe provider key.
	 *
	 * @var string
	 */
	const PROVIDER_STRIPE = 'stripe';

	/**
	 * PayPal provider key.
	 *
	 * @var string
	 */
	const PROVIDER_PAYPAL = 'paypal';

	/**
	 * GoCardless provider key.
	 *
	 * @var string
	 */
	const PROVIDER_GOCARDLESS = 'gocardless';

	/**
	 * Manual invoice / bank transfer provider key.
	 *
	 * @var string
	 */
	const PROVIDER_MANUAL = 'manual';

	/**
	 * Provider is currently available.
	 *
	 * @var string
	 */
	const STATUS_AVAILABLE = 'available';

	/**
	 * Provider is planned but not yet available.
	 *
	 * @var string
	 */
	const STATUS_COMING_SOON = 'coming_soon';

	/**
	 * Return all payment providers known to TutorHelper Pro.
	 *
	 * @return array
	 */

    /**
     * Stripe mode option.
     *
     * @var string
     */
    const OPTION_STRIPE_MODE =
        'tutorhelper_pro_stripe_mode';

    /**
     * Stripe test secret key option.
     *
     * @var string
     */
    const OPTION_STRIPE_TEST_SECRET =
        'tutorhelper_pro_stripe_test_secret';

    /**
     * Stripe test webhook secret option.
     *
     * @var string
     */
    const OPTION_STRIPE_TEST_WEBHOOK_SECRET =
        'tutorhelper_pro_stripe_test_webhook_secret';

    /**
     * Stripe live secret key option.
     *
     * @var string
     */
    const OPTION_STRIPE_LIVE_SECRET =
        'tutorhelper_pro_stripe_live_secret';

    /**
     * Stripe live webhook secret option.
     *
     * @var string
     */
    const OPTION_STRIPE_LIVE_WEBHOOK_SECRET =
        'tutorhelper_pro_stripe_live_webhook_secret';

    /**
     * Test mode.
     *
     * @var string
     */
    const MODE_TEST = 'test';

    /**
     * Live mode.
     *
     * @var string
     */
    const MODE_LIVE = 'live';


	public static function get_providers() {
		return array(
			self::PROVIDER_STRIPE => array(
				'key'         => self::PROVIDER_STRIPE,
				'name'        => __(
					'Stripe',
					'tutorhelper-pro'
				),
				'description' => __(
					'Accept online card payments securely using Stripe Checkout.',
					'tutorhelper-pro'
				),
				'status'      => self::STATUS_AVAILABLE,
			),

			self::PROVIDER_PAYPAL => array(
				'key'         => self::PROVIDER_PAYPAL,
				'name'        => __(
					'PayPal',
					'tutorhelper-pro'
				),
				'description' => __(
					'Accept online payments using PayPal.',
					'tutorhelper-pro'
				),
				'status'      => self::STATUS_COMING_SOON,
			),

			self::PROVIDER_GOCARDLESS => array(
				'key'         => self::PROVIDER_GOCARDLESS,
				'name'        => __(
					'GoCardless',
					'tutorhelper-pro'
				),
				'description' => __(
					'Collect payments using bank debit through GoCardless.',
					'tutorhelper-pro'
				),
				'status'      => self::STATUS_COMING_SOON,
			),

			self::PROVIDER_MANUAL => array(
				'key'         => self::PROVIDER_MANUAL,
				'name'        => __(
					'Invoice / bank transfer',
					'tutorhelper-pro'
				),
				'description' => __(
					'Record payments made by invoice or bank transfer.',
					'tutorhelper-pro'
				),
				'status'      => self::STATUS_COMING_SOON,
			),
		);
	}

	/**
	 * Return one provider definition.
	 *
	 * @param string $provider Provider key.
	 *
	 * @return array|null
	 */
	public static function get_provider(
		$provider
	) {
		$provider = sanitize_key(
			$provider
		);

		$providers = self::get_providers();

		return isset( $providers[ $provider ] )
			? $providers[ $provider ]
			: null;
	}

	/**
	 * Check whether a provider exists.
	 *
	 * @param string $provider Provider key.
	 *
	 * @return bool
	 */
	public static function is_known_provider(
		$provider
	) {
		return null !== self::get_provider(
			$provider
		);
	}

	/**
	 * Check whether a provider is currently available.
	 *
	 * @param string $provider Provider key.
	 *
	 * @return bool
	 */
	public static function is_available(
		$provider
	) {
		$provider_data =
			self::get_provider(
				$provider
			);

		if ( ! $provider_data ) {
			return false;
		}

		return self::STATUS_AVAILABLE
			=== $provider_data['status'];
	}

	/**
	 * Return only providers which can currently be used.
	 *
	 * @return array
	 */
	public static function get_available_providers() {
		return array_filter(
			self::get_providers(),
			static function ( $provider ) {
				return isset(
					$provider['status']
				)
					&& self::STATUS_AVAILABLE
					=== $provider['status'];
			}
		);
	}

    /**
     * Return the configured Stripe mode.
     *
     * @return string
     */
    public static function get_stripe_mode() {

        $mode = sanitize_key(
            get_option(
                self::OPTION_STRIPE_MODE,
                self::MODE_TEST
            )
        );

        return in_array(
            $mode,
            array(
                self::MODE_TEST,
                self::MODE_LIVE,
            ),
            true
        )
            ? $mode
            : self::MODE_TEST;
    }

    /**
     * Check whether Stripe is using live mode.
     *
     * @return bool
     */
    public static function is_live_mode() {
        return self::MODE_LIVE
            === self::get_stripe_mode();
    }


    /**
     * Return the active Stripe secret key.
     *
     * wp-config.php constants take priority over database values.
     *
     * @return string
     */
    public static function get_stripe_secret_key() {

        if ( self::is_live_mode() ) {

            if (
                defined(
                    'TUTORHELPER_PRO_STRIPE_LIVE_SECRET_KEY'
                )
            ) {
                return (string)
                    TUTORHELPER_PRO_STRIPE_LIVE_SECRET_KEY;
            }

            return (string) get_option(
                self::OPTION_STRIPE_LIVE_SECRET,
                ''
            );
        }

        if (
            defined(
                'TUTORHELPER_PRO_STRIPE_TEST_SECRET_KEY'
            )
        ) {
            return (string)
                TUTORHELPER_PRO_STRIPE_TEST_SECRET_KEY;
        }

        return (string) get_option(
            self::OPTION_STRIPE_TEST_SECRET,
            ''
        );
    }


    /**
     * Return the active Stripe webhook signing secret.
     *
     * @return string
     */
    public static function get_stripe_webhook_secret() {

        if ( self::is_live_mode() ) {

            if (
                defined(
                    'TUTORHELPER_PRO_STRIPE_LIVE_WEBHOOK_SECRET'
                )
            ) {
                return (string)
                    TUTORHELPER_PRO_STRIPE_LIVE_WEBHOOK_SECRET;
            }

            return (string) get_option(
                self::OPTION_STRIPE_LIVE_WEBHOOK_SECRET,
                ''
            );
        }

        if (
            defined(
                'TUTORHELPER_PRO_STRIPE_TEST_WEBHOOK_SECRET'
            )
        ) {
            return (string)
                TUTORHELPER_PRO_STRIPE_TEST_WEBHOOK_SECRET;
        }

        return (string) get_option(
            self::OPTION_STRIPE_TEST_WEBHOOK_SECRET,
            ''
        );
    }

    /**
     * Check whether a stored or constant Stripe credential exists.
     *
     * @param string $type Credential type.
     * @param string $mode Stripe mode.
     *
     * @return bool
     */
    public static function has_credential(
        $type,
        $mode
    ) {

        $value = self::get_credential(
            $type,
            $mode
        );

        return '' !== $value;
    }

    /**
     * Return one Stripe credential.
     *
     * @param string $type Credential type.
     * @param string $mode Stripe mode.
     *
     * @return string
     */
    public static function get_credential(
        $type,
        $mode
    ) {

        $mode = self::MODE_LIVE === $mode
            ? self::MODE_LIVE
            : self::MODE_TEST;

        if ( 'secret_key' === $type ) {

            if (
                self::MODE_LIVE === $mode
                && defined(
                    'TUTORHELPER_PRO_STRIPE_LIVE_SECRET_KEY'
                )
            ) {
                return (string)
                    TUTORHELPER_PRO_STRIPE_LIVE_SECRET_KEY;
            }

            if (
                self::MODE_TEST === $mode
                && defined(
                    'TUTORHELPER_PRO_STRIPE_TEST_SECRET_KEY'
                )
            ) {
                return (string)
                    TUTORHELPER_PRO_STRIPE_TEST_SECRET_KEY;
            }

            return (string) get_option(
                self::MODE_LIVE === $mode
                    ? self::OPTION_STRIPE_LIVE_SECRET
                    : self::OPTION_STRIPE_TEST_SECRET,
                ''
            );
        }

        if ( 'webhook_secret' === $type ) {

            if (
                self::MODE_LIVE === $mode
                && defined(
                    'TUTORHELPER_PRO_STRIPE_LIVE_WEBHOOK_SECRET'
                )
            ) {
                return (string)
                    TUTORHELPER_PRO_STRIPE_LIVE_WEBHOOK_SECRET;
            }

            if (
                self::MODE_TEST === $mode
                && defined(
                    'TUTORHELPER_PRO_STRIPE_TEST_WEBHOOK_SECRET'
                )
            ) {
                return (string)
                    TUTORHELPER_PRO_STRIPE_TEST_WEBHOOK_SECRET;
            }

            return (string) get_option(
                self::MODE_LIVE === $mode
                    ? self::OPTION_STRIPE_LIVE_WEBHOOK_SECRET
                    : self::OPTION_STRIPE_TEST_WEBHOOK_SECRET,
                ''
            );
        }

        return '';
    }

    /**
     * Return a masked credential label.
     *
     * Never return the complete credential for display.
     *
     * @param string $type Credential type.
     * @param string $mode Stripe mode.
     *
     * @return string
     */
    public static function get_masked_credential(
        $type,
        $mode
    ) {

        $value = self::get_credential(
            $type,
            $mode
        );

        if ( '' === $value ) {
            return '';
        }

        $length = strlen( $value );

        if ( $length <= 4 ) {
            return '••••';
        }

        return '••••••••'
            . substr(
                $value,
                -4
            );
    }

    /**
     * Save Stripe configuration.
     *
     * Blank credential fields preserve existing stored values.
     *
     * @param array $input Submitted form values.
     *
     * @return true
     */
    public static function save(
        $input
    ) {

        $input = is_array( $input )
            ? $input
            : array();

        $mode = isset(
            $input['stripe_mode']
        )
            ? sanitize_key(
                wp_unslash(
                    $input['stripe_mode']
                )
            )
            : self::MODE_TEST;

        if (
            ! in_array(
                $mode,
                array(
                    self::MODE_TEST,
                    self::MODE_LIVE,
                ),
                true
            )
        ) {
            $mode = self::MODE_TEST;
        }

        update_option(
            self::OPTION_STRIPE_MODE,
            $mode
        );

        self::save_credential(
            self::OPTION_STRIPE_TEST_SECRET,
            'stripe_test_secret',
            $input,
            'TUTORHELPER_PRO_STRIPE_TEST_SECRET_KEY'
        );

        self::save_credential(
            self::OPTION_STRIPE_TEST_WEBHOOK_SECRET,
            'stripe_test_webhook_secret',
            $input,
            'TUTORHELPER_PRO_STRIPE_TEST_WEBHOOK_SECRET'
        );

        self::save_credential(
            self::OPTION_STRIPE_LIVE_SECRET,
            'stripe_live_secret',
            $input,
            'TUTORHELPER_PRO_STRIPE_LIVE_SECRET_KEY'
        );

        self::save_credential(
            self::OPTION_STRIPE_LIVE_WEBHOOK_SECRET,
            'stripe_live_webhook_secret',
            $input,
            'TUTORHELPER_PRO_STRIPE_LIVE_WEBHOOK_SECRET'
        );

        return true;
    }


    /**
     * Save one Stripe credential.
     *
     * @param string $option_name  WordPress option.
     * @param string $field_name   Submitted form field.
     * @param array  $input        Submitted values.
     * @param string $constant     wp-config constant.
     *
     * @return void
     */
    private static function save_credential(
        $option_name,
        $field_name,
        $input,
        $constant
    ) {

        /*
        * A wp-config.php value takes precedence and must not
        * be overwritten through WordPress Admin.
        */
        if ( defined( $constant ) ) {
            return;
        }

        $remove_field =
            $field_name . '_remove';

        if (
            ! empty(
                $input[ $remove_field ]
            )
        ) {
            delete_option(
                $option_name
            );

            return;
        }

        if (
            empty(
                $input[ $field_name ]
            )
        ) {
            return;
        }

        $value = sanitize_text_field(
            wp_unslash(
                $input[ $field_name ]
            )
        );

        if ( '' === $value ) {
            return;
        }

        /*
        * Ensure secrets are not autoloaded on every WordPress request.
        */
        if (
            false
            === get_option(
                $option_name,
                false
            )
        ) {
            add_option(
                $option_name,
                $value,
                '',
                false
            );

            return;
        }

        update_option(
            $option_name,
            $value,
            false
        );
    }


    /**
     * Check whether the active Stripe mode is configured.
     *
     * @return bool
     */
    public static function stripe_is_configured() {
        return ''
            !== self::get_stripe_secret_key()
            && ''
            !== self::get_stripe_webhook_secret();
    }

    /**
     * Return the Stripe webhook endpoint URL.
     *
     * @return string
     */
    public static function get_stripe_webhook_url() {
        return rest_url(
            'tutorhelper-pro/v1/stripe/webhook'
        );
    }


}
