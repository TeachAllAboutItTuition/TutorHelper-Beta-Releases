<?php
/**
 * Tutor notification for paid student bookings.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and sends the paid-booking tutor notification.
 */
final class TutorHelper_Pro_Paid_Booking_Email {

	/**
	 * Email template key.
	 *
	 * @var string
	 */
	const TEMPLATE_KEY =
		'booking_paid_confirmed_tutor';


    /**
     * Initialise paid-booking email handling.
     *
     * @return void
     */
    public static function init() {

        self::register_template();

        add_action(
            'tutorhelper_pro_booking_payment_received',
            array(
                __CLASS__,
                'handle_payment_received',
            ),
            10,
            3
        );
    }


    /**
     * Notify the tutor after a successful payment transition.
     *
     * @param int    $booking_id Booking ID.
     * @param object $updated    Updated booking.
     * @param object $existing   Booking before payment.
     *
     * @return void
     */
    public static function handle_payment_received(
        $booking_id,
        $updated,
        $existing
    ) {

        if (
            ! is_object( $updated )
            || ! is_object( $existing )
        ) {
            return;
        }

        $previous_payment_status =
            isset(
                $existing->payment_status
            )
                ? sanitize_key(
                    $existing->payment_status
                )
                : '';

        $new_payment_status =
            isset(
                $updated->payment_status
            )
                ? sanitize_key(
                    $updated->payment_status
                )
                : '';

        $new_booking_status =
            isset(
                $updated->status
            )
                ? sanitize_key(
                    $updated->status
                )
                : '';

        if (
            TutorHelper_Booking_Records::
                PAYMENT_STATUS_PENDING
            !== $previous_payment_status
            || TutorHelper_Booking_Records::
                PAYMENT_STATUS_PAID
            !== $new_payment_status
            || TutorHelper_Booking_Records::
                STATUS_CONFIRMED
            !== $new_booking_status
        ) {
            return;
        }

        /**
         * Filters whether the individual paid-booking tutor email should
         * be sent. Combined payment workflows use this to replace several
         * per-lesson messages with one payment summary.
         *
         * @param bool   $send       Whether to send the individual email.
         * @param int    $booking_id Booking ID.
         * @param object $updated    Booking after payment.
         * @param object $existing   Booking before payment.
         */
        $send_email =
            (bool) apply_filters(
                'tutorhelper_pro_send_paid_booking_email',
                true,
                absint( $booking_id ),
                $updated,
                $existing
            );

        if ( ! $send_email ) {
            return;
        }

        $result =
            self::send(
                $booking_id
            );

        if (
            is_wp_error(
                $result
            )
            && class_exists(
                'TutorHelper_Logger'
            )
        ) {
            TutorHelper_Logger::warning(
                'Paid booking tutor notification could not be sent.',
                array(
                    'booking_id' =>
                        absint(
                            $booking_id
                        ),

                    'error_code' =>
                        $result->
                            get_error_code(),
                )
            );
        }
    }


	/**
	 * Register the email template.
	 *
	 * @return void
	 */
	public static function register_template() {

		TutorHelper_Email_Templates::register(
			self::TEMPLATE_KEY,
			array(
				'module' =>
					'bookings',

				'label' =>
					__(
						'Paid booking confirmed — Tutor',
						'tutorhelper-pro'
					),

				'description' =>
					__(
						'Sent to the tutor when payment is received for a student booking and the lesson is confirmed automatically.',
						'tutorhelper-pro'
					),

				'heading' =>
					__(
						'New Paid Booking',
						'tutorhelper-pro'
					),

				'recipient' =>
					'tutor',

				'enabled' =>
					true,

				'subject' =>
					__(
						'New paid booking from {student_name}',
						'tutorhelper-pro'
					),

				'body' =>
					__(
						"Hello {tutor_name},\n\nPayment has been received for a new lesson booking from {student_name}.\n\nLesson: {booking_type}\nDate: {lesson_date}\nTime: {lesson_time}\nLocation: {location_type}\nAmount paid: {payment_amount}\nPayment method: {payment_method}\n\nThe lesson has been confirmed automatically.\n\nYou can view the booking in TutorHelper here:\n{calendar_url}\n\nBest wishes,\nTutorHelper",
						'tutorhelper-pro'
					),

				'placeholders' =>
					array(
						'{student_name}',
						'{student_email}',
						'{booking_type}',
						'{lesson_date}',
						'{lesson_time}',
						'{location_type}',
						'{tutor_name}',
						'{site_name}',
						'{calendar_url}',
						'{payment_amount}',
						'{payment_method}',
					),
			)
		);
	}


    	/**
	 * Send the paid-booking notification to the tutor.
	 *
	 * @param int $booking_id Booking ID.
	 *
	 * @return true|WP_Error
	 */
	public static function send(
		$booking_id
	) {

		$booking_id =
			absint(
				$booking_id
			);

		if ( ! $booking_id ) {
			return new WP_Error(
				'tutorhelper_pro_paid_booking_email_invalid_booking',
				__(
					'The paid booking email could not be prepared.',
					'tutorhelper-pro'
				)
			);
		}

		if (
			! TutorHelper_Email_Templates::
				is_enabled(
					self::TEMPLATE_KEY
				)
		) {
			return true;
		}

		$context =
			TutorHelper_Booking_Email_Context::
				build(
					$booking_id
				);

		if ( is_wp_error( $context ) ) {
			return $context;
		}

		$booking =
			isset(
				$context['booking']
			)
			&& is_object(
				$context['booking']
			)
				? $context['booking']
				: null;

		if ( ! $booking ) {
			return new WP_Error(
				'tutorhelper_pro_paid_booking_email_booking_missing',
				__(
					'The paid booking could not be prepared for email.',
					'tutorhelper-pro'
				)
			);
		}

		$placeholders =
			$context[
				'placeholders'
			];

		$placeholders[
			'{payment_amount}'
		] =
			self::get_payment_amount(
				$booking
			);

		$placeholders[
			'{payment_method}'
		] =
			self::get_payment_method_label(
				$booking
			);

		$result =
			TutorHelper_Email_Sender::send(
				self::TEMPLATE_KEY,
				$context[
					'tutor_email'
				],
				$placeholders,
				array(
					'related_object_type' =>
						'booking',

					'related_object_id' =>
						$booking_id,

					'recipient_type' =>
						'tutor',
				)
			);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}


    /**
	 * Return the formatted amount paid.
	 *
	 * @param object $booking Booking record.
	 *
	 * @return string
	 */
	private static function get_payment_amount(
		$booking
	) {

		$currency =
			! empty(
				$booking->currency
			)
				? strtoupper(
					sanitize_text_field(
						$booking->currency
					)
				)
				: TutorHelper_Currency::
					get_currency();

		return TutorHelper_Currency::
			format_minor_units(
				absint(
					$booking->
						price_minor_units
				),
				$currency
			);
	}


    /**
	 * Return the tutor-facing payment method label.
	 *
	 * @param object $booking Booking record.
	 *
	 * @return string
	 */
	private static function get_payment_method_label(
		$booking
	) {

		$payment_method =
			isset(
				$booking->payment_method
			)
				? sanitize_key(
					$booking->payment_method
				)
				: '';

		if (
			TutorHelper_Booking_Records::
				PAYMENT_METHOD_STRIPE
			=== $payment_method
		) {
			return __(
				'Card',
				'tutorhelper-pro'
			);
		}

		if (
			TutorHelper_Booking_Records::
				PAYMENT_METHOD_MANUAL
			=== $payment_method
		) {
			return __(
				'Invoice / bank transfer',
				'tutorhelper-pro'
			);
		}

		return ucwords(
			str_replace(
				'_',
				' ',
				$payment_method
			)
		);
	}
}
