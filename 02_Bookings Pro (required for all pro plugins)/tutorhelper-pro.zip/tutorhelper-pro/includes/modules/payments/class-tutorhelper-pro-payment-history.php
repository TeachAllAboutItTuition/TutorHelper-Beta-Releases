<?php
/**
 * Payment status history for TutorHelper Pro.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records an audit trail of booking payment status changes.
 */
final class TutorHelper_Pro_Payment_History {

	const SOURCE_ADMIN            = 'admin';
	const SOURCE_PROVIDER_WEBHOOK = 'provider_webhook';
	const SOURCE_STUDENT_CHECKOUT = 'student_checkout';
	const SOURCE_REFUND           = 'refund';
	const SOURCE_CREDIT           = 'credit';
	const SOURCE_SYSTEM           = 'system';

	/**
	 * Return supported payment change sources.
	 *
	 * @return array
	 */
	public static function get_change_sources() {
		return array(
			self::SOURCE_ADMIN,
			self::SOURCE_PROVIDER_WEBHOOK,
			self::SOURCE_STUDENT_CHECKOUT,
			self::SOURCE_REFUND,
			self::SOURCE_CREDIT,
			self::SOURCE_SYSTEM,
		);
	}

	/**
	 * Record a booking payment status change.
	 *
	 * This class records history only. It does not modify
	 * the Core booking record.
	 *
	 * @param array $change Status change data.
	 *
	 * @return int|WP_Error
	 */
	public static function record(
		$change
	) {
		global $wpdb;

		if ( ! is_array( $change ) ) {
			return new WP_Error(
				'tutorhelper_pro_payment_history_invalid',
				__(
					'The payment history data was invalid.',
					'tutorhelper-pro'
				)
			);
		}

		$booking_id = isset(
			$change['booking_id']
		)
			? absint(
				$change['booking_id']
			)
			: 0;

		$student_user_id = isset(
			$change['student_user_id']
		)
			? absint(
				$change['student_user_id']
			)
			: 0;

		if ( ! $booking_id ) {
			return new WP_Error(
				'tutorhelper_pro_payment_history_missing_booking',
				__(
					'A booking is required for payment history.',
					'tutorhelper-pro'
				)
			);
		}

		if ( ! $student_user_id ) {
			return new WP_Error(
				'tutorhelper_pro_payment_history_missing_student',
				__(
					'A student is required for payment history.',
					'tutorhelper-pro'
				)
			);
		}

		$new_payment_status = isset(
			$change['new_payment_status']
		)
			? sanitize_key(
				$change['new_payment_status']
			)
			: '';

		if ( '' === $new_payment_status ) {
			return new WP_Error(
				'tutorhelper_pro_payment_history_missing_status',
				__(
					'A new payment status is required.',
					'tutorhelper-pro'
				)
			);
		}

		$change_source = isset(
			$change['change_source']
		)
			? sanitize_key(
				$change['change_source']
			)
			: self::SOURCE_SYSTEM;

		if (
			! in_array(
				$change_source,
				self::get_change_sources(),
				true
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_payment_history_invalid_source',
				__(
					'The payment change source was invalid.',
					'tutorhelper-pro'
				)
			);
		}

		$currency = isset(
			$change['currency']
		)
			? strtoupper(
				sanitize_text_field(
					$change['currency']
				)
			)
			: '';

		if (
			class_exists(
				'TutorHelper_Currency'
			)
		) {
			$currencies =
				TutorHelper_Currency::
					get_supported_currencies();

			if (
				! isset(
					$currencies[ $currency ]
				)
			) {
				return new WP_Error(
					'tutorhelper_pro_payment_history_invalid_currency',
					__(
						'The payment currency was invalid.',
						'tutorhelper-pro'
					)
				);
			}
		}

		$payment_provider =
			isset(
				$change[
					'payment_provider'
				]
			)
				? sanitize_key(
					$change[
						'payment_provider'
					]
				)
				: '';

		$provider_event_id =
			! empty(
				$change[
					'provider_event_id'
				]
			)
				? sanitize_text_field(
					$change[
						'provider_event_id'
					]
				)
				: '';

		if (
			''
			!== $payment_provider
			&& ''
			!== $provider_event_id
		) {

			$existing =
				self::get_by_provider_event(
					$payment_provider,
					$provider_event_id
				);

			if ( $existing ) {
				return absint(
					$existing->id
				);
			}
		}

		$data = array(
			'booking_id' =>
				$booking_id,

			'student_user_id' =>
				$student_user_id,

			'previous_payment_status' => isset(
				$change['previous_payment_status']
			)
				? sanitize_key(
					$change[
						'previous_payment_status'
					]
				)
				: '',

			'new_payment_status' =>
				$new_payment_status,

			'previous_booking_status' => isset(
				$change['previous_booking_status']
			)
				? sanitize_key(
					$change[
						'previous_booking_status'
					]
				)
				: '',

			'new_booking_status' => isset(
				$change['new_booking_status']
			)
				? sanitize_key(
					$change[
						'new_booking_status'
					]
				)
				: '',

			'amount_minor_units' => isset(
				$change['amount_minor_units']
			)
				? intval(
					$change['amount_minor_units']
				)
				: 0,

			'currency' =>
				$currency,

			'payment_method' => isset(
				$change['payment_method']
			)
				? sanitize_key(
					$change['payment_method']
				)
				: '',

			'payment_provider' =>
				$payment_provider,

			'provider_event_id' =>
				''
				!== $provider_event_id
					? $provider_event_id
					: null,

			'provider_reference' => isset(
				$change['provider_reference']
			)
				? sanitize_text_field(
					$change['provider_reference']
				)
				: '',

			'change_source' =>
				$change_source,

			'changed_by_user_id' => ! empty(
				$change['changed_by_user_id']
			)
				? absint(
					$change[
						'changed_by_user_id'
					]
				)
				: null,

			'changed_at' => current_time(
				'mysql',
				true
			),

			'notes' => isset(
				$change['notes']
			)
				? sanitize_textarea_field(
					$change['notes']
				)
				: null,
		);

		$table_name =
			TutorHelper_Pro_Database::
				get_table_name(
					'payment_history'
				);

		$result = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- TutorHelper Pro stores immutable payment audit history in its own custom table.
			$table_name,
			$data
		);

		if ( false === $result ) {

			if (
				''
				!== $payment_provider
				&& ''
				!== $provider_event_id
			) {

				$existing =
					self::get_by_provider_event(
						$payment_provider,
						$provider_event_id
					);

				if ( $existing ) {
					return absint(
						$existing->id
					);
				}
			}

			return new WP_Error(
				'tutorhelper_pro_payment_history_insert_failed',
				$wpdb->last_error
					? $wpdb->last_error
					: __(
						'The payment history could not be recorded.',
						'tutorhelper-pro'
					)
			);
		}

		return absint(
			$wpdb->insert_id
		);
	}


	/**
	 * Retrieve payment history by provider event ID.
	 *
	 * @param string $provider Provider key.
	 * @param string $event_id Provider event ID.
	 *
	 * @return object|null
	 */
	public static function get_by_provider_event(
		$provider,
		$event_id
	) {
		global $wpdb;

		$provider =
			sanitize_key(
				$provider
			);

		$event_id =
			sanitize_text_field(
				$event_id
			);

		if (
			'' === $provider
			|| '' === $event_id
		) {
			return null;
		}

		$table_name =
			TutorHelper_Pro_Database::
				get_table_name(
					'payment_history'
				);

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Provider webhook history must be checked against current stored events.
			$wpdb->prepare(
				'SELECT *
				FROM %i
				WHERE payment_provider = %s
				AND provider_event_id = %s
				LIMIT 1',
				$table_name,
				$provider,
				$event_id
			)
		);
	}

}
