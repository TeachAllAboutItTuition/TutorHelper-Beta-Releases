<?php
/**
 * Per-student TutorHelper Pro payment settings.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages student-specific payment permissions and manual payment flow.
 */
final class TutorHelper_Pro_Student_Payment_Settings {

	/**
	 * User meta controlling manual payment access.
	 *
	 * @var string
	 */
	const META_ALLOW_MANUAL_PAYMENT =
		'tutorhelper_pro_allow_manual_payment';

	/**
	 * Admin POST action.
	 *
	 * @var string
	 */
	const SAVE_ACTION =
		'tutorhelper_pro_save_student_payment_settings';

	/**
	 * Front-end script handle.
	 *
	 * @var string
	 */
	const SCRIPT_HANDLE =
		'tutorhelper-pro-student-payment-choice';

	/**
	 * Front-end style handle.
	 *
	 * @var string
	 */
	const STYLE_HANDLE =
		'tutorhelper-pro-student-payment-choice';

	/**
	 * Initialise hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'tutorhelper_students_detail_lesson_options_pricing',
			array(
				__CLASS__,
				'render_student_settings',
			),
			20,
			1
		);

		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array(
				__CLASS__,
				'handle_save',
			)
		);

		add_filter(
			'tutorhelper_student_booking_payment_args',
			array(
				__CLASS__,
				'configure_manual_payment',
			),
			20,
			2
		);

		add_filter(
			'tutorhelper_student_booking_submission_result',
			array(
				__CLASS__,
				'confirm_manual_booking',
			),
			20,
			3
		);

		add_filter(
			'tutorhelper_booking_send_request_emails',
			array(
				__CLASS__,
				'filter_request_emails',
			),
			20,
			3
		);

		add_action(
			'wp_enqueue_scripts',
			array(
				__CLASS__,
				'register_frontend_assets',
			),
			30
		);

		add_action(
			'wp_footer',
			array(
				__CLASS__,
				'enqueue_frontend_script',
			),
			5
		);

		add_filter(
			'tutorhelper_student_data_export',
			array(
				__CLASS__,
				'add_privacy_export_data',
			),
			20,
			2
		);

		add_action(
			'tutorhelper_before_student_data_delete',
			array(
				__CLASS__,
				'delete_privacy_data',
			),
			20,
			3
		);
	}

	/**
	 * Check whether a student may choose manual payment.
	 *
	 * @param int $student_user_id Student user ID.
	 * @return bool
	 */
	public static function manual_payment_is_allowed(
		$student_user_id
	) {

		return '1'
			=== (string) get_user_meta(
				absint( $student_user_id ),
				self::META_ALLOW_MANUAL_PAYMENT,
				true
			);
	}

	/**
	 * Render student payment permissions.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render_student_settings(
		$student
	) {

		if (
			! $student instanceof WP_User
			|| ! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		$student_id = absint( $student->ID );
		$manual_allowed =
			self::manual_payment_is_allowed(
				$student_id
			);

		self::render_notice();
		?>
		<section
			class="tutorhelper-student-detail__section tutorhelper-pro-student-payment-settings"
		>
			<h3>
				<?php
				echo esc_html__(
					'Payment Options',
					'tutorhelper-pro'
				);
				?>
			</h3>

			<p>
				<?php
				echo esc_html__(
					'Choose which additional payment options this student may use when booking paid lessons.',
					'tutorhelper-pro'
				);
				?>
			</p>

			<form
				method="post"
				action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
			>
				<input
					type="hidden"
					name="action"
					value="<?php echo esc_attr( self::SAVE_ACTION ); ?>"
				/>

				<input
					type="hidden"
					name="student_id"
					value="<?php echo esc_attr( $student_id ); ?>"
				/>

				<?php
				wp_nonce_field(
					self::SAVE_ACTION,
					'tutorhelper_pro_student_payment_nonce'
				);
				?>

				<label class="tutorhelper-toggle-row">
					<input
						type="checkbox"
						name="allow_manual_payment"
						value="1"
						<?php checked( $manual_allowed ); ?>
					/>

					<span>
						<strong>
							<?php
							echo esc_html__(
								'Allow invoice / bank transfer',
								'tutorhelper-pro'
							);
							?>
						</strong>
						<br />
						<small>
							<?php
							echo esc_html__(
								'The student may reserve a paid lesson without paying by card immediately. The booking is confirmed with payment marked as pending.',
								'tutorhelper-pro'
							);
							?>
						</small>
					</span>
				</label>

				<p>
					<button
						type="submit"
						class="button tutorhelper-admin-button tutorhelper-admin-button--primary"
					>
						<?php
						echo esc_html__(
							'Save payment options',
							'tutorhelper-pro'
						);
						?>
					</button>
				</p>
			</form>
		</section>
		<?php
	}

	/**
	 * Save student payment permissions.
	 *
	 * @return void
	 */
	public static function handle_save() {

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_die(
				esc_html__(
					'You do not have permission to manage student payment options.',
					'tutorhelper-pro'
				),
				esc_html__(
					'Permission denied',
					'tutorhelper-pro'
				),
				array(
					'response' => 403,
				)
			);
		}

		check_admin_referer(
			self::SAVE_ACTION,
			'tutorhelper_pro_student_payment_nonce'
		);

		$student_id =
			isset( $_POST['student_id'] )
				? absint(
					wp_unslash(
						$_POST['student_id']
					)
				)
				: 0;

		$student =
			TutorHelper_Students::get_student(
				$student_id
			);

		if ( ! $student instanceof WP_User ) {
			self::redirect(
				$student_id,
				'invalid_student'
			);
		}

		$allow_manual =
			isset( $_POST['allow_manual_payment'] )
			&& '1'
			=== sanitize_text_field(
				wp_unslash(
					$_POST['allow_manual_payment']
				)
			);

		if ( $allow_manual ) {
			update_user_meta(
				$student_id,
				self::META_ALLOW_MANUAL_PAYMENT,
				'1'
			);
		} else {
			delete_user_meta(
				$student_id,
				self::META_ALLOW_MANUAL_PAYMENT
			);
		}

		self::redirect(
			$student_id,
			'saved'
		);
	}

	/**
	 * Configure a student booking for manual payment when selected.
	 *
	 * Runs after the default Pro Stripe configuration so an approved
	 * manual payment can replace the provider-specific path.
	 *
	 * @param array|WP_Error $payment_args Current payment arguments.
	 * @param array          $context      Booking context.
	 * @return array|WP_Error
	 */
	public static function configure_manual_payment(
		$payment_args,
		$context
	) {

		if (
			TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL
			!== self::get_requested_payment_method()
		) {
			return $payment_args;
		}

		if ( ! is_array( $context ) ) {
			return $payment_args;
		}

		$student_user_id =
			isset( $context['student_user_id'] )
				? absint( $context['student_user_id'] )
				: 0;

		if (
			! $student_user_id
			|| ! self::manual_payment_is_allowed(
				$student_user_id
			)
		) {
			return new WP_Error(
				'tutorhelper_pro_manual_payment_not_allowed',
				__(
					'Invoice / bank transfer is not available for this account.',
					'tutorhelper-pro'
				)
			);
		}

		$duration =
			self::calculate_duration_minutes(
				isset( $context['booking_start'] )
					? $context['booking_start']
					: '',
				isset( $context['booking_end'] )
					? $context['booking_end']
					: '',
				isset( $context['timezone'] )
					? $context['timezone']
					: ''
			);

		if ( is_wp_error( $duration ) ) {
			return $duration;
		}

		$pricing =
			TutorHelper_Booking_Records::resolve_pricing(
				$student_user_id,
				absint(
					isset( $context['booking_type_id'] )
						? $context['booking_type_id']
						: 0
				),
				$duration
			);

		if ( is_wp_error( $pricing ) ) {
			return $pricing;
		}

		if (
			0 === absint(
				$pricing['price_minor_units']
			)
		) {
			return is_array( $payment_args )
				? $payment_args
				: array();
		}

		$args = is_array( $payment_args )
			? $payment_args
			: array();

		$args['skip_payment'] = false;
		$args['payment_method'] =
			TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL;
		$args['payment_status'] =
			TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING;

		return $args;
	}

	/**
	 * Confirm a manually paid booking after Core creates it.
	 *
	 * @param array  $result          Core submission result.
	 * @param int    $student_user_id Student user ID.
	 * @param string $return_url      Booking page return URL.
	 * @return array|WP_Error
	 */
	public static function confirm_manual_booking(
		$result,
		$student_user_id,
		$return_url
	) {

		unset( $return_url );

		if (
			! is_array( $result )
			|| empty( $result['booking_id'] )
		) {
			return $result;
		}

		$booking_id = absint( $result['booking_id'] );
		$booking =
			TutorHelper_Booking_Records::get_by_id(
				$booking_id
			);

		if (
			! $booking
			|| absint( $booking->student_user_id )
			!== absint( $student_user_id )
		) {
			return $result;
		}

		if (
			TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING
			!== sanitize_key( $booking->payment_status )
			|| TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL
			!== sanitize_key( $booking->payment_method )
		) {
			return $result;
		}

		$updated =
			TutorHelper_Booking_Records::update_payment_details(
				$booking_id,
				array(
					'payment_method' =>
						TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL,
					'payment_status' =>
						TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING,
					'payment_provider' => '',
					'payment_reference' => '',
					'booking_status' =>
						TutorHelper_Booking_Records::STATUS_CONFIRMED,
				),
				TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING
			);

		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		$result['status'] =
			TutorHelper_Booking_Records::STATUS_CONFIRMED;
		$result['message'] =
			__(
				'Your lesson is booked. Payment is awaiting invoice / bank transfer.',
				'tutorhelper-pro'
			);

		unset( $result['redirect_url'] );

		return $result;
	}

	/**
	 * Suppress temporary request emails for pending manual bookings.
	 *
	 * @param bool  $send        Current decision.
	 * @param int   $booking_id  Booking ID.
	 * @param array $insert_data Booking data.
	 * @return bool
	 */
	public static function filter_request_emails(
		$send,
		$booking_id,
		$insert_data
	) {

		unset( $booking_id );

		if ( ! is_array( $insert_data ) ) {
			return $send;
		}

		$payment_status =
			sanitize_key(
				isset( $insert_data['payment_status'] )
					? $insert_data['payment_status']
					: ''
			);

		$payment_method =
			sanitize_key(
				isset( $insert_data['payment_method'] )
					? $insert_data['payment_method']
					: ''
			);

		if (
			TutorHelper_Booking_Records::PAYMENT_STATUS_PENDING
			=== $payment_status
			&& TutorHelper_Booking_Records::PAYMENT_METHOD_MANUAL
			=== $payment_method
		) {
			return false;
		}

		return $send;
	}

	/**
	 * Register payment-choice front-end assets.
	 *
	 * @return void
	 */
	public static function register_frontend_assets() {

		if ( ! self::current_student_can_pay_manually() ) {
			return;
		}

		$script_path =
			TUTORHELPER_PRO_PATH
			. 'assets/js/student-payment-choice.js';

		$style_path =
			TUTORHELPER_PRO_PATH
			. 'assets/css/student-payment-choice.css';

		wp_register_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_PRO_URL
				. 'assets/js/student-payment-choice.js',
			array(
				'tutorhelper-student-booking-extensions',
			),
			file_exists( $script_path )
				? (string) filemtime( $script_path )
				: TUTORHELPER_PRO_VERSION,
			true
		);

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_PRO_URL
				. 'assets/css/student-payment-choice.css',
			array(),
			file_exists( $style_path )
				? (string) filemtime( $style_path )
				: TUTORHELPER_PRO_VERSION
		);
	}

	/**
	 * Enqueue the payment choice only when the Core booking form is used.
	 *
	 * @return void
	 */
	public static function enqueue_frontend_script() {

		if (
			! self::current_student_can_pay_manually()
			|| ! wp_script_is(
				'tutorhelper-student-booking',
				'enqueued'
			)
		) {
			return;
		}

		if ( ! wp_script_is( self::SCRIPT_HANDLE, 'registered' ) ) {
			self::register_frontend_assets();
		}

		wp_enqueue_script( self::SCRIPT_HANDLE );
	}

	/**
	 * Add manual payment permission to the student privacy export.
	 *
	 * @param array   $data    Existing export data.
	 * @param WP_User $student Student account.
	 * @return array
	 */
	public static function add_privacy_export_data(
		$data,
		$student
	) {

		if (
			! is_array( $data )
			|| ! $student instanceof WP_User
		) {
			return $data;
		}

		if ( ! isset( $data['pro'] ) || ! is_array( $data['pro'] ) ) {
			$data['pro'] = array();
		}

		if (
			! isset( $data['pro']['user_meta'] )
			|| ! is_array( $data['pro']['user_meta'] )
		) {
			$data['pro']['user_meta'] = array();
		}

		$data['pro']['user_meta'][ self::META_ALLOW_MANUAL_PAYMENT ] =
			get_user_meta(
				absint( $student->ID ),
				self::META_ALLOW_MANUAL_PAYMENT,
				true
			);

		return $data;
	}

	/**
	 * Delete manual payment permission during student data erasure.
	 *
	 * @param int    $student_id Student user ID.
	 * @param mixed  $student    Student object, when supplied by Core.
	 * @param string $mode       Core deletion mode.
	 * @return void
	 */
	public static function delete_privacy_data(
		$student_id,
		$student,
		$mode
	) {

		unset( $student, $mode );

		delete_user_meta(
			absint( $student_id ),
			self::META_ALLOW_MANUAL_PAYMENT
		);
	}

	/**
	 * Return the payment method selected by the student.
	 *
	 * The Core extension bridge sends extension fields as query arguments
	 * alongside the existing AJAX endpoint, so REQUEST is intentional here.
	 *
	 * @return string
	 */
	private static function get_requested_payment_method() {

		if (
			! isset( $_REQUEST['tutorhelper_payment_method'] )
			|| is_array(
				$_REQUEST['tutorhelper_payment_method']
			)
		) {
			return TutorHelper_Booking_Records::PAYMENT_METHOD_STRIPE;
		}

		return sanitize_key(
			wp_unslash(
				$_REQUEST['tutorhelper_payment_method']
			)
		);
	}

	/**
	 * Check current logged-in user is a student allowed manual payment.
	 *
	 * @return bool
	 */
	private static function current_student_can_pay_manually() {

		if ( ! is_user_logged_in() ) {
			return false;
		}

		$student_id = get_current_user_id();
		$student = TutorHelper_Students::get_student( $student_id );

		return $student instanceof WP_User
			&& self::manual_payment_is_allowed(
				$student_id
			);
	}

	/**
	 * Calculate booking duration.
	 *
	 * @param string $start    Local start.
	 * @param string $end      Local end.
	 * @param string $timezone Timezone.
	 * @return int|WP_Error
	 */
	private static function calculate_duration_minutes(
		$start,
		$end,
		$timezone
	) {

		try {
			$zone = new DateTimeZone(
				sanitize_text_field( $timezone )
			);

			$start_date = new DateTimeImmutable(
				sanitize_text_field( $start ),
				$zone
			);

			$end_date = new DateTimeImmutable(
				sanitize_text_field( $end ),
				$zone
			);
		} catch ( Exception $exception ) {
			return new WP_Error(
				'tutorhelper_pro_payment_date_invalid',
				__(
					'The lesson time could not be prepared for payment.',
					'tutorhelper-pro'
				)
			);
		}

		$seconds =
			$end_date->getTimestamp()
			- $start_date->getTimestamp();

		if (
			0 >= $seconds
			|| 0 !== $seconds % MINUTE_IN_SECONDS
		) {
			return new WP_Error(
				'tutorhelper_pro_payment_duration_invalid',
				__(
					'The lesson duration could not be prepared for payment.',
					'tutorhelper-pro'
				)
			);
		}

		return (int) (
			$seconds / MINUTE_IN_SECONDS
		);
	}

	/**
	 * Redirect back to the student's details screen.
	 *
	 * @param int    $student_id Student user ID.
	 * @param string $notice     Notice identifier.
	 * @return void
	 */
	private static function redirect(
		$student_id,
		$notice
	) {

		$url = add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Students_Admin::TAB_KEY,
				'student_id' => absint( $student_id ),
				'tutorhelper_pro_payment_notice' =>
					sanitize_key( $notice ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Render payment-setting feedback.
	 *
	 * @return void
	 */
	private static function render_notice() {

		$notice =
			isset( $_GET['tutorhelper_pro_payment_notice'] )
				? sanitize_key(
					wp_unslash(
						$_GET['tutorhelper_pro_payment_notice']
					)
				)
				: '';

		if ( '' === $notice ) {
			return;
		}

		$messages = array(
			'saved' => array(
				'type' => 'success',
				'text' => __(
					'Student payment options saved.',
					'tutorhelper-pro'
				),
			),
			'invalid_student' => array(
				'type' => 'error',
				'text' => __(
					'The selected student could not be found.',
					'tutorhelper-pro'
				),
			),
		);

		if ( ! isset( $messages[ $notice ] ) ) {
			return;
		}

		$message = $messages[ $notice ];
		$class = 'success' === $message['type']
			? 'notice notice-success inline'
			: 'notice notice-error inline';
		?>
		<div class="<?php echo esc_attr( $class ); ?>">
			<p><?php echo esc_html( $message['text'] ); ?></p>
		</div>
		<?php
	}
}
