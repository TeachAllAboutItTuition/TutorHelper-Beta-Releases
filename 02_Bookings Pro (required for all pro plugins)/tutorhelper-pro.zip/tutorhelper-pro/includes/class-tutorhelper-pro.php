<?php
/**
 * Main TutorHelper Pro controller.
 *
 * @package TutorHelper_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Coordinates TutorHelper Pro startup.
 */
class TutorHelper_Pro {

	/**
	 * Singleton instance.
	 *
	 * @var TutorHelper_Pro|null
	 */
	private static $instance = null;

	/**
	 * Get the plugin instance.
	 *
	 * @return TutorHelper_Pro
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/** Prevent direct construction. */
	private function __construct() {}

	/**
	 * Start TutorHelper Pro.
	 *
	 * @return void
	 */
	public function run() {

		if ( ! TutorHelper_Pro_Dependency::core_is_available() ) {
			$this->register_missing_core_notice();
			return;
		}

		TutorHelper_Pro_Stripe_Webhook::init();

		$is_pro_active = TutorHelper_Pro_License::is_active();

		if ( $is_pro_active ) {
			TutorHelper_Pro_Online_Lessons::init();
			TutorHelper_Pro_Email_Branding::init();
			TutorHelper_Pro_Booking_Branding::init();
			TutorHelper_Pro_Dashboard_Branding::init();
			TutorHelper_Pro_Dashboard_Reports::init();
			TutorHelper_Pro_Progress_Reports::init();
			TutorHelper_Pro_Dashboard_Analytics::init();
			TutorHelper_Pro_Email_Reminders::register_templates();
			TutorHelper_Pro_Paid_Booking_Email::init();
			TutorHelper_Pro_Registration_Emails::init();
			TutorHelper_Pro_Email_Delivery_History::init();
			TutorHelper_Pro_Email_Reminder_Cron::init();
			TutorHelper_Pro_Email_Reminder_Delivery::init();
			TutorHelper_Pro_Student_Pricing::init();
			TutorHelper_Pro_Student_Finance_Visibility::init();
			TutorHelper_Pro_Student_Data::init();
			TutorHelper_Pro_Student_Notes::init();
			TutorHelper_Pro_Student_History::init();
			TutorHelper_Pro_Student_Email::init();
			TutorHelper_Pro_Student_Credits::init();
			TutorHelper_Pro_Credit_Refund_Requests::init();
			TutorHelper_Pro_Bank_Details::init();
			TutorHelper_Pro_Student_Payment_Methods::init();
			TutorHelper_Pro_Student_Payment_Checkout::init();
			TutorHelper_Pro_Parent_Finance::init();
			TutorHelper_Pro_Booking_Type_Access::init();
			TutorHelper_Pro_Booking_Attendance::init();
			TutorHelper_Pro_Lesson_Follow_Up::init();
			TutorHelper_Pro_Booking_Change_Limits::init();
			TutorHelper_Pro_Student_Rescheduling::init();
			TutorHelper_Pro_Student_Rescheduling_UX::init();
			TutorHelper_Pro_Booking_Series_Email::init();
			TutorHelper_Pro_Recurring_Booking_Editor::init();
			TutorHelper_Pro_Registration_Frontend::init();
			TutorHelper_Pro_Registration_Handler::init();
			TutorHelper_Pro_Terms_Update::init();
			TutorHelper_Pro_Calendar_Sync::init();
			TutorHelper_Pro_Online_Lessons_Dashboard::init();
			TutorHelper_Pro_Student_Dashboard_Table::init();
			TutorHelper_Pro_Payment_Requests::init();
		}

		if ( is_admin() ) {
			TutorHelper_Pro_Settings::init();

			if ( $is_pro_active ) {
				TutorHelper_Pro_Google_Calendar_Admin::init();
				add_action(
					'admin_enqueue_scripts',
					array( $this, 'enqueue_google_calendar_admin_style' )
				);
				TutorHelper_Pro_Late_Reminder_Email::register();
				TutorHelper_Pro_Student_Pricing_Admin::init();
				TutorHelper_Pro_Registration_Admin::init();
				TutorHelper_Pro_Groups_Admin::init();
				TutorHelper_Pro_Booking_Type_Admin::init();
				TutorHelper_Pro_Recurring_Booking_Admin::init();
				TutorHelper_Pro_Email_Admin::init();
				TutorHelper_Pro_Student_Bookings_Admin::init();
				TutorHelper_Pro_Finance_Admin::init();
				TutorHelper_Pro_Finance_Statements::init();
				TutorHelper_Pro_Finance_Payments::init();
				TutorHelper_Pro_Finance_Credit_Allocations::init();
				TutorHelper_Pro_Finance_Adjustments::init();
				TutorHelper_Pro_Finance_Adjustment_UI::init();
			}
		}
	}

	/**
	 * Load the small Calendar settings stylesheet on TutorHelper settings only.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public function enqueue_google_calendar_admin_style( $hook_suffix ) {
		if ( 'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix ) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] )
			? sanitize_key( wp_unslash( $_GET['tab'] ) )
			: '';

		if ( TutorHelper_Pro_Settings::ONLINE_LESSONS_TAB !== $tab ) {
			return;
		}

		$path = TUTORHELPER_PRO_PATH . 'assets/css/tutorhelper-pro-google-calendar-admin.css';
		wp_enqueue_style(
			'tutorhelper-pro-google-calendar-admin',
			TUTORHELPER_PRO_URL . 'assets/css/tutorhelper-pro-google-calendar-admin.css',
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : TUTORHELPER_PRO_VERSION
		);
	}

	/**
	 * Register the missing Core plugin notice.
	 *
	 * @return void
	 */
	private function register_missing_core_notice() {
		if ( ! is_admin() ) {
			return;
		}

		add_action(
			'admin_notices',
			array( $this, 'render_missing_core_notice' )
		);
	}

	/**
	 * Display a notice when TutorHelper Bookings is unavailable.
	 *
	 * @return void
	 */
	public function render_missing_core_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		?>
		<div class="notice notice-error">
			<p>
				<?php
				echo esc_html__(
					'TutorHelper Pro requires TutorHelper Bookings to be installed and active.',
					'tutorhelper-pro'
				);
				?>
			</p>
		</div>
		<?php
	}
}
