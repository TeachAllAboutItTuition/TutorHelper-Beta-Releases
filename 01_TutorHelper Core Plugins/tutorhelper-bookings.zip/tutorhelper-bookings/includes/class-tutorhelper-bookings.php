<?php
/**
 * Main plugin controller.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Coordinates the TutorHelper Bookings plugin.
 */
final class TutorHelper_Bookings {

	/**
	 * Shared plugin instance.
	 *
	 * @var TutorHelper_Bookings|null
	 */
	private static $instance = null;

	/**
	 * Get the shared plugin instance.
	 *
	 * @return TutorHelper_Bookings
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Prevent direct construction outside this class.
	 */
	private function __construct() {}

	/**
	 * Register the plugin's runtime functionality.
	 *
	 * @return void
	 */
	public function run() {
        TutorHelper_Bookings_Database::update_check();
		
		TutorHelper_Roles::register_roles();
		TutorHelper_Student_Parent_Links::migrate_legacy_links();

        /**
         * Fires after TutorHelper Bookings has loaded.
         *
         * Extensions can use this action to initialise functionality that
         * depends on the core booking plugin.
         *
         * @param TutorHelper_Bookings $plugin Main plugin instance.
         */
        do_action( 'tutorhelper_bookings_loaded', $this );
    }
}
