<?php
/**
 * TutorHelper reporting dashboard.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides the dashboard page, shared filters and extension API.
 */
final class TutorHelper_Dashboard {

	/**
	 * Register dashboard hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' )
		);
	}

	/**
	 * Load dashboard styling on the un-tabbed TutorHelper page only.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| self::is_booking_hub_request()
		) {
			return;
		}

		$path = TUTORHELPER_BOOKINGS_PATH . 'assets/css/admin-dashboard.css';

		wp_enqueue_style(
			'tutorhelper-admin-dashboard',
			TUTORHELPER_BOOKINGS_URL . 'assets/css/admin-dashboard.css',
			array( 'dashicons' ),
			file_exists( $path )
				? (string) filemtime( $path )
				: TUTORHELPER_BOOKINGS_VERSION
		);

		$script_path = TUTORHELPER_BOOKINGS_PATH . 'assets/js/admin-dashboard-tabs.js';
		wp_enqueue_script(
			'tutorhelper-admin-dashboard-tabs',
			TUTORHELPER_BOOKINGS_URL . 'assets/js/admin-dashboard-tabs.js',
			array(),
			file_exists( $script_path )
				? (string) filemtime( $script_path )
				: TUTORHELPER_BOOKINGS_VERSION,
			true
		);
		wp_localize_script(
			'tutorhelper-admin-dashboard-tabs',
			'tutorhelperDashboardTabs',
			array(
				'refreshingText' => __( 'Refreshing this dashboard section…', 'tutorhelper-bookings' ),
				'errorText'      => __( 'This dashboard section could not be refreshed. Please try again.', 'tutorhelper-bookings' ),
			)
		);
	}

	/**
	 * Whether this request is for a Booking Hub tab.
	 *
	 * Existing Booking Hub URLs use page=tutorhelper&tab=... . Keeping that
	 * contract avoids breaking saved links and add-on integrations.
	 *
	 * @return bool
	 */
	public static function is_booking_hub_request() {
		return isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
	}

	/**
	 * Render either the dashboard or a legacy-compatible Booking Hub tab.
	 *
	 * @return void
	 */
	public static function render_controller() {
		if ( self::is_booking_hub_request() ) {
			TutorHelper_Booking_Hub::render_page();
			return;
		}

		self::render_page();
	}

	/**
	 * Render the reporting dashboard.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to access this page.',
					'tutorhelper-bookings'
				)
			);
		}

		$context = self::build_context();
		$widgets = self::get_widgets( $context );
		?>
		<div class="wrap tutorhelper-dashboard">
			<div class="tutorhelper-dashboard__hero">
				<div>
					<p class="tutorhelper-dashboard__eyebrow">
						<?php echo esc_html__( 'Tutor reporting', 'tutorhelper-bookings' ); ?>
					</p>
					<h1><?php echo esc_html__( 'TutorHelper Dashboard', 'tutorhelper-bookings' ); ?></h1>
					<p>
						<?php echo esc_html__( 'Review lesson activity and student engagement for the selected period.', 'tutorhelper-bookings' ); ?>
					</p>
				</div>
				<a class="tutorhelper-dashboard__hub-button" href="<?php echo esc_url( self::get_booking_hub_url() ); ?>">
					<span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
					<?php echo esc_html__( 'Open Booking Hub', 'tutorhelper-bookings' ); ?>
				</a>
			</div>

			<?php self::render_filters( $context ); ?>

			<div class="tutorhelper-dashboard__period" aria-live="polite">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: report start date, 2: report end date. */
						__( 'Showing %1$s to %2$s', 'tutorhelper-bookings' ),
						wp_date( get_option( 'date_format' ), $context['start_local']->getTimestamp() ),
						wp_date( get_option( 'date_format' ), $context['end_local']->getTimestamp() )
					)
				);
				?>
			</div>

			<?php do_action( 'tutorhelper_dashboard_before_widgets', $context ); ?>
			<?php self::render_dashboard_tabs( $widgets, $context ); ?>
		</div>
		<?php
	}

	/**
	 * Build the shared report context.
	 *
	 * @return array
	 */
	public static function build_context() {
		$timezone = wp_timezone();
		$now      = new DateTimeImmutable( 'now', $timezone );
		$defaults = array(
			'from'            => $now->modify( 'first day of this month' )->format( 'Y-m-d' ),
			'to'              => $now->modify( 'last day of this month' )->format( 'Y-m-d' ),
			'student_id'      => 0,
			'tutor_id'        => 0,
			'booking_type_id' => 0,
			'status'          => '',
		);

		$filters = array(
			'from'            => self::read_date_filter( 'dashboard_from', $defaults['from'] ),
			'to'              => self::read_date_filter( 'dashboard_to', $defaults['to'] ),
			'student_id'      => self::read_id_filter( 'dashboard_student' ),
			'tutor_id'        => self::read_id_filter( 'dashboard_tutor' ),
			'booking_type_id' => self::read_id_filter( 'dashboard_booking_type' ),
			'status'          => self::read_status_filter(),
		);

		$start_local = self::date_object( $filters['from'], $timezone );
		$end_local   = self::date_object( $filters['to'], $timezone );

		if ( $end_local < $start_local ) {
			$end_local     = $start_local;
			$filters['to'] = $filters['from'];
		}

		$utc            = new DateTimeZone( 'UTC' );
		$start_utc      = $start_local->setTimezone( $utc );
		$end_exclusive  = $end_local->modify( '+1 day' )->setTimezone( $utc );
		$bookings       = self::query_bookings( $filters, $start_utc, $end_exclusive );

		$context = array(
			'filters'           => $filters,
			'defaults'          => $defaults,
			'timezone'          => $timezone,
			'start_local'       => $start_local,
			'end_local'         => $end_local,
			'start_utc'         => $start_utc,
			'end_utc_exclusive' => $end_exclusive,
			'bookings'          => $bookings,
			'booking_ids'       => array_map( 'absint', wp_list_pluck( $bookings, 'id' ) ),
		);

		/**
		 * Filters the shared TutorHelper dashboard context.
		 *
		 * Add-ons should consume this context so every widget honours the same
		 * date, student, tutor, Booking Type and status filters.
		 *
		 * @param array $context Dashboard context.
		 */
		return apply_filters( 'tutorhelper_dashboard_context', $context );
	}

	/**
	 * Return Core and extension dashboard widgets.
	 *
	 * @param array $context Dashboard context.
	 * @return array
	 */
	private static function get_widgets( $context ) {
		$bookings       = $context['bookings'];
		$active_ids     = array();
		$hours_seconds  = 0;
		$tutor_created  = 0;
		$student_created = 0;

		foreach ( $bookings as $booking ) {
			if ( TutorHelper_Booking_Records::STATUS_CANCELLED !== $booking->status ) {
				$start = strtotime( $booking->booking_start . ' UTC' );
				$end   = strtotime( $booking->booking_end . ' UTC' );
				if ( false !== $start && false !== $end && $end > $start ) {
					$hours_seconds += $end - $start;
				}
				$active_ids[ absint( $booking->student_user_id ) ] = true;
			}

			if ( TutorHelper_Booking_Records::SOURCE_TUTOR === $booking->source ) {
				++$tutor_created;
			} elseif ( TutorHelper_Booking_Records::SOURCE_STUDENT === $booking->source ) {
				++$student_created;
			}
		}

		$student_args = array(
			'role'   => TutorHelper_Students::STUDENT_ROLE,
			'fields' => 'ids',
		);
		if ( $context['filters']['student_id'] ) {
			$student_args['include'] = array( $context['filters']['student_id'] );
		}
		$student_ids = get_users( $student_args );
		$student_ids = apply_filters(
			'tutorhelper_dashboard_student_ids',
			array_values( array_filter( array_map( 'absint', (array) $student_ids ) ) ),
			$context
		);
		$new_students = apply_filters(
			'tutorhelper_dashboard_new_student_count',
			self::count_new_students( $context ),
			$context
		);
		$hours = number_format_i18n( $hours_seconds / HOUR_IN_SECONDS, 1 );

		$widgets = array(
			'hours_booked' => array(
				'label'       => __( 'Hours booked', 'tutorhelper-bookings' ),
				'value'       => $hours,
				'description' => __( 'Confirmed and unconfirmed lesson time', 'tutorhelper-bookings' ),
				'icon'        => 'clock',
				'tone'        => 'primary',
				'section'     => 'bookings',
				'priority'    => 10,
			),
			'tutor_bookings' => array(
				'label'       => __( 'Booked by tutor', 'tutorhelper-bookings' ),
				'value'       => number_format_i18n( $tutor_created ),
				'description' => __( 'Bookings created by staff', 'tutorhelper-bookings' ),
				'icon'        => 'businessperson',
				'tone'        => 'orange',
				'section'     => 'bookings',
				'priority'    => 20,
			),
			'student_bookings' => array(
				'label'       => __( 'Booked by students', 'tutorhelper-bookings' ),
				'value'       => number_format_i18n( $student_created ),
				'description' => __( 'Bookings requested through student booking', 'tutorhelper-bookings' ),
				'icon'        => 'calendar-alt',
				'tone'        => 'blue',
				'section'     => 'bookings',
				'priority'    => 30,
			),
			'new_students' => array(
				'label'       => __( 'New students', 'tutorhelper-bookings' ),
				'value'       => number_format_i18n( $new_students ),
				'description' => __( 'Student accounts created in this period', 'tutorhelper-bookings' ),
				'icon'        => 'groups',
				'tone'        => 'green',
				'section'     => 'students',
				'priority'    => 10,
			),
			'active_students' => array(
				'label'       => __( 'Active students', 'tutorhelper-bookings' ),
				'value'       => number_format_i18n( count( $active_ids ) ),
				'description' => __( 'Students with a non-cancelled booking', 'tutorhelper-bookings' ),
				'icon'        => 'yes-alt',
				'tone'        => 'green',
				'section'     => 'students',
				'priority'    => 20,
			),
			'inactive_students' => array(
				'label'       => __( 'Inactive students', 'tutorhelper-bookings' ),
				'value'       => number_format_i18n( max( 0, count( $student_ids ) - count( $active_ids ) ) ),
				'description' => __( 'Students without a booking in this period', 'tutorhelper-bookings' ),
				'icon'        => 'minus',
				'tone'        => 'muted',
				'section'     => 'students',
				'priority'    => 30,
			),
		);

		/**
		 * Filters dashboard widgets.
		 *
		 * Add-ons can append widgets without changing the dashboard controller.
		 * Each widget supports label, value, description, icon, tone, section,
		 * priority and an optional URL.
		 *
		 * @param array $widgets Dashboard widget definitions keyed by ID.
		 * @param array $context Shared dashboard context.
		 */
		$widgets = apply_filters( 'tutorhelper_dashboard_widgets', $widgets, $context );

		foreach ( $widgets as $id => &$widget ) {
			$widget['id'] = sanitize_key( $id );
		}
		unset( $widget );

		$section_order = array(
			'bookings'       => 10,
			'analytics'      => 15,
			'attendance'     => 20,
			'finance'        => 30,
			'students'       => 40,
			'communications' => 50,
			'feedback'       => 60,
			'other'          => 70,
		);

		usort(
			$widgets,
			function ( $left, $right ) use ( $section_order ) {
				$left_section  = isset( $left['section'] ) ? $left['section'] : 'other';
				$right_section = isset( $right['section'] ) ? $right['section'] : 'other';
				if ( $left_section !== $right_section ) {
					$left_order  = isset( $section_order[ $left_section ] ) ? $section_order[ $left_section ] : 999;
					$right_order = isset( $section_order[ $right_section ] ) ? $section_order[ $right_section ] : 999;
					return $left_order - $right_order;
				}
				return intval( isset( $left['priority'] ) ? $left['priority'] : 10 )
					- intval( isset( $right['priority'] ) ? $right['priority'] : 10 );
			}
		);

		return $widgets;
	}

	/**
	 * Render the shared filter form.
	 *
	 * @param array $context Dashboard context.
	 * @return void
	 */
	private static function render_filters( $context ) {
		$filters       = $context['filters'];
		$students      = get_users(
			array(
				'role'    => TutorHelper_Students::STUDENT_ROLE,
				'orderby' => 'display_name',
				'order'   => 'ASC',
			)
		);
		$tutors        = get_users(
			array(
				'capability' => TutorHelper_Admin::CAPABILITY,
				'orderby'    => 'display_name',
				'order'      => 'ASC',
			)
		);
		$tutors        = apply_filters( 'tutorhelper_dashboard_tutor_options', $tutors );
		$booking_types = TutorHelper_Booking_Types::get_all();
		?>
		<form class="tutorhelper-dashboard__filters" method="get">
			<input type="hidden" name="page" value="<?php echo esc_attr( TutorHelper_Admin::MENU_SLUG ); ?>">
			<div class="tutorhelper-dashboard__filter-heading">
				<h2><?php echo esc_html__( 'Report filters', 'tutorhelper-bookings' ); ?></h2>
				<p><?php echo esc_html__( 'All dashboard figures use these filters.', 'tutorhelper-bookings' ); ?></p>
			</div>
			<label>
				<span><?php echo esc_html__( 'From', 'tutorhelper-bookings' ); ?></span>
				<input type="date" name="dashboard_from" value="<?php echo esc_attr( $filters['from'] ); ?>">
			</label>
			<label>
				<span><?php echo esc_html__( 'To', 'tutorhelper-bookings' ); ?></span>
				<input type="date" name="dashboard_to" value="<?php echo esc_attr( $filters['to'] ); ?>">
			</label>
			<label>
				<span><?php echo esc_html__( 'Student', 'tutorhelper-bookings' ); ?></span>
				<select name="dashboard_student">
					<option value="0"><?php echo esc_html__( 'All students', 'tutorhelper-bookings' ); ?></option>
					<?php foreach ( $students as $student ) : ?>
						<option value="<?php echo esc_attr( $student->ID ); ?>" <?php selected( $filters['student_id'], $student->ID ); ?>><?php echo esc_html( $student->display_name ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>
				<span><?php echo esc_html__( 'Tutor / staff', 'tutorhelper-bookings' ); ?></span>
				<select name="dashboard_tutor">
					<option value="0"><?php echo esc_html__( 'All tutors', 'tutorhelper-bookings' ); ?></option>
					<?php foreach ( $tutors as $tutor ) : ?>
						<option value="<?php echo esc_attr( $tutor->ID ); ?>" <?php selected( $filters['tutor_id'], $tutor->ID ); ?>><?php echo esc_html( $tutor->display_name ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>
				<span><?php echo esc_html__( 'Booking Type', 'tutorhelper-bookings' ); ?></span>
				<select name="dashboard_booking_type">
					<option value="0"><?php echo esc_html__( 'All Booking Types', 'tutorhelper-bookings' ); ?></option>
					<?php foreach ( $booking_types as $booking_type ) : ?>
						<option value="<?php echo esc_attr( $booking_type->id ); ?>" <?php selected( $filters['booking_type_id'], $booking_type->id ); ?>><?php echo esc_html( $booking_type->title ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>
				<span><?php echo esc_html__( 'Booking status', 'tutorhelper-bookings' ); ?></span>
				<select name="dashboard_status">
					<option value=""><?php echo esc_html__( 'All statuses', 'tutorhelper-bookings' ); ?></option>
					<option value="confirmed" <?php selected( $filters['status'], 'confirmed' ); ?>><?php echo esc_html__( 'Confirmed', 'tutorhelper-bookings' ); ?></option>
					<option value="unconfirmed" <?php selected( $filters['status'], 'unconfirmed' ); ?>><?php echo esc_html__( 'Unconfirmed', 'tutorhelper-bookings' ); ?></option>
					<option value="cancelled" <?php selected( $filters['status'], 'cancelled' ); ?>><?php echo esc_html__( 'Cancelled', 'tutorhelper-bookings' ); ?></option>
				</select>
			</label>
			<?php
			/**
			 * Render dashboard filters supplied by add-ons.
			 *
			 * @param array $context Shared dashboard context.
			 */
			do_action( 'tutorhelper_dashboard_filter_fields', $context );
			?>
			<div class="tutorhelper-dashboard__filter-actions">
				<button class="button button-primary" type="submit"><?php echo esc_html__( 'Apply filters', 'tutorhelper-bookings' ); ?></button>
				<a class="button" href="<?php echo esc_url( self::get_dashboard_url() ); ?>"><?php echo esc_html__( 'Reset', 'tutorhelper-bookings' ); ?></a>
			</div>
		</form>
		<?php
	}

	/**
	 * Render widgets grouped into labelled sections.
	 *
	 * @param array $widgets Widget definitions.
	 * @return void
	 */
	private static function render_dashboard_tabs( $widgets, $context ) {
		$sections = self::group_widgets_by_section( $widgets );
		$tabs     = self::get_dashboard_tabs( $sections, $context );
		$active   = self::read_dashboard_tab( array_keys( $tabs ) );
		?>
		<div class="tutorhelper-dashboard__tabs" data-active-tab="<?php echo esc_attr( $active ); ?>">
			<div class="tutorhelper-dashboard__tabs-status" role="status" aria-live="polite"></div>
			<div class="tutorhelper-dashboard__tab-list" role="tablist" aria-label="<?php echo esc_attr__( 'Tutor Dashboard sections', 'tutorhelper-bookings' ); ?>">
				<?php foreach ( $tabs as $tab_id => $tab ) : ?>
					<?php $is_active = $active === $tab_id; ?>
					<button
						type="button"
						class="tutorhelper-dashboard__tab"
						role="tab"
						id="tutorhelper-dashboard-tab-<?php echo esc_attr( $tab_id ); ?>"
						aria-controls="tutorhelper-dashboard-panel-<?php echo esc_attr( $tab_id ); ?>"
						aria-selected="<?php echo $is_active ? 'true' : 'false'; ?>"
						tabindex="<?php echo $is_active ? '0' : '-1'; ?>"
						data-dashboard-tab="<?php echo esc_attr( $tab_id ); ?>"
					>
						<?php echo esc_html( $tab['label'] ); ?>
					</button>
				<?php endforeach; ?>
			</div>

			<div class="tutorhelper-dashboard__tab-panels">
				<?php foreach ( $tabs as $tab_id => $tab ) : ?>
					<section
						class="tutorhelper-dashboard__tab-panel"
						id="tutorhelper-dashboard-panel-<?php echo esc_attr( $tab_id ); ?>"
						role="tabpanel"
						aria-labelledby="tutorhelper-dashboard-tab-<?php echo esc_attr( $tab_id ); ?>"
						data-dashboard-tab="<?php echo esc_attr( $tab_id ); ?>"
					>
						<div class="tutorhelper-dashboard__tab-panel-heading">
							<h2><?php echo esc_html( $tab['label'] ); ?></h2>
							<button type="button" class="button tutorhelper-dashboard__tab-refresh" data-dashboard-refresh-tab>
								<span class="dashicons dashicons-update" aria-hidden="true"></span>
								<?php echo esc_html__( 'Refresh this section', 'tutorhelper-bookings' ); ?>
							</button>
						</div>
						<div class="tutorhelper-dashboard__tab-panel-content">
							<?php self::render_dashboard_tab_content( $tab_id, $tab, $sections, $context ); ?>
						</div>
					</section>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Group dashboard widgets by their registered section.
	 *
	 * @param array $widgets Dashboard widget definitions.
	 * @return array
	 */
	private static function group_widgets_by_section( $widgets ) {
		$sections = array();
		foreach ( $widgets as $widget ) {
			$section = isset( $widget['section'] )
				? sanitize_key( $widget['section'] )
				: 'other';
			$sections[ $section ][] = $widget;
		}
		return $sections;
	}

	/**
	 * Define the logical dashboard tabs while leaving a filter for add-ons.
	 *
	 * @param array $sections Widgets grouped by section.
	 * @param array $context  Shared dashboard context.
	 * @return array
	 */
	private static function get_dashboard_tabs( $sections, $context ) {
		$tabs = array(
			'overview' => array(
				'label'    => __( 'Overview', 'tutorhelper-bookings' ),
				'sections' => array( 'bookings', 'analytics', 'other' ),
			),
			'attendance' => array(
				'label'    => __( 'Attendance', 'tutorhelper-bookings' ),
				'sections' => array( 'attendance' ),
			),
			'finance' => array(
				'label'    => __( 'Finance', 'tutorhelper-bookings' ),
				'sections' => array( 'finance' ),
			),
			'students' => array(
				'label'    => __( 'Students', 'tutorhelper-bookings' ),
				'sections' => array( 'students' ),
			),
			'communications' => array(
				'label'    => __( 'Communications', 'tutorhelper-bookings' ),
				'sections' => array( 'communications', 'feedback' ),
			),
		);

		if ( has_action( 'tutorhelper_dashboard_after_widgets' ) ) {
			$tabs['reports'] = array(
				'label'    => __( 'Reports', 'tutorhelper-bookings' ),
				'sections' => array(),
			);
		}

		$assigned_sections = array();
		foreach ( $tabs as $tab ) {
			$assigned_sections = array_merge( $assigned_sections, $tab['sections'] );
		}
		foreach ( array_keys( $sections ) as $section ) {
			if ( ! in_array( $section, $assigned_sections, true ) ) {
				$tabs['overview']['sections'][] = $section;
			}
		}

		foreach ( $tabs as $tab_id => $tab ) {
			$has_widgets = false;
			foreach ( $tab['sections'] as $section ) {
				if ( ! empty( $sections[ $section ] ) ) {
					$has_widgets = true;
					break;
				}
			}

			if ( ! $has_widgets && 'reports' !== $tab_id ) {
				unset( $tabs[ $tab_id ] );
			}
		}

		/**
		 * Filters the logical tabs shown on the Tutor Dashboard.
		 *
		 * @param array $tabs     Dashboard tab definitions.
		 * @param array $sections Widgets grouped by section.
		 * @param array $context  Shared dashboard context.
		 */
		return apply_filters( 'tutorhelper_dashboard_tabs', $tabs, $sections, $context );
	}

	/**
	 * Render the widgets or extension content for one logical tab.
	 *
	 * @param string $tab_id   Current tab ID.
	 * @param array  $tab      Current tab definition.
	 * @param array  $sections Widgets grouped by section.
	 * @param array  $context  Shared dashboard context.
	 * @return void
	 */
	private static function render_dashboard_tab_content( $tab_id, $tab, $sections, $context ) {
		if ( 'reports' === $tab_id ) {
			do_action( 'tutorhelper_dashboard_reports_tab', $context );
			do_action( 'tutorhelper_dashboard_after_widgets', $context );
			return;
		}

		$labels = self::section_labels();
		foreach ( $tab['sections'] as $section ) {
			if ( empty( $sections[ $section ] ) ) {
				continue;
			}
			?>
			<section class="tutorhelper-dashboard__section" aria-labelledby="tutorhelper-dashboard-section-<?php echo esc_attr( $section ); ?>">
				<h3 id="tutorhelper-dashboard-section-<?php echo esc_attr( $section ); ?>"><?php echo esc_html( isset( $labels[ $section ] ) ? $labels[ $section ] : ucfirst( $section ) ); ?></h3>
				<div class="tutorhelper-dashboard__grid">
					<?php foreach ( $sections[ $section ] as $widget ) : ?>
						<?php self::render_widget( $widget ); ?>
					<?php endforeach; ?>
				</div>
			</section>
			<?php
		}
	}

	/**
	 * Return user-facing labels for widget sections.
	 *
	 * @return array
	 */
	private static function section_labels() {
		return array(
			'bookings'       => __( 'Bookings', 'tutorhelper-bookings' ),
			'analytics'      => __( 'Booking analytics', 'tutorhelper-bookings' ),
			'attendance'     => __( 'Attendance', 'tutorhelper-bookings' ),
			'finance'        => __( 'Finance', 'tutorhelper-bookings' ),
			'students'       => __( 'Students', 'tutorhelper-bookings' ),
			'communications' => __( 'Communications', 'tutorhelper-bookings' ),
			'feedback'       => __( 'Lesson feedback', 'tutorhelper-bookings' ),
			'other'          => __( 'Other', 'tutorhelper-bookings' ),
		);
	}

	/**
	 * Read the selected dashboard tab from the read-only navigation query.
	 *
	 * @param array $tabs Supported tab IDs.
	 * @return string
	 */
	private static function read_dashboard_tab( $tabs ) {
		$tab = isset( $_GET['dashboard_tab'] ) && ! is_array( $_GET['dashboard_tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only dashboard tab selection.
			? sanitize_key( wp_unslash( $_GET['dashboard_tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only dashboard tab selection.
			: 'overview';
		return in_array( $tab, $tabs, true ) ? $tab : reset( $tabs );
	}

	/**
	 * Render one metric card.
	 *
	 * @param array $widget Widget definition.
	 * @return void
	 */
	private static function render_widget( $widget ) {
		$label       = isset( $widget['label'] ) ? $widget['label'] : '';
		$value       = isset( $widget['value'] ) ? $widget['value'] : '—';
		$description = isset( $widget['description'] ) ? $widget['description'] : '';
		$icon        = isset( $widget['icon'] ) ? sanitize_key( $widget['icon'] ) : 'chart-bar';
		$tone        = isset( $widget['tone'] ) ? sanitize_key( $widget['tone'] ) : 'primary';
		$url         = ! empty( $widget['url'] ) ? $widget['url'] : '';
		$link_label  = isset( $widget['link_label'] ) ? $widget['link_label'] : __( 'Open linked page', 'tutorhelper-bookings' );
		$callback    = isset( $widget['panel_callback'] ) && is_callable( $widget['panel_callback'] )
			? $widget['panel_callback']
			: null;
		$panel_args  = isset( $widget['panel_args'] ) ? $widget['panel_args'] : array();

		if ( $callback ) :
			?>
			<details class="tutorhelper-dashboard__expandable">
				<summary class="tutorhelper-dashboard__card tutorhelper-dashboard__card--<?php echo esc_attr( $tone ); ?>">
					<span class="tutorhelper-dashboard__card-icon dashicons dashicons-<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
					<span class="tutorhelper-dashboard__card-content">
						<span class="tutorhelper-dashboard__card-label"><?php echo esc_html( $label ); ?></span>
						<strong class="tutorhelper-dashboard__card-value"><?php echo esc_html( $value ); ?></strong>
						<?php if ( $description ) : ?>
							<span class="tutorhelper-dashboard__card-description"><?php echo esc_html( $description ); ?></span>
						<?php endif; ?>
					</span>
					<span class="dashicons dashicons-arrow-down-alt2 tutorhelper-dashboard__card-arrow" aria-hidden="true"></span>
				</summary>
				<div class="tutorhelper-dashboard__expanded-panel">
					<?php call_user_func( $callback, $panel_args ); ?>
				</div>
			</details>
			<?php
			return;
		endif;

		$tag = $url ? 'a' : 'div';
		?>
		<<?php echo tag_escape( $tag ); ?> class="tutorhelper-dashboard__card tutorhelper-dashboard__card--<?php echo esc_attr( $tone ); ?>"<?php echo $url ? ' href="' . esc_url( $url ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- URL is escaped immediately above. ?>>
			<span class="tutorhelper-dashboard__card-icon dashicons dashicons-<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
			<span class="tutorhelper-dashboard__card-content">
				<span class="tutorhelper-dashboard__card-label"><?php echo esc_html( $label ); ?></span>
				<strong class="tutorhelper-dashboard__card-value"><?php echo esc_html( $value ); ?></strong>
				<?php if ( $description ) : ?>
					<span class="tutorhelper-dashboard__card-description"><?php echo esc_html( $description ); ?></span>
				<?php endif; ?>
				<?php if ( $url ) : ?>
					<span class="tutorhelper-dashboard__card-link-label"><?php echo esc_html( $link_label ); ?></span>
				<?php endif; ?>
			</span>
			<?php if ( $url ) : ?>
				<span class="dashicons dashicons-arrow-right-alt2 tutorhelper-dashboard__card-arrow" aria-hidden="true"></span>
			<?php endif; ?>
		</<?php echo tag_escape( $tag ); ?>>
		<?php
	}

	/**
	 * Query bookings matching the shared filters without a page-size cap.
	 *
	 * @param array             $filters       Sanitized filters.
	 * @param DateTimeImmutable $start_utc     Inclusive UTC start.
	 * @param DateTimeImmutable $end_exclusive Exclusive UTC end.
	 * @return array
	 */
	private static function query_bookings( $filters, $start_utc, $end_exclusive ) {
		global $wpdb;

		$table = TutorHelper_Booking_Records::get_table_name();
		$where = array( 'booking_start >= %s', 'booking_start < %s' );
		$args  = array( $table, $start_utc->format( 'Y-m-d H:i:s' ), $end_exclusive->format( 'Y-m-d H:i:s' ) );

		$optional = array(
			'student_id'      => 'student_user_id',
			'tutor_id'        => 'tutor_user_id',
			'booking_type_id' => 'booking_type_id',
		);
		foreach ( $optional as $filter_key => $column ) {
			if ( ! empty( $filters[ $filter_key ] ) ) {
				$where[] = $column . ' = %d';
				$args[]  = absint( $filters[ $filter_key ] );
			}
		}
		if ( $filters['status'] ) {
			$where[] = 'status = %s';
			$args[]  = $filters['status'];
		}

		$sql = 'SELECT * FROM %i WHERE ' . implode( ' AND ', $where ) . ' ORDER BY booking_start ASC';

		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Fixed query fragments are assembled above; every value is passed to prepare().
			$wpdb->prepare( $sql, $args ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Query fragments are fixed above and values are prepared.
		);
	}

	/**
	 * Count student accounts created during the report period.
	 *
	 * @param array $context Dashboard context.
	 * @return int
	 */
	private static function count_new_students( $context ) {
		$args = array(
			'role'         => TutorHelper_Students::STUDENT_ROLE,
			'fields'       => 'ids',
			'date_query'   => array(
				array(
					'after'     => $context['start_local']->format( 'Y-m-d 00:00:00' ),
					'before'    => $context['end_local']->format( 'Y-m-d 23:59:59' ),
					'inclusive' => true,
				),
			),
		);
		if ( $context['filters']['student_id'] ) {
			$args['include'] = array( $context['filters']['student_id'] );
		}
		return count( get_users( $args ) );
	}

	/** Read and validate a date filter. */
	private static function read_date_filter( $key, $fallback ) {
		$value = isset( $_GET[ $key ] ) && ! is_array( $_GET[ $key ] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
			? sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
			: $fallback;
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : $fallback;
	}

	/** Read an integer filter. */
	private static function read_id_filter( $key ) {
		return isset( $_GET[ $key ] ) && ! is_array( $_GET[ $key ] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
			? absint( wp_unslash( $_GET[ $key ] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
			: 0;
	}

	/** Read a supported booking status filter. */
	private static function read_status_filter() {
		$status = isset( $_GET['dashboard_status'] ) && ! is_array( $_GET['dashboard_status'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
			? sanitize_key( wp_unslash( $_GET['dashboard_status'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
			: '';
		return in_array( $status, array( 'confirmed', 'unconfirmed', 'cancelled' ), true ) ? $status : '';
	}

	/** Create a local midnight date object, falling back safely. */
	private static function date_object( $date, $timezone ) {
		$object = DateTimeImmutable::createFromFormat( '!Y-m-d', $date, $timezone );
		return $object ? $object : new DateTimeImmutable( 'today', $timezone );
	}

	/** Return the dashboard URL. */
	public static function get_dashboard_url() {
		return add_query_arg( 'page', TutorHelper_Admin::MENU_SLUG, admin_url( 'admin.php' ) );
	}

	/** Return the canonical Booking Hub URL. */
	public static function get_booking_hub_url() {
		return add_query_arg(
			array(
				'page' => TutorHelper_Admin::MENU_SLUG,
				'tab'  => TutorHelper_Booking_Hub::DEFAULT_TAB,
			),
			admin_url( 'admin.php' )
		);
	}
}
