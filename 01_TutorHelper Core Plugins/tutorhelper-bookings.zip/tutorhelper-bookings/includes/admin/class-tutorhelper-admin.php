<?php
/**
 * TutorHelper admin menu controller.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the shared TutorHelper admin menu.
 */
final class TutorHelper_Admin {

	/** Main TutorHelper menu slug. */
	const MENU_SLUG = 'tutorhelper';

	/** Capability required to manage TutorHelper Bookings. */
	const CAPABILITY = 'manage_options';

	/** Register WordPress hooks. */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
	}

	/** Register the top-level TutorHelper dashboard. */
	public static function register_menu() {
		add_menu_page(
			__( 'TutorHelper Dashboard', 'tutorhelper-bookings' ),
			__( 'TutorHelper', 'tutorhelper-bookings' ),
			self::CAPABILITY,
			self::MENU_SLUG,
			array( 'TutorHelper_Dashboard', 'render_controller' ),
			'dashicons-chart-area',
			30
		);
	}

	/**
	 * Backwards-compatible callback for integrations using the old method.
	 *
	 * @return void
	 */
	public static function render_dashboard() {
		TutorHelper_Dashboard::render_controller();
	}

	/** Return the Booking Types admin URL. */
	public static function get_booking_types_url() {
		return add_query_arg(
			array( 'page' => TutorHelper_Booking_Types_Admin::PAGE_SLUG ),
			admin_url( 'admin.php' )
		);
	}
}
