<?php
/**
 * TutorHelper informational admin pages.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders TutorHelper About, Help and Upgrade links.
 */
final class TutorHelper_Admin_Pages {

	/**
	 * About page slug.
	 *
	 * @var string
	 */
	const ABOUT_PAGE_SLUG =
		'tutorhelper-about';

	/**
	 * Help page slug.
	 *
	 * @var string
	 */
	const HELP_PAGE_SLUG =
		'tutorhelper-help';

	/**
	 * Upgrade menu placeholder slug.
	 *
	 * WordPress requires a menu slug when registering the item.
	 * The menu URL is replaced with the TutorHelper website later.
	 *
	 * @var string
	 */
	const UPGRADE_PAGE_SLUG =
		'tutorhelper-upgrade';

	/**
	 * TutorHelper website URL.
	 *
	 * @var string
	 */
	const UPGRADE_URL =
		'https://www.tutorhelper.co.uk/';

    /**
     * TutorHelper YouTube channel.
     *
     * @var string
     */
    const YOUTUBE_URL =
        'https://www.youtube.com/@TutorHelperSoftware';

    /**
     * TutorHelper website help URL.
     *
     * @var string
     */
    const HELP_URL =
        'https://www.tutorhelper.co.uk/';



	/**
	 * Initialise admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'admin_menu',
			array(
				__CLASS__,
				'register_menu',
			),
			30
		);

		add_action(
			'admin_menu',
			array(
				__CLASS__,
				'replace_upgrade_menu_url',
			),
			999
		);

		add_action(
			'admin_enqueue_scripts',
			array(
				__CLASS__,
				'enqueue_assets',
			)
		);
	}

	/**
	 * Register informational TutorHelper submenu pages.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_submenu_page(
			TutorHelper_Admin::MENU_SLUG,
			__(
				'About TutorHelper',
				'tutorhelper-bookings'
			),
			__(
				'About',
				'tutorhelper-bookings'
			),
			TutorHelper_Admin::CAPABILITY,
			self::ABOUT_PAGE_SLUG,
			array(
				__CLASS__,
				'render_about_page',
			)
		);

		add_submenu_page(
			TutorHelper_Admin::MENU_SLUG,
			__(
				'TutorHelper Help',
				'tutorhelper-bookings'
			),
			__(
				'Help',
				'tutorhelper-bookings'
			),
			TutorHelper_Admin::CAPABILITY,
			self::HELP_PAGE_SLUG,
			array(
				__CLASS__,
				'render_help_page',
			)
		);

		add_submenu_page(
			TutorHelper_Admin::MENU_SLUG,
			__(
				'Upgrade TutorHelper',
				'tutorhelper-bookings'
			),
			__(
				'Upgrade ↗',
				'tutorhelper-bookings'
			),
			TutorHelper_Admin::CAPABILITY,
			self::UPGRADE_PAGE_SLUG,
			'__return_null'
		);
	}

	/**
	 * Replace the temporary Upgrade admin URL with the website.
	 *
	 * @return void
	 */
	public static function replace_upgrade_menu_url() {
		global $submenu;

		if (
			empty(
				$submenu[
					TutorHelper_Admin::MENU_SLUG
				]
			)
			|| ! is_array(
				$submenu[
					TutorHelper_Admin::MENU_SLUG
				]
			)
		) {
			return;
		}

		foreach (
			$submenu[
				TutorHelper_Admin::MENU_SLUG
			]
			as &$menu_item
		) {
			if (
				! isset( $menu_item[2] )
				|| self::UPGRADE_PAGE_SLUG
				!== $menu_item[2]
			) {
				continue;
			}

			$menu_item[2] =
				self::UPGRADE_URL;

			break;
		}

		unset( $menu_item );
	}

	/**
	 * Load TutorHelper styling on About and Help.
	 *
	 * @param string $hook_suffix Current WordPress admin hook.
	 *
	 * @return void
	 */
	public static function enqueue_assets(
		$hook_suffix
	) {
		$allowed_hooks = array(
			'tutorhelper_page_'
				. self::ABOUT_PAGE_SLUG,

			'tutorhelper_page_'
				. self::HELP_PAGE_SLUG,
		);

		$is_information_page = in_array(
			$hook_suffix,
			$allowed_hooks,
			true
		);

		$is_tutorhelper_page =
			$is_information_page
			|| 'toplevel_page_' . TutorHelper_Admin::MENU_SLUG
				=== $hook_suffix
			|| 0 === strpos(
				$hook_suffix,
				TutorHelper_Admin::MENU_SLUG . '_page_'
			);

		if ( ! $is_tutorhelper_page ) {
			return;
		}

		if ( $is_information_page ) {
			$css_path =
				TUTORHELPER_BOOKINGS_PATH
				. 'assets/css/booking-hub.css';

			wp_enqueue_style(
				'tutorhelper-booking-hub',
				TUTORHELPER_BOOKINGS_URL
					. 'assets/css/booking-hub.css',
				array(),
				file_exists( $css_path )
					? (string) filemtime(
						$css_path
					)
					: TUTORHELPER_BOOKINGS_VERSION
			);
		}


		$js_path =
			TUTORHELPER_BOOKINGS_PATH
			. 'assets/js/admin-pages.js';

		wp_enqueue_script(
			'tutorhelper-admin-pages',
			TUTORHELPER_BOOKINGS_URL
				. 'assets/js/admin-pages.js',
			array(),
			file_exists( $js_path )
				? (string) filemtime(
					$js_path
				)
				: TUTORHELPER_BOOKINGS_VERSION,
			true
		);

		wp_localize_script(
			'tutorhelper-admin-pages',
			'tutorhelperAdminPages',
			array(
				'upgradeUrl' => self::UPGRADE_URL,
			)
		);
	}

	/**
	 * Render the About page.
	 *
	 * @return void
	 */
	public static function render_about_page() {
		self::check_access();

		?>
		<div
			class="
				wrap
				tutorhelper-booking-hub
				tutorhelper-information-page
			"
		>
			<?php
			self::render_header(
				__(
					'About TutorHelper',
					'tutorhelper-bookings'
				),
				__(
					'Simple tools for managing tutoring without turning your website into another full-time job.',
					'tutorhelper-bookings'
				)
			);
			?>

			<div
				class="tutorhelper-hub-workspace"
			>
				<section
					class="tutorhelper-main-section"
				>
					<header
						class="
							tutorhelper-main-section__header
							is-compact
						"
					>
						<div
							class="
								tutorhelper-main-section__header-content
							"
						>
							<h2>
								<?php
								esc_html_e(
									'TutorHelper Bookings',
									'tutorhelper-bookings'
								);
								?>
							</h2>

							<p>
								<?php
								esc_html_e(
									'Core booking tools for independent tutors.',
									'tutorhelper-bookings'
								);
								?>
							</p>
						</div>
					</header>

					<div
						class="
							tutorhelper-main-section__body
							tutorhelper-information-page__body
						"
					>
						<p>
                            <?php
                            esc_html_e(
                                'TutorHelper is a collection of WordPress tools created specifically for tutors who want to manage more of their teaching business from their own website.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>

                        <p>
                            <?php
                            esc_html_e(
                                'The aim is to make common tutoring tasks easier without forcing tutors into an oversized business-management system. TutorHelper focuses on practical features that fit naturally around lessons, students and an existing WordPress website.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>

                        <p>
                            <?php
                            esc_html_e(
                                'TutorHelper Bookings is the booking part of that system. It provides the Core tools needed to publish lesson availability, accept student lesson requests and manage those bookings from WordPress.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>



                        <h3>
                            <?php
                            esc_html_e(
                                'Designed around tutoring',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </h3>

                        <div
                            class="tutorhelper-information-grid"
                        >
                            <div
                                class="tutorhelper-information-card"
                            >
                                <span
                                    class="
                                        dashicons
                                        dashicons-calendar-alt
                                    "
                                    aria-hidden="true"
                                ></span>

                                <h4>
                                    <?php
                                    esc_html_e(
                                        'Manage lessons',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </h4>

                                <p>
                                    <?php
                                    esc_html_e(
                                        'Set the lessons you offer, publish your availability and manage requests from your own Booking Hub.',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </p>
                            </div>

                            <div
                                class="tutorhelper-information-card"
                            >
                                <span
                                    class="
                                        dashicons
                                        dashicons-groups
                                    "
                                    aria-hidden="true"
                                ></span>

                                <h4>
                                    <?php
                                    esc_html_e(
                                        'Support students',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </h4>

                                <p>
                                    <?php
                                    esc_html_e(
                                        'Give students a straightforward way to request lessons, check upcoming bookings and understand cancellations.',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </p>
                            </div>

                            <div
                                class="tutorhelper-information-card"
                            >
                                <span
                                    class="
                                        dashicons
                                        dashicons-admin-site-alt3
                                    "
                                    aria-hidden="true"
                                ></span>

                                <h4>
                                    <?php
                                    esc_html_e(
                                        'Keep control of your website',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </h4>

                                <p>
                                    <?php
                                    esc_html_e(
                                        'Keep your booking experience, student pages and business information within the WordPress site you already manage.',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </p>
                            </div>
                        </div>

						<h3>
							<?php
							esc_html_e(
								'What TutorHelper Bookings Core includes',
								'tutorhelper-bookings'
							);
							?>
						</h3>


						<ul class="tutorhelper-information-checklist">
                            <li>
                                <?php
                                esc_html_e(
                                    'Booking Types for the different lessons or services you offer.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </li>

                            <li>
                                <?php
                                esc_html_e(
                                    'Weekly availability and date exclusions for managing when students may request lessons.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </li>

                            <li>
                                <?php
                                esc_html_e(
                                    'A Booking Hub calendar for viewing and managing lesson requests.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </li>

                            <li>
                                <?php
                                esc_html_e(
                                    'A student booking form for requesting available lessons.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </li>

                            <li>
                                <?php
                                esc_html_e(
                                    'A student dashboard showing pending, upcoming, cancelled and previous lessons.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </li>

                            <li>
                                <?php
                                esc_html_e(
                                    'Tutor and student cancellation workflows with recorded cancellation reasons.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </li>

                            <li>
                                <?php
                                esc_html_e(
                                    'Automatic booking request, confirmation and cancellation emails.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </li>

                            <li>
                                <?php
                                esc_html_e(
                                    'Page, email and currency settings for adapting TutorHelper to your website.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </li>
                        </ul>


                        <h3>
                            <?php
                            esc_html_e(
                                'Core and Pro',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </h3>

                        <p>
                            <?php
                            esc_html_e(
                                'TutorHelper Bookings Core is intended to provide a complete basic lesson-request workflow without requiring payment features or advanced automation.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>

                        <p>
                            <?php
                            esc_html_e(
                                'TutorHelper Pro is intended for tutors who need more advanced booking tools such as payments, recurring or multiple bookings, richer booking management and additional automation.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>



                        <h3>
                            <?php
                            esc_html_e(
                                'Learn more about TutorHelper',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </h3>

                        <div
                            class="tutorhelper-information-actions"
                        >
                            <a
                                class="
                                    button
                                    tutorhelper-action-button
                                "
                                href="<?php echo esc_url(
                                    self::UPGRADE_URL
                                ); ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <span
                                    class="
                                        dashicons
                                        dashicons-admin-site-alt3
                                    "
                                    aria-hidden="true"
                                ></span>

                                <?php
                                esc_html_e(
                                    'Visit TutorHelper',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </a>

                            <a
                                class="
                                    button
                                    tutorhelper-hub-pill-button
                                "
                                href="<?php echo esc_url(
                                    self::YOUTUBE_URL
                                ); ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <span
                                    class="
                                        dashicons
                                        dashicons-video-alt3
                                    "
                                    aria-hidden="true"
                                ></span>

                                <?php
                                esc_html_e(
                                    'TutorHelper on YouTube',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </a>
                        </div>



						<h3>
							<?php
							esc_html_e(
								'Plugin information',
								'tutorhelper-bookings'
							);
							?>
						</h3>

						<p>
							<strong>
								<?php
								esc_html_e(
									'Version:',
									'tutorhelper-bookings'
								);
								?>
							</strong>

							<?php
							echo esc_html(
								TUTORHELPER_BOOKINGS_VERSION
							);
							?>
						</p>

						<p>
							<a
								class="
									button
									tutorhelper-action-button
								"
								href="<?php echo esc_url(
									self::UPGRADE_URL
								); ?>"
								target="_blank"
								rel="noopener noreferrer"
							>
								<?php
								esc_html_e(
									'Visit TutorHelper',
									'tutorhelper-bookings'
								);
								?>

								<span
									class="
										dashicons
										dashicons-external
									"
									aria-hidden="true"
								></span>
							</a>
						</p>
					</div>
				</section>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the Help page.
	 *
	 * @return void
	 */
	public static function render_help_page() {
		self::check_access();

		$settings_url =
			add_query_arg(
				array(
					'page' =>
						TutorHelper_Settings::
							PAGE_SLUG,

					'tab' =>
						'pages',
				),
				admin_url(
					'admin.php'
				)
			);

        $booking_hub_url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Admin::
                            MENU_SLUG,
                ),
                admin_url(
                    'admin.php'
                )
            );

        $youtube_url =
            self::YOUTUBE_URL;

        $diagnostics_url =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Diagnostics::
                            PAGE_SLUG,
                ),
                admin_url(
                    'tools.php'
                )
            );

		?>
		<div
			class="
				wrap
				tutorhelper-booking-hub
				tutorhelper-information-page
			"
		>
			<?php
			self::render_header(
				__(
					'TutorHelper Help',
					'tutorhelper-bookings'
				),
				__(
					'A quick guide to setting up and using TutorHelper Bookings.',
					'tutorhelper-bookings'
				)
			);
			?>

			<div
				class="tutorhelper-hub-workspace"
			>
				<section
					class="tutorhelper-main-section"
				>
					<header
						class="
							tutorhelper-main-section__header
							is-compact
						"
					>
						<div
							class="
								tutorhelper-main-section__header-content
							"
						>
							<h2>
								<?php
								esc_html_e(
									'Getting started with TutorHelper Bookings Core',
									'tutorhelper-bookings'
								);
								?>
							</h2>
						</div>
					</header>

					<div
						class="
							tutorhelper-main-section__body
							tutorhelper-information-page__body
						"
					>
						<div
                            class="tutorhelper-help-steps"
                        >
                            <div
                                class="tutorhelper-help-step"
                            >
                                <span
                                    class="tutorhelper-help-step__number"
                                >
                                    1
                                </span>

                                <div>
                                    <h3>
                                        <?php
                                        esc_html_e(
                                            'Create your Booking Types',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </h3>

                                    <p>
                                        <?php
                                        esc_html_e(
                                            'Add each type of lesson you want to offer. Set its duration, price, available locations, online-booking visibility and cancellation rules.',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </p>
                                </div>
                            </div>

                            <div
                                class="tutorhelper-help-step"
                            >
                                <span
                                    class="tutorhelper-help-step__number"
                                >
                                    2
                                </span>

                                <div>
                                    <h3>
                                        <?php
                                        esc_html_e(
                                            'Add your availability',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </h3>

                                    <p>
                                        <?php
                                        esc_html_e(
                                            'Use the Availability area to define the times you normally teach. Add exclusions for tutor leave and other dates when lessons should not be available.',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </p>
                                </div>
                            </div>

                            <div
                                class="tutorhelper-help-step"
                            >
                                <span
                                    class="tutorhelper-help-step__number"
                                >
                                    3
                                </span>

                                <div>
                                    <h3>
                                        <?php
                                        esc_html_e(
                                            'Student pages and shortcodes',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </h3>

                                    <div
                                        class="tutorhelper-shortcode-help"
                                    >
                                        <div>
                                            <h4>
                                                <?php
                                                esc_html_e(
                                                    'Lesson booking page',
                                                    'tutorhelper-bookings'
                                                );
                                                ?>
                                            </h4>

                                            <code>[tutorhelper_student_booking]</code>

                                            <p>
                                                <?php
                                                esc_html_e(
                                                    'Place this shortcode on the page students will use to request an available lesson.',
                                                    'tutorhelper-bookings'
                                                );
                                                ?>
                                            </p>
                                        </div>

                                        <div>
                                            <h4>
                                                <?php
                                                esc_html_e(
                                                    'Student dashboard page',
                                                    'tutorhelper-bookings'
                                                );
                                                ?>
                                            </h4>

                                            <code>[tutorhelper_student_dashboard]</code>

                                            <p>
                                                <?php
                                                esc_html_e(
                                                    'Place this shortcode on the page students will use to view pending requests, confirmed lessons, cancellations and lesson history.',
                                                    'tutorhelper-bookings'
                                                );
                                                ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="tutorhelper-help-step"
                            >
                                <span
                                    class="tutorhelper-help-step__number"
                                >
                                    4
                                </span>

                                <div>
                                    <h3>
                                        <?php
                                        esc_html_e(
                                            'Connect those pages to TutorHelper',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </h3>

                                    <p>
                                        <?php
                                        esc_html_e(
                                            'Open TutorHelper Settings → Pages and select your Booking, Dashboard and Login pages. TutorHelper uses these settings for student links and redirects.',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </p>
                                </div>
                            </div>

                            <div
                                class="tutorhelper-help-step"
                            >
                                <span
                                    class="tutorhelper-help-step__number"
                                >
                                    5
                                </span>

                                <div>
                                    <h3>
                                        <?php
                                        esc_html_e(
                                            'Check your email settings',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </h3>

                                    <p>
                                        <?php
                                        esc_html_e(
                                            'Review your sender details under TutorHelper Settings → Email, then check the five Booking email templates in Booking Hub → Emails.',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </p>
                                </div>
                            </div>

                            <div
                                class="tutorhelper-help-step"
                            >
                                <span
                                    class="tutorhelper-help-step__number"
                                >
                                    6
                                </span>

                                <div>
                                    <h3>
                                        <?php
                                        esc_html_e(
                                            'Test the complete student journey',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </h3>

                                    <p>
                                        <?php
                                        esc_html_e(
                                            'Before sharing the booking page with students, submit a test request, confirm it from the Booking Hub, check the student dashboard and test a cancellation.',
                                            'tutorhelper-bookings'
                                        );
                                        ?>
                                    </p>
                                </div>
                            </div>
                        </div>

						<h3>
							<?php
							esc_html_e(
								'Student shortcodes',
								'tutorhelper-bookings'
							);
							?>
						</h3>

						<p>
							<code>[tutorhelper_student_booking]</code>
							<br>
							<?php
							esc_html_e(
								'Displays the student lesson-request form.',
								'tutorhelper-bookings'
							);
							?>
						</p>

						<p>
							<code>[tutorhelper_student_dashboard]</code>
							<br>
							<?php
							esc_html_e(
								'Displays upcoming requests, lessons, cancellations and lesson history.',
								'tutorhelper-bookings'
							);
							?>
						</p>

						<h3>
							<?php
							esc_html_e(
								'Booking workflow',
								'tutorhelper-bookings'
							);
							?>
						</h3>

						<div
                            class="tutorhelper-workflow"
                        >
                            <div>
                                <strong>
                                    <?php
                                    esc_html_e(
                                        '1. Student requests a lesson',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </strong>

                                <p>
                                    <?php
                                    esc_html_e(
                                        'The request is saved as Unconfirmed and the tutor receives a new lesson request email.',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </p>
                            </div>

                            <div>
                                <strong>
                                    <?php
                                    esc_html_e(
                                        '2. Tutor reviews the request',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </strong>

                                <p>
                                    <?php
                                    esc_html_e(
                                        'Open the booking from the Booking Hub calendar and change its status to Confirmed when you are happy to accept it.',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </p>
                            </div>

                            <div>
                                <strong>
                                    <?php
                                    esc_html_e(
                                        '3. Student receives confirmation',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </strong>

                                <p>
                                    <?php
                                    esc_html_e(
                                        'The confirmed lesson appears on the student dashboard and the student receives the confirmation email.',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </p>
                            </div>

                            <div>
                                <strong>
                                    <?php
                                    esc_html_e(
                                        '4. Cancellation if needed',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </strong>

                                <p>
                                    <?php
                                    esc_html_e(
                                        'Eligible lessons may be cancelled by the student, or cancelled by the tutor from the Booking Hub. TutorHelper records the reason and sends the appropriate email notification.',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </p>
                            </div>
                        </div>

						<p>
							<a
								class="
									button
									tutorhelper-action-button
								"
								href="<?php echo esc_url(
									$settings_url
								); ?>"
							>
								<?php
								esc_html_e(
									'Configure TutorHelper pages',
									'tutorhelper-bookings'
								);
								?>
							</a>
						</p>
					</div>
				</section>
			</div>

            <h3>
                <?php
                esc_html_e(
                    'Need more help?',
                    'tutorhelper-bookings'
                );
                ?>
            </h3>

            <p>
                <?php
                esc_html_e(
                    'Visit TutorHelper online for additional guidance, updates and tutorials, or watch TutorHelper videos on YouTube.',
                    'tutorhelper-bookings'
                );
                ?>
            </p>

            <div
                class="tutorhelper-information-actions"
            >
                <a
                    class="
                        button
                        tutorhelper-action-button
                    "
                    href="<?php echo esc_url(
                        self::HELP_URL
                    ); ?>"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    <span
                        class="
                            dashicons
                            dashicons-admin-site-alt3
                        "
                        aria-hidden="true"
                    ></span>

                    <?php
                    esc_html_e(
                        'Visit TutorHelper online',
                        'tutorhelper-bookings'
                    );
                    ?>
                </a>

                <a
                    class="
                        button
                        tutorhelper-hub-pill-button
                    "
                    href="<?php echo esc_url(
                        self::YOUTUBE_URL
                    ); ?>"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    <span
                        class="
                            dashicons
                            dashicons-video-alt3
                        "
                        aria-hidden="true"
                    ></span>

                    <?php
                    esc_html_e(
                        'Watch TutorHelper on YouTube',
                        'tutorhelper-bookings'
                    );
                    ?>
                </a>
            </div>

            <h3>
                <?php
                esc_html_e(
                    'Something not working?',
                    'tutorhelper-bookings'
                );
                ?>
            </h3>

            <p>
                <?php
                esc_html_e(
                    'TutorHelper Diagnostics can check whether the essential booking setup is ready and provide technical information if you need support.',
                    'tutorhelper-bookings'
                );
                ?>
            </p>

            <p>
                <a
                    class="
                        button
                        tutorhelper-hub-pill-button
                    "
                    href="<?php
                        echo esc_url(
                            $diagnostics_url
                        );
                    ?>"
                >
                    <span
                        class="
                            dashicons
                            dashicons-admin-tools
                        "
                        aria-hidden="true"
                    ></span>

                    <?php
                    esc_html_e(
                        'Run TutorHelper Diagnostics',
                        'tutorhelper-bookings'
                    );
                    ?>
                </a>
            </p>

		</div>
		<?php
	}

	/**
	 * Render the shared information-page header.
	 *
	 * @param string $title       Page title.
	 * @param string $description Page description.
	 *
	 * @return void
	 */
	private static function render_header(
		$title,
		$description
	) {
		?>
		<header
			class="tutorhelper-booking-hub__heading"
		>
			<div>
				<h1>
					<?php
					echo esc_html(
						$title
					);
					?>
				</h1>

				<p>
					<?php
					echo esc_html(
						$description
					);
					?>
				</p>
			</div>
		</header>
		<?php
	}

	/**
	 * Check access to TutorHelper admin information.
	 *
	 * @return void
	 */
	private static function check_access() {
		if (
			current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		wp_die(
			esc_html__(
				'You do not have permission to view this TutorHelper page.',
				'tutorhelper-bookings'
			),
			esc_html__(
				'Permission denied',
				'tutorhelper-bookings'
			),
			array(
				'response' => 403,
			)
		);
	}
}
