<?php
/**
 * TutorHelper Bookings diagnostics page.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides production-safe diagnostics and log management.
 */
final class TutorHelper_Diagnostics {

	/**
	 * Diagnostics page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'tutorhelper-bookings-diagnostics';

	/** Stripe diagnostics download action. */
	const STRIPE_DOWNLOAD_ACTION = 'tutorhelper_download_stripe_log';

	/** Stripe diagnostics clear action. */
	const STRIPE_CLEAR_ACTION = 'tutorhelper_clear_stripe_log';

	/** One-off, tutor-confirmed legacy booking timestamp repair action. */
	const LEGACY_TIMESTAMP_REPAIR_ACTION =
		'tutorhelper_repair_legacy_booking_timestamp';

	/**
	 * Register diagnostics hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'admin_menu',
			array( __CLASS__, 'register_menu' )
		);

		add_action(
			'admin_post_tutorhelper_download_system_report',
			array( __CLASS__, 'download_system_report' )
		);

		add_action(
			'admin_post_tutorhelper_download_plugin_log',
			array( __CLASS__, 'download_plugin_log' )
		);

		add_action(
			'admin_post_tutorhelper_clear_plugin_log',
			array( __CLASS__, 'clear_plugin_log' )
		);

		add_action(
			'admin_post_' . self::STRIPE_DOWNLOAD_ACTION,
			array( __CLASS__, 'download_stripe_log' )
		);

		add_action(
			'admin_post_' . self::STRIPE_CLEAR_ACTION,
			array( __CLASS__, 'clear_stripe_log' )
		);

		add_action(
			'admin_post_' . self::LEGACY_TIMESTAMP_REPAIR_ACTION,
			array( __CLASS__, 'repair_legacy_booking_timestamp' )
		);

		add_action(
			'admin_enqueue_scripts',
			array(
				__CLASS__,
				'enqueue_assets',
			)
		);
	}


	/**
	 * Load TutorHelper diagnostics styling.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 *
	 * @return void
	 */
	public static function enqueue_assets(
		$hook_suffix
	) {
		$expected_hook =
			'tools_page_'
			. self::PAGE_SLUG;

		if (
			$expected_hook
			!== $hook_suffix
		) {
			return;
		}

		$css_path =
			TUTORHELPER_BOOKINGS_PATH
			. 'assets/css/diagnostics.css';

		wp_enqueue_style(
			'tutorhelper-diagnostics',
			TUTORHELPER_BOOKINGS_URL
				. 'assets/css/diagnostics.css',
			array(),
			file_exists( $css_path )
				? (string) filemtime(
					$css_path
				)
				: TUTORHELPER_BOOKINGS_VERSION
		);
	}

	/**
	 * Add the diagnostics page under Tools.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_management_page(
			__(
				'TutorHelper Diagnostics',
				'tutorhelper-bookings'
			),
			__(
				'TutorHelper Diagnostics',
				'tutorhelper-bookings'
			),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Render the diagnostics page.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to view TutorHelper diagnostics.',
					'tutorhelper-bookings'
				),
				esc_html__(
					'Permission denied',
					'tutorhelper-bookings'
				),
				array(
					'response' => 403,
				)
			);
		}

		$report =
			TutorHelper_System_Report::
				get_data();

		$readiness_checks =
			TutorHelper_System_Report::
				get_readiness_checks();

		$plain_text =
			TutorHelper_System_Report::
				get_plain_text();

		$log_entries =
			TutorHelper_Logger::
				get_recent_entries(
					100
				);

		$stripe_log_available = TutorHelper_Stripe_Log::is_enabled();
		$stripe_log_entries = $stripe_log_available
			? TutorHelper_Stripe_Log::get_recent_entries( 50 )
			: array();

		?>
		<div
			class="
				wrap
				tutorhelper-diagnostics
			"
		>
			<h1>
				<?php
				echo esc_html__(
					'TutorHelper Diagnostics',
					'tutorhelper-bookings'
				);
				?>
			</h1>

			<p>
				<?php
				echo esc_html__(
					'Use this page to review TutorHelper Bookings system information and recent technical log entries.',
					'tutorhelper-bookings'
				);
				?>
			</p>

			<div class="notice notice-info inline">
				<p>
					<?php
					echo esc_html__(
						'Diagnostic information is not sent anywhere automatically. Review the report before sharing it with support.',
						'tutorhelper-bookings'
					);
					?>
				</p>
			</div>

			<?php self::render_notice(); ?>

			<?php self::render_legacy_timestamp_repair(); ?>

			<?php
			self::render_readiness_summary(
				$readiness_checks
			);
			?>

			<details
				class="tutorhelper-diagnostics-details"
			>
				<summary
					class="tutorhelper-diagnostics-details__summary"
				>
					<span>
						<?php
						echo esc_html__(
							'Detailed system information',
							'tutorhelper-bookings'
						);
						?>
					</span>

					<small>
						<?php
						echo esc_html__(
							'Click to expand technical information for troubleshooting and support',
							'tutorhelper-bookings'
						);
						?>
					</small>
				</summary>

				<div
					class="tutorhelper-diagnostics-details__content"
				>
					<?php foreach ( $report as $section ) : ?>
						<?php
						self::render_report_section(
							$section
						);
						?>
					<?php endforeach; ?>
				</div>
			</details>

			<details
				class="tutorhelper-diagnostics-details"
			>
				<summary
					class="tutorhelper-diagnostics-details__summary"
				>
					<span>
						<?php
						echo esc_html__(
							'Support report and logs',
							'tutorhelper-bookings'
						);
						?>
					</span>

					<small>
						<?php
						echo esc_html__(
							'Click to expand information you may be asked to provide when troubleshooting TutorHelper',
							'tutorhelper-bookings'
						);
						?>
					</small>
				</summary>

				<div
					class="tutorhelper-diagnostics-details__content"
				>

					<h2>
						<?php
						echo esc_html__(
							'Copyable system report',
							'tutorhelper-bookings'
						);
						?>
					</h2>

					<p
						class="tutorhelper-diagnostics-help"
					>
						<?php
						echo esc_html__(
							'This report contains technical information about your TutorHelper installation. You can copy or download it if TutorHelper support asks you to provide a system report.',
							'tutorhelper-bookings'
						);
						?>
					</p>

					<textarea
						readonly
						rows="20"
						class="large-text code"
					><?php echo esc_textarea( $plain_text ); ?></textarea>
					

					<p>
						<a
							class="button"
							href="<?php echo esc_url( self::get_download_report_url() ); ?>"
						>
							<?php
							echo esc_html__(
								'Download system report',
								'tutorhelper-bookings'
							);
							?>
						</a>
					</p>

			

					<hr />

					<h2>
						<?php
						echo esc_html__(
							'Recent TutorHelper log entries',
							'tutorhelper-bookings'
						);
						?>
					</h2>

					<p
						class="tutorhelper-diagnostics-help"
					>
						<?php
						echo esc_html__(
							'TutorHelper records a limited technical log to help diagnose plugin problems. Review log contents before sharing them with support.',
							'tutorhelper-bookings'
						);
						?>
					</p>

					<?php self::render_log_entries( $log_entries ); ?>

					<p>
						<a
							class="button"
							href="<?php echo esc_url( self::get_download_log_url() ); ?>"
						>
							<?php
							echo esc_html__(
								'Download plugin log',
								'tutorhelper-bookings'
							);
							?>
						</a>
					</p>

					<form
						method="post"
						action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					>
						<input
							type="hidden"
							name="action"
							value="tutorhelper_clear_plugin_log"
						/>

						<?php
						wp_nonce_field(
							'tutorhelper_clear_plugin_log'
						);
						?>

						<?php
						submit_button(
							__(
								'Clear plugin log',
								'tutorhelper-bookings'
							),
							'delete',
							'submit',
							false
						);
						?>
					</form>

					<?php
					if ( $stripe_log_available ) {
						self::render_stripe_log_section( $stripe_log_entries );
					}
					?>
				</div>
			</details>
		</div>
		<?php
	}


	/**
	 * Render the intentionally manual legacy-timestamp repair tool.
	 *
	 * @return void
	 */
	private static function render_legacy_timestamp_repair() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- This GET request only previews a repair; the write has its own nonce.
		$booking_id = isset( $_GET['legacy_booking_id'] )
			&& ! is_array( $_GET['legacy_booking_id'] )
			? absint( wp_unslash( $_GET['legacy_booking_id'] ) )
			: 0;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$preview = $booking_id
			? TutorHelper_Booking_Records::get_legacy_timestamp_repair_preview( $booking_id )
			: null;
		?>
		<details class="tutorhelper-diagnostics-details">
			<summary class="tutorhelper-diagnostics-details__summary">
				<span><?php esc_html_e( 'Legacy booking time repair', 'tutorhelper-bookings' ); ?></span>
				<small><?php esc_html_e( 'Use only for a booking that is exactly one hour out during British Summer Time.', 'tutorhelper-bookings' ); ?></small>
			</summary>
			<div class="tutorhelper-diagnostics-details__content">
				<p><?php esc_html_e( 'Older bookings may have saved local time in fields that are now correctly treated as UTC. This tool shows the proposed correction before you confirm it. It never changes bookings automatically.', 'tutorhelper-bookings' ); ?></p>
				<form method="get" action="<?php echo esc_url( admin_url( 'tools.php' ) ); ?>">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
					<label for="tutorhelper-legacy-booking-id"><strong><?php esc_html_e( 'Booking ID', 'tutorhelper-bookings' ); ?></strong></label>
					<input id="tutorhelper-legacy-booking-id" type="number" min="1" name="legacy_booking_id" value="<?php echo esc_attr( $booking_id ); ?>" class="small-text" required />
					<?php submit_button( __( 'Preview time correction', 'tutorhelper-bookings' ), 'secondary', 'submit', false ); ?>
				</form>
				<?php if ( $preview instanceof WP_Error ) : ?>
					<div class="notice notice-warning inline"><p><?php echo esc_html( $preview->get_error_message() ); ?></p></div>
				<?php elseif ( is_array( $preview ) ) : ?>
					<?php
					$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
					?>
					<table class="widefat striped">
						<thead><tr><th><?php esc_html_e( 'Interpretation', 'tutorhelper-bookings' ); ?></th><th><?php esc_html_e( 'Start', 'tutorhelper-bookings' ); ?></th><th><?php esc_html_e( 'End', 'tutorhelper-bookings' ); ?></th></tr></thead>
						<tbody>
							<tr><td><?php esc_html_e( 'Current display', 'tutorhelper-bookings' ); ?></td><td><?php echo esc_html( wp_date( $format, $preview['current_start_local']->getTimestamp(), $preview['current_start_local']->getTimezone() ) ); ?></td><td><?php echo esc_html( wp_date( $format, $preview['current_end_local']->getTimestamp(), $preview['current_end_local']->getTimezone() ) ); ?></td></tr>
							<tr><td><strong><?php esc_html_e( 'Corrected display', 'tutorhelper-bookings' ); ?></strong></td><td><strong><?php echo esc_html( wp_date( $format, $preview['repaired_start_local']->getTimestamp(), $preview['repaired_start_local']->getTimezone() ) ); ?></strong></td><td><strong><?php echo esc_html( wp_date( $format, $preview['repaired_end_local']->getTimestamp(), $preview['repaired_end_local']->getTimezone() ) ); ?></strong></td></tr>
						</tbody>
					</table>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::LEGACY_TIMESTAMP_REPAIR_ACTION ); ?>" />
						<input type="hidden" name="booking_id" value="<?php echo esc_attr( $booking_id ); ?>" />
						<?php wp_nonce_field( self::LEGACY_TIMESTAMP_REPAIR_ACTION ); ?>
						<p><label><input type="checkbox" name="confirm_legacy_timestamp_repair" value="1" required /> <?php esc_html_e( 'I have checked the corrected time and want to repair this one booking.', 'tutorhelper-bookings' ); ?></label></p>
						<?php submit_button( __( 'Repair this booking time', 'tutorhelper-bookings' ), 'primary', 'submit', false ); ?>
					</form>
				<?php endif; ?>
			</div>
		</details>
		<?php
	}

	/**
	 * Handle a tutor-confirmed legacy timestamp repair.
	 *
	 * @return void
	 */
	public static function repair_legacy_booking_timestamp() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to repair TutorHelper booking times.', 'tutorhelper-bookings' ), esc_html__( 'Permission denied', 'tutorhelper-bookings' ), array( 'response' => 403 ) );
		}

		check_admin_referer( self::LEGACY_TIMESTAMP_REPAIR_ACTION );
		$booking_id = isset( $_POST['booking_id'] ) && ! is_array( $_POST['booking_id'] )
			? absint( wp_unslash( $_POST['booking_id'] ) )
			: 0;
		$confirmed = isset( $_POST['confirm_legacy_timestamp_repair'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['confirm_legacy_timestamp_repair'] ) );

		if ( ! $booking_id || ! $confirmed ) {
			self::redirect_with_legacy_repair_notice( $booking_id, 'legacy_timestamp_repair_confirmation_missing' );
		}

		$result = TutorHelper_Booking_Records::repair_legacy_local_timestamp( $booking_id );
		if ( is_wp_error( $result ) ) {
			self::redirect_with_legacy_repair_notice( $booking_id, $result->get_error_code() );
		}

		self::redirect_with_legacy_repair_notice( $booking_id, 'legacy_timestamp_repaired' );
	}


	/**
	 * Render the TutorHelper Core readiness summary.
	 *
	 * @param array $checks Readiness checks.
	 *
	 * @return void
	 */
	private static function render_readiness_summary(
		$checks
	) {
		$checks =
			is_array( $checks )
				? $checks
				: array();

		$problem_count =
			0;

		$attention_count =
			0;

		foreach ( $checks as $check ) {
			$status =
				isset(
					$check['status']
				)
					? sanitize_key(
						$check['status']
					)
					: 'attention';

			if ( 'problem' === $status ) {
				++$problem_count;
			} elseif (
				'attention' === $status
			) {
				++$attention_count;
			}
		}

		if ( $problem_count ) {
			$summary_status =
				'problem';

			$summary_heading =
				__(
					'TutorHelper needs attention',
					'tutorhelper-bookings'
				);

			$summary_message =
				sprintf(
					/* translators: %d: Number of readiness problems. */
					_n(
						'%d setup problem should be resolved before students use online booking.',
						'%d setup problems should be resolved before students use online booking.',
						$problem_count,
						'tutorhelper-bookings'
					),
					$problem_count
				);
		} elseif ( $attention_count ) {
			$summary_status =
				'attention';

			$summary_heading =
				__(
					'TutorHelper Core is ready',
					'tutorhelper-bookings'
				);

			$summary_message =
				__(
					'The essential booking setup is ready. A few optional recommendations are shown below.',
					'tutorhelper-bookings'
				);
		} else {
			$summary_status =
				'ready';

			$summary_heading =
				__(
					'TutorHelper Core is ready',
					'tutorhelper-bookings'
				);

			$summary_message =
				__(
					'The essential TutorHelper booking configuration passed all readiness checks.',
					'tutorhelper-bookings'
				);
		}

		?>
		<section
			class="
				tutorhelper-diagnostics-readiness
				tutorhelper-diagnostics-readiness--<?php
					echo esc_attr(
						$summary_status
					);
				?>
			"
		>
			<header
				class="tutorhelper-diagnostics-readiness__header"
			>
				<div
					class="tutorhelper-diagnostics-readiness__summary-icon"
					aria-hidden="true"
				>
					<?php
					if ( 'ready' === $summary_status ) {
						echo '✓';
					} elseif (
						'attention'
						=== $summary_status
					) {
						echo '!';
					} else {
						echo '×';
					}
					?>
				</div>

				<div>
					<h2>
						<?php
						echo esc_html(
							$summary_heading
						);
						?>
					</h2>

					<p>
						<?php
						echo esc_html(
							$summary_message
						);
						?>
					</p>
				</div>
			</header>

			<div
				class="tutorhelper-diagnostics-readiness__checks"
			>
				<?php foreach ( $checks as $check ) : ?>
					<?php
					$status =
						isset(
							$check['status']
						)
							? sanitize_key(
								$check['status']
							)
							: 'attention';

					$label =
						isset(
							$check['label']
						)
							? $check['label']
							: '';

					$message =
						isset(
							$check['message']
						)
							? $check['message']
							: '';

					$action_url =
						isset(
							$check[
								'action_url'
							]
						)
							? $check[
								'action_url'
							]
							: '';

					$action_label =
						isset(
							$check[
								'action_label'
							]
						)
							? $check[
								'action_label'
							]
							: '';
					?>

					<div
						class="
							tutorhelper-diagnostics-check
							tutorhelper-diagnostics-check--<?php
								echo esc_attr(
									$status
								);
							?>
						"
					>
						<span
							class="tutorhelper-diagnostics-check__icon"
							aria-hidden="true"
						>
							<?php
							if ( 'ready' === $status ) {
								echo '✓';
							} elseif (
								'attention'
								=== $status
							) {
								echo '!';
							} else {
								echo '×';
							}
							?>
						</span>

						<div
							class="tutorhelper-diagnostics-check__content"
						>
							<strong>
								<?php
								echo esc_html(
									$label
								);
								?>
							</strong>

							<p>
								<?php
								echo esc_html(
									$message
								);
								?>
							</p>
						</div>

						<?php
						if (
							'' !== $action_url
							&& ''
								!== $action_label
						) :
							?>
							<a
								class="
									button
									tutorhelper-hub-pill-button
								"
								href="<?php
									echo esc_url(
										$action_url
									);
								?>"
							>
								<?php
								echo esc_html(
									$action_label
								);
								?>
							</a>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</section>
		<?php
	}



	/**
	 * Render one system report section.
	 *
	 * @param array $section Report section.
	 *
	 * @return void
	 */
	private static function render_report_section( $section ) {
		$label = isset( $section['label'] )
			? $section['label']
			: '';

		$items = isset( $section['items'] )
			&& is_array( $section['items'] )
			? $section['items']
			: array();

		?>
		<h3><?php echo esc_html( $label ); ?></h3>

		<table
			class="
				widefat
				striped
				tutorhelper-diagnostics-table
			"
		>
			<tbody>
				<?php foreach ( $items as $item_label => $value ) : ?>
					<tr>
						<th
							scope="row"
							class="tutorhelper-diagnostics-table__label"
						>
							<?php echo esc_html( $item_label ); ?>
						</th>
						<td>
							<?php echo esc_html( $value ); ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}


	/**
	 * Render the optional Stripe Payment Log supplied by TutorHelper Pro.
	 *
	 * @param array $entries Recent Stripe diagnostic entries.
	 * @return void
	 */
	private static function render_stripe_log_section( $entries ) {
		?>
		<hr />

		<h2>
			<?php echo esc_html__( 'Stripe Payment Log', 'tutorhelper-bookings' ); ?>
		</h2>

		<p class="tutorhelper-diagnostics-help">
			<?php
			echo esc_html__(
				'This separate log records the outcome of TutorHelper Stripe webhooks without storing payment card details, secrets or raw webhook data.',
				'tutorhelper-bookings'
			);
			?>
		</p>

		<?php self::render_stripe_log_entries( $entries ); ?>

		<p>
			<a
				class="button"
				href="<?php echo esc_url( self::get_download_stripe_log_url() ); ?>"
			>
				<?php echo esc_html__( 'Download Stripe Log', 'tutorhelper-bookings' ); ?>
			</a>
		</p>

		<form
			method="post"
			action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
		>
			<input
				type="hidden"
				name="action"
				value="<?php echo esc_attr( self::STRIPE_CLEAR_ACTION ); ?>"
			/>

			<?php wp_nonce_field( self::STRIPE_CLEAR_ACTION ); ?>

			<?php
			submit_button(
				__( 'Clear Stripe Log', 'tutorhelper-bookings' ),
				'delete',
				'submit',
				false
			);
			?>
		</form>
		<?php
	}

	/**
	 * Render recent Stripe webhook outcomes.
	 *
	 * @param array $entries Stripe diagnostic entries.
	 * @return void
	 */
	private static function render_stripe_log_entries( $entries ) {
		if ( empty( $entries ) ) {
			echo '<p>';
			echo esc_html__(
				'No Stripe webhook entries have been recorded yet.',
				'tutorhelper-bookings'
			);
			echo '</p>';

			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php echo esc_html__( 'UTC time', 'tutorhelper-bookings' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Event', 'tutorhelper-bookings' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Booking', 'tutorhelper-bookings' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'HTTP response', 'tutorhelper-bookings' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Outcome', 'tutorhelper-bookings' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Interpretation', 'tutorhelper-bookings' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $entries as $entry ) : ?>
					<tr>
						<td><?php echo esc_html( isset( $entry['timestamp'] ) ? $entry['timestamp'] : '' ); ?></td>
						<td>
							<?php
							$event_type = isset( $entry['event_type'] ) ? $entry['event_type'] : '';
							$event_id = isset( $entry['event_id'] ) ? $entry['event_id'] : '';
							echo esc_html( '' !== $event_type ? $event_type : __( 'Unverified request', 'tutorhelper-bookings' ) );
							if ( '' !== $event_id ) {
								echo '<br /><code>' . esc_html( $event_id ) . '</code>';
							}
							?>
						</td>
						<td><?php echo esc_html( ! empty( $entry['booking_id'] ) ? '#' . absint( $entry['booking_id'] ) : '—' ); ?></td>
						<td><?php echo esc_html( ! empty( $entry['http_status'] ) ? absint( $entry['http_status'] ) : '—' ); ?></td>
						<td><?php echo esc_html( isset( $entry['outcome'] ) ? ucfirst( $entry['outcome'] ) : '' ); ?></td>
						<td>
							<?php
							echo esc_html( isset( $entry['interpretation'] ) ? $entry['interpretation'] : '' );
							if ( ! empty( $entry['error'] ) ) {
								echo '<br /><code>' . esc_html( $entry['error'] ) . '</code>';
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Render recent plugin log entries.
	 *
	 * @param array $entries Log entries.
	 *
	 * @return void
	 */
	private static function render_log_entries( $entries ) {
		if ( empty( $entries ) ) {
			echo '<p>';
			echo esc_html__(
				'No TutorHelper log entries have been recorded.',
				'tutorhelper-bookings'
			);
			echo '</p>';

			return;
		}

		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col">
						<?php
						echo esc_html__(
							'UTC time',
							'tutorhelper-bookings'
						);
						?>
					</th>
					<th scope="col">
						<?php
						echo esc_html__(
							'Level',
							'tutorhelper-bookings'
						);
						?>
					</th>
					<th scope="col">
						<?php
						echo esc_html__(
							'Message',
							'tutorhelper-bookings'
						);
						?>
					</th>
					<th scope="col">
						<?php
						echo esc_html__(
							'Context',
							'tutorhelper-bookings'
						);
						?>
					</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $entries as $entry ) : ?>
					<tr>
						<td>
							<?php
							echo esc_html(
								isset( $entry['timestamp'] )
									? $entry['timestamp']
									: ''
							);
							?>
						</td>
						<td>
							<?php
							echo esc_html(
								isset( $entry['level'] )
									? strtoupper(
										$entry['level']
									)
									: ''
							);
							?>
						</td>
						<td>
							<?php
							echo esc_html(
								isset( $entry['message'] )
									? $entry['message']
									: ''
							);
							?>
						</td>
						<td>
							<code>
								<?php
								echo esc_html(
									isset( $entry['context'] )
										? wp_json_encode(
											$entry['context']
										)
										: ''
								);
								?>
							</code>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Download the system report.
	 *
	 * @return void
	 */
	public static function download_system_report() {
		self::verify_admin_request(
			'tutorhelper_download_system_report'
		);

		header( 'Content-Type: text/plain; charset=utf-8' );
		header(
			'Content-Disposition: attachment; filename="tutorhelper-system-report.txt"'
		);

		echo esc_html(
			TutorHelper_System_Report::get_plain_text()
		);
		
		exit;
	}

	/**
	 * Download the active plugin log.
	 *
	 * @return void
	 */
	public static function download_plugin_log() {
		self::verify_admin_request(
			'tutorhelper_download_plugin_log'
		);

		$contents =
			TutorHelper_Logger::get_log_contents();

		if ( '' === $contents ) {
			wp_die(
				esc_html__(
					'No readable TutorHelper log file was found.',
					'tutorhelper-bookings'
				)
			);
		}

		header(
			'Content-Type: text/plain; charset=utf-8'
		);

		header(
			'Content-Disposition: attachment; filename="tutorhelper-bookings.log"'
		);

		echo esc_html( $contents );
		exit;
	}

	/**
	 * Clear the active and rotated plugin logs.
	 *
	 * @return void
	 */
	public static function clear_plugin_log() {
		self::verify_admin_request(
			'tutorhelper_clear_plugin_log'
		);

		$cleared = TutorHelper_Logger::clear();

		self::redirect_with_notice(
			$cleared
				? 'log_cleared'
				: 'log_clear_failed'
		);
	}


	/**
	 * Download all retained Stripe diagnostic records.
	 *
	 * @return void
	 */
	public static function download_stripe_log() {
		self::verify_admin_request( self::STRIPE_DOWNLOAD_ACTION );

		$contents = TutorHelper_Stripe_Log::get_log_contents();

		if ( '' === $contents ) {
			wp_die(
				esc_html__(
					'No readable Stripe log file was found.',
					'tutorhelper-bookings'
				)
			);
		}

		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="tutorhelper-stripe.log"' );

		echo $contents; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The download contains only internally generated, sanitised JSON diagnostic records.
		exit;
	}

	/**
	 * Clear only Stripe diagnostic records.
	 *
	 * @return void
	 */
	public static function clear_stripe_log() {
		self::verify_admin_request( self::STRIPE_CLEAR_ACTION );

		self::redirect_with_notice(
			TutorHelper_Stripe_Log::clear()
				? 'stripe_log_cleared'
				: 'stripe_log_clear_failed'
		);
	}

	/**
	 * Verify an administrator action and nonce.
	 *
	 * @param string $nonce_action Nonce action.
	 *
	 * @return void
	 */
	private static function verify_admin_request( $nonce_action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to manage TutorHelper diagnostics.',
					'tutorhelper-bookings'
				),
				esc_html__(
					'Permission denied',
					'tutorhelper-bookings'
				),
				array(
					'response' => 403,
				)
			);
		}

		check_admin_referer( $nonce_action );
	}

	/**
	 * Return the system report download URL.
	 *
	 * @return string
	 */
	private static function get_download_report_url() {
		return wp_nonce_url(
			admin_url(
				'admin-post.php?action=tutorhelper_download_system_report'
			),
			'tutorhelper_download_system_report'
		);
	}

	/**
	 * Return the plugin log download URL.
	 *
	 * @return string
	 */
	private static function get_download_log_url() {
		return wp_nonce_url(
			admin_url(
				'admin-post.php?action=tutorhelper_download_plugin_log'
			),
			'tutorhelper_download_plugin_log'
		);
	}


	/**
	 * Return the Stripe log download URL.
	 *
	 * @return string
	 */
	private static function get_download_stripe_log_url() {
		return wp_nonce_url(
			admin_url(
				'admin-post.php?action=' . self::STRIPE_DOWNLOAD_ACTION
			),
			self::STRIPE_DOWNLOAD_ACTION
		);
	}

	/**
	 * Redirect to the diagnostics page with a notice.
	 *
	 * @param string $notice Notice code.
	 *
	 * @return void
	 */
	private static function redirect_with_notice( $notice ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'               => self::PAGE_SLUG,
					'tutorhelper_notice' => sanitize_key(
						$notice
					),
				),
				admin_url( 'tools.php' )
			)
		);

		exit;
	}

	/**
	 * Redirect to the preview with a legacy-timestamp repair notice.
	 *
	 * @param int    $booking_id Booking ID.
	 * @param string $notice     Notice code.
	 * @return void
	 */
	private static function redirect_with_legacy_repair_notice( $booking_id, $notice ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => self::PAGE_SLUG,
					'legacy_booking_id' => absint( $booking_id ),
					'tutorhelper_notice' => sanitize_key( $notice ),
				),
				admin_url( 'tools.php' )
			)
		);
		exit;
	}


	/**
	 * Render a diagnostics action notice.
	 *
	 * @return void
	 */
	private static function render_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only notice key used only to render feedback after a nonce-protected diagnostics action.
		if ( ! isset( $_GET['tutorhelper_notice'] ) ) {
			return;
		}

		$notice = sanitize_key(
			wp_unslash( $_GET['tutorhelper_notice'] )
		);
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$notices = array(
			'log_cleared' => array(
				'class'   => 'notice notice-success inline',
				'message' => __(
					'The TutorHelper log was cleared.',
					'tutorhelper-bookings'
				),
			),
			'log_clear_failed' => array(
				'class'   => 'notice notice-error inline',
				'message' => __(
					'The TutorHelper log could not be cleared.',
					'tutorhelper-bookings'
				),
			),
			'stripe_log_cleared' => array(
				'class'   => 'notice notice-success inline',
				'message' => __( 'The Stripe Payment Log was cleared.', 'tutorhelper-bookings' ),
			),
			'stripe_log_clear_failed' => array(
				'class'   => 'notice notice-error inline',
				'message' => __( 'The Stripe Payment Log could not be cleared.', 'tutorhelper-bookings' ),
			),
			'legacy_timestamp_repaired' => array(
				'class' => 'notice notice-success inline',
				'message' => __( 'The legacy booking time was repaired. Review any linked calendar event to confirm its displayed time.', 'tutorhelper-bookings' ),
			),
			'legacy_timestamp_repair_confirmation_missing' => array(
				'class' => 'notice notice-error inline',
				'message' => __( 'Confirm the displayed corrected time before repairing a booking.', 'tutorhelper-bookings' ),
			),
			'legacy_timestamp_booking_missing' => array(
				'class' => 'notice notice-error inline',
				'message' => __( 'The booking could not be found.', 'tutorhelper-bookings' ),
			),
			'legacy_timestamp_not_applicable' => array(
				'class' => 'notice notice-warning inline',
				'message' => __( 'This booking does not have a daylight-saving offset that can be repaired.', 'tutorhelper-bookings' ),
			),
			'legacy_timestamp_repair_failed' => array(
				'class' => 'notice notice-error inline',
				'message' => __( 'The booking time changed before the repair could be saved. Refresh and try again.', 'tutorhelper-bookings' ),
			),
			'legacy_timestamp_invalid' => array(
				'class' => 'notice notice-error inline',
				'message' => __( 'The booking date or timezone could not be prepared for repair.', 'tutorhelper-bookings' ),
			),
		);

		if ( ! isset( $notices[ $notice ] ) ) {
			return;
		}

		echo '<div class="';
		echo esc_attr( $notices[ $notice ]['class'] );
		echo '"><p>';
		echo esc_html( $notices[ $notice ]['message'] );
		echo '</p></div>';
	}


	

}
