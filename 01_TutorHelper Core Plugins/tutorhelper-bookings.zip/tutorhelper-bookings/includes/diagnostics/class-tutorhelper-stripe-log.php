<?php
/**
 * Stripe payment diagnostics log.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores privacy-conscious Stripe webhook outcomes independently of the
 * general TutorHelper diagnostic log.
 */
final class TutorHelper_Stripe_Log {

	/** Maximum active log size before rotation. */
	const MAX_FILE_SIZE = 1048576;

	/** Maximum retained size across the active and rotated Stripe logs. */
	const MAX_RETAINED_SIZE = 2097152;

	/** Number of days to retain Stripe diagnostic entries. */
	const RETENTION_DAYS = 30;

	/** Daily retention event hook. */
	const RETENTION_HOOK = 'tutorhelper_stripe_log_retention';

	/**
	 * Register background retention.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			self::RETENTION_HOOK,
			array( __CLASS__, 'purge_expired_entries' )
		);

		add_action(
			'init',
			array( __CLASS__, 'schedule_retention' )
		);

		add_action(
			'init',
			array( __CLASS__, 'prepare_enabled_log' ),
			20
		);
	}


	/**
	 * Create the empty protected Stripe log once a configured Pro integration
	 * is available, so Diagnostics can show an intentional empty state.
	 *
	 * @return void
	 */
	public static function prepare_enabled_log() {
		if ( ! self::is_enabled() || ! self::prepare_log_directory() ) {
			return;
		}

		$file = self::get_log_file_path();

		if ( file_exists( $file ) ) {
			return;
		}

		file_put_contents( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Creates the empty, protected TutorHelper-owned Stripe diagnostic log.
			$file,
			'',
			LOCK_EX
		);
	}

	/**
	 * Schedule the daily retention event when it has not yet been scheduled.
	 *
	 * @return void
	 */
	public static function schedule_retention() {
		if ( wp_next_scheduled( self::RETENTION_HOOK ) ) {
			return;
		}

		wp_schedule_event(
			time() + HOUR_IN_SECONDS,
			'daily',
			self::RETENTION_HOOK
		);
	}

	/**
	 * Return whether Stripe diagnostics may be displayed and written.
	 *
	 * Core stays independent from Pro by using an integration filter.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) apply_filters(
			'tutorhelper_stripe_diagnostics_enabled',
			false
		);
	}

	/**
	 * Record one sanitised Stripe webhook outcome.
	 *
	 * @param array $entry Stripe webhook diagnostic data.
	 * @return bool
	 */
	public static function record( $entry ) {
		if ( ! self::is_enabled() || ! is_array( $entry ) ) {
			return false;
		}

		$entry = self::normalise_entry( $entry );

		if ( '' === $entry['outcome'] || '' === $entry['interpretation'] ) {
			return false;
		}

		if ( ! self::prepare_log_directory() ) {
			return false;
		}

		/*
		 * Retention runs before rotation so that old records do not consume
		 * the bounded log capacity indefinitely.
		 */
		self::purge_expired_entries();
		self::rotate_if_required();

		$encoded = wp_json_encode(
			$entry,
			JSON_UNESCAPED_SLASHES
		);

		if ( false === $encoded ) {
			return false;
		}

		$result = file_put_contents( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Webhook logging requires an atomic append with an exclusive lock.
			self::get_log_file_path(),
			$encoded . PHP_EOL,
			FILE_APPEND | LOCK_EX
		);

		return false !== $result;
	}

	/**
	 * Return the most recent Stripe log entries, newest first.
	 *
	 * @param int $limit Maximum number of entries.
	 * @return array
	 */
	public static function get_recent_entries( $limit = 50 ) {
		$limit = max( 1, min( 500, absint( $limit ) ) );
		$entries = self::get_all_entries();

		if ( empty( $entries ) ) {
			return array();
		}

		$entries = array_slice( $entries, -$limit );

		return array_reverse( $entries );
	}

	/**
	 * Return all retained Stripe records for a diagnostic download.
	 *
	 * @return string
	 */
	public static function get_log_contents() {
		$entries = self::get_all_entries();

		if ( empty( $entries ) ) {
			return '';
		}

		$lines = array();

		foreach ( $entries as $entry ) {
			$encoded = wp_json_encode(
				$entry,
				JSON_UNESCAPED_SLASHES
			);

			if ( false !== $encoded ) {
				$lines[] = $encoded;
			}
		}

		return implode( PHP_EOL, $lines ) . PHP_EOL;
	}

	/**
	 * Clear only the active and rotated Stripe logs.
	 *
	 * @return bool
	 */
	public static function clear() {
		$success = true;

		foreach ( self::get_log_files() as $file ) {
			if ( '' !== $file && file_exists( $file ) && ! wp_delete_file( $file ) ) {
				$success = false;
			}
		}

		return $success;
	}

	/**
	 * Remove expired records and keep retained storage bounded.
	 *
	 * This method is intentionally safe to run from both the scheduled task
	 * and a live webhook request. A logging failure never changes payment
	 * processing because callers do not depend on its result.
	 *
	 * @return bool
	 */
	public static function purge_expired_entries() {
		$entries = self::get_all_entries();

		if ( empty( $entries ) ) {
			return true;
		}

		$cutoff = time() - ( self::RETENTION_DAYS * DAY_IN_SECONDS );
		$retained = array();

		foreach ( $entries as $entry ) {
			$timestamp = isset( $entry['timestamp'] )
				? strtotime( $entry['timestamp'] . ' UTC' )
				: false;

			if ( false !== $timestamp && $timestamp >= $cutoff ) {
				$retained[] = $entry;
			}
		}

		$retained = self::limit_retained_size( $retained );

		if ( $retained === $entries ) {
			return true;
		}

		return self::replace_entries( $retained );
	}

	/**
	 * Return the active Stripe log path.
	 *
	 * @return string
	 */
	public static function get_log_file_path() {
		$directory = TutorHelper_Logger::get_log_directory();

		if ( '' === $directory ) {
			return '';
		}

		return trailingslashit( $directory )
			. 'tutorhelper-stripe-'
			. self::get_file_hash()
			. '.log';
	}

	/**
	 * Return the rotated Stripe log path.
	 *
	 * @return string
	 */
	public static function get_rotated_log_file_path() {
		$file = self::get_log_file_path();

		return '' === $file ? '' : $file . '.1';
	}

	/**
	 * Normalise one safe Stripe diagnostic record.
	 *
	 * @param array $entry Raw record fields supplied by Pro.
	 * @return array
	 */
	private static function normalise_entry( $entry ) {
		$outcome = isset( $entry['outcome'] )
			? sanitize_key( $entry['outcome'] )
			: '';
		$allowed_outcomes = array(
			'success',
			'pending',
			'ignored',
			'duplicate',
			'rejected',
			'failed',
		);

		if ( ! in_array( $outcome, $allowed_outcomes, true ) ) {
			$outcome = '';
		}

		$http_status = isset( $entry['http_status'] )
			? absint( $entry['http_status'] )
			: 0;

		if ( 599 < $http_status ) {
			$http_status = 0;
		}

		return array(
			'timestamp'      => gmdate( 'Y-m-d H:i:s' ),
			'event_type'     => isset( $entry['event_type'] )
				? sanitize_text_field( $entry['event_type'] )
				: '',
			'event_id'       => isset( $entry['event_id'] )
				? sanitize_text_field( $entry['event_id'] )
				: '',
			'booking_id'     => isset( $entry['booking_id'] )
				? absint( $entry['booking_id'] )
				: 0,
			'http_status'    => $http_status,
			'outcome'        => $outcome,
			'interpretation' => isset( $entry['interpretation'] )
				? sanitize_text_field( $entry['interpretation'] )
				: '',
			'error'          => isset( $entry['error'] )
				? sanitize_text_field( $entry['error'] )
				: '',
		);
	}

	/**
	 * Return all valid retained records in chronological order.
	 *
	 * @return array
	 */
	private static function get_all_entries() {
		$entries = array();

		foreach ( self::get_log_files() as $file ) {
			if ( ! file_exists( $file ) ) {
				continue;
			}

			$lines = file( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file -- Log parsing reads a bounded TutorHelper-owned diagnostic file.
				$file,
				FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
			);

			if ( ! is_array( $lines ) ) {
				continue;
			}

			foreach ( $lines as $line ) {
				$entry = json_decode( $line, true );

				if ( is_array( $entry ) && isset( $entry['timestamp'] ) ) {
					$entries[] = $entry;
				}
			}
		}

		usort(
			$entries,
			static function( $first, $second ) {
				return strcmp(
					isset( $first['timestamp'] ) ? $first['timestamp'] : '',
					isset( $second['timestamp'] ) ? $second['timestamp'] : ''
				);
			}
		);

		return $entries;
	}

	/**
	 * Limit records to the two-file retention limit, retaining newest first.
	 *
	 * @param array $entries Chronological entries.
	 * @return array
	 */
	private static function limit_retained_size( $entries ) {
		$kept = array();
		$size = 0;

		for ( $index = count( $entries ) - 1; 0 <= $index; $index-- ) {
			$encoded = wp_json_encode( $entries[ $index ], JSON_UNESCAPED_SLASHES );

			if ( false === $encoded ) {
				continue;
			}

			$entry_size = strlen( $encoded ) + strlen( PHP_EOL );

			if ( self::MAX_RETAINED_SIZE < ( $size + $entry_size ) ) {
				break;
			}

			array_unshift( $kept, $entries[ $index ] );
			$size += $entry_size;
		}

		return $kept;
	}

	/**
	 * Replace active and rotated logs with retained records.
	 *
	 * @param array $entries Chronological entries.
	 * @return bool
	 */
	private static function replace_entries( $entries ) {
		if ( ! self::prepare_log_directory() ) {
			return false;
		}

		$lines = array();

		foreach ( $entries as $entry ) {
			$encoded = wp_json_encode( $entry, JSON_UNESCAPED_SLASHES );

			if ( false !== $encoded ) {
				$lines[] = $encoded;
			}
		}

		$active_lines = array();
		$active_size = 0;

		for ( $index = count( $lines ) - 1; 0 <= $index; $index-- ) {
			$line_size = strlen( $lines[ $index ] ) + strlen( PHP_EOL );

			if (
				self::MAX_FILE_SIZE < ( $active_size + $line_size )
				&& ! empty( $active_lines )
			) {
				break;
			}

			array_unshift( $active_lines, $lines[ $index ] );
			$active_size += $line_size;
		}

		$rotated_lines = array_slice(
			$lines,
			0,
			count( $lines ) - count( $active_lines )
		);
		$active_contents = empty( $active_lines )
			? ''
			: implode( PHP_EOL, $active_lines ) . PHP_EOL;
		$rotated_contents = empty( $rotated_lines )
			? ''
			: implode( PHP_EOL, $rotated_lines ) . PHP_EOL;

		$active_result = file_put_contents( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Retention rewrites the TutorHelper-owned log under the protected directory.
			self::get_log_file_path(),
			$active_contents,
			LOCK_EX
		);

		if ( false === $active_result ) {
			return false;
		}

		if ( '' === $rotated_contents ) {
			$rotated = self::get_rotated_log_file_path();

			return ! file_exists( $rotated ) || wp_delete_file( $rotated );
		}

		$rotated_result = file_put_contents( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Retention rewrites the TutorHelper-owned rotated log under the protected directory.
			self::get_rotated_log_file_path(),
			$rotated_contents,
			LOCK_EX
		);

		return false !== $rotated_result;
	}

	/**
	 * Ensure the protected shared log directory exists.
	 *
	 * @return bool
	 */
	private static function prepare_log_directory() {
		$directory = TutorHelper_Logger::get_log_directory();

		if (
			'' === $directory
			|| ( ! is_dir( $directory ) && ! wp_mkdir_p( $directory ) )
		) {
			return false;
		}

		self::create_protection_file(
			trailingslashit( $directory ) . 'index.php',
			"<?php\n// Silence is golden.\n"
		);
		self::create_protection_file(
			trailingslashit( $directory ) . '.htaccess',
			"Require all denied\nDeny from all\n"
		);
		self::create_protection_file(
			trailingslashit( $directory ) . 'web.config',
			"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
			. "<configuration>\n"
			. "\t<system.webServer>\n"
			. "\t\t<authorization>\n"
			. "\t\t\t<deny users=\"*\" />\n"
			. "\t\t</authorization>\n"
			. "\t</system.webServer>\n"
			. "</configuration>\n"
		);

		return wp_is_writable( $directory );
	}

	/**
	 * Add a protective file when it does not yet exist.
	 *
	 * @param string $path File path.
	 * @param string $data File contents.
	 * @return void
	 */
	private static function create_protection_file( $path, $data ) {
		if ( file_exists( $path ) ) {
			return;
		}

		file_put_contents( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Protection files are created in the TutorHelper-owned protected log directory.
			$path,
			$data,
			LOCK_EX
		);
	}

	/**
	 * Rotate the active file while retaining a single previous file.
	 *
	 * @return void
	 */
	private static function rotate_if_required() {
		$file = self::get_log_file_path();

		if (
			! file_exists( $file )
			|| self::MAX_FILE_SIZE > filesize( $file ) // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_filesize -- Rotation requires the current TutorHelper-owned log size.
		) {
			return;
		}

		$rotated = self::get_rotated_log_file_path();

		if ( file_exists( $rotated ) && ! wp_delete_file( $rotated ) ) {
			return;
		}

		if ( ! rename( $file, $rotated ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Atomic rotation is required for the active TutorHelper-owned log.
			return;
		}
	}

	/**
	 * Return active and rotated file paths.
	 *
	 * @return array
	 */
	private static function get_log_files() {
		return array_values(
			array_filter(
				array(
					self::get_rotated_log_file_path(),
					self::get_log_file_path(),
				)
			)
		);
	}

	/**
	 * Return a non-secret stable filename fragment.
	 *
	 * @return string
	 */
	private static function get_file_hash() {
		return substr(
			hash(
				'sha256',
				wp_salt( 'auth' ) . '|tutorhelper-stripe-log'
			),
			0,
			32
		);
	}
}
