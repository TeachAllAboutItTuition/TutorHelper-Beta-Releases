<?php
/**
 * TutorHelper Bookings system report.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds read-only diagnostic information.
 */
final class TutorHelper_System_Report {

	/**
	 * Return all diagnostics data.
	 *
	 * @return array
	 */
	public static function get_data() {
		global $wpdb;

		$data = array(
			'plugin' => array(
				'label' => __( 'TutorHelper Bookings', 'tutorhelper-bookings' ),
				'items' => array(
					'Plugin version' => TUTORHELPER_BOOKINGS_VERSION,
					'Installed database version' => get_option(
						TutorHelper_Bookings_Database::VERSION_OPTION,
						'Not installed'
					),
					'Expected database version' => TUTORHELPER_BOOKINGS_DB_VERSION,
					'Database version match' => self::database_version_matches(),
					'Plugin path' => TUTORHELPER_BOOKINGS_PATH,
				),
			),
			'wordpress' => array(
				'label' => __( 'WordPress', 'tutorhelper-bookings' ),
				'items' => array(
					'WordPress version' => get_bloginfo( 'version' ),
					'Site URL' => home_url(),
					'Site timezone' => wp_timezone_string(),
					'Current UTC time' => gmdate( 'Y-m-d H:i:s' ),
					'WP_DEBUG' => self::boolean_label( defined( 'WP_DEBUG' ) && WP_DEBUG ),
					'WP_DEBUG_LOG' => self::get_debug_log_status(),
					'Multisite' => self::boolean_label( is_multisite() ),
				),
			),
			'server' => array(
				'label' => __( 'Server', 'tutorhelper-bookings' ),
				'items' => array(
					'PHP version' => PHP_VERSION,
					'Database version' => $wpdb->db_version(),
					'PHP memory limit' => ini_get( 'memory_limit' ),
					'WordPress memory' => WP_MEMORY_LIMIT,
					'Maximum execution' => ini_get( 'max_execution_time' ),
					'Upload maximum' => ini_get( 'upload_max_filesize' ),
				),
			),
			'database' => array(
				'label' => __( 'Booking database', 'tutorhelper-bookings' ),
				'items' => self::get_database_status(),
			),
			'configuration' => array(
				'label' => __( 'TutorHelper configuration', 'tutorhelper-bookings' ),
				'items' => self::get_configuration_status(),
			),
			'booking_readiness' => array(
				'label' => __( 'Booking readiness', 'tutorhelper-bookings' ),
				'items' => self::get_booking_readiness(),
			),
			'logging' => array(
				'label' => __( 'Logging', 'tutorhelper-bookings' ),
				'items' => array(
					'Log directory writable' => self::boolean_label( TutorHelper_Logger::is_writable() ),
					'Active log size' => size_format( TutorHelper_Logger::get_log_size() ),
					'Maximum log size' => size_format( TutorHelper_Logger::MAX_FILE_SIZE ),
				),
			),
		);

		return apply_filters( 'tutorhelper_system_report_data', $data );
	}

	/**
	 * Check whether the installed schema version matches Core.
	 *
	 * @return string
	 */
	private static function database_version_matches() {
		$installed = get_option( TutorHelper_Bookings_Database::VERSION_OPTION, '' );
		if ( '' === $installed ) {
			return 'No';
		}

		return version_compare( $installed, TUTORHELPER_BOOKINGS_DB_VERSION, '==' )
			? 'Yes'
			: 'No';
	}

	/**
	 * Return database table health information.
	 *
	 * @return array
	 */
	public static function get_database_status() {
		global $wpdb;

		$table_keys = array(
			'availability' => 'Availability table',
			'types' => 'Booking Types table',
			'availability_exceptions' => 'Availability Exceptions table',
			'bookings' => 'Bookings table',
			'date_exclusions' => 'Date Exclusions table',
			'student_audit' => 'Student Audit table',
		);

		$items = array();

		foreach ( $table_keys as $table_key => $label ) {
			$table_name = TutorHelper_Bookings_Database::get_table_name( $table_key );
			$exists = $table_name === $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
				$wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name )
			);
			$items[ $label ] = $exists ? 'Present' : 'Missing';
		}

		$items['Booking Types count'] = self::count_rows(
			TutorHelper_Bookings_Database::get_table_name( 'types' )
		);
		$items['Availability count'] = self::count_rows(
			TutorHelper_Bookings_Database::get_table_name( 'availability' )
		);
		$items['Bookings count'] = self::count_rows(
			TutorHelper_Bookings_Database::get_table_name( 'bookings' )
		);
		$items['Bookings required columns'] = self::check_booking_columns();

		return $items;
	}

	/**
	 * Verify important Core booking columns exist.
	 *
	 * @return string
	 */
	private static function check_booking_columns() {
		global $wpdb;

		$table = TutorHelper_Bookings_Database::get_table_name( 'bookings' );

		if (
			'' === $table
			|| $table !== $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
				$wpdb->prepare( 'SHOW TABLES LIKE %s', $table )
			)
		) {
			return 'Table unavailable';
		}

		$required_columns = array(
			'status',
			'source',
			'cancelled_at',
			'cancelled_by',
			'cancellation_reason',
		);

		$existing_columns = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
			$wpdb->prepare( 'SHOW COLUMNS FROM %i', $table ),
			0
		);

		$missing = array_diff(
			$required_columns,
			is_array( $existing_columns ) ? $existing_columns : array()
		);

		return empty( $missing )
			? 'Present'
			: 'Missing: ' . implode( ', ', $missing );
	}

	/**
	 * Return TutorHelper configuration information.
	 *
	 * @return array
	 */
	private static function get_configuration_status() {
		$booking_page_id = absint( get_option( TutorHelper_Settings::OPTION_STUDENT_BOOKING_PAGE, 0 ) );
		$dashboard_page_id = absint( get_option( TutorHelper_Settings::OPTION_STUDENT_DASHBOARD_PAGE, 0 ) );
		$login_page_id = absint( get_option( TutorHelper_Settings::OPTION_LOGIN_PAGE, 0 ) );
		$email_settings = TutorHelper_Email_Settings::get_all();
		$sender_name = ! empty( $email_settings['sender_name'] )
			? sanitize_text_field( $email_settings['sender_name'] )
			: '';
		$sender_email = ! empty( $email_settings['contact_email'] )
			? sanitize_email( $email_settings['contact_email'] )
			: '';

		return array(
			'Student booking page' => self::get_page_status( $booking_page_id ),
			'Student dashboard page' => self::get_page_status( $dashboard_page_id ),
			'Login page' => $login_page_id
				? self::get_page_status( $login_page_id )
				: 'WordPress default',
			'Site timezone' => wp_timezone_string(),
			'Currency' => TutorHelper_Currency::get_currency(),
			'Email sender name' => $sender_name ? $sender_name : 'Missing',
			'Email sender address' => $sender_email ? $sender_email : 'Missing',
			'Outgoing sender' => $sender_name && $sender_email
				? sprintf( '%s <%s>', $sender_name, $sender_email )
				: 'Incomplete',
			'Privacy policy URL' => ! empty( $email_settings['privacy_policy_url'] ) ? 'Configured' : 'Not configured',
		);
	}

	/**
	 * Return Core Booking readiness information.
	 *
	 * @return array
	 */
	private static function get_booking_readiness() {
		return array(
			'Active Booking Types' => self::count_active_booking_types(),
			'Active availability rules' => self::count_active_availability(),
			'Default tutor' => self::get_default_tutor_status(),
			'Student booking page shortcode' => self::page_contains_shortcode(
				TutorHelper_Settings::OPTION_STUDENT_BOOKING_PAGE,
				'tutorhelper_student_booking'
			),
			'Student dashboard shortcode' => self::page_contains_shortcode(
				TutorHelper_Settings::OPTION_STUDENT_DASHBOARD_PAGE,
				'tutorhelper_student_dashboard'
			),
		);
	}

	/**
	 * Count active Booking Types.
	 *
	 * @return string
	 */
	private static function count_active_booking_types() {
		global $wpdb;

		$table = TutorHelper_Bookings_Database::get_table_name( 'types' );
		if (
			'' === $table
			|| $table !== $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
				$wpdb->prepare( 'SHOW TABLES LIKE %s', $table )
			)
		) {
			return 'Table unavailable';
		}

		$count = absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i WHERE is_active = %d',
					$table,
					1
				)
			)
		);

		return 0 < $count ? sprintf( '%d active', $count ) : 'None active';
	}

	/**
	 * Return the resolved default tutor status.
	 *
	 * @return string
	 */
	private static function get_default_tutor_status() {
		$tutor_user_id = TutorHelper_Booking_Tutor_Resolver::resolve( 0, 0 );

		if ( is_wp_error( $tutor_user_id ) ) {
			return sprintf( 'Not resolved — %s', $tutor_user_id->get_error_message() );
		}

		$tutor_user_id = absint( $tutor_user_id );
		if ( ! $tutor_user_id ) {
			return 'Not resolved';
		}

		$user = get_user_by( 'id', $tutor_user_id );
		if ( ! $user instanceof WP_User ) {
			return sprintf( 'Invalid user ID %d', $tutor_user_id );
		}

		return sprintf( '%s (ID %d)', $user->display_name, $tutor_user_id );
	}

	/**
	 * Check whether a configured page contains a shortcode.
	 *
	 * @param string $option_name Page-setting option.
	 * @param string $shortcode Expected shortcode.
	 * @return string
	 */
	private static function page_contains_shortcode( $option_name, $shortcode ) {
		$page_id = absint( get_option( $option_name, 0 ) );
		if ( ! $page_id ) {
			return 'Page not configured';
		}

		$page = get_post( $page_id );
		if ( ! $page || 'page' !== $page->post_type ) {
			return 'Configured page missing';
		}

		$content = (string) $page->post_content;
		if ( self::content_contains_shortcode( $content, $shortcode ) ) {
			return 'Present';
		}

		if ( has_blocks( $content ) ) {
			$resolved_blocks = do_blocks( $content );
			if ( self::content_contains_shortcode( $resolved_blocks, $shortcode ) ) {
				return 'Present';
			}
		}

		$meta = get_post_meta( $page_id );
		foreach ( is_array( $meta ) ? $meta : array() as $meta_key => $values ) {
			$meta_key = sanitize_key( $meta_key );

			if (
				0 === strpos( $meta_key, '_wp_' )
				|| false !== strpos( $meta_key, 'password' )
				|| false !== strpos( $meta_key, 'secret' )
				|| false !== strpos( $meta_key, 'token' )
			) {
				continue;
			}

			if ( self::value_contains_shortcode( $values, $shortcode ) ) {
				return 'Present';
			}
		}

		return sprintf( 'Missing [%s]', $shortcode );
	}

	/**
	 * Test rendered or stored content for a shortcode token.
	 *
	 * @param string $content Content to inspect.
	 * @param string $shortcode Shortcode tag.
	 * @return bool
	 */
	private static function content_contains_shortcode( $content, $shortcode ) {
		$content = (string) $content;
		$shortcode = sanitize_key( $shortcode );

		if ( '' === $content || '' === $shortcode ) {
			return false;
		}

		return has_shortcode( $content, $shortcode )
			|| false !== strpos( $content, '[' . $shortcode );
	}

	/**
	 * Recursively inspect page-builder metadata for a shortcode reference.
	 *
	 * @param mixed  $value Metadata value.
	 * @param string $shortcode Shortcode tag.
	 * @return bool
	 */
	private static function value_contains_shortcode( $value, $shortcode ) {
		if ( is_array( $value ) || is_object( $value ) ) {
			foreach ( (array) $value as $nested ) {
				if ( self::value_contains_shortcode( $nested, $shortcode ) ) {
					return true;
				}
			}
			return false;
		}

		if ( ! is_scalar( $value ) ) {
			return false;
		}

		$string = (string) $value;
		$unserialized = maybe_unserialize( $string );
		if ( $unserialized !== $string ) {
			return self::value_contains_shortcode( $unserialized, $shortcode );
		}

		return self::content_contains_shortcode( $string, $shortcode )
			|| false !== strpos( $string, $shortcode );
	}

	/**
	 * Count active tutor availability rules.
	 *
	 * @return string
	 */
	private static function count_active_availability() {
		global $wpdb;

		$table = TutorHelper_Bookings_Database::get_table_name( 'availability' );
		if (
			'' === $table
			|| $table !== $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
				$wpdb->prepare( 'SHOW TABLES LIKE %s', $table )
			)
		) {
			return 'Table unavailable';
		}

		$count = absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i WHERE is_active = %d',
					$table,
					1
				)
			)
		);

		return 0 < $count ? sprintf( '%d active', $count ) : 'None active';
	}

	/**
	 * Return a readable status for one configured WordPress page.
	 *
	 * @param int $page_id WordPress page ID.
	 * @return string
	 */
	private static function get_page_status( $page_id ) {
		$page_id = absint( $page_id );
		if ( ! $page_id ) {
			return 'Not configured';
		}

		$page = get_post( $page_id );
		if ( ! $page || 'page' !== $page->post_type ) {
			return sprintf( 'Missing (ID %d)', $page_id );
		}

		$status = get_post_status( $page_id );
		if ( 'publish' === $status ) {
			return sprintf( 'Published — %s', get_the_title( $page_id ) );
		}

		return sprintf(
			'%s — %s',
			ucfirst( sanitize_key( $status ) ),
			get_the_title( $page_id )
		);
	}

	/**
	 * Return user-facing Core readiness checks.
	 *
	 * @return array
	 */
	public static function get_readiness_checks() {
		$database_status = self::get_database_status();
		$booking_page_id = absint( get_option( TutorHelper_Settings::OPTION_STUDENT_BOOKING_PAGE, 0 ) );
		$dashboard_page_id = absint( get_option( TutorHelper_Settings::OPTION_STUDENT_DASHBOARD_PAGE, 0 ) );
		$login_page_id = absint( get_option( TutorHelper_Settings::OPTION_LOGIN_PAGE, 0 ) );
		$email_settings = TutorHelper_Email_Settings::get_all();
		$booking_shortcode_status = self::page_contains_shortcode(
			TutorHelper_Settings::OPTION_STUDENT_BOOKING_PAGE,
			'tutorhelper_student_booking'
		);
		$dashboard_shortcode_status = self::page_contains_shortcode(
			TutorHelper_Settings::OPTION_STUDENT_DASHBOARD_PAGE,
			'tutorhelper_student_dashboard'
		);
		$booking_types_status = self::count_active_booking_types();
		$availability_status = self::count_active_availability();
		$tutor_status = self::get_default_tutor_status();
		$database_ready = self::is_database_ready( $database_status );

		return array(
			array(
				'key' => 'database',
				'label' => __( 'Database', 'tutorhelper-bookings' ),
				'status' => $database_ready ? 'ready' : 'problem',
				'message' => $database_ready
					? __( 'TutorHelper database tables and required booking fields are ready.', 'tutorhelper-bookings' )
					: __( 'TutorHelper detected a database schema problem. Review the detailed Booking database section below.', 'tutorhelper-bookings' ),
				'action_url' => '',
				'action_label' => '',
			),
			array(
				'key' => 'booking_page',
				'label' => __( 'Student booking page', 'tutorhelper-bookings' ),
				'status' => $booking_page_id && 'Present' === $booking_shortcode_status ? 'ready' : 'problem',
				'message' => $booking_page_id && 'Present' === $booking_shortcode_status
					? __( 'The student booking page is configured and contains the booking shortcode.', 'tutorhelper-bookings' )
					: __( 'Choose a student booking page and make sure it contains [tutorhelper_student_booking].', 'tutorhelper-bookings' ),
				'action_url' => add_query_arg(
					array( 'page' => TutorHelper_Settings::PAGE_SLUG, 'tab' => 'pages' ),
					admin_url( 'admin.php' )
				),
				'action_label' => __( 'Page settings', 'tutorhelper-bookings' ),
			),
			array(
				'key' => 'dashboard_page',
				'label' => __( 'Student dashboard', 'tutorhelper-bookings' ),
				'status' => $dashboard_page_id && 'Present' === $dashboard_shortcode_status ? 'ready' : 'problem',
				'message' => $dashboard_page_id && 'Present' === $dashboard_shortcode_status
					? __( 'The student dashboard page is configured and contains the dashboard shortcode.', 'tutorhelper-bookings' )
					: __( 'Choose a student dashboard page and make sure it contains [tutorhelper_student_dashboard].', 'tutorhelper-bookings' ),
				'action_url' => add_query_arg(
					array( 'page' => TutorHelper_Settings::PAGE_SLUG, 'tab' => 'pages' ),
					admin_url( 'admin.php' )
				),
				'action_label' => __( 'Page settings', 'tutorhelper-bookings' ),
			),
			array(
				'key' => 'booking_types',
				'label' => __( 'Booking Types', 'tutorhelper-bookings' ),
				'status' => 'None active' !== $booking_types_status && 'Table unavailable' !== $booking_types_status ? 'ready' : 'problem',
				'message' => 'None active' !== $booking_types_status && 'Table unavailable' !== $booking_types_status
					? sprintf(
						/* translators: %s: Booking Type status summary. */
						__( 'TutorHelper found %s.', 'tutorhelper-bookings' ),
						$booking_types_status
					)
					: __( 'Create and activate at least one Booking Type before students can request lessons.', 'tutorhelper-bookings' ),
				'action_url' => add_query_arg(
					array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => 'booking-types' ),
					admin_url( 'admin.php' )
				),
				'action_label' => __( 'Booking Types', 'tutorhelper-bookings' ),
			),
			array(
				'key' => 'availability',
				'label' => __( 'Availability', 'tutorhelper-bookings' ),
				'status' => 'None active' !== $availability_status && 'Table unavailable' !== $availability_status ? 'ready' : 'problem',
				'message' => 'None active' !== $availability_status && 'Table unavailable' !== $availability_status
					? sprintf(
						/* translators: %s: Availability status summary. */
						__( 'TutorHelper found %s.', 'tutorhelper-bookings' ),
						$availability_status
					)
					: __( 'Add at least one active availability rule so students have times they can request.', 'tutorhelper-bookings' ),
				'action_url' => add_query_arg(
					array( 'page' => TutorHelper_Booking_Hub::PAGE_SLUG, 'tab' => 'availability' ),
					admin_url( 'admin.php' )
				),
				'action_label' => __( 'Availability', 'tutorhelper-bookings' ),
			),
			array(
				'key' => 'tutor',
				'label' => __( 'Tutor account', 'tutorhelper-bookings' ),
				'status' => 0 === strpos( $tutor_status, 'Not resolved' ) ? 'problem' : 'ready',
				'message' => 0 === strpos( $tutor_status, 'Not resolved' )
					? __( 'TutorHelper could not resolve the tutor who should receive lesson requests.', 'tutorhelper-bookings' )
					: sprintf(
						/* translators: %s: Tutor account status summary. */
						__( 'Lesson requests will be assigned to %s.', 'tutorhelper-bookings' ),
						$tutor_status
					),
				'action_url' => '',
				'action_label' => '',
			),
			array(
				'key' => 'email',
				'label' => __( 'Email settings', 'tutorhelper-bookings' ),
				'status' => ! empty( $email_settings['sender_name'] ) && ! empty( $email_settings['contact_email'] ) ? 'ready' : 'problem',
				'message' => ! empty( $email_settings['sender_name'] ) && ! empty( $email_settings['contact_email'] )
					? sprintf(
						/* translators: 1: Sender name, 2: Sender email address. */
						__( 'TutorHelper emails will be sent as %1$s <%2$s>.', 'tutorhelper-bookings' ),
						sanitize_text_field( $email_settings['sender_name'] ),
						sanitize_email( $email_settings['contact_email'] )
					)
					: __( 'Complete the TutorHelper email sender name and sender address.', 'tutorhelper-bookings' ),
				'action_url' => add_query_arg(
					array( 'page' => TutorHelper_Settings::PAGE_SLUG, 'tab' => 'email' ),
					admin_url( 'admin.php' )
				),
				'action_label' => __( 'Email settings', 'tutorhelper-bookings' ),
			),
			array(
				'key' => 'privacy',
				'label' => __( 'Privacy policy', 'tutorhelper-bookings' ),
				'status' => ! empty( $email_settings['privacy_policy_url'] ) ? 'ready' : 'attention',
				'message' => ! empty( $email_settings['privacy_policy_url'] )
					? __( 'A privacy policy URL is available for student-facing emails.', 'tutorhelper-bookings' )
					: __( 'No privacy policy URL is configured. TutorHelper can still operate, but adding one is recommended for student-facing emails.', 'tutorhelper-bookings' ),
				'action_url' => add_query_arg(
					array( 'page' => TutorHelper_Settings::PAGE_SLUG, 'tab' => 'email' ),
					admin_url( 'admin.php' )
				),
				'action_label' => __( 'Email settings', 'tutorhelper-bookings' ),
			),
			array(
				'key' => 'login',
				'label' => __( 'Student login', 'tutorhelper-bookings' ),
				'status' => $login_page_id ? 'ready' : 'attention',
				'message' => $login_page_id
					? __( 'A custom student login page is configured.', 'tutorhelper-bookings' )
					: __( 'No custom login page is selected. TutorHelper will safely use the standard WordPress login page.', 'tutorhelper-bookings' ),
				'action_url' => add_query_arg(
					array( 'page' => TutorHelper_Settings::PAGE_SLUG, 'tab' => 'pages' ),
					admin_url( 'admin.php' )
				),
				'action_label' => __( 'Page settings', 'tutorhelper-bookings' ),
			),
		);
	}

	/**
	 * Check whether the Core database diagnostics are healthy.
	 *
	 * @param array $database_status Database report values.
	 * @return bool
	 */
	private static function is_database_ready( $database_status ) {
		if ( 'Yes' !== self::database_version_matches() ) {
			return false;
		}

		foreach ( is_array( $database_status ) ? $database_status : array() as $value ) {
			$value = (string) $value;
			if ( 0 === strpos( $value, 'Missing' ) || 'Table unavailable' === $value ) {
				return false;
			}
		}

		return isset( $database_status['Bookings required columns'] )
			&& 'Present' === $database_status['Bookings required columns'];
	}

	/**
	 * Return the report as plain text.
	 *
	 * @return string
	 */
	public static function get_plain_text() {
		$data = self::get_data();
		$output = array();
		$output[] = 'TutorHelper Bookings System Report';
		$output[] = 'Generated: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC';
		$output[] = str_repeat( '=', 40 );

		foreach ( $data as $section ) {
			$output[] = '';
			$output[] = isset( $section['label'] ) ? $section['label'] : 'Section';
			$output[] = str_repeat( '-', 40 );

			if ( ! isset( $section['items'] ) || ! is_array( $section['items'] ) ) {
				continue;
			}

			foreach ( $section['items'] as $label => $value ) {
				$output[] = $label . ': ' . $value;
			}
		}

		return implode( PHP_EOL, $output );
	}

	/**
	 * Count rows safely when a table exists.
	 *
	 * @param string $table_name Full table name.
	 * @return int|string
	 */
	private static function count_rows( $table_name ) {
		global $wpdb;

		if (
			empty( $table_name )
			|| $table_name !== $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
				$wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name )
			)
		) {
			return 'Table unavailable';
		}

		return absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Diagnostics must reflect current database state.
				$wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table_name )
			)
		);
	}

	/**
	 * Convert a boolean to a readable label.
	 *
	 * @param bool $value Boolean value.
	 * @return string
	 */
	private static function boolean_label( $value ) {
		return $value ? 'Enabled' : 'Disabled';
	}

	/**
	 * Describe WordPress debug log configuration.
	 *
	 * @return string
	 */
	private static function get_debug_log_status() {
		if ( ! defined( 'WP_DEBUG_LOG' ) || ! WP_DEBUG_LOG ) {
			return 'Disabled';
		}

		if ( is_string( WP_DEBUG_LOG ) ) {
			return 'Enabled with a custom path';
		}

		return 'Enabled';
	}
}
