<?php
/**
 * Student booking front-end module.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the student booking front-end feature.
 */
final class TutorHelper_Student_Booking_Module {

	/**
	 * Initialise the module.
	 *
	 * @return void
	 */
	public static function init() {
		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-booking/'
			. 'class-tutorhelper-student-booking-labels.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-booking/'
			. 'class-tutorhelper-student-booking-frontend.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-booking/'
			. 'class-tutorhelper-student-booking-context.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-booking/'
			. 'class-tutorhelper-student-booking-shortcode.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/student-booking/'
            . 'class-tutorhelper-student-booking-slots.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/student-booking/'
            . 'class-tutorhelper-student-booking-ajax.php';

		require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/student-booking/'
            . 'class-tutorhelper-student-booking-access.php';

		TutorHelper_Student_Booking_Frontend::init();

		TutorHelper_Student_Booking_Shortcode::init();

        TutorHelper_Student_Booking_Ajax::init();
	}
}
