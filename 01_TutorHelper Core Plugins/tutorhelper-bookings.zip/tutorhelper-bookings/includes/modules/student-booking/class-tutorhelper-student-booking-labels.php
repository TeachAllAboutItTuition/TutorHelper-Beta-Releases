<?php
/**
 * Student booking form labels.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Supplies the default Core wording for the student booking form.
 *
 * Pro may replace individual values through the
 * tutorhelper_student_booking_form_labels filter.
 */
final class TutorHelper_Student_Booking_Labels {

	/**
     * Return the student booking form labels.
     *
     * @return array
     */
    public static function get_all() {
        $defaults = self::get_defaults();

        /**
         * Filter the wording used by the student booking form.
         *
         * Pro may use this filter to replace Core defaults with wording
         * stored in the tutor's booking settings.
         *
         * @param array $labels Core booking form labels.
         */
        $labels = apply_filters(
            'tutorhelper_student_booking_form_labels',
            $defaults
        );

        if ( ! is_array( $labels ) ) {
            $labels = array();
        }

        $labels = wp_parse_args(
            $labels,
            $defaults
        );

        foreach ( $labels as $key => $value ) {
            $labels[ $key ] =
                sanitize_text_field(
                    $value
                );
        }

        return $labels;
    }

	/**
	 * Return one form label.
	 *
	 * @param string $key Label key.
	 *
	 * @return string
	 */
	public static function get(
		$key
	) {
		$key = sanitize_key(
			$key
		);

		$labels = self::get_all();

		return isset( $labels[ $key ] )
			? sanitize_text_field(
				$labels[ $key ]
			)
			: '';
	}

	/**
	 * Return unfiltered Core defaults.
	 *
	 * @return array
	 */
	private static function get_defaults() {
		return array(
			'heading' => __(
				'Book a lesson',
				'tutorhelper-bookings'
			),

			'introduction' => __(
				'Choose the type of session, then pick a date and time that works for you',
				'tutorhelper-bookings'
			),

			'select_service' => __(
				'Select Service',
				'tutorhelper-bookings'
			),

			'service' => __(
				'Service',
				'tutorhelper-bookings'
			),

			'select_date' => __(
				'Select Date',
				'tutorhelper-bookings'
			),

			'select_time' => __(
				'Select Time',
				'tutorhelper-bookings'
			),
		);
	}
}
