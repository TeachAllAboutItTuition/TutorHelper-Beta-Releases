<?php
/**
 * Student Booking Type access resolver.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves whether a student may see or book a Booking Type.
 */
final class TutorHelper_Student_Booking_Access {

	/**
	 * Determine whether a Booking Type is visible.
	 *
	 * Core's student booking form currently displays only
	 * active, publicly bookable Booking Types.
	 *
	 * Extensions may further restrict or expand visibility.
	 *
	 * @param object $booking_type    Booking Type record.
	 * @param int    $student_user_id Student user ID.
	 *
	 * @return bool
	 */
	public static function can_view(
		$booking_type,
		$student_user_id = 0
	) {
		if (
			! is_object( $booking_type )
			|| empty( $booking_type->is_active )
		) {
			return false;
		}

		$can_view =
			'bookable'
			=== sanitize_key(
				$booking_type
					->online_booking_visibility
			);

		/**
		 * Filters whether a student may see a Booking Type
		 * on the student booking form.
		 *
		 * @param bool   $can_view        Core visibility result.
		 * @param object $booking_type    Booking Type record.
		 * @param int    $student_user_id Student user ID.
		 */
		return (bool) apply_filters(
			'tutorhelper_student_booking_type_can_view',
			$can_view,
			$booking_type,
			absint( $student_user_id )
		);
	}

	/**
	 * Determine whether a Booking Type can be booked.
	 *
	 * @param object $booking_type    Booking Type record.
	 * @param int    $student_user_id Student user ID.
	 *
	 * @return bool
	 */
	public static function can_book(
		$booking_type,
		$student_user_id = 0
	) {
		if (
			! is_object( $booking_type )
			|| empty( $booking_type->is_active )
		) {
			return false;
		}

		$can_book =
			'bookable'
			=== sanitize_key(
				$booking_type
					->online_booking_visibility
			);

		/**
		 * Filters whether a student may book a Booking Type.
		 *
		 * This filter is used by both presentation and
		 * server-side request validation.
		 *
		 * @param bool   $can_book        Core bookability result.
		 * @param object $booking_type    Booking Type record.
		 * @param int    $student_user_id Student user ID.
		 */
		return (bool) apply_filters(
			'tutorhelper_student_booking_type_can_book',
			$can_book,
			$booking_type,
			absint( $student_user_id )
		);
	}

	/**
	 * Return an explanation when a visible Booking Type
	 * cannot be booked by the current student.
	 *
	 * @param object $booking_type    Booking Type record.
	 * @param int    $student_user_id Student user ID.
	 *
	 * @return string
	 */
	public static function get_unavailable_message(
		$booking_type,
		$student_user_id = 0
	) {
		$message = __(
			'This lesson type is not available for your account.',
			'tutorhelper-bookings'
		);

		/**
		 * Filters the student-facing unavailable message.
		 *
		 * @param string $message         Default message.
		 * @param object $booking_type    Booking Type record.
		 * @param int    $student_user_id Student user ID.
		 */
		return sanitize_text_field(
			apply_filters(
				'tutorhelper_student_booking_type_unavailable_message',
				$message,
				$booking_type,
				absint( $student_user_id )
			)
		);
	}
}
