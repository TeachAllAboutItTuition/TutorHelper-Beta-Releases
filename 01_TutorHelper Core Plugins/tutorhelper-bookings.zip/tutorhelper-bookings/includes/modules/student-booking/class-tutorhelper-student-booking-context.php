<?php
/**
 * Student booking context resolver.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves the student account used by a front-end booking request.
 *
 * Core permits the logged-in student by default. Authorised add-ons may
 * securely supply a linked student through the documented filter.
 */
final class TutorHelper_Student_Booking_Context {

	/**
	 * Query and request field used to nominate a child account.
	 *
	 * @var string
	 */
	const STUDENT_FIELD = 'tutorhelper_booking_child_id';

	/**
	 * Resolve the current booking context.
	 *
	 * @return array|WP_Error {
	 *     Resolved booking context.
	 *
	 *     @type int    $student_user_id Authorised student account.
	 *     @type string $mode            Student or delegated booking mode.
	 * }
	 */
	public static function resolve() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'tutorhelper_student_booking_login_required',
				__(
					'Please log in to request a lesson.',
					'tutorhelper-bookings'
				)
			);
		}

		$viewer_user_id = get_current_user_id();
		$requested_student_id = self::requested_student_id();
		$viewer_is_student = TutorHelper_Students::get_student(
			$viewer_user_id
		) instanceof WP_User;

		$context = array(
			'student_user_id' => $viewer_is_student
				? absint( $viewer_user_id )
				: 0,
			'mode'            => $viewer_is_student
				? 'student'
				: '',
			'is_authorised'   => $viewer_is_student,
		);

		/**
		 * Filters a secure front-end booking context.
		 *
		 * Extensions must verify the relationship between the logged-in
		 * viewer and any substituted student before setting is_authorised.
		 *
		 * @param array $context              Core booking context.
		 * @param int   $viewer_user_id       Logged-in user ID.
		 * @param int   $requested_student_id Requested student account ID.
		 */
		$context = apply_filters(
			'tutorhelper_student_booking_context',
			$context,
			absint( $viewer_user_id ),
			absint( $requested_student_id )
		);

		$context = is_array( $context )
			? $context
			: array();

		$student_user_id = isset( $context['student_user_id'] )
			? absint( $context['student_user_id'] )
			: 0;

		if (
			empty( $context['is_authorised'] )
			|| ! $student_user_id
			|| ! (
				TutorHelper_Students::get_student(
					$student_user_id
				) instanceof WP_User
			)
		) {
			return new WP_Error(
				'tutorhelper_student_booking_context_forbidden',
				__(
					'You are not allowed to book lessons for this student.',
					'tutorhelper-bookings'
				)
			);
		}

		return array(
			'student_user_id' => $student_user_id,
			'mode'            => isset( $context['mode'] )
				? sanitize_key( $context['mode'] )
				: 'student',
		);
	}

	/**
	 * Return the requested child account ID from the current request.
	 *
	 * This value never authorises access by itself. Authorisation is
	 * performed by the booking-context filter in resolve().
	 *
	 * @return int
	 */
	private static function requested_student_id() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only context selector; mutating AJAX handlers verify their nonce before resolving.
		$value = isset( $_REQUEST[ self::STUDENT_FIELD ] )
			&& ! is_array( $_REQUEST[ self::STUDENT_FIELD ] )
			? absint(
				wp_unslash(
					$_REQUEST[ self::STUDENT_FIELD ]
				)
			)
			: 0;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		return $value;
	}
}
