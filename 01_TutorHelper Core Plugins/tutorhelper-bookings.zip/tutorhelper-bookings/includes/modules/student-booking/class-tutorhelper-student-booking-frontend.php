<?php
/**
 * Student booking front-end assets.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and loads student booking form assets.
 */
final class TutorHelper_Student_Booking_Frontend {

	/**
	 * Front-end stylesheet handle.
	 *
	 * @var string
	 */
	const STYLE_HANDLE =
		'tutorhelper-student-booking';

	/**
	 * Front-end script handle.
	 *
	 * @var string
	 */
	const SCRIPT_HANDLE =
		'tutorhelper-student-booking';

	/**
	 * Student booking extension bridge handle.
	 *
	 * @var string
	 */
	const EXTENSIONS_SCRIPT_HANDLE =
		'tutorhelper-student-booking-extensions';

	/**
	 * Register front-end assets.
	 *
	 * Assets are registered globally but only enqueued when the shortcode
	 * is actually rendered.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'wp_enqueue_scripts',
			array(
				__CLASS__,
				'register_assets',
			)
		);
	}

	/**
	 * Register the student booking CSS and JavaScript.
	 *
	 * @return void
	 */
	public static function register_assets() {
		$css_path =
			TUTORHELPER_BOOKINGS_PATH
			. 'assets/css/student-booking.css';

		$script_path =
			TUTORHELPER_BOOKINGS_PATH
			. 'assets/js/student-booking.js';

		$extensions_script_path =
			TUTORHELPER_BOOKINGS_PATH
			. 'assets/js/student-booking-extensions.js';

		wp_register_style(
			self::STYLE_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/css/student-booking.css',
			array(),
			file_exists( $css_path )
				? (string) filemtime(
					$css_path
				)
				: TUTORHELPER_BOOKINGS_VERSION
		);

		wp_register_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/js/student-booking.js',
			array(),
			file_exists( $script_path )
				? (string) filemtime(
					$script_path
				)
				: TUTORHELPER_BOOKINGS_VERSION,
			true
		);

		wp_register_script(
			self::EXTENSIONS_SCRIPT_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/js/student-booking-extensions.js',
			array(
				self::SCRIPT_HANDLE,
			),
			file_exists( $extensions_script_path )
				? (string) filemtime(
					$extensions_script_path
				)
				: TUTORHELPER_BOOKINGS_VERSION,
			true
		);
	}

	/**
	 * Enqueue assets for a rendered booking form.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {
		if (
			! wp_style_is(
				self::STYLE_HANDLE,
				'registered'
			)
			|| ! wp_script_is(
				self::SCRIPT_HANDLE,
				'registered'
			)
			|| ! wp_script_is(
				self::EXTENSIONS_SCRIPT_HANDLE,
				'registered'
			)
		) {
			self::register_assets();
		}

		wp_enqueue_style(
			self::STYLE_HANDLE
		);

		wp_enqueue_script(
			self::SCRIPT_HANDLE
		);

		wp_enqueue_script(
			self::EXTENSIONS_SCRIPT_HANDLE
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperStudentBooking',
			array(
				'ajaxUrl' =>
					admin_url(
						'admin-ajax.php'
					),

				'timezone' =>
					wp_timezone_string(),

				'labels' =>
					TutorHelper_Student_Booking_Labels::
						get_all(),

                'nonce' =>
                    wp_create_nonce(
                        TutorHelper_Student_Booking_Ajax::
                            NONCE_ACTION
                    ),

                'actions' => array(
                    'dates' =>
                        TutorHelper_Student_Booking_Ajax::
                            ACTION_DATES,
                    'times' =>
                        TutorHelper_Student_Booking_Ajax::
                            ACTION_TIMES,
                    'submit' =>
                        TutorHelper_Student_Booking_Ajax::
                            ACTION_SUBMIT,
                ),

                'strings' => array(
                    'loadingDates' => __(
                        'Loading available dates…',
                        'tutorhelper-bookings'
                    ),

                    'noDates' => __(
                        'No available dates were found for this month.',
                        'tutorhelper-bookings'
                    ),

                    'dateError' => __(
                        'Available dates could not be loaded. Please try again.',
                        'tutorhelper-bookings'
                    ),

                    'notSelected' => __(
                        'Not selected',
                        'tutorhelper-bookings'
                    ),

                    'loadingTimes' => __(
                        'Loading available times…',
                        'tutorhelper-bookings'
                    ),

                    'noTimes' => __(
                        'No available times remain for this date.',
                        'tutorhelper-bookings'
                    ),

                    'timeError' => __(
                        'Available times could not be loaded. Please try again.',
                        'tutorhelper-bookings'
                    ),

                    'submitting' => __(
                        'Sending request…',
                        'tutorhelper-bookings'
                    ),

                    'submitError' => __(
                        'Your lesson request could not be sent. Please check your selection and try again.',
                        'tutorhelper-bookings'
                    ),

                    'submitSuccess' => __(
                        'Your lesson request has been sent to your tutor for confirmation.',
                        'tutorhelper-bookings'
                    ),

					'redirecting' => __(
						'Redirecting…',
						'tutorhelper-bookings'
					),
                ),
			)
		);
	}
}
