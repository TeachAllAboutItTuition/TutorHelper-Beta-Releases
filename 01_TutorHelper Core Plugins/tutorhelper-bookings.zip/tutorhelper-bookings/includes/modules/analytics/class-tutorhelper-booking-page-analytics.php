<?php
/**
 * Privacy-conscious booking-page analytics.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records aggregate booking-page views and exposes dashboard reporting.
 *
 * No IP address, user ID, cookie, referrer, user agent or individual visit
 * record is stored. Each rendered request counts as one page view.
 */
final class TutorHelper_Booking_Page_Analytics {

	const SETTINGS_TAB     = 'analytics';
	const SETTINGS_GROUP   = 'tutorhelper_booking_analytics_settings';
	const OPTION_ENABLED   = 'tutorhelper_booking_analytics_enabled';
	const OPTION_RETENTION = 'tutorhelper_booking_analytics_retention_days';
	const CLEANUP_HOOK     = 'tutorhelper_booking_analytics_cleanup';

	/** @var bool */
	private static $recorded_request = false;

	/** Register hooks. */
	public static function init() {
		add_filter( 'pre_do_shortcode_tag', array( __CLASS__, 'track_booking_shortcode' ), 10, 4 );
		add_action( 'init', array( __CLASS__, 'schedule_cleanup' ) );
		add_action( self::CLEANUP_HOOK, array( __CLASS__, 'delete_expired_data' ) );
		add_action( 'add_option_' . self::OPTION_RETENTION, array( __CLASS__, 'delete_expired_data' ), 10, 0 );
		add_action( 'update_option_' . self::OPTION_RETENTION, array( __CLASS__, 'delete_expired_data' ), 10, 0 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_filter( 'tutorhelper_settings_tabs', array( __CLASS__, 'add_settings_tab' ) );
		add_action( 'tutorhelper_settings_render_tab', array( __CLASS__, 'render_settings_tab' ) );
		add_filter( 'tutorhelper_dashboard_widgets', array( __CLASS__, 'add_dashboard_widgets' ), 20, 2 );
	}

	/** Register analytics settings. */
	public static function register_settings() {
		register_setting(
			self::SETTINGS_GROUP,
			self::OPTION_ENABLED,
			array(
				'type'              => 'boolean',
				'sanitize_callback' => array( __CLASS__, 'sanitize_enabled' ),
				'default'           => 1,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			self::OPTION_RETENTION,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( __CLASS__, 'sanitize_retention' ),
				'default'           => 180,
			)
		);
	}

	/** @param mixed $value Submitted setting. @return int */
	public static function sanitize_enabled( $value ) {
		return empty( $value ) ? 0 : 1;
	}

	/** @param mixed $value Submitted retention. @return int */
	public static function sanitize_retention( $value ) {
		$value   = absint( $value );
		$allowed = array( 30, 90, 180, 365, 730 );
		return in_array( $value, $allowed, true ) ? $value : 180;
	}

	/** @param array $tabs Settings tabs. @return array */
	public static function add_settings_tab( $tabs ) {
		$tabs[ self::SETTINGS_TAB ] = array(
			'label' => __( 'Analytics', 'tutorhelper-bookings' ),
			'icon'  => 'dashicons-chart-area',
		);
		return $tabs;
	}

	/** @param string $selected_tab Selected Settings tab. @return void */
	public static function render_settings_tab( $selected_tab ) {
		if ( self::SETTINGS_TAB !== $selected_tab ) {
			return;
		}
		?>
		<form method="post" action="options.php" class="tutorhelper-settings-form">
			<?php settings_fields( self::SETTINGS_GROUP ); ?>
			<section class="tutorhelper-card">
				<div class="tutorhelper-card__header">
					<h2><?php esc_html_e( 'Booking-page analytics', 'tutorhelper-bookings' ); ?></h2>
				</div>
				<div class="tutorhelper-card__body">
					<p><?php esc_html_e( 'Measure demand for the student booking page using daily aggregate page views.', 'tutorhelper-bookings' ); ?></p>
					<div class="tutorhelper-input-field is-full-width">
						<label for="<?php echo esc_attr( self::OPTION_ENABLED ); ?>">
							<input type="hidden" name="<?php echo esc_attr( self::OPTION_ENABLED ); ?>" value="0">
							<input type="checkbox" id="<?php echo esc_attr( self::OPTION_ENABLED ); ?>" name="<?php echo esc_attr( self::OPTION_ENABLED ); ?>" value="1" <?php checked( self::is_enabled() ); ?>>
							<?php esc_html_e( 'Record booking-page views', 'tutorhelper-bookings' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'One page render counts as one view, so repeat visits and reloads are counted. TutorHelper stores only the date and total count—never IP addresses, account IDs, cookies, browser fingerprints, referrers or individual visit records.', 'tutorhelper-bookings' ); ?></p>
					</div>
					<div class="tutorhelper-input-field">
						<label for="<?php echo esc_attr( self::OPTION_RETENTION ); ?>"><?php esc_html_e( 'Keep aggregate data for', 'tutorhelper-bookings' ); ?></label>
						<select id="<?php echo esc_attr( self::OPTION_RETENTION ); ?>" name="<?php echo esc_attr( self::OPTION_RETENTION ); ?>">
							<?php foreach ( array( 30, 90, 180, 365, 730 ) as $days ) : ?>
								<option value="<?php echo esc_attr( $days ); ?>" <?php selected( self::get_retention_days(), $days ); ?>>
									<?php
					/* translators: %s: Number of days for which analytics data is retained. */
					echo esc_html( sprintf( _n( '%s day', '%s days', $days, 'tutorhelper-bookings' ), number_format_i18n( $days ) ) );
					?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Older daily totals are deleted automatically. Data begins when this feature is enabled; earlier visitor history cannot be reconstructed.', 'tutorhelper-bookings' ); ?></p>
					</div>
				</div>
			</section>
			<?php submit_button( __( 'Save analytics settings', 'tutorhelper-bookings' ), 'primary' ); ?>
		</form>
		<?php
	}

	/**
	 * Count one booking shortcode render.
	 *
	 * @param false|string $return Short-circuit value.
	 * @param string       $tag Shortcode tag.
	 * @param array|string $attr Shortcode attributes.
	 * @param array        $match Shortcode regex match.
	 * @return false|string
	 */
	public static function track_booking_shortcode( $return, $tag, $attr, $match ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required filter signature.
		if (
			'tutorhelper_student_booking' !== $tag
			|| false !== $return
			|| self::$recorded_request
			|| ! self::is_enabled()
			|| is_admin()
			|| wp_doing_ajax()
			|| wp_doing_cron()
			|| current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return $return;
		}

		self::$recorded_request = true;
		self::record_view();
		return $return;
	}

	/** Record a daily aggregate page view atomically. */
	private static function record_view() {
		global $wpdb;

		$table = self::get_table_name();
		$date  = current_time( 'Y-m-d' );
		$result = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic aggregate counter must be written directly.
			$wpdb->prepare(
				'INSERT INTO %i (view_date, view_count, updated_at) VALUES (%s, %d, %s)
				ON DUPLICATE KEY UPDATE view_count = view_count + 1, updated_at = VALUES(updated_at)',
				$table,
				$date,
				1,
				current_time( 'mysql', true )
			)
		);

		if ( false === $result ) {
			TutorHelper_Logger::error(
				'Booking-page aggregate view could not be recorded.',
				array(
					'table'          => $table,
					'database_error' => $wpdb->last_error,
				)
			);
		}
	}

	/** Ensure daily retention cleanup is scheduled. */
	public static function schedule_cleanup() {
		if ( ! wp_next_scheduled( self::CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_HOOK );
		}
	}

	/** Delete daily aggregate totals beyond the configured retention period. */
	public static function delete_expired_data() {
		global $wpdb;

		$cutoff = ( new DateTimeImmutable( 'today', wp_timezone() ) )
			->modify( '-' . ( self::get_retention_days() - 1 ) . ' days' )
			->format( 'Y-m-d' );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Scheduled retention operation.
			$wpdb->prepare(
				'DELETE FROM %i WHERE view_date < %s',
				self::get_table_name(),
				$cutoff
			)
		);
	}

	/** @return bool */
	public static function is_enabled() {
		return (bool) get_option( self::OPTION_ENABLED, 1 );
	}

	/** @return int */
	public static function get_retention_days() {
		return self::sanitize_retention( get_option( self::OPTION_RETENTION, 180 ) );
	}

	/** @param string $from Inclusive date. @param string $to Inclusive date. @return int */
	public static function get_total( $from, $to ) {
		global $wpdb;
		if ( ! self::valid_date( $from ) || ! self::valid_date( $to ) ) {
			return 0;
		}
		return absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Dashboard reporting requires current aggregate values.
				$wpdb->prepare(
					'SELECT COALESCE(SUM(view_count), 0) FROM %i WHERE view_date BETWEEN %s AND %s',
					self::get_table_name(),
					$from,
					$to
				)
			)
		);
	}

	/** @param string $from Inclusive date. @param string $to Inclusive date. @return array */
	public static function get_series( $from, $to ) {
		global $wpdb;
		if ( ! self::valid_date( $from ) || ! self::valid_date( $to ) ) {
			return array();
		}
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Dashboard reporting requires current aggregate values.
			$wpdb->prepare(
				'SELECT view_date, view_count FROM %i WHERE view_date BETWEEN %s AND %s ORDER BY view_date ASC',
				self::get_table_name(),
				$from,
				$to
			),
			ARRAY_A
		);
		$series = array();
		foreach ( $rows as $row ) {
			$series[ $row['view_date'] ] = absint( $row['view_count'] );
		}
		return $series;
	}

	/** @param array $widgets Existing widgets. @param array $context Dashboard context. @return array */
	public static function add_dashboard_widgets( $widgets, $context ) {
		$from     = $context['start_local']->format( 'Y-m-d' );
		$to       = $context['end_local']->format( 'Y-m-d' );
		$total    = self::is_enabled() ? self::get_total( $from, $to ) : 0;
		$previous = self::previous_period( $context['start_local'], $context['end_local'] );
		$old      = self::is_enabled() ? self::get_total( $previous['from'], $previous['to'] ) : 0;

		$widgets['booking_page_views'] = array(
			'label'       => __( 'Booking page views', 'tutorhelper-bookings' ),
			'value'       => self::is_enabled() ? number_format_i18n( $total ) : '—',
			'description' => self::is_enabled()
				? __( 'Aggregate page views; date filters apply.', 'tutorhelper-bookings' )
				: __( 'Enable booking-page analytics in Settings.', 'tutorhelper-bookings' ),
			'icon'        => 'visibility',
			'tone'        => 'primary',
			'section'     => 'analytics',
			'priority'    => 10,
		);

		$widgets['booking_page_trend'] = array(
			'label'       => __( 'Visitor trend', 'tutorhelper-bookings' ),
			'value'       => self::is_enabled() ? self::format_trend( $total, $old ) : '—',
			'description' => __( 'Compared with the immediately preceding period of the same length.', 'tutorhelper-bookings' ),
			'icon'        => 'chart-line',
			'tone'        => 'accent',
			'section'     => 'analytics',
			'priority'    => 20,
			'panel_callback' => array( __CLASS__, 'render_dashboard_chart' ),
			'panel_args' => $context,
		);

		return $widgets;
	}

	/** @param array $context Dashboard context. @return void */
	public static function render_dashboard_chart( $context ) {
		if ( ! self::is_enabled() ) {
			return;
		}

		$start = $context['start_local']->modify( 'first day of this month' );
		$end = $context['end_local']->modify( 'last day of this month' );
		$series = self::get_series( $start->format( 'Y-m-d' ), $end->format( 'Y-m-d' ) );
		$values = array_values( $series );
		$day_count = absint( $start->diff( $end )->days ) + 1;
		$minimum = count( $values ) < $day_count ? 0 : min( $values );
		$maximum = max( array_merge( array( 1 ), $values ) );
		?>
		<section class="tutorhelper-dashboard__heatmap" aria-labelledby="tutorhelper-booking-view-chart-title">
			<header>
				<h2 id="tutorhelper-booking-view-chart-title"><?php esc_html_e( 'Booking page view heatmap', 'tutorhelper-bookings' ); ?></h2>
				<p><?php esc_html_e( 'Each square is one calendar day. Darker colour indicates more booking-page views. Hover over a date to see the number of views.', 'tutorhelper-bookings' ); ?></p>
				<div class="tutorhelper-dashboard__heatmap-legend" aria-label="<?php echo esc_attr__( 'Booking page view colour scale', 'tutorhelper-bookings' ); ?>">
					<span><?php echo esc_html( number_format_i18n( $minimum ) ); ?></span>
					<span class="level-0" aria-hidden="true"></span><span class="level-1" aria-hidden="true"></span><span class="level-2" aria-hidden="true"></span><span class="level-3" aria-hidden="true"></span><span class="level-4" aria-hidden="true"></span><span class="level-5" aria-hidden="true"></span>
					<span><?php echo esc_html( number_format_i18n( $maximum ) ); ?></span>
				</div>
			</header>
			<?php for ( $month = $start; $month <= $end; $month = $month->modify( '+1 month' ) ) : ?>
				<?php
				$month_end = $month->modify( 'last day of this month' );
				$leading = absint( $month->format( 'N' ) ) - 1;
				?>
				<section class="tutorhelper-dashboard__heatmap-month">
					<h3><?php echo esc_html( wp_date( 'F Y', $month->getTimestamp(), wp_timezone() ) ); ?></h3>
					<div class="tutorhelper-dashboard__heatmap-weekdays" aria-hidden="true">
						<?php foreach ( array( __( 'Mon', 'tutorhelper-bookings' ), __( 'Tue', 'tutorhelper-bookings' ), __( 'Wed', 'tutorhelper-bookings' ), __( 'Thu', 'tutorhelper-bookings' ), __( 'Fri', 'tutorhelper-bookings' ), __( 'Sat', 'tutorhelper-bookings' ), __( 'Sun', 'tutorhelper-bookings' ) ) as $weekday ) : ?>
							<span><?php echo esc_html( $weekday ); ?></span>
						<?php endforeach; ?>
					</div>
					<div class="tutorhelper-dashboard__heatmap-grid">
						<?php for ( $blank = 0; $blank < $leading; $blank++ ) : ?>
							<span class="is-empty" aria-hidden="true"></span>
						<?php endfor; ?>
						<?php for ( $day = $month; $day <= $month_end; $day = $day->modify( '+1 day' ) ) : ?>
							<?php
							$key = $day->format( 'Y-m-d' );
							$value = isset( $series[ $key ] ) ? absint( $series[ $key ] ) : 0;
							$level = $value ? max( 1, min( 5, (int) ceil( ( $value / $maximum ) * 5 ) ) ) : 0;
							$label = sprintf(
								/* translators: 1: date, 2: booking-page view count. */
								__( '%1$s: %2$s views', 'tutorhelper-bookings' ),
								wp_date( get_option( 'date_format' ), $day->getTimestamp(), wp_timezone() ),
								number_format_i18n( $value )
							);
							?>
							<span class="tutorhelper-dashboard__heatmap-day level-<?php echo esc_attr( $level ); ?>" title="<?php echo esc_attr( $label ); ?>">
								<span aria-hidden="true"><?php echo esc_html( $day->format( 'j' ) ); ?></span>
								<span class="screen-reader-text"><?php echo esc_html( $label ); ?></span>
							</span>
						<?php endfor; ?>
					</div>
				</section>
			<?php endfor; ?>
		</section>
		<?php
	}

	/** @return string */
	private static function get_table_name() {
		return TutorHelper_Bookings_Database::get_table_name( 'booking_page_views' );
	}

	/** @param string $date Date string. @return bool */
	private static function valid_date( $date ) {
		$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $date, wp_timezone() );
		return false !== $parsed && $parsed->format( 'Y-m-d' ) === $date;
	}

	/** @param DateTimeImmutable $start Start. @param DateTimeImmutable $end End. @return array */
	private static function previous_period( $start, $end ) {
		$days = (int) $start->diff( $end )->days + 1;
		$old_end = $start->modify( '-1 day' );
		return array(
			'from' => $old_end->modify( '-' . ( $days - 1 ) . ' days' )->format( 'Y-m-d' ),
			'to'   => $old_end->format( 'Y-m-d' ),
		);
	}

	/** @param int $current Current total. @param int $previous Previous total. @return string */
	private static function format_trend( $current, $previous ) {
		if ( 0 === $previous ) {
			return 0 === $current ? '0%' : __( 'New', 'tutorhelper-bookings' );
		}
		$change = (int) round( ( ( $current - $previous ) / $previous ) * 100 );
		return ( 0 < $change ? '+' : '' ) . number_format_i18n( $change ) . '%';
	}

	/** @param DateTimeImmutable $start Start. @param DateTimeImmutable $end End. @return array */
	private static function chart_points( $start, $end ) {
		$series = self::get_series( $start->format( 'Y-m-d' ), $end->format( 'Y-m-d' ) );
		$days   = (int) $start->diff( $end )->days + 1;
		$points = array();
		if ( 62 >= $days ) {
			for ( $day = $start; $day <= $end; $day = $day->modify( '+1 day' ) ) {
				$key = $day->format( 'Y-m-d' );
				$points[] = array(
					'label' => wp_date( get_option( 'date_format' ), $day->getTimestamp(), wp_timezone() ),
					'value' => isset( $series[ $key ] ) ? $series[ $key ] : 0,
				);
			}
			return $points;
		}

		$buckets = array();
		foreach ( $series as $date => $value ) {
			$key = substr( $date, 0, 7 );
			$buckets[ $key ] = isset( $buckets[ $key ] ) ? $buckets[ $key ] + $value : $value;
		}
		$month = $start->modify( 'first day of this month' );
		$last  = $end->modify( 'first day of this month' );
		for ( ; $month <= $last; $month = $month->modify( '+1 month' ) ) {
			$key = $month->format( 'Y-m' );
			$points[] = array(
				'label' => wp_date( 'M Y', $month->getTimestamp(), wp_timezone() ),
				'value' => isset( $buckets[ $key ] ) ? $buckets[ $key ] : 0,
			);
		}
		return $points;
	}
}
