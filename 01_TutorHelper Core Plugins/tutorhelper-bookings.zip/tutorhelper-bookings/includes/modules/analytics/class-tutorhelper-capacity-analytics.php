<?php
/**
 * Remaining bookable lesson capacity reporting.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculates capacity from the same slots exposed to students.
 */
final class TutorHelper_Capacity_Analytics {

	/** Register dashboard hooks. */
	public static function init() {
		add_filter( 'tutorhelper_dashboard_widgets', array( __CLASS__, 'add_dashboard_widget' ), 15, 2 );
	}

	/**
	 * Add the remaining capacity card.
	 *
	 * @param array $widgets Existing widgets.
	 * @param array $context Dashboard context.
	 * @return array
	 */
	public static function add_dashboard_widget( $widgets, $context ) {
		$days = (int) $context['start_local']->diff( $context['end_local'] )->days + 1;
		if ( 366 < $days ) {
			$widgets['remaining_bookable_hours'] = array(
				'label'       => __( 'Remaining bookable hours', 'tutorhelper-bookings' ),
				'value'       => '—',
				'description' => __( 'Choose a date range of 366 days or fewer to calculate capacity.', 'tutorhelper-bookings' ),
				'icon'        => 'clock',
				'tone'        => 'accent',
				'section'     => 'bookings',
				'priority'    => 35,
			);
			return $widgets;
		}

		$seconds = self::calculate_seconds( $context );
		$widgets['remaining_bookable_hours'] = array(
			'label'       => __( 'Remaining bookable hours', 'tutorhelper-bookings' ),
			'value'       => self::format_hours( $seconds ),
			'description' => __( 'Student-facing slots after bookings, exclusions and Booking Type buffers. Student and status filters do not apply.', 'tutorhelper-bookings' ),
			'icon'        => 'clock',
			'tone'        => 'accent',
			'section'     => 'bookings',
			'priority'    => 35,
		);

		return $widgets;
	}

	/**
	 * Calculate the union of currently bookable lesson intervals.
	 *
	 * Alternative Booking Types can expose overlapping choices. Merging those
	 * intervals prevents the same tutor time from being counted twice.
	 *
	 * @param array $context Dashboard context.
	 * @return int Seconds of bookable lesson time.
	 */
	private static function calculate_seconds( $context ) {
		$tutors = self::get_tutor_ids( $context['filters']['tutor_id'] );
		$types  = self::get_booking_types( $context['filters']['booking_type_id'] );
		if ( empty( $tutors ) || empty( $types ) ) {
			return 0;
		}

		$intervals = array();
		$first_day = $context['start_local'];
		$today     = new DateTimeImmutable( 'today', $context['timezone'] );
		if ( $first_day < $today ) {
			$first_day = $today;
		}

		if ( $first_day > $context['end_local'] ) {
			return 0;
		}

		foreach ( $tutors as $tutor_id ) {
			for ( $day = $first_day; $day <= $context['end_local']; $day = $day->modify( '+1 day' ) ) {
				$date = $day->format( 'Y-m-d' );
				$key  = $tutor_id . ':' . $date;
				foreach ( $types as $booking_type ) {
					$slots = TutorHelper_Student_Booking_Slots::get_for_date(
						$tutor_id,
						absint( $booking_type->id ),
						$date
					);
					if ( is_wp_error( $slots ) || empty( $slots ) ) {
						continue;
					}
					foreach ( $slots as $slot ) {
						$start = self::slot_timestamp( $slot, 'start', $context['timezone'] );
						$end   = self::slot_timestamp( $slot, 'end', $context['timezone'] );
						if ( $start && $end && $end > $start ) {
							$intervals[ $key ][] = array( $start, $end );
						}
					}
				}
			}
		}

		$seconds = 0;
		foreach ( $intervals as $day_intervals ) {
			usort(
				$day_intervals,
				function ( $left, $right ) {
					return $left[0] - $right[0];
				}
			);
			$merged = array();
			foreach ( $day_intervals as $interval ) {
				$last = count( $merged ) - 1;
				if ( 0 > $last || $interval[0] > $merged[ $last ][1] ) {
					$merged[] = $interval;
				} else {
					$merged[ $last ][1] = max( $merged[ $last ][1], $interval[1] );
				}
			}
			foreach ( $merged as $interval ) {
				$seconds += $interval[1] - $interval[0];
			}
		}

		return $seconds;
	}

	/** @param int $selected_tutor Selected tutor. @return array */
	private static function get_tutor_ids( $selected_tutor ) {
		if ( $selected_tutor ) {
			return array( absint( $selected_tutor ) );
		}

		global $wpdb;
		$table = TutorHelper_Bookings_Database::get_table_name( 'availability' );
		return array_values(
			array_filter(
				array_map(
					'absint',
					$wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Current availability owners are needed for reporting.
						$wpdb->prepare( 'SELECT DISTINCT tutor_user_id FROM %i WHERE is_active = %d', $table, 1 )
					)
				)
			)
		);
	}

	/** @param int $selected_type Selected Booking Type. @return array */
	private static function get_booking_types( $selected_type ) {
		if ( $selected_type ) {
			$type = TutorHelper_Booking_Types::get_by_id( $selected_type );
			return self::is_bookable_type( $type ) ? array( $type ) : array();
		}

		return array_values(
			array_filter(
				TutorHelper_Booking_Types::get_active(),
				array( __CLASS__, 'is_bookable_type' )
			)
		);
	}

	/** @param object|null $type Booking Type. @return bool */
	private static function is_bookable_type( $type ) {
		return is_object( $type )
			&& ! empty( $type->is_active )
			&& isset( $type->online_booking_visibility )
			&& 'bookable' === sanitize_key( $type->online_booking_visibility );
	}

	/** @param array $slot Slot data. @param string $key Field key. @param DateTimeZone $timezone Timezone. @return int */
	private static function slot_timestamp( $slot, $key, $timezone ) {
		if ( empty( $slot[ $key ] ) ) {
			return 0;
		}
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $slot[ $key ], $timezone );
		return false === $date ? 0 : $date->getTimestamp();
	}

	/** @param int $seconds Seconds. @return string */
	private static function format_hours( $seconds ) {
		$hours = round( $seconds / HOUR_IN_SECONDS, 1 );
		$decimals = floor( $hours ) === $hours ? 0 : 1;
		return sprintf(
			/* translators: %s: number of hours. */
			_n( '%s hour', '%s hours', $hours, 'tutorhelper-bookings' ),
			number_format_i18n( $hours, $decimals )
		);
	}
}
