<?php
/**
 * TutorHelper analytics module bootstrap.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once TUTORHELPER_BOOKINGS_PATH . 'includes/modules/analytics/class-tutorhelper-booking-page-analytics.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/modules/analytics/class-tutorhelper-capacity-analytics.php';

/**
 * Starts the Core analytics services.
 */
final class TutorHelper_Analytics_Module {

	/**
	 * Register analytics hooks.
	 *
	 * @return void
	 */
	public static function init() {
		TutorHelper_Booking_Page_Analytics::init();
		TutorHelper_Capacity_Analytics::init();
	}
}
