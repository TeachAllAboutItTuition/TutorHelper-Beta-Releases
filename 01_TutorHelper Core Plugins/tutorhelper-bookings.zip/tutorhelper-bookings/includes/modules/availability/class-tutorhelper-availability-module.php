<?php
/**
 * TutorHelper Availability module loader.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads Availability components only where required.
 */
final class TutorHelper_Availability_Module {

	/**
	 * Start the Availability module.
	 *
	 * Reusable data services load for all requests. Administration and
	 * diagnostics remain restricted to wp-admin.
	 *
	 * @return void
	 */
	public static function init() {
		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/availability/'
			. 'class-tutorhelper-booking-availability.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/availability/'
			. 'class-tutorhelper-availability-exceptions.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/availability/'
			. 'class-tutorhelper-availability-calendar.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/availability/'
			. 'class-tutorhelper-availability-range-save.php';

		if ( ! is_admin() ) {
			return;
		}

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/availability/'
			. 'class-tutorhelper-availability-calendar-admin.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/availability/'
			. 'class-tutorhelper-availability-admin.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/availability/'
			. 'class-tutorhelper-availability-diagnostics.php';

		TutorHelper_Availability_Admin::init();
		TutorHelper_Availability_Diagnostics::init();
	}
}
