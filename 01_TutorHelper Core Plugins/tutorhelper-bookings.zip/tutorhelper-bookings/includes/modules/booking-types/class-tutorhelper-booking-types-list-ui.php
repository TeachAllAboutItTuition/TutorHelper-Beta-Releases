<?php
/**
 * Booking Type list quality-of-life helpers.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds Booking Hub quality-of-life assets and Booking Type visibility metadata.
 */
final class TutorHelper_Booking_Types_List_UI {

	/**
	 * Asset handles.
	 *
	 * @var string
	 */
	const SCRIPT_HANDLE = 'tutorhelper-booking-type-list-visibility';
	const STYLE_HANDLE = 'tutorhelper-booking-hub-qol';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' ),
			35
		);
	}

	/**
	 * Load shared Booking Hub polish and the Calendar Booking Type enhancement.
	 *
	 * @param string $hook_suffix Current WordPress admin hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		unset( $hook_suffix );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- These query arguments select a read-only admin screen; they do not change state.
		$page = isset( $_GET['page'] ) && ! is_array( $_GET['page'] )
			? sanitize_key( wp_unslash( $_GET['page'] ) )
			: '';
		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] )
			? sanitize_key( wp_unslash( $_GET['tab'] ) )
			: 'calendar';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if (
			TutorHelper_Booking_Hub::PAGE_SLUG !== $page
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$style_path = TUTORHELPER_BOOKINGS_PATH
			. 'assets/css/booking-hub-qol.css';

		wp_enqueue_style(
			self::STYLE_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/css/booking-hub-qol.css',
			array( 'tutorhelper-booking-hub' ),
			file_exists( $style_path )
				? (string) filemtime( $style_path )
				: TUTORHELPER_BOOKINGS_VERSION
		);

		if ( 'calendar' !== $tab ) {
			return;
		}

		$script_path = TUTORHELPER_BOOKINGS_PATH
			. 'assets/js/booking-type-list-visibility.js';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/js/booking-type-list-visibility.js',
			array(),
			file_exists( $script_path )
				? (string) filemtime( $script_path )
				: TUTORHELPER_BOOKINGS_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperBookingTypeListVisibility',
			array(
				'bookingTypes' => self::prepare_booking_types(),
			)
		);
	}

	/**
	 * Prepare visibility details keyed by Booking Type ID.
	 *
	 * The admin visibility filter is deliberately reused here so Pro virtual
	 * visibility modes are displayed consistently with the edit form.
	 *
	 * @return array
	 */
	private static function prepare_booking_types() {
		$prepared = array();
		$labels = self::get_visibility_labels();

		foreach ( TutorHelper_Booking_Types::get_all() as $booking_type ) {
			if ( ! is_object( $booking_type ) || empty( $booking_type->id ) ) {
				continue;
			}

			$visibility = ! empty( $booking_type->online_booking_visibility )
				? sanitize_key( $booking_type->online_booking_visibility )
				: 'bookable';

			$visibility = sanitize_key(
				apply_filters(
					'tutorhelper_booking_type_admin_visibility',
					$visibility,
					$booking_type
				)
			);

			$prepared[ absint( $booking_type->id ) ] = array(
				'visibility' => $visibility,
				'label' => isset( $labels[ $visibility ] )
					? $labels[ $visibility ]
					: ucwords( str_replace( '_', ' ', $visibility ) ),
				'isHidden' => 'hidden' === $visibility,
			);
		}

		return $prepared;
	}

	/**
	 * Return Core visibility labels plus extension-provided choices.
	 *
	 * @return array
	 */
	private static function get_visibility_labels() {
		$labels = array(
			'bookable' => __( 'Visible and bookable', 'tutorhelper-bookings' ),
			'private_url' => __( 'Bookable by private link', 'tutorhelper-bookings' ),
			'visible_not_bookable' => __( 'Visible but not bookable', 'tutorhelper-bookings' ),
			'hidden' => __( 'Hidden', 'tutorhelper-bookings' ),
		);

		return apply_filters(
			'tutorhelper_booking_type_visibility_options',
			$labels
		);
	}
}
