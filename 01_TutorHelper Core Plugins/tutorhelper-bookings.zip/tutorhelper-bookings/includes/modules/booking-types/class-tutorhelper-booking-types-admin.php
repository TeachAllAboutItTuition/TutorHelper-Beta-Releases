<?php
/**
 * Booking Types admin interface.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the Booking Types WordPress admin page and form actions.
 */
final class TutorHelper_Booking_Types_Admin {

	/**
	 * Booking Types page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'tutorhelper-booking-types';

	/**
	 * Save action name.
	 *
	 * @var string
	 */
	const SAVE_ACTION = 'tutorhelper_save_booking_type';

	/**
	 * Status action name.
	 *
	 * Used for archive and restore operations.
	 *
	 * @var string
	 */
	const STATUS_ACTION = 'tutorhelper_change_booking_type_status';

	/**
	 * AJAX action used to save Booking Type order.
	 *
	 * @var string
	 */
	const REORDER_ACTION = 'tutorhelper_reorder_booking_types';




	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {
		

		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array( __CLASS__, 'handle_save' )
		);

		add_action(
			'admin_post_' . self::STATUS_ACTION,
			array( __CLASS__, 'handle_status_change' )
		);

		add_action(
			'tutorhelper_booking_hub_booking_types_panel',
			array( __CLASS__, 'render_hub_panel' ),
			10,
			1
		);

		add_action(
			'wp_ajax_' . self::REORDER_ACTION,
			array( __CLASS__, 'handle_reorder' )
		);


	}



	/**
	 * Process the create or update form.
	 *
	 * @return void
	 */
	public static function handle_save() {
		self::verify_admin_request();

		check_admin_referer(
			self::SAVE_ACTION
		);

		$booking_type_id = isset( $_POST['booking_type_id'] )
			? absint( $_POST['booking_type_id'] )
			: 0;

		$data = array(
			'title' => isset( $_POST['title'] )
				? sanitize_text_field(
					wp_unslash( $_POST['title'] )
				)
				: '',
			'description' => isset( $_POST['description'] )
				? sanitize_textarea_field(
					wp_unslash( $_POST['description'] )
				)
				: '',
			'duration_minutes' => isset( $_POST['duration_minutes'] )
				? absint( $_POST['duration_minutes'] )
				: 60,
			'buffer_after_minutes' => isset( $_POST['buffer_after_minutes'] )
				? absint( $_POST['buffer_after_minutes'] )
				: 0,
			'price_minor_units' => isset(
				$_POST['price']
			)
				? TutorHelper_Currency::major_to_minor_units(
					sanitize_text_field(
						wp_unslash( $_POST['price'] )
					),
					TutorHelper_Currency::get_currency()
				)
				: 0,
			'location_type' => isset( $_POST['location_type'] )
				? sanitize_key(
					wp_unslash( $_POST['location_type'] )
				)
				: 'online',
			'location_types' => isset( $_POST['location_types'] )
				&& is_array( $_POST['location_types'] )
				? array_map(
					'sanitize_key',
					wp_unslash( $_POST['location_types'] )
				)
				: array(),
			'location_details' => isset( $_POST['location_details'] )
				? sanitize_textarea_field(
					wp_unslash( $_POST['location_details'] )
				)
				: '',
			'colour' => isset( $_POST['colour'] )
				? (
					sanitize_hex_color(
						wp_unslash( $_POST['colour'] )
					)
						?: '#FF6326'
				)
				: '#FF6326',
			'online_booking_visibility' =>
				isset( $_POST['online_booking_visibility'] )
					? sanitize_key(
						wp_unslash(
							$_POST['online_booking_visibility']
						)
					)
					: 'bookable',
			'notice_period_hours' =>
				isset( $_POST['notice_period_hours'] )
					? absint( $_POST['notice_period_hours'] )
					: 48,
			'cancellations_allowed' =>
				isset( $_POST['cancellations_allowed'] )
					? 1
					: 0,
			'cancellation_notice_hours' =>
				isset( $_POST['cancellation_notice_hours'] )
					? absint(
						$_POST['cancellation_notice_hours']
					)
					: 24,
		);

		if ( $booking_type_id ) {
			$result = TutorHelper_Booking_Types::update(
				$booking_type_id,
				$data
			);

			$success_notice = 'updated';
		} else {
			$result = TutorHelper_Booking_Types::create( $data );

			$success_notice = 'created';
		}

		if ( is_wp_error( $result ) ) {
			TutorHelper_Logger::warning(
				'Booking Type admin save was rejected.',
				array(
					'booking_type_id' => $booking_type_id,
					'error_code'      => $result->get_error_code(),
				)
			);

			self::redirect(
				'error',
				$result->get_error_code(),
				$booking_type_id
			);
		}

		$saved_booking_type_id =
			$booking_type_id
				? $booking_type_id
				: absint( $result );

		/**
		 * Fires after a Booking Type has been successfully
		 * saved through the Core admin form.
		 *
		 * Extensions may persist additional settings using
		 * the final Booking Type ID.
		 *
		 * @param int  $saved_booking_type_id Booking Type ID.
		 * @param bool $is_update             Whether this was an update.
		 */
		do_action(
			'tutorhelper_booking_type_admin_saved',
			$saved_booking_type_id,
			(bool) $booking_type_id
		);

		
		TutorHelper_Logger::success(
			$booking_type_id
				? 'Booking Type updated from the admin page.'
				: 'Booking Type created from the admin page.',
			array(
				'booking_type_id' => $booking_type_id
					? $booking_type_id
					: absint( $result ),

				'duration_minutes' => absint(
					$data['duration_minutes']
				),

				'price_minor_units' => absint(
					$data['price_minor_units']
				),

				'currency' =>
					TutorHelper_Currency::get_currency(),
			)
		);

		self::redirect( $success_notice );
	}

	/**
	 * Process archive or restore actions.
	 *
	 * @return void
	 */
	public static function handle_status_change() {
		self::verify_admin_request();

		check_admin_referer(
			self::STATUS_ACTION
		);

		$booking_type_id = isset( $_POST['booking_type_id'] )
			? absint( $_POST['booking_type_id'] )
			: 0;

		$status_action = isset( $_POST['status_action'] )
			? sanitize_key(
				wp_unslash( $_POST['status_action'] )
			)
			: '';

		if ( ! $booking_type_id ) {
			self::redirect(
				'error',
				'tutorhelper_booking_type_invalid_id'
			);
		}

		if ( 'archive' === $status_action ) {
			$result = TutorHelper_Booking_Types::archive(
				$booking_type_id
			);

			$notice = 'archived';
		} elseif ( 'restore' === $status_action ) {
			$result = TutorHelper_Booking_Types::restore(
				$booking_type_id
			);

			$notice = 'restored';
		} else {
			self::redirect(
				'error',
				'tutorhelper_booking_type_invalid_status_action'
			);
		}

		if ( is_wp_error( $result ) ) {
			TutorHelper_Logger::warning(
				'Booking Type status change was rejected.',
				array(
					'booking_type_id' => $booking_type_id,
					'error_code'      => $result->get_error_code(),
				)
			);

			self::redirect(
				'error',
				$result->get_error_code()
			);
		}

		TutorHelper_Logger::success(
			'Booking Type status changed from the admin page.',
			array(
				'booking_type_id' => $booking_type_id,
				'status_action'   => $status_action,
			)
		);

		self::redirect( $notice );
	}


	/**
	 * Save a drag-and-drop Booking Type order.
	 *
	 * @return void
	 */
	public static function handle_reorder() {
		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_send_json_error(
				array(
					'message' => __(
						'You do not have permission to reorder Booking Types.',
						'tutorhelper-bookings'
					),
				),
				403
			);
		}

		check_ajax_referer(
			self::REORDER_ACTION,
			'nonce'
		);

		$ordered_ids = isset(
			$_POST['booking_type_ids']
		)
		&& is_array(
			$_POST['booking_type_ids']
		)
			? array_map(
				'absint',
				wp_unslash(
					$_POST['booking_type_ids']
				)
			)
			: array();

		$result =
			TutorHelper_Booking_Types::update_sort_order(
				$ordered_ids
			);

		if ( is_wp_error( $result ) ) {
			TutorHelper_Logger::warning(
				'Booking Type reorder request was rejected.',
				array(
					'error_code' =>
						$result->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'message' =>
						$result->get_error_message(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'message' => __(
					'Booking Type order saved.',
					'tutorhelper-bookings'
				),
			)
		);
	}


	/**
	 * Return the Booking Hub URL for Booking Type management.
	 *
	 * @param array $args Additional query arguments.
	 *
	 * @return string
	 */
	private static function get_hub_url( $args = array() ) {
		$base_args = array(
			'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
			'tab'  => 'calendar',
			'view' => TutorHelper_Booking_Hub::get_selected_view(),
			'date' => TutorHelper_Booking_Hub::get_selected_date()
				->format( 'Y-m-d' ),
		);

		return add_query_arg(
			array_merge(
				$base_args,
				is_array( $args ) ? $args : array()
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Return the URL for adding a Booking Type in the Hub.
	 *
	 * @return string
	 */
	private static function get_add_url() {
		return self::get_hub_url(
			array(
				'booking_type_action' => 'add',
			)
		);
	}

	/**
	 * Return the URL for editing a Booking Type in the Hub.
	 *
	 * @param int $booking_type_id Booking Type ID.
	 *
	 * @return string
	 */
	private static function get_edit_url( $booking_type_id ) {
		return self::get_hub_url(
			array(
				'booking_type_id' => absint(
					$booking_type_id
				),
			)
		);
	}

	/**
	 * Return the Hub URL without Booking Type edit parameters.
	 *
	 * @return string
	 */
	private static function get_cancel_url() {
		return self::get_hub_url();
	}


	/**
	 * Render Booking Type management inside the Booking Hub.
	 *
	 * @param array $booking_types Existing Booking Types.
	 *
	 * @return void
	 */
	public static function render_hub_panel(
		$booking_types = array()
	) {
		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		if (
			is_array( $booking_types )
			&& array_key_exists(
				'booking_types',
				$booking_types
			)
		) {
			$booking_types =
				is_array(
					$booking_types['booking_types']
				)
					? $booking_types['booking_types']
					: array();
		} elseif ( is_object( $booking_types ) ) {
			$booking_types =
				array( $booking_types );
		} elseif ( ! is_array( $booking_types ) ) {
			$booking_types = array();
		}


		$booking_type_id = isset(
			$_GET['booking_type_id'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
		)
			? absint( $_GET['booking_type_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
			: 0;

		$editing_type = $booking_type_id
			? TutorHelper_Booking_Types::get_by_id(
				$booking_type_id
			)
			: null;

		if (
			$editing_type
			&& ! absint( $editing_type->id )
		) {
			$editing_type = null;
		}

		$active_types   = array();
		$archived_types = array();

		foreach ( (array) $booking_types as $booking_type ) {
			if ( absint( $booking_type->is_active ) ) {
				$active_types[] = $booking_type;
			} else {
				$archived_types[] = $booking_type;
			}
		}

		self::render_notice();

		if ( $booking_type_id && ! $editing_type ) {
			?>
			<div class="notice notice-error inline">
				<p>
					<?php
					echo esc_html__(
						'The requested Booking Type could not be found.',
						'tutorhelper-bookings'
					);
					?>
				</p>
			</div>
			<?php
		}

		$booking_type_action = isset(
			$_GET['booking_type_action'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
		)
			? sanitize_key(
				wp_unslash(
					$_GET['booking_type_action'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
				)
			)
			: '';

		$list_expanded = 0 === $booking_type_id
			&& 'add' !== $booking_type_action;

		self::render_hub_list(
			$active_types,
			$archived_types,
			$booking_type_id,
			$list_expanded
		);

		?>
		<hr class="tutorhelper-booking-types-divider" />
		<?php

		self::render_form(
			$editing_type,
			true
		);
	}


	/**
	 * Render an archive or restore action for one Booking Type.
	 *
	 * @param object $booking_type Booking Type record.
	 *
	 * @return void
	 */
	private static function render_hub_status_form(
		$booking_type
	) {
		$is_active = 1 === absint(
			$booking_type->is_active
		);

		$status_action = $is_active
			? 'archive'
			: 'restore';

		$icon = $is_active
			? 'dashicons-trash'
			: 'dashicons-undo';

		$label = $is_active
			? sprintf(
				/* translators: %s: Booking Type title. */
				__(
					'Archive %s',
					'tutorhelper-bookings'
				),
				$booking_type->title
			)
			: sprintf(
				/* translators: %s: Booking Type title. */
				__(
					'Restore %s',
					'tutorhelper-bookings'
				),
				$booking_type->title
			);

		?>
		<form
			method="post"
			action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
			class="tutorhelper-booking-type-status-form"
			data-booking-type-status="<?php echo esc_attr( $status_action ); ?>"
		>
			<input
				type="hidden"
				name="action"
				value="<?php echo esc_attr( self::STATUS_ACTION ); ?>"
			/>

			<input
				type="hidden"
				name="booking_type_id"
				value="<?php echo esc_attr( $booking_type->id ); ?>"
			/>

			<input
				type="hidden"
				name="status_action"
				value="<?php echo esc_attr( $status_action ); ?>"
			/>

			<?php self::render_return_fields(); ?>

			<?php
			wp_nonce_field(
				self::STATUS_ACTION
			);
			?>

			<button
				type="submit"
				class="button-link tutorhelper-booking-type-item__status is-<?php echo esc_attr( $status_action ); ?>"
				aria-label="<?php echo esc_attr( $label ); ?>"
				title="<?php echo esc_attr( $label ); ?>"
			>
				<span
					class="dashicons <?php echo esc_attr( $icon ); ?>"
					aria-hidden="true"
				></span>
			</button>
		</form>
		<?php
	}


	/**
	 * Return a readable location summary.
	 *
	 * @param string|null $location_types Stored CSV locations.
	 *
	 * @return string
	 */
	private static function get_location_summary(
		$location_types
	) {
		$labels = array(
			'online'    => __(
				'Online',
				'tutorhelper-bookings'
			),
			'phone'     => __(
				'Phone',
				'tutorhelper-bookings'
			),
			'in_person' => __(
				'In person',
				'tutorhelper-bookings'
			),
			'other'     => __(
				'Other',
				'tutorhelper-bookings'
			),
		);

		$locations = array_filter(
			array_map(
				'trim',
				explode(
					',',
					(string) $location_types
				)
			)
		);

		$display = array();

		foreach ( $locations as $location ) {
			if ( isset( $labels[ $location ] ) ) {
				$display[] = $labels[ $location ];
			}
		}

		return empty( $display )
			? __( 'No location', 'tutorhelper-bookings' )
			: implode( ' / ', $display );
	}

	/**
	 * Render fields needed to return to the same Hub view.
	 *
	 * @return void
	 */
	private static function render_return_fields() {
		?>
		<input
			type="hidden"
			name="return_to"
			value="hub"
		/>

		<input
			type="hidden"
			name="return_view"
			value="<?php echo esc_attr(
				TutorHelper_Booking_Hub::get_selected_view()
			); ?>"
		/>

		<input
			type="hidden"
			name="return_date"
			value="<?php echo esc_attr(
				TutorHelper_Booking_Hub::get_selected_date()
					->format( 'Y-m-d' )
			); ?>"
		/>
		<?php
	}


	/**
	 * Render active and archived Booking Types inside the Hub.
	 *
	 * The active list can be hidden independently from the complete
	 * Booking Types panel. Active Booking Types are also marked as
	 * sortable so they can be reordered by dragging.
	 *
	 * @param array $active_types     Active Booking Types.
	 * @param array $archived_types   Archived Booking Types.
	 * @param int   $selected_type_id Selected Booking Type ID.
	 * @param bool  $list_expanded    Whether the existing list starts open.
	 *
	 * @return void
	 */
	private static function render_hub_list(
		$active_types,
		$archived_types,
		$selected_type_id = 0,
		$list_expanded = true
	) {
		?>
		<section class="tutorhelper-booking-type-existing">
			<div class="tutorhelper-booking-type-list-header">
				<div>
					<h3>
						<?php
						echo esc_html__(
							'Existing Booking Types',
							'tutorhelper-bookings'
						);
						?>
					</h3>

					<p>
						<?php
						echo esc_html__(
							'Drag active Booking Types into the order students should see them.',
							'tutorhelper-bookings'
						);
						?>
					</p>
				</div>

				<div class="tutorhelper-booking-type-list-header__actions">
					<a
						class="button button-small"
						href="<?php echo esc_url( self::get_add_url() ); ?>"
					>
						<?php
						echo esc_html__(
							'Add new',
							'tutorhelper-bookings'
						);
						?>
					</a>

					<button
						type="button"
						class="button button-small tutorhelper-booking-type-list-toggle"
						aria-expanded="<?php echo $list_expanded ? 'true' : 'false'; ?>"
						aria-controls="tutorhelper-booking-type-existing-content"
						data-show-label="<?php echo esc_attr__(
							'Show existing',
							'tutorhelper-bookings'
						); ?>"
						data-hide-label="<?php echo esc_attr__(
							'Hide existing',
							'tutorhelper-bookings'
						); ?>"
					>
						<span class="tutorhelper-booking-type-list-toggle__label">
							<?php
							echo esc_html(
								$list_expanded
									? __(
										'Hide existing',
										'tutorhelper-bookings'
									)
									: __(
										'Show existing',
										'tutorhelper-bookings'
									)
							);
							?>
						</span>

						<span
							class="dashicons <?php echo esc_attr(
								$list_expanded
									? 'dashicons-arrow-up-alt2'
									: 'dashicons-arrow-down-alt2'
							); ?>"
							aria-hidden="true"
						></span>
					</button>
				</div>
			</div>

			<div
				id="tutorhelper-booking-type-existing-content"
				class="tutorhelper-booking-type-existing__content"
				<?php echo $list_expanded ? '' : 'hidden'; ?>
			>
				<div
					class="tutorhelper-booking-type-list is-sortable"
					id="tutorhelper-booking-type-list"
					data-sortable="booking-types"
				>
					<?php if ( empty( $active_types ) ) : ?>
						<div class="tutorhelper-booking-type-empty">
							<strong>
								<?php
								echo esc_html__(
									'No active Booking Types',
									'tutorhelper-bookings'
								);
								?>
							</strong>

							<span>
								<?php
								echo esc_html__(
									'Add your first Booking Type using the form below.',
									'tutorhelper-bookings'
								);
								?>
							</span>
						</div>
					<?php else : ?>
						<?php foreach ( $active_types as $booking_type ) : ?>
							<?php
							self::render_hub_list_item(
								$booking_type,
								$selected_type_id
							);
							?>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>

				<p
					id="tutorhelper-booking-type-order-status"
					class="tutorhelper-booking-type-order-status"
					role="status"
					aria-live="polite"
				></p>

				<?php if ( ! empty( $archived_types ) ) : ?>
					<details class="tutorhelper-booking-type-archived">
						<summary>
							<?php
							printf(
								/* translators: %d: Archived Booking Type count. */
								esc_html__(
									'Archived Booking Types (%d)',
									'tutorhelper-bookings'
								),
								count( $archived_types )
							);
							?>
						</summary>

						<div class="tutorhelper-booking-type-list">
							<?php foreach ( $archived_types as $booking_type ) : ?>
								<?php
								self::render_hub_list_item(
									$booking_type,
									$selected_type_id
								);
								?>
							<?php endforeach; ?>
						</div>
					</details>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	/**
	 * Render one Booking Type list item.
	 *
	 * @param object $booking_type    Booking Type record.
	 * @param int    $selected_type_id Selected ID.
	 *
	 * @return void
	 */
	private static function render_hub_list_item(
		$booking_type,
		$selected_type_id = 0
	) {
		$booking_type_id = absint(
			$booking_type->id
		);

		$colour = sanitize_hex_color(
			$booking_type->colour
		);

		if ( empty( $colour ) ) {
			$colour = '#FF6326';
		}

		$is_active = 1 === absint(
			$booking_type->is_active
		);

		$classes = array(
			'tutorhelper-booking-type-item',
		);

		if ( $booking_type_id === absint( $selected_type_id ) ) {
			$classes[] = 'is-selected';
		}

		if ( ! $is_active ) {
			$classes[] = 'is-archived';
		}

		?>
		<article
			class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"
			data-booking-type-id="<?php echo esc_attr(
				$booking_type_id
			); ?>"
		>

			<?php if ( $is_active ) : ?>
				<button
					type="button"
					class="tutorhelper-booking-type-item__drag"
					aria-label="<?php echo esc_attr(
						sprintf(
							/* translators: %s: Booking Type title. */
							__(
								'Drag to reorder %s',
								'tutorhelper-bookings'
							),
							$booking_type->title
						)
					); ?>"
					title="<?php echo esc_attr__(
						'Drag to reorder',
						'tutorhelper-bookings'
					); ?>"
				>
					<span
						class="dashicons dashicons-move"
						aria-hidden="true"
					></span>
				</button>
			<?php endif; ?>


			<span
				class="tutorhelper-booking-type-item__colour"
				style="background-color:<?php echo esc_attr( $colour ); ?>;"
				aria-hidden="true"
			></span>

			<div class="tutorhelper-booking-type-item__main">
				<strong>
					<?php echo esc_html( $booking_type->title ); ?>
				</strong>

				<small>
					<?php
					printf(
						/* translators: %d: Duration in minutes. */
						esc_html__(
							'%d minutes',
							'tutorhelper-bookings'
						),
						absint(
							$booking_type->duration_minutes
						)
					);
					?>

					<span aria-hidden="true"> · </span>

					<?php
					echo esc_html(
						TutorHelper_Currency::format_minor_units(
							absint(
								$booking_type->price_minor_units
							),
							TutorHelper_Currency::get_currency()
						)
					);
					?>

					<span aria-hidden="true"> · </span>

					<?php
					echo esc_html(
						self::get_location_summary(
							$booking_type->location_types
						)
					);
					?>
				</small>
			</div>

			<div class="tutorhelper-booking-type-item__actions">
				<a
					class="button-link tutorhelper-booking-type-item__edit"
					href="<?php echo esc_url(
						self::get_edit_url(
							$booking_type_id
						)
					); ?>"
					aria-label="<?php echo esc_attr(
						sprintf(
							/* translators: %s: Booking Type title. */
							__(
								'Edit %s',
								'tutorhelper-bookings'
							),
							$booking_type->title
						)
					); ?>"
					title="<?php echo esc_attr__(
						'Edit Booking Type',
						'tutorhelper-bookings'
					); ?>"
				>
					<span
						class="dashicons dashicons-edit"
						aria-hidden="true"
					></span>
				</a>

				<?php
				self::render_hub_status_form(
					$booking_type
				);
				?>
			</div>
		</article>
		<?php
	}




	
	/**
	 * Render the create/edit form.
	 *
	 * @param object|null $booking_type Booking Type being edited.
	 *
	 * @return void
	 */
	private static function render_form(
		$booking_type = null,
		$is_hub = false
	) {
		$is_editing = is_object( $booking_type );

		$wrapper_class = $is_hub
		? 'tutorhelper-booking-type-form-wrap'
		: 'postbox';

		$values = array(
			'id' => $is_editing
				? absint( $booking_type->id )
				: 0,
			'title' => $is_editing
				? $booking_type->title
				: '',
			'description' => $is_editing
				? $booking_type->description
				: '',
			'duration_minutes' => $is_editing
				? absint( $booking_type->duration_minutes )
				: 60,
			'buffer_after_minutes' => $is_editing
				&& isset( $booking_type->buffer_after_minutes )
					? absint( $booking_type->buffer_after_minutes )
					: 0,
			'price' => $is_editing
				? TutorHelper_Currency::minor_to_major_units(
					absint(
						$booking_type->price_minor_units
					),
					TutorHelper_Currency::get_currency()
				)
				: TutorHelper_Currency::minor_to_major_units(
					0,
					TutorHelper_Currency::get_currency()
				),
			'location_type' => $is_editing
				? $booking_type->location_type
				: 'online',
			'location_types' => $is_editing
				? array_filter(
					explode(
						',',
						$booking_type->location_types
					)
				)
				: array( 'online' ),
			'location_details' => $is_editing
				? $booking_type->location_details
				: '',
			'colour' => $is_editing
				? $booking_type->colour
				: '#FF6326',
			'online_booking_visibility' => $is_editing
				? $booking_type->online_booking_visibility
				: 'bookable',
			'notice_period_hours' => $is_editing
				? absint( $booking_type->notice_period_hours )
				: 48,
			'cancellations_allowed' => $is_editing
				? absint( $booking_type->cancellations_allowed )
				: 0,
			'cancellation_notice_hours' => $is_editing
				? absint(
					$booking_type->cancellation_notice_hours
				)
				: 24,
			'sort_order' => $is_editing
				? absint( $booking_type->sort_order )
				: 0,
		);

		/**
		 * Filters the visibility value displayed in the
		 * Booking Type admin form.
		 *
		 * Extensions may expose a virtual admin visibility
		 * value while Core retains its supported stored value.
		 *
		 * @param string      $visibility   Core visibility value.
		 * @param object|null $booking_type Booking Type being edited.
		 */
		$values['online_booking_visibility'] =
			apply_filters(
				'tutorhelper_booking_type_admin_visibility',
				$values[
					'online_booking_visibility'
				],
				$booking_type
			);


		$current_currency =
			TutorHelper_Currency::get_currency();

		$currency_details =
			TutorHelper_Currency::get_currency_details(
				$current_currency
			);

		$currency_symbol = isset(
			$currency_details['symbol']
		)
			? $currency_details['symbol']
			: $current_currency;

		$currency_decimals =
			TutorHelper_Currency::get_decimal_places(
				$current_currency
			);

		$price_step = 0 === $currency_decimals
			? '1'
			: '0.' . str_repeat(
				'0',
				max( 0, $currency_decimals - 1 )
			) . '1';

		?>
		<div class="<?php echo esc_attr( $wrapper_class ); ?>">
			<div class="tutorhelper-booking-type-form__header">
				<h2>
					<?php
					echo esc_html(
						$is_editing
							? __(
								'Edit Booking Type',
								'tutorhelper-bookings'
							)
							: __(
								'Add Booking Type',
								'tutorhelper-bookings'
							)
					);
					?>
				</h2>
			</div>

			<div class="tutorhelper-booking-type-form__body">
				<form
					method="post"
					action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					id="tutorhelper-booking-type-form"
					class="tutorhelper-booking-type-form"
				>
					<input
						type="hidden"
						name="action"
						value="<?php echo esc_attr( self::SAVE_ACTION ); ?>"
					/>

					<input
						type="hidden"
						name="booking_type_id"
						value="<?php echo esc_attr( $values['id'] ); ?>"
					/>

					<?php
					wp_nonce_field(
						'tutorhelper_save_booking_type'
					);
					?>

					<?php if ( $is_hub ) : ?>
						<?php self::render_return_fields(); ?>
					<?php endif; ?>

					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-title">
										<?php
										echo esc_html__(
											'Title',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<input
										type="text"
										id="tutorhelper-booking-type-title"
										name="title"
										class="regular-text"
										value="<?php echo esc_attr( $values['title'] ); ?>"
										required
									/>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-description">
										<?php
										echo esc_html__(
											'Description',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<textarea
										id="tutorhelper-booking-type-description"
										name="description"
										rows="4"
										class="large-text"
									><?php echo esc_textarea( $values['description'] ); ?></textarea>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-duration">
										<?php
										echo esc_html__(
											'Duration',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<input
										type="number"
										id="tutorhelper-booking-type-duration"
										name="duration_minutes"
										min="5"
										max="1440"
										step="5"
										value="<?php echo esc_attr( $values['duration_minutes'] ); ?>"
										required
									/>
									<span>
										<?php
										echo esc_html__(
											'minutes',
											'tutorhelper-bookings'
										);
										?>
									</span>
								</td>
							</tr>


							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-buffer">
										<?php esc_html_e( 'Buffer after lesson', 'tutorhelper-bookings' ); ?>
									</label>
								</th>
								<td>
									<select id="tutorhelper-booking-type-buffer" name="buffer_after_minutes">
										<?php foreach ( array( 0, 5, 10, 15, 30, 45, 60 ) as $buffer_minutes ) : ?>
											<option value="<?php echo esc_attr( $buffer_minutes ); ?>" <?php selected( $values['buffer_after_minutes'], $buffer_minutes ); ?>>
												<?php
												echo esc_html(
													0 === $buffer_minutes
														? __( 'No buffer', 'tutorhelper-bookings' )
														: sprintf(
															/* translators: %d: Buffer duration in minutes. */
															_n( '%d minute', '%d minutes', $buffer_minutes, 'tutorhelper-bookings' ),
															$buffer_minutes
														)
												);
												?>
											</option>
										<?php endforeach; ?>
									</select>
									<p class="description">
										<?php esc_html_e( 'Blocks this time after the lesson without changing the time shown to students.', 'tutorhelper-bookings' ); ?>
									</p>
								</td>
							</tr>


							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-price">
										<?php
										echo esc_html__(
											'Standard price',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>

								<td>
									<div class="tutorhelper-price-input">
										<span
											class="tutorhelper-price-input__symbol"
											aria-hidden="true"
										>
											<?php
											echo esc_html(
												$currency_symbol
											);
											?>
										</span>

										<input
											type="number"
											id="tutorhelper-booking-type-price"
											name="price"
											min="0"
											step="<?php echo esc_attr(
												$price_step
											); ?>"
											value="<?php echo esc_attr(
												$values['price']
											); ?>"
											inputmode="decimal"
											required
										/>

										<span class="tutorhelper-price-input__code">
											<?php
											echo esc_html(
												$current_currency
											);
											?>
										</span>
									</div>

									<p class="description">
										<?php
										printf(
											/* translators: %d is the standard Booking Type duration. */
											esc_html__(
												'The price charged for the standard %d-minute duration. Tutor-created bookings with a different duration will be recalculated proportionally.',
												'tutorhelper-bookings'
											),
											absint(
												$values['duration_minutes']
											)
										);
										?>
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<?php
									echo esc_html__(
										'Available locations',
										'tutorhelper-bookings'
									);
									?>
								</th>
								<td>
									<?php
									self::render_location_checkboxes(
										$values['location_types']
									);
									?>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-primary-location">
										<?php
										echo esc_html__(
											'Primary location',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<select
										id="tutorhelper-booking-type-primary-location"
										name="location_type"
									>
										<?php
										self::render_location_options(
											$values['location_type']
										);
										?>
									</select>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-location-details">
										<?php
										echo esc_html__(
											'Location details',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<textarea
										id="tutorhelper-booking-type-location-details"
										name="location_details"
										rows="3"
										class="large-text"
									><?php echo esc_textarea( $values['location_details'] ); ?></textarea>

									<p class="description">
										<?php
										echo esc_html__(
											'For example, a meeting link, telephone instructions or teaching address.',
											'tutorhelper-bookings'
										);
										?>
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-colour">
										<?php
										echo esc_html__(
											'Calendar colour',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<input
										type="color"
										id="tutorhelper-booking-type-colour"
										name="colour"
										value="<?php echo esc_attr( $values['colour'] ); ?>"
									/>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-visibility">
										<?php
										echo esc_html__(
											'Online visibility',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<select
										id="tutorhelper-booking-type-visibility"
										name="online_booking_visibility"
									>
										<?php
										self::render_visibility_options(
											$values['online_booking_visibility']
										);
										?>
									</select>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-notice">
										<?php
										echo esc_html__(
											'Minimum booking notice',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<input
										type="number"
										id="tutorhelper-booking-type-notice"
										name="notice_period_hours"
										min="0"
										step="1"
										value="<?php echo esc_attr( $values['notice_period_hours'] ); ?>"
									/>
									<span>
										<?php
										echo esc_html__(
											'hours',
											'tutorhelper-bookings'
										);
										?>
									</span>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<?php
									echo esc_html__(
										'Cancellations',
										'tutorhelper-bookings'
									);
									?>
								</th>
								<td>
									<label>
										<input
											type="checkbox"
											name="cancellations_allowed"
											value="1"
											<?php
											checked(
												1,
												$values['cancellations_allowed']
											);
											?>
										/>

										<?php
										echo esc_html__(
											'Allow students to cancel this Booking Type',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="tutorhelper-booking-type-cancellation-notice">
										<?php
										echo esc_html__(
											'Cancellation notice',
											'tutorhelper-bookings'
										);
										?>
									</label>
								</th>
								<td>
									<input
										type="number"
										id="tutorhelper-booking-type-cancellation-notice"
										name="cancellation_notice_hours"
										min="0"
										step="1"
										value="<?php echo esc_attr( $values['cancellation_notice_hours'] ); ?>"
									/>
									<span>
										<?php
										echo esc_html__(
											'hours',
											'tutorhelper-bookings'
										);
										?>
									</span>
								</td>
							</tr>

							<?php
							/**
							 * Render additional Booking Type admin fields.
							 *
							 * Extensions may output additional table rows within
							 * the existing Booking Type form.
							 *
							 * @param object|null $booking_type Booking Type being edited.
							 * @param array       $values       Core Booking Type form values.
							 */
							do_action(
								'tutorhelper_booking_type_render_admin_fields',
								$booking_type,
								$values
							);
							?>

						</tbody>
					</table>

					<?php
					submit_button(
						$is_editing
							? __(
								'Update Booking Type',
								'tutorhelper-bookings'
							)
							: __(
								'Add Booking Type',
								'tutorhelper-bookings'
							)
					);
					?>

					<?php if ( $is_editing ) : ?>
						<a
							class="button"
							href="<?php echo esc_url(
								$is_hub
									? self::get_cancel_url()
									: self::get_page_url()
							); ?>"
						>
							<?php
							echo esc_html__(
								'Cancel edit',
								'tutorhelper-bookings'
							);
							?>
						</a>
					<?php endif; ?>
				</form>
			</div>
		</div>
		<?php
	}



	/**
	 * Render one Booking Type row.
	 *
	 * @param object $booking_type Booking Type record.
	 *
	 * @return void
	 */
	private static function render_list_row( $booking_type ) {
		$is_active = 1 === absint( $booking_type->is_active );

		$edit_url = add_query_arg(
			array(
				'page' => self::PAGE_SLUG,
				'edit' => absint( $booking_type->id ),
			),
			admin_url( 'admin.php' )
		);

		?>
		<tr>
			<td>
				<span
					aria-hidden="true"
					style="
						display:inline-block;
						width:14px;
						height:14px;
						border-radius:50%;
						vertical-align:-2px;
						margin-right:6px;
						background:<?php echo esc_attr( $booking_type->colour ); ?>;
					"
				></span>

				<strong>
					<?php echo esc_html( $booking_type->title ); ?>
				</strong>
			</td>

			<td>
				<?php
				printf(
					/* translators: %d: Booking duration in minutes. */
					esc_html__(
						'%d minutes',
						'tutorhelper-bookings'
					),
					absint( $booking_type->duration_minutes )
				);
				?>
			</td>

			<td>
				<?php
				echo esc_html(
					self::format_location_types(
						$booking_type->location_types
					)
				);
				?>
			</td>

			<td>
				<?php
				echo esc_html(
					self::get_visibility_label(
						$booking_type->online_booking_visibility
					)
				);
				?>
			</td>

			<td>
				<?php
				echo esc_html(
					$is_active
						? __(
							'Active',
							'tutorhelper-bookings'
						)
						: __(
							'Archived',
							'tutorhelper-bookings'
						)
				);
				?>
			</td>

			<td>
				<a
					class="button button-small"
					href="<?php echo esc_url( $edit_url ); ?>"
				>
					<?php
					echo esc_html__(
						'Edit',
						'tutorhelper-bookings'
					);
					?>
				</a>

				<?php
				self::render_status_form(
					$booking_type
				);
				?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Render the archive or restore form.
	 *
	 * @param object $booking_type Booking Type record.
	 *
	 * @return void
	 */
	private static function render_status_form( $booking_type ) {
		$is_active = 1 === absint( $booking_type->is_active );

		?>
		<form
			method="post"
			action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
			style="display:inline-block;margin-left:4px;"
		>
			<input
				type="hidden"
				name="action"
				value="<?php echo esc_attr( self::STATUS_ACTION ); ?>"
			/>

			<input
				type="hidden"
				name="booking_type_id"
				value="<?php echo esc_attr( $booking_type->id ); ?>"
			/>

			<input
				type="hidden"
				name="status_action"
				value="<?php echo esc_attr( $is_active ? 'archive' : 'restore' ); ?>"
			/>

			<?php
			wp_nonce_field(
				'tutorhelper_change_booking_type_status'
			);
			?>

			<button
				type="submit"
				class="button button-small"
			>
				<?php
				echo esc_html(
					$is_active
						? __(
							'Archive',
							'tutorhelper-bookings'
						)
						: __(
							'Restore',
							'tutorhelper-bookings'
						)
				);
				?>
			</button>
		</form>
		<?php
	}

	/**
	 * Render location checkboxes.
	 *
	 * @param array $selected_types Selected location types.
	 *
	 * @return void
	 */
	private static function render_location_checkboxes(
		$selected_types
	) {
		foreach ( self::get_location_labels() as $key => $label ) {
			?>
			<label style="display:block;margin-bottom:5px;">
				<input
					type="checkbox"
					name="location_types[]"
					value="<?php echo esc_attr( $key ); ?>"
					<?php
					checked(
						in_array(
							$key,
							$selected_types,
							true
						)
					);
					?>
				/>

				<?php echo esc_html( $label ); ?>
			</label>
			<?php
		}
	}

	/**
	 * Render primary-location options.
	 *
	 * @param string $selected_type Selected location.
	 *
	 * @return void
	 */
	private static function render_location_options(
		$selected_type
	) {
		foreach ( self::get_location_labels() as $key => $label ) {
			?>
			<option
				value="<?php echo esc_attr( $key ); ?>"
				<?php selected( $selected_type, $key ); ?>
			>
				<?php echo esc_html( $label ); ?>
			</option>
			<?php
		}
	}

	/**
	 * Render visibility options.
	 *
	 * @param string $selected_visibility Selected visibility.
	 *
	 * @return void
	 */
	private static function render_visibility_options(
		$selected_visibility
	) {

		foreach (
			self::get_visibility_labels()
			as $key => $label
		) {
			?>
			<option
				value="<?php echo esc_attr( $key ); ?>"
				<?php selected( $selected_visibility, $key ); ?>
			>
				<?php echo esc_html( $label ); ?>
			</option>
			<?php
		}
	}

	/**
	 * Return location labels.
	 *
	 * @return array
	 */
	private static function get_location_labels() {
		return array(
			'online'    => __(
				'Online',
				'tutorhelper-bookings'
			),
			'phone'     => __(
				'Telephone',
				'tutorhelper-bookings'
			),
			'in_person' => __(
				'In person',
				'tutorhelper-bookings'
			),
			'custom'    => __(
				'Custom',
				'tutorhelper-bookings'
			),
		);
	}

	/**
	 * Return visibility labels.
	 *
	 * Extensions may add additional admin visibility
	 * choices without changing Core Booking Type storage.
	 *
	 * @return array
	 */
	private static function get_visibility_labels() {

		$labels = array(
			'bookable' => __(
				'Visible and bookable',
				'tutorhelper-bookings'
			),

			'private_url' => __(
				'Bookable by private link',
				'tutorhelper-bookings'
			),

			'visible_not_bookable' => __(
				'Visible but not bookable',
				'tutorhelper-bookings'
			),

			'hidden' => __(
				'Hidden',
				'tutorhelper-bookings'
			),
		);

		/**
		 * Filters the Booking Type visibility choices
		 * displayed in the admin interface.
		 *
		 * Extensions may add virtual visibility choices.
		 * Core still validates and stores only its own
		 * supported visibility values.
		 *
		 * @param array $labels Visibility key => label.
		 */
		return apply_filters(
			'tutorhelper_booking_type_visibility_options',
			$labels
		);
	}

	/**
	 * Return a visibility label.
	 *
	 * @param string $visibility Visibility key.
	 *
	 * @return string
	 */
	private static function get_visibility_label( $visibility ) {
		$labels = self::get_visibility_labels();

		return isset( $labels[ $visibility ] )
			? $labels[ $visibility ]
			: $visibility;
	}

	/**
	 * Format stored location keys for display.
	 *
	 * @param string $location_types Comma-separated location keys.
	 *
	 * @return string
	 */
	private static function format_location_types(
		$location_types
	) {
		$labels = self::get_location_labels();
		$types  = array_filter(
			explode( ',', (string) $location_types )
		);

		$output = array();

		foreach ( $types as $type ) {
			$output[] = isset( $labels[ $type ] )
				? $labels[ $type ]
				: $type;
		}

		return implode( ', ', $output );
	}

	/**
	 * Verify that the current user may manage Booking Types.
	 *
	 * @return void
	 */
	private static function verify_admin_request() {
		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			wp_die(
				esc_html__(
					'You do not have permission to manage Booking Types.',
					'tutorhelper-bookings'
				),
				esc_html__(
					'Permission denied',
					'tutorhelper-bookings'
				),
				array(
					'response' => 403,
				)
			);
		}

		
	}

	/**
	 * Redirect after a Booking Type action.
	 *
	 * @param string $notice          Notice key.
	 * @param string $error_code      Optional error code.
	 * @param int    $booking_type_id Optional Booking Type ID.
	 *
	 * @return void
	 */
	private static function redirect(
		$notice,
		$error_code = '',
		$booking_type_id = 0
	) {
		$return_to = isset( $_POST['return_to'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Request value is read only after the calling admin/AJAX action has completed capability and nonce verification; value is sanitized before use.
			? sanitize_key(
				wp_unslash( $_POST['return_to'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Request value is read only after the calling admin/AJAX action has completed capability and nonce verification; value is sanitized before use.
			)
			: '';

		if ( 'hub' === $return_to ) {
			$view = isset( $_POST['return_view'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Request value is read only after the calling admin/AJAX action has completed capability and nonce verification; value is sanitized before use.
				? sanitize_key(
					wp_unslash(
						$_POST['return_view'] // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Request value is read only after the calling admin/AJAX action has completed capability and nonce verification; value is sanitized before use.
					)
				)
				: 'week';

			if (
				! in_array(
					$view,
					array( 'week', 'month' ),
					true
				)
			) {
				$view = 'week';
			}

			$date = isset( $_POST['return_date'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Request value is read only after the calling admin/AJAX action has completed capability and nonce verification; value is sanitized before use.
				? sanitize_text_field(
					wp_unslash(
						$_POST['return_date'] // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Request value is read only after the calling admin/AJAX action has completed capability and nonce verification; value is sanitized before use.
					)
				)
				: wp_date( 'Y-m-d' );

			$args = array(
				'page'                    =>
					TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab'                     => 'calendar',
				'view'                    => $view,
				'date'                    => $date,
				'tutorhelper_type_notice' =>
					sanitize_key( $notice ),
			);

			if ( ! empty( $error_code ) ) {
				$args['tutorhelper_type_error'] =
					sanitize_key( $error_code );
			}

			if (
				'error' === $notice
				&& $booking_type_id
			) {
				$args['booking_type_id'] =
					absint( $booking_type_id );
			}

			wp_safe_redirect(
				add_query_arg(
					$args,
					admin_url( 'admin.php' )
				)
			);

			exit;
		}

		/*
		* Existing standalone-page redirect.
		*/
		$args = array(
			'page'                    => self::PAGE_SLUG,
			'tutorhelper_type_notice' =>
				sanitize_key( $notice ),
		);

		if ( ! empty( $error_code ) ) {
			$args['tutorhelper_type_error'] =
				sanitize_key( $error_code );
		}

		if ( $booking_type_id ) {
			$args['edit'] = absint(
				$booking_type_id
			);
		}

		wp_safe_redirect(
			add_query_arg(
				$args,
				admin_url( 'admin.php' )
			)
		);

		exit;
	}

	/**
	 * Return the Booking Types page URL.
	 *
	 * @return string
	 */
	private static function get_page_url() {
		return add_query_arg(
			array(
				'page' => self::PAGE_SLUG,
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Render a saved-action notice.
	 *
	 * @return void
	 */
	private static function render_notice() {
		if ( ! isset( $_GET['tutorhelper_type_notice']) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
			return;
		}

		$notice = sanitize_key(
			wp_unslash( $_GET['tutorhelper_type_notice'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
		);

		$notices = array(
			'created' => array(
				'class'   => 'notice notice-success inline',
				'message' => __(
					'The Booking Type was created.',
					'tutorhelper-bookings'
				),
			),
			'updated' => array(
				'class'   => 'notice notice-success inline',
				'message' => __(
					'The Booking Type was updated.',
					'tutorhelper-bookings'
				),
			),
			'archived' => array(
				'class'   => 'notice notice-success inline',
				'message' => __(
					'The Booking Type was archived.',
					'tutorhelper-bookings'
				),
			),
			'restored' => array(
				'class'   => 'notice notice-success inline',
				'message' => __(
					'The Booking Type was restored.',
					'tutorhelper-bookings'
				),
			),
			'error' => array(
				'class'   => 'notice notice-error inline',
				'message' => self::get_error_message(),
			),
		);

		if ( ! isset( $notices[ $notice ] ) ) {
			return;
		}

		echo '<div class="';
		echo esc_attr( $notices[ $notice ]['class'] );
		echo '"><p>';
		echo esc_html( $notices[ $notice ]['message'] );
		echo '</p></div>';
	}

	/**
	 * Return a safe user-facing error message.
	 *
	 * @return string
	 */
	private static function get_error_message() {
		$error_code = isset( $_GET['tutorhelper_error'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
			? sanitize_key(
				wp_unslash( $_GET['tutorhelper_error'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
			)
			: '';

		$messages = array(
			'tutorhelper_booking_type_missing_title' => __(
				'Please enter a title for the Booking Type.',
				'tutorhelper-bookings'
			),
			'tutorhelper_booking_type_invalid_duration' => __(
				'The duration must be at least five minutes.',
				'tutorhelper-bookings'
			),
			'tutorhelper_booking_type_duration_too_long' => __(
				'The duration cannot be longer than 24 hours.',
				'tutorhelper-bookings'
			),
			'tutorhelper_booking_type_invalid_id' => __(
				'The Booking Type ID is invalid.',
				'tutorhelper-bookings'
			),
			'tutorhelper_booking_type_not_found' => __(
				'The Booking Type could not be found.',
				'tutorhelper-bookings'
			),
			'tutorhelper_booking_type_invalid_status_action' => __(
				'The requested Booking Type action is invalid.',
				'tutorhelper-bookings'
			),
		);

		return isset( $messages[ $error_code ] )
			? $messages[ $error_code ]
			: __(
				'The Booking Type could not be saved. Check TutorHelper Diagnostics for more information.',
				'tutorhelper-bookings'
			);
	}
}
