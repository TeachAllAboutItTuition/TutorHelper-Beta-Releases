<?php
/**
 * Booking Types diagnostics integration.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds Booking Type information to TutorHelper Diagnostics.
 *
 * Detailed diagnostic checks will be added later in Milestone 10.
 */
final class TutorHelper_Booking_Types_Diagnostics {

	/**
	 * Register diagnostic hooks.
	 *
	 * @return void
	 */
	public static function init() {
		/*
		 * Booking Type diagnostic hooks will be registered here later.
		 *
		 * The empty method allows the Booking Types module to initialise
		 * safely while the Hub interface is being completed.
		 */
	}
}
