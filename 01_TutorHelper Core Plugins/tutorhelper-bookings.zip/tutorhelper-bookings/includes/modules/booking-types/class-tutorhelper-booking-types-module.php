<?php
/**
 * TutorHelper Booking Types module.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the Booking Types module.
 */
final class TutorHelper_Booking_Types_Module {

	/**
	 * Initialise the module.
	 *
	 * @return void
	 */
	public static function init() {
		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/booking-types/'
			. 'class-tutorhelper-booking-types.php';

		if ( is_admin() ) {
			require_once TUTORHELPER_BOOKINGS_PATH
				. 'includes/modules/booking-types/'
				. 'class-tutorhelper-booking-types-admin.php';

			require_once TUTORHELPER_BOOKINGS_PATH
				. 'includes/modules/booking-types/'
				. 'class-tutorhelper-booking-types-diagnostics.php';

			require_once TUTORHELPER_BOOKINGS_PATH
				. 'includes/modules/booking-types/'
				. 'class-tutorhelper-booking-types-list-ui.php';

			if (
				class_exists(
					'TutorHelper_Booking_Types_Admin'
				)
			) {
				TutorHelper_Booking_Types_Admin::init();
			}

			if (
				class_exists(
					'TutorHelper_Booking_Types_Diagnostics'
				)
			) {
				TutorHelper_Booking_Types_Diagnostics::init();
			}

			if (
				class_exists(
					'TutorHelper_Booking_Types_List_UI'
				)
			) {
				TutorHelper_Booking_Types_List_UI::init();
			}
		}
	}
}
