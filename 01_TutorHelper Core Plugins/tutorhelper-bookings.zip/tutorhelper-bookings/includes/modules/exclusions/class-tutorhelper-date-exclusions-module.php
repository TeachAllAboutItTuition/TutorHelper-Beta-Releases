<?php
/**
 * TutorHelper date-exclusions module.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the shared date-exclusions service.
 */
final class TutorHelper_Date_Exclusions_Module {

	/**
	 * Initialise the module.
	 *
	 * @return void
	 */
	public static function init() {
		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/exclusions/'
			. 'class-tutorhelper-date-exclusions.php';
	}
}
