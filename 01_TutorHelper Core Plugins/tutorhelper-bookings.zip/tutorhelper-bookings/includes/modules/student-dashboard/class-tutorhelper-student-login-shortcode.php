<?php
/**
 * Front-end student login shortcode.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders and processes the TutorHelper student login form.
 */
final class TutorHelper_Student_Login_Shortcode {

	/**
	 * Shortcode name.
	 *
	 * @var string
	 */
	const SHORTCODE = 'tutorhelper_student_login';

	/**
	 * Form action name.
	 *
	 * @var string
	 */
	const ACTION = 'tutorhelper_student_login';

	/**
	 * Password reset form action name.
	 *
	 * @var string
	 */
	const RESET_ACTION =
		'tutorhelper_student_password_reset';

	/**
	 * Register shortcode and request hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode(
			self::SHORTCODE,
			array( __CLASS__, 'render' )
		);

		add_action(
			'template_redirect',
			array( __CLASS__, 'handle_submission' )
		);
	}

	/**
	 * Process a submitted login before the theme sends output.
	 *
	 * @return void
	 */
	public static function handle_submission() {
		if (
			'POST' !== strtoupper(
				isset( $_SERVER['REQUEST_METHOD'] )
					? sanitize_text_field(
						wp_unslash( $_SERVER['REQUEST_METHOD'] )
					)
					: ''
			)
			|| ! isset( $_POST['tutorhelper_login_action'] )
			|| is_array( $_POST['tutorhelper_login_action'] )
		) {
			return;
		}

		$action =
			sanitize_key(
				wp_unslash(
					$_POST['tutorhelper_login_action']
				)
			);

		if ( self::RESET_ACTION === $action ) {
			self::handle_password_reset();
			return;
		}

		if ( self::ACTION !== $action ) {
			return;
		}

		$return_url = self::get_return_url();

		if ( is_user_logged_in() ) {
			self::redirect_to_dashboard();
		}

		$nonce = isset( $_POST['tutorhelper_login_nonce'] ) && ! is_array( $_POST['tutorhelper_login_nonce'] )
			? sanitize_text_field( wp_unslash( $_POST['tutorhelper_login_nonce'] ) )
			: '';

		if ( ! wp_verify_nonce( $nonce, self::ACTION ) ) {
			self::redirect_with_error( $return_url, 'expired' );
		}

		$honeypot = isset( $_POST['tutorhelper_login_website'] ) && ! is_array( $_POST['tutorhelper_login_website'] )
			? sanitize_text_field( wp_unslash( $_POST['tutorhelper_login_website'] ) )
			: '';

		if ( '' !== $honeypot ) {
			self::redirect_with_error( $return_url, 'invalid' );
		}

		$user_login = isset( $_POST['tutorhelper_login_username'] ) && ! is_array( $_POST['tutorhelper_login_username'] )
			? sanitize_text_field( wp_unslash( $_POST['tutorhelper_login_username'] ) )
			: '';
		$password = isset( $_POST['tutorhelper_login_password'] ) && ! is_array( $_POST['tutorhelper_login_password'] )
			? (string) wp_unslash( $_POST['tutorhelper_login_password'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Authentication requires the exact password supplied by the user.
			: '';
		$remember = isset( $_POST['tutorhelper_login_remember'] ) && ! is_array( $_POST['tutorhelper_login_remember'] )
			? '1' === sanitize_key( wp_unslash( $_POST['tutorhelper_login_remember'] ) )
			: false;

		if ( '' === $user_login || '' === $password ) {
			self::redirect_with_error( $return_url, 'missing' );
		}

		$user = wp_signon(
			array(
				'user_login'    => $user_login,
				'user_password' => $password,
				'remember'      => $remember,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			self::redirect_with_error( $return_url, 'invalid' );
		}

		self::redirect_to_dashboard();
	}

	/**
	 * Render the login form.
	 *
	 * @return string
	 */
	public static function render() {
		TutorHelper_Student_Dashboard_Frontend::enqueue_assets();

		$reset_key =
			isset( $_GET['key'] ) && ! is_array( $_GET['key'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WordPress password reset key is validated by check_password_reset_key().
				? sanitize_text_field( wp_unslash( $_GET['key'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WordPress password reset key is validated by check_password_reset_key().
				: '';

		$reset_login =
			isset( $_GET['login'] ) && ! is_array( $_GET['login'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only account identifier paired with the validated reset key.
				? sanitize_user( wp_unslash( $_GET['login'] ), true ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only account identifier paired with the validated reset key.
				: '';

		$reset_action =
			isset( $_GET['action'] ) && ! is_array( $_GET['action'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route selection; no state is changed.
				? sanitize_key( wp_unslash( $_GET['action'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route selection; no state is changed.
				: '';

		if (
			'rp' === $reset_action
			&& '' !== $reset_key
			&& '' !== $reset_login
		) {
			return self::render_password_reset(
				$reset_key,
				$reset_login
			);
		}

		$dashboard_url = TutorHelper_Settings::get_student_dashboard_url();

		if ( is_user_logged_in() ) {
			ob_start();
			?>
			<section class="tutorhelper-student-login tutorhelper-student-login--active">
				<p class="tutorhelper-student-login__eyebrow"><?php esc_html_e( 'Student account', 'tutorhelper-bookings' ); ?></p>
				<h2><?php esc_html_e( 'You are already logged in', 'tutorhelper-bookings' ); ?></h2>
				<p><?php esc_html_e( 'Continue to your student dashboard to view and manage your lessons.', 'tutorhelper-bookings' ); ?></p>
				<a class="tutorhelper-student-login__button" href="<?php echo esc_url( $dashboard_url ? $dashboard_url : home_url( '/' ) ); ?>">
					<?php esc_html_e( 'Open student dashboard', 'tutorhelper-bookings' ); ?>
				</a>
			</section>
			<?php
			return ob_get_clean();
		}

		$error = isset( $_GET['tutorhelper_login'] ) && ! is_array( $_GET['tutorhelper_login'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status following a protected login request.
			? sanitize_key( wp_unslash( $_GET['tutorhelper_login'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status following a protected login request.
			: '';

		$password_status =
			isset( $_GET['tutorhelper_password'] ) && ! is_array( $_GET['tutorhelper_password'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status following a protected reset request.
				? sanitize_key( wp_unslash( $_GET['tutorhelper_password'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status following a protected reset request.
				: '';

		$messages = array(
			'expired' => __( 'This login form has expired. Please reload the page and try again.', 'tutorhelper-bookings' ),
			'missing' => __( 'Enter your email address or username and password.', 'tutorhelper-bookings' ),
			'invalid' => __( 'The email address, username or password was not recognised.', 'tutorhelper-bookings' ),
		);

		ob_start();
		?>
		<section class="tutorhelper-student-login">
			<header class="tutorhelper-student-login__header">
				<p class="tutorhelper-student-login__eyebrow"><?php esc_html_e( 'Student account', 'tutorhelper-bookings' ); ?></p>
				<h2><?php esc_html_e( 'Log in', 'tutorhelper-bookings' ); ?></h2>
				<p><?php esc_html_e( 'Use your student account details to access your lessons and bookings.', 'tutorhelper-bookings' ); ?></p>
			</header>

			<?php if ( 'changed' === $password_status ) : ?>
				<div class="tutorhelper-student-login__notice" role="status">
					<?php esc_html_e( 'Your password has been set. You can now log in.', 'tutorhelper-bookings' ); ?>
				</div>
			<?php elseif ( isset( $messages[ $error ] ) ) : ?>
				<div class="tutorhelper-student-login__notice" role="alert">
					<?php echo esc_html( $messages[ $error ] ); ?>
				</div>
			<?php endif; ?>

			<form class="tutorhelper-student-login__form" method="post" action="<?php echo esc_url( self::get_current_page_url() ); ?>">
				<?php wp_nonce_field( self::ACTION, 'tutorhelper_login_nonce' ); ?>
				<input type="hidden" name="tutorhelper_login_action" value="<?php echo esc_attr( self::ACTION ); ?>" />
				<input type="hidden" name="tutorhelper_login_return" value="<?php echo esc_url( self::get_current_page_url() ); ?>" />

				<div class="tutorhelper-student-login__website" aria-hidden="true">
					<label for="tutorhelper-login-website"><?php esc_html_e( 'Website', 'tutorhelper-bookings' ); ?></label>
					<input id="tutorhelper-login-website" type="text" name="tutorhelper_login_website" value="" tabindex="-1" autocomplete="off" />
				</div>

				<label for="tutorhelper-login-username"><?php esc_html_e( 'Email address or username', 'tutorhelper-bookings' ); ?></label>
				<input id="tutorhelper-login-username" type="text" name="tutorhelper_login_username" autocomplete="username" required />

				<label for="tutorhelper-login-password"><?php esc_html_e( 'Password', 'tutorhelper-bookings' ); ?></label>
				<div class="tutorhelper-password-control">
					<input id="tutorhelper-login-password" type="password" name="tutorhelper_login_password" autocomplete="current-password" required />
					<button type="button" class="tutorhelper-password-toggle" aria-controls="tutorhelper-login-password" aria-pressed="false" data-show-label="<?php esc_attr_e( 'Show password', 'tutorhelper-bookings' ); ?>" data-hide-label="<?php esc_attr_e( 'Hide password', 'tutorhelper-bookings' ); ?>"><?php esc_html_e( 'Show password', 'tutorhelper-bookings' ); ?></button>
				</div>

				<label class="tutorhelper-student-login__remember">
					<input type="checkbox" name="tutorhelper_login_remember" value="1" />
					<span><?php esc_html_e( 'Keep me logged in', 'tutorhelper-bookings' ); ?></span>
				</label>

				<button class="tutorhelper-student-login__button" type="submit">
					<?php esc_html_e( 'Log in', 'tutorhelper-bookings' ); ?>
				</button>

				<a class="tutorhelper-student-login__forgotten" href="<?php echo esc_url( wp_lostpassword_url( self::get_current_page_url() ) ); ?>">
					<?php esc_html_e( 'Forgotten your password?', 'tutorhelper-bookings' ); ?>
				</a>
			</form>
		</section>
		<?php

		return ob_get_clean();
	}

	/**
	 * Process a password setup or reset submission.
	 *
	 * @return void
	 */
	private static function handle_password_reset() {
		$login_url =
			TutorHelper_Settings::get_login_url();

		$nonce =
			isset( $_POST['tutorhelper_reset_nonce'] )
			&& ! is_array( $_POST['tutorhelper_reset_nonce'] )
				? sanitize_text_field(
					wp_unslash(
						$_POST['tutorhelper_reset_nonce']
					)
				)
				: '';

		if ( ! wp_verify_nonce( $nonce, self::RESET_ACTION ) ) {
			self::redirect_reset_error(
				$login_url,
				'',
				'',
				'expired'
			);
		}

		$reset_key =
			isset( $_POST['tutorhelper_reset_key'] )
			&& ! is_array( $_POST['tutorhelper_reset_key'] )
				? sanitize_text_field(
					wp_unslash(
						$_POST['tutorhelper_reset_key']
					)
				)
				: '';

		$user_login =
			isset( $_POST['tutorhelper_reset_login'] )
			&& ! is_array( $_POST['tutorhelper_reset_login'] )
				? sanitize_user(
					wp_unslash(
						$_POST['tutorhelper_reset_login']
					),
					true
				)
				: '';

		$password =
			isset( $_POST['tutorhelper_reset_password'] )
			&& ! is_array( $_POST['tutorhelper_reset_password'] )
				? (string) wp_unslash( $_POST['tutorhelper_reset_password'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Password reset requires the exact password supplied by the user.
				: '';

		$confirmation =
			isset( $_POST['tutorhelper_reset_confirmation'] )
			&& ! is_array( $_POST['tutorhelper_reset_confirmation'] )
				? (string) wp_unslash( $_POST['tutorhelper_reset_confirmation'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Password comparison requires the exact password supplied by the user.
				: '';

		if (
			'' === $password
			|| $password !== $confirmation
		) {
			self::redirect_reset_error(
				$login_url,
				$reset_key,
				$user_login,
				'mismatch'
			);
		}

		$user =
			check_password_reset_key(
				$reset_key,
				$user_login
			);

		if ( is_wp_error( $user ) ) {
			self::redirect_reset_error(
				$login_url,
				$reset_key,
				$user_login,
				'invalid'
			);
		}

		reset_password(
			$user,
			$password
		);

		wp_safe_redirect(
			add_query_arg(
				'tutorhelper_password',
				'changed',
				$login_url
			)
		);
		exit;
	}

	/**
	 * Render the front-end password setup form.
	 *
	 * @param string $reset_key WordPress password reset key.
	 * @param string $user_login WordPress user login.
	 *
	 * @return string
	 */
	private static function render_password_reset(
		$reset_key,
		$user_login
	) {
		$user =
			check_password_reset_key(
				$reset_key,
				$user_login
			);

		$error =
			isset( $_GET['tutorhelper_reset'] )
			&& ! is_array( $_GET['tutorhelper_reset'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status following a protected reset request.
				? sanitize_key( wp_unslash( $_GET['tutorhelper_reset'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status following a protected reset request.
				: '';

		$messages = array(
			'expired'  => __( 'This password form has expired. Please open the link from your email again.', 'tutorhelper-bookings' ),
			'mismatch' => __( 'Enter the same new password in both fields.', 'tutorhelper-bookings' ),
			'invalid'  => __( 'This password link is invalid or has expired. Request a new password reset email.', 'tutorhelper-bookings' ),
		);

		ob_start();
		?>
		<section class="tutorhelper-student-login">
			<header class="tutorhelper-student-login__header">
				<p class="tutorhelper-student-login__eyebrow"><?php esc_html_e( 'Student account', 'tutorhelper-bookings' ); ?></p>
				<h2><?php esc_html_e( 'Set your password', 'tutorhelper-bookings' ); ?></h2>
				<p><?php esc_html_e( 'Choose a password for your TutorHelper account.', 'tutorhelper-bookings' ); ?></p>
			</header>

			<?php if ( is_wp_error( $user ) || isset( $messages[ $error ] ) ) : ?>
				<div class="tutorhelper-student-login__notice" role="alert">
					<?php
					echo esc_html(
						isset( $messages[ $error ] )
							? $messages[ $error ]
							: $messages['invalid']
					);
					?>
				</div>
			<?php endif; ?>

			<?php if ( ! is_wp_error( $user ) ) : ?>
				<form class="tutorhelper-student-login__form" method="post" action="<?php echo esc_url( TutorHelper_Settings::get_login_url() ); ?>">
					<?php wp_nonce_field( self::RESET_ACTION, 'tutorhelper_reset_nonce' ); ?>
					<input type="hidden" name="tutorhelper_login_action" value="<?php echo esc_attr( self::RESET_ACTION ); ?>" />
					<input type="hidden" name="tutorhelper_reset_key" value="<?php echo esc_attr( $reset_key ); ?>" />
					<input type="hidden" name="tutorhelper_reset_login" value="<?php echo esc_attr( $user_login ); ?>" autocomplete="username" />

					<label for="tutorhelper-reset-password"><?php esc_html_e( 'New password', 'tutorhelper-bookings' ); ?></label>
					<div class="tutorhelper-password-control">
						<input id="tutorhelper-reset-password" type="password" name="tutorhelper_reset_password" autocomplete="new-password" required />
						<button type="button" class="tutorhelper-password-toggle" aria-controls="tutorhelper-reset-password" aria-pressed="false" data-show-label="<?php esc_attr_e( 'Show password', 'tutorhelper-bookings' ); ?>" data-hide-label="<?php esc_attr_e( 'Hide password', 'tutorhelper-bookings' ); ?>"><?php esc_html_e( 'Show password', 'tutorhelper-bookings' ); ?></button>
					</div>

					<label for="tutorhelper-reset-confirmation"><?php esc_html_e( 'Confirm new password', 'tutorhelper-bookings' ); ?></label>
					<div class="tutorhelper-password-control">
						<input id="tutorhelper-reset-confirmation" type="password" name="tutorhelper_reset_confirmation" autocomplete="new-password" required />
						<button type="button" class="tutorhelper-password-toggle" aria-controls="tutorhelper-reset-confirmation" aria-pressed="false" data-show-label="<?php esc_attr_e( 'Show password', 'tutorhelper-bookings' ); ?>" data-hide-label="<?php esc_attr_e( 'Hide password', 'tutorhelper-bookings' ); ?>"><?php esc_html_e( 'Show password', 'tutorhelper-bookings' ); ?></button>
					</div>

					<button class="tutorhelper-student-login__button" type="submit">
						<?php esc_html_e( 'Save password', 'tutorhelper-bookings' ); ?>
					</button>
				</form>
			<?php else : ?>
				<p>
					<a class="tutorhelper-student-login__forgotten" href="<?php echo esc_url( wp_lostpassword_url( TutorHelper_Settings::get_login_url() ) ); ?>">
						<?php esc_html_e( 'Request a new password link', 'tutorhelper-bookings' ); ?>
					</a>
				</p>
			<?php endif; ?>
		</section>
		<?php

		return ob_get_clean();
	}

	/**
	 * Redirect back to the password form with a safe error key.
	 *
	 * @param string $login_url Login page URL.
	 * @param string $reset_key WordPress password reset key.
	 * @param string $user_login WordPress user login.
	 * @param string $error Public error key.
	 *
	 * @return void
	 */
	private static function redirect_reset_error(
		$login_url,
		$reset_key,
		$user_login,
		$error
	) {
		$args = array(
			'action'            => 'rp',
			'key'               => $reset_key,
			'login'             => $user_login,
			'tutorhelper_reset' => sanitize_key( $error ),
		);

		wp_safe_redirect(
			add_query_arg(
				$args,
				$login_url
			)
		);
		exit;
	}

	/**
	 * Return the current page permalink.
	 *
	 * @return string
	 */
	private static function get_current_page_url() {
		$page_id = get_queried_object_id();
		$url     = $page_id ? get_permalink( $page_id ) : '';

		return $url ? $url : home_url( '/' );
	}

	/**
	 * Resolve a safe return URL for failed submissions.
	 *
	 * @return string
	 */
	private static function get_return_url() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Used only as a validated failure redirect; the login nonce is verified by the caller.
		$submitted = isset( $_POST['tutorhelper_login_return'] ) && ! is_array( $_POST['tutorhelper_login_return'] )
			? esc_url_raw( wp_unslash( $_POST['tutorhelper_login_return'] ) )
			: '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return wp_validate_redirect( $submitted, home_url( '/' ) );
	}

	/**
	 * Redirect to the configured dashboard.
	 *
	 * @return void
	 */
	private static function redirect_to_dashboard() {
		$dashboard_url = TutorHelper_Settings::get_student_dashboard_url();

		wp_safe_redirect( $dashboard_url ? $dashboard_url : home_url( '/' ) );
		exit;
	}

	/**
	 * Redirect back to the form with a safe error key.
	 *
	 * @param string $return_url Login page URL.
	 * @param string $error      Public error key.
	 * @return void
	 */
	private static function redirect_with_error( $return_url, $error ) {
		wp_safe_redirect(
			add_query_arg(
				'tutorhelper_login',
				sanitize_key( $error ),
				remove_query_arg( 'tutorhelper_login', $return_url )
			)
		);
		exit;
	}
}
