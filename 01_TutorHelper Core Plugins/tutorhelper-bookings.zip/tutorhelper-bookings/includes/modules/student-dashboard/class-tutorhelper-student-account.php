<?php
/**
 * Front-end TutorHelper account details.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders and updates the optional Account dashboard tab.
 */
final class TutorHelper_Student_Account {

	const SAVE_ACTION = 'tutorhelper_save_account_details';
	const TAB_QUERY   = 'tutorhelper_dashboard_tab';

	/** Register the protected account save action. */
	public static function init() {
		add_action(
			'admin_post_' . self::SAVE_ACTION,
			array( __CLASS__, 'handle_save' )
		);
	}

	/** Whether the Account tab is available. */
	public static function is_enabled() {
		return (bool) apply_filters(
			'tutorhelper_student_dashboard_account_enabled',
			true,
			get_current_user_id()
		);
	}

	/**
	 * Return registered dashboard tabs.
	 *
	 * Extensions may add a tab through tutorhelper_student_dashboard_tabs.
	 * The Dashboard remains responsible for the active-tab query handling and
	 * markup so add-ons do not need to duplicate navigation.
	 *
	 * @return array<string,string>
	 */
	public static function dashboard_tabs() {
		$tabs = array(
			'lessons' => __( 'Lessons', 'tutorhelper-bookings' ),
		);
		if ( self::is_enabled() ) {
			$tabs['account'] = __( 'Account details', 'tutorhelper-bookings' );
		}
		$tabs = apply_filters( 'tutorhelper_student_dashboard_tabs', $tabs, get_current_user_id() );
		$valid_tabs = array();
		foreach ( is_array( $tabs ) ? $tabs : array() as $key => $label ) {
			$key = sanitize_key( $key );
			if ( $key && is_string( $label ) && '' !== trim( $label ) ) {
				$valid_tabs[ $key ] = $label;
			}
		}
		if ( ! isset( $valid_tabs['lessons'] ) ) {
			$valid_tabs = array_merge( array( 'lessons' => __( 'Lessons', 'tutorhelper-bookings' ) ), $valid_tabs );
		}
		return $valid_tabs;
	}

	/** Return the selected dashboard tab. */
	public static function get_active_tab() {
		$tab = isset( $_GET[ self::TAB_QUERY ] ) && ! is_array( $_GET[ self::TAB_QUERY ] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only dashboard navigation.
			? sanitize_key( wp_unslash( $_GET[ self::TAB_QUERY ] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only dashboard navigation.
			: 'lessons';

		return array_key_exists( $tab, self::dashboard_tabs() ) ? $tab : 'lessons';
	}

	/** Render dashboard navigation and quick links. */
	public static function render_navigation( $active_tab ) {
		$current_url = get_permalink();
		$booking_url = TutorHelper_Settings::get_student_booking_url();
		?>
		<nav class="tutorhelper-student-dashboard__navigation" aria-label="<?php esc_attr_e( 'Dashboard navigation', 'tutorhelper-bookings' ); ?>">
			<div class="tutorhelper-student-dashboard__tabs">
				<?php foreach ( self::dashboard_tabs() as $tab => $label ) : ?>
					<a class="<?php echo $tab === $active_tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( 'lessons' === $tab ? remove_query_arg( self::TAB_QUERY, $current_url ) : add_query_arg( self::TAB_QUERY, $tab, $current_url ) ); ?>"<?php echo $tab === $active_tab ? ' aria-current="page"' : ''; ?>>
						<?php echo esc_html( $label ); ?>
					</a>
				<?php endforeach; ?>
			</div>
			<div class="tutorhelper-student-dashboard__quick-links">
				<?php if ( $booking_url ) : ?>
					<a href="<?php echo esc_url( $booking_url ); ?>"><?php esc_html_e( 'Book a lesson', 'tutorhelper-bookings' ); ?></a>
				<?php endif; ?>
				<a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Log out', 'tutorhelper-bookings' ); ?></a>
			</div>
		</nav>
		<?php
	}

	/** Render the editable account form. */
	public static function render() {
		$user = wp_get_current_user();
		if ( ! $user->exists() ) {
			return;
		}

		$status = isset( $_GET['tutorhelper_account_status'] ) && ! is_array( $_GET['tutorhelper_account_status'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only action result.
			? sanitize_key( wp_unslash( $_GET['tutorhelper_account_status'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only action result.
			: '';
		?>
		<section class="tutorhelper-student-account">
			<header>
				<h3><?php esc_html_e( 'My account details', 'tutorhelper-bookings' ); ?></h3>
				<p><?php esc_html_e( 'Keep your contact and postal details up to date.', 'tutorhelper-bookings' ); ?></p>
			</header>
			<?php if ( 'saved' === $status ) : ?>
				<p class="tutorhelper-student-dashboard__notice tutorhelper-student-dashboard__notice--success" role="status"><?php esc_html_e( 'Your account details have been saved.', 'tutorhelper-bookings' ); ?></p>
			<?php elseif ( 'error' === $status ) : ?>
				<p class="tutorhelper-student-dashboard__notice tutorhelper-student-dashboard__notice--error" role="alert"><?php esc_html_e( 'Your account details could not be saved. Check the highlighted information and try again.', 'tutorhelper-bookings' ); ?></p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tutorhelper-student-account__form">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>" />
				<?php wp_nonce_field( self::SAVE_ACTION, 'tutorhelper_account_nonce' ); ?>
				<div class="tutorhelper-student-account__grid">
					<label><span><?php esc_html_e( 'First name', 'tutorhelper-bookings' ); ?></span><input type="text" name="first_name" value="<?php echo esc_attr( $user->first_name ); ?>" autocomplete="given-name" required /></label>
					<label><span><?php esc_html_e( 'Last name', 'tutorhelper-bookings' ); ?></span><input type="text" name="last_name" value="<?php echo esc_attr( $user->last_name ); ?>" autocomplete="family-name" required /></label>
					<label><span><?php esc_html_e( 'Email address', 'tutorhelper-bookings' ); ?></span><input type="email" name="user_email" value="<?php echo esc_attr( $user->user_email ); ?>" autocomplete="email" required /></label>
					<label><span><?php esc_html_e( 'Phone number', 'tutorhelper-bookings' ); ?></span><input type="tel" name="phone" value="<?php echo esc_attr( get_user_meta( $user->ID, TutorHelper_Students::META_STUDENT_PHONE, true ) ); ?>" autocomplete="tel" /></label>
					<label class="tutorhelper-student-account__wide"><span><?php esc_html_e( 'Address line 1', 'tutorhelper-bookings' ); ?></span><input type="text" name="address_1" value="<?php echo esc_attr( get_user_meta( $user->ID, TutorHelper_Students::META_ADDRESS_LINE_1, true ) ); ?>" autocomplete="address-line1" /></label>
					<label class="tutorhelper-student-account__wide"><span><?php esc_html_e( 'Address line 2', 'tutorhelper-bookings' ); ?></span><input type="text" name="address_2" value="<?php echo esc_attr( get_user_meta( $user->ID, TutorHelper_Students::META_ADDRESS_LINE_2, true ) ); ?>" autocomplete="address-line2" /></label>
					<label><span><?php esc_html_e( 'Town or city', 'tutorhelper-bookings' ); ?></span><input type="text" name="city" value="<?php echo esc_attr( get_user_meta( $user->ID, TutorHelper_Students::META_ADDRESS_CITY, true ) ); ?>" autocomplete="address-level2" /></label>
					<label><span><?php esc_html_e( 'County', 'tutorhelper-bookings' ); ?></span><input type="text" name="county" value="<?php echo esc_attr( get_user_meta( $user->ID, TutorHelper_Students::META_ADDRESS_COUNTY, true ) ); ?>" autocomplete="address-level1" /></label>
					<label><span><?php esc_html_e( 'Postcode', 'tutorhelper-bookings' ); ?></span><input type="text" name="postcode" value="<?php echo esc_attr( get_user_meta( $user->ID, TutorHelper_Students::META_ADDRESS_POSTCODE, true ) ); ?>" autocomplete="postal-code" /></label>
					<label><span><?php esc_html_e( 'Country code', 'tutorhelper-bookings' ); ?></span><input type="text" name="country" maxlength="2" value="<?php echo esc_attr( get_user_meta( $user->ID, TutorHelper_Students::META_ADDRESS_COUNTRY, true ) ); ?>" autocomplete="country" /></label>
				</div>
				<button type="submit" class="button"><?php esc_html_e( 'Save account details', 'tutorhelper-bookings' ); ?></button>
			</form>
			<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
				<p class="tutorhelper-student-account__woocommerce">
					<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"><?php esc_html_e( 'View WooCommerce orders', 'tutorhelper-bookings' ); ?></a>
				</p>
			<?php endif; ?>
		</section>
		<?php
	}

	/** Save the signed-in user's submitted account details. */
	public static function handle_save() {
		$user_id = get_current_user_id();
		if ( ! $user_id || ! current_user_can( 'read' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to update this account.', 'tutorhelper-bookings' ),
				'',
				array( 'response' => 403 )
			);
		}

		check_admin_referer( self::SAVE_ACTION, 'tutorhelper_account_nonce' );

		$email = isset( $_POST['user_email'] ) && ! is_array( $_POST['user_email'] )
			? sanitize_email( wp_unslash( $_POST['user_email'] ) )
			: '';

		if ( ! is_email( $email ) ) {
			self::redirect( 'error' );
		}

		$existing = get_user_by( 'email', $email );
		if ( $existing instanceof WP_User && absint( $existing->ID ) !== $user_id ) {
			self::redirect( 'error' );
		}

		$result = wp_update_user(
			array(
				'ID'         => $user_id,
				'first_name' => self::posted_text( 'first_name' ),
				'last_name'  => self::posted_text( 'last_name' ),
				'user_email' => $email,
			)
		);

		if ( is_wp_error( $result ) ) {
			self::redirect( 'error' );
		}

		$meta = array(
			TutorHelper_Students::META_STUDENT_PHONE    => 'phone',
			TutorHelper_Students::META_ADDRESS_LINE_1  => 'address_1',
			TutorHelper_Students::META_ADDRESS_LINE_2  => 'address_2',
			TutorHelper_Students::META_ADDRESS_CITY    => 'city',
			TutorHelper_Students::META_ADDRESS_COUNTY  => 'county',
			TutorHelper_Students::META_ADDRESS_POSTCODE => 'postcode',
			TutorHelper_Students::META_ADDRESS_COUNTRY => 'country',
		);

		foreach ( $meta as $meta_key => $field ) {
			$value = self::posted_text( $field );
			if ( TutorHelper_Students::META_ADDRESS_COUNTRY === $meta_key ) {
				$value = strtoupper( substr( $value, 0, 2 ) );
			}
			update_user_meta( $user_id, $meta_key, $value );
		}

		self::redirect( 'saved' );
	}

	/** Return one sanitized scalar POST field. */
	private static function posted_text( $field ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- This helper is called only after handle_save() verifies the account nonce.
		$value = isset( $_POST[ $field ] ) && ! is_array( $_POST[ $field ] )
			? sanitize_text_field( wp_unslash( $_POST[ $field ] ) )
			: '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return $value;
	}

	/** Redirect back to the Account tab with a status. */
	private static function redirect( $status ) {
		$url = wp_get_referer();
		$url = $url ? $url : TutorHelper_Settings::get_student_dashboard_url();
		$url = add_query_arg(
			array(
				self::TAB_QUERY             => 'account',
				'tutorhelper_account_status' => sanitize_key( $status ),
			),
			$url
		);
		wp_safe_redirect( $url );
		exit;
	}
}
