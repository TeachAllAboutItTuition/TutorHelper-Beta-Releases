<?php
/**
 * Student dashboard front-end assets.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers student dashboard assets.
 */
final class TutorHelper_Student_Dashboard_Frontend {

	/**
	 * Stylesheet handle.
	 *
	 * @var string
	 */
	const STYLE_HANDLE =
		'tutorhelper-student-dashboard';

	/**
	 * Sidebar countdown script handle.
	 *
	 * @var string
	 */
	const SIDEBAR_SCRIPT_HANDLE =
		'tutorhelper-student-sidebar';

	/**
	 * Shared password visibility script handle.
	 *
	 * @var string
	 */
	const PASSWORD_SCRIPT_HANDLE =
		'tutorhelper-password-visibility';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'wp_enqueue_scripts',
			array(
				__CLASS__,
				'maybe_enqueue_assets',
			)
		);
	}

	/**
	 * Register and enqueue front-end student account styles before wp_head().
	 *
	 * The stylesheet is intentionally small and fully namespaced. Loading it on
	 * every public page also supports shortcodes embedded by page builders,
	 * widgets and reusable blocks whose source is not present in post_content.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_assets() {
		self::register_assets();

		wp_enqueue_style( self::STYLE_HANDLE );
		wp_enqueue_script( self::PASSWORD_SCRIPT_HANDLE );
	}

	/**
	 * Register dashboard assets.
	 *
	 * @return void
	 */
	public static function register_assets() {
		$css_path =
			TUTORHELPER_BOOKINGS_PATH
			. 'assets/css/student-dashboard.css';

		wp_register_style(
			self::STYLE_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/css/student-dashboard.css',
			array(),
			file_exists( $css_path )
				? (string) filemtime(
					$css_path
				)
				: TUTORHELPER_BOOKINGS_VERSION
		);

		$sidebar_script_path =
			TUTORHELPER_BOOKINGS_PATH
			. 'assets/js/student-account-sidebar.js';

		wp_register_script(
			self::SIDEBAR_SCRIPT_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/js/student-account-sidebar.js',
			array(),
			file_exists( $sidebar_script_path )
				? (string) filemtime( $sidebar_script_path )
				: TUTORHELPER_BOOKINGS_VERSION,
			true
		);

		$password_script_path =
			TUTORHELPER_BOOKINGS_PATH
			. 'assets/js/password-visibility.js';

		wp_register_script(
			self::PASSWORD_SCRIPT_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/js/password-visibility.js',
			array(),
			file_exists( $password_script_path )
				? (string) filemtime( $password_script_path )
				: TUTORHELPER_BOOKINGS_VERSION,
			true
		);
	}

	/**
	 * Enqueue dashboard assets.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {
		if (
			! wp_style_is(
				self::STYLE_HANDLE,
				'registered'
			)
		) {
			self::register_assets();
		}

		wp_enqueue_style(
			self::STYLE_HANDLE
		);

		if ( ! wp_script_is( self::PASSWORD_SCRIPT_HANDLE, 'registered' ) ) {
			self::register_assets();
		}

		wp_enqueue_script( self::PASSWORD_SCRIPT_HANDLE );
	}

	/**
	 * Enqueue the compact account sidebar and live countdown assets.
	 *
	 * @return void
	 */
	public static function enqueue_sidebar_assets() {
		self::enqueue_assets();

		if ( ! wp_script_is( self::SIDEBAR_SCRIPT_HANDLE, 'registered' ) ) {
			self::register_assets();
		}

		wp_enqueue_script( self::SIDEBAR_SCRIPT_HANDLE );

		wp_localize_script(
			self::SIDEBAR_SCRIPT_HANDLE,
			'tutorhelperStudentSidebar',
			array(
				/* translators: %s: Human-readable time remaining until the lesson. */
				'startsIn'   => __( 'Starts in %s.', 'tutorhelper-bookings' ),
				'startingNow' => __( 'Your lesson is starting now.', 'tutorhelper-bookings' ),
				'day'        => __( 'day', 'tutorhelper-bookings' ),
				'days'       => __( 'days', 'tutorhelper-bookings' ),
				'hour'       => __( 'hour', 'tutorhelper-bookings' ),
				'hours'      => __( 'hours', 'tutorhelper-bookings' ),
				'minute'     => __( 'minute', 'tutorhelper-bookings' ),
				'minutes'    => __( 'minutes', 'tutorhelper-bookings' ),
			)
		);
	}
}
