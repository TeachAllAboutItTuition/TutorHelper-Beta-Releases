<?php
/**
 * Student dashboard module.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the student dashboard components.
 */
final class TutorHelper_Student_Dashboard_Module {

	/**
	 * Initialise the module.
	 *
	 * @return void
	 */
	public static function init() {
		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-dashboard/'
			. 'class-tutorhelper-student-dashboard-bookings.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-dashboard/'
			. 'class-tutorhelper-student-dashboard-actions.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-dashboard/'
			. 'class-tutorhelper-student-dashboard-frontend.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-dashboard/'
			. 'class-tutorhelper-student-dashboard-shortcode.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-dashboard/'
			. 'class-tutorhelper-student-account.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-dashboard/'
			. 'class-tutorhelper-student-login-shortcode.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/student-dashboard/'
			. 'class-tutorhelper-student-sidebar-shortcode.php';

		
		TutorHelper_Student_Dashboard_Actions::init();
		
		TutorHelper_Student_Dashboard_Frontend::init();

		TutorHelper_Student_Dashboard_Shortcode::init();

		TutorHelper_Student_Account::init();

		TutorHelper_Student_Login_Shortcode::init();

		TutorHelper_Student_Sidebar_Shortcode::init();
	}
}
