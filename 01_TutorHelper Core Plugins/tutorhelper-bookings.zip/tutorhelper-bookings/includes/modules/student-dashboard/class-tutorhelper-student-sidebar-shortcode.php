<?php
/**
 * Compact front-end student account sidebar.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders a compact account panel for a theme sidebar or widget area.
 */
final class TutorHelper_Student_Sidebar_Shortcode {

	/**
	 * Shortcode name.
	 *
	 * @var string
	 */
	const SHORTCODE = 'tutorhelper_student_sidebar';

	/**
	 * Register the shortcode.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode(
			self::SHORTCODE,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Render the student account panel.
	 *
	 * @return string
	 */
	public static function render() {
		TutorHelper_Student_Dashboard_Frontend::enqueue_sidebar_assets();

		$login_url     = TutorHelper_Settings::get_login_url();
		$dashboard_url = TutorHelper_Settings::get_student_dashboard_url();

		if ( ! is_user_logged_in() ) {
			ob_start();
			?>
			<aside class="tutorhelper-student-sidebar tutorhelper-student-sidebar--logged-out">
				<h2 class="tutorhelper-student-sidebar__heading"><?php esc_html_e( 'Student account', 'tutorhelper-bookings' ); ?></h2>
				<p><?php esc_html_e( 'Please log in to access your tuition.', 'tutorhelper-bookings' ); ?></p>
				<a class="tutorhelper-student-sidebar__button" href="<?php echo esc_url( $login_url ); ?>">
					<?php esc_html_e( 'Log in', 'tutorhelper-bookings' ); ?>
				</a>
			</aside>
			<?php
			return ob_get_clean();
		}

		$user        = wp_get_current_user();
		$first_name  = self::get_first_name( $user );
		$next_lesson = self::get_next_lesson( $user->ID );

		ob_start();
		?>
		<aside class="tutorhelper-student-sidebar tutorhelper-student-sidebar--logged-in">
			<p class="tutorhelper-student-sidebar__eyebrow"><?php esc_html_e( 'Welcome back', 'tutorhelper-bookings' ); ?></p>
			<h2 class="tutorhelper-student-sidebar__heading">
				<?php
				printf(
					/* translators: %s: Student first name. */
					esc_html__( 'Hi %s!', 'tutorhelper-bookings' ),
					esc_html( $first_name )
				);
				?>
			</h2>

			<?php if ( $next_lesson ) : ?>
				<div class="tutorhelper-student-sidebar__next-lesson">
					<span class="tutorhelper-student-sidebar__next-label"><?php esc_html_e( 'Your next lesson', 'tutorhelper-bookings' ); ?></span>
					<strong><?php echo esc_html( $next_lesson['title'] ); ?></strong>
					<time datetime="<?php echo esc_attr( $next_lesson['start']->format( DateTimeInterface::ATOM ) ); ?>">
						<?php echo esc_html( self::format_lesson_date( $next_lesson['start'] ) ); ?>
					</time>
					<span
						class="tutorhelper-student-sidebar__countdown"
						data-tutorhelper-next-lesson-countdown
						data-start="<?php echo esc_attr( $next_lesson['start']->format( DateTimeInterface::ATOM ) ); ?>"
						aria-live="polite"
					>
						<?php
						printf(
							/* translators: %s: Approximate time until the next lesson. */
							esc_html__( 'Starts in approximately %s.', 'tutorhelper-bookings' ),
							esc_html( human_time_diff( time(), $next_lesson['start']->getTimestamp() ) )
						);
						?>
					</span>
				</div>
			<?php else : ?>
				<p class="tutorhelper-student-sidebar__empty"><?php esc_html_e( 'You have no upcoming confirmed lessons.', 'tutorhelper-bookings' ); ?></p>
			<?php endif; ?>

			<a class="tutorhelper-student-sidebar__button" href="<?php echo esc_url( $dashboard_url ? $dashboard_url : home_url( '/' ) ); ?>">
				<?php esc_html_e( 'Open student dashboard', 'tutorhelper-bookings' ); ?>
			</a>
			<a class="tutorhelper-student-sidebar__logout" href="<?php echo esc_url( wp_logout_url( $login_url ) ); ?>">
				<?php esc_html_e( 'Log out', 'tutorhelper-bookings' ); ?>
			</a>
		</aside>
		<?php

		return ob_get_clean();
	}

	/**
	 * Return a friendly name for the current user.
	 *
	 * @param WP_User $user Current user.
	 * @return string
	 */
	private static function get_first_name( $user ) {
		$first_name = isset( $user->first_name )
			? sanitize_text_field( $user->first_name )
			: '';

		if ( '' !== $first_name ) {
			return $first_name;
		}

		return sanitize_text_field( $user->display_name );
	}

	/**
	 * Return the next future confirmed lesson.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @return array|null
	 */
	private static function get_next_lesson( $student_user_id ) {
		$bookings = TutorHelper_Student_Dashboard_Bookings::get_upcoming(
			absint( $student_user_id )
		);

		foreach ( $bookings as $booking ) {
			if (
				isset( $booking['status'], $booking['start'] )
				&& TutorHelper_Booking_Records::STATUS_CONFIRMED === $booking['status']
				&& $booking['start'] instanceof DateTimeInterface
				&& $booking['start']->getTimestamp() > time()
			) {
				return $booking;
			}
		}

		return null;
	}

	/**
	 * Format a lesson start in its booking timezone.
	 *
	 * @param DateTimeInterface $start Lesson start.
	 * @return string
	 */
	private static function format_lesson_date( $start ) {
		return wp_date(
			get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ),
			$start->getTimestamp(),
			$start->getTimezone()
		);
	}
}
