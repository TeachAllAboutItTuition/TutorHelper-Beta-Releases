<?php
/**
 * TutorHelper student data export and erasure.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles TutorHelper student data management.
 */
final class TutorHelper_Student_Data {

	/**
	 * Student export action.
	 *
	 * @var string
	 */
	const EXPORT_ACTION =
		'tutorhelper_export_student_data';

	/**
	 * Student deletion action.
	 *
	 * @var string
	 */
	const DELETE_ACTION =
		'tutorhelper_delete_student_data';

    /**
     * Privacy-erasure mode.
     *
     * Removes identifying TutorHelper data while retaining
     * anonymised records where retention may be required.
     *
     * @var string
     */
    const DELETE_MODE_ERASE =
        'erase';


    /**
     * Full-deletion mode.
     *
     * Removes all TutorHelper records associated with the student.
     *
     * @var string
     */
    const DELETE_MODE_FULL =
        'full';


	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {

		add_action(
			'tutorhelper_students_detail_data_export',
			array(
				__CLASS__,
				'render_panel',
			),
			100
		);

		add_action(
			'admin_post_'
				. self::EXPORT_ACTION,
			array(
				__CLASS__,
				'handle_export',
			)
		);

		add_action(
			'admin_post_'
				. self::DELETE_ACTION,
			array(
				__CLASS__,
				'handle_delete',
			)
		);
	}


    /**
     * Render student data management controls.
     *
     * @param WP_User $student Student user.
     *
     * @return void
     */
    public static function render_panel(
        $student
    ) {

        if (
            ! $student instanceof WP_User
            || ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            return;
        }

        $student_id =
            absint(
                $student->ID
            );

        ?>
        <section
            class="tutorhelper-students-panel tutorhelper-student-data-panel"
        >
            <header
                class="tutorhelper-students-panel__header"
            >
                <h3>
                    <?php
                    echo esc_html__(
                        'Data & Privacy',
                        'tutorhelper-bookings'
                    );
                    ?>
                </h3>

                <p>
                    <?php
                    echo esc_html__(
                        'Export or remove TutorHelper data associated with this student.',
                        'tutorhelper-bookings'
                    );
                    ?>
                </p>
            </header>

            <div
                class="tutorhelper-students-panel__body"
            >
                <div
                    class="tutorhelper-student-data-actions"
                >
                    <form
                        method="post"
                        action="<?php
                            echo esc_url(
                                admin_url(
                                    'admin-post.php'
                                )
                            );
                        ?>"
                    >
                        <input
                            type="hidden"
                            name="action"
                            value="<?php
                                echo esc_attr(
                                    self::EXPORT_ACTION
                                );
                            ?>"
                        />

                        <input
                            type="hidden"
                            name="student_user_id"
                            value="<?php
                                echo esc_attr(
                                    $student_id
                                );
                            ?>"
                        />

                        <?php
                        wp_nonce_field(
                            self::EXPORT_ACTION
                            . '_'
                            . $student_id
                        );
                        ?>

                        <div
                            class="tutorhelper-student-data-export"
                        >
                            <label
                                for="tutorhelper-student-export-format-<?php
                                    echo esc_attr(
                                        $student_id
                                    );
                                ?>"
                            >
                                <?php
                                echo esc_html__(
                                    'Export format',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </label>

                            <select
                                id="tutorhelper-student-export-format-<?php
                                    echo esc_attr(
                                        $student_id
                                    );
                                ?>"
                                name="export_format"
                                class="tutorhelper-admin-control"
                            >
                                <option value="pdf">
                                    <?php
                                    echo esc_html__(
                                        'PDF - readable report',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </option>

                                <option value="csv">
                                    <?php
                                    echo esc_html__(
                                        'CSV - spreadsheet',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </option>

                                <option value="json">
                                    <?php
                                    echo esc_html__(
                                        'JSON - complete data',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </option>
                            </select>

                            <button
                                type="submit"
                                class="button tutorhelper-admin-button"
                            >
                                <span
                                    class="dashicons dashicons-download"
                                    aria-hidden="true"
                                ></span>

                                <?php
                                echo esc_html__(
                                    'Export student data',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </button>
                        </div>

                    </form>

                    <div
                        class="tutorhelper-student-data-erasure"
                    >
                        <h4>
                            <?php
                            echo esc_html__(
                                'Privacy erasure',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </h4>

                        <p>
                            <?php
                            echo esc_html__(
                                'Remove identifying TutorHelper information while retaining anonymised records that may be required for finance and audit purposes.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>

                        <form
                            method="post"
                            action="<?php
                                echo esc_url(
                                    admin_url(
                                        'admin-post.php'
                                    )
                                );
                            ?>"
                            data-tutorhelper-student-delete
                            data-delete-mode="erase"
                        >
                            <input
                                type="hidden"
                                name="action"
                                value="<?php
                                    echo esc_attr(
                                        self::DELETE_ACTION
                                    );
                                ?>"
                            />

                            <input
                                type="hidden"
                                name="student_user_id"
                                value="<?php
                                    echo esc_attr(
                                        $student_id
                                    );
                                ?>"
                            />

                            <input
                                type="hidden"
                                name="deletion_mode"
                                value="<?php
                                    echo esc_attr(
                                        self::DELETE_MODE_ERASE
                                    );
                                ?>"
                            />

                            <?php
                            wp_nonce_field(
                                self::DELETE_ACTION
                                . '_'
                                . $student_id
                            );
                            ?>

                            <button
                                type="submit"
                                class="button tutorhelper-admin-button"
                            >
                                <span
                                    class="dashicons dashicons-privacy"
                                    aria-hidden="true"
                                ></span>

                                <?php
                                echo esc_html__(
                                    'Erase TutorHelper personal data',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </button>
                        </form>
                    </div>

                    <div
                        class="tutorhelper-student-data-danger"
                    >
                        <h4>
                            <?php
                            echo esc_html__(
                                'Danger zone',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </h4>

                        <p>
                            <?php
                            echo esc_html__(
                                'Permanently remove all TutorHelper records for this student. Use this for test, duplicate or incorrectly-created accounts.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>

                        <form
                            method="post"
                            action="<?php
                                echo esc_url(
                                    admin_url(
                                        'admin-post.php'
                                    )
                                );
                            ?>"
                            data-tutorhelper-student-delete
                            data-delete-mode="full"
                        >
                            <input
                                type="hidden"
                                name="action"
                                value="<?php
                                    echo esc_attr(
                                        self::DELETE_ACTION
                                    );
                                ?>"
                            />

                            <input
                                type="hidden"
                                name="student_user_id"
                                value="<?php
                                    echo esc_attr(
                                        $student_id
                                    );
                                ?>"
                            />

                            <input
                                type="hidden"
                                name="deletion_mode"
                                value="<?php
                                    echo esc_attr(
                                        self::DELETE_MODE_FULL
                                    );
                                ?>"
                            />

                            <?php
                            wp_nonce_field(
                                self::DELETE_ACTION
                                . '_'
                                . $student_id
                            );
                            ?>

                            <button
                                type="submit"
                                class="
                                    button
                                    tutorhelper-admin-button
                                    tutorhelper-admin-button--danger
                                "
                            >
                                <span
                                    class="dashicons dashicons-trash"
                                    aria-hidden="true"
                                ></span>

                                <?php
                                echo esc_html__(
                                    'Delete all TutorHelper data',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }


    /**
     * Export TutorHelper student data.
     *
     * @return void
     */
    public static function handle_export() {

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to export student data.',
                    'tutorhelper-bookings'
                )
            );
        }

        $student_id =
            isset(
                $_POST['student_user_id']
            )
                ? absint(
                    $_POST[
                        'student_user_id'
                    ]
                )
                : 0;

        if ( ! $student_id ) {
            wp_die(
                esc_html__(
                    'The student could not be found.',
                    'tutorhelper-bookings'
                )
            );
        }

        

        check_admin_referer(
            self::EXPORT_ACTION
            . '_'
            . $student_id
        );

        $student =
            TutorHelper_Students::
                get_student(
                    $student_id
                );

        if ( ! $student ) {
            wp_die(
                esc_html__(
                    'The student could not be found.',
                    'tutorhelper-bookings'
                )
            );
        }

        $export_format =
            isset(
                $_POST['export_format']
            )
            && ! is_array(
                $_POST['export_format']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_POST['export_format']
                    )
                )
                : 'pdf';

        if (
            ! in_array(
                $export_format,
                array(
                    'pdf',
                    'csv',
                    'json',
                ),
                true
            )
        ) {
            $export_format =
                'pdf';
        }

        $data =
            self::build_export(
                $student
            );

        /**
         * Allow add-ons to append their own student data.
         *
         * @param array   $data    Export data.
         * @param WP_User $student Student account.
         */
        $data =
            apply_filters(
                'tutorhelper_student_data_export',
                $data,
                $student
            );

        switch ( $export_format ) {

            case 'csv':
                self::send_csv_export(
                    $data,
                    $student_id
                );
                break;

            case 'pdf':
                self::send_pdf_export(
                    $data,
                    $student,
                    $student_id
                );
                break;

            case 'json':
            default:
                self::send_json_export(
                    $data,
                    $student_id
                );
                break;
        }

        exit;
    }


    /**
     * Send student data as JSON.
     *
     * @param array $data       Export data.
     * @param int   $student_id Student ID.
     *
     * @return void
     */
    private static function send_json_export(
        $data,
        $student_id
    ) {

        $filename =
            self::get_export_filename(
                $student_id,
                'json'
            );

        nocache_headers();

        header(
            'Content-Type: application/json; charset=utf-8'
        );

        header(
            'Content-Disposition: attachment; filename="'
            . $filename
            . '"'
        );

        echo wp_json_encode(
            $data,
            JSON_PRETTY_PRINT
            | JSON_UNESCAPED_SLASHES
        );
    }


    /**
     * Build a student export filename.
     *
     * @param int    $student_id Student ID.
     * @param string $extension  File extension.
     *
     * @return string
     */
    private static function get_export_filename(
        $student_id,
        $extension
    ) {

        return sprintf(
            'tutorhelper-student-%1$d-%2$s.%3$s',
            absint(
                $student_id
            ),
            gmdate(
                'Y-m-d'
            ),
            sanitize_key(
                $extension
            )
        );
    }


    /**
     * Send student data as CSV.
     *
     * @param array $data       Export data.
     * @param int   $student_id Student ID.
     *
     * @return void
     */
    private static function send_csv_export(
        $data,
        $student_id
    ) {

        $filename =
            self::get_export_filename(
                $student_id,
                'csv'
            );

        nocache_headers();

        header(
            'Content-Type: text/csv; charset=utf-8'
        );

        header(
            'Content-Disposition: attachment; filename="'
            . $filename
            . '"'
        );

        $output =
            fopen(
                'php://output',
                'w'
            );

        if ( false === $output ) {
            return;
        }

        /*
        * UTF-8 BOM improves Excel compatibility.
        */
        fwrite( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- The CSV is streamed directly to the HTTP response; WP_Filesystem does not support output streams.
            $output,
            "\xEF\xBB\xBF"
        );

        fputcsv(
            $output,
            array(
                'Section',
                'Record',
                'Field',
                'Value',
            )
        );

        self::write_csv_rows(
            $output,
            $data
        );

        fclose( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Close the HTTP output stream opened for this CSV download.
            $output
        );
    }


    /**
     * Write nested export data as CSV rows.
     *
     * @param resource $output CSV stream.
     * @param array    $data   Export data.
     * @param string   $section Current section.
     *
     * @return void
     */
    private static function write_csv_rows(
        $output,
        $data,
        $section = ''
    ) {

        foreach (
            $data
            as $key => $value
        ) {

            $current_section =
                '' === $section
                    ? (string) $key
                    : $section
                        . '.'
                        . $key;

            if (
                is_object(
                    $value
                )
            ) {
                $value =
                    get_object_vars(
                        $value
                    );
            }

            if (
                is_array(
                    $value
                )
            ) {

                if (
                    self::is_list_array(
                        $value
                    )
                ) {

                    $record_number = 0;

                    foreach (
                        $value
                        as $record
                    ) {

                        $record_number++;

                        if (
                            is_object(
                                $record
                            )
                        ) {
                            $record =
                                get_object_vars(
                                    $record
                                );
                        }

                        if (
                            is_array(
                                $record
                            )
                        ) {

                            foreach (
                                $record
                                as $field =>
                                    $field_value
                            ) {
                                fputcsv(
                                    $output,
                                    array(
                                        $current_section,
                                        $record_number,
                                        $field,
                                        self::csv_value(
                                            $field_value
                                        ),
                                    )
                                );
                            }
                        } else {
                            fputcsv(
                                $output,
                                array(
                                    $current_section,
                                    $record_number,
                                    'value',
                                    self::csv_value(
                                        $record
                                    ),
                                )
                            );
                        }
                    }

                    continue;
                }

                foreach (
                    $value
                    as $field =>
                        $field_value
                ) {

                    if (
                        is_array(
                            $field_value
                        )
                        || is_object(
                            $field_value
                        )
                    ) {
                        self::write_csv_rows(
                            $output,
                            array(
                                $field =>
                                    $field_value,
                            ),
                            $current_section
                        );

                        continue;
                    }

                    fputcsv(
                        $output,
                        array(
                            $current_section,
                            1,
                            $field,
                            self::csv_value(
                                $field_value
                            ),
                        )
                    );
                }

                continue;
            }

            fputcsv(
                $output,
                array(
                    $current_section,
                    1,
                    'value',
                    self::csv_value(
                        $value
                    ),
                )
            );
        }
    }


    /**
     * Determine whether an array is a list.
     *
     * PHP 7.1 compatible replacement for array_is_list().
     *
     * @param array $value Array.
     *
     * @return bool
     */
    private static function is_list_array(
        $value
    ) {

        if ( empty( $value ) ) {
            return true;
        }

        return array_keys(
            $value
        )
        === range(
            0,
            count(
                $value
            ) - 1
        );
    }


    /**
     * Prepare a value for CSV output.
     *
     * @param mixed $value Value.
     *
     * @return string
     */
    private static function csv_value(
        $value
    ) {

        if (
            is_array(
                $value
            )
            || is_object(
                $value
            )
        ) {
            $value =
                wp_json_encode(
                    $value,
                    JSON_UNESCAPED_SLASHES
                );
        }

        if (
            is_bool(
                $value
            )
        ) {
            return $value
                ? 'Yes'
                : 'No';
        }

        if ( null === $value ) {
            return '';
        }

        $value =
            (string) $value;

        /*
        * Prevent spreadsheet formula execution.
        */
        if (
            isset(
                $value[0]
            )
            && in_array(
                $value[0],
                array(
                    '=',
                    '+',
                    '-',
                    '@',
                ),
                true
            )
        ) {
            $value =
                "'"
                . $value;
        }

        return $value;
    }


    /**
     * Send student data as a human-readable PDF.
     *
     * @param array   $data       Export data.
     * @param WP_User $student    Student account.
     * @param int     $student_id Student ID.
     *
     * @return void
     */
    private static function send_pdf_export(
        $data,
        $student,
        $student_id
    ) {

        $autoload =
            TUTORHELPER_BOOKINGS_PATH
            . 'vendor/dompdf/autoload.inc.php';

        if (
            ! file_exists(
                $autoload
            )
        ) {
            wp_die(
                esc_html__(
                    'PDF export is currently unavailable.',
                    'tutorhelper-bookings'
                )
            );
        }

        require_once $autoload;

        $html =
            self::build_pdf_html(
                $data,
                $student
            );

        $options =
            new \Dompdf\Options();

        $options->set(
            'isRemoteEnabled',
            false
        );

        $dompdf =
            new \Dompdf\Dompdf(
                $options
            );

        $dompdf->loadHtml(
            $html,
            'UTF-8'
        );

        $dompdf->setPaper(
            'A4',
            'portrait'
        );

        $dompdf->render();

        $filename =
            self::get_export_filename(
                $student_id,
                'pdf'
            );

        $dompdf->stream(
            $filename,
            array(
                'Attachment' =>
                    true,
            )
        );

        exit;
    }


    /**
     * Build the student-data PDF report.
     *
     * @param array   $data    Export data.
     * @param WP_User $student Student.
     *
     * @return string
     */
    private static function build_pdf_html(
        $data,
        $student
    ) {

        $title =
            sprintf(
                /* translators: %s: student name. */
                __(
                    'TutorHelper Data Export - %s',
                    'tutorhelper-bookings'
                ),
                $student->display_name
            );

        $html =
            '<!doctype html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    @page {
                        margin: 36px;
                    }

                    body {
                        font-family: DejaVu Sans, sans-serif;
                        font-size: 10px;
                        line-height: 1.45;
                        color: #143f4d;
                    }

                    h1 {
                        font-size: 20px;
                        margin: 0 0 6px;
                    }

                    h2 {
                        margin: 22px 0 8px;
                        padding: 8px 10px;
                        background: #143f4d;
                        color: #ffffff;
                        font-size: 13px;
                    }

                    h3 {
                        margin: 14px 0 6px;
                        font-size: 11px;
                        color: #143f4d;
                    }

                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 12px;
                    }

                    th,
                    td {
                        padding: 6px 8px;
                        border: 1px solid #dcdcde;
                        vertical-align: top;
                        word-wrap: break-word;
                    }

                    th {
                        width: 30%;
                        background: #faf1eb;
                        text-align: left;
                    }

                    .meta {
                        margin-bottom: 18px;
                        color: #50575e;
                    }
                </style>
            </head>
            <body>';

        $html .=
            '<h1>'
            . esc_html(
                $title
            )
            . '</h1>';

        $html .=
            '<div class="meta">'
            . esc_html(
                sprintf(
                    /* translators: %s: export timestamp. */
                    __(
                        'Exported: %s',
                        'tutorhelper-bookings'
                    ),
                    current_time(
                        'mysql'
                    )
                )
            )
            . '</div>';

        $html .=
            self::render_pdf_data(
                $data
            );

        $html .=
            '</body></html>';

        return $html;
    }



    /**
     * Render nested export data as readable PDF HTML.
     *
     * @param array  $data  Export data.
     * @param string $title Optional section title.
     *
     * @return string
     */
    private static function render_pdf_data(
        $data,
        $title = ''
    ) {

        if ( ! is_array( $data ) ) {
            return '';
        }

        $html = '';

        if ( '' !== $title ) {
            $html .=
                '<h2>'
                . esc_html(
                    self::humanise_key(
                        $title
                    )
                )
                . '</h2>';
        }

        /*
        * Numbered arrays represent a collection of records.
        */
        if (
            self::is_list_array(
                $data
            )
        ) {

            if ( empty( $data ) ) {
                $html .=
                    '<p>No data recorded.</p>';

                return $html;
            }

            $record_number = 0;

            foreach (
                $data
                as $record
            ) {

                $record_number++;

                if (
                    is_object(
                        $record
                    )
                ) {
                    $record =
                        get_object_vars(
                            $record
                        );
                }

                $html .=
                    '<h3>Record '
                    . absint(
                        $record_number
                    )
                    . '</h3>';

                if (
                    is_array(
                        $record
                    )
                ) {
                    $html .=
                        self::render_pdf_record_table(
                            $record
                        );
                } else {
                    $html .=
                        '<p>'
                        . esc_html(
                            (string) $record
                        )
                        . '</p>';
                }
            }

            return $html;
        }

        /*
        * Associative arrays may contain scalar fields and
        * further nested sections.
        */
        $scalar_fields =
            array();

        foreach (
            $data
            as $key => $value
        ) {

            if (
                is_object(
                    $value
                )
            ) {
                $value =
                    get_object_vars(
                        $value
                    );
            }

            if (
                is_array(
                    $value
                )
            ) {

                if (
                    ! empty(
                        $scalar_fields
                    )
                ) {
                    $html .=
                        self::render_pdf_record_table(
                            $scalar_fields
                        );

                    $scalar_fields =
                        array();
                }

                $html .=
                    self::render_pdf_data(
                        $value,
                        (string) $key
                    );

                continue;
            }

            $scalar_fields[
                $key
            ] =
                $value;
        }

        if (
            ! empty(
                $scalar_fields
            )
        ) {
            $html .=
                self::render_pdf_record_table(
                    $scalar_fields
                );
        }

        return $html;
    }


    /**
     * Convert a data key into a readable label.
     *
     * @param string $key Data key.
     *
     * @return string
     */
    private static function humanise_key(
        $key
    ) {

        return ucwords(
            str_replace(
                array(
                    '_',
                    '-',
                ),
                ' ',
                (string) $key
            )
        );
    }


    /**
     * Render one associative data record as a PDF table.
     *
     * @param array $record Record data.
     *
     * @return string
     */
    private static function render_pdf_record_table(
        $record
    ) {

        $html =
            '<table>';

        foreach (
            $record
            as $field => $value
        ) {

            if (
                is_array(
                    $value
                )
                || is_object(
                    $value
                )
            ) {
                $value =
                    wp_json_encode(
                        $value,
                        JSON_UNESCAPED_SLASHES
                    );
            }

            if (
                is_bool(
                    $value
                )
            ) {
                $value =
                    $value
                        ? __(
                            'Yes',
                            'tutorhelper-bookings'
                        )
                        : __(
                            'No',
                            'tutorhelper-bookings'
                        );
            }

            if (
                null === $value
                || '' === $value
            ) {
                $value =
                    '—';
            }

            $html .=
                '<tr>
                    <th>'
                . esc_html(
                    self::humanise_key(
                        $field
                    )
                )
                . '</th>
                    <td>'
                . esc_html(
                    (string) $value
                )
                . '</td>
                </tr>';
        }

        $html .=
            '</table>';

        return $html;
    }




    /**
     * Build Core student export data.
     *
     * @param WP_User $student Student.
     *
     * @return array
     */
    private static function build_export(
        $student
    ) {

        $student_id =
            absint(
                $student->ID
            );

        $details =
            TutorHelper_Students::
                get_student_details(
                    $student
                );

        if (
            is_array( $details )
            && isset(
                $details['parent']
            )
            && is_array(
                $details['parent']
            )
        ) {
            unset(
                $details[
                    'parent'
                ][
                    'linked_parent'
                ]
            );
        }

        $bookings =
            self::prepare_booking_export(
                self::get_all_student_bookings(
                    $student_id
                )
            );

        return array(
            'exported_at' =>
                current_time(
                    'mysql'
                ),

            'student' =>
                $details,

            'bookings' =>
	            $bookings,
        );
    }


    /**
     * Prepare Core bookings for a human-readable data export.
     *
     * @param array $bookings Booking records.
     *
     * @return array
     */
    private static function prepare_booking_export(
        $bookings
    ) {

        $prepared = array();

        foreach (
            $bookings
            as $booking
        ) {

            if ( is_object( $booking ) ) {
                $booking =
                    get_object_vars(
                        $booking
                    );
            }

            if ( ! is_array( $booking ) ) {
                continue;
            }

            $booking_type_id =
                isset(
                    $booking[
                        'booking_type_id'
                    ]
                )
                    ? absint(
                        $booking[
                            'booking_type_id'
                        ]
                    )
                    : 0;

            $booking_type =
                $booking_type_id
                    ? TutorHelper_Booking_Types::
                        get_by_id(
                            $booking_type_id
                        )
                    : null;

            $currency =
                ! empty(
                    $booking['currency']
                )
                    ? strtoupper(
                        sanitize_text_field(
                            $booking[
                                'currency'
                            ]
                        )
                    )
                    : TutorHelper_Currency::
                        get_currency();

            $price_minor_units =
                isset(
                    $booking[
                        'price_minor_units'
                    ]
                )
                    ? absint(
                        $booking[
                            'price_minor_units'
                        ]
                    )
                    : 0;

            /*
            * Add useful human-readable fields.
            */
            $booking[
                'booking_type'
            ] =
                $booking_type
                && isset(
                    $booking_type->title
                )
                    ? $booking_type->title
                    : __(
                        'Unknown booking type',
                        'tutorhelper-bookings'
                    );

            $booking[
                'price'
            ] =
                TutorHelper_Currency::
                    format_minor_units(
                        $price_minor_units,
                        $currency
                    );

            /*
            * Remove the internal monetary representation.
            * The formatted price is much clearer in a
            * subject-access export.
            */
            unset(
                $booking[
                    'price_minor_units'
                ]
            );

            /*
            * Put the readable Booking Type beside its ID.
            */
            $booking =
                self::move_array_key_after(
                    $booking,
                    'booking_type',
                    'booking_type_id'
                );

            $booking =
                self::move_array_key_after(
                    $booking,
                    'price',
                    'booking_end'
                );

            $prepared[] =
                $booking;
        }

        return $prepared;
    }


    /**
     * Move one array key immediately after another.
     *
     * @param array  $data       Data.
     * @param string $move_key   Key to move.
     * @param string $after_key  Key to place it after.
     *
     * @return array
     */
    private static function move_array_key_after(
        $data,
        $move_key,
        $after_key
    ) {

        if (
            ! array_key_exists(
                $move_key,
                $data
            )
            || ! array_key_exists(
                $after_key,
                $data
            )
        ) {
            return $data;
        }

        $value =
            $data[
                $move_key
            ];

        unset(
            $data[
                $move_key
            ]
        );

        $result = array();

        foreach (
            $data
            as $key => $item
        ) {

            $result[
                $key
            ] =
                $item;

            if (
                $after_key
                === $key
            ) {
                $result[
                    $move_key
                ] =
                    $value;
            }
        }

        return $result;
    }


    /**
     * Delete TutorHelper data associated with a student.
     *
     * @return void
     */
    public static function handle_delete() {

        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to delete student data.',
                    'tutorhelper-bookings'
                )
            );
        }

        $student_id =
            isset(
                $_POST['student_user_id']
            )
                ? absint(
                    $_POST[
                        'student_user_id'
                    ]
                )
                : 0;

        if ( ! $student_id ) {
            wp_die(
                esc_html__(
                    'The student could not be found.',
                    'tutorhelper-bookings'
                )
            );
        }

        $deletion_mode =
            isset(
                $_POST['deletion_mode']
            )
            && ! is_array(
                $_POST['deletion_mode']
            )
                ? sanitize_key(
                    wp_unslash(
                        $_POST['deletion_mode']
                    )
                )
                : '';

        $allowed_modes =
            array(
                self::DELETE_MODE_ERASE,
                self::DELETE_MODE_FULL,
            );

        if (
            ! in_array(
                $deletion_mode,
                $allowed_modes,
                true
            )
        ) {
            wp_die(
                esc_html__(
                    'The requested student data deletion mode is invalid.',
                    'tutorhelper-bookings'
                )
            );
        }

        check_admin_referer(
            self::DELETE_ACTION
            . '_'
            . $student_id
        );

        $student =
            TutorHelper_Students::
                get_student(
                    $student_id
                );

        if ( ! $student ) {
            wp_die(
                esc_html__(
                    'The student could not be found.',
                    'tutorhelper-bookings'
                )
            );
        }

        /*
        * Give future add-ons a chance to remove their
        * student-specific records first.
        */
        do_action(
            'tutorhelper_before_student_data_delete',
            $student_id,
            $student,
            $deletion_mode
        );

        $result =
            self::delete_core_data(
                $student_id,
                $deletion_mode
            );

        if ( is_wp_error( $result ) ) {
            wp_die(
                esc_html(
                    $result->
                        get_error_message()
                )
            );
        }

        do_action(
            'tutorhelper_after_student_data_delete',
            $student_id,
            $student,
            $deletion_mode
        );

        $redirect =
            add_query_arg(
                array(
                    'page' =>
                        TutorHelper_Admin::
                            MENU_SLUG,

                    'tab' =>
                        'students',

                    'student_data_deleted' =>
                        $deletion_mode,
                ),
                admin_url(
                    'admin.php'
                )
            );

        wp_safe_redirect(
            $redirect
        );

        exit;
    }


    /**
     * Return all Core bookings belonging to a student.
     *
     * Export operations must not stop at the normal
     * administrative pagination limit.
     *
     * @param int $student_id Student user ID.
     *
     * @return array
     */
    private static function get_all_student_bookings(
        $student_id
    ) {

        $bookings = array();
        $page     = 1;

        do {

            $result =
                TutorHelper_Booking_Records::
                    query(
                        array(
                            'student_user_id' =>
                                absint(
                                    $student_id
                                ),

                            'time_scope' =>
                                'all',

                            'sort_order' =>
                                'date_asc',

                            'page' =>
                                $page,

                            'per_page' =>
                                100,
                        )
                    );

            $page_bookings =
                isset(
                    $result['bookings']
                )
                && is_array(
                    $result['bookings']
                )
                    ? $result['bookings']
                    : array();

            $bookings =
                array_merge(
                    $bookings,
                    $page_bookings
                );

            $total_pages =
                isset(
                    $result['total_pages']
                )
                    ? absint(
                        $result['total_pages']
                    )
                    : 0;

            $page++;

        } while (
            0 < $total_pages
            && $page <= $total_pages
        );

        return $bookings;
    }



    /**
     * Remove or anonymise Core data for a student.
     *
     * @param int    $student_id Student user ID.
     * @param string $mode       Deletion mode.
     *
     * @return true|WP_Error
     */
    private static function delete_core_data(
        $student_id,
        $mode
    ) {

        if (
            self::DELETE_MODE_FULL
            === $mode
        ) {
            return self::fully_delete_core_data(
                $student_id
            );
        }

        if (
            self::DELETE_MODE_ERASE
            === $mode
        ) {
            return self::erase_core_personal_data(
                $student_id
            );
        }

        return new WP_Error(
            'tutorhelper_student_delete_mode_invalid',
            __(
                'The requested student data deletion mode is invalid.',
                'tutorhelper-bookings'
            )
        );
    }


    /**
     * Permanently remove Core TutorHelper data.
     *
     * @param int $student_id Student user ID.
     *
     * @return true|WP_Error
     */
    private static function fully_delete_core_data(
        $student_id
    ) {

        global $wpdb;

        $student_id =
            absint(
                $student_id
            );

        $bookings_table =
            TutorHelper_Bookings_Database::
                get_table_name(
                    'bookings'
                );

        $audit_table =
            TutorHelper_Bookings_Database::
                get_table_name(
                    'student_audit'
                );

        $bookings_deleted =
            $wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit permanent privacy/data-management operation.
                $bookings_table,
                array(
                    'student_user_id' =>
                        $student_id,
                ),
                array(
                    '%d',
                )
            );

        if ( false === $bookings_deleted ) {
            return new WP_Error(
                'tutorhelper_student_bookings_delete_failed',
                __(
                    'The student booking records could not be deleted.',
                    'tutorhelper-bookings'
                )
            );
        }

        $audit_deleted =
            $wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit permanent privacy/data-management operation.
                $audit_table,
                array(
                    'student_user_id' =>
                        $student_id,
                ),
                array(
                    '%d',
                )
            );

        if ( false === $audit_deleted ) {
            return new WP_Error(
                'tutorhelper_student_audit_delete_failed',
                __(
                    'The student audit records could not be deleted.',
                    'tutorhelper-bookings'
                )
            );
        }

        self::delete_student_meta(
            $student_id
        );

        return true;
    }


    /**
     * Remove personal information while retaining anonymised
     * Core booking records.
     *
     * @param int $student_id Student user ID.
     *
     * @return true|WP_Error
     */
    private static function erase_core_personal_data(
        $student_id
    ) {

        global $wpdb;

        $student_id =
            absint(
                $student_id
            );

        $bookings_table =
            TutorHelper_Bookings_Database::
                get_table_name(
                    'bookings'
                );

        $audit_table =
            TutorHelper_Bookings_Database::
                get_table_name(
                    'student_audit'
                );

        $updated =
            $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit privacy-erasure operation.
                $bookings_table,
                array(
                    'student_user_id' =>
                        0,

                    'student_name' =>
                        __(
                            'Erased student',
                            'tutorhelper-bookings'
                        ),

                    'student_email' =>
                        '',

                    'location_details' =>
                        '',

                    'notes' =>
                        '',

                    'cancellation_reason' =>
                        '',
                ),
                array(
                    'student_user_id' =>
                        $student_id,
                ),
                array(
                    '%d',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                ),
                array(
                    '%d',
                )
            );

        if ( false === $updated ) {
            return new WP_Error(
                'tutorhelper_student_bookings_erase_failed',
                __(
                    'The student booking records could not be anonymised.',
                    'tutorhelper-bookings'
                )
            );
        }

        /*
        * Existing audit records may themselves contain old/new
        * personal values, so remove them.
        */
        $audit_deleted =
            $wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit permanent privacy/data-management operation.
                $audit_table,
                array(
                    'student_user_id' =>
                        $student_id,
                ),
                array(
                    '%d',
                )
            );

        if ( false === $audit_deleted ) {
            return new WP_Error(
                'tutorhelper_student_audit_erase_failed',
                __(
                    'The student audit records could not be erased.',
                    'tutorhelper-bookings'
                )
            );
        }

        self::delete_student_meta(
            $student_id
        );

        return true;
    }


    /**
     * Remove TutorHelper-managed student metadata.
     *
     * @param int $student_id Student user ID.
     *
     * @return void
     */
    private static function delete_student_meta(
        $student_id
    ) {

        $meta_keys =
            array(
                TutorHelper_Students::
                    META_BOOKING_BLOCKED,

                TutorHelper_Students::
                    META_BOOKING_BLOCKED_MESSAGE,

                TutorHelper_Students::
                    META_PARENT_USER_ID,

                TutorHelper_Students::
                    META_USE_LINKED_PARENT,

                TutorHelper_Students::
                    META_PARENT_NAME,

                TutorHelper_Students::
                    META_PARENT_EMAIL,

                TutorHelper_Students::
                    META_PARENT_PHONE,

                TutorHelper_Students::
                    META_STUDENT_PHONE,

                TutorHelper_Students::
                    META_ADDRESS_LINE_1,

                TutorHelper_Students::
                    META_ADDRESS_LINE_2,

                TutorHelper_Students::
                    META_ADDRESS_CITY,

                TutorHelper_Students::
                    META_ADDRESS_COUNTY,

                TutorHelper_Students::
                    META_ADDRESS_POSTCODE,

                TutorHelper_Students::
                    META_ADDRESS_COUNTRY,

                TutorHelper_Students::
                    META_DATE_OF_BIRTH,
            );

        foreach (
            $meta_keys
            as $meta_key
        ) {
            delete_user_meta(
                $student_id,
                $meta_key
            );
        }
    }



}
