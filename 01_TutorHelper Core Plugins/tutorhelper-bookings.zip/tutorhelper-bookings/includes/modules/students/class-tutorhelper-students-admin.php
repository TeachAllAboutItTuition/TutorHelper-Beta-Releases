<?php
/**
 * Student Management admin interface.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Connects Student Management to the Booking Hub.
 */
final class TutorHelper_Students_Admin {

	/**
	 * Booking Hub tab identifier.
	 *
	 * This matches the existing third tab in the Booking Hub.
	 *
	 * @var string
	 */
	const TAB_KEY = 'students';


    /**
     * Student-details save action.
     *
     * @var string
     */
    const SAVE_ACTION =
        'tutorhelper_save_student';

    /**
     * Password-reset email action.
     *
     * @var string
     */
    const RESET_EMAIL_ACTION =
        'tutorhelper_send_student_password_reset';

    /**
     * Manual password action.
     *
     * @var string
     */
    const PASSWORD_ACTION =
        'tutorhelper_set_student_password';


     /**
     * AJAX action used to search Parent Account candidates.
     *
     * @var string
     */
    const PARENT_SEARCH_ACTION = 'tutorhelper_search_parent_accounts';


	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter(
			'tutorhelper_booking_hub_tabs',
			array( __CLASS__, 'enable_students_tab' )
		);

		add_action(
			'tutorhelper_booking_hub_render_tab',
			array( __CLASS__, 'render_hub_tab' ),
			10,
			2
		);

        add_action(
            'admin_post_' . self::SAVE_ACTION,
            array( __CLASS__, 'handle_save_student' )
        );

        add_action(
            'admin_post_' . self::RESET_EMAIL_ACTION,
            array( __CLASS__, 'handle_send_password_reset' )
        );

        add_action(
            'admin_post_' . self::PASSWORD_ACTION,
            array( __CLASS__, 'handle_set_password' )
        );

        add_action(
            'wp_ajax_' . self::PARENT_SEARCH_ACTION,
            array( __CLASS__, 'handle_parent_account_search' )
        );

        add_filter(
            'wp_redirect',
            array( __CLASS__, 'capture_async_student_detail_redirect' ),
            10,
            2
        );


	}

	/**
	 * Return a JSON result when a Student Detail form requests an in-place save.
	 *
	 * The form's normal admin-post handler still performs its own capability,
	 * nonce, validation and persistence checks. This filter only replaces the
	 * final redirect after that handler has completed.
	 *
	 * @param string $location Redirect destination.
	 * @param int    $status   Redirect status.
	 *
	 * @return string
	 */
	public static function capture_async_student_detail_redirect(
		$location,
		$status
	) {
		unset( $status );

		$is_async = isset( $_POST['tutorhelper_student_detail_async'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The destination handler verifies its own action nonce before redirecting.
			&& ! is_array( $_POST['tutorhelper_student_detail_async'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			&& '1' === sanitize_text_field( wp_unslash( $_POST['tutorhelper_student_detail_async'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! $is_async ) {
			return $location;
		}

		$query = wp_parse_url( $location, PHP_URL_QUERY );
		$args  = array();

		if ( is_string( $query ) ) {
			parse_str( $query, $args );
		}

		$notice = '';
		foreach ( $args as $key => $value ) {
			if (
				is_scalar( $value )
				&& false !== strpos( sanitize_key( $key ), 'notice' )
			) {
				$notice = sanitize_key( (string) $value );
				break;
			}
		}

		$data = array(
			'location' => esc_url_raw( $location ),
			'notice'   => $notice,
		);

		if ( '' === $notice || 'saved' === $notice ) {
			wp_send_json_success( $data );
		}

		wp_send_json_error( $data, 422 );

		return $location;
	}


	/**
	 * Make the existing Students tab available.
	 *
	 * The tab has already been created by the Booking Hub. This module
	 * changes only its status and keeps its existing third position.
	 *
	 * @param array $tabs Booking Hub tab definitions.
	 *
	 * @return array
	 */
	public static function enable_students_tab( $tabs ) {
		if (
			! is_array( $tabs )
			|| ! isset( $tabs[ self::TAB_KEY ] )
		) {
			return $tabs;
		}

		$tabs[ self::TAB_KEY ]['status'] =
			'available';

		$tabs[ self::TAB_KEY ]['description'] =
			__(
				'Manage student accounts, parent details and booking access.',
				'tutorhelper-bookings'
			);

		return $tabs;
	}

	/**
	 * Render Student Management inside the Students Hub tab.
	 *
	 * @param string $selected_tab Selected Booking Hub tab.
	 * @param array  $active_tab   Active tab definition.
	 *
	 * @return void
	 */
	public static function render_hub_tab(
		$selected_tab,
		$active_tab
	) {
		if ( self::TAB_KEY !== $selected_tab ) {
			return;
		}

		if (
			! current_user_can(
				TutorHelper_Admin::CAPABILITY
			)
		) {
			return;
		}

		self::render_workspace( $active_tab );
	}

	/**
	 * Render the initial Student Management workspace.
	 *
	 * @param array $active_tab Active Booking Hub tab definition.
	 *
	 * @return void
	 */
	private static function render_workspace(
		$active_tab
	) {
		$tab_label = isset( $active_tab['label'] )
			? $active_tab['label']
			: __(
				'Students',
				'tutorhelper-bookings'
			);

        $student_user_id = isset(
            $_GET['student_id'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
        )
            ? absint( $_GET['student_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
            : 0;

        $student = $student_user_id
            ? TutorHelper_Students::get_student(
                $student_user_id
            )
            : null;

        $has_custom_workspace =
            (bool) apply_filters(
                'tutorhelper_students_has_custom_workspace',
                false,
                $active_tab
            );

        if ( $has_custom_workspace ) {
            do_action(
                'tutorhelper_students_render_custom_workspace',
                $active_tab
            );

            return;
        }


		?>
		<section class="tutorhelper-students-workspace">
            
                <header class="tutorhelper-workspace__header">
                    <div>
                        <h2>
                            <?php echo esc_html( $tab_label ); ?>
                        </h2>

                        <p>
                            <?php
                            echo esc_html__(
                                'Manage WordPress student accounts, parent details and booking permissions.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>
                    </div>
                </header>


			<div class="tutorhelper-students-workspace__grid <?php echo $student_user_id
                ? 'is-detail-view'
                : ''; ?>">
				<main class="tutorhelper-students-workspace__main">
                    <?php
                    if ( $student_user_id && $student ) {
                        self::render_student_detail_shell(
                            $student
                        );
                    } elseif ( $student_user_id ) {
                        self::render_student_not_found();
                    } else {
                        self::render_student_list();
                    }
                    ?>
                </main>

                <?php if ( ! $student_user_id ) : ?>

                    <aside class="tutorhelper-students-workspace__sidebar">
                        <?php
                        if (
                            has_action(
                                'tutorhelper_students_registration_sidebar'
                            )
                        ) {
                            do_action(
                                'tutorhelper_students_registration_sidebar'
                            );
                        } else {
                            self::render_pro_feature(
                                __(
                                    'Student Registrations',
                                    'tutorhelper-bookings'
                                ),
                                __(
                                    'Review new registrations and onboarding answers with TutorHelper Bookings Pro.',
                                    'tutorhelper-bookings'
                                ),
                                'dashicons-id'
                            );
                        }
                        ?>
                    </aside>
                <?php endif; ?>
			</div>
		</section>
		<?php
	}

	/**
     * Render the searchable Student Accounts list.
     *
     * @return void
     */
    private static function render_student_list() {
        $search = isset( $_GET['student_search'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
            ? sanitize_text_field(
                wp_unslash(
                    $_GET['student_search'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
                )
            )
            : '';

        $page = isset( $_GET['student_page'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
            ? max(
                1,
                absint( $_GET['student_page'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
            )
            : 1;

        $booking_access = isset( $_GET['student_booking_access'] ) && ! is_array( $_GET['student_booking_access'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            ? sanitize_key( wp_unslash( $_GET['student_booking_access'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            : '';

        if ( ! in_array( $booking_access, array( '', 'allowed', 'blocked' ), true ) ) {
            $booking_access = '';
        }

        $account_created_from = isset( $_GET['student_created_from'] ) && ! is_array( $_GET['student_created_from'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            ? sanitize_text_field( wp_unslash( $_GET['student_created_from'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            : '';

        $account_created_to = isset( $_GET['student_created_to'] ) && ! is_array( $_GET['student_created_to'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            ? sanitize_text_field( wp_unslash( $_GET['student_created_to'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            : '';

        $last_login = isset( $_GET['student_last_login'] ) && ! is_array( $_GET['student_last_login'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            ? sanitize_key( wp_unslash( $_GET['student_last_login'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            : '';

        if ( ! in_array( $last_login, array( '', 'logged_in', 'never' ), true ) ) {
            $last_login = '';
        }

        $parent_link = isset( $_GET['student_parent_link'] ) && ! is_array( $_GET['student_parent_link'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            ? sanitize_key( wp_unslash( $_GET['student_parent_link'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter state.
            : '';

        if ( ! in_array( $parent_link, array( '', 'missing' ), true ) ) {
            $parent_link = '';
        }

        $orderby = isset( $_GET['student_orderby'] ) && ! is_array( $_GET['student_orderby'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only sorting state.
            ? sanitize_key( wp_unslash( $_GET['student_orderby'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only sorting state.
            : 'display_name';

        if ( ! in_array( $orderby, array( 'display_name', 'registered', 'last_login' ), true ) ) {
            $orderby = 'display_name';
        }

        $order = isset( $_GET['student_order'] ) && ! is_array( $_GET['student_order'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only sorting state.
            ? strtoupper( sanitize_key( wp_unslash( $_GET['student_order'] ) ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only sorting state.
            : 'ASC';

        $order = 'DESC' === $order ? 'DESC' : 'ASC';

        $filters = array(
            'search'               => $search,
            'booking_access'       => $booking_access,
            'account_created_from' => $account_created_from,
            'account_created_to'   => $account_created_to,
            'last_login'           => $last_login,
            'parent_link'          => $parent_link,
            'orderby'              => $orderby,
            'order'                => $order,
        );

        $result = TutorHelper_Students::get_students(
            array_merge(
                $filters,
                array(
                    'page'     => $page,
                    'per_page' => 20,
                )
            )
        );

        ?>
        <section class="tutorhelper-main-section tutorhelper-students-panel">
            <header class="tutorhelper-main-section__header">
                <div class="tutorhelper-main-section__header-content">
                    <h2>
                        <?php
                        echo esc_html__(
                            'Student Accounts',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </h2>

                    <p>
                        <?php
                        printf(
                            esc_html(
                                /* translators: %d: Student account count. */
                                _n(
                                    '%d TH Student account',
                                    '%d TH Student accounts',
                                    $result['total'],
                                    'tutorhelper-bookings'
                                )
                            ),
                            absint( $result['total'] )
                        );
                        ?>
                    </p>
                </div>
            </header>

            <div class="tutorhelper-main-section__body">

            <?php
            self::render_student_search_form(
                $filters
            );
            ?>

            <?php if ( empty( $result['students'] ) ) : ?>
                <?php
                self::render_student_empty_state(
                    $filters
                );
                ?>
            <?php else : ?>
                <?php
                self::render_student_table(
                    $result['students'],
                    $filters
                );

                self::render_student_pagination(
                    $result,
                    $filters
                );
                ?>
            <?php endif; ?>
        	</div>
        </section>
        <?php
    }

    /**
     * Render the student search form.
     *
     * @param string $search Current search term.
     *
     * @return void
     */
    private static function render_student_search_form(
        $filters
    ) {
        $has_filters = '' !== $filters['search']
            || '' !== $filters['booking_access']
            || '' !== $filters['account_created_from']
            || '' !== $filters['account_created_to']
            || '' !== $filters['last_login']
            || '' !== $filters['parent_link'];

        ?>
        <form
            method="get"
            action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>"
            class="tutorhelper-student-search"
        >
            <input type="hidden" name="page" value="<?php echo esc_attr( TutorHelper_Booking_Hub::PAGE_SLUG ); ?>" />
            <input type="hidden" name="tab" value="<?php echo esc_attr( self::TAB_KEY ); ?>" />

            <div class="tutorhelper-input-field tutorhelper-student-search__field">
                <label for="tutorhelper-student-search">
                    <?php echo esc_html__( 'Student', 'tutorhelper-bookings' ); ?>
                </label>
                <input
                    type="search"
                    id="tutorhelper-student-search"
                    name="student_search"
                    value="<?php echo esc_attr( $filters['search'] ); ?>"
                    placeholder="<?php echo esc_attr__( 'Name, username or email', 'tutorhelper-bookings' ); ?>"
                />
            </div>

            <div class="tutorhelper-input-field">
                <label for="tutorhelper-student-booking-access">
                    <?php echo esc_html__( 'Booking access', 'tutorhelper-bookings' ); ?>
                </label>
                <select id="tutorhelper-student-booking-access" name="student_booking_access">
                    <option value=""><?php echo esc_html__( 'All access', 'tutorhelper-bookings' ); ?></option>
                    <option value="allowed" <?php selected( $filters['booking_access'], 'allowed' ); ?>>
                        <?php echo esc_html__( 'Allowed', 'tutorhelper-bookings' ); ?>
                    </option>
                    <option value="blocked" <?php selected( $filters['booking_access'], 'blocked' ); ?>>
                        <?php echo esc_html__( 'Blocked', 'tutorhelper-bookings' ); ?>
                    </option>
                </select>
            </div>

            <div class="tutorhelper-input-field">
                <label for="tutorhelper-student-created-from">
                    <?php echo esc_html__( 'Created from', 'tutorhelper-bookings' ); ?>
                </label>
                <input
                    type="date"
                    id="tutorhelper-student-created-from"
                    name="student_created_from"
                    value="<?php echo esc_attr( $filters['account_created_from'] ); ?>"
                />
            </div>

            <div class="tutorhelper-input-field">
                <label for="tutorhelper-student-created-to">
                    <?php echo esc_html__( 'Created to', 'tutorhelper-bookings' ); ?>
                </label>
                <input
                    type="date"
                    id="tutorhelper-student-created-to"
                    name="student_created_to"
                    value="<?php echo esc_attr( $filters['account_created_to'] ); ?>"
                />
            </div>

            <div class="tutorhelper-input-field">
                <label for="tutorhelper-student-last-login">
                    <?php echo esc_html__( 'Last login', 'tutorhelper-bookings' ); ?>
                </label>
                <select id="tutorhelper-student-last-login" name="student_last_login">
                    <option value=""><?php echo esc_html__( 'All students', 'tutorhelper-bookings' ); ?></option>
                    <option value="logged_in" <?php selected( $filters['last_login'], 'logged_in' ); ?>>
                        <?php echo esc_html__( 'Has logged in', 'tutorhelper-bookings' ); ?>
                    </option>
                    <option value="never" <?php selected( $filters['last_login'], 'never' ); ?>>
                        <?php echo esc_html__( 'Never logged in', 'tutorhelper-bookings' ); ?>
                    </option>
                </select>
            </div>

            <div class="tutorhelper-input-field">
                <label for="tutorhelper-student-parent-link">
                    <?php echo esc_html__( 'Parent link', 'tutorhelper-bookings' ); ?>
                </label>
                <select id="tutorhelper-student-parent-link" name="student_parent_link">
                    <option value=""><?php echo esc_html__( 'All students', 'tutorhelper-bookings' ); ?></option>
                    <option value="missing" <?php selected( $filters['parent_link'], 'missing' ); ?>>
                        <?php echo esc_html__( 'No linked parent', 'tutorhelper-bookings' ); ?>
                    </option>
                </select>
            </div>

            <button type="submit" class="button tutorhelper-action-button">
                <span class="dashicons dashicons-filter" aria-hidden="true"></span>
                <?php echo esc_html__( 'Apply filters', 'tutorhelper-bookings' ); ?>
            </button>

            <?php if ( $has_filters ) : ?>
                <a class="button tutorhelper-hub-pill-button" href="<?php echo esc_url( self::get_students_url() ); ?>">
                    <span class="dashicons dashicons-dismiss" aria-hidden="true"></span>
                    <?php echo esc_html__( 'Clear filters', 'tutorhelper-bookings' ); ?>
                </a>
            <?php endif; ?>
        </form>
        <?php
    }

    /**
     * Render the student list table.
     *
     * @param array $students Student WP_User objects.
     *
     * @return void
     */
    private static function render_student_table(
        $students,
        $filters
    ) {
        ?>
        <div class="tutorhelper-student-table-wrap">
            <table class="widefat striped tutorhelper-student-table">
                <thead>
                    <tr>
                        <th scope="col"><?php echo esc_html__( 'Student', 'tutorhelper-bookings' ); ?></th>
                        <th scope="col"><?php echo esc_html__( 'Parent / Guardian', 'tutorhelper-bookings' ); ?></th>
                        <th scope="col">
                            <?php self::render_sortable_heading( __( 'Account created', 'tutorhelper-bookings' ), 'registered', $filters ); ?>
                        </th>
                        <th scope="col">
                            <?php self::render_sortable_heading( __( 'Last login', 'tutorhelper-bookings' ), 'last_login', $filters ); ?>
                        </th>
                        <th scope="col"><?php echo esc_html__( 'Booking access', 'tutorhelper-bookings' ); ?></th>
                        <th scope="col"><span class="screen-reader-text"><?php echo esc_html__( 'Actions', 'tutorhelper-bookings' ); ?></span></th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ( $students as $student ) : ?>
                        <?php self::render_student_row( $student ); ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Render a sortable Student table heading.
     *
     * @param string $label   Visible label.
     * @param string $orderby Sort key.
     * @param array  $filters Current filters.
     *
     * @return void
     */
    private static function render_sortable_heading(
        $label,
        $orderby,
        $filters
    ) {
        $is_current = $orderby === $filters['orderby'];
        $next_order = $is_current && 'ASC' === $filters['order']
            ? 'DESC'
            : 'ASC';

        $url = self::get_students_url(
            array(
                'student_search'         => $filters['search'],
                'student_booking_access' => $filters['booking_access'],
                'student_created_from'   => $filters['account_created_from'],
                'student_created_to'     => $filters['account_created_to'],
                'student_last_login'     => $filters['last_login'],
                'student_parent_link'    => $filters['parent_link'],
                'student_orderby'        => $orderby,
                'student_order'          => $next_order,
            )
        );

        ?>
        <a href="<?php echo esc_url( $url ); ?>">
            <?php echo esc_html( $label ); ?>
            <?php if ( $is_current ) : ?>
                <span aria-hidden="true"><?php echo 'ASC' === $filters['order'] ? '↑' : '↓'; ?></span>
                <span class="screen-reader-text">
                    <?php echo esc_html( 'ASC' === $filters['order'] ? __( 'sorted ascending', 'tutorhelper-bookings' ) : __( 'sorted descending', 'tutorhelper-bookings' ) ); ?>
                </span>
            <?php endif; ?>
        </a>
        <?php
    }

    /**
     * Render one student table row.
     *
     * @param WP_User $student Student user.
     *
     * @return void
     */
    private static function render_student_row(
        $student
    ) {
        $parent = TutorHelper_Students::get_parent_summary(
            $student->ID
        );

        $is_blocked =
            TutorHelper_Students::is_booking_blocked(
                $student->ID
            );

        ?>
        <tr>
            <td data-label="<?php echo esc_attr__(
                'Student',
                'tutorhelper-bookings'
            ); ?>">
                <div class="tutorhelper-student-identity">
                    <?php
                    echo get_avatar(
                        $student->ID,
                        40,
                        '',
                        $student->display_name
                    );
                    ?>

                    <div>
                        <strong>
                            <?php
                            echo esc_html(
                                $student->display_name
                            );
                            ?>
                        </strong>

                        <a href="mailto:<?php echo esc_attr(
                            $student->user_email
                        ); ?>">
                            <?php
                            echo esc_html(
                                $student->user_email
                            );
                            ?>
                        </a>

                        <small>
                            <?php
                            printf(
                                /* translators: %s: WordPress username. */
                                esc_html__(
                                    'Username: %s',
                                    'tutorhelper-bookings'
                                ),
                                esc_html(
                                    $student->user_login
                                )
                            );
                            ?>
                        </small>
                    </div>
                </div>
            </td>

            <td data-label="<?php echo esc_attr__(
                'Parent / Guardian',
                'tutorhelper-bookings'
            ); ?>">
                <?php if ( $parent['name'] || $parent['email'] ) : ?>
                    <strong>
                        <?php
                        echo esc_html(
                            $parent['name']
                                ? $parent['name']
                                : __(
                                    'Name not provided',
                                    'tutorhelper-bookings'
                                )
                        );
                        ?>
                    </strong>

                    <?php if ( $parent['email'] ) : ?>
                        <a href="mailto:<?php echo esc_attr(
                            $parent['email']
                        ); ?>">
                            <?php
                            echo esc_html(
                                $parent['email']
                            );
                            ?>
                        </a>
                    <?php endif; ?>
                <?php else : ?>
                    <span class="tutorhelper-student-muted">
                        <?php
                        echo esc_html__(
                            'Not provided',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </span>
                <?php endif; ?>
            </td>

            <td data-label="<?php echo esc_attr__(
                'Account created',
                'tutorhelper-bookings'
            ); ?>">
                <?php
                echo esc_html(
                    get_date_from_gmt(
                        $student->user_registered,
                        get_option( 'date_format' )
                    )
                );
                ?>
            </td>

            <td data-label="<?php echo esc_attr__(
                'Last login',
                'tutorhelper-bookings'
            ); ?>">
                <?php
                $last_login = get_user_meta(
                    $student->ID,
                    TutorHelper_Students::META_LAST_LOGIN,
                    true
                );

                echo esc_html(
                    $last_login
                        ? get_date_from_gmt(
                            $last_login,
                            get_option( 'date_format' ) . ' ' . get_option( 'time_format' )
                        )
                        : __( 'Never', 'tutorhelper-bookings' )
                );
                ?>
            </td>

            <td data-label="<?php echo esc_attr__(
                'Booking access',
                'tutorhelper-bookings'
            ); ?>">
                <span class="tutorhelper-student-status <?php echo $is_blocked
                    ? 'is-blocked'
                    : 'is-allowed'; ?>">
                    <?php
                    echo esc_html(
                        $is_blocked
                            ? __(
                                'Blocked',
                                'tutorhelper-bookings'
                            )
                            : __(
                                'Allowed',
                                'tutorhelper-bookings'
                            )
                    );
                    ?>
                </span>
            </td>

            <td class="tutorhelper-student-table__actions">
                <a
                    class="tutorhelper-hub-pill-button-small"
                    href="<?php echo esc_url(
                        self::get_student_url(
                            $student->ID
                        )
                    ); ?>"
                >
                    <?php
                    echo esc_html__(
                        'Open student',
                        'tutorhelper-bookings'
                    );
                    ?>
                </a>
            </td>
        </tr>
        <?php
    }

    /**
     * Render student-list pagination.
     *
	 * @param array $result  Student query result.
	 * @param array $filters Current student filters.
     *
     * @return void
     */
    private static function render_student_pagination(
        $result,
        $filters
    ) {
        if ( $result['total_pages'] <= 1 ) {
            return;
        }

        $links = paginate_links(
            array(
                'base'      => add_query_arg(
                    array(
                        'page'                   => TutorHelper_Booking_Hub::PAGE_SLUG,
                        'tab'                    => self::TAB_KEY,
                        'student_search'         => $filters['search'],
                        'student_booking_access' => $filters['booking_access'],
                        'student_created_from'   => $filters['account_created_from'],
                        'student_created_to'     => $filters['account_created_to'],
                        'student_last_login'     => $filters['last_login'],
                'student_parent_link'    => $filters['parent_link'],
                        'student_orderby'        => $filters['orderby'],
                        'student_order'          => $filters['order'],
                        'student_page'           => '%#%',
                    ),
                    admin_url( 'admin.php' )
                ),
                'format'    => '',
                'current'   => absint( $result['page'] ),
                'total'     => absint( $result['total_pages'] ),
                'prev_text' => __( '‹ Previous', 'tutorhelper-bookings' ),
                'next_text' => __( 'Next ›', 'tutorhelper-bookings' ),
            )
        );

        if ( ! $links ) {
            return;
        }

        ?>
        <div class="tutorhelper-student-pagination">
            <div class="tutorhelper-student-pagination__count">
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: %d: total number of student accounts. */
                        _n(
                            '%d student',
                            '%d students',
                            absint( $result['total'] ),
                            'tutorhelper-bookings'
                        ),
                        absint( $result['total'] )
                    )
                );
                ?>
            </div>
            <nav class="tutorhelper-student-pagination__links" aria-label="<?php echo esc_attr__( 'Student account pages', 'tutorhelper-bookings' ); ?>">
                <?php echo wp_kses_post( $links ); ?>
            </nav>
        </div>
        <?php
    }

    /**
     * Render the student-list empty state.
     *
     * @param string $search Current search term.
     *
     * @return void
     */
    private static function render_student_empty_state(
        $filters
    ) {
        $is_filtered = '' !== $filters['search']
            || '' !== $filters['booking_access']
            || '' !== $filters['account_created_from']
            || '' !== $filters['account_created_to']
            || '' !== $filters['last_login']
            || '' !== $filters['parent_link'];

        ?>
        <div class="tutorhelper-students-empty">
            <span class="dashicons dashicons-groups" aria-hidden="true"></span>
            <h3>
                <?php echo esc_html( $is_filtered ? __( 'No matching students', 'tutorhelper-bookings' ) : __( 'No TH Student accounts', 'tutorhelper-bookings' ) ); ?>
            </h3>
            <p>
                <?php echo esc_html( $is_filtered ? __( 'Try adjusting or clearing the student filters.', 'tutorhelper-bookings' ) : __( 'Assign the TH Student role to a WordPress user to show them here.', 'tutorhelper-bookings' ) ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Render an invalid-student message.
     *
     * @return void
     */
    private static function render_student_not_found() {
        ?>
        <section class="tutorhelper-students-panel">
            <div class="tutorhelper-students-empty">
                <span
                    class="dashicons dashicons-warning"
                    aria-hidden="true"
                ></span>

                <h3>
                    <?php
                    echo esc_html__(
                        'Student not found',
                        'tutorhelper-bookings'
                    );
                    ?>
                </h3>

                <p>
                    <?php
                    echo esc_html__(
                        'The requested user does not exist or is not assigned the TH Student role.',
                        'tutorhelper-bookings'
                    );
                    ?>
                </p>

                <a
                    class="button"
                    href="<?php echo esc_url(
                        self::get_students_url()
                    ); ?>"
                >
                    <?php
                    echo esc_html__(
                        'Return to students',
                        'tutorhelper-bookings'
                    );
                    ?>
                </a>
            </div>
        </section>
        <?php
    }



    /**
     * Render the complete student detail view.
     *
     * Tutors can switch between a read-only account view and the
     * editable account form.
     *
     * @param WP_User $student Student user.
     *
     * @return void
     */
    private static function render_student_detail_shell(
        $student
    ) {
        $details = TutorHelper_Students::get_student_details(
            $student
        );

        if ( ! is_array( $details ) ) {
            self::render_student_not_found();

            return;
        }

        $student_mode = isset(
            $_GET['student_mode'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
        )
            ? sanitize_key(
                wp_unslash(
                    $_GET['student_mode'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
                )
            )
            : 'view';

        $is_editing = 'edit' === $student_mode;

        $view_url = self::get_student_url(
            $details['id'],
            array(
                'student_mode' => 'view',
            )
        );

        $edit_url = self::get_student_url(
            $details['id'],
            array(
                'student_mode' => 'edit',
            )
        );

        ?>
        <section class="tutorhelper-student-detail">
            <header class="tutorhelper-student-detail__header">
                <div class="tutorhelper-student-detail__identity">
                    <?php
                    echo get_avatar(
                        $details['id'],
                        64,
                        '',
                        $details['student_name']
                    );
                    ?>

                    <div>
                        <h2>
                            <?php
                            echo esc_html(
                                $details['student_name']
                            );
                            ?>
                        </h2>

                        <a
                            href="mailto:<?php echo esc_attr(
                                $details['email']
                            ); ?>"
                        >
                            <?php
                            echo esc_html(
                                $details['email']
                            );
                            ?>
                        </a>
                    </div>
                </div>

                <div class="tutorhelper-student-detail__header-actions">
                    <div
                        class="tutorhelper-booking-hub__view-switcher"
                        aria-label="<?php echo esc_attr__(
                            'Student detail mode',
                            'tutorhelper-bookings'
                        ); ?>"
                    >
                        <a
                            class="button <?php echo ! $is_editing
                                ? 'button-primary'
                                : ''; ?>"
                            href="<?php echo esc_url(
                                $view_url
                            ); ?>"
                            <?php echo ! $is_editing
                                ? 'aria-current="page"'
                                : ''; ?>
                        >
                            <span
                                class="dashicons dashicons-visibility"
                                aria-hidden="true"
                            ></span>

                            <?php
                            echo esc_html__(
                                'View',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </a>

                        <a
                            class="button <?php echo $is_editing
                                ? 'button-primary'
                                : ''; ?>"
                            href="<?php echo esc_url(
                                $edit_url
                            ); ?>"
                            <?php echo $is_editing
                                ? 'aria-current="page"'
                                : ''; ?>
                        >
                            <span
                                class="dashicons dashicons-edit"
                                aria-hidden="true"
                            ></span>

                            <?php
                            echo esc_html__(
                                'Edit',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </a>
                    </div>

                    <a
                        class="button tutorhelper-hub-pill-button"
                        href="<?php echo esc_url(
                            self::get_students_url()
                        ); ?>"
                    >
                        <span aria-hidden="true">&larr;</span>

                        <?php
                        echo esc_html__(
                            'Back to students',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </a>
                </div>
            </header>

            <div class="tutorhelper-student-detail__body">
                <?php
                self::render_student_notice();
                ?>

                <?php if ( $is_editing ) : ?>
                    <?php
                    self::render_student_edit_form(
                        $details,
                        $view_url
                    );
                    ?>
                    <div class="tutorhelper-student-detail__account-tools">
                        <?php
                        self::render_password_management( $details );
                        self::render_student_account_extensions( $student );
                        ?>
                    </div>
                <?php else : ?>
                    <div class="tutorhelper-student-detail__account-layout">
                        <div class="tutorhelper-student-detail__account-main">
                            <div class="tutorhelper-student-detail__columns">
                                <?php
                                self::render_student_account_details(
                                    $details,
                                    false
                                );

                                self::render_parent_details(
                                    $details,
                                    false
                                );
                                ?>
                            </div>
                        </div>

                        <aside
                            class="tutorhelper-student-detail__account-sidebar"
                            aria-label="<?php echo esc_attr__(
                                'Student account tools',
                                'tutorhelper-bookings'
                            ); ?>"
                        >
                            <?php
                            self::render_booking_access_details(
                                $details,
                                false
                            );
                            self::render_password_management( $details );
                            self::render_student_account_extensions( $student );
                            ?>
                        </aside>
                    </div>
                <?php endif; ?>

                <?php self::render_student_detail_sections( $student ); ?>
            </div>
        </section>
        <?php
    }


    /**
     * Render account-level extensions beside the student's core details.
     *
     * Add-ons should use this location for concise account relationships or
     * access summaries, rather than adding another full-width panel.
     *
     * @param WP_User $student Student user.
     * @return void
     */
    private static function render_student_account_extensions( $student ) {
        /**
         * Render student account sidebar extensions.
         *
         * @param WP_User $student Student user.
         */
        do_action(
            'tutorhelper_students_render_account_sidebar',
            $student
        );
    }


    /**
     * Render the ordered, extensible Student Detail disclosures.
     *
     * Add-ons may amend the definitions through the filter or render content
     * into any registered section's action. New sections require a unique ID,
     * translated title and description, Dashicon, priority and action name.
     *
     * @param WP_User $student Student user.
     * @return void
     */
    private static function render_student_detail_sections( $student ) {
        $sections = array(
            array(
                'id'          => 'notes-communication',
                'title'       => __( 'Student Notes & Communication', 'tutorhelper-bookings' ),
                'description' => __( 'Review onboarding, private notes and communication history.', 'tutorhelper-bookings' ),
                'icon'        => 'dashicons-format-chat',
                'priority'    => 10,
                'action'      => 'tutorhelper_students_detail_notes_communication',
            ),
            array(
                'id'          => 'lesson-history',
                'title'       => __( 'Lesson History', 'tutorhelper-bookings' ),
                'description' => __( 'Review lessons, attendance, feedback and homework.', 'tutorhelper-bookings' ),
                'icon'        => 'dashicons-welcome-learn-more',
                'priority'    => 20,
                'action'      => 'tutorhelper_students_detail_lesson_history',
            ),
            array(
                'id'          => 'lesson-options-pricing',
                'title'       => __( 'Lesson Options & Pricing', 'tutorhelper-bookings' ),
                'description' => __( 'Manage booking changes, pricing, payments, visibility and credit.', 'tutorhelper-bookings' ),
                'icon'        => 'dashicons-money-alt',
                'priority'    => 30,
                'action'      => 'tutorhelper_students_detail_lesson_options_pricing',
            ),
            array(
                'id'          => 'data-export',
                'title'       => __( 'Data Export', 'tutorhelper-bookings' ),
                'description' => __( 'Review privacy information and export the student’s data.', 'tutorhelper-bookings' ),
                'icon'        => 'dashicons-download',
                'priority'    => 40,
                'action'      => 'tutorhelper_students_detail_data_export',
            ),
        );

        /**
         * Filter the labels describing data supplied by installed add-ons.
         *
         * Add-ons should append a short, translated label such as
         * "Student groups". The labels are shown in the Additional
         * Information section summary.
         *
         * @param array   $items   Add-on data labels.
         * @param WP_User $student Student user.
         */
        $additional_items = apply_filters(
            'tutorhelper_students_detail_additional_information_items',
            array(),
            $student
        );

        if ( ! is_array( $additional_items ) ) {
            $additional_items = array();
        }

        $additional_items = array_values(
            array_filter(
                array_map(
                    'sanitize_text_field',
                    $additional_items
                )
            )
        );

        if ( has_action( 'tutorhelper_students_render_extensions' ) ) {
            $description = $additional_items
                ? implode( ', ', $additional_items )
                : __( 'Additional student information', 'tutorhelper-bookings' );

            $sections[] = array(
                'id'          => 'additional-information',
                'title'       => __( 'Additional Information', 'tutorhelper-bookings' ),
                'description' => $description,
                'icon'        => 'dashicons-admin-plugins',
                'priority'    => 90,
                'action'      => 'tutorhelper_students_render_extensions',
            );
        }

        /**
         * Filter Student Detail disclosure sections.
         *
         * @param array   $sections Ordered section definitions.
         * @param WP_User $student  Student user.
         */
        $sections = apply_filters(
            'tutorhelper_students_detail_sections',
            $sections,
            $student
        );

        if ( ! is_array( $sections ) ) {
            return;
        }

        usort(
            $sections,
            static function ( $first, $second ) {
                return absint( $first['priority'] ?? 100 )
                    <=> absint( $second['priority'] ?? 100 );
            }
        );

        echo '<div class="tutorhelper-student-detail__sections">';

        foreach ( $sections as $section ) {
            if (
                ! is_array( $section )
                || empty( $section['id'] )
                || empty( $section['title'] )
                || empty( $section['action'] )
            ) {
                continue;
            }

            $section_id = sanitize_key( $section['id'] );
            $action     = sanitize_key( $section['action'] );
            $icon       = ! empty( $section['icon'] )
                ? sanitize_html_class( $section['icon'] )
                : 'dashicons-admin-generic';
            ?>
            <details
                id="tutorhelper-student-section-<?php echo esc_attr( $section_id ); ?>"
                class="tutorhelper-student-detail-section tutorhelper-student-detail-section--<?php echo esc_attr( $section_id ); ?> tutorhelper-student-accordion"
                data-save-success="<?php echo esc_attr__( 'Settings saved.', 'tutorhelper-bookings' ); ?>"
                data-save-error="<?php echo esc_attr__( 'The settings could not be saved. Please try again.', 'tutorhelper-bookings' ); ?>"
                data-filter-error="<?php echo esc_attr__( 'The filters could not be applied. Please try again.', 'tutorhelper-bookings' ); ?>"
                data-dismiss-label="<?php echo esc_attr__( 'Dismiss this notice.', 'tutorhelper-bookings' ); ?>"
            >
                <summary class="tutorhelper-student-accordion__summary">
                    <span
                        class="dashicons <?php echo esc_attr( $icon ); ?>"
                        aria-hidden="true"
                    ></span>
                    <span class="tutorhelper-student-accordion__title">
                        <strong><?php echo esc_html( $section['title'] ); ?></strong>
                        <?php if ( ! empty( $section['description'] ) ) : ?>
                            <small><?php echo esc_html( $section['description'] ); ?></small>
                        <?php endif; ?>
                    </span>
                    <span
                        class="dashicons dashicons-arrow-down-alt2 tutorhelper-student-accordion__icon"
                        aria-hidden="true"
                    ></span>
                </summary>
                <div class="tutorhelper-student-detail-section__content tutorhelper-student-accordion__content">
                    <?php
                    $legacy_action = '';
                    if ( 'notes-communication' === $section_id ) {
                        $legacy_action = 'tutorhelper_students_registration_detail';
                    } elseif ( 'lesson-options-pricing' === $section_id ) {
                        $legacy_action = 'tutorhelper_students_render_pricing';
                    }

                    if ( has_action( $action ) || ( $legacy_action && has_action( $legacy_action ) ) ) {
                        do_action( $action, $student, $section );
                        if ( $legacy_action ) {
                            do_action( $legacy_action, $student );
                        }
                    } else {
                        self::render_pro_feature(
                            $section['title'],
                            $section['description'] ?? '',
                            $icon
                        );
                    }
                    ?>
                </div>
            </details>
            <?php
        }

        echo '</div>';
    }


    /**
     * Render the editable student details form.
     *
     * @param array  $details Student details.
     * @param string $cancel_url Read-only student view URL.
     *
     * @return void
     */
    private static function render_student_edit_form(
        $details,
        $cancel_url
    ) {
        ?>
        <form
            method="post"
            action="<?php echo esc_url(
                admin_url( 'admin-post.php' )
            ); ?>"
            class="tutorhelper-student-edit-form"
        >
            <input
                type="hidden"
                name="action"
                value="<?php echo esc_attr(
                    self::SAVE_ACTION
                ); ?>"
            />

            <input
                type="hidden"
                name="student_user_id"
                value="<?php echo esc_attr(
                    $details['id']
                ); ?>"
            />

            <?php
            wp_nonce_field(
                self::SAVE_ACTION
            );
            ?>

            <div class="tutorhelper-student-detail__account-layout">
                <div class="tutorhelper-student-detail__account-main">
                    <div class="tutorhelper-student-detail__columns">
                        <?php
                        self::render_student_account_details(
                            $details,
                            true
                        );

                        self::render_parent_details(
                            $details,
                            true
                        );
                        ?>
                    </div>
                </div>

                <aside
                    class="tutorhelper-student-detail__account-sidebar"
                    aria-label="<?php echo esc_attr__(
                        'Student account settings',
                        'tutorhelper-bookings'
                    ); ?>"
                >
                    <?php
                    self::render_booking_access_details(
                        $details,
                        true
                    );
                    ?>
                </aside>
            </div>

            <div class="tutorhelper-student-edit-form__actions">
                <button
                    type="submit"
                    class="button button-primary tutorhelper-action-button"
                >
                    <span
                        class="dashicons dashicons-saved"
                        aria-hidden="true"
                    ></span>

                    <?php
                    echo esc_html__(
                        'Save student details',
                        'tutorhelper-bookings'
                    );
                    ?>
                </button>

                <a
                    class="button tutorhelper-hub-pill-button"
                    href="<?php echo esc_url(
                        $cancel_url
                    ); ?>"
                >
                    <?php
                    echo esc_html__(
                        'Cancel editing',
                        'tutorhelper-bookings'
                    );
                    ?>
                </a>
            </div>
        </form>
        <?php
    }


    /**
     * Render a Student Management notice.
     *
     * @return void
     */
    private static function render_student_notice() {
        $notice_code = isset(
            $_GET['student_notice'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
        )
            ? sanitize_key(
                wp_unslash(
                    $_GET['student_notice'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
                )
            )
            : '';

        if ( '' === $notice_code ) {
            return;
        }

        $notice_type = isset(
            $_GET['student_notice_type'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
        )
            ? sanitize_key(
                wp_unslash(
                    $_GET['student_notice_type'] // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only request state used for navigation or feedback; value is sanitized and no state change occurs.
                )
            )
            : 'success';

        $messages = array(
            'student_saved' => __(
                'Student details saved.',
                'tutorhelper-bookings'
            ),

            'student_not_found' => __(
                'The student account could not be found.',
                'tutorhelper-bookings'
            ),

            'tutorhelper_student_invalid_email' => __(
                'Enter a valid student email address.',
                'tutorhelper-bookings'
            ),

            'tutorhelper_student_email_exists' => __(
                'That email address is already used by another WordPress account.',
                'tutorhelper-bookings'
            ),

            'tutorhelper_student_display_name_required' => __(
                'Enter a display name for the student.',
                'tutorhelper-bookings'
            ),

            'password_email_sent' => __(
                'The WordPress password-reset email was sent.',
                'tutorhelper-bookings'
            ),

            'password_email_failed' => __(
                'The password-reset email could not be sent.',
                'tutorhelper-bookings'
            ),

            'password_updated' => __(
                'The student password was updated.',
                'tutorhelper-bookings'
            ),

            'password_too_short' => __(
                'The new password must contain at least 12 characters.',
                'tutorhelper-bookings'
            ),

            'password_mismatch' => __(
                'The new passwords do not match.',
                'tutorhelper-bookings'
            ),

            'tutorhelper_parent_same_as_student' => __(
                'A student cannot be linked as their own Parent Account.',
                'tutorhelper-bookings'
            ),

            'tutorhelper_parent_not_found' => __(
                'The selected Parent Account could not be found.',
                'tutorhelper-bookings'
            ),
        );

        if ( ! isset( $messages[ $notice_code ] ) ) {
            return;
        }

        $classes = array(
            'notice',
            'error' === $notice_type
                ? 'notice-error'
                : 'notice-success',
            'is-dismissible',
            'tutorhelper-student-notice',
        );

        ?>
        <div class="<?php echo esc_attr(
            implode( ' ', $classes )
        ); ?>">
            <p>
                <?php echo esc_html(
                    $messages[ $notice_code ]
                ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Render expandable student password-management controls.
     *
     * @param array $details Student details.
     *
     * @return void
     */
    private static function render_password_management(
        $details
    ) {
        ?>
        <details class="tutorhelper-student-accordion">
            <summary class="tutorhelper-student-accordion__summary">
                <span
                    class="dashicons dashicons-lock"
                    aria-hidden="true"
                ></span>

                <span class="tutorhelper-student-accordion__title">
                    <strong>
                        <?php
                        echo esc_html__(
                            'Password Management',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </strong>

                    <small>
                        <?php
                        echo esc_html__(
                            'Send a reset email or set a new password manually.',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </small>
                </span>

                <span
                    class="dashicons dashicons-arrow-down-alt2 tutorhelper-student-accordion__icon"
                    aria-hidden="true"
                ></span>
            </summary>

            <div class="tutorhelper-student-accordion__content">
                <div class="tutorhelper-student-password__grid">
                    <section class="tutorhelper-student-password__option">
                        <h4>
                            <?php
                            echo esc_html__(
                                'Send password reset email',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </h4>

                        <p>
                            <?php
                            printf(
                                /* translators: %s: Student email address. */
                                esc_html__(
                                    'WordPress will send a secure reset link to %s.',
                                    'tutorhelper-bookings'
                                ),
                                esc_html(
                                    $details['email']
                                )
                            );
                            ?>
                        </p>

                        <form
                            method="post"
                            action="<?php echo esc_url(
                                admin_url( 'admin-post.php' )
                            ); ?>"
                        >
                            <input
                                type="hidden"
                                name="action"
                                value="<?php echo esc_attr(
                                    self::RESET_EMAIL_ACTION
                                ); ?>"
                            />

                            <input
                                type="hidden"
                                name="student_user_id"
                                value="<?php echo esc_attr(
                                    $details['id']
                                ); ?>"
                            />

                            <?php
                            wp_nonce_field(
                                self::RESET_EMAIL_ACTION
                            );
                            ?>

                            <button
                                type="submit"
                                class="button tutorhelper-hub-pill-button"
                            >
                                <span
                                    class="dashicons dashicons-email-alt"
                                    aria-hidden="true"
                                ></span>

                                <?php
                                echo esc_html__(
                                    'Send reset email',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </button>
                        </form>
                    </section>

                    <section class="tutorhelper-student-password__option">
                        <h4>
                            <?php
                            echo esc_html__(
                                'Set a new password manually',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </h4>

                        <p>
                            <?php
                            echo esc_html__(
                                'The student will be signed out and must use this new password. For security, no confirmation email will be sent containing passwords.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>

                        <form
                            method="post"
                            action="<?php echo esc_url(
                                admin_url( 'admin-post.php' )
                            ); ?>"
                            class="tutorhelper-student-password__form"
                        >
                            <input
                                type="hidden"
                                name="action"
                                value="<?php echo esc_attr(
                                    self::PASSWORD_ACTION
                                ); ?>"
                            />

                            <input
                                type="hidden"
                                name="student_user_id"
                                value="<?php echo esc_attr(
                                    $details['id']
                                ); ?>"
                            />

                            <input
                                type="text"
                                name="username"
                                value="<?php echo esc_attr(
                                    $details['username']
                                ); ?>"
                                class="tutorhelper-password-username"
                                autocomplete="username"
                                tabindex="-1"
                                aria-hidden="true"
                            />

                            <?php
                            wp_nonce_field(
                                self::PASSWORD_ACTION
                            );
                            ?>

                            <div class="tutorhelper-student-field">
                                <label for="tutorhelper-new-password">
                                    <?php
                                    echo esc_html__(
                                        'New password',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </label>

                                <div class="tutorhelper-password-control">
                                    <input
                                        type="password"
                                        id="tutorhelper-new-password"
                                        name="new_password"
                                        minlength="12"
                                        autocomplete="new-password"
                                        required
                                    />
                                    <button
                                        type="button"
                                        class="tutorhelper-password-toggle"
                                        aria-controls="tutorhelper-new-password"
                                        aria-pressed="false"
                                        data-show-label="<?php esc_attr_e( 'Show password', 'tutorhelper-bookings' ); ?>"
                                        data-hide-label="<?php esc_attr_e( 'Hide password', 'tutorhelper-bookings' ); ?>"
                                    >
                                        <?php esc_html_e( 'Show password', 'tutorhelper-bookings' ); ?>
                                    </button>
                                </div>
                            </div>

                            <div class="tutorhelper-student-field">
                                <label for="tutorhelper-confirm-password">
                                    <?php
                                    echo esc_html__(
                                        'Confirm password',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </label>

                                <div class="tutorhelper-password-control">
                                    <input
                                        type="password"
                                        id="tutorhelper-confirm-password"
                                        name="confirm_password"
                                        minlength="12"
                                        autocomplete="new-password"
                                        required
                                    />
                                    <button
                                        type="button"
                                        class="tutorhelper-password-toggle"
                                        aria-controls="tutorhelper-confirm-password"
                                        aria-pressed="false"
                                        data-show-label="<?php esc_attr_e( 'Show password', 'tutorhelper-bookings' ); ?>"
                                        data-hide-label="<?php esc_attr_e( 'Hide password', 'tutorhelper-bookings' ); ?>"
                                    >
                                        <?php esc_html_e( 'Show password', 'tutorhelper-bookings' ); ?>
                                    </button>
                                </div>
                            </div>

                            <button
                                type="submit"
                                class="button tutorhelper-action-button"
                            >
                                <span
                                    class="dashicons dashicons-saved"
                                    aria-hidden="true"
                                ></span>

                                <?php
                                echo esc_html__(
                                    'Set new password',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </button>
                        </form>
                    </section>
                </div>
            </div>
        </details>
        <?php
    }




    /**
     * Render student account details.
     *
     * @param array $details  Student details.
     * @param bool  $editable Whether to display editable fields.
     *
     * @return void
     */
    private static function render_student_account_details(
        $details,
        $editable = false
    ) {
        ?>
        <section class="tutorhelper-student-detail__section">
            <h3>
                <?php
                echo esc_html__(
                    'Student Details',
                    'tutorhelper-bookings'
                );
                ?>
            </h3>

            <?php if ( $editable ) : ?>
                <div class="tutorhelper-student-fields">
                    <div class="tutorhelper-student-field">
                        <label for="tutorhelper-first-name">
                            <?php
                            echo esc_html__(
                                'First name',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            id="tutorhelper-first-name"
                            name="first_name"
                            value="<?php echo esc_attr(
                                $details['first_name']
                            ); ?>"
                            autocomplete="given-name"
                        />
                    </div>

                    <div class="tutorhelper-student-field">
                        <label for="tutorhelper-last-name">
                            <?php
                            echo esc_html__(
                                'Last name',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            id="tutorhelper-last-name"
                            name="last_name"
                            value="<?php echo esc_attr(
                                $details['last_name']
                            ); ?>"
                            autocomplete="family-name"
                        />
                    </div>

                    <div class="tutorhelper-student-field">
                        <label for="tutorhelper-display-name">
                            <?php
                            echo esc_html__(
                                'Display name',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            id="tutorhelper-display-name"
                            name="display_name"
                            value="<?php echo esc_attr(
                                $details['display_name']
                            ); ?>"
                            required
                        />
                    </div>

                    <div class="tutorhelper-student-field">
                        <label>
                            <?php
                            echo esc_html__(
                                'Username',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            value="<?php echo esc_attr(
                                $details['username']
                            ); ?>"
                            disabled
                        />

                        <p class="description">
                            <?php
                            echo esc_html__(
                                'WordPress usernames cannot be changed here.',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </p>
                    </div>

                    <div class="tutorhelper-student-field">
                        <label for="tutorhelper-student-email">
                            <?php
                            echo esc_html__(
                                'Email',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="email"
                            id="tutorhelper-student-email"
                            name="user_email"
                            value="<?php echo esc_attr(
                                $details['email']
                            ); ?>"
                            autocomplete="email"
                            required
                        />
                    </div>

                    <div class="tutorhelper-student-field">
                        <label for="tutorhelper-student-phone">
                            <?php
                            echo esc_html__(
                                'Phone',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="tel"
                            id="tutorhelper-student-phone"
                            name="phone"
                            value="<?php echo esc_attr(
                                $details['phone']
                            ); ?>"
                            autocomplete="tel"
                        />
                    </div>

                    <div class="tutorhelper-student-field">
                        <label>
                            <?php
                            echo esc_html__(
                                'Account created',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            value="<?php echo esc_attr(
                                get_date_from_gmt(
                                    $details['registered'],
                                    get_option( 'date_format' )
                                    . ', '
                                    . get_option( 'time_format' )
                                )
                            ); ?>"
                            disabled
                        />
                    </div>

                    <div class="tutorhelper-student-field">
                        <label>
                            <?php
                            echo esc_html__(
                                'Account role',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            value="<?php echo esc_attr__(
                                'TH Student',
                                'tutorhelper-bookings'
                            ); ?>"
                            disabled
                        />
                    </div>
                </div>
            <?php else : ?>
                <dl class="tutorhelper-student-detail__list">
                    <?php
                    self::render_detail_row(
                        __(
                            'Student name',
                            'tutorhelper-bookings'
                        ),
                        $details['student_name']
                    );

                    self::render_detail_row(
                        __(
                            'Display name',
                            'tutorhelper-bookings'
                        ),
                        $details['display_name']
                    );

                    self::render_detail_row(
                        __(
                            'Username',
                            'tutorhelper-bookings'
                        ),
                        $details['username']
                    );

                    self::render_detail_row(
                        __(
                            'Email',
                            'tutorhelper-bookings'
                        ),
                        $details['email'],
                        'email'
                    );

                    self::render_detail_row(
                        __(
                            'Phone',
                            'tutorhelper-bookings'
                        ),
                        $details['phone']
                    );

                    self::render_detail_row(
                        __(
                            'Account created',
                            'tutorhelper-bookings'
                        ),
                        get_date_from_gmt(
                            $details['registered'],
                            get_option( 'date_format' )
                            . ', '
                            . get_option( 'time_format' )
                        )
                    );

                    self::render_detail_row(
                        __(
                            'Account role',
                            'tutorhelper-bookings'
                        ),
                        __(
                            'TH Student',
                            'tutorhelper-bookings'
                        )
                    );
                    ?>
                </dl>
            <?php endif; ?>
        </section>
        <?php
    }


    /**
     * Render parent, guardian and postal-address details.
     *
     * @param array $details  Student details.
     * @param bool  $editable Whether to display editable fields.
     *
     * @return void
     */
    private static function render_parent_details(
        $details,
        $editable = false
    ) {
        $parent  = $details['parent'];
        $address = $details['address'];
        $linked_parent_accounts = array();

        if (
            class_exists( 'TutorHelper_Student_Parent_Links' )
            && TutorHelper_Student_Parent_Links::table_exists()
        ) {
            $linked_parent_accounts =
                TutorHelper_Student_Parent_Links::get_parents(
                    absint( $details['id'] )
                );
        }

        /*
         * Preserve the legacy primary-parent display if the relationship table
         * is unavailable or has not yet been populated.
         */
        if (
            empty( $linked_parent_accounts )
            && $parent['linked_parent']
        ) {
            $linked_parent_accounts[] = (object) array(
                'display_name'       => $parent['linked_name'],
                'user_email'         => $parent['linked_email'],
                'relationship_label' => __(
                    'Parent / Guardian',
                    'tutorhelper-bookings'
                ),
                'is_primary'         => 1,
            );
        }

        ?>
        <section class="tutorhelper-student-detail__section">
            <h3>
                <?php
                echo esc_html__(
                    'Parent / Guardian',
                    'tutorhelper-bookings'
                );
                ?>
            </h3>

            <?php if ( $editable ) : ?>
                <div class="tutorhelper-student-fields">
                    <div class="tutorhelper-student-field">
                        <label for="tutorhelper-parent-name">
                            <?php
                            echo esc_html__(
                                'Name',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="text"
                            id="tutorhelper-parent-name"
                            name="parent_name"
                            value="<?php echo esc_attr(
                                $parent['legacy_name']
                            ); ?>"
                        />
                    </div>

                    <div class="tutorhelper-student-field">
                        <label for="tutorhelper-parent-email">
                            <?php
                            echo esc_html__(
                                'Email',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="email"
                            id="tutorhelper-parent-email"
                            name="parent_email"
                            value="<?php echo esc_attr(
                                $parent['legacy_email']
                            ); ?>"
                        />
                    </div>

                    <div class="tutorhelper-student-field">
                        <label for="tutorhelper-parent-phone">
                            <?php
                            echo esc_html__(
                                'Phone',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <input
                            type="tel"
                            id="tutorhelper-parent-phone"
                            name="parent_phone"
                            value="<?php echo esc_attr(
                                $parent['legacy_phone']
                            ); ?>"
                        />
                    </div>
                </div>

                <section class="tutorhelper-parent-account">
                    <div class="tutorhelper-parent-account__header">
                        <span class="dashicons dashicons-admin-links" aria-hidden="true"></span>
                        <div>
                            <h4><?php echo esc_html__( 'Parent Accounts', 'tutorhelper-bookings' ); ?></h4>
                            <p><?php echo esc_html__( 'Manage every linked Parent Account here, including the primary contact.', 'tutorhelper-bookings' ); ?></p>
                        </div>
                    </div>

                    <?php
                    /**
                     * Render Parent Account relationship controls.
                     *
                     * @param int $student_user_id Student WordPress user ID.
                     */
                    do_action(
                        'tutorhelper_students_render_parent_account_controls',
                        absint( $details['id'] )
                    );
                    ?>

                    <label class="tutorhelper-toggle-row">
                        <input
                            type="checkbox"
                            name="use_linked_parent"
                            value="1"
                            class="tutorhelper-use-linked-parent"
                            <?php checked( $parent['use_linked_parent'] ); ?>
                            <?php disabled( ! $parent['linked_parent_user_id'] ); ?>
                        />
                        <span>
                            <strong><?php echo esc_html__( 'Use details from the primary Parent Account', 'tutorhelper-bookings' ); ?></strong>
                            <small><?php echo esc_html__( 'Overrides the separately stored parent name, email and phone. Those details remain available as a fallback.', 'tutorhelper-bookings' ); ?></small>
                        </span>
                    </label>
                </section>

                <div class="tutorhelper-student-address-fields">
                    <h4>
                        <?php
                        echo esc_html__(
                            'Postal Address',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </h4>

                    <div class="tutorhelper-student-fields">
                        <div class="tutorhelper-student-field is-full-width">
                            <label for="tutorhelper-address-line-1">
                                <?php
                                echo esc_html__(
                                    'Address line 1',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </label>

                            <input
                                type="text"
                                id="tutorhelper-address-line-1"
                                name="address_line_1"
                                value="<?php echo esc_attr(
                                    $address['line_1']
                                ); ?>"
                                autocomplete="address-line1"
                            />
                        </div>

                        <div class="tutorhelper-student-field is-full-width">
                            <label for="tutorhelper-address-line-2">
                                <?php
                                echo esc_html__(
                                    'Address line 2',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </label>

                            <input
                                type="text"
                                id="tutorhelper-address-line-2"
                                name="address_line_2"
                                value="<?php echo esc_attr(
                                    $address['line_2']
                                ); ?>"
                                autocomplete="address-line2"
                            />
                        </div>

                        <div class="tutorhelper-student-field">
                            <label for="tutorhelper-address-city">
                                <?php
                                echo esc_html__(
                                    'Town / City',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </label>

                            <input
                                type="text"
                                id="tutorhelper-address-city"
                                name="address_city"
                                value="<?php echo esc_attr(
                                    $address['city']
                                ); ?>"
                                autocomplete="address-level2"
                            />
                        </div>

                        <div class="tutorhelper-student-field">
                            <label for="tutorhelper-address-county">
                                <?php
                                echo esc_html__(
                                    'County / State',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </label>

                            <input
                                type="text"
                                id="tutorhelper-address-county"
                                name="address_county"
                                value="<?php echo esc_attr(
                                    $address['county']
                                ); ?>"
                                autocomplete="address-level1"
                            />
                        </div>

                        <div class="tutorhelper-student-field">
                            <label for="tutorhelper-address-postcode">
                                <?php
                                echo esc_html__(
                                    'Postcode',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </label>

                            <input
                                type="text"
                                id="tutorhelper-address-postcode"
                                name="address_postcode"
                                value="<?php echo esc_attr(
                                    $address['postcode']
                                ); ?>"
                                autocomplete="postal-code"
                            />
                        </div>

                        <div class="tutorhelper-student-field">
                            <label for="tutorhelper-address-country">
                                <?php
                                echo esc_html__(
                                    'Country',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </label>

                            <input
                                type="text"
                                id="tutorhelper-address-country"
                                name="address_country"
                                value="<?php echo esc_attr(
                                    $address['country']
                                ); ?>"
                                autocomplete="country-name"
                            />
                        </div>
                    </div>
                </div>
            <?php else : ?>
                <dl class="tutorhelper-student-detail__list">
                    <?php
                    self::render_detail_row(
                        __(
                            'Name',
                            'tutorhelper-bookings'
                        ),
                        $parent['name']
                    );

                    self::render_detail_row(
                        __(
                            'Email',
                            'tutorhelper-bookings'
                        ),
                        $parent['email'],
                        'email'
                    );

                    self::render_detail_row(
                        __(
                            'Phone',
                            'tutorhelper-bookings'
                        ),
                        $parent['phone']
                    );
                    ?>
                </dl>

                
                <section class="tutorhelper-parent-account">
                    <div class="tutorhelper-parent-account__header">
                        <span
                            class="dashicons dashicons-admin-links"
                            aria-hidden="true"
                        ></span>

                        <div>
                            <h4>
                                <?php
                                echo esc_html__(
                                    'Linked Parent Accounts',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </h4>

                            <?php if ( empty( $linked_parent_accounts ) ) : ?>
                                <p>
                                    <?php
                                    echo esc_html__(
                                        'No Parent Account is currently linked.',
                                        'tutorhelper-bookings'
                                    );
                                    ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if ( ! empty( $linked_parent_accounts ) ) : ?>
                        <ul class="tutorhelper-parent-account__list">
                            <?php foreach ( $linked_parent_accounts as $linked_parent_account ) : ?>
                                <?php
                                $relationship_label = ! empty(
                                    $linked_parent_account->relationship_label
                                )
                                    ? $linked_parent_account->relationship_label
                                    : __(
                                        'Parent / Guardian',
                                        'tutorhelper-bookings'
                                    );
                                ?>
                                <li class="tutorhelper-parent-account__item">
                                    <div class="tutorhelper-parent-account__details">
                                        <strong>
                                            <?php
                                            echo esc_html(
                                                $linked_parent_account->display_name
                                            );
                                            ?>
                                        </strong>

                                        <span class="tutorhelper-parent-account__relationship">
                                            <?php
                                            echo esc_html(
                                                $relationship_label
                                            );
                                            ?>
                                        </span>

                                        <?php if ( ! empty( $linked_parent_account->user_email ) ) : ?>
                                            <a
                                                class="tutorhelper-parent-account__email"
                                                href="<?php echo esc_url(
                                                    'mailto:' . $linked_parent_account->user_email
                                                ); ?>"
                                            >
                                                <?php
                                                echo esc_html(
                                                    $linked_parent_account->user_email
                                                );
                                                ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>

                                    <?php if ( ! empty( $linked_parent_account->is_primary ) ) : ?>
                                        <span class="tutorhelper-parent-account__primary">
                                            <?php
                                            echo esc_html__(
                                                'Primary contact',
                                                'tutorhelper-bookings'
                                            );
                                            ?>
                                        </span>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>

                        <span class="tutorhelper-parent-account__status">
                            <?php
                            echo esc_html(
                                $parent['use_linked_parent']
                                    ? __(
                                        'Using primary linked account details',
                                        'tutorhelper-bookings'
                                    )
                                    : __(
                                        'Using separately stored parent details',
                                        'tutorhelper-bookings'
                                    )
                            );
                            ?>
                        </span>
                    <?php endif; ?>
                </section>


                <section class="tutorhelper-student-address-section">
                <div class="tutorhelper-student-address">
                    <h4>
                        <?php
                        echo esc_html__(
                            'Postal Address',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </h4>

                        <?php if ( $address['is_empty'] ) : ?>
                            <p class="tutorhelper-student-muted">
                                <?php
                                echo esc_html__(
                                    'Not provided',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </p>
                        <?php else : ?>
                            <address>
                                <?php foreach ( $address['lines'] as $line ) : ?>
                                    <span>
                                        <?php echo esc_html( $line ); ?>
                                    </span>
                                <?php endforeach; ?>
                            </address>
                        <?php endif; ?>
                    </div>
                </section>

            <?php endif; ?>

           
        </section>
        <?php
    }


    /**
     * Render one label and value within a details list.
     *
     * @param string $label Label.
     * @param string $value Display value.
     * @param string $type  Optional value type.
     *
     * @return void
     */
    private static function render_detail_row(
        $label,
        $value,
        $type = 'text'
    ) {
        $value = trim(
            (string) $value
        );

        ?>
        <div class="tutorhelper-student-detail__row">
            <dt>
                <?php echo esc_html( $label ); ?>
            </dt>

            <dd>
                <?php if ( '' === $value ) : ?>
                    <span class="tutorhelper-student-muted">
                        <?php
                        echo esc_html__(
                            'Not provided',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </span>
                <?php elseif ( 'email' === $type ) : ?>
                    <a href="mailto:<?php echo esc_attr(
                        $value
                    ); ?>">
                        <?php echo esc_html( $value ); ?>
                    </a>
                <?php else : ?>
                    <?php echo esc_html( $value ); ?>
                <?php endif; ?>
            </dd>
        </div>
        <?php
    }


    /**
     * Render Booking Access details or controls.
     *
     * @param array $details  Student details.
     * @param bool  $editable Whether to display editable fields.
     *
     * @return void
     */
    private static function render_booking_access_details(
        $details,
        $editable = false
    ) {
        $is_blocked = ! empty(
            $details['booking']['blocked']
        );

        ?>
        <section class="tutorhelper-student-booking-access">
            <div class="tutorhelper-student-booking-access__header">
                <div>
                    <h3>
                        <?php
                        echo esc_html__(
                            'Booking Access',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </h3>

                    <p>
                        <?php
                        echo esc_html__(
                            'Control whether this student can make lesson bookings.',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </p>
                </div>

                <span class="tutorhelper-student-status <?php echo esc_attr(
                    $is_blocked
                        ? 'is-blocked'
                        : 'is-allowed'
                ); ?>">
                    <?php
                    echo esc_html(
                        $is_blocked
                            ? __(
                                'Booking blocked',
                                'tutorhelper-bookings'
                            )
                            : __(
                                'Booking allowed',
                                'tutorhelper-bookings'
                            )
                    );
                    ?>
                </span>
            </div>

            <?php if ( $editable ) : ?>
                <div class="tutorhelper-student-booking-access__controls">
                    <label class="tutorhelper-toggle-row">
                        <input
                            type="checkbox"
                            name="booking_blocked"
                            value="1"
                            <?php checked( $is_blocked ); ?>
                        />

                        <span>
                            <strong>
                                <?php
                                echo esc_html__(
                                    'Block this student from booking lessons',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </strong>

                            <small>
                                <?php
                                echo esc_html__(
                                    'Existing bookings are not changed.',
                                    'tutorhelper-bookings'
                                );
                                ?>
                            </small>
                        </span>
                    </label>

                    <div class="tutorhelper-student-field is-full-width">
                        <label for="tutorhelper-booking-message">
                            <?php
                            echo esc_html__(
                                'Message shown to student',
                                'tutorhelper-bookings'
                            );
                            ?>
                        </label>

                        <textarea
                            id="tutorhelper-booking-message"
                            name="booking_blocked_message"
                            rows="3"
                        ><?php echo esc_textarea(
                            $details['booking']['message']
                        ); ?></textarea>
                    </div>
                </div>
            <?php elseif ( $is_blocked ) : ?>
                <div class="tutorhelper-student-booking-access__message">
                    <strong>
                        <?php
                        echo esc_html__(
                            'Message shown to student',
                            'tutorhelper-bookings'
                        );
                        ?>
                    </strong>

                    <p>
                        <?php
                        echo esc_html(
                            $details['booking']['message']
                                ? $details['booking']['message']
                                : __(
                                    'Online booking is temporarily unavailable. Please contact us.',
                                    'tutorhelper-bookings'
                                )
                        );
                        ?>
                    </p>
                </div>
            <?php endif; ?>
        </section>
        <?php
    }



    /**
     * Return the Student Management list URL.
     *
     * @param array $args Additional query arguments.
     *
     * @return string
     */
    private static function get_students_url(
        $args = array()
    ) {
        $query_args = array_merge(
            array(
                'page' =>
                    TutorHelper_Booking_Hub::PAGE_SLUG,
                'tab'  => self::TAB_KEY,
            ),
            is_array( $args )
                ? $args
                : array()
        );

        return add_query_arg(
            $query_args,
            admin_url( 'admin.php' )
        );
    }

    /**
     * Return the Student Management detail URL.
     *
     * @param int   $student_user_id Student user ID.
     * @param array $args            Additional query arguments.
     *
     * @return string
     */
    private static function get_student_url(
        $student_user_id,
        $args = array()
    ) {
        return self::get_students_url(
            array_merge(
                array(
                    'student_id' => absint(
                        $student_user_id
                    ),
                ),
                is_array( $args )
                    ? $args
                    : array()
            )
        );
    }





	/**
	 * Render a disabled Pro feature placeholder.
	 *
	 * @param string $title       Feature title.
	 * @param string $description Feature description.
	 * @param string $icon        Dashicon class.
	 *
	 * @return void
	 */
	private static function render_pro_feature(
		$title,
		$description,
		$icon
	) {
		?>
		<section
			class="tutorhelper-students-pro-feature"
			aria-disabled="true"
		>
			<div class="tutorhelper-students-pro-feature__header">
				<span
					class="dashicons <?php echo esc_attr( $icon ); ?>"
					aria-hidden="true"
				></span>

				<h3>
					<?php echo esc_html( $title ); ?>
				</h3>

				<span class="tutorhelper-pro-badge">
					<?php
					echo esc_html__(
						'Pro',
						'tutorhelper-bookings'
					);
					?>
				</span>
			</div>

			<p>
				<?php echo esc_html( $description ); ?>
			</p>

			<p class="tutorhelper-students-pro-feature__status">
				<?php
				echo esc_html__(
					'Available with TutorHelper Bookings Pro',
					'tutorhelper-bookings'
				);
				?>
			</p>
		</section>
		<?php
	}



    /**
     * Search WordPress users who may be linked as Parent Accounts.
     *
     * @return void
     */
    public static function handle_parent_account_search() {
        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_send_json_error(
                array(
                    'message' => __(
                        'You do not have permission to search user accounts.',
                        'tutorhelper-bookings'
                    ),
                ),
                403
            );
        }

        check_ajax_referer(
            self::PARENT_SEARCH_ACTION,
            'nonce'
        );

        $search = isset( $_GET['search'] )
            ? sanitize_text_field(
                wp_unslash(
                    $_GET['search']
                )
            )
            : '';

        $student_user_id = isset(
            $_GET['student_user_id']
        )
            ? absint(
                $_GET['student_user_id']
            )
            : 0;

        $exclude_linked = isset( $_GET['exclude_linked'] )
            && ! is_array( $_GET['exclude_linked'] )
            && '1' === sanitize_key(
                wp_unslash( $_GET['exclude_linked'] )
            );

        if (
            ! $student_user_id
            || ! TutorHelper_Students::get_student(
                $student_user_id
            )
        ) {
            wp_send_json_error(
                array(
                    'message' => __(
                        'The student account could not be found.',
                        'tutorhelper-bookings'
                    ),
                ),
                400
            );
        }

        if ( strlen( $search ) < 2 ) {
            wp_send_json_success(
                array(
                    'results' => array(),
                )
            );
        }

        $users = TutorHelper_Students::search_parent_accounts(
            $search,
            $student_user_id,
            20
        );

        $results = array();

        foreach ( $users as $user ) {
            if ( ! $user instanceof WP_User ) {
                continue;
            }

            if (
                $exclude_linked
                && TutorHelper_Student_Parent_Links::is_linked(
                    $user->ID,
                    $student_user_id
                )
            ) {
                continue;
            }

            $results[] = array(
                'id' => absint(
                    $user->ID
                ),

                'name' => sanitize_text_field(
                    $user->display_name
                ),

                'email' => sanitize_email(
                    $user->user_email
                ),

                'username' => sanitize_user(
                    $user->user_login
                ),

                'is_parent' => in_array(
                    TutorHelper_Students::PARENT_ROLE,
                    (array) $user->roles,
                    true
                ),
            );
        }

        wp_send_json_success(
            array(
                'results' => $results,
            )
        );
    }




    /**
     * Save editable student details.
     *
     * @return void
     */
    public static function handle_save_student() {
        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to edit student accounts.',
                    'tutorhelper-bookings'
                )
            );
        }

        check_admin_referer(
            self::SAVE_ACTION
        );

        $student_user_id = isset(
            $_POST['student_user_id']
        )
            ? absint(
                $_POST['student_user_id']
            )
            : 0;

        $student = TutorHelper_Students::get_student(
            $student_user_id
        );

        if ( ! $student ) {
            self::redirect_student_notice(
                $student_user_id,
                'student_not_found',
                'error'
            );
        }

        $data = array(
            'display_name' => isset(
                $_POST['display_name']
            )
                ? sanitize_text_field(
                    wp_unslash(
                        $_POST['display_name']
                    )
                )
                : '',

            'user_email' => isset(
                $_POST['user_email']
            )
                ? sanitize_email(
                    wp_unslash(
                        $_POST['user_email']
                    )
                )
                : '',
        );

        foreach (
            TutorHelper_Students::get_editable_meta_fields()
            as $field_key => $definition
        ) {
            $data[ $field_key ] = isset(
                $_POST[ $field_key ]
            )
                ? sanitize_text_field(
                    wp_unslash(
                        $_POST[ $field_key ]
                    )
                )
                : '';
        }

        $result =
            TutorHelper_Students::update_student(
                $student_user_id,
                $data
            );

        if ( is_wp_error( $result ) ) {
            self::redirect_student_notice(
                $student_user_id,
                $result->get_error_code(),
                'error'
            );
        }

        $blocked = isset(
            $_POST['booking_blocked']
        );

        $booking_message = isset(
            $_POST['booking_blocked_message']
        )
            ? sanitize_textarea_field(
                wp_unslash(
                    $_POST['booking_blocked_message']
                )
            )
            : '';
        
        $parent_preference_result =
            TutorHelper_Students::
                update_parent_contact_preference(
                    $student_user_id,
                    isset( $_POST['use_linked_parent'] )
                );

        if ( is_wp_error( $parent_preference_result ) ) {
            self::redirect_student_notice(
                $student_user_id,
                $parent_preference_result->get_error_code(),
                'error',
                array(
                    'student_mode' => 'edit',
                )
            );
        }


        $access_result =
            TutorHelper_Students::update_booking_access(
                $student_user_id,
                $blocked,
                $booking_message
            );

        if ( is_wp_error( $access_result ) ) {
            self::redirect_student_notice(
                $student_user_id,
                $access_result->get_error_code(),
                'error'
            );
        }

        self::redirect_student_notice(
            $student_user_id,
            'student_saved',
            'success',
            array(
                'student_mode' => 'view',
            )
        );

    }


    /**
     * Send WordPress's standard password-reset email.
     *
     * @return void
     */
    public static function handle_send_password_reset() {
        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to reset student passwords.',
                    'tutorhelper-bookings'
                )
            );
        }

        check_admin_referer(
            self::RESET_EMAIL_ACTION
        );

        $student_user_id = isset(
            $_POST['student_user_id']
        )
            ? absint(
                $_POST['student_user_id']
            )
            : 0;

        $student = TutorHelper_Students::get_student(
            $student_user_id
        );

        if ( ! $student ) {
            self::redirect_student_notice(
                $student_user_id,
                'student_not_found',
                'error'
            );
        }

        $result = retrieve_password(
            $student->user_login
        );

        if ( is_wp_error( $result ) ) {
            self::redirect_student_notice(
                $student_user_id,
                'password_email_failed',
                'error'
            );
        }

        TutorHelper_Student_Audit_Log::record(
            $student_user_id,
            'password_reset_email_sent',
            'password'
        );

        self::redirect_student_notice(
            $student_user_id,
            'password_email_sent',
            'success'
        );
    }


    /**
     * Manually set a new student password.
     *
     * @return void
     */
    public static function handle_set_password() {
        if (
            ! current_user_can(
                TutorHelper_Admin::CAPABILITY
            )
        ) {
            wp_die(
                esc_html__(
                    'You do not have permission to reset student passwords.',
                    'tutorhelper-bookings'
                )
            );
        }

        check_admin_referer(
            self::PASSWORD_ACTION
        );

        $student_user_id = isset(
            $_POST['student_user_id']
        )
            ? absint(
                $_POST['student_user_id']
            )
            : 0;

        $student = TutorHelper_Students::get_student(
            $student_user_id
        );

        if ( ! $student ) {
            self::redirect_student_notice(
                $student_user_id,
                'student_not_found',
                'error'
            );
        }

        $password = isset(
            $_POST['new_password']
        )
            ? (string) wp_unslash(
                $_POST['new_password'] // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords must remain byte-for-byte unchanged; the nonce-protected handler intentionally unslashes but does not text-sanitize the password.
            )
            : '';

        $confirmation = isset(
            $_POST['confirm_password']
        )
            ? (string) wp_unslash(
                $_POST['confirm_password'] // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords must remain byte-for-byte unchanged; the nonce-protected handler intentionally unslashes but does not text-sanitize the password.
            )
            : '';

        if ( strlen( $password ) < 12 ) {
            self::redirect_student_notice(
                $student_user_id,
                'password_too_short',
                'error'
            );
        }

        if ( $password !== $confirmation ) {
            self::redirect_student_notice(
                $student_user_id,
                'password_mismatch',
                'error'
            );
        }

        wp_set_password(
            $password,
            $student_user_id
        );

        TutorHelper_Student_Audit_Log::record(
            $student_user_id,
            'password_manually_reset',
            'password'
        );

        self::redirect_student_notice(
            $student_user_id,
            'password_updated',
            'success'
        );
    }


    /**
     * Redirect back to one student with a notice.
     *
     * @param int    $student_user_id Student user ID.
     * @param string $notice          Notice code.
     * @param string $type            Notice type.
     *
     * @return void
     */
    private static function redirect_student_notice(
        $student_user_id,
        $notice,
        $type,
        $args = array()
    ) {
        $redirect_args = array_merge(
            array(
                'student_notice' =>
                    sanitize_key( $notice ),

                'student_notice_type' =>
                    sanitize_key( $type ),
            ),
            is_array( $args )
                ? $args
                : array()
        );

        wp_safe_redirect(
            self::get_student_url(
                $student_user_id,
                $redirect_args
            )
        );

        exit;
    }


}
