<?php
/**
 * Parent Account relationship management.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides the Core administration UI for parent-student relationships.
 */
final class TutorHelper_Student_Parent_Admin {

	/** Link an existing WordPress account. */
	const LINK_ACTION = 'tutorhelper_link_parent_account';

	/** Create and link a Parent Account. */
	const CREATE_ACTION = 'tutorhelper_create_parent_account';

	/** Set the primary Parent Account. */
	const PRIMARY_ACTION = 'tutorhelper_set_primary_parent';

	/** Deactivate one relationship. */
	const UNLINK_ACTION = 'tutorhelper_unlink_parent_account';

	/** Update a relationship label. */
	const RELATIONSHIP_ACTION = 'tutorhelper_update_parent_relationship';

	/** Script handle. */
	const SCRIPT_HANDLE = 'tutorhelper-student-parent-links';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'tutorhelper_students_render_parent_account_controls',
			array( __CLASS__, 'render_manager' ),
			5
		);

		add_action(
			'tutorhelper_students_render_extensions',
			array( __CLASS__, 'render_external_forms' ),
			5
		);

		add_action(
			'admin_post_' . self::LINK_ACTION,
			array( __CLASS__, 'handle_link' )
		);

		add_action(
			'admin_post_' . self::CREATE_ACTION,
			array( __CLASS__, 'handle_create' )
		);

		add_action(
			'admin_post_' . self::PRIMARY_ACTION,
			array( __CLASS__, 'handle_set_primary' )
		);

		add_action(
			'admin_post_' . self::UNLINK_ACTION,
			array( __CLASS__, 'handle_unlink' )
		);

		add_action(
			'admin_post_' . self::RELATIONSHIP_ACTION,
			array( __CLASS__, 'handle_update_relationship' )
		);

		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' ),
			90
		);
	}

	/**
	 * Load the relationship-search script on the Students tab.
	 *
	 * @param string $hook_suffix Current admin screen hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix ) {
			return;
		}

		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing.
			: '';

		if ( TutorHelper_Students_Admin::TAB_KEY !== $tab ) {
			return;
		}

		$path = TUTORHELPER_BOOKINGS_PATH
			. 'assets/js/student-parent-links.js';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_BOOKINGS_URL
				. 'assets/js/student-parent-links.js',
			array(),
			file_exists( $path )
				? (string) filemtime( $path )
				: TUTORHELPER_BOOKINGS_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperParentLinks',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => TutorHelper_Students_Admin::PARENT_SEARCH_ACTION,
				'nonce'   => wp_create_nonce( TutorHelper_Students_Admin::PARENT_SEARCH_ACTION ),
				'strings' => array(
					'minimum'  => __( 'Enter at least two characters.', 'tutorhelper-bookings' ),
					'searching' => __( 'Searching Parent Accounts…', 'tutorhelper-bookings' ),
					'noResults' => __( 'No matching user accounts found.', 'tutorhelper-bookings' ),
					'failed'    => __( 'Parent Accounts could not be searched.', 'tutorhelper-bookings' ),
					'selected'  => __( 'Parent Account selected.', 'tutorhelper-bookings' ),
					'unsaved'   => __( 'You have unsaved Student Details. Save or cancel those changes before managing an additional Parent Account.', 'tutorhelper-bookings' ),
				),
			)
		);
	}

	/**
	 * Render the relationship manager on the Student Details screen.
	 *
	 * @param int $student_id Student user ID.
	 * @return void
	 */
	public static function render_manager( $student_id ) {
		if (
			! TutorHelper_Students::get_student( $student_id )
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$student_id = absint( $student_id );
		$parents    = TutorHelper_Student_Parent_Links::get_parents( $student_id );
		?>
		<div class="tutorhelper-parent-links-manager">
			<header class="tutorhelper-parent-links-manager__header">
				<div>
					<h4><?php esc_html_e( 'Linked Parent Accounts', 'tutorhelper-bookings' ); ?></h4>
					<p><?php esc_html_e( 'Set the primary contact, edit each relationship and manage account access in one place.', 'tutorhelper-bookings' ); ?></p>
				</div>
				<span class="tutorhelper-student-status is-allowed">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %d: number of linked Parent Accounts. */
							_n( '%d linked account', '%d linked accounts', count( $parents ), 'tutorhelper-bookings' ),
							count( $parents )
						)
					);
					?>
				</span>
			</header>

			<?php self::render_notice(); ?>

			<div class="tutorhelper-parent-links-manager__list">
				<?php if ( empty( $parents ) ) : ?>
					<p class="tutorhelper-student-muted"><?php esc_html_e( 'No Parent Accounts are currently linked.', 'tutorhelper-bookings' ); ?></p>
				<?php else : ?>
					<?php foreach ( $parents as $relationship ) : ?>
						<?php self::render_relationship( $student_id, $relationship ); ?>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>

			<?php self::render_link_form( $student_id, empty( $parents ) ); ?>
			<?php self::render_create_form( $student_id, empty( $parents ) ); ?>
		</div>
		<?php
	}

	/**
	 * Render standalone forms after the main Student Details form.
	 *
	 * Visible controls use their form attributes to target these forms, which
	 * avoids invalid nested forms inside the existing student edit workflow.
	 *
	 * @param WP_User $student Student account.
	 * @return void
	 */
	public static function render_external_forms( $student ) {
		if (
			! $student instanceof WP_User
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$student_id = absint( $student->ID );
		$parents    = TutorHelper_Student_Parent_Links::get_parents( $student_id );
		?>
		<form id="<?php echo esc_attr( self::link_form_id( $student_id ) ); ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::LINK_ACTION ); ?>" />
			<input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student_id ); ?>" />
			<?php wp_nonce_field( self::LINK_ACTION . '_' . $student_id ); ?>
		</form>

		<form id="<?php echo esc_attr( self::create_form_id( $student_id ) ); ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::CREATE_ACTION ); ?>" />
			<input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student_id ); ?>" />
			<?php wp_nonce_field( self::CREATE_ACTION . '_' . $student_id ); ?>
		</form>

		<?php foreach ( $parents as $relationship ) : ?>
			<?php self::render_external_action_form( self::PRIMARY_ACTION, $student_id, $relationship->parent_user_id ); ?>
			<?php self::render_external_action_form( self::UNLINK_ACTION, $student_id, $relationship->parent_user_id ); ?>
			<?php self::render_external_action_form( self::RELATIONSHIP_ACTION, $student_id, $relationship->parent_user_id ); ?>
		<?php endforeach; ?>
		<?php
	}

	/**
	 * Render one active relationship.
	 *
	 * @param int    $student_id  Student user ID.
	 * @param object $relationship Relationship record.
	 * @return void
	 */
	private static function render_relationship( $student_id, $relationship ) {
		$parent_id = absint( $relationship->parent_user_id );
		$is_primary = 1 === absint( $relationship->is_primary );
		$relationship_form = self::action_form_id( self::RELATIONSHIP_ACTION, $student_id, $parent_id );
		?>
		<article class="tutorhelper-parent-link">
			<div class="tutorhelper-parent-link__identity">
				<strong><?php echo esc_html( $relationship->display_name ); ?></strong>
				<a href="<?php echo esc_url( 'mailto:' . $relationship->user_email ); ?>"><?php echo esc_html( $relationship->user_email ); ?></a>
				<?php if ( $is_primary ) : ?>
					<span class="tutorhelper-student-status is-allowed"><?php esc_html_e( 'Primary contact', 'tutorhelper-bookings' ); ?></span>
				<?php endif; ?>
				<label for="tutorhelper-parent-relationship-<?php echo esc_attr( $student_id . '-' . $parent_id ); ?>"><?php esc_html_e( 'Relationship', 'tutorhelper-bookings' ); ?></label>
				<input form="<?php echo esc_attr( $relationship_form ); ?>" id="tutorhelper-parent-relationship-<?php echo esc_attr( $student_id . '-' . $parent_id ); ?>" name="relationship_label" type="text" value="<?php echo esc_attr( $relationship->relationship_label ); ?>" />
			</div>

			<div class="tutorhelper-parent-link__actions">
				<?php self::render_action_button( self::RELATIONSHIP_ACTION, $student_id, $parent_id, __( 'Save relationship', 'tutorhelper-bookings' ) ); ?>
				<?php if ( ! $is_primary ) : ?>
					<?php self::render_action_button( self::PRIMARY_ACTION, $student_id, $parent_id, __( 'Make primary', 'tutorhelper-bookings' ) ); ?>
				<?php endif; ?>
				<?php self::render_action_button( self::UNLINK_ACTION, $student_id, $parent_id, __( 'Remove link', 'tutorhelper-bookings' ), true ); ?>
			</div>
		</article>
		<?php
	}

	/**
	 * Render a compact relationship action form.
	 *
	 * @param string $action         Admin-post action.
	 * @param int    $student_id     Student user ID.
	 * @param int    $parent_user_id Parent user ID.
	 * @param string $label          Button label.
	 * @param bool   $destructive    Whether the action removes access.
	 * @return void
	 */
	private static function render_action_button( $action, $student_id, $parent_user_id, $label, $destructive = false ) {
		?>
		<button type="submit" form="<?php echo esc_attr( self::action_form_id( $action, $student_id, $parent_user_id ) ); ?>" class="button tutorhelper-hub-pill-button-small<?php echo $destructive ? ' tutorhelper-parent-link__remove' : ''; ?>" data-parent-immediate-action>
			<?php echo esc_html( $label ); ?>
		</button>
		<?php
	}

	/**
	 * Render the existing-account relationship form.
	 *
	 * @param int  $student_id Student user ID.
	 * @param bool $first_link Whether this will be the first active link.
	 * @return void
	 */
	private static function render_link_form( $student_id, $first_link ) {
		$form_id = self::link_form_id( $student_id );
		?>
		<details class="tutorhelper-parent-links-manager__panel">
			<summary><?php esc_html_e( 'Link an existing account', 'tutorhelper-bookings' ); ?></summary>
			<div class="tutorhelper-parent-links-manager__form" data-tutorhelper-parent-link-search data-student-user-id="<?php echo esc_attr( $student_id ); ?>" data-exclude-linked="1">
				<input form="<?php echo esc_attr( $form_id ); ?>" type="hidden" name="parent_user_id" value="" data-parent-user-id />

				<div class="tutorhelper-student-field is-full-width">
					<label for="tutorhelper-add-parent-<?php echo esc_attr( $student_id ); ?>"><?php esc_html_e( 'Search WordPress accounts', 'tutorhelper-bookings' ); ?></label>
					<input id="tutorhelper-add-parent-<?php echo esc_attr( $student_id ); ?>" type="search" autocomplete="off" placeholder="<?php echo esc_attr__( 'Search by name, username or email', 'tutorhelper-bookings' ); ?>" data-parent-search-input aria-controls="tutorhelper-add-parent-results-<?php echo esc_attr( $student_id ); ?>" />
					<div id="tutorhelper-add-parent-results-<?php echo esc_attr( $student_id ); ?>" class="tutorhelper-parent-link-search__results" role="listbox" hidden data-parent-search-results></div>
					<p class="description" aria-live="polite" data-parent-search-status></p>
					<div data-parent-search-selection></div>
				</div>

				<?php self::render_relationship_fields( $first_link, $form_id ); ?>

				<button form="<?php echo esc_attr( $form_id ); ?>" type="submit" class="button button-primary" disabled data-parent-link-submit data-parent-immediate-action>
					<?php esc_html_e( 'Link Parent Account', 'tutorhelper-bookings' ); ?>
				</button>
			</div>
		</details>
		<?php
	}

	/**
	 * Render the new-account form.
	 *
	 * @param int  $student_id Student user ID.
	 * @param bool $first_link Whether this will be the first active link.
	 * @return void
	 */
	private static function render_create_form( $student_id, $first_link ) {
		$form_id = self::create_form_id( $student_id );
		?>
		<details class="tutorhelper-parent-links-manager__panel">
			<summary><?php esc_html_e( 'Create a new Parent Account', 'tutorhelper-bookings' ); ?></summary>
			<div class="tutorhelper-parent-links-manager__form">

				<div class="tutorhelper-student-fields">
					<div class="tutorhelper-student-field">
						<label for="tutorhelper-parent-first-name-<?php echo esc_attr( $student_id ); ?>"><?php esc_html_e( 'First name', 'tutorhelper-bookings' ); ?></label>
						<input form="<?php echo esc_attr( $form_id ); ?>" id="tutorhelper-parent-first-name-<?php echo esc_attr( $student_id ); ?>" name="first_name" type="text" required />
					</div>
					<div class="tutorhelper-student-field">
						<label for="tutorhelper-parent-last-name-<?php echo esc_attr( $student_id ); ?>"><?php esc_html_e( 'Last name', 'tutorhelper-bookings' ); ?></label>
						<input form="<?php echo esc_attr( $form_id ); ?>" id="tutorhelper-parent-last-name-<?php echo esc_attr( $student_id ); ?>" name="last_name" type="text" required />
					</div>
					<div class="tutorhelper-student-field is-full-width">
						<label for="tutorhelper-parent-email-<?php echo esc_attr( $student_id ); ?>"><?php esc_html_e( 'Email address', 'tutorhelper-bookings' ); ?></label>
						<input form="<?php echo esc_attr( $form_id ); ?>" id="tutorhelper-parent-email-<?php echo esc_attr( $student_id ); ?>" name="user_email" type="email" required />
					</div>
				</div>

				<?php self::render_relationship_fields( $first_link, $form_id ); ?>

				<p class="description"><?php esc_html_e( 'TutorHelper will email the parent a secure link to set their password using the editable New account template.', 'tutorhelper-bookings' ); ?></p>
				<button form="<?php echo esc_attr( $form_id ); ?>" type="submit" class="button button-primary" data-parent-immediate-action><?php esc_html_e( 'Create and link account', 'tutorhelper-bookings' ); ?></button>
			</div>
		</details>
		<?php
	}

	/**
	 * Render fields shared by new and existing relationships.
	 *
	 * @param bool   $first_link Whether the primary field should be forced.
	 * @param string $form_id    External form identifier.
	 * @return void
	 */
	private static function render_relationship_fields( $first_link, $form_id ) {
		?>
		<div class="tutorhelper-student-fields">
			<div class="tutorhelper-student-field">
				<label><?php esc_html_e( 'Relationship', 'tutorhelper-bookings' ); ?></label>
				<input form="<?php echo esc_attr( $form_id ); ?>" name="relationship_label" type="text" value="<?php echo esc_attr__( 'Parent / Guardian', 'tutorhelper-bookings' ); ?>" maxlength="100" />
			</div>
			<label class="tutorhelper-toggle-row">
				<input form="<?php echo esc_attr( $form_id ); ?>" name="is_primary" type="checkbox" value="1" <?php checked( $first_link ); ?> <?php disabled( $first_link ); ?> />
				<?php if ( $first_link ) : ?><input form="<?php echo esc_attr( $form_id ); ?>" name="is_primary" type="hidden" value="1" /><?php endif; ?>
				<span><strong><?php esc_html_e( 'Primary contact', 'tutorhelper-bookings' ); ?></strong><small><?php esc_html_e( 'The primary account supplies linked parent contact details.', 'tutorhelper-bookings' ); ?></small></span>
			</label>
		</div>
		<?php
	}

	/** Render one hidden relationship action form. */
	private static function render_external_action_form( $action, $student_id, $parent_user_id ) {
		?>
		<form id="<?php echo esc_attr( self::action_form_id( $action, $student_id, $parent_user_id ) ); ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden>
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>" />
			<input type="hidden" name="student_user_id" value="<?php echo esc_attr( $student_id ); ?>" />
			<input type="hidden" name="parent_user_id" value="<?php echo esc_attr( $parent_user_id ); ?>" />
			<?php wp_nonce_field( $action . '_' . $student_id . '_' . $parent_user_id ); ?>
		</form>
		<?php
	}

	/** Return the existing-account form ID. */
	private static function link_form_id( $student_id ) {
		return 'tutorhelper-link-parent-account-' . absint( $student_id );
	}

	/** Return the new-account form ID. */
	private static function create_form_id( $student_id ) {
		return 'tutorhelper-create-parent-account-' . absint( $student_id );
	}

	/** Return a relationship action form ID. */
	private static function action_form_id( $action, $student_id, $parent_user_id ) {
		return sanitize_html_class(
			$action . '-' . absint( $student_id ) . '-' . absint( $parent_user_id )
		);
	}

	// phpcs:disable WordPress.Security.NonceVerification.Missing -- Each handler authorises and verifies its action nonce before these helper-level POST reads.
	/** Handle linking an existing account. */
	public static function handle_link() {
		$student_id = self::authorise_request( self::LINK_ACTION );
		$parent_id  = isset( $_POST['parent_user_id'] ) ? absint( $_POST['parent_user_id'] ) : 0;
		$parent     = get_userdata( $parent_id );

		if ( ! $parent instanceof WP_User || $parent_id === $student_id ) {
			self::redirect( $student_id, 'invalid_parent', 'error' );
		}

		if ( ! in_array( TutorHelper_Roles::PARENT_ROLE, (array) $parent->roles, true ) ) {
			$parent->add_role( TutorHelper_Roles::PARENT_ROLE );
		}

		$result = TutorHelper_Student_Parent_Links::link(
			$parent_id,
			$student_id,
			array(
				'relationship_label' => self::posted_relationship_label(),
				'is_primary'         => isset( $_POST['is_primary'] ),
			)
		);

		if ( is_wp_error( $result ) ) {
			self::redirect( $student_id, $result->get_error_code(), 'error' );
		}

		TutorHelper_Student_Audit_Log::record( $student_id, 'parent_account_linked', 'parent_user_id', '', $parent_id );
		self::redirect( $student_id, 'parent_linked', 'success' );
	}

	/** Handle creating and linking a Parent Account. */
	public static function handle_create() {
		$student_id = self::authorise_request( self::CREATE_ACTION );
		$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
		$last_name  = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
		$email      = isset( $_POST['user_email'] ) ? sanitize_email( wp_unslash( $_POST['user_email'] ) ) : '';

		if ( '' === $first_name || '' === $last_name || ! is_email( $email ) ) {
			self::redirect( $student_id, 'parent_details_invalid', 'error' );
		}

		if ( email_exists( $email ) ) {
			self::redirect( $student_id, 'parent_email_exists', 'error' );
		}

		$username = self::unique_username( $email );
		$user_id  = wp_insert_user(
			array(
				'user_login'   => $username,
				'user_email'   => $email,
				'user_pass'    => wp_generate_password( 32, true, true ),
				'display_name' => trim( $first_name . ' ' . $last_name ),
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'role'         => TutorHelper_Roles::PARENT_ROLE,
			)
		);

		if ( is_wp_error( $user_id ) ) {
			self::redirect( $student_id, 'parent_create_failed', 'error' );
		}

		$result = TutorHelper_Student_Parent_Links::link(
			$user_id,
			$student_id,
			array(
				'relationship_label' => self::posted_relationship_label(),
				'is_primary'         => isset( $_POST['is_primary'] ),
			)
		);

		if ( is_wp_error( $result ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( $user_id );
			self::redirect( $student_id, $result->get_error_code(), 'error' );
		}

		$email_result = TutorHelper_Booking_Email_Templates::send_new_account_email(
			$user_id
		);

		TutorHelper_Student_Audit_Log::record( $student_id, 'parent_account_created', 'parent_user_id', '', $user_id );

		if ( is_wp_error( $email_result ) ) {
			self::redirect( $student_id, 'parent_created_email_failed', 'error' );
		}

		self::redirect( $student_id, 'parent_created', 'success' );
	}

	/** Handle setting the primary Parent Account. */
	public static function handle_set_primary() {
		$student_id = self::authorise_pair_request( self::PRIMARY_ACTION );
		$parent_id  = isset( $_POST['parent_user_id'] ) && ! is_array( $_POST['parent_user_id'] ) ? absint( $_POST['parent_user_id'] ) : 0;

		if ( ! TutorHelper_Student_Parent_Links::set_primary( $parent_id, $student_id ) ) {
			self::redirect( $student_id, 'primary_failed', 'error' );
		}

		TutorHelper_Student_Audit_Log::record( $student_id, 'primary_parent_updated', 'parent_user_id', '', $parent_id );
		self::redirect( $student_id, 'primary_updated', 'success' );
	}

	/** Update one relationship label. */
	public static function handle_update_relationship() {
		$student_id = self::authorise_pair_request( self::RELATIONSHIP_ACTION );
		$parent_id  = isset( $_POST['parent_user_id'] ) && ! is_array( $_POST['parent_user_id'] ) ? absint( $_POST['parent_user_id'] ) : 0;
		$result     = TutorHelper_Student_Parent_Links::update_relationship_label(
			$parent_id,
			$student_id,
			self::posted_relationship_label()
		);

		if ( is_wp_error( $result ) ) {
			self::redirect( $student_id, $result->get_error_code(), 'error' );
		}

		TutorHelper_Student_Audit_Log::record( $student_id, 'parent_relationship_updated', 'parent_user_id', $parent_id, $parent_id );
		self::redirect( $student_id, 'relationship_updated', 'success' );
	}

	/** Handle deactivating one relationship. */
	public static function handle_unlink() {
		$student_id = self::authorise_pair_request( self::UNLINK_ACTION );
		$parent_id  = isset( $_POST['parent_user_id'] ) && ! is_array( $_POST['parent_user_id'] ) ? absint( $_POST['parent_user_id'] ) : 0;

		if ( ! TutorHelper_Student_Parent_Links::unlink( $parent_id, $student_id ) ) {
			self::redirect( $student_id, 'unlink_failed', 'error' );
		}

		TutorHelper_Student_Audit_Log::record( $student_id, 'parent_account_unlinked', 'parent_user_id', $parent_id, '' );
		self::redirect( $student_id, 'parent_unlinked', 'success' );
	}

	// phpcs:enable WordPress.Security.NonceVerification.Missing

	/**
	 * Authorise a relationship request containing a student only.
	 *
	 * @param string $action Nonce action.
	 * @return int Student user ID.
	 */
	private static function authorise_request( $action ) {
		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Parent Accounts.', 'tutorhelper-bookings' ) );
		}

		$student_id = isset( $_POST['student_user_id'] ) && ! is_array( $_POST['student_user_id'] ) ? absint( $_POST['student_user_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Required to construct the action-specific nonce; verification follows immediately.
		check_admin_referer( $action . '_' . $student_id );

		if ( ! TutorHelper_Students::get_student( $student_id ) ) {
			wp_die( esc_html__( 'The student account could not be found.', 'tutorhelper-bookings' ) );
		}

		return $student_id;
	}

	/** Authorise a relationship request containing a student and parent. */
	private static function authorise_pair_request( $action ) {
		$student_id = isset( $_POST['student_user_id'] ) && ! is_array( $_POST['student_user_id'] ) ? absint( $_POST['student_user_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Required to construct the action-specific nonce; verification follows below.
		$parent_id  = isset( $_POST['parent_user_id'] ) && ! is_array( $_POST['parent_user_id'] ) ? absint( $_POST['parent_user_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Required to construct the action-specific nonce; verification follows below.

		if ( ! current_user_can( TutorHelper_Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage Parent Accounts.', 'tutorhelper-bookings' ) );
		}

		check_admin_referer( $action . '_' . $student_id . '_' . $parent_id );

		if ( ! TutorHelper_Students::get_student( $student_id ) ) {
			wp_die( esc_html__( 'The student account could not be found.', 'tutorhelper-bookings' ) );
		}

		return $student_id;
	}

	/** Return the submitted relationship label. */
	private static function posted_relationship_label() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Called only after the relevant action nonce has been verified.
		$label = isset( $_POST['relationship_label'] )
			? sanitize_text_field( wp_unslash( $_POST['relationship_label'] ) )
			: '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return '' !== $label
			? $label
			: __( 'Parent / Guardian', 'tutorhelper-bookings' );
	}

	/** Generate a unique login from an email address. */
	private static function unique_username( $email ) {
		$parts = explode( '@', $email );
		$base  = sanitize_user( $parts[0], true );
		$base  = '' !== $base ? $base : 'parent';
		$name  = $base;
		$count = 2;

		while ( username_exists( $name ) ) {
			$name = $base . $count;
			++$count;
		}

		return $name;
	}

	/** Render one manager-specific notice. */
	private static function render_notice() {
		$code = isset( $_GET['parent_notice'] ) && ! is_array( $_GET['parent_notice'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			? sanitize_key( wp_unslash( $_GET['parent_notice'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			: '';
		$type = isset( $_GET['parent_notice_type'] ) && ! is_array( $_GET['parent_notice_type'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			? sanitize_key( wp_unslash( $_GET['parent_notice_type'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only feedback state.
			: 'success';
		$messages = array(
			'parent_linked'         => __( 'Parent Account linked.', 'tutorhelper-bookings' ),
			'parent_created'        => __( 'Parent Account created and linked. TutorHelper has sent the editable New account email.', 'tutorhelper-bookings' ),
			'parent_created_email_failed' => __( 'Parent Account created and linked, but TutorHelper could not send the New account email. Check TutorHelper Diagnostics and Email delivery history before sending a password reset.', 'tutorhelper-bookings' ),
			'parent_unlinked'       => __( 'Parent Account link removed.', 'tutorhelper-bookings' ),
			'primary_updated'       => __( 'Primary Parent Account updated.', 'tutorhelper-bookings' ),
			'invalid_parent'        => __( 'Select a valid Parent Account.', 'tutorhelper-bookings' ),
			'parent_details_invalid' => __( 'Enter the parent’s first name, last name and a valid email address.', 'tutorhelper-bookings' ),
			'parent_email_exists'   => __( 'That email address already belongs to a WordPress account. Use “Link an existing account” instead.', 'tutorhelper-bookings' ),
			'parent_create_failed'  => __( 'The Parent Account could not be created.', 'tutorhelper-bookings' ),
			'primary_failed'        => __( 'The primary Parent Account could not be updated.', 'tutorhelper-bookings' ),
			'unlink_failed'         => __( 'The Parent Account link could not be removed.', 'tutorhelper-bookings' ),
			'tutorhelper_parent_link_failed' => __( 'The Parent Account could not be linked.', 'tutorhelper-bookings' ),
		);

		if ( ! isset( $messages[ $code ] ) ) {
			return;
		}
		?>
		<div class="notice <?php echo 'error' === $type ? 'notice-error' : 'notice-success'; ?> inline">
			<p><?php echo esc_html( $messages[ $code ] ); ?></p>
		</div>
		<?php
	}

	/** Redirect back to Student Details. */
	private static function redirect( $student_id, $notice, $type ) {
		$url = add_query_arg(
			array(
				'page'               => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab'                => TutorHelper_Students_Admin::TAB_KEY,
				'student_id'         => absint( $student_id ),
				'student_mode'       => 'edit',
				'parent_notice'      => sanitize_key( $notice ),
				'parent_notice_type' => sanitize_key( $type ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
