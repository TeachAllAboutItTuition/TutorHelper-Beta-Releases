<?php
/**
 * Student detail quality-of-life controls.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds previous/next navigation and promotes the student save action.
 */
final class TutorHelper_Student_Admin_QOL {

	const SCRIPT_HANDLE = 'tutorhelper-student-admin-qol';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'admin_enqueue_scripts',
			array( __CLASS__, 'enqueue_assets' ),
			40
		);
	}

	/**
	 * Enqueue controls only on an individual Student detail screen.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if (
			'toplevel_page_' . TutorHelper_Admin::MENU_SLUG !== $hook_suffix
			|| ! current_user_can( TutorHelper_Admin::CAPABILITY )
		) {
			return;
		}

		$page = isset( $_GET['page'] ) && ! is_array( $_GET['page'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? sanitize_key( wp_unslash( $_GET['page'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: '';
		$tab = isset( $_GET['tab'] ) && ! is_array( $_GET['tab'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: '';
		$student_id = isset( $_GET['student_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? absint( $_GET['student_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: 0;

		if (
			TutorHelper_Booking_Hub::PAGE_SLUG !== $page
			|| TutorHelper_Students_Admin::TAB_KEY !== $tab
			|| ! $student_id
		) {
			return;
		}

		$student = TutorHelper_Students::get_student( $student_id );
		if ( ! $student ) {
			return;
		}

		$mode = isset( $_GET['student_mode'] ) && ! is_array( $_GET['student_mode'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			? sanitize_key( wp_unslash( $_GET['student_mode'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation state.
			: 'view';
		$mode = 'edit' === $mode ? 'edit' : 'view';

		$neighbours = self::get_neighbouring_students( $student_id );
		$script_path = TUTORHELPER_BOOKINGS_PATH . 'assets/js/student-admin-qol.js';

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			TUTORHELPER_BOOKINGS_URL . 'assets/js/student-admin-qol.js',
			array(),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : TUTORHELPER_BOOKINGS_VERSION,
			true
		);

		TutorHelper_Student_Dashboard_Frontend::register_assets();
		wp_enqueue_script(
			TutorHelper_Student_Dashboard_Frontend::PASSWORD_SCRIPT_HANDLE
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'tutorhelperStudentAdminQol',
			array(
				'previousUrl' => $neighbours['previous']
					? self::get_student_url( $neighbours['previous'], $mode )
					: '',
				'nextUrl' => $neighbours['next']
					? self::get_student_url( $neighbours['next'], $mode )
					: '',
				'labels' => array(
					'previous' => __( 'Previous student', 'tutorhelper-bookings' ),
					'next' => __( 'Next student', 'tutorhelper-bookings' ),
				),
			)
		);
	}

	/**
	 * Find adjacent students in the same alphabetical order used by Core.
	 *
	 * @param int $student_id Current student ID.
	 * @return array
	 */
	private static function get_neighbouring_students( $student_id ) {
		$query = new WP_User_Query(
			array(
				'role' => TutorHelper_Students::STUDENT_ROLE,
				'fields' => 'ID',
				'number' => -1,
				'orderby' => 'display_name',
				'order' => 'ASC',
				'count_total' => false,
			)
		);

		$ids = array_values( array_map( 'absint', $query->get_results() ) );
		$index = array_search( absint( $student_id ), $ids, true );

		if ( false === $index ) {
			return array( 'previous' => 0, 'next' => 0 );
		}

		return array(
			'previous' => 0 < $index ? $ids[ $index - 1 ] : 0,
			'next' => isset( $ids[ $index + 1 ] ) ? $ids[ $index + 1 ] : 0,
		);
	}

	/**
	 * Build a Student detail URL while preserving View/Edit mode.
	 *
	 * @param int    $student_id Student ID.
	 * @param string $mode Detail mode.
	 * @return string
	 */
	private static function get_student_url( $student_id, $mode ) {
		return add_query_arg(
			array(
				'page' => TutorHelper_Booking_Hub::PAGE_SLUG,
				'tab' => TutorHelper_Students_Admin::TAB_KEY,
				'student_id' => absint( $student_id ),
				'student_mode' => 'edit' === $mode ? 'edit' : 'view',
			),
			admin_url( 'admin.php' )
		);
	}
}
