<?php
/**
 * Parent-student relationship service.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Owns the canonical many-to-many relationship between Parent and Student accounts.
 */
final class TutorHelper_Student_Parent_Links {

	/** Active relationship status. */
	const STATUS_ACTIVE = 'active';

	/** Inactive relationship status. */
	const STATUS_INACTIVE = 'inactive';

	/** Migration completion option. */
	const MIGRATION_OPTION = 'tutorhelper_parent_links_migration_version';

	/** Current migration version. */
	const MIGRATION_VERSION = '1.0.0';

	/**
	 * Register compatibility hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'added_user_meta',
			array( __CLASS__, 'sync_legacy_parent_meta' ),
			10,
			4
		);

		add_action(
			'updated_user_meta',
			array( __CLASS__, 'sync_legacy_parent_meta' ),
			10,
			4
		);

		add_action(
			'deleted_user_meta',
			array( __CLASS__, 'sync_deleted_legacy_parent_meta' ),
			10,
			4
		);
	}

	/**
	 * Return the relationship table name.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		return TutorHelper_Bookings_Database::get_table_name(
			'student_parent_links'
		);
	}

	/**
	 * Whether the relationship table is installed.
	 *
	 * @return bool
	 */
	public static function table_exists() {
		global $wpdb;

		$table = self::get_table_name();

		if ( '' === $table ) {
			return false;
		}

		$found = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Installation diagnostic must inspect the current schema.
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $table )
		);

		return $table === $found;
	}

	/**
	 * Create or reactivate a relationship.
	 *
	 * @param int   $parent_user_id  Parent WordPress user ID.
	 * @param int   $student_user_id Student WordPress user ID.
	 * @param array $args            Relationship attributes.
	 * @return int|WP_Error Relationship ID or an error.
	 */
	public static function link( $parent_user_id, $student_user_id, $args = array() ) {
		global $wpdb;

		$parent_user_id  = absint( $parent_user_id );
		$student_user_id = absint( $student_user_id );
		$parent          = get_userdata( $parent_user_id );
		$student         = TutorHelper_Students::get_student( $student_user_id );

		if (
			! $parent instanceof WP_User
			|| ! in_array( TutorHelper_Roles::PARENT_ROLE, (array) $parent->roles, true )
		) {
			return new WP_Error(
				'tutorhelper_parent_account_invalid',
				__( 'Select a valid TutorHelper Parent account.', 'tutorhelper-bookings' )
			);
		}

		if ( ! $student instanceof WP_User ) {
			return new WP_Error(
				'tutorhelper_student_account_invalid',
				__( 'Select a valid TutorHelper Student account.', 'tutorhelper-bookings' )
			);
		}

		$args = wp_parse_args(
			$args,
			array(
				'relationship_label' => __( 'Parent / Guardian', 'tutorhelper-bookings' ),
				'is_primary'         => null,
				'created_by'         => get_current_user_id(),
			)
		);

		$table       = self::get_table_name();
		$existing_id = absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Relationship writes require current state.
				$wpdb->prepare(
					'SELECT id FROM %i WHERE parent_user_id = %d AND student_user_id = %d LIMIT 1',
					$table,
					$parent_user_id,
					$student_user_id
				)
			)
		);

		$is_primary = null === $args['is_primary']
			? ! self::get_primary_parent( $student_user_id )
			: (bool) $args['is_primary'];

		if (
			! $is_primary
			&& $existing_id
			&& self::is_primary( $parent_user_id, $student_user_id )
		) {
			$is_primary = true;
		}

		if ( $is_primary ) {
			self::clear_primary( $student_user_id );
		}

		$now  = current_time( 'mysql', true );
		$data = array(
			'parent_user_id'   => $parent_user_id,
			'student_user_id'  => $student_user_id,
			'relationship_label' => sanitize_text_field( $args['relationship_label'] ),
			'is_primary'       => $is_primary ? 1 : 0,
			'status'           => self::STATUS_ACTIVE,
			'updated_at'       => $now,
		);

		if ( $existing_id ) {
			$result = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Canonical relationship write.
				$table,
				$data,
				array( 'id' => $existing_id ),
				array( '%d', '%d', '%s', '%d', '%s', '%s' ),
				array( '%d' )
			);
			$relationship_id = $existing_id;
		} else {
			$data['created_by_user_id'] = absint( $args['created_by'] );
			$data['created_at']         = $now;

			$result = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Canonical relationship write.
				$table,
				$data,
				array( '%d', '%d', '%s', '%d', '%s', '%s', '%d', '%s' )
			);
			$relationship_id = absint( $wpdb->insert_id );
		}

		if ( false === $result ) {
			return new WP_Error(
				'tutorhelper_parent_link_failed',
				__( 'The parent account could not be linked to this student.', 'tutorhelper-bookings' )
			);
		}

		if ( $is_primary ) {
			update_user_meta(
				$student_user_id,
				TutorHelper_Students::META_PARENT_USER_ID,
				$parent_user_id
			);
		}

		do_action(
			'tutorhelper_parent_student_linked',
			$relationship_id,
			$parent_user_id,
			$student_user_id
		);

		return $relationship_id;
	}

	/**
	 * Deactivate a relationship without destroying its history.
	 *
	 * @param int $parent_user_id  Parent WordPress user ID.
	 * @param int $student_user_id Student WordPress user ID.
	 * @return bool
	 */
	/**
	 * Update the label shown for one active Parent Account relationship.
	 *
	 * @param int    $parent_user_id Parent user ID.
	 * @param int    $student_user_id Student user ID.
	 * @param string $relationship_label Relationship label.
	 *
	 * @return true|WP_Error
	 */
	public static function update_relationship_label(
		$parent_user_id,
		$student_user_id,
		$relationship_label
	) {
		global $wpdb;

		$parent_user_id    = absint( $parent_user_id );
		$student_user_id   = absint( $student_user_id );
		$relationship_label = sanitize_text_field( $relationship_label );

		if ( ! $parent_user_id || ! $student_user_id ) {
			return new WP_Error(
				'tutorhelper_parent_link_missing',
				__( 'A Parent Account and student are required.', 'tutorhelper-bookings' )
			);
		}

		if ( '' === $relationship_label ) {
			$relationship_label = __( 'Parent / Guardian', 'tutorhelper-bookings' );
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- This authorised relationship mutation must be immediately visible to access checks.
			self::get_table_name(),
			array( 'relationship_label' => $relationship_label ),
			array(
				'parent_user_id'  => $parent_user_id,
				'student_user_id' => $student_user_id,
				'status'          => self::STATUS_ACTIVE,
			),
			array( '%s' ),
			array( '%d', '%d', '%s' )
		);

		if ( false === $updated ) {
			return new WP_Error(
				'tutorhelper_parent_link_update_failed',
				__( 'The relationship could not be updated.', 'tutorhelper-bookings' )
			);
		}

		if ( 0 === $updated && ! self::is_linked( $parent_user_id, $student_user_id ) ) {
			return new WP_Error(
				'tutorhelper_parent_link_not_found',
				__( 'That Parent Account is no longer linked to this student.', 'tutorhelper-bookings' )
			);
		}

		return true;
	}

	public static function unlink( $parent_user_id, $student_user_id ) {
		global $wpdb;

		$parent_user_id  = absint( $parent_user_id );
		$student_user_id = absint( $student_user_id );
		$table           = self::get_table_name();
		$was_primary     = self::is_primary( $parent_user_id, $student_user_id );

		$result = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Soft removal preserves relationship history.
			$table,
			array(
				'status'     => self::STATUS_INACTIVE,
				'is_primary' => 0,
				'updated_at' => current_time( 'mysql', true ),
			),
			array(
				'parent_user_id'  => $parent_user_id,
				'student_user_id' => $student_user_id,
			),
			array( '%s', '%d', '%s' ),
			array( '%d', '%d' )
		);

		if ( false === $result ) {
			return false;
		}

		if ( $was_primary ) {
			self::promote_first_active_parent( $student_user_id );
		}

		do_action(
			'tutorhelper_parent_student_unlinked',
			$parent_user_id,
			$student_user_id
		);

		return true;
	}

	/**
	 * Return active parent relationships for a student.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @return array
	 */
	public static function get_parents( $student_user_id ) {
		global $wpdb;

		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Permissions require current relationship data.
			$wpdb->prepare(
				'SELECT links.*, users.display_name, users.user_email
				FROM %i AS links
				INNER JOIN %i AS users ON users.ID = links.parent_user_id
				WHERE links.student_user_id = %d AND links.status = %s
				ORDER BY links.is_primary DESC, users.display_name ASC',
				self::get_table_name(),
				$wpdb->users,
				absint( $student_user_id ),
				self::STATUS_ACTIVE
			)
		);
	}

	/**
	 * Return active student relationships for a parent.
	 *
	 * @param int $parent_user_id Parent WordPress user ID.
	 * @return array
	 */
	public static function get_students( $parent_user_id ) {
		global $wpdb;

		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Permissions require current relationship data.
			$wpdb->prepare(
				'SELECT links.*, users.display_name, users.user_email
				FROM %i AS links
				INNER JOIN %i AS users ON users.ID = links.student_user_id
				WHERE links.parent_user_id = %d AND links.status = %s
				ORDER BY users.display_name ASC',
				self::get_table_name(),
				$wpdb->users,
				absint( $parent_user_id ),
				self::STATUS_ACTIVE
			)
		);
	}

	/**
	 * Whether a parent has an active relationship with a student.
	 *
	 * @param int $parent_user_id  Parent WordPress user ID.
	 * @param int $student_user_id Student WordPress user ID.
	 * @return bool
	 */
	public static function is_linked( $parent_user_id, $student_user_id ) {
		global $wpdb;

		$count = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- This is an authorisation boundary and must use current data.
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE parent_user_id = %d AND student_user_id = %d AND status = %s',
				self::get_table_name(),
				absint( $parent_user_id ),
				absint( $student_user_id ),
				self::STATUS_ACTIVE
			)
		);

		return 0 < absint( $count );
	}

	/**
	 * Return the primary active parent relationship for a student.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @return object|null
	 */
	public static function get_primary_parent( $student_user_id ) {
		global $wpdb;

		return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Primary contact must reflect the latest relationship state.
			$wpdb->prepare(
				'SELECT * FROM %i WHERE student_user_id = %d AND status = %s AND is_primary = 1 LIMIT 1',
				self::get_table_name(),
				absint( $student_user_id ),
				self::STATUS_ACTIVE
			)
		);
	}

	/**
	 * Make an active link the primary relationship.
	 *
	 * @param int $parent_user_id  Parent WordPress user ID.
	 * @param int $student_user_id Student WordPress user ID.
	 * @return bool
	 */
	public static function set_primary( $parent_user_id, $student_user_id ) {
		global $wpdb;

		if ( ! self::is_linked( $parent_user_id, $student_user_id ) ) {
			return false;
		}

		self::clear_primary( $student_user_id );

		$result = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Canonical relationship write.
			self::get_table_name(),
			array(
				'is_primary' => 1,
				'updated_at' => current_time( 'mysql', true ),
			),
			array(
				'parent_user_id'  => absint( $parent_user_id ),
				'student_user_id' => absint( $student_user_id ),
				'status'          => self::STATUS_ACTIVE,
			),
			array( '%d', '%s' ),
			array( '%d', '%d', '%s' )
		);

		if ( false === $result ) {
			return false;
		}

		update_user_meta(
			absint( $student_user_id ),
			TutorHelper_Students::META_PARENT_USER_ID,
			absint( $parent_user_id )
		);

		return true;
	}

	/**
	 * Import Core's existing single-parent metadata once.
	 *
	 * @return int Number of relationships imported.
	 */
	public static function migrate_legacy_links() {
		if ( self::MIGRATION_VERSION === get_option( self::MIGRATION_OPTION, '' ) ) {
			return 0;
		}

		$imported = 0;
		$page     = 1;

		do {
			$query = new WP_User_Query(
				array(
					'role'       => TutorHelper_Roles::STUDENT_ROLE,
					'fields'     => 'ID',
					'number'     => 100,
					'paged'      => $page,
					'meta_key'   => TutorHelper_Students::META_PARENT_USER_ID, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One-time bounded compatibility migration.
					'meta_compare' => 'EXISTS',
				)
			);

			$student_ids = $query->get_results();

			foreach ( $student_ids as $student_user_id ) {
				$parent_user_id = absint(
					get_user_meta(
						$student_user_id,
						TutorHelper_Students::META_PARENT_USER_ID,
						true
					)
				);

				if ( ! $parent_user_id ) {
					continue;
				}

				$result = self::link(
					$parent_user_id,
					$student_user_id,
					array(
						'is_primary' => true,
						'created_by' => 0,
					)
				);

				if ( ! is_wp_error( $result ) ) {
					++$imported;
				}
			}

			++$page;
		} while ( 100 === count( $student_ids ) );

		update_option( self::MIGRATION_OPTION, self::MIGRATION_VERSION, false );

		TutorHelper_Logger::success(
			'Parent account relationships migrated.',
			array( 'relationship_count' => $imported )
		);

		return $imported;
	}

	/**
	 * Keep legacy single-parent updates represented in the relationship table.
	 *
	 * @param int    $meta_id         Metadata row ID.
	 * @param int    $student_user_id Student user ID.
	 * @param string $meta_key        Metadata key.
	 * @param mixed  $meta_value      Metadata value.
	 * @return void
	 */
	public static function sync_legacy_parent_meta(
		$meta_id,
		$student_user_id,
		$meta_key,
		$meta_value
	) {
		unset( $meta_id );

		if ( TutorHelper_Students::META_PARENT_USER_ID !== $meta_key ) {
			return;
		}

		$parent_user_id = absint( $meta_value );

		if ( ! $parent_user_id ) {
			return;
		}

		self::link(
			$parent_user_id,
			absint( $student_user_id ),
			array( 'is_primary' => true )
		);
	}

	/**
	 * Deactivate the old primary relationship when legacy metadata is removed.
	 *
	 * @param int[]  $meta_ids        Deleted metadata row IDs.
	 * @param int    $student_user_id Student user ID.
	 * @param string $meta_key        Metadata key.
	 * @param mixed  $meta_value      Deleted metadata value.
	 * @return void
	 */
	public static function sync_deleted_legacy_parent_meta(
		$meta_ids,
		$student_user_id,
		$meta_key,
		$meta_value
	) {
		unset( $meta_ids );

		if ( TutorHelper_Students::META_PARENT_USER_ID !== $meta_key ) {
			return;
		}

		$parent_user_id  = absint( $meta_value );
		$student_user_id = absint( $student_user_id );

		if (
			! $parent_user_id
			|| ! self::is_linked( $parent_user_id, $student_user_id )
		) {
			return;
		}

		self::unlink( $parent_user_id, $student_user_id );
	}

	/**
	 * Whether one active link is primary.
	 *
	 * @param int $parent_user_id  Parent WordPress user ID.
	 * @param int $student_user_id Student WordPress user ID.
	 * @return bool
	 */
	private static function is_primary( $parent_user_id, $student_user_id ) {
		global $wpdb;

		$value = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Relationship write requires current state.
			$wpdb->prepare(
				'SELECT is_primary FROM %i WHERE parent_user_id = %d AND student_user_id = %d AND status = %s LIMIT 1',
				self::get_table_name(),
				absint( $parent_user_id ),
				absint( $student_user_id ),
				self::STATUS_ACTIVE
			)
		);

		return 1 === absint( $value );
	}

	/**
	 * Remove the primary flag from active relationships for one student.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @return void
	 */
	private static function clear_primary( $student_user_id ) {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Canonical relationship write.
			self::get_table_name(),
			array(
				'is_primary' => 0,
				'updated_at' => current_time( 'mysql', true ),
			),
			array(
				'student_user_id' => absint( $student_user_id ),
				'status'          => self::STATUS_ACTIVE,
			),
			array( '%d', '%s' ),
			array( '%d', '%s' )
		);
	}

	/**
	 * Promote the oldest remaining active relationship after unlinking a primary.
	 *
	 * @param int $student_user_id Student WordPress user ID.
	 * @return void
	 */
	private static function promote_first_active_parent( $student_user_id ) {
		global $wpdb;

		$parent_user_id = absint(
			$wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Primary contact repair requires current data.
				$wpdb->prepare(
					'SELECT parent_user_id FROM %i WHERE student_user_id = %d AND status = %s ORDER BY created_at ASC, id ASC LIMIT 1',
					self::get_table_name(),
					absint( $student_user_id ),
					self::STATUS_ACTIVE
				)
			)
		);

		if ( $parent_user_id ) {
			self::set_primary( $parent_user_id, $student_user_id );
			return;
		}

		delete_user_meta(
			absint( $student_user_id ),
			TutorHelper_Students::META_PARENT_USER_ID
		);
	}
}
