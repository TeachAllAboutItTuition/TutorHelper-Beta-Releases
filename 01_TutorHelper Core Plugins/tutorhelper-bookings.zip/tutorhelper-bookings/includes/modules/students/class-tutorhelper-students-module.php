<?php
/**
 * TutorHelper Student Management module loader.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads Student Management components where required.
 */
final class TutorHelper_Students_Module {

	/**
	 * Initialise the Student Management module.
	 *
	 * @return void
	 */
	public static function init() {
		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/students/'
			. 'class-tutorhelper-students.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/students/'
            . 'class-tutorhelper-student-audit-log.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/students/'
			. 'class-tutorhelper-student-data.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/students/'
			. 'class-tutorhelper-student-parent-links.php';

		TutorHelper_Students::init();
		TutorHelper_Student_Data::init();
		TutorHelper_Student_Parent_Links::init();

		/*
		 * Student Management currently exposes only its wp-admin shell.
		 *
		 * The shared Students class is deliberately loaded outside this
		 * condition so it can later support the frontend Student Hub.
		 */
		if ( ! is_admin() ) {
			return;
		}

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/students/'
			. 'class-tutorhelper-students-admin.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/students/'
			. 'class-tutorhelper-student-parent-admin.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/students/'
			. 'class-tutorhelper-students-diagnostics.php';

		require_once TUTORHELPER_BOOKINGS_PATH
			. 'includes/modules/students/'
			. 'class-tutorhelper-student-admin-qol.php';

		TutorHelper_Students_Admin::init();
		TutorHelper_Student_Parent_Admin::init();
		TutorHelper_Students_Diagnostics::init();
		TutorHelper_Student_Admin_QOL::init();
	}
}
