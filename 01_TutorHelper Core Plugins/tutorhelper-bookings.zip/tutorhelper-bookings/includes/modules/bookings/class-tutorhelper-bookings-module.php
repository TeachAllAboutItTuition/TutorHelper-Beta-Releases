<?php
/**
 * TutorHelper Bookings records module.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the shared booking records service.
 */
final class TutorHelper_Bookings_Module {

	/**
	 * Initialise the module.
	 *
	 * @return void
	 */
	public static function init() {
        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/emails/'
            . 'class-tutorhelper-emails-module.php';

        TutorHelper_Emails_Module::init();

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-records.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-location-inheritance.php';

        TutorHelper_Booking_Location_Inheritance::init();

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-conditions.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-tutor-resolver.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-student-booking-request.php';
        
        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-calendar-data.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-tutor-booking-save.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-tutor-booking-update.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-recurrence.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-email-templates.php';

        TutorHelper_Booking_Email_Templates::register();

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-email-context.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/bookings/'
            . 'class-tutorhelper-booking-email-events.php';

        TutorHelper_Booking_Email_Events::init();


        if ( is_admin() ) {
            require_once TUTORHELPER_BOOKINGS_PATH
                . 'includes/modules/bookings/'
                . 'class-tutorhelper-booking-email-admin.php';

            TutorHelper_Booking_Email_Admin::init();
        }


        if ( is_admin() ) {
            require_once TUTORHELPER_BOOKINGS_PATH
                . 'includes/modules/bookings/'
                . 'class-tutorhelper-booking-calendar-admin.php';

            require_once TUTORHELPER_BOOKINGS_PATH
                . 'includes/modules/bookings/'
                . 'class-tutorhelper-tutor-booking-admin.php';

            TutorHelper_Booking_Calendar_Admin::init();
            TutorHelper_Tutor_Booking_Admin::init();
        }

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/student-booking/'
            . 'class-tutorhelper-student-booking-module.php';

        TutorHelper_Student_Booking_Module::init();

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/student-dashboard/'
            . 'class-tutorhelper-student-dashboard-module.php';

        TutorHelper_Student_Dashboard_Module::init();

    }
}
