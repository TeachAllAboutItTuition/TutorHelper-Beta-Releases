<?php
/**
 * TutorHelper Booking email definitions.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the Core email templates used by Bookings.
 */
final class TutorHelper_Booking_Email_Templates {

	/**
	 * Tutor notification for a new student request.
	 *
	 * @var string
	 */
	const STUDENT_REQUEST_TUTOR =
		'booking_student_request_tutor';

	/**
	 * Student acknowledgement for a submitted request.
	 *
	 * @var string
	 */
	const STUDENT_REQUEST_RECEIVED =
		'booking_student_request_received';

	/**
	 * Student notification for a confirmed lesson.
	 *
	 * @var string
	 */
	const STUDENT_BOOKING_CONFIRMED =
		'booking_student_confirmed';

	/**
	 * Student notification for a cancelled lesson.
	 *
	 * @var string
	 */
	const STUDENT_BOOKING_CANCELLED =
		'booking_student_cancelled';


	/**
	 * Tutor notification when a student cancels a lesson.
	 *
	 * @var string
	 */
	const STUDENT_CANCELLED_TUTOR =
		'booking_student_cancelled_tutor';

	/** New TutorHelper account email. */
	const ACCOUNT_CREATED = 'account_created';

	/** TutorHelper password reset email. */
	const PASSWORD_RESET = 'account_password_reset';


	/**
	 * Register Booking email templates.
	 *
	 * @return void
	 */
	public static function register() {
		self::register_student_request_tutor();

		self::register_student_request_received();

		self::register_student_booking_confirmed();

		self::register_student_booking_cancelled();

		self::register_student_cancelled_tutor();

		self::register_account_templates();

		add_filter( 'wp_new_user_notification_email', array( __CLASS__, 'filter_new_account_email' ), 20, 3 );
		add_filter( 'retrieve_password_notification_email', array( __CLASS__, 'filter_password_reset_email' ), 20, 4 );
	}

	/**
	 * Register the tutor's new-request notification.
	 *
	 * @return void
	 */
	private static function register_student_request_tutor() {
		TutorHelper_Email_Templates::register(
			self::STUDENT_REQUEST_TUTOR,
			array(
				'module' =>
					'bookings',

				'label' =>
					__(
						'New lesson request — Tutor',
						'tutorhelper-bookings'
					),

				'description' =>
					__(
						'Sent to the tutor when a student submits a new lesson request.',
						'tutorhelper-bookings'
					),

				'heading' =>
					__(
						'New Lesson Request',
						'tutorhelper-bookings'
					),

				'recipient' =>
					'tutor',

				'enabled' =>
					true,

				'subject' =>
					__(
						'New lesson request from {student_name}',
						'tutorhelper-bookings'
					),

				'body' =>
					__(
						"Hello {tutor_name},\n\n{student_name} has requested a {booking_type} lesson.\n\nDate: {lesson_date}\nTime: {lesson_time}\nLocation: {location_type}\nStatus: Awaiting confirmation\n\nStudent notes:\n{student_notes}\n\nPlease review the request in your TutorHelper calendar:\n{calendar_url}\n\nIf you would like to accept the request, open the booking and change its status to Confirmed.\n\nBest wishes,\nTutorHelper",
						'tutorhelper-bookings'
					),

				'placeholders' =>
					array(
						'{student_name}',
						'{first_name}',
						'{student_email}',
						'{booking_type}',
						'{lesson_date}',
						'{lesson_time}',
						'{location_type}',
						'{student_notes}',
						'{tutor_name}',
						'{site_name}',
						'{calendar_url}',
					),
			)
		);
	}

	/**
	 * Register the student request acknowledgement.
	 *
	 * @return void
	 */
	private static function register_student_request_received() {
		TutorHelper_Email_Templates::register(
			self::STUDENT_REQUEST_RECEIVED,
			array(
				'module' =>
					'bookings',

				'label' =>
					__(
						'Lesson request received — Student',
						'tutorhelper-bookings'
					),

				'description' =>
					__(
						'Sent to the student after they submit a new lesson request.',
						'tutorhelper-bookings'
					),

				'heading' =>
					__(
						'Lesson Request Received',
						'tutorhelper-bookings'
					),

				'recipient' =>
					'student',

				'enabled' =>
					true,

				'subject' =>
					__(
						'We have received your {booking_type} lesson request',
						'tutorhelper-bookings'
					),

				'body' =>
					__(
						"Hello {student_name},\n\nYour lesson request has been sent to {tutor_name} and is awaiting confirmation.\n\nLesson: {booking_type}\nDate: {lesson_date}\nTime: {lesson_time}\nLocation: {location_type}\n\nYou can view your lessons here:\n{student_dashboard_url}\n\nBest wishes,\n{tutor_name}",
						'tutorhelper-bookings'
					),

				'placeholders' =>
					array(
						'{student_name}',
						'{first_name}',
						'{booking_type}',
						'{lesson_date}',
						'{lesson_time}',
						'{location_type}',
						'{tutor_name}',
						'{site_name}',
						'{student_dashboard_url}',
					),
			)
		);
	}

	/**
	 * Register the student confirmation notification.
	 *
	 * @return void
	 */
	private static function register_student_booking_confirmed() {
		TutorHelper_Email_Templates::register(
			self::STUDENT_BOOKING_CONFIRMED,
			array(
				'module' =>
					'bookings',

				'label' =>
					__(
						'Lesson confirmed — Student',
						'tutorhelper-bookings'
					),

				'description' =>
					__(
						'Sent to the student when their lesson is confirmed.',
						'tutorhelper-bookings'
					),

				'heading' =>
					__(
						'Lesson Confirmed',
						'tutorhelper-bookings'
					),

				'recipient' =>
					'student',

				'enabled' =>
					true,

				'subject' =>
					__(
						'Your {booking_type} lesson is confirmed',
						'tutorhelper-bookings'
					),

				'body' =>
					__(
						"Hello {student_name},\n\nYour lesson has been confirmed.\n\nLesson: {booking_type}\nDate: {lesson_date}\nTime: {lesson_time}\nLocation: {location_type}\n\n{joining_details}\n\nYou can view your lessons here:\n{student_dashboard_url}\n\nBest wishes,\n{tutor_name}",
						'tutorhelper-bookings'
					),

				'placeholders' =>
					array(
						'{student_name}',
						'{first_name}',
						'{booking_type}',
						'{lesson_date}',
						'{lesson_time}',
						'{location_type}',
						'{joining_details}',
						'{tutor_name}',
						'{site_name}',
						'{student_dashboard_url}',
					),
			)
		);
	}

	/**
	 * Register the student cancellation notification.
	 *
	 * @return void
	 */
	private static function register_student_booking_cancelled() {
		TutorHelper_Email_Templates::register(
			self::STUDENT_BOOKING_CANCELLED,
			array(
				'module' =>
					'bookings',

				'label' =>
					__(
						'Lesson cancelled — Student',
						'tutorhelper-bookings'
					),

				'description' =>
					__(
						'Sent to the student when a lesson is cancelled.',
						'tutorhelper-bookings'
					),

				'heading' =>
					__(
						'Lesson Cancelled',
						'tutorhelper-bookings'
					),

				'recipient' =>
					'student',

				'enabled' =>
					true,

				'subject' =>
					__(
						'{booking_type} lesson on {lesson_date} has been cancelled',
						'tutorhelper-bookings'
					),

				'body' =>
					__(
						"Hello {student_name},\n\nYour lesson has been cancelled.\n\nLesson: {booking_type}\nDate: {lesson_date}\nTime: {lesson_time}\nLocation: {location_type}\n\nCancellation reason:\n{cancellation_reason}\n\nYou can view your lessons here:\n{student_dashboard_url}\n\nIf you have any questions about this cancellation, please reply to this email.\n\nBest wishes,\n{tutor_name}",
						'tutorhelper-bookings'
					),

				'placeholders' =>
					array(
						'{student_name}',
						'{first_name}',
						'{booking_type}',
						'{lesson_date}',
						'{lesson_time}',
						'{location_type}',
						'{tutor_name}',
						'{site_name}',
						'{student_dashboard_url}',
						'{cancellation_reason}',
					),
			)
		);
	}

	/**
	 * Register the tutor notification for a student cancellation.
	 *
	 * @return void
	 */
	private static function register_student_cancelled_tutor() {
		TutorHelper_Email_Templates::register(
			self::STUDENT_CANCELLED_TUTOR,
			array(
				'module' =>
					'bookings',

				'label' =>
					__(
						'Lesson cancelled by student — Tutor',
						'tutorhelper-bookings'
					),

				'description' =>
					__(
						'Sent to the tutor when a student cancels one of their lessons.',
						'tutorhelper-bookings'
					),

				'heading' =>
					__(
						'Lesson Cancelled by Student',
						'tutorhelper-bookings'
					),

				'recipient' =>
					'tutor',

				'enabled' =>
					true,

				'subject' =>
					__(
						'{student_name} cancelled their {booking_type} lesson on {lesson_date}',
						'tutorhelper-bookings'
					),

				'body' =>
					__(
						"Hello {tutor_name},\n\n{student_name} has cancelled their {booking_type} lesson.\n\nDate: {lesson_date}\nTime: {lesson_time}\nLocation: {location_type}\n\nCancellation reason:\n{cancellation_reason}\n\nYou can review the booking in your TutorHelper calendar:\n{calendar_url}\n\nBest wishes,\nTutorHelper",
						'tutorhelper-bookings'
					),

				'placeholders' =>
					array(
						'{student_name}',
						'{first_name}',
						'{student_email}',
						'{booking_type}',
						'{lesson_date}',
						'{lesson_time}',
						'{location_type}',
						'{cancellation_reason}',
						'{tutor_name}',
						'{site_name}',
						'{calendar_url}',
					),
			)
		);
	}


	/**
	 * Register editable account lifecycle templates.
	 *
	 * @return void
	 */
	private static function register_account_templates() {
		$placeholders = array(
			'{first_name}',
			'{user_name}',
			'{site_name}',
			'{login_url}',
			'{set_password_url}',
			'{reset_password_url}',
		);

		TutorHelper_Email_Templates::register(
			self::ACCOUNT_CREATED,
			array(
				'module' => 'bookings',
				'label' => __( 'New account', 'tutorhelper-bookings' ),
				'description' => __( 'Sent when WordPress creates an account for a TutorHelper user.', 'tutorhelper-bookings' ),
				'heading' => __( 'Welcome to TutorHelper', 'tutorhelper-bookings' ),
				'recipient' => 'user',
				'enabled' => true,
				'subject' => __( 'Your {site_name} account is ready', 'tutorhelper-bookings' ),
				'body' => __( "Hello {first_name},\n\nYour account has been created.\n\nUsername: {user_name}\n\nChoose a password: {set_password_url}\n\nSign in: {login_url}\n\nBest wishes,\n{site_name}", 'tutorhelper-bookings' ),
				'placeholders' => $placeholders,
			)
		);

		TutorHelper_Email_Templates::register(
			self::PASSWORD_RESET,
			array(
				'module' => 'bookings',
				'label' => __( 'Password reset', 'tutorhelper-bookings' ),
				'description' => __( 'Sent when a TutorHelper user requests or is sent a password reset.', 'tutorhelper-bookings' ),
				'heading' => __( 'Reset your password', 'tutorhelper-bookings' ),
				'recipient' => 'user',
				'enabled' => true,
				'subject' => __( 'Reset your {site_name} password', 'tutorhelper-bookings' ),
				'body' => __( "Hello {first_name},\n\nA password reset was requested for your account.\n\nReset your password: {reset_password_url}\n\nIf you did not request this, you can ignore this email.\n\nBest wishes,\n{site_name}", 'tutorhelper-bookings' ),
				'placeholders' => $placeholders,
			)
		);
	}

	/**
	 * Send the editable TutorHelper new-account email directly.
	 *
	 * Plugin-created accounts use this method instead of delegating delivery
	 * to WordPress's default notification so the configured TutorHelper
	 * template, branding and delivery history are always applied.
	 *
	 * @param int $user_id New WordPress user ID.
	 * @return true|WP_Error
	 */
	public static function send_new_account_email( $user_id ) {
		$user = get_userdata( absint( $user_id ) );

		if ( ! $user instanceof WP_User ) {
			return new WP_Error(
				'tutorhelper_account_email_user_missing',
				__( 'The new account could not be found.', 'tutorhelper-bookings' )
			);
		}

		$key = get_password_reset_key( $user );

		if ( is_wp_error( $key ) ) {
			return $key;
		}

		$set_password_url =
			self::get_password_url(
				$key,
				$user->user_login
			);

		return TutorHelper_Email_Sender::send(
			self::ACCOUNT_CREATED,
			$user->user_email,
			array(
				'{first_name}' => $user->first_name ? $user->first_name : $user->display_name,
				'{user_name}' => $user->user_login,
				'{site_name}' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
				'{login_url}' => TutorHelper_Settings::get_login_url(),
				'{set_password_url}' => $set_password_url,
				'{reset_password_url}' => '',
			),
			array(
				'context' => array(
					'user_id' => absint( $user_id ),
					'student_user_id' => absint( $user_id ),
					'recipient_type' => 'parent',
					'email_type' => 'account_created',
				),
			)
		);
	}

	/**
	 * Replace the default new-user email with the editable TutorHelper template.
	 *
	 * @param array   $email Default email.
	 * @param WP_User $user  User receiving the email.
	 * @param string  $blogname Site name.
	 * @return array
	 */
	public static function filter_new_account_email( $email, $user, $blogname ) {
		if ( ! $user instanceof WP_User ) {
			return $email;
		}

		$key = get_password_reset_key( $user );
		if ( is_wp_error( $key ) ) {
			return $email;
		}

		$url =
			self::get_password_url(
				$key,
				$user->user_login
			);
		return self::render_wordpress_email( self::ACCOUNT_CREATED, $email, $user, $blogname, $url, '' );
	}

	/**
	 * Replace the default password reset email with TutorHelper styling.
	 *
	 * @param array   $email      Default email.
	 * @param string  $key        Reset key.
	 * @param string  $user_login Login name.
	 * @param WP_User $user       User receiving the email.
	 * @return array
	 */
	public static function filter_password_reset_email( $email, $key, $user_login, $user ) {
		if ( ! $user instanceof WP_User ) {
			return $email;
		}
		$url =
			self::get_password_url(
				$key,
				$user_login
			);
		return self::render_wordpress_email( self::PASSWORD_RESET, $email, $user, get_bloginfo( 'name' ), '', $url );
	}

	/**
	 * Build a password setup or reset URL on the configured student login page.
	 *
	 * @param string $key        WordPress password reset key.
	 * @param string $user_login WordPress user login.
	 *
	 * @return string
	 */
	private static function get_password_url(
		$key,
		$user_login
	) {
		$login_url =
			TutorHelper_Settings::get_login_url();

		return add_query_arg(
			array(
				'action' => 'rp',
				'key'    => $key,
				'login'  => $user_login,
			),
			$login_url
		);
	}

	/**
	 * Render one account template for a WordPress notification filter.
	 *
	 * @param string  $template_key Template key.
	 * @param array   $email        Default email.
	 * @param WP_User $user         Recipient.
	 * @param string  $site_name    Site name.
	 * @param string  $set_url      Password setup URL.
	 * @param string  $reset_url    Password reset URL.
	 * @return array
	 */
	private static function render_wordpress_email( $template_key, $email, $user, $site_name, $set_url, $reset_url ) {
		$rendered = TutorHelper_Email_Renderer::render(
			$template_key,
			array(
				'{first_name}' => $user->first_name ? $user->first_name : $user->display_name,
				'{user_name}' => $user->user_login,
				'{site_name}' => wp_specialchars_decode( $site_name, ENT_QUOTES ),
				'{login_url}' => TutorHelper_Settings::get_login_url(),
				'{set_password_url}' => $set_url,
				'{reset_password_url}' => $reset_url,
			)
		);
		if ( is_wp_error( $rendered ) ) {
			return $email;
		}
		$email['subject'] = $rendered['subject'];
		$email['message'] = $rendered['html'];
		$email['headers'] = array( 'Content-Type: text/html; charset=UTF-8' );
		return $email;
	}

}
