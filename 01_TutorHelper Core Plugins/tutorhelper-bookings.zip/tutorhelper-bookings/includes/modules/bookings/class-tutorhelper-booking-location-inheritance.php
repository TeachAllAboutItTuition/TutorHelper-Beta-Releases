<?php
/**
 * Booking location detail inheritance.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snapshots effective location details onto newly-created bookings.
 */
final class TutorHelper_Booking_Location_Inheritance {

	/**
	 * Register booking lifecycle hooks.
	 *
	 * This runs before email and Calendar listeners so downstream features
	 * receive the resolved booking location details.
	 *
	 * @return void
	 */
	public static function init() {
		add_action(
			'tutorhelper_booking_created',
			array( __CLASS__, 'apply_to_booking' ),
			1,
			1
		);
	}

	/**
	 * Resolve and persist inherited location details for a new booking.
	 *
	 * Precedence:
	 * 1. Explicit individual booking details already stored.
	 * 2. Matching availability/date override for student bookings.
	 * 3. Booking Type default details.
	 *
	 * @param int $booking_id Booking ID.
	 * @return void
	 */
	public static function apply_to_booking( $booking_id ) {
		$booking_id = absint( $booking_id );
		if ( ! $booking_id ) {
			return;
		}

		$booking = TutorHelper_Booking_Records::get_by_id( $booking_id );
		if ( ! $booking ) {
			return;
		}

		$existing_details = isset( $booking->location_details )
			? trim( sanitize_textarea_field( $booking->location_details ) )
			: '';

		/*
		 * An individual booking override is authoritative and must not be
		 * replaced by later Booking Type or availability defaults.
		 */
		if ( '' !== $existing_details ) {
			return;
		}

		$booking_type = TutorHelper_Booking_Types::get_by_id(
			absint( $booking->booking_type_id )
		);

		if ( ! $booking_type ) {
			return;
		}

		$resolved_details = '';
		$source = sanitize_key( $booking->source );

		if ( TutorHelper_Booking_Records::SOURCE_STUDENT === $source ) {
			$resolved_details = self::get_student_availability_details(
				$booking
			);
		}

		if ( '' === $resolved_details && isset( $booking_type->location_details ) ) {
			$resolved_details = trim(
				sanitize_textarea_field( $booking_type->location_details )
			);
		}

		if ( '' === $resolved_details ) {
			return;
		}

		global $wpdb;
		$result = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Core is snapshotting inherited data onto its own newly-created booking record before downstream lifecycle listeners run.
			TutorHelper_Booking_Records::get_table_name(),
			array(
				'location_details' => $resolved_details,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $booking_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $result ) {
			TutorHelper_Logger::warning(
				'Booking location details could not be inherited.',
				array(
					'booking_id' => $booking_id,
					'booking_type_id' => absint( $booking->booking_type_id ),
					'source' => $source,
				)
			);
			return;
		}

		TutorHelper_Logger::info(
			'Booking location details inherited.',
			array(
				'booking_id' => $booking_id,
				'booking_type_id' => absint( $booking->booking_type_id ),
				'source' => $source,
				'location_type' => sanitize_key( $booking->location_type ),
			)
		);
	}

	/**
	 * Resolve details from the matching public availability occurrence.
	 *
	 * Date-specific availability overrides are already applied by
	 * TutorHelper_Booking_Availability::get_occurrences().
	 *
	 * @param object $booking Booking record.
	 * @return string
	 */
	private static function get_student_availability_details( $booking ) {
		if ( ! class_exists( 'TutorHelper_Booking_Availability' ) ) {
			return '';
		}

		try {
			$timezone_name = ! empty( $booking->timezone )
				? sanitize_text_field( $booking->timezone )
				: wp_timezone()->getName();
			$timezone = new DateTimeZone( $timezone_name );
			$utc = new DateTimeZone( 'UTC' );
			$start = new DateTimeImmutable( $booking->booking_start, $utc );
			$end = new DateTimeImmutable( $booking->booking_end, $utc );
			$start = $start->setTimezone( $timezone );
			$end = $end->setTimezone( $timezone );
		} catch ( Exception $exception ) {
			return '';
		}

		$date = $start->format( 'Y-m-d' );
		$start_time = $start->format( 'H:i:s' );
		$end_time = $end->format( 'H:i:s' );

		$occurrences = TutorHelper_Booking_Availability::get_occurrences(
			absint( $booking->tutor_user_id ),
			$date,
			$date
		);

		if ( is_wp_error( $occurrences ) || ! is_array( $occurrences ) ) {
			return '';
		}

		foreach ( $occurrences as $occurrence ) {
			if ( ! is_array( $occurrence ) ) {
				continue;
			}

			$occurrence_start = isset( $occurrence['start_time'] )
				? sanitize_text_field( $occurrence['start_time'] )
				: '';
			$occurrence_end = isset( $occurrence['end_time'] )
				? sanitize_text_field( $occurrence['end_time'] )
				: '';

			if ( strlen( $occurrence_start ) === 5 ) {
				$occurrence_start .= ':00';
			}
			if ( strlen( $occurrence_end ) === 5 ) {
				$occurrence_end .= ':00';
			}

			if (
				'' === $occurrence_start
				|| '' === $occurrence_end
				|| $start_time < $occurrence_start
				|| $end_time > $occurrence_end
			) {
				continue;
			}

			$location_types = isset( $occurrence['location_types'] )
				&& is_array( $occurrence['location_types'] )
					? array_map( 'sanitize_key', $occurrence['location_types'] )
					: array();

			if (
				! empty( $location_types )
				&& ! in_array(
					sanitize_key( $booking->location_type ),
					$location_types,
					true
				)
			) {
				continue;
			}

			$allowed_booking_type_ids = isset( $occurrence['allowed_booking_type_ids'] )
				&& is_array( $occurrence['allowed_booking_type_ids'] )
					? array_map( 'absint', $occurrence['allowed_booking_type_ids'] )
					: array();

			if (
				! empty( $allowed_booking_type_ids )
				&& ! in_array(
					absint( $booking->booking_type_id ),
					$allowed_booking_type_ids,
					true
				)
			) {
				continue;
			}

			$details = isset( $occurrence['location_details'] )
				? trim( sanitize_textarea_field( $occurrence['location_details'] ) )
				: '';

			if ( '' !== $details ) {
				return $details;
			}
		}

		return '';
	}
}
