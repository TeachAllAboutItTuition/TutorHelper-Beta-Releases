<?php
/**
 * TutorHelper shared emails module.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads shared TutorHelper email functionality.
 */
final class TutorHelper_Emails_Module {

	/**
	 * Initialise the module.
	 *
	 * @return void
	 */
	public static function init() {
        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/emails/'
            . 'class-tutorhelper-email-templates.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/emails/'
            . 'class-tutorhelper-email-settings.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/emails/'
            . 'class-tutorhelper-email-placeholders.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/emails/'
            . 'class-tutorhelper-email-renderer.php';

        require_once TUTORHELPER_BOOKINGS_PATH
            . 'includes/modules/emails/'
            . 'class-tutorhelper-email-sender.php';

        if ( is_admin() ) {
            require_once TUTORHELPER_BOOKINGS_PATH
                . 'includes/modules/emails/'
                . 'class-tutorhelper-email-admin.php';

            TutorHelper_Email_Admin::init();
        }
    }
}
