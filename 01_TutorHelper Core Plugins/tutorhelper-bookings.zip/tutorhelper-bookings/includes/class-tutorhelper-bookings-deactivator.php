<?php
/**
 * Plugin deactivation handler.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles TutorHelper Bookings deactivation.
 */
final class TutorHelper_Bookings_Deactivator {

	/**
	 * Run deactivation tasks.
	 *
	 * Deactivation must not delete bookings, availability or settings.
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'tutorhelper_booking_analytics_cleanup' );

		/**
		 * Fires when TutorHelper Bookings is deactivated.
		 *
		 * Scheduled booking events will eventually be cleared here.
		 */
		do_action( 'tutorhelper_bookings_deactivated' );
	}
}
