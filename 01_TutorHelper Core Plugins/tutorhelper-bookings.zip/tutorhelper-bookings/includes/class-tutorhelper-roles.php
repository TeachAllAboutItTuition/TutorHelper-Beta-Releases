<?php
/**
 * TutorHelper WordPress roles.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and maintains TutorHelper user roles.
 */
final class TutorHelper_Roles {

	/**
	 * Student role slug.
	 *
	 * @var string
	 */
	const STUDENT_ROLE = 'th_student';

	/**
	 * Parent role slug.
	 *
	 * @var string
	 */
	const PARENT_ROLE = 'th_parent';

	/**
	 * Create any missing TutorHelper roles.
	 *
	 * add_role() is safe to call when a role already exists. However,
	 * checking first makes the intention clearer and avoids unnecessary
	 * writes to the WordPress roles option.
	 *
	 * @return void
	 */
	public static function register_roles() {
		if ( ! get_role( self::STUDENT_ROLE ) ) {
			add_role(
				self::STUDENT_ROLE,
				__(
					'TH Student',
					'tutorhelper-bookings'
				),
				self::get_student_capabilities()
			);
		}

		if ( ! get_role( self::PARENT_ROLE ) ) {
			add_role(
				self::PARENT_ROLE,
				__(
					'TH Parent',
					'tutorhelper-bookings'
				),
				self::get_parent_capabilities()
			);
		}
	}

	/**
	 * Return the initial TH Student capabilities.
	 *
	 * Students require only the basic read capability for now.
	 * More specific TutorHelper capabilities can be added later.
	 *
	 * @return array
	 */
	private static function get_student_capabilities() {
		return array(
			'read' => true,
		);
	}

	/**
	 * Return the initial TH Parent capabilities.
	 *
	 * Parent access will be controlled by TutorHelper itself rather
	 * than granting broad WordPress administration capabilities.
	 *
	 * @return array
	 */
	private static function get_parent_capabilities() {
		return array(
			'read' => true,
		);
	}
}
