<?php
/**
 * Temporary manual tests for the booking types data layer.
 *
 * Delete this file after testing.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Run booking type data tests from the WordPress dashboard.
 *
 * @return void
 */
function tutorhelper_booking_types_run_manual_test() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if (
		! isset( $_GET['tutorhelper_booking_types_test'] )
		|| 'run' !== sanitize_key( wp_unslash( $_GET['tutorhelper_booking_types_test'] ) )
	) {
		return;
	}

	if (
		! isset( $_GET['_wpnonce'] )
		|| ! wp_verify_nonce(
			sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ),
			'tutorhelper_booking_types_manual_test'
		)
	) {
		wp_die(
			esc_html__(
				'The booking types test link is invalid or has expired.',
				'tutorhelper-bookings'
			)
		);
	}

	$results = array();

	$invalid_result = TutorHelper_Booking_Types::create(
		array(
			'title'            => '',
			'duration_minutes' => 60,
		)
	);

	$results['Rejects missing title'] = is_wp_error( $invalid_result );

	$booking_type_id = TutorHelper_Booking_Types::create(
		array(
			'title'                     => 'Manual Test Lesson',
			'description'               => 'Temporary booking type data test.',
			'duration_minutes'          => 60,
			'location_type'             => 'online',
			'location_types'            => array(
				'online',
				'phone',
			),
			'location_details'          => 'Test location details',
			'colour'                    => '#FF6326',
			'online_booking_visibility' => 'bookable',
			'notice_period_hours'       => 48,
			'cancellations_allowed'     => 1,
			'cancellation_notice_hours' => 24,
			'is_active'                 => 1,
			'sort_order'                => 10,
		)
	);

	$results['Creates booking type'] = is_int( $booking_type_id )
		&& 0 < $booking_type_id;

	if ( ! is_wp_error( $booking_type_id ) ) {
		$created = TutorHelper_Booking_Types::get_by_id(
			$booking_type_id
		);

		$results['Retrieves booking type'] = $created
			&& 'Manual Test Lesson' === $created->title;

		$update_result = TutorHelper_Booking_Types::update(
			$booking_type_id,
			array(
				'title'            => 'Updated Manual Test Lesson',
				'duration_minutes' => 90,
			)
		);

		$updated = TutorHelper_Booking_Types::get_by_id(
			$booking_type_id
		);

		$results['Updates booking type'] = true === $update_result
			&& $updated
			&& 'Updated Manual Test Lesson' === $updated->title
			&& 90 === absint( $updated->duration_minutes );

		$results['Partial update preserves description'] = $updated
			&& 'Temporary booking type data test.' === $updated->description;

		$archive_result = TutorHelper_Booking_Types::archive(
			$booking_type_id
		);

		$archived = TutorHelper_Booking_Types::get_by_id(
			$booking_type_id
		);

		$results['Archives booking type'] = true === $archive_result
			&& $archived
			&& 0 === absint( $archived->is_active );

		$active_types = TutorHelper_Booking_Types::get_active();

		$active_ids = wp_list_pluck(
			$active_types,
			'id'
		);

		$results['Archived type excluded from active list'] = ! in_array(
			(string) $booking_type_id,
			array_map( 'strval', $active_ids ),
			true
		);

		$restore_result = TutorHelper_Booking_Types::restore(
			$booking_type_id
		);

		$restored = TutorHelper_Booking_Types::get_by_id(
			$booking_type_id
		);

		$results['Restores booking type'] = true === $restore_result
			&& $restored
			&& 1 === absint( $restored->is_active );
	}

	set_transient(
		'tutorhelper_booking_types_manual_test_results',
		$results,
		MINUTE_IN_SECONDS
	);

	wp_safe_redirect(
		remove_query_arg(
			array(
				'tutorhelper_booking_types_test',
				'_wpnonce',
			)
		)
	);

	exit;
}

add_action(
	'admin_init',
	'tutorhelper_booking_types_run_manual_test'
);

/**
 * Show the booking types test link and results.
 *
 * @return void
 */
function tutorhelper_booking_types_manual_test_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$test_url = wp_nonce_url(
		add_query_arg(
			'tutorhelper_booking_types_test',
			'run',
			admin_url()
		),
		'tutorhelper_booking_types_manual_test'
	);

	$results = get_transient(
		'tutorhelper_booking_types_manual_test_results'
	);

	echo '<div class="notice notice-info">';
	echo '<p><strong>';
	echo esc_html__(
		'TutorHelper Booking Types manual test',
		'tutorhelper-bookings'
	);
	echo '</strong></p>';

	echo '<p><a class="button" href="';
	echo esc_url( $test_url );
	echo '">';
	echo esc_html__(
		'Run booking types test',
		'tutorhelper-bookings'
	);
	echo '</a></p>';

	if ( is_array( $results ) ) {
		echo '<ul>';

		foreach ( $results as $label => $passed ) {
			echo '<li>';
			echo $passed ? '✅ ' : '❌ ';
			echo esc_html( $label );
			echo '</li>';
		}

		echo '</ul>';

		delete_transient(
			'tutorhelper_booking_types_manual_test_results'
		);
	}

	echo '</div>';
}

add_action(
	'admin_notices',
	'tutorhelper_booking_types_manual_test_notice'
);
