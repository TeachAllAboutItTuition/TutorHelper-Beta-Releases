<?php
/**
 * Plugin activation handler.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles TutorHelper Bookings activation.
 */
final class TutorHelper_Bookings_Activator {

	/**
	 * Run activation tasks.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			deactivate_plugins( TUTORHELPER_BOOKINGS_BASENAME );

			wp_die(
				esc_html__(
					'TutorHelper Bookings requires PHP 7.4 or later.',
					'tutorhelper-bookings'
				),
				esc_html__(
					'Plugin activation failed',
					'tutorhelper-bookings'
				),
				array(
					'back_link' => true,
				)
			);
		}

		update_option(
            'tutorhelper_bookings_version',
            TUTORHELPER_BOOKINGS_VERSION
        );

        TutorHelper_Bookings_Database::create_tables();
		TutorHelper_Roles::register_roles();

		TutorHelper_Logger::success(
			'TutorHelper Bookings activated.',
			array(
				'plugin_version'   => TUTORHELPER_BOOKINGS_VERSION,
				'database_version' => TUTORHELPER_BOOKINGS_DB_VERSION,
			)
		);
		

		/**
		 * Fires after TutorHelper Bookings has been activated.
		 */
		do_action( 'tutorhelper_bookings_activated' );
	}
}
