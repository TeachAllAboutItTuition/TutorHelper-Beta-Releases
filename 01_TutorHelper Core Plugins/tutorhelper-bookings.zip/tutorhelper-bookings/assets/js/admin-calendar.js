(function () {
	'use strict';

	const STORAGE_KEY =
		'tutorhelperCalendarSidebarCollapsed';

	const WEEK_MODE_STORAGE_KEY =
		'tutorhelperCalendarWeekMode';

    const settings =
	window.tutorhelperAdminCalendar || {};

    const sidebarSettings =
        settings.sidebar || {};

	/**
	 * Read the saved sidebar state.
	 *
	 * @returns {boolean}
	 */
	function getSavedState() {
		try {
			return window.localStorage.getItem(
				STORAGE_KEY
			) === '1';
		} catch (error) {
			return false;
		}
	}

	/**
	 * Save the sidebar state.
	 *
	 * @param {boolean} collapsed Whether the panel is collapsed.
	 */
	function saveState(collapsed) {
		try {
			window.localStorage.setItem(
				STORAGE_KEY,
				collapsed ? '1' : '0'
			);
		} catch (error) {
			/*
			 * Storage may be unavailable in private or restricted
			 * browser contexts. The toggle still works for the
			 * current page without persistence.
			 */
		}
	}

	/**
	 * Initialise the calendar sidebar toggle.
	 */
	function initialiseCalendarSidebar() {
		const layout = document.querySelector(
			'[data-calendar-layout]'
		);

		const sidebar = document.querySelector(
			'[data-calendar-sidebar]'
		);

		const button = document.querySelector(
			'[data-calendar-sidebar-toggle]'
		);

		if (
			!layout
			|| !sidebar
			|| !button
		) {
			return;
		}

		const label = button.querySelector(
			'[data-calendar-sidebar-toggle-label]'
		);

		/**
		 * Apply the selected state.
		 *
		 * @param {boolean} collapsed Whether to collapse the sidebar.
		 * @param {boolean} persist Whether to save the choice.
		 */
		function setCollapsed(
			collapsed,
			persist
		) {
			layout.classList.toggle(
				'is-sidebar-collapsed',
				collapsed
			);

			sidebar.hidden = collapsed;

			button.setAttribute(
				'aria-expanded',
				collapsed ? 'false' : 'true'
			);

			if (label) {
				label.textContent = collapsed
                ? (
                    sidebarSettings.showLabel
                    || 'Show side panel'
                )
                : (
                    sidebarSettings.hideLabel
                    || 'Hide side panel'
                );
			}

			if (persist) {
				saveState(collapsed);
			}
		}

		setCollapsed(
			getSavedState(),
			false
		);

		button.addEventListener(
			'click',
			function () {
				const collapsed =
					!layout.classList.contains(
						'is-sidebar-collapsed'
					);

				setCollapsed(
					collapsed,
					true
				);
			}
		);
	}

	/**
	 * Convert a local HH:MM value to minutes after midnight.
	 *
	 * @param {string} value Time value.
	 * @returns {number|null}
	 */
	function timeToMinutes(value) {
		const match = /^(\d{1,2}):(\d{2})$/.exec(value || '');

		if (!match) {
			return null;
		}

		const hours = Number.parseInt(match[1], 10);
		const minutes = Number.parseInt(match[2], 10);

		if (hours > 23 || minutes > 59) {
			return null;
		}

		return (hours * 60) + minutes;
	}

	/**
	 * Build and control the timetable-style weekly view.
	 */
	function initialiseWeekViews() {
		const wrapper = document.querySelector('[data-week-view]');

		if (!wrapper) {
			return;
		}

		const details = wrapper.querySelector('[data-week-details]');
		const timetable = wrapper.querySelector('[data-week-timetable]');
		const buttons = Array.from(wrapper.querySelectorAll('[data-week-mode]'));
		const zoomInput = wrapper.querySelector('[data-week-timetable-zoom]');

		if (!details || !timetable || !buttons.length) {
			return;
		}

		const days = Array.from(details.querySelectorAll('[data-week-date]'));
		let pixelsPerMinute = 1.2;

		try {
			pixelsPerMinute = Number.parseFloat(
				window.localStorage.getItem('tutorhelperCalendarTimetableZoom')
			) || pixelsPerMinute;
		} catch (error) {
			// Use the default scale if browser storage is unavailable.
		}

		pixelsPerMinute = Math.max(1, Math.min(3, pixelsPerMinute));

		if (zoomInput) {
			zoomInput.value = String(pixelsPerMinute);
		}

		function hideCancelled() {
			return document.documentElement.classList.contains(
				'tutorhelper-calendar-hide-cancelled'
			);
		}

		function sourceEvents() {
			return Array.from(
				details.querySelectorAll('[data-timetable-event]')
			).filter(function (event) {
				return !hideCancelled()
					|| !event.classList.contains('is-cancelled');
			});
		}

		function buildTimetable() {
			const allEvents = sourceEvents();
			const eventTimes = allEvents.map(function (event) {
				return {
					start: timeToMinutes(event.dataset.startTime),
					end: timeToMinutes(event.dataset.endTime)
				};
			}).filter(function (times) {
				return times.start !== null
					&& times.end !== null
					&& times.end > times.start;
			});

			let rangeStart = 8 * 60;
			let rangeEnd = 20 * 60;

			if (eventTimes.length) {
				rangeStart = Math.max(0, Math.floor(Math.min.apply(null, eventTimes.map(function (times) {
					return times.start;
				})) / 60) * 60);
				rangeEnd = Math.min(24 * 60, Math.ceil(Math.max.apply(null, eventTimes.map(function (times) {
					return times.end;
				})) / 60) * 60);
			}

			if (rangeEnd <= rangeStart) {
				rangeEnd = Math.min(24 * 60, rangeStart + (12 * 60));
			}

			const height = (rangeEnd - rangeStart) * pixelsPerMinute;
			const grid = document.createElement('div');
			grid.className = 'tutorhelper-week-timetable__grid';

			const corner = document.createElement('div');
			corner.className = 'tutorhelper-week-timetable__corner';
			corner.textContent = 'Time';
			grid.appendChild(corner);

			days.forEach(function (day) {
				const heading = document.createElement('div');
				heading.className = 'tutorhelper-week-timetable__day-heading';
				if (day.classList.contains('is-today')) {
					heading.classList.add('is-today');
				}
				heading.innerHTML = '<strong></strong><span></span>';
				heading.querySelector('strong').textContent = day.dataset.weekdayLabel || '';
				heading.querySelector('span').textContent = day.dataset.dateLabel || '';
				grid.appendChild(heading);
			});

			const axis = document.createElement('div');
			axis.className = 'tutorhelper-week-timetable__axis';
			axis.style.height = height + 'px';

			for (let minute = rangeStart; minute <= rangeEnd; minute += 60) {
				const label = document.createElement('span');
				label.style.top = ((minute - rangeStart) * pixelsPerMinute) + 'px';
				label.textContent = String(Math.floor(minute / 60)).padStart(2, '0') + ':00';
				axis.appendChild(label);
			}
			grid.appendChild(axis);

			days.forEach(function (day) {
				const column = document.createElement('div');
				column.className = 'tutorhelper-week-timetable__day';
				column.style.height = height + 'px';

				for (let minute = rangeStart; minute <= rangeEnd; minute += 60) {
					const line = document.createElement('span');
					line.className = 'tutorhelper-week-timetable__hour-line';
					line.style.top = ((minute - rangeStart) * pixelsPerMinute) + 'px';
					column.appendChild(line);
				}

				Array.from(day.querySelectorAll('[data-timetable-event]')).forEach(function (source) {
					if (hideCancelled() && source.classList.contains('is-cancelled')) {
						return;
					}

					const start = timeToMinutes(source.dataset.startTime);
					const end = timeToMinutes(source.dataset.endTime);
					if (start === null || end === null || end <= start) {
						return;
					}

					const eventUrl = source.dataset.eventUrl || (source.matches('a') ? source.href : '');
					const event = document.createElement(eventUrl ? 'a' : 'div');
					const type = source.dataset.timetableEvent;
					event.className = 'tutorhelper-week-timetable__event is-' + type;
					if (source.classList.contains('is-cancelled')) {
						event.classList.add('is-cancelled');
					}
					event.style.top = ((start - rangeStart) * pixelsPerMinute) + 'px';
					event.style.height = Math.max(24, (end - start) * pixelsPerMinute) + 'px';

					const eventLabel = source.dataset.eventLabel || '';
					const eventMeta = source.dataset.eventMeta || '';
					if ('booking' === type) {
						const label = document.createElement('strong');
						label.textContent = eventLabel;
						event.appendChild(label);
						if (eventMeta) {
							const meta = document.createElement('span');
							meta.textContent = eventMeta;
							event.appendChild(meta);
						}
					} else {
						event.textContent = eventLabel;
					}

					event.setAttribute('aria-label', [
						eventLabel,
						eventMeta,
						(source.dataset.startTime || '') + '–' + (source.dataset.endTime || '')
					].filter(Boolean).join(', '));

					if (source.dataset.eventColour) {
						event.style.setProperty('--tutorhelper-booking-colour', source.dataset.eventColour);
					}
					if (eventUrl) {
						event.href = eventUrl;
					}
					column.appendChild(event);
				});

				grid.appendChild(column);
			});

			timetable.replaceChildren(grid);
		}

		function setMode(mode, persist) {
			const timetableMode = mode !== 'details';
			timetable.hidden = !timetableMode;
			details.hidden = timetableMode;
			buttons.forEach(function (button) {
				const active = button.dataset.weekMode === (timetableMode ? 'timetable' : 'details');
				button.classList.toggle('is-active', active);
				button.setAttribute('aria-pressed', active ? 'true' : 'false');
			});
			if (persist) {
				try {
					window.localStorage.setItem(WEEK_MODE_STORAGE_KEY, timetableMode ? 'timetable' : 'details');
				} catch (error) {
					// The selected mode still works for this page.
				}
			}
		}

		buildTimetable();

		let savedMode = 'timetable';
		try {
			savedMode = window.localStorage.getItem(WEEK_MODE_STORAGE_KEY) || 'timetable';
		} catch (error) {
			// Use the timetable default.
		}
		setMode(savedMode, false);

		buttons.forEach(function (button) {
			button.addEventListener('click', function () {
				setMode(button.dataset.weekMode, true);
			});
		});

		if (zoomInput) {
			zoomInput.addEventListener('input', function () {
				pixelsPerMinute = Math.max(1, Math.min(3, Number.parseFloat(zoomInput.value) || 1.2));
				zoomInput.setAttribute('aria-valuenow', String(pixelsPerMinute));
				try {
					window.localStorage.setItem('tutorhelperCalendarTimetableZoom', String(pixelsPerMinute));
				} catch (error) {
					// The chosen zoom still works for this page.
				}
				buildTimetable();
			});
		}

		document.addEventListener('tutorhelperCalendarVisibilityChange', buildTimetable);
	}

	function initialiseCancelledVisibility() {
		const control = document.querySelector('[data-calendar-hide-cancelled]');
		if (!control) {
			return;
		}

		let hidden = false;
		try {
			hidden = window.localStorage.getItem('tutorhelperCalendarHideCancelled') === '1';
		} catch (error) {
			// The control works for this page without persistent browser storage.
		}

		function apply(value, persist) {
			control.checked = value;
			document.documentElement.classList.toggle('tutorhelper-calendar-hide-cancelled', value);
			if (persist) {
				try {
					window.localStorage.setItem('tutorhelperCalendarHideCancelled', value ? '1' : '0');
				} catch (error) {
					// No persistent preference is available.
				}
			}
			document.dispatchEvent(new Event('tutorhelperCalendarVisibilityChange'));
		}

		apply(hidden, false);
		control.addEventListener('change', function () {
			apply(control.checked, true);
		});
	}

	function initialiseCalendar() {
		initialiseCalendarSidebar();
		initialiseCancelledVisibility();
		initialiseWeekViews();
	}

	if (document.readyState === 'loading') {
		document.addEventListener(
			'DOMContentLoaded',
			initialiseCalendar
		);
	} else {
		initialiseCalendar();
	}
}());
