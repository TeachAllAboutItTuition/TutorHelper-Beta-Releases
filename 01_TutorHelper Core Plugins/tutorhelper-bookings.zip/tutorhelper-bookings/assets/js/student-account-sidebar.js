( function () {
	'use strict';

	const settings = window.tutorhelperStudentSidebar || {};
	const countdowns = document.querySelectorAll(
		'[data-tutorhelper-next-lesson-countdown]'
	);

	if ( ! countdowns.length ) {
		return;
	}

	const unit = ( value, singular, plural ) =>
		value + ' ' + ( 1 === value ? singular : plural );

	const updateCountdown = ( element ) => {
		const start = Date.parse( element.dataset.start || '' );

		if ( Number.isNaN( start ) ) {
			return;
		}

		let remaining = Math.floor( ( start - Date.now() ) / 1000 );

		if ( remaining <= 0 ) {
			element.textContent = settings.startingNow || 'Your lesson is starting now.';
			return;
		}

		const days = Math.floor( remaining / 86400 );
		remaining %= 86400;
		const hours = Math.floor( remaining / 3600 );
		remaining %= 3600;
		const minutes = Math.max( 1, Math.ceil( remaining / 60 ) );
		const parts = [];

		if ( days ) {
			parts.push( unit( days, settings.day || 'day', settings.days || 'days' ) );
		}

		if ( hours ) {
			parts.push( unit( hours, settings.hour || 'hour', settings.hours || 'hours' ) );
		}

		if ( ! days && minutes ) {
			parts.push( unit( minutes, settings.minute || 'minute', settings.minutes || 'minutes' ) );
		}

		element.textContent = ( settings.startsIn || 'Starts in %s.' ).replace(
			'%s',
			parts.slice( 0, 2 ).join( ', ' )
		);
	};

	const updateAll = () => countdowns.forEach( updateCountdown );

	updateAll();
	window.setInterval( updateAll, 30000 );
}() );
