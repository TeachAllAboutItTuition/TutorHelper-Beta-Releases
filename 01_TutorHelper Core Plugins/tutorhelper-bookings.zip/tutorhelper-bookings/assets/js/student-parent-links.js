/**
 * TutorHelper Parent Account relationship search.
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		if (typeof tutorhelperParentLinks === 'undefined') {
			return;
		}

		const studentForm = document.querySelector(
			'.tutorhelper-student-edit-form'
		);
		let studentFormDirty = false;

		if (studentForm) {
			studentForm.addEventListener('input', function (event) {
				if (
					event.target.form === studentForm &&
					!event.target.closest('.tutorhelper-parent-links-manager')
				) {
					studentFormDirty = true;
				}
			});

			document.querySelectorAll('[data-parent-immediate-action]').forEach(
				function (button) {
					button.addEventListener('click', function (event) {
						if (studentFormDirty) {
							event.preventDefault();
							window.alert(tutorhelperParentLinks.strings.unsaved);
						}
					});
				}
			);
		}

		const forms = document.querySelectorAll(
			'[data-tutorhelper-parent-link-search]'
		);

		if (forms.length === 0) {
			return;
		}

		forms.forEach(function (form) {
			const input = form.querySelector('[data-parent-search-input]');
			const value = form.querySelector('[data-parent-user-id]');
			const results = form.querySelector('[data-parent-search-results]');
			const status = form.querySelector('[data-parent-search-status]');
			const selection = form.querySelector('[data-parent-search-selection]');
			const submit = form.querySelector('[data-parent-link-submit]');
			let timer = null;
			let controller = null;

			if (!input || !value || !results || !selection || !submit) {
				return;
			}

			function setStatus(message) {
				if (status) {
					status.textContent = message || '';
				}
			}

			function closeResults() {
				results.hidden = true;
				results.innerHTML = '';
			}

			function makeResult(user) {
				const button = document.createElement('button');
				const name = document.createElement('strong');
				const email = document.createElement('span');

				button.type = 'button';
				button.className = 'tutorhelper-parent-link-search__result';
				button.setAttribute('role', 'option');
				name.textContent = user.name || '';
				email.textContent = user.email || '';
				button.appendChild(name);
				button.appendChild(email);

				button.addEventListener('click', function () {
					value.value = String(user.id || '');
					selection.innerHTML = '';
					selection.appendChild(makeSelection(user));
					submit.disabled = !value.value;
					input.value = '';
					closeResults();
					setStatus(tutorhelperParentLinks.strings.selected);
				});

				return button;
			}

			function makeSelection(user) {
				const wrapper = document.createElement('div');
				const name = document.createElement('strong');
				const email = document.createElement('span');

				wrapper.className = 'tutorhelper-parent-link-search__selection';
				name.textContent = user.name || '';
				email.textContent = user.email || '';
				wrapper.appendChild(name);
				wrapper.appendChild(email);

				return wrapper;
			}

			async function search(term) {
				if (controller) {
					controller.abort();
				}

				controller = new AbortController();
				setStatus(tutorhelperParentLinks.strings.searching);

				const url = new URL(tutorhelperParentLinks.ajaxUrl);
				url.searchParams.set('action', tutorhelperParentLinks.action);
				url.searchParams.set('nonce', tutorhelperParentLinks.nonce);
				url.searchParams.set('search', term);
				url.searchParams.set('student_user_id', form.dataset.studentUserId || '0');
				url.searchParams.set('exclude_linked', form.dataset.excludeLinked || '0');

				try {
					const response = await fetch(url.toString(), {
						credentials: 'same-origin',
						signal: controller.signal
					});
					const payload = await response.json();

					if (!payload.success || !payload.data) {
						throw new Error(
							payload.data && payload.data.message
								? payload.data.message
								: tutorhelperParentLinks.strings.failed
						);
					}

					const users = Array.isArray(payload.data.results)
						? payload.data.results
						: [];

					results.innerHTML = '';

					if (users.length === 0) {
						setStatus(tutorhelperParentLinks.strings.noResults);
						closeResults();
						return;
					}

					users.forEach(function (user) {
						results.appendChild(makeResult(user));
					});
					results.hidden = false;
					setStatus('');
				} catch (error) {
					if (error.name === 'AbortError') {
						return;
					}
					setStatus(error.message || tutorhelperParentLinks.strings.failed);
					closeResults();
				}
			}

			input.addEventListener('input', function () {
				window.clearTimeout(timer);
				const term = input.value.trim();

				if (term.length < 2) {
					closeResults();
					setStatus(tutorhelperParentLinks.strings.minimum);
					return;
				}

				timer = window.setTimeout(function () {
					search(term);
				}, 300);
			});

			input.addEventListener('keydown', function (event) {
				if (event.key === 'Escape') {
					closeResults();
				}
			});

			document.addEventListener('click', function (event) {
				if (!form.contains(event.target)) {
					closeResults();
				}
			});
		});
	});
}());
