(function () {
	'use strict';

	function initialisePasswordVisibility() {
		document.addEventListener('click', function (event) {
			var button = event.target.closest('.tutorhelper-password-toggle');
			if (!button) {
				return;
			}

			var fieldId = button.getAttribute('aria-controls');
			var field = fieldId ? document.getElementById(fieldId) : null;
			if (!field || !field.matches('input[type="password"], input[data-password-visible="true"]')) {
				return;
			}

			var isVisible = 'password' === field.type;
			field.type = isVisible ? 'text' : 'password';

			if (isVisible) {
				field.setAttribute('data-password-visible', 'true');
			} else {
				field.removeAttribute('data-password-visible');
			}

			button.setAttribute('aria-pressed', isVisible ? 'true' : 'false');
			button.textContent = isVisible
				? button.dataset.hideLabel
				: button.dataset.showLabel;
		});
	}

	if ('loading' === document.readyState) {
		document.addEventListener('DOMContentLoaded', initialisePasswordVisibility);
	} else {
		initialisePasswordVisibility();
	}
})();
