(function () {
	'use strict';

	if (typeof tutorhelperStudentAdminQol === 'undefined') {
		return;
	}

	function makeLink(url, label, direction) {
		if (!url) {
			return null;
		}

		var link = document.createElement('a');
		link.className = 'button tutorhelper-hub-pill-button';
		link.href = url;
		link.textContent = (direction === 'previous' ? '← ' : '') + label + (direction === 'next' ? ' →' : '');
		return link;
	}

	function makeDismissible(notice, section) {
		if (!notice || notice.querySelector('.notice-dismiss')) {
			return;
		}

		notice.classList.add('is-dismissible');

		var button = document.createElement('button');
		var label = document.createElement('span');
		button.type = 'button';
		button.className = 'notice-dismiss';
		label.className = 'screen-reader-text';
		label.textContent = section.dataset.dismissLabel || 'Dismiss this notice.';
		button.appendChild(label);
		button.addEventListener('click', function () {
			notice.remove();
		});
		notice.appendChild(button);
	}

	function createNotice(section, message, isError) {
		var notice = document.createElement('div');
		var paragraph = document.createElement('p');
		notice.className = 'notice ' + (isError ? 'notice-error' : 'notice-success') + ' inline';
		paragraph.textContent = message;
		notice.appendChild(paragraph);
		makeDismissible(notice, section);
		return notice;
	}

	function showSectionNotice(section, notice) {
		var content = section.querySelector('.tutorhelper-student-detail-section__content');
		if (!content) {
			return;
		}

		Array.prototype.forEach.call(
			content.querySelectorAll(':scope > .notice'),
			function (existingNotice) {
				existingNotice.remove();
			}
		);

		makeDismissible(notice, section);
		content.insertBefore(notice, content.firstChild);
	}

	function getSaveSuccessMessage(button, section) {
		var label = button ? button.textContent.trim() : '';
		label = label.replace(/^Save\s+/i, '');

		if (!label) {
			return section.dataset.saveSuccess || 'Settings saved.';
		}

		return label.charAt(0).toUpperCase() + label.slice(1) + ' saved.';
	}

	function initialiseLessonOptionSaves() {
		var section = document.getElementById(
			'tutorhelper-student-section-lesson-options-pricing'
		);

		if (!section || typeof window.fetch !== 'function') {
			return;
		}

		Array.prototype.forEach.call(
			section.querySelectorAll(
				'.tutorhelper-student-detail-section__content > .notice'
			),
			function (notice) {
				makeDismissible(notice, section);
			}
		);

		section.addEventListener('submit', function (event) {
			var form = event.target;
			if (
				!form.matches('form[method="post"]')
				|| form.dataset.tutorhelperFullSubmit === 'true'
			) {
				return;
			}

			event.preventDefault();

			var submitButton = event.submitter
				|| form.querySelector('button[type="submit"], input[type="submit"]');
			if (submitButton) {
				submitButton.disabled = true;
			}
			form.setAttribute('aria-busy', 'true');

			var actionUrl = new URL(
				form.getAttribute('action') || window.location.href,
				window.location.href
			);
			var formData = new FormData(form);

			actionUrl.protocol = window.location.protocol;
			actionUrl.host = window.location.host;

			if (
				submitButton
				&& submitButton.name
				&& !formData.has(submitButton.name)
			) {
				formData.append(submitButton.name, submitButton.value);
			}

			formData.set('tutorhelper_student_detail_async', '1');

			window.fetch(actionUrl.toString(), {
				method: 'POST',
				body: formData,
				credentials: 'same-origin'
			})
				.then(function (response) {
					return response.json()
						.catch(function () {
							throw new Error(
								'The server did not return a Student Detail save result.'
							);
						})
						.then(function (payload) {
							if (!response.ok || !payload.success) {
								throw new Error(
									'The Student Detail save was rejected.'
								);
							}

							return payload;
						});
				})
				.then(function () {
					showSectionNotice(
						section,
						createNotice(
							section,
							getSaveSuccessMessage(submitButton, section),
							false
						)
					);
				})
				.catch(function (error) {
					if (window.console && typeof window.console.error === 'function') {
						window.console.error(
							'TutorHelper Student Detail save failed.',
							error
						);
					}

					showSectionNotice(
						section,
						createNotice(
							section,
							section.dataset.saveError
								|| 'The settings could not be saved. Please try again.',
							true
						)
					);
				})
				.then(function () {
					form.removeAttribute('aria-busy');
					if (submitButton) {
						submitButton.disabled = false;
					}
				});
		});
	}

	function buildFilterUrl(form) {
		var url = new URL(
			form.getAttribute('action') || window.location.href,
			window.location.href
		);
		url.search = '';

		new FormData(form).forEach(function (value, key) {
			url.searchParams.append(key, value);
		});

		return url;
	}

	function refreshSectionContent(section, selector, url) {
		var currentTarget = section.querySelector(selector);
		if (!currentTarget) {
			return;
		}

		currentTarget.setAttribute('aria-busy', 'true');

		window.fetch(url.toString(), {
			credentials: 'same-origin'
		})
			.then(function (response) {
				return response.text().then(function (html) {
					if (!response.ok) {
						throw new Error('Filter request failed');
					}
					return html;
				});
			})
			.then(function (html) {
				var responseDocument = new DOMParser().parseFromString(
					html,
					'text/html'
				);
				var responseSection = responseDocument.getElementById(section.id);
				var responseTarget = responseSection
					? responseSection.querySelector(selector)
					: null;

				if (!responseTarget) {
					throw new Error('Filtered section was not returned');
				}

				var replacement = document.importNode(responseTarget, true);
				replacement.setAttribute('aria-live', 'polite');
				currentTarget.replaceWith(replacement);
				section.open = true;
				window.history.replaceState({}, '', url.toString());
			})
			.catch(function () {
				currentTarget.removeAttribute('aria-busy');
				showSectionNotice(
					section,
					createNotice(
						section,
						section.dataset.filterError
							|| 'The filters could not be applied. Please try again.',
						true
					)
				);
			});
	}

	function initialiseSectionFilters() {
		var sections = [
			{
				id: 'tutorhelper-student-section-notes-communication',
				target: '.tutorhelper-pro-student-notes__history'
			},
			{
				id: 'tutorhelper-student-section-lesson-history',
				target: '.tutorhelper-pro-student-history'
			}
		];

		if (typeof window.fetch !== 'function') {
			return;
		}

		sections.forEach(function (settings) {
			var section = document.getElementById(settings.id);
			if (!section) {
				return;
			}

			section.addEventListener('submit', function (event) {
				var form = event.target;
				if (!form.matches('form[method="get"]')) {
					return;
				}

				event.preventDefault();
				refreshSectionContent(
					section,
					settings.target,
					buildFilterUrl(form)
				);
			});

			section.addEventListener('click', function (event) {
				var link = event.target.closest('a');
				if (
					!link
					|| !link.closest(
						'.tutorhelper-student-pagination__links, form[method="get"]'
					)
				) {
					return;
				}

				event.preventDefault();
				refreshSectionContent(
					section,
					settings.target,
					new URL(link.href, window.location.href)
				);
			});
		});
	}

	function initialise() {
		initialiseLessonOptionSaves();
		initialiseSectionFilters();

		var headerActions = document.querySelector('.tutorhelper-student-detail__header-actions');
		if (!headerActions) {
			return;
		}

		var previous = makeLink(
			tutorhelperStudentAdminQol.previousUrl || '',
			tutorhelperStudentAdminQol.labels.previous,
			'previous'
		);
		var next = makeLink(
			tutorhelperStudentAdminQol.nextUrl || '',
			tutorhelperStudentAdminQol.labels.next,
			'next'
		);

		var navigation = document.createElement('div');
		navigation.className = 'tutorhelper-student-detail__student-navigation tutorhelper-booking-hub__view-switcher';
		navigation.setAttribute('aria-label', 'Student navigation');
		if (previous) {
			navigation.appendChild(previous);
		}
		if (next) {
			navigation.appendChild(next);
		}
		if (navigation.childNodes.length) {
			headerActions.insertBefore(navigation, headerActions.firstChild);
		}

		if (window.location.hash) {
			var target = document.getElementById(window.location.hash.substring(1));
			var disclosure = target ? target.closest('details') : null;
			while (disclosure) {
				disclosure.open = true;
				disclosure = disclosure.parentElement
					? disclosure.parentElement.closest('details')
					: null;
			}
		}

		var form = document.querySelector('.tutorhelper-student-edit-form');
		if (!form) {
			return;
		}

		if (!form.id) {
			form.id = 'tutorhelper-student-edit-form';
		}

		var bottomActions = form.querySelector('.tutorhelper-student-edit-form__actions');
		var saveButton = bottomActions
			? bottomActions.querySelector('button[type="submit"]')
			: null;
		var cancelButton = bottomActions
			? bottomActions.querySelector('a')
			: null;

		if (saveButton) {
			saveButton.setAttribute('form', form.id);
			headerActions.appendChild(saveButton);
		}

		if (cancelButton) {
			headerActions.appendChild(cancelButton);
		}

		if (bottomActions && !bottomActions.children.length) {
			bottomActions.remove();
		}
	}

	window.addEventListener('load', initialise);
})();
