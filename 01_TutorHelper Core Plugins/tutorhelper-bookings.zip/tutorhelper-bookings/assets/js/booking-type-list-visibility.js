(function () {
	'use strict';

	if (typeof tutorhelperBookingTypeListVisibility === 'undefined') {
		return;
	}

	var bookingTypes = tutorhelperBookingTypeListVisibility.bookingTypes || {};

	function initialise() {
		document
			.querySelectorAll('.tutorhelper-booking-type-item[data-booking-type-id]')
			.forEach(function (item) {
				var bookingTypeId = String(item.dataset.bookingTypeId || '');
				var details = bookingTypes[bookingTypeId];
				if (!details) {
					return;
				}

				var meta = item.querySelector('.tutorhelper-booking-type-item__main small');
				if (meta && !meta.querySelector('[data-booking-type-visibility]')) {
					var separator = document.createElement('span');
					separator.setAttribute('aria-hidden', 'true');
					separator.textContent = ' · ';

					var visibility = document.createElement('span');
					visibility.className = 'tutorhelper-booking-type-item__visibility';
					visibility.setAttribute('data-booking-type-visibility', details.visibility || '');
					visibility.textContent = details.label || '';

					meta.appendChild(separator);
					meta.appendChild(visibility);
				}

				if (details.isHidden) {
					item.classList.add('is-hidden-online');
				}
			});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initialise);
	} else {
		initialise();
	}
}());
