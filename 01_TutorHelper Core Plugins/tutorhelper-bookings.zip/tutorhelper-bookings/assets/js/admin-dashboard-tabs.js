( function () {
	'use strict';

	var dashboard = document.querySelector( '.tutorhelper-dashboard__tabs' );
	var config = window.tutorhelperDashboardTabs || {};

	if ( ! dashboard ) {
		return;
	}

	var tabList = dashboard.querySelector( '[role="tablist"]' );
	var buttons = Array.prototype.slice.call(
		dashboard.querySelectorAll( '[role="tab"]' )
	);

	function tabButton( tab ) {
		return dashboard.querySelector(
			'[role="tab"][data-dashboard-tab="' + tab + '"]'
		);
	}

	function tabPanel( tab ) {
		return dashboard.querySelector(
			'.tutorhelper-dashboard__tab-panel[data-dashboard-tab="' + tab + '"]'
		);
	}

	function activeTab() {
		var selected = dashboard.querySelector( '[role="tab"][aria-selected="true"]' );
		return selected ? selected.dataset.dashboardTab : '';
	}

	function setStatus( message, error ) {
		var status = dashboard.querySelector( '.tutorhelper-dashboard__tabs-status' );

		if ( ! status ) {
			return;
		}

		status.textContent = message || '';
		status.classList.toggle( 'is-error', !! error );
	}

	function updateUrl( tab ) {
		var url = new window.URL( window.location.href );
		url.searchParams.set( 'dashboard_tab', tab );
		window.history.replaceState( {}, '', url.toString() );
	}

	function activate( tab, focus ) {
		var button = tabButton( tab );
		var panel = tabPanel( tab );

		if ( ! button || ! panel ) {
			return;
		}

		buttons.forEach( function ( item ) {
			var isActive = item === button;
			var itemPanel = tabPanel( item.dataset.dashboardTab );

			item.setAttribute( 'aria-selected', isActive ? 'true' : 'false' );
			item.tabIndex = isActive ? 0 : -1;

			if ( itemPanel ) {
				itemPanel.hidden = ! isActive;
			}
		} );

		dashboard.dataset.activeTab = tab;
		updateUrl( tab );

		if ( focus ) {
			button.focus();
		}
	}

	function responsePanel( documentNode, tab ) {
		return documentNode.querySelector(
			'.tutorhelper-dashboard__tab-panel[data-dashboard-tab="' + tab + '"]'
		);
	}

	function refreshActiveTab() {
		var tab = activeTab();
		var panel = tabPanel( tab );
		var form = document.querySelector( '.tutorhelper-dashboard__filters' );

		if ( ! tab || ! panel || ! form || panel.dataset.loading === '1' ) {
			return;
		}

		var refreshButton = panel.querySelector(
			'[data-dashboard-refresh-tab]'
		);
		var parameters = new window.URLSearchParams();
		var url = new window.URL( form.action, window.location.origin );

		new window.FormData( form ).forEach( function ( value, key ) {
			parameters.append( key, value );
		} );
		parameters.set( 'dashboard_tab', tab );
		url.search = parameters.toString();

		panel.dataset.loading = '1';
		panel.setAttribute( 'aria-busy', 'true' );

		if ( refreshButton ) {
			refreshButton.disabled = true;
		}

		setStatus( config.refreshingText || '', false );

		window.fetch( url.toString(), {
			credentials: 'same-origin'
		} ).then( function ( response ) {
			if ( ! response.ok ) {
				throw new Error( 'Dashboard refresh failed.' );
			}

			return response.text();
		} ).then( function ( markup ) {
			var responseDocument = new window.DOMParser().parseFromString(
				markup,
				'text/html'
			);
			var replacement = responsePanel( responseDocument, tab );
			var currentContent = panel.querySelector(
				'.tutorhelper-dashboard__tab-panel-content'
			);
			var replacementContent = replacement
				? replacement.querySelector(
					'.tutorhelper-dashboard__tab-panel-content'
				)
				: null;
			var period = document.querySelector(
				'.tutorhelper-dashboard__period'
			);
			var replacementPeriod = responseDocument.querySelector(
				'.tutorhelper-dashboard__period'
			);

			if ( ! replacementContent || ! currentContent ) {
				throw new Error( 'Dashboard tab content was unavailable.' );
			}

			currentContent.innerHTML = replacementContent.innerHTML;

			if ( period && replacementPeriod ) {
				period.textContent = replacementPeriod.textContent;
			}

			setStatus( '', false );
			updateUrl( tab );
			document.dispatchEvent(
				new window.CustomEvent( 'tutorhelper:dashboard-tab-refreshed', {
					detail: { tab: tab }
				} )
			);
		} ).catch( function () {
			setStatus(
				config.errorText || '',
				true
			);
		} ).finally( function () {
			delete panel.dataset.loading;
			panel.removeAttribute( 'aria-busy' );

			if ( refreshButton ) {
				refreshButton.disabled = false;
			}
		} );
	}

	tabList.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '[role="tab"]' );

		if ( button && dashboard.contains( button ) ) {
			activate( button.dataset.dashboardTab, true );
		}
	} );

	tabList.addEventListener( 'keydown', function ( event ) {
		var index = buttons.indexOf( document.activeElement );
		var nextIndex;

		if ( -1 === index ) {
			return;
		}

		if ( 'ArrowRight' !== event.key && 'ArrowLeft' !== event.key
			&& 'Home' !== event.key && 'End' !== event.key ) {
			return;
		}

		event.preventDefault();

		if ( 'Home' === event.key ) {
			nextIndex = 0;
		} else if ( 'End' === event.key ) {
			nextIndex = buttons.length - 1;
		} else {
			nextIndex = 'ArrowRight' === event.key
				? ( index + 1 ) % buttons.length
				: ( index - 1 + buttons.length ) % buttons.length;
		}

		activate( buttons[ nextIndex ].dataset.dashboardTab, true );
	} );

	document.addEventListener( 'click', function ( event ) {
		var refreshButton = event.target.closest(
			'[data-dashboard-refresh-tab]'
		);

		if ( refreshButton && dashboard.contains( refreshButton ) ) {
			event.preventDefault();
			refreshActiveTab();
		}
	} );

	document.addEventListener( 'submit', function ( event ) {
		if ( event.target.matches( '.tutorhelper-dashboard__filters' ) ) {
			event.preventDefault();
			refreshActiveTab();
		}
	} );

	activate( activeTab(), false );
}() );
