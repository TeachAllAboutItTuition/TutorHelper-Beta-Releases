/**
 * TutorHelper student booking extension field bridge.
 *
 * Allows add-ons to submit explicitly marked form fields without
 * Core needing to understand the add-on's domain.
 */
(function () {
	'use strict';

	document.addEventListener(
		'DOMContentLoaded',
		function () {
			if (
				typeof tutorhelperStudentBooking === 'undefined'
				|| ! tutorhelperStudentBooking.ajaxUrl
			) {
				return;
			}

			const baseAjaxUrl =
				tutorhelperStudentBooking.ajaxUrl;

			document
				.querySelectorAll(
					'[data-tutorhelper-student-booking] [data-booking-form]'
				)
				.forEach(function (form) {
					form.addEventListener(
						'submit',
						function () {
							let requestUrl;

							try {
								requestUrl =
									new URL(
										baseAjaxUrl,
										window.location.href
									);
							} catch (error) {
								return;
							}

							form
								.querySelectorAll(
									'[data-tutorhelper-booking-extension-field][name]'
								)
								.forEach(function (field) {
									if (
										(
											'radio' === field.type
											|| 'checkbox' === field.type
										)
										&& ! field.checked
									) {
										return;
									}

									requestUrl.searchParams.set(
										field.name,
										field.value
									);
								});

							tutorhelperStudentBooking.ajaxUrl =
								requestUrl.toString();

							window.setTimeout(
								function () {
									tutorhelperStudentBooking.ajaxUrl =
										baseAjaxUrl;
								},
								0
							);
						},
						true
					);
				});
		}
	);
})();
