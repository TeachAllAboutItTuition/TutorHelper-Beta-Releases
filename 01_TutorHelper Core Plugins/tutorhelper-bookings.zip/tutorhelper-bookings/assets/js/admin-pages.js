document.addEventListener('DOMContentLoaded', function () {
    if (
        typeof tutorhelperAdminPages === 'undefined'
        || !tutorhelperAdminPages.upgradeUrl
    ) {
        return;
    }

    const link = document.querySelector(
        '#toplevel_page_tutorhelper a[href="'
        + tutorhelperAdminPages.upgradeUrl
        + '"]'
    );

    if (!link) {
        return;
    }

    link.target = '_blank';
    link.rel = 'noopener noreferrer';
});
