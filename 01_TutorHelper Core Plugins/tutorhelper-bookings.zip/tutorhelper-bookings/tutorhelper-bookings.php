<?php
/**
 * Plugin Name:       TutorHelper Bookings
 * Plugin URI:        https://tutorhelper.co.uk/wp-plugin-core/
 * Description:       TutorHelper Bookings is a standalone booking plugin for tutors. Manage availability, bookings, and student accounts from one easy dashboard.
 * Version:           2.2.4
 * Requires at least: 6.4
 * Requires PHP:      7.1
 * Author:            Holly Billinghurst
 * Author URI:        https://tutorhelper.co.uk/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tutorhelper-bookings
 * Domain Path:       /languages
 *
 * @package TutorHelper_Bookings
 */

/*
 * TutorHelper Bookings is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * TutorHelper Bookings is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TutorHelper Bookings. If not, see https://www.gnu.org/licenses/gpl-2.0.html.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Plugin version.
 *
 * Developer note/reminder: This version should match the Stable tag in readme.txt 
 * whenever a release is published.
 */
if ( ! defined( 'TUTORHELPER_BOOKINGS_VERSION' ) ) {
	define( 'TUTORHELPER_BOOKINGS_VERSION', '2.2.4' );
}


/**
 * Current database schema version.
 * 
 */
if ( ! defined( 'TUTORHELPER_BOOKINGS_DB_VERSION' ) ) {
	define( 'TUTORHELPER_BOOKINGS_DB_VERSION', '1.6.1' );
}




/*
 * Main plugin file.
 *
 * Used by activation hooks, deactivation hooks and plugin helpers.
 */
if ( ! defined( 'TUTORHELPER_BOOKINGS_FILE' ) ) {
	define( 'TUTORHELPER_BOOKINGS_FILE', __FILE__ );
}

/*
 * Absolute path to the plugin directory.
 */
if ( ! defined( 'TUTORHELPER_BOOKINGS_PATH' ) ) {
	define(
		'TUTORHELPER_BOOKINGS_PATH',
		plugin_dir_path( TUTORHELPER_BOOKINGS_FILE )
	);
}

/*
 * Public URL for the plugin directory.
 */
if ( ! defined( 'TUTORHELPER_BOOKINGS_URL' ) ) {
	define(
		'TUTORHELPER_BOOKINGS_URL',
		plugin_dir_url( TUTORHELPER_BOOKINGS_FILE )
	);
}

/*
 * Plugin basename, for example:
 * tutorhelper-bookings/tutorhelper-bookings.php
 */
if ( ! defined( 'TUTORHELPER_BOOKINGS_BASENAME' ) ) {
	define(
		'TUTORHELPER_BOOKINGS_BASENAME',
		plugin_basename( TUTORHELPER_BOOKINGS_FILE )
	);
}

/*
 * Load the database schema manager and primary plugin controller.
 */
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/class-tutorhelper-bookings-database.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/class-tutorhelper-currency.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/class-tutorhelper-roles.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/modules/booking-types/' . 'class-tutorhelper-booking-types-module.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/modules/bookings/' . 'class-tutorhelper-bookings-module.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/modules/exclusions/' . 'class-tutorhelper-date-exclusions-module.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/modules/analytics/' . 'class-tutorhelper-analytics-module.php';



require_once TUTORHELPER_BOOKINGS_PATH . 'includes/class-tutorhelper-logger.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/diagnostics/class-tutorhelper-system-report.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/diagnostics/class-tutorhelper-stripe-log.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/diagnostics/class-tutorhelper-diagnostics.php';


require_once TUTORHELPER_BOOKINGS_PATH . 'includes/admin/class-tutorhelper-admin.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/admin/class-tutorhelper-dashboard.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/admin/class-tutorhelper-settings.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/admin/class-tutorhelper-booking-hub.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/admin/class-tutorhelper-admin-pages.php';


require_once TUTORHELPER_BOOKINGS_PATH . 'includes/modules/availability/' . 'class-tutorhelper-availability-module.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/modules/students/' . 'class-tutorhelper-students-module.php';


require_once TUTORHELPER_BOOKINGS_PATH . 'includes/class-tutorhelper-bookings.php';



TutorHelper_Booking_Types_Module::init();
TutorHelper_Bookings_Module::init();
TutorHelper_Date_Exclusions_Module::init();
TutorHelper_Students_Module::init();
TutorHelper_Availability_Module::init();
TutorHelper_Analytics_Module::init();

TutorHelper_Stripe_Log::init();

if ( is_admin() ) {
	TutorHelper_Admin::init();
	TutorHelper_Dashboard::init();
	TutorHelper_Settings::init();
	TutorHelper_Booking_Hub::init();
	TutorHelper_Admin_Pages::init();
	TutorHelper_Diagnostics::init();
}
	


/*
 * Load lifecycle handlers explicitly.
 *
 * Activation and deactivation hooks should not depend on runtime autoloading.
 */
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/class-tutorhelper-bookings-activator.php';
require_once TUTORHELPER_BOOKINGS_PATH . 'includes/class-tutorhelper-bookings-deactivator.php';

/*
 * Register plugin lifecycle hooks.
 */
register_activation_hook(
	TUTORHELPER_BOOKINGS_FILE,
	array( 'TutorHelper_Bookings_Activator', 'activate' )
);

register_deactivation_hook(
	TUTORHELPER_BOOKINGS_FILE,
	array( 'TutorHelper_Bookings_Deactivator', 'deactivate' )
);

/**
 * Start TutorHelper Bookings.
 *
 * Delaying startup until plugins_loaded allows WordPress and any compatible
 * extensions to finish loading first.
 *
 * @return void
 */
function tutorhelper_bookings_run() {
	$plugin = TutorHelper_Bookings::instance();
	$plugin->run();
}

add_action( 'plugins_loaded', 'tutorhelper_bookings_run' );
