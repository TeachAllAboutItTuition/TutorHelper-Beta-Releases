<?php
/**
 * Uninstall TutorHelper Bookings.
 *
 * This file runs only when TutorHelper Bookings is deleted through the
 * WordPress Plugins screen.
 *
 * @package TutorHelper_Bookings
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/*
 * TutorHelper Bookings intentionally retains its data when the plugin is
 * uninstalled.
 *
 * Booking Types, availability, bookings, settings and related TutorHelper
 * data may represent an important tutoring record. Retaining these records
 * also allows the plugin to restore the existing booking configuration if it
 * is installed again later.
 *
 * No plugin data is deleted by this uninstall routine.
 *
 * Site administrators who need to remove retained TutorHelper data should
 * do so separately after confirming that the information is no longer
 * required for operational, safeguarding, accounting or other retention
 * purposes.
 */
