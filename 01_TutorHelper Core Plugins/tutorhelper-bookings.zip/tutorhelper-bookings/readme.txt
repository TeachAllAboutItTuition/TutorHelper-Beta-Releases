=== TutorHelper Bookings ===
Contributors: teachallaboutit
Tags: tutor booking, lesson scheduling, availability calendar, student bookings, appointment booking 
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.1
Stable tag: 2.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage lesson availability, accept student booking requests and organise tutoring appointments directly from WordPress.

== Description ==

TutorHelper Bookings is a WordPress booking plugin created specifically for independent tutors and tuition providers.

It provides the Core tools needed to publish lesson availability, allow registered students to request available lessons, and manage those bookings from your own WordPress website.

Instead of sending students to a separate scheduling service, TutorHelper keeps your booking experience within the website you already manage.

= Designed for tutors =

* 🆕 New Feature: 🖥️ Adds a secure extension point for authorised linked-account booking contexts while retaining each student’s normal booking rules.

TutorHelper Bookings follows a request-and-confirm workflow designed around private tuition:

1. The tutor creates one or more Booking Types.
2. The tutor publishes the dates and times they are available.
3. A registered student chooses an available lesson and submits a booking request.
4. The request appears in the TutorHelper Booking Hub as awaiting confirmation.
5. The tutor reviews the request and confirms the lesson.
6. The student can view the lesson from their TutorHelper student dashboard.
7. TutorHelper sends the appropriate request, confirmation and cancellation emails throughout the process.

The free Core plugin does not require an external TutorHelper booking service.

= Core features =

* Create and manage multiple Booking Types.
* Set lesson duration and price information.
* Configure online, telephone, in-person and custom lesson locations.
* Set minimum booking notice for each Booking Type.
* Enable or disable student cancellation for each Booking Type.
* Set a minimum cancellation notice period.
* Create recurring weekly tutor availability.
* Restrict availability to selected Booking Types and locations.
* Make date-specific changes to recurring availability.
* Remove individual dates or ranges from recurring availability.
* Prevent students from requesting unavailable or conflicting lesson times.
* View lessons and availability through the TutorHelper Booking Hub calendar.
* Review remaining student-bookable lesson hours on the tutor dashboard.
* Record privacy-conscious daily booking-page view totals with configurable retention.
* View the Booking Hub by week or month.
* Create and edit tutor-entered bookings.
* Confirm student lesson requests from the Booking Hub.
* Allow registered students to request available lessons online.
* Display the responsive booking form using a shortcode.
* Give students a dashboard showing pending, upcoming, cancelled and previous lessons.
* Allow students to cancel eligible lessons and provide a cancellation reason.
* Allow tutors to cancel lessons and provide a reason to the student.
* Keep cancelled lessons visible as part of the booking history.
* Manage registered TutorHelper students from WordPress.
* Send automatic lesson request, confirmation and cancellation emails.
* Enable or disable individual Core email templates.
* Edit the subject and message text of the fixed Core email templates.
* Configure shared email sender, contact and privacy-policy details.
* Configure the pages used for student booking, lesson management and login.
* Use the standard WordPress login page or select a custom login page.
* Configure the working currency used for Booking Type prices and new bookings.
* Run TutorHelper Diagnostics to check whether the essential booking setup is ready.
* Download diagnostic system information and TutorHelper technical logs when troubleshooting.
* Store Core booking and availability information within the WordPress database.

= Booking Shortcodes =

Use the following shortcode to display the student lesson booking form:

`[tutorhelper_student_booking]`

Use the following shortcode to display the logged-in student's lesson dashboard:

`[tutorhelper_student_dashboard]`

Students must be logged in with a registered TutorHelper student account to request lessons or view their lesson dashboard.

= Student booking workflow =

Student bookings are submitted as lesson requests.

A new student request is not automatically confirmed. The tutor can review the request from the TutorHelper Booking Hub and change its status to Confirmed.

TutorHelper Core is designed around individual lesson requests. Recurring booking requests, multiple simultaneous bookings and integrated online payments are not included in Core.

= Booking Types =

Booking Types describe the lessons or services you offer.

Each Booking Type can define information including:

* Title and description.
* Lesson duration.
* Price information.
* Available location types.
* Location or joining details.
* Minimum booking notice.
* Whether student cancellation is allowed.
* Minimum cancellation notice.
* Whether the Booking Type can be requested through online booking.

Booking Types can be reordered and archived when they are no longer required.

= Availability =

TutorHelper Availability controls when students may request lessons.

You can create recurring weekly availability and then make changes to individual dates or date ranges when your normal timetable changes.

Availability can also be restricted to particular Booking Types or lesson locations.

TutorHelper checks existing bookings and tutor unavailability before allowing a student to request a lesson time.

= Booking Hub =

The TutorHelper Booking Hub provides a calendar-based view of your lessons and availability.

Tutors can use it to:

* View bookings by week or month.
* Review pending student lesson requests.
* Confirm lesson requests.
* Create tutor-entered bookings.
* Edit upcoming bookings.
* Cancel lessons.
* Review cancelled lessons and cancellation reasons.
* Work with Booking Types and Availability from the booking interface.

= Student dashboard =

The student dashboard gives logged-in students a simple view of their lessons.

It separates lessons into useful sections including:

* Pending requests.
* Upcoming lessons.
* Cancelled lessons.
* Previous lessons and booking history.

Where a Booking Type permits student cancellation and the required notice remains, the student can cancel the lesson from their dashboard and provide a cancellation reason.

= Booking emails =

TutorHelper Core includes fixed automatic email templates for the standard booking workflow.

These include messages for:

* A new student lesson request sent to the tutor.
* Confirmation that the student's request was received.
* A confirmed lesson.
* A cancelled lesson.
* A student cancellation notification sent to the tutor.

Core users can enable or disable these registered templates and edit their subject and message text.

The layout and template types themselves remain controlled by TutorHelper Core.

Emails are sent using the standard WordPress `wp_mail()` function. Actual email delivery can therefore be affected by the website's hosting configuration or any SMTP or transactional email plugin in use.

= TutorHelper Diagnostics =

TutorHelper Diagnostics checks important parts of the Core booking setup and highlights anything that may need attention.

Checks include areas such as:

* Database readiness.
* Student booking and dashboard pages.
* Active Booking Types.
* Tutor availability.
* Tutor configuration.
* Email settings.
* Privacy-policy configuration.

The Diagnostics screen also provides technical system information and TutorHelper log information that can be reviewed when troubleshooting.

Diagnostic information is not sent automatically to TutorHelper.

= Privacy =

TutorHelper Bookings stores information required to provide and manage lesson bookings.

Depending on how the plugin is used, this may include:

* WordPress user IDs.
* Student account information.
* Student names.
* Student email addresses.
* Booking dates and times.
* Booking Type information.
* Lesson location and joining information.
* Student booking notes.
* Booking status.
* Cancellation status and reasons.
* Tutor and student relationships required to manage bookings.

Core booking and availability information is stored within the WordPress database.

TutorHelper Bookings does not automatically send booking information to an external TutorHelper booking service.

Automatic emails are sent through the WordPress `wp_mail()` system. Information contained within an email will therefore be processed by the website's configured email-delivery system.

TutorHelper also maintains a limited technical diagnostic log. The logger is designed to record technical information rather than student names, email addresses or other unnecessary personal information.

Website owners are responsible for explaining how booking information is collected, processed, stored and retained within their own privacy policy and for complying with the privacy requirements that apply to their organisation.

= TutorHelper Pro =

TutorHelper Bookings Core is designed to remain useful as a standalone free plugin.

Additional TutorHelper Pro functionality may be available separately for tutors who require more advanced booking tools.

Planned advanced functionality may include features such as:

* Recurring lesson bookings.
* Multiple lesson bookings.
* Integrated online payments.
* More advanced Booking Type restrictions.
* Term-time-only booking rules.
* Additional booking automation.
* More advanced booking management tools.
* Extended email customisation, layouts and branding.

TutorHelper Bookings Core does not require TutorHelper Pro in order to provide its standard booking workflow.

= Support =

Support for the free plugin is available through the WordPress.org support forum.

TutorHelper documentation, tutorials and information about additional TutorHelper products are available from the TutorHelper website.

Video tutorials are also available through the TutorHelper YouTube channel.

== Installation ==

1. Install **TutorHelper Bookings** through the WordPress Plugins screen, or upload the plugin to your `/wp-content/plugins/` directory.
2. Activate **TutorHelper Bookings**.
3. Open **TutorHelper > Settings** and review the Pages, Currency and Email settings.
4. Create a WordPress page for student booking and add the `[tutorhelper_student_booking]` shortcode.
5. Create a WordPress page for the student lesson dashboard and add the `[tutorhelper_student_dashboard]` shortcode.
6. Select those pages under **TutorHelper > Settings > Pages**.
7. Optionally select a custom student Login page. If none is selected, TutorHelper uses the standard WordPress login page.
8. Open the TutorHelper Booking Hub and create at least one Booking Type.
9. Add the dates and times that students may request under Availability.
10. Ensure the students who should use online booking have registered TutorHelper student accounts.
11. Open **Tools > TutorHelper Diagnostics** to check that the essential booking setup is ready.
12. Test the booking process using a student account before publishing the booking page to students.

== Frequently Asked Questions ==

= Do students need a WordPress account? =

Yes.

Students must be logged in with a registered TutorHelper student account to request a lesson or view their lesson dashboard.

This allows TutorHelper to associate bookings with the correct student and prevents anonymous lesson requests.

= Is Tutor LMS required? =

No.

TutorHelper Bookings is a standalone WordPress booking plugin and does not require Tutor LMS.

= Does a student booking become confirmed immediately? =

No.

A student submits a lesson request. The request is created as awaiting confirmation so that the tutor can review it from the Booking Hub.

The tutor can then confirm the lesson.

= Can I create more than one type of lesson? =

Yes.

You can create multiple Booking Types with different names, durations, prices, locations, notice periods and cancellation rules.

= Can I offer both online and in-person lessons? =

Yes.

Booking Types and Availability can support online, telephone, in-person and custom lesson locations.

= Can I control how much notice students must give when booking? =

Yes.

Each Booking Type has a minimum booking-notice setting.

Times that fall inside the minimum-notice period are not offered to students for online booking.

= Can students cancel lessons? =

Yes, where cancellation is enabled for the relevant Booking Type.

You can also configure how much notice the student must give before cancellation is no longer available.

Cancelled lessons remain part of the student's booking history.

= Can tutors cancel lessons? =

Yes.

Tutors can cancel a lesson from the Booking Hub and provide a cancellation reason for the student.

= Can students make recurring bookings? =

Not in TutorHelper Bookings Core.

Core handles individual lesson requests. Recurring and multiple-booking functionality may be provided through additional TutorHelper functionality.

= Does TutorHelper Bookings accept online payments? =

TutorHelper Bookings Core does not process integrated online payments.

Price information can be stored against Booking Types and bookings, but the Core student booking workflow does not require or collect payment.

Integrated payment functionality may be available separately.

= Can I edit the automatic emails? =

Yes.

Core provides a fixed set of booking email templates. You can enable or disable individual templates and edit their subject and message text.

More advanced email layouts, branding and custom template functionality may be available separately.

= How are booking emails sent? =

Emails are sent using the standard WordPress `wp_mail()` function.

If your website has difficulty delivering WordPress emails, you may wish to configure a suitable SMTP or transactional email solution.

= Can I use my own login page? =

Yes.

You can select a Login page under **TutorHelper > Settings > Pages**.

If you leave this setting empty, TutorHelper uses the standard WordPress login page.

= Does the plugin connect to an external booking service? =

No.

TutorHelper Core booking and availability data is stored within your WordPress website.

= What happens if I uninstall or delete the plugin? =

TutorHelper Bookings intentionally keeps its booking, availability, settings and related data when the plugin is uninstalled.

This allows an existing TutorHelper booking setup and booking history to be restored if the plugin is installed again later.

Website owners remain responsible for deciding how long personal and booking information should be retained and for removing information when it is no longer required under their own privacy and data-retention obligations.

= How can I check whether TutorHelper is configured correctly? =

Open **Tools > TutorHelper Diagnostics**.

The readiness checks highlight important configuration items and provide technical information that may help with troubleshooting.

== Screenshots ==

1. TutorHelper Booking Hub calendar for viewing and managing lessons.
2. Booking Type management for configuring the lessons and services students may request.
3. Tutor Availability management for recurring lesson times and date-specific changes.
4. Responsive student lesson booking form displayed using the `[tutorhelper_student_booking]` shortcode.
5. Student lesson dashboard displayed using the `[tutorhelper_student_dashboard]` shortcode.
6. TutorHelper student management screen for viewing registered students.
7. Core booking email template settings for automatic request, confirmation and cancellation messages.
8. TutorHelper page settings for choosing the booking, student dashboard and login pages.
9. TutorHelper Diagnostics showing Core booking readiness and technical system information.

== Changelog ==

= 2.2.4 =

* 🐛 Fix: 🎛️ Supplies the existing student to Edit Booking price previews so requested recalculations display the correct amount.

= 2.2.3 =

* 🐛 Fix: 🎛️ Updates the Edit Booking price to save from the selected Booking Type and duration when price recalculation is chosen.

= 2.2.2 =

* ✨ Improvement: Adds a supported, authorised deletion service for unconfirmed booking occurrences resolved from an add-on workflow.

= 2.2.1 =

* 🆕 New Feature: 💳 Adds a separate protected Stripe Payment Log in TutorHelper Diagnostics, with download, clear and automatic 30-day retention when an active Pro Stripe integration is configured.
* ✨ Add: 🌐 Adds the External student account status for secure public Group Lesson registration. Existing student accounts remain Live automatically.


* 🐛 Fix: 🔄 Reinitialises a restored Parent Dashboard booking form so dates, times and payment controls remain interactive after switching tabs.

* 🚀 Improvement: 💳 Passes the selected student or parent-booking payment method securely through the shared booking form, while keeping the normal request route where no Pro payment option is available.

* 🐛 Fix: ⏱️ Stops a Booking Type buffer from automatically extending a tutor-managed lesson’s saved end time and blocking valid back-to-back manual lessons.
* 🚀 Improvement: ⚙️ Adds an explicit per-manual-booking checkbox so tutors can choose whether the Booking Type’s after-lesson buffer applies.


* 🐛 Fix: 🕒 Adds a safe, tutor-confirmed Diagnostics repair for legacy bookings that saved local times as UTC and appear one hour out during British Summer Time.


* 🐛 Fix: 🎛️ Prevents a lesson being treated as a conflict with itself while the tutor is editing it. Genuine clashes with other bookings remain blocked.

* 🚀 Improvement: 🎛️ Names the student, Booking Type and booking ID responsible for a genuine lesson-time clash in the tutor booking editor.

* 🐛 Fix: Restores the current Booking Type or student-specific price for every new booking, while preserving the saved price on existing bookings unless the tutor explicitly chooses to recalculate it.

* 🐛 Fix: 🎛️ Keeps the Edit Booking price-choice radio controls compact and aligned instead of stretching across the form.

* 🐛 Fix: 💷 Preserves an existing booking’s saved price snapshot when tutors edit it; the edit preview shows the exact retained amount and lets tutors explicitly choose a server-calculated replacement price before saving.

* 🚀 Improvement: 🧾 Records previous and new lesson prices, together with the pricing basis, whenever a booking is updated so price changes are traceable in Diagnostics.

* 🚀 Improvement: 🎛️ Organises the Tutor Dashboard into logical tabs and refreshes only the selected section when filters are applied.

* 🐛 Fix: 🎛️ Shows every linked Parent Account and its relationship label in the read-only Student Details view.

* ♻️ Update: Adds a student-dashboard extension point after the My Lessons cards so add-ons can place related content in a predictable position.

* ♿ Accessibility: Adds reusable show/hide controls and password-manager metadata to Student Password Management and the front-end login and reset forms.

* 🐛 Fix: Prevents Student Detail in-place saves from confusing the hidden WordPress action field with the form destination.
* ♻️ Update: 🎛️ Reorganises Student Details into a compact account layout with Booking Access beside the student’s main information.
* 🆕 New Feature: Adds ordered, reusable Student Detail disclosure hooks so add-ons can extend existing sections, describe their data or register new sections.
* 🚀 Improvement: Reuses the full-width Password Management card styling across the Student Detail sections, with in-place filters and JSON-backed dismissible settings confirmations.
* ♻️ Update: 🎛️ Adds extension points for add-ons to provide scoped booking-edit controls and update handling.
* 🔎 Adds an extensible Students filter for accounts without an active linked parent, used by TutorHelper Pro dashboard reporting.
* 🆕 New Feature: Adds a dedicated Privacy Policy page setting alongside Terms and Conditions.
* 🐛 Fix: Uses the configured student login page in new-account and password-reset emails.
* 🐛 Fix: Handles password setup and reset securely on the front-end student login page.

* Shows lesson status beneath each student or group name and supports Pro finance status details across calendar views.
* Displays unconfirmed lessons in neutral grey so they are immediately distinguishable.
* Keeps Jump to date within the Booking Hub Calendar tab.
* Renames student-facing How to join details to Lesson Notes.

* Fixes new Parent Account notifications so they use the editable TutorHelper New account template instead of WordPress's default email.
* Sends Parent Account welcome messages through the shared branded sender and Email delivery history.
* Reports a clear admin error when the account is created but its welcome email cannot be sent.
* Keeps the timetable and full-details weekly calendar displays mutually exclusive when switching views.

= 2.2.0 =

* Adds a timetable-style weekly calendar with a time axis for quick visual planning.
* Adds a saved Timetable / Full details switch while preserving the existing detailed week and Month view.
* Positions availability and colour-coded bookings through each day; compact bookings show the student name and support add-on labels such as Group names.

= 2.1.1 =

* Adds a clear booking-page heatmap legend with actual minimum and maximum view counts, plus hover guidance.
* Labels dashboard cards that open another Booking Hub screen.
* Makes the editable new-account and password-reset templates visible in the Emails screen.

= 2.1.0 =

* Adds wrapped Booking Hub tabs for extension-heavy installations.
* Adds reusable dashboard expansion support for reports without full-page navigation.
* Adds editable, branded account and password email templates.



= 2.0.0 =

* 🆕 New Feature: Added dashboard navigation with quick links to book a lesson and log out.
* 🆕 New Feature: Added an optional Account details tab where students can update their TutorHelper profile, contact details and postal address, with a WooCommerce My Account link when available.
* 🆕 New Feature: Added a Terms and Conditions page setting for registration and agreement workflows.
* 🚀 Improvement: Tutors can reject unpaid lesson requests so they no longer remain in New Requests.
* 🚀 Improvement: Added the {first_name} field to Core email templates.
* 🚀 Improvement: Expanded Parent Account management to support multiple linked parents or guardians and a clearly managed primary relationship.
* 🔒 Security: Hardened student and Parent Account request validation, nonce handling, redirects and database access.
* 🐛 Fix: Corrected additional Parent Account linking and protected unsaved Student Details during relationship actions.
* 🐛 Fix: Improved dashboard account-update errors and permission responses.
* 🚀 Improvement: Refined diagnostics, exports, analytics and Booking Hub interfaces for release readiness.

= 1.1.2 =

* 🐛 Fix: Prevented Parent Account search controls from being mistaken for unsaved Student Details, allowing multiple accounts to be linked to one student.

= 1.1.1 =

* 🆕 New Feature: Added remaining bookable-hours reporting based on the same availability, exclusions, bookings, notice periods and Booking Type buffers used by the student booking form.
* 🆕 New Feature: Added privacy-conscious booking-page view totals, comparison trends and an accessible dashboard chart.
* ⚙️ Settings: Added visitor analytics controls with configurable retention and no storage of personal visitor identifiers.


= 1.1.0 =

* Added calendar-based editing for existing Working Day and date exclusion ranges.
* Added the ability to update or delete complete availability ranges from the Availability Planner.
* Added clearer controls for editing a complete recurring Working Day or changing an individual calendar occurrence.
* Added a chooser when a calendar date contains multiple editable availability or exclusion entries.
* Added a Default Tutor setting so Core availability is linked explicitly to the correct administrator on sites with multiple administrator accounts.
* Improved availability handling so explicitly-created tutor availability can override outside-term dates while tutor leave and booking conflicts remain blocked.
* Improved Availability Planner controls, loading behaviour and editing feedback.
* Fixed a booking status update error and other minor availability interface issues.



= 1.0.0 =

* Initial release of TutorHelper Bookings Core.
* Added Booking Types with duration, pricing, location, booking-notice and cancellation settings.
* Added recurring tutor Availability and date-specific availability changes.
* Added weekly and monthly Booking Hub calendar views.
* Added tutor-created booking management.
* Added student lesson requests with tutor confirmation.
* Added responsive student booking shortcode.
* Added student dashboard shortcode with pending, upcoming, cancelled and previous lessons.
* Added tutor and student cancellation workflows with cancellation reasons.
* Added TutorHelper student management.
* Added automatic lesson request, confirmation and cancellation emails.
* Added editable Core email subjects and message text.
* Added TutorHelper Pages, Currency and Email settings.
* Added configurable student login-page support with WordPress login fallback.
* Added TutorHelper Diagnostics and technical logging.
* Added Core booking security, ownership and permission checks.

== Upgrade Notice ==

= 2.2.1 =

Routes newly created Parent Accounts through the editable TutorHelper welcome-email workflow.

= 2.2.0 =

Adds compact and detailed weekly calendar displays. No data migration is required.

= 2.1.0 =

Introduces shared dashboard and email presentation improvements; no data migration is required.


= 2.0.0 =

Adds student account management, dashboard navigation, unpaid-request rejection, Terms and Conditions configuration, first-name email fields, and expanded Parent Account relationships. Review TutorHelper page and email settings after updating.

= 1.1.0 =

Adds calendar-based availability editing, a new Default Tutor setting, and improved handling of recurring Working Days, date exclusions and outside-term availability.

= 1.0.0 =

Initial release of TutorHelper Bookings.
